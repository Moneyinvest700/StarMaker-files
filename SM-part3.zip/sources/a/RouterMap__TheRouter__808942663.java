package a;

import defpackage.heq;
import defpackage.mld;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__808942663;", "Lmld;", "<init>", "()V", "", "init", "Companion", "heq", "impl"}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__808942663 implements mld {
    public static final int COUNT = 1;
    public static final heq Companion = new heq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://community/apply/moderator\",\"className\":\"com.starmakerinteractive.community.ui.view.CommunityApplyGroupLeaderActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/record\",\"className\":\"com.starmakerinteractive.community.ui.UsersCommunityActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/application\",\"className\":\"com.starmakerinteractive.community.ui.UsersApplicationCommunityActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/user\",\"className\":\"com.starmakerinteractive.community.ui.UsersAggregateCommunityPage\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/social/create\",\"className\":\"com.starmakerinteractive.community.ui.CommunitySocialCreateActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community_search\",\"className\":\"com.starmakerinteractive.community.ui.CommunitySearchActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/member/remove_or_block\",\"className\":\"com.starmakerinteractive.community.ui.CommunityRemoveOrBlockMembersActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/video/play\",\"className\":\"com.starmakerinteractive.community.ui.CommunityPostVideoPlayActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/detail\",\"className\":\"com.starmakerinteractive.community.ui.CommunityPostDetailActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/popular_new\",\"className\":\"com.starmakerinteractive.community.ui.CommunityPopularListNewActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/popular\",\"className\":\"com.starmakerinteractive.community.ui.CommunityPopularListActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/member\",\"className\":\"com.starmakerinteractive.community.ui.CommunityMembersActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community/club\",\"className\":\"com.starmakerinteractive.community.ui.CommunityHomeActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        heq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        heq.a();
    }
}
