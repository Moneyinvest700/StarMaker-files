package a;

import defpackage.beq;
import defpackage.mld;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__2121331530;", "Lmld;", "<init>", "()V", "", "init", "Companion", "beq", "impl"}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__2121331530 implements mld {
    public static final int COUNT = 1;
    public static final beq Companion = new beq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://video/crop\",\"className\":\"com.starmaker.ushowmedia.capturelib.trimmer.CropActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://publish/previewcapture\",\"className\":\"com.starmaker.ushowmedia.capturelib.previewandedit.ui.CapturePreviewActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://pick\",\"className\":\"com.starmaker.ushowmedia.capturelib.capture.ui.CaptureNoBgmActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://pick/bgm\",\"className\":\"com.starmaker.ushowmedia.capturelib.capture.ui.CaptureActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://publish/library\",\"className\":\"com.starmaker.ushowmedia.capturelib.SMMediaBridgeActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\",\"support_teenager\":\"true\"}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        beq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        beq.a();
    }
}
