package a;

import defpackage.mld;
import defpackage.vdq;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__1317921021;", "Lmld;", "<init>", "()V", "", "init", "Companion", "vdq", "impl"}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__1317921021 implements mld {
    public static final int COUNT = 1;
    public static final vdq Companion = new vdq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://recorder/voice_range_check\",\"className\":\"com.ushowmedia.recorder.recorderlib.voice.VoiceRangeCheckActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://audio_debug_tool\",\"className\":\"com.ushowmedia.recorder.recorderlib.sounddebugtool.SoundDebugToolActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\",\"support_teenager\":\"true\"}},{\"path\":\"sm://recorder/recently_deleted\",\"className\":\"com.ushowmedia.recorder.recorderlib.recently.ui.ProRecentlyDeletedActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://featured_group_pick\",\"className\":\"com.ushowmedia.recorder.recorderlib.preview.ui.GroupChorusPickActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://combined_template_album\",\"className\":\"com.ushowmedia.recorder.recorderlib.preview.template.TemplateAlbumAssemblyActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://selected_chorus_list\",\"className\":\"com.ushowmedia.recorder.recorderlib.pickgroup.activity.PickGroupRankListActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://recorder/draft_recall_tool\",\"className\":\"com.ushowmedia.recorder.recorderlib.draftrecall.tool.DraftRecallToolActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://aimv/preview_mv\",\"className\":\"com.ushowmedia.recorder.recorderlib.aimv.ui.AiMvVideoPreviewActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://aimv/home\",\"className\":\"com.ushowmedia.recorder.recorderlib.aimv.ui.AiMvHomeActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://aimv/preview_avatar\",\"className\":\"com.ushowmedia.recorder.recorderlib.aimv.ui.AiMvAvatarPreviewActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://aimv/preview_avatar_generating\",\"className\":\"com.ushowmedia.recorder.recorderlib.aimv.ui.AiMvAvatarGeneratingActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://aimv/avatar_create\",\"className\":\"com.ushowmedia.recorder.recorderlib.aimv.ui.AiMvAvatarCreateActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        vdq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        vdq.a();
    }
}
