package a;

import defpackage.mld;
import defpackage.wdq;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__1328491885;", "Lmld;", "<init>", "()V", "", "init", "Companion", "wdq", "impl"}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__1328491885 implements mld {
    public static final int COUNT = 1;
    public static final wdq Companion = new wdq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://rhythm_practice\",\"className\":\"com.ushowmedia.starmaker.feature.practice.rhythm.RhythmPracticeActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://practices\",\"className\":\"com.ushowmedia.starmaker.feature.practice.list.PracticeListActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://breath_practice\",\"className\":\"com.ushowmedia.starmaker.feature.practice.breath.BreathPracticeActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        wdq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        wdq.a();
    }
}
