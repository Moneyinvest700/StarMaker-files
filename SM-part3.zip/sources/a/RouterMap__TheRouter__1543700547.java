package a;

import defpackage.mld;
import defpackage.zdq;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__1543700547;", "Lmld;", "<init>", "()V", "", "init", "Companion", "zdq", "shared_user"}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__1543700547 implements mld {
    public static final int COUNT = 1;
    public static final zdq Companion = new zdq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://select_ethnicity\",\"className\":\"com.ushowmedia.starmaker.user.guide.SelectEthnicityActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"support_teenager\":\"true\"}},{\"path\":\"sm://select_nux_ethnicity\",\"className\":\"com.ushowmedia.starmaker.user.guide.NuxSelectEthnicityActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        zdq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        zdq.a();
    }
}
