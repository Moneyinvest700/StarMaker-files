package a;

import com.secmtp.sdk.core.common.my.mm;
import defpackage.ieq;
import defpackage.mld;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__96801;", "Lmld;", "<init>", "()V", "", "init", "Companion", "ieq", mm.C0192mm.mu}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__96801 implements mld {
    public static final int COUNT = 1;
    public static final ieq Companion = new ieq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://splash\",\"className\":\"com.ushowmedia.starmaker.splash.SplashActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"support_teenager\":\"true\"}},{\"path\":\"sm://vocal_enter\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://me\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"support_teenager\":\"true\"}},{\"path\":\"sm://podcast/home\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://moment\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://chatinbox\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://discovery\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://music\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"support_teenager\":\"true\"}},{\"path\":\"sm://sing\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://dynamic\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://library\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"support_teenager\":\"true\"}},{\"path\":\"sm://main\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"support_teenager\":\"true\"}},{\"path\":\"sm://home\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"support_teenager\":\"true\"}},{\"path\":\"sm://guide_float_window\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://community\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/multivoice\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/home\",\"className\":\"com.ushowmedia.starmaker.main.MainActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        ieq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        ieq.a();
    }
}
