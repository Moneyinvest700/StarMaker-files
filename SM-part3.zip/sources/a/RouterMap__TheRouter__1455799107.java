package a;

import defpackage.mld;
import defpackage.ydq;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__1455799107;", "Lmld;", "<init>", "()V", "", "init", "Companion", "ydq", "impl"}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__1455799107 implements mld {
    public static final int COUNT = 1;
    public static final ydq Companion = new ydq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://ktv_test_gateway\",\"className\":\"com.ushowmedia.ktvlib.test.TestGatewayActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/room_report\",\"className\":\"com.ushowmedia.ktvlib.feature.roomreport.RoomReportActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/myroom\",\"className\":\"com.ushowmedia.ktvlib.RoomsActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://parties/innerstarrank\",\"className\":\"com.ushowmedia.ktvlib.PartyStarActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/rich_users\",\"className\":\"com.ushowmedia.ktvlib.PartyRichUsersActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://parties/new_users\",\"className\":\"com.ushowmedia.ktvlib.PartyNewUsersActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://heartbeat_chorus_match\",\"className\":\"com.ushowmedia.ktvlib.PartyHeartbeatMatchActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://heartbeat_chorus_game\",\"className\":\"com.ushowmedia.ktvlib.PartyHeartbeatChorusActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://party_room\",\"className\":\"com.ushowmedia.ktvlib.PartyActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://ktv_privilege\",\"className\":\"com.ushowmedia.ktvlib.KtvRoomPrivilegeActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/frequent\",\"className\":\"com.ushowmedia.ktvlib.HistoryActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/history\",\"className\":\"com.ushowmedia.ktvlib.HistoryActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://parties/giftchallenge\",\"className\":\"com.ushowmedia.ktvlib.GiftChallengeManagerActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://parties/create\",\"className\":\"com.ushowmedia.ktvlib.BuildActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://parties/roominfo\",\"className\":\"com.ushowmedia.ktvlib.BuildActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        ydq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        ydq.a();
    }
}
