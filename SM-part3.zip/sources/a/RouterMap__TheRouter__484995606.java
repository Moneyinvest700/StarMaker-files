package a;

import defpackage.deq;
import defpackage.mld;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0003¨\u0006\b"}, d2 = {"La/RouterMap__TheRouter__484995606;", "Lmld;", "<init>", "()V", "", "init", "Companion", "deq", "impl"}, k = 1, mv = {2, 3, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RouterMap__TheRouter__484995606 implements mld {
    public static final int COUNT = 1;
    public static final deq Companion = new deq();
    public static final String ROUTERMAP0 = "[{\"path\":\"sm://message_no_disturb_setting\",\"className\":\"com.ushowmedia.chatlib.setting.PromotionMessageSettingActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://setting/stranger_message_shield\",\"className\":\"com.ushowmedia.chatlib.inbox.stranger.InboxStrangerSettingActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://chat/group/members\",\"className\":\"com.ushowmedia.chatlib.group.edit.GroupMembersActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://chat/remove/member\",\"className\":\"com.ushowmedia.chatlib.group.edit.ChatRemoveMemberActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://chat/edittext\",\"className\":\"com.ushowmedia.chatlib.group.edit.ChatEditTextActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://chat/group/detail\",\"className\":\"com.ushowmedia.chatlib.group.detail.ChatGroupDetailActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://chat/create/conversation\",\"className\":\"com.ushowmedia.chatlib.create.CreateConversationActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://community_member_with_check\",\"className\":\"com.ushowmedia.chatlib.create.CommunityMemberWithCheckActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://familyGroupSkinSetting\",\"className\":\"com.ushowmedia.chatlib.chat.skin.ChatSkinSettingActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://select_members\",\"className\":\"com.ushowmedia.chatlib.chat.SelectGroupMemberActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://chat_group/list\",\"className\":\"com.ushowmedia.chatlib.chat.FamilyGroupListActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}},{\"path\":\"sm://buddy/message_setting\",\"className\":\"com.ushowmedia.chatlib.chat.ChatBuddyMessageSettingActivity\",\"action\":\"\",\"description\":\"\",\"params\":{}},{\"path\":\"sm://chat\",\"className\":\"com.ushowmedia.chatlib.chat.ChatActivity\",\"action\":\"\",\"description\":\"\",\"params\":{\"need_login\":\"true\"}}]";
    public static final String TAG = "Created by kymjs, and KSP Version is 1.3.2.";
    public static final String THEROUTER_APT_VERSION = "1.3.2";

    public static final void addRoute() {
        Companion.getClass();
        deq.a();
    }

    @Override // defpackage.mld
    public void init() {
        Companion.getClass();
        deq.a();
    }
}
