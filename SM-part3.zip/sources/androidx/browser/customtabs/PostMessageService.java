package androidx.browser.customtabs;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import defpackage.l9n;
import defpackage.rkd;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class PostMessageService extends Service {
    public final l9n b;

    public PostMessageService() {
        l9n l9nVar = new l9n();
        l9nVar.attachInterface(l9nVar, rkd.No);
        this.b = l9nVar;
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return this.b;
    }
}
