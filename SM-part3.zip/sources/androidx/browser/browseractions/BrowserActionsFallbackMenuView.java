package androidx.browser.browseractions;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.starmakerinteractive.starmaker.R;
import com.ushowmedia.starmaker.feature.login.secure.email.ui.EmailLinkActivity;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Deprecated
/* loaded from: classes4.dex */
public class BrowserActionsFallbackMenuView extends LinearLayout {
    public final int b;
    public final int c;

    public BrowserActionsFallbackMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = getResources().getDimensionPixelOffset(R.dimen.browser_actions_context_menu_min_padding);
        this.c = getResources().getDimensionPixelOffset(R.dimen.browser_actions_context_menu_max_width);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(Math.min(getResources().getDisplayMetrics().widthPixels - (this.b * 2), this.c), EmailLinkActivity.SEND_TO_CURRENT), i2);
    }
}
