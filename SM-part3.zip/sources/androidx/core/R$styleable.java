package androidx.core;

import android.R;

/* loaded from: classes5.dex */
public final class R$styleable {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f4309a = {R.attr.color, R.attr.alpha, R.attr.lStar, com.starmakerinteractive.starmaker.R.attr.alpha, com.starmakerinteractive.starmaker.R.attr.lStar};
    public static final int[] b = {com.starmakerinteractive.starmaker.R.attr.fontProviderAuthority, com.starmakerinteractive.starmaker.R.attr.fontProviderCerts, com.starmakerinteractive.starmaker.R.attr.fontProviderFallbackQuery, com.starmakerinteractive.starmaker.R.attr.fontProviderFetchStrategy, com.starmakerinteractive.starmaker.R.attr.fontProviderFetchTimeout, com.starmakerinteractive.starmaker.R.attr.fontProviderPackage, com.starmakerinteractive.starmaker.R.attr.fontProviderQuery, com.starmakerinteractive.starmaker.R.attr.fontProviderSystemFontFamily};
    public static final int[] c = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, com.starmakerinteractive.starmaker.R.attr.font, com.starmakerinteractive.starmaker.R.attr.fontStyle, com.starmakerinteractive.starmaker.R.attr.fontVariationSettings, com.starmakerinteractive.starmaker.R.attr.fontWeight, com.starmakerinteractive.starmaker.R.attr.ttcIndex};
    public static final int[] d = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};
    public static final int[] e = {R.attr.color, R.attr.offset};
}
