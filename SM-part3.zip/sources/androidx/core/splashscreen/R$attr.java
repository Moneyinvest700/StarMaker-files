package androidx.core.splashscreen;

/* loaded from: classes.dex */
public final class R$attr {
}
