package androidx.core.splashscreen;

/* loaded from: classes4.dex */
public final class R$id {
}
