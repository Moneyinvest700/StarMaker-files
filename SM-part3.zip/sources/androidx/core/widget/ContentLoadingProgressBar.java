package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import androidx.core.widget.ContentLoadingProgressBar;
import defpackage.b95;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class ContentLoadingProgressBar extends ProgressBar {
    public static final /* synthetic */ int d = 0;
    public final b95 b;
    public final b95 c;

    /* JADX WARN: Type inference failed for: r2v1, types: [b95] */
    /* JADX WARN: Type inference failed for: r2v2, types: [b95] */
    public ContentLoadingProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        final int i = 0;
        this.b = new Runnable(this) { // from class: b95
            public final /* synthetic */ ContentLoadingProgressBar c;

            {
                this.c = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                int i2 = i;
                ContentLoadingProgressBar contentLoadingProgressBar = this.c;
                switch (i2) {
                    case 0:
                        int i3 = ContentLoadingProgressBar.d;
                        contentLoadingProgressBar.setVisibility(8);
                        break;
                    default:
                        int i4 = ContentLoadingProgressBar.d;
                        System.currentTimeMillis();
                        contentLoadingProgressBar.setVisibility(0);
                        break;
                }
            }
        };
        final int i2 = 1;
        this.c = new Runnable(this) { // from class: b95
            public final /* synthetic */ ContentLoadingProgressBar c;

            {
                this.c = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                int i22 = i2;
                ContentLoadingProgressBar contentLoadingProgressBar = this.c;
                switch (i22) {
                    case 0:
                        int i3 = ContentLoadingProgressBar.d;
                        contentLoadingProgressBar.setVisibility(8);
                        break;
                    default:
                        int i4 = ContentLoadingProgressBar.d;
                        System.currentTimeMillis();
                        contentLoadingProgressBar.setVisibility(0);
                        break;
                }
            }
        };
    }

    @Override // android.widget.ProgressBar, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(this.b);
        removeCallbacks(this.c);
    }

    @Override // android.widget.ProgressBar, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.b);
        removeCallbacks(this.c);
    }

    public ContentLoadingProgressBar(Context context) {
        this(context, null);
    }
}
