package androidx.coordinatorlayout.widget;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Retention(RetentionPolicy.RUNTIME)
/* loaded from: classes4.dex */
public @interface b {
    Class value();
}
