package androidx.coordinatorlayout;

import com.starmakerinteractive.starmaker.R;

/* loaded from: classes4.dex */
public final class R$styleable {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f4307a = {R.attr.keylines, R.attr.statusBarBackground};
    public static final int[] b = {android.R.attr.layout_gravity, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};
}
