package androidx.asynclayoutinflater;

/* loaded from: classes4.dex */
public final class R$color {
}
