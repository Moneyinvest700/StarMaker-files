package androidx.cardview;

import android.R;

/* loaded from: classes.dex */
public final class R$styleable {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f4297a = {R.attr.minWidth, R.attr.minHeight, com.starmakerinteractive.starmaker.R.attr.cardBackgroundColor, com.starmakerinteractive.starmaker.R.attr.cardCornerRadius, com.starmakerinteractive.starmaker.R.attr.cardElevation, com.starmakerinteractive.starmaker.R.attr.cardMaxElevation, com.starmakerinteractive.starmaker.R.attr.cardPreventCornerOverlap, com.starmakerinteractive.starmaker.R.attr.cardUseCompatPadding, com.starmakerinteractive.starmaker.R.attr.contentPadding, com.starmakerinteractive.starmaker.R.attr.contentPaddingBottom, com.starmakerinteractive.starmaker.R.attr.contentPaddingLeft, com.starmakerinteractive.starmaker.R.attr.contentPaddingRight, com.starmakerinteractive.starmaker.R.attr.contentPaddingTop};
}
