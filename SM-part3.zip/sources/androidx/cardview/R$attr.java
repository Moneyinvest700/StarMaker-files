package androidx.cardview;

/* loaded from: classes.dex */
public final class R$attr {
}
