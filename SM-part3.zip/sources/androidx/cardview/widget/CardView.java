package androidx.cardview.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import androidx.cardview.R$styleable;
import defpackage.nru;
import defpackage.ucq;
import defpackage.w8c;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes.dex */
public class CardView extends FrameLayout {
    public static final int[] g = {R.attr.colorBackground};
    public boolean b;
    public boolean c;
    public final Rect d;
    public final Rect e;
    public final nru f;

    public CardView(Context context, AttributeSet attributeSet, int i) {
        ColorStateList colorStateListValueOf;
        super(context, attributeSet, i);
        Rect rect = new Rect();
        this.d = rect;
        this.e = new Rect();
        nru nruVar = new nru(this, 5);
        this.f = nruVar;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.f4297a, i, com.starmakerinteractive.starmaker.R.style.CardView);
        if (typedArrayObtainStyledAttributes.hasValue(2)) {
            colorStateListValueOf = typedArrayObtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray typedArrayObtainStyledAttributes2 = getContext().obtainStyledAttributes(g);
            int color = typedArrayObtainStyledAttributes2.getColor(0, 0);
            typedArrayObtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            colorStateListValueOf = ColorStateList.valueOf(fArr[2] > 0.5f ? getResources().getColor(com.starmakerinteractive.starmaker.R.color.cardview_light_background) : getResources().getColor(com.starmakerinteractive.starmaker.R.color.cardview_dark_background));
        }
        float dimension = typedArrayObtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = typedArrayObtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = typedArrayObtainStyledAttributes.getDimension(5, 0.0f);
        this.b = typedArrayObtainStyledAttributes.getBoolean(7, false);
        this.c = typedArrayObtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = typedArrayObtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = typedArrayObtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = typedArrayObtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        ucq ucqVar = new ucq(colorStateListValueOf, dimension);
        nruVar.c = ucqVar;
        setBackgroundDrawable(ucqVar);
        setClipToOutline(true);
        setElevation(dimension2);
        w8c.m(nruVar, dimension3);
    }

    public ColorStateList getCardBackgroundColor() {
        return ((ucq) this.f.c).h;
    }

    public float getCardElevation() {
        return ((CardView) this.f.d).getElevation();
    }

    public int getContentPaddingBottom() {
        return this.d.bottom;
    }

    public int getContentPaddingLeft() {
        return this.d.left;
    }

    public int getContentPaddingRight() {
        return this.d.right;
    }

    public int getContentPaddingTop() {
        return this.d.top;
    }

    public float getMaxCardElevation() {
        return ((ucq) this.f.c).e;
    }

    public boolean getPreventCornerOverlap() {
        return this.c;
    }

    public float getRadius() {
        return ((ucq) this.f.c).f16400a;
    }

    public boolean getUseCompatPadding() {
        return this.b;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }

    public void setCardBackgroundColor(int i) {
        ColorStateList colorStateListValueOf = ColorStateList.valueOf(i);
        ucq ucqVar = (ucq) this.f.c;
        if (colorStateListValueOf == null) {
            ucqVar.getClass();
            colorStateListValueOf = ColorStateList.valueOf(0);
        }
        ucqVar.h = colorStateListValueOf;
        ucqVar.b.setColor(colorStateListValueOf.getColorForState(ucqVar.getState(), ucqVar.h.getDefaultColor()));
        ucqVar.invalidateSelf();
    }

    public void setCardElevation(float f) {
        ((CardView) this.f.d).setElevation(f);
    }

    public void setMaxCardElevation(float f) {
        w8c.m(this.f, f);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i) {
        super.setMinimumHeight(i);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i) {
        super.setMinimumWidth(i);
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.c) {
            this.c = z;
            nru nruVar = this.f;
            w8c.m(nruVar, ((ucq) nruVar.c).e);
        }
    }

    public void setRadius(float f) {
        ucq ucqVar = (ucq) this.f.c;
        if (f == ucqVar.f16400a) {
            return;
        }
        ucqVar.f16400a = f;
        ucqVar.b(null);
        ucqVar.invalidateSelf();
    }

    public void setUseCompatPadding(boolean z) {
        if (this.b != z) {
            this.b = z;
            nru nruVar = this.f;
            w8c.m(nruVar, ((ucq) nruVar.c).e);
        }
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        ucq ucqVar = (ucq) this.f.c;
        if (colorStateList == null) {
            ucqVar.getClass();
            colorStateList = ColorStateList.valueOf(0);
        }
        ucqVar.h = colorStateList;
        ucqVar.b.setColor(colorStateList.getColorForState(ucqVar.getState(), ucqVar.h.getDefaultColor()));
        ucqVar.invalidateSelf();
    }

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.starmakerinteractive.starmaker.R.attr.cardViewStyle);
    }

    public CardView(Context context) {
        this(context, null);
    }

    @Override // android.view.View
    public final void setPadding(int i, int i2, int i3, int i4) {
    }

    @Override // android.view.View
    public final void setPaddingRelative(int i, int i2, int i3, int i4) {
    }
}
