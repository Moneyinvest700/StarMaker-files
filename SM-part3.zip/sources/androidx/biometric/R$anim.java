package androidx.biometric;

/* loaded from: classes4.dex */
public final class R$anim {
}
