package android.support.v4.os;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import defpackage.erp;
import defpackage.ild;
import defpackage.kbm;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class ResultReceiver implements Parcelable {
    public static final Parcelable.Creator<ResultReceiver> CREATOR = new kbm(28);
    public ild b;

    public final void b(int i, Bundle bundle) {
        ild ildVar = this.b;
        if (ildVar != null) {
            try {
                ildVar.q(i, bundle);
            } catch (RemoteException unused) {
            }
        }
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            try {
                ild erpVar = this.b;
                if (erpVar == null) {
                    erpVar = new erp(this);
                    this.b = erpVar;
                }
                parcel.writeStrongBinder(erpVar.asBinder());
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void a(int i, Bundle bundle) {
    }
}
