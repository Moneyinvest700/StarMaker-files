package android.support.v4.media;

import android.os.Bundle;
import android.support.v4.os.ResultReceiver;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
class MediaBrowserCompat$CustomActionResultReceiver extends ResultReceiver {
    @Override // android.support.v4.os.ResultReceiver
    public final void a(int i, Bundle bundle) {
    }
}
