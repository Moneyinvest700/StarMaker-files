package android.media;

/* loaded from: classes5.dex */
public /* synthetic */ interface Spatializer$OnSpatializerStateChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
