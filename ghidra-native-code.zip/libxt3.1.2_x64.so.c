// ==== _FINI_1 @ 00115ff0

void _FINI_1(void)

{
  __cxa_finalize(&PTR_LOOP_0013e320);
  return;
}


// ==== _FINI_0 @ 00116010

undefined8 _FINI_0(void)

{
  undefined8 in_RAX;
  
  if (DAT_00145340 == '\x01') {
    pthread_key_delete(DAT_00145344);
    DAT_00145340 = '\0';
  }
  return in_RAX;
}


// ==== FUN_00116ab0 @ 00116ab0

undefined8 * FUN_00116ab0(char *param_1,char *param_2)

{
  long *plVar1;
  size_t __n;
  void *__dest;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  ulong uVar6;
  long in_FS_OFFSET;
  undefined8 local_70 [3];
  undefined8 local_58;
  size_t sStack_50;
  void *local_48;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  if (*param_1 == '\0') {
    *param_1 = '\x01';
    plVar1 = (long *)FUN_0011e900(0x18);
    plVar1[1] = 0;
    plVar1[2] = 0;
    *plVar1 = (long)(plVar1 + 1);
    *(long **)(param_1 + 8) = plVar1;
  }
  else if (*param_1 != '\x01') {
    uVar4 = FUN_001202b0(0x20);
    uVar5 = FUN_00118770(param_1);
                    /* try { // try from 00116c5d to 00116c69 has its CatchHandler @ 00116d44 */
    FUN_001186c0(local_70,uVar5);
                    /* try { // try from 00116c6a to 00116c7c has its CatchHandler @ 00116d2e */
    puVar3 = (undefined8 *)
             FUN_0011f030(local_70,0,"cannot use operator[] with a string argument with ");
    local_48 = (void *)puVar3[2];
    local_58 = *puVar3;
    sStack_50 = puVar3[1];
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
                    /* try { // try from 00116c9f to 00116cc8 has its CatchHandler @ 00116cf4 */
    FUN_00118540(uVar4,0x131,&local_58);
    FUN_00120320(uVar4,&PTR_PTR_0013e390,&LAB_00118750);
    goto LAB_00116cc9;
  }
  plVar1 = *(long **)(param_1 + 8);
  __n = strlen(param_2);
  if (0xffffffffffffffef < __n) {
LAB_00116cc9:
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(&local_58);
  }
  if (__n < 0x17) {
    local_58 = CONCAT71(local_58._1_7_,(char)__n * '\x02');
    __dest = (void *)((long)&local_58 + 1);
    if (__n == 0) goto LAB_00116b6c;
  }
  else {
    uVar6 = __n + 0x10 & 0xfffffffffffffff0;
    __dest = (void *)FUN_0011e900(uVar6);
    local_58 = uVar6 | 1;
    sStack_50 = __n;
    local_48 = __dest;
  }
  memcpy(__dest,param_2,__n);
LAB_00116b6c:
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 00116b71 to 00116bd2 has its CatchHandler @ 00116cd8 */
  puVar2 = (undefined8 *)FUN_001190f0(plVar1,local_70,&local_58);
  puVar3 = (undefined8 *)*puVar2;
  if (puVar3 == (undefined8 *)0x0) {
    puVar3 = (undefined8 *)FUN_0011e900(0x48);
    puVar3[6] = local_48;
    puVar3[4] = local_58;
    puVar3[5] = sStack_50;
    local_58 = 0;
    sStack_50 = 0;
    local_48 = (void *)0x0;
    *(undefined1 *)(puVar3 + 7) = 0;
    puVar3[8] = 0;
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = local_70[0];
    *puVar2 = puVar3;
    if (*(long *)*plVar1 == 0) {
      puVar2 = puVar3;
    }
    else {
      *plVar1 = *(long *)*plVar1;
      puVar2 = (undefined8 *)*puVar2;
    }
    FUN_00119260(plVar1[1],puVar2);
    plVar1[2] = plVar1[2] + 1;
  }
  if ((local_58 & 1) != 0) {
    free(local_48);
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar3 + 7;
}


// ==== FUN_00116d60 @ 00116d60

long FUN_00116d60(char *param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  ulong uVar4;
  long lVar5;
  long in_FS_OFFSET;
  undefined1 local_60 [24];
  undefined8 local_48;
  undefined8 uStack_40;
  undefined8 local_38;
  long local_28;
  
  local_28 = *(long *)(in_FS_OFFSET + 0x28);
  if (*param_1 == '\0') {
    *param_1 = '\x02';
    puVar1 = (undefined8 *)FUN_0011e900(0x18);
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    *(undefined8 **)(param_1 + 8) = puVar1;
    uVar4 = puVar1[1];
    if (uVar4 < (ulong)puVar1[2]) goto LAB_00116db3;
LAB_00116ddd:
    FUN_001195b0(puVar1,param_2);
    lVar5 = puVar1[1];
  }
  else {
    if (*param_1 != '\x02') {
      uVar2 = FUN_001202b0(0x20);
      uVar3 = FUN_00118770(param_1);
                    /* try { // try from 00116e29 to 00116e35 has its CatchHandler @ 00116ef7 */
      FUN_001186c0(local_60,uVar3);
                    /* try { // try from 00116e36 to 00116e48 has its CatchHandler @ 00116ee1 */
      puVar1 = (undefined8 *)FUN_0011f030(local_60,0,"cannot use emplace_back() with ");
      local_38 = puVar1[2];
      local_48 = *puVar1;
      uStack_40 = puVar1[1];
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
                    /* try { // try from 00116e6a to 00116e93 has its CatchHandler @ 00116ea3 */
      FUN_00118540(uVar2,0x137,&local_48);
      FUN_00120320(uVar2,&PTR_PTR_0013e390,&LAB_00118750);
      goto LAB_00116e94;
    }
    puVar1 = *(undefined8 **)(param_1 + 8);
    uVar4 = puVar1[1];
    if ((ulong)puVar1[2] <= uVar4) goto LAB_00116ddd;
LAB_00116db3:
                    /* try { // try from 00116db3 to 00116dbd has its CatchHandler @ 00116e99 */
    FUN_00118a60(uVar4,param_2);
    lVar5 = uVar4 + 0x10;
    puVar1[1] = lVar5;
  }
  if (*(long *)(in_FS_OFFSET + 0x28) == local_28) {
    return lVar5 + -0x10;
  }
LAB_00116e94:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00116f10 @ 00116f10

undefined8 *
FUN_00116f10(undefined8 *param_1,undefined8 param_2,int param_3,byte param_4,undefined1 param_5,
            undefined4 param_6)

{
  long *plVar1;
  long lVar2;
  char *pcVar3;
  long *plVar4;
  void *__s;
  long in_FS_OFFSET;
  long *local_2b8;
  long *local_2b0;
  undefined8 local_2a8;
  undefined8 uStack_2a0;
  undefined8 local_298;
  undefined8 uStack_290;
  undefined8 local_288;
  undefined8 uStack_280;
  undefined8 local_278;
  undefined8 uStack_270;
  lconv *local_268;
  char local_260;
  char local_25f;
  undefined1 local_25e [512];
  byte local_5e;
  ulong local_58;
  undefined8 uStack_50;
  void *local_48;
  undefined4 local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
                    /* try { // try from 00116f56 to 00116f5f has its CatchHandler @ 00117150 */
  plVar4 = (long *)FUN_0011e900(0x28);
  plVar4[1] = 0;
  plVar4[2] = 0;
  *plVar4 = (long)&PTR_LAB_0013e408;
  local_2b8 = plVar4 + 3;
  plVar4[3] = (long)&PTR_LAB_0013e440;
  plVar4[4] = (long)param_1;
  LOCK();
  plVar4[1] = plVar4[1] + 1;
  UNLOCK();
  local_2a8 = 0;
  uStack_2a0 = 0;
  local_298 = 0;
  uStack_290 = 0;
  local_288 = 0;
  uStack_280 = 0;
  local_278 = 0;
  uStack_270 = 0;
  local_2b0 = plVar4;
                    /* try { // try from 00116fbe to 00116fc2 has its CatchHandler @ 00117155 */
  local_268 = localeconv();
  if (local_268->thousands_sep == (char *)0x0) {
    local_260 = '\0';
    pcVar3 = local_268->decimal_point;
  }
  else {
    local_260 = *local_268->thousands_sep;
    pcVar3 = local_268->decimal_point;
  }
  if (pcVar3 == (char *)0x0) {
    local_25f = '\0';
  }
  else {
    local_25f = *pcVar3;
  }
  memset(local_25e,0,0x200);
  local_5e = param_4;
                    /* try { // try from 0011701f to 00117028 has its CatchHandler @ 00117155 */
  __s = (void *)FUN_0011e900(0x210);
  local_58 = 0x211;
  uStack_50 = 0x200;
  local_48 = __s;
  memset(__s,(uint)param_4,0x200);
  *(undefined1 *)((long)__s + 0x200) = 0;
  LOCK();
  plVar1 = plVar4 + 1;
  lVar2 = *plVar1;
  *plVar1 = *plVar1 + -1;
  UNLOCK();
  local_40 = param_6;
  if (lVar2 == 0) {
    (**(code **)(*plVar4 + 0x10))(plVar4);
    FUN_0011e880(plVar4);
  }
  if (param_3 < 0) {
                    /* try { // try from 001170b3 to 001170ce has its CatchHandler @ 00117141 */
    FUN_001197c0(&local_2b8,param_2,0,param_5,0,0);
  }
  else {
                    /* try { // try from 0011707b to 00117099 has its CatchHandler @ 00117141 */
    FUN_001197c0(&local_2b8,param_2,1,param_5,param_3,0);
  }
  if ((local_58 & 1) != 0) {
    free(local_48);
  }
  plVar4 = local_2b0;
  if (local_2b0 != (long *)0x0) {
    LOCK();
    plVar1 = local_2b0 + 1;
    lVar2 = *plVar1;
    *plVar1 = *plVar1 + -1;
    UNLOCK();
    if (lVar2 == 0) {
      (**(code **)(*local_2b0 + 0x10))(local_2b0);
      FUN_0011e880(plVar4);
    }
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== JNI_OnLoad @ 001173f0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 JNI_OnLoad(long *param_1)

{
  int iVar1;
  long lVar2;
  long lVar3;
  undefined8 uVar4;
  long in_FS_OFFSET;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  char cVar11;
  ushort uVar12;
  undefined4 uVar13;
  undefined6 uVar14;
  undefined1 auVar15 [12];
  undefined1 auVar16 [14];
  char cVar19;
  char cVar20;
  char cVar21;
  char cVar22;
  char cVar23;
  char cVar24;
  char cVar25;
  char cVar26;
  char cVar27;
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined1 auVar28 [12];
  undefined1 auVar29 [12];
  undefined1 auVar30 [14];
  undefined1 auVar31 [14];
  undefined1 auVar32 [16];
  undefined1 auVar33 [16];
  undefined1 auVar34 [16];
  undefined1 auVar35 [16];
  undefined1 auVar36 [12];
  undefined1 auVar38 [14];
  undefined1 auVar40 [16];
  undefined1 auVar41 [16];
  undefined1 auVar42 [16];
  undefined1 auVar37 [12];
  undefined1 auVar39 [14];
  undefined1 auVar43 [16];
  undefined1 auVar44 [16];
  undefined1 auVar45 [16];
  undefined1 auVar46 [16];
  long *local_80;
  undefined1 local_78;
  char cStack_77;
  char cStack_76;
  char cStack_75;
  char cStack_74;
  char cStack_73;
  char cStack_72;
  char cStack_71;
  char cStack_70;
  char cStack_6f;
  char cStack_6e;
  char cStack_6d;
  char cStack_6c;
  char cStack_6b;
  char cStack_6a;
  char cStack_69;
  char local_68;
  char cStack_67;
  char cStack_66;
  char cStack_65;
  char cStack_64;
  char cStack_63;
  char cStack_62;
  char cStack_61;
  char cStack_60;
  char cStack_5f;
  char cStack_5e;
  char cStack_5d;
  char cStack_5c;
  char cStack_5b;
  char cStack_5a;
  char cStack_59;
  char cStack_58;
  undefined8 local_57;
  undefined1 local_48;
  char cStack_47;
  char cStack_46;
  char cStack_45;
  char cStack_44;
  char cStack_43;
  char cStack_42;
  char cStack_41;
  char cStack_40;
  char cStack_3f;
  char cStack_3e;
  char cStack_3d;
  char cStack_3c;
  char cStack_3b;
  char cStack_3a;
  char cStack_39;
  char cStack_38;
  undefined1 local_37;
  undefined8 local_36;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  iVar1 = (**(code **)(*param_1 + 0x30))(param_1,&local_80,0x10004);
  uVar4 = 0xffffffff;
  if (iVar1 == 0) {
    lVar2 = (**(code **)(*local_80 + 0x30))(local_80,"com/netease/mobsec/xt/a");
    lVar3 = (**(code **)(*local_80 + 0x78))(local_80);
    if (lVar3 == 0) {
      if (lVar2 != 0) {
        iVar1 = (**(code **)(*local_80 + 0x6b8))(local_80,lVar2,&PTR_DAT_0013e330,3);
        if (-1 < iVar1) {
          local_48 = 0x2e;
          auVar5[8] = 0x2e;
          auVar5._0_8_ = 0x1b18d1d2ebd4eca7;
          auVar5[9] = 0x45;
          auVar5[10] = 0x50;
          auVar5[0xb] = 0xcf;
          auVar5[0xc] = 0xe6;
          auVar5[0xd] = 0xe;
          auVar5[0xe] = 0x94;
          auVar5[0xf] = 0x8a;
          auVar5 = auVar5 ^ _DAT_001097e0;
          auVar44._0_2_ = auVar5._0_2_ >> 3;
          auVar44._2_2_ = auVar5._2_2_ >> 3;
          auVar44._4_2_ = auVar5._4_2_ >> 3;
          auVar44._6_2_ = auVar5._6_2_ >> 3;
          auVar44._8_2_ = auVar5._8_2_ >> 3;
          auVar44._10_2_ = auVar5._10_2_ >> 3;
          auVar44._12_2_ = auVar5._12_2_ >> 3;
          auVar44._14_2_ = auVar5._14_2_ >> 3;
          auVar5 = psllw(auVar5,5);
          auVar5 = auVar5 & _DAT_001097b0 | auVar44 & _DAT_00109730;
          cVar11 = '\x02' - auVar5[0];
          cVar19 = '\x02' - auVar5[1];
          uVar12 = CONCAT11(cVar19,cVar11);
          cVar20 = '\x02' - auVar5[2];
          cVar21 = '\x02' - auVar5[3];
          uVar13 = CONCAT13(cVar21,CONCAT12(cVar20,uVar12));
          cVar22 = '\x02' - auVar5[4];
          cVar23 = '\x02' - auVar5[5];
          uVar14 = CONCAT15(cVar23,CONCAT14(cVar22,uVar13));
          cVar24 = '\x02' - auVar5[6];
          cVar25 = '\x02' - auVar5[7];
          uVar4 = CONCAT17(cVar25,CONCAT16(cVar24,uVar14));
          cVar26 = '\x02' - auVar5[8];
          cVar27 = '\x02' - auVar5[9];
          auVar15._0_10_ = CONCAT19(cVar27,CONCAT18(cVar26,uVar4));
          auVar15[10] = '\x02' - auVar5[10];
          auVar15[0xb] = '\x02' - auVar5[0xb];
          auVar16[0xc] = '\x02' - auVar5[0xc];
          auVar16._0_12_ = auVar15;
          auVar16[0xd] = '\x02' - auVar5[0xd];
          auVar17[0xe] = '\x02' - auVar5[0xe];
          auVar17._0_14_ = auVar16;
          auVar17[0xf] = '\x02' - auVar5[0xf];
          auVar9._0_2_ = uVar12 >> 7;
          auVar9._2_2_ = (ushort)((uint)uVar13 >> 0x17);
          auVar9._4_2_ = (ushort)((uint6)uVar14 >> 0x27);
          auVar9._6_2_ = (ushort)((ulong)uVar4 >> 0x37);
          auVar9._8_2_ = (ushort)((unkuint10)auVar15._0_10_ >> 0x47);
          auVar9._10_2_ = auVar15._10_2_ >> 7;
          auVar9._12_2_ = auVar16._12_2_ >> 7;
          auVar9._14_2_ = auVar17._14_2_ >> 7;
          auVar18[1] = cVar19 * '\x02';
          auVar18[0] = cVar11 * '\x02';
          auVar18[2] = cVar20 * '\x02';
          auVar18[3] = cVar21 * '\x02';
          auVar18[4] = cVar22 * '\x02';
          auVar18[5] = cVar23 * '\x02';
          auVar18[6] = cVar24 * '\x02';
          auVar18[7] = cVar25 * '\x02';
          auVar18[8] = cVar26 * '\x02';
          auVar18[9] = cVar27 * '\x02';
          auVar18[10] = auVar15[10] * '\x02';
          auVar18[0xb] = auVar15[0xb] * '\x02';
          auVar18[0xc] = auVar16[0xc] * '\x02';
          auVar18[0xd] = auVar16[0xd] * '\x02';
          auVar18[0xe] = auVar17[0xe] * '\x02';
          auVar18[0xf] = auVar17[0xf] * '\x02';
          auVar5 = (auVar18 | auVar9 & _DAT_001096e0) ^ _DAT_00109760;
          cStack_47 = (auVar5[0] ^ 0xe2) - 1;
          cStack_46 = (auVar5[1] - 1U ^ 0xe2) - 2;
          cStack_45 = (auVar5[2] - 2U ^ 0xe2) - 3;
          cStack_44 = (auVar5[3] - 3U ^ 0xe2) - 4;
          cStack_43 = (auVar5[4] - 4U ^ 0xe2) - 5;
          cStack_42 = (auVar5[5] - 5U ^ 0xe2) - 6;
          cStack_41 = (auVar5[6] - 6U ^ 0xe2) - 7;
          cStack_40 = (auVar5[7] - 7U ^ 0xe2) - 8;
          cStack_3f = (auVar5[8] - 8U ^ 0xe2) - 9;
          cStack_3e = (auVar5[9] - 9U ^ 0xe2) - 10;
          cStack_3d = (auVar5[10] - 10U ^ 0xe2) - 0xb;
          cStack_3c = (auVar5[0xb] - 0xbU ^ 0xe2) - 0xc;
          cStack_3b = (auVar5[0xc] - 0xcU ^ 0xe2) - 0xd;
          cStack_3a = (auVar5[0xd] - 0xdU ^ 0xe2) - 0xe;
          cStack_39 = (auVar5[0xe] - 0xeU ^ 0xe2) - 0xf;
          cStack_38 = (auVar5[0xf] - 0xfU ^ 0xe2) - 0x10;
          local_37 = 0x74;
          auVar40[8] = 10;
          auVar40._0_8_ = 0x12b77e0e7a5386ce;
          auVar40[9] = 0x6e;
          auVar40[10] = 0xaa;
          auVar40[0xb] = 0x9a;
          auVar40[0xc] = 0x8a;
          auVar40[0xd] = 0x12;
          auVar40[0xe] = 0x9f;
          auVar40[0xf] = 0x4a;
          auVar40 = auVar40 ^ _DAT_001097c0;
          auVar45._0_2_ = auVar40._0_2_ >> 1;
          auVar45._2_2_ = auVar40._2_2_ >> 1;
          auVar45._4_2_ = auVar40._4_2_ >> 1;
          auVar45._6_2_ = auVar40._6_2_ >> 1;
          auVar45._8_2_ = auVar40._8_2_ >> 1;
          auVar45._10_2_ = auVar40._10_2_ >> 1;
          auVar45._12_2_ = auVar40._12_2_ >> 1;
          auVar45._14_2_ = auVar40._14_2_ >> 1;
          auVar5 = psllw(auVar40,7);
          auVar5 = (auVar5 & _DAT_00109740 | ~_DAT_00109740 & auVar45) ^ _DAT_00109760;
          cVar11 = auVar5[0] + -10;
          cVar19 = auVar5[1] + -0xb;
          uVar12 = CONCAT11(cVar19,cVar11);
          cVar20 = auVar5[2] + -0xc;
          cVar21 = auVar5[3] + -0xd;
          uVar13 = CONCAT13(cVar21,CONCAT12(cVar20,uVar12));
          cVar22 = auVar5[4] + -0xe;
          cVar23 = auVar5[5] + -0xf;
          uVar14 = CONCAT15(cVar23,CONCAT14(cVar22,uVar13));
          cVar24 = auVar5[6] + -0x10;
          cVar25 = auVar5[7] + -0x11;
          uVar4 = CONCAT17(cVar25,CONCAT16(cVar24,uVar14));
          cVar26 = auVar5[8] + -0x12;
          cVar27 = auVar5[9] + -0x13;
          auVar36._0_10_ = CONCAT19(cVar27,CONCAT18(cVar26,uVar4));
          auVar36[10] = auVar5[10] + -0x14;
          auVar36[0xb] = auVar5[0xb] + -0x15;
          auVar38[0xc] = auVar5[0xc] + -0x16;
          auVar38._0_12_ = auVar36;
          auVar38[0xd] = auVar5[0xd] + -0x17;
          auVar41[0xe] = auVar5[0xe] + -0x18;
          auVar41._0_14_ = auVar38;
          auVar41[0xf] = auVar5[0xf] + -0x19;
          auVar10._0_2_ = uVar12 >> 7;
          auVar10._2_2_ = (ushort)((uint)uVar13 >> 0x17);
          auVar10._4_2_ = (ushort)((uint6)uVar14 >> 0x27);
          auVar10._6_2_ = (ushort)((ulong)uVar4 >> 0x37);
          auVar10._8_2_ = (ushort)((unkuint10)auVar36._0_10_ >> 0x47);
          auVar10._10_2_ = auVar36._10_2_ >> 7;
          auVar10._12_2_ = auVar38._12_2_ >> 7;
          auVar10._14_2_ = auVar41._14_2_ >> 7;
          auVar42[1] = cVar19 * '\x02';
          auVar42[0] = cVar11 * '\x02';
          auVar42[2] = cVar20 * '\x02';
          auVar42[3] = cVar21 * '\x02';
          auVar42[4] = cVar22 * '\x02';
          auVar42[5] = cVar23 * '\x02';
          auVar42[6] = cVar24 * '\x02';
          auVar42[7] = cVar25 * '\x02';
          auVar42[8] = cVar26 * '\x02';
          auVar42[9] = cVar27 * '\x02';
          auVar42[10] = auVar36[10] * '\x02';
          auVar42[0xb] = auVar36[0xb] * '\x02';
          auVar42[0xc] = auVar38[0xc] * '\x02';
          auVar42[0xd] = auVar38[0xd] * '\x02';
          auVar42[0xe] = auVar41[0xe] * '\x02';
          auVar42[0xf] = auVar41[0xf] * '\x02';
          auVar42 = auVar42 | auVar10 & _DAT_001096e0;
          uVar12 = CONCAT11(auVar42[1] + DAT_001097f0._1_1_,auVar42[0] + DAT_001097f0);
          uVar13 = CONCAT13(auVar42[3] + DAT_001097f0._3_1_,
                            CONCAT12(auVar42[2] + DAT_001097f0._2_1_,uVar12));
          uVar14 = CONCAT15(auVar42[5] + DAT_001097f0._5_1_,
                            CONCAT14(auVar42[4] + DAT_001097f0._4_1_,uVar13));
          uVar4 = CONCAT17(auVar42[7] + DAT_001097f0._7_1_,
                           CONCAT16(auVar42[6] + DAT_001097f0._6_1_,uVar14));
          auVar37._0_10_ =
               CONCAT19(auVar42[9] + DAT_001097f0._9_1_,
                        CONCAT18(auVar42[8] + DAT_001097f0._8_1_,uVar4));
          auVar37[10] = auVar42[10] + DAT_001097f0._10_1_;
          auVar37[0xb] = auVar42[0xb] + DAT_001097f0._11_1_;
          auVar39[0xc] = auVar42[0xc] + DAT_001097f0._12_1_;
          auVar39._0_12_ = auVar37;
          auVar39[0xd] = auVar42[0xd] + DAT_001097f0._13_1_;
          auVar43[0xe] = auVar42[0xe] + DAT_001097f0._14_1_;
          auVar43._0_14_ = auVar39;
          auVar43[0xf] = auVar42[0xf] + DAT_001097f0._15_1_;
          auVar46._0_2_ = uVar12 >> 2;
          auVar46._2_2_ = (ushort)((uint)uVar13 >> 0x12);
          auVar46._4_2_ = (ushort)((uint6)uVar14 >> 0x22);
          auVar46._6_2_ = (ushort)((ulong)uVar4 >> 0x32);
          auVar46._8_2_ = (ushort)((unkuint10)auVar37._0_10_ >> 0x42);
          auVar46._10_2_ = auVar37._10_2_ >> 2;
          auVar46._12_2_ = auVar39._12_2_ >> 2;
          auVar46._14_2_ = auVar43._14_2_ >> 2;
          auVar5 = psllw(auVar43,6);
          auVar44 = (auVar5 & _DAT_001096f0 | ~_DAT_001096f0 & auVar46) ^ _DAT_001097d0;
          _local_78 = CONCAT17(auVar44[6] + '\x01',
                               CONCAT16(auVar44[5] + '\x01',
                                        CONCAT15(auVar44[4] + '\x01',
                                                 CONCAT14(auVar44[3] + '\x01',
                                                          CONCAT13(auVar44[2] + '\x01',
                                                                   CONCAT12(auVar44[1] + '\x01',
                                                                            CONCAT11(auVar44[0] +
                                                                                     '\x01',0x5f))))
                                                )));
          _cStack_70 = CONCAT17(auVar44[0xe] + '\x01',
                                CONCAT16(auVar44[0xd] + '\x01',
                                         CONCAT15(auVar44[0xc] + '\x01',
                                                  CONCAT14(auVar44[0xb] + '\x01',
                                                           CONCAT13(auVar44[10] + '\x01',
                                                                    CONCAT12(auVar44[9] + '\x01',
                                                                             CONCAT11(auVar44[8] +
                                                                                      '\x01',auVar44
                                                  [7] + '\x01')))))));
          auVar6[8] = 0x62;
          auVar6._0_8_ = 0xb6bf466aafda4632;
          auVar6[9] = 0x52;
          auVar6[10] = 0x5e;
          auVar6[0xb] = 0xbb;
          auVar6[0xc] = 0xee;
          auVar6[0xd] = 0xd7;
          auVar6[0xe] = 0x52;
          auVar6[0xf] = 0x3a;
          auVar6 = auVar6 ^ _DAT_001097c0;
          auVar35._0_2_ = auVar6._0_2_ >> 1;
          auVar35._2_2_ = auVar6._2_2_ >> 1;
          auVar35._4_2_ = auVar6._4_2_ >> 1;
          auVar35._6_2_ = auVar6._6_2_ >> 1;
          auVar35._8_2_ = auVar6._8_2_ >> 1;
          auVar35._10_2_ = auVar6._10_2_ >> 1;
          auVar35._12_2_ = auVar6._12_2_ >> 1;
          auVar35._14_2_ = auVar6._14_2_ >> 1;
          auVar5 = psllw(auVar6,7);
          auVar5 = (~_DAT_00109740 & auVar35 | auVar5 & _DAT_00109740) ^ _DAT_00109800;
          cVar11 = auVar5[0] + -0x1a;
          cVar19 = auVar5[1] + -0x1b;
          uVar12 = CONCAT11(cVar19,cVar11);
          cVar20 = auVar5[2] + -0x1c;
          cVar21 = auVar5[3] + -0x1d;
          uVar13 = CONCAT13(cVar21,CONCAT12(cVar20,uVar12));
          cVar22 = auVar5[4] + -0x1e;
          cVar23 = auVar5[5] + -0x1f;
          uVar14 = CONCAT15(cVar23,CONCAT14(cVar22,uVar13));
          cVar24 = auVar5[6] + -0x20;
          cVar25 = auVar5[7] + -0x21;
          uVar4 = CONCAT17(cVar25,CONCAT16(cVar24,uVar14));
          cVar26 = auVar5[8] + -0x22;
          cVar27 = auVar5[9] + -0x23;
          auVar28._0_10_ = CONCAT19(cVar27,CONCAT18(cVar26,uVar4));
          auVar28[10] = auVar5[10] + -0x24;
          auVar28[0xb] = auVar5[0xb] + -0x25;
          auVar30[0xc] = auVar5[0xc] + -0x26;
          auVar30._0_12_ = auVar28;
          auVar30[0xd] = auVar5[0xd] + -0x27;
          auVar32[0xe] = auVar5[0xe] + -0x28;
          auVar32._0_14_ = auVar30;
          auVar32[0xf] = auVar5[0xf] + -0x29;
          auVar7._0_2_ = uVar12 >> 7;
          auVar7._2_2_ = (ushort)((uint)uVar13 >> 0x17);
          auVar7._4_2_ = (ushort)((uint6)uVar14 >> 0x27);
          auVar7._6_2_ = (ushort)((ulong)uVar4 >> 0x37);
          auVar7._8_2_ = (ushort)((unkuint10)auVar28._0_10_ >> 0x47);
          auVar7._10_2_ = auVar28._10_2_ >> 7;
          auVar7._12_2_ = auVar30._12_2_ >> 7;
          auVar7._14_2_ = auVar32._14_2_ >> 7;
          auVar33[1] = cVar19 * '\x02';
          auVar33[0] = cVar11 * '\x02';
          auVar33[2] = cVar20 * '\x02';
          auVar33[3] = cVar21 * '\x02';
          auVar33[4] = cVar22 * '\x02';
          auVar33[5] = cVar23 * '\x02';
          auVar33[6] = cVar24 * '\x02';
          auVar33[7] = cVar25 * '\x02';
          auVar33[8] = cVar26 * '\x02';
          auVar33[9] = cVar27 * '\x02';
          auVar33[10] = auVar28[10] * '\x02';
          auVar33[0xb] = auVar28[0xb] * '\x02';
          auVar33[0xc] = auVar30[0xc] * '\x02';
          auVar33[0xd] = auVar30[0xd] * '\x02';
          auVar33[0xe] = auVar32[0xe] * '\x02';
          auVar33[0xf] = auVar32[0xf] * '\x02';
          auVar33 = auVar33 | auVar7 & _DAT_001096e0;
          uVar12 = CONCAT11(auVar33[1] + DAT_001097f0._1_1_,auVar33[0] + DAT_001097f0);
          uVar13 = CONCAT13(auVar33[3] + DAT_001097f0._3_1_,
                            CONCAT12(auVar33[2] + DAT_001097f0._2_1_,uVar12));
          uVar14 = CONCAT15(auVar33[5] + DAT_001097f0._5_1_,
                            CONCAT14(auVar33[4] + DAT_001097f0._4_1_,uVar13));
          uVar4 = CONCAT17(auVar33[7] + DAT_001097f0._7_1_,
                           CONCAT16(auVar33[6] + DAT_001097f0._6_1_,uVar14));
          auVar29._0_10_ =
               CONCAT19(auVar33[9] + DAT_001097f0._9_1_,
                        CONCAT18(auVar33[8] + DAT_001097f0._8_1_,uVar4));
          auVar29[10] = auVar33[10] + DAT_001097f0._10_1_;
          auVar29[0xb] = auVar33[0xb] + DAT_001097f0._11_1_;
          auVar31[0xc] = auVar33[0xc] + DAT_001097f0._12_1_;
          auVar31._0_12_ = auVar29;
          auVar31[0xd] = auVar33[0xd] + DAT_001097f0._13_1_;
          auVar34[0xe] = auVar33[0xe] + DAT_001097f0._14_1_;
          auVar34._0_14_ = auVar31;
          auVar34[0xf] = auVar33[0xf] + DAT_001097f0._15_1_;
          auVar8._0_2_ = uVar12 >> 2;
          auVar8._2_2_ = (ushort)((uint)uVar13 >> 0x12);
          auVar8._4_2_ = (ushort)((uint6)uVar14 >> 0x22);
          auVar8._6_2_ = (ushort)((ulong)uVar4 >> 0x32);
          auVar8._8_2_ = (ushort)((unkuint10)auVar29._0_10_ >> 0x42);
          auVar8._10_2_ = auVar29._10_2_ >> 2;
          auVar8._12_2_ = auVar31._12_2_ >> 2;
          auVar8._14_2_ = auVar34._14_2_ >> 2;
          auVar5 = psllw(auVar34,6);
          auVar5 = (~_DAT_001096f0 & auVar8 | auVar5 & _DAT_001096f0) ^ _DAT_001097d0;
          cStack_60 = auVar5[7] + '\x01';
          cStack_5f = auVar5[8] + '\x01';
          cStack_5e = auVar5[9] + '\x01';
          cStack_5d = auVar5[10] + '\x01';
          cStack_5c = auVar5[0xb] + '\x01';
          cStack_5b = auVar5[0xc] + '\x01';
          cStack_5a = auVar5[0xd] + '\x01';
          cStack_59 = auVar5[0xe] + '\x01';
          cStack_58 = auVar5[0xf] + '\x01';
          _local_68 = CONCAT17(auVar5[6] + '\x01',
                               CONCAT16(auVar5[5] + '\x01',
                                        CONCAT15(auVar5[4] + '\x01',
                                                 CONCAT14(auVar5[3] + '\x01',
                                                          CONCAT13(auVar5[2] + '\x01',
                                                                   CONCAT12(auVar5[1] + '\x01',
                                                                            CONCAT11(auVar5[0] +
                                                                                     '\x01',auVar44[
                                                  0xf] + '\x01')))))));
          local_36 = 0x246f732e656d69;
          local_57 = 0x625f30534b5045;
          iVar1 = thunk_FUN_0011bba0(&local_48,&local_78,&LAB_001171a0,&DAT_00144f38);
          if (iVar1 == 0) {
            thunk_FUN_0011c760(1);
            iVar1 = thunk_FUN_0011bcf0(0);
            if (iVar1 == 0) {
              FUN_0011bb80();
              LOCK();
              DAT_00144f40 = 1;
              UNLOCK();
            }
          }
          uVar4 = 0x10004;
        }
      }
    }
    else {
      (**(code **)(*local_80 + 0x88))(local_80);
    }
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_20) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar4;
}


// ==== FUN_00117910 @ 00117910

void FUN_00117910(void)

{
  FUN_00120410();
                    /* WARNING: Subroutine does not return */
  FUN_00120930();
}


// ==== FUN_00117920 @ 00117920

void FUN_00117920(long *param_1,char param_2)

{
  ulong uVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  char cVar4;
  long *plVar5;
  undefined8 *puVar6;
  long *plVar7;
  long *plVar8;
  long lVar9;
  undefined8 *puVar10;
  undefined1 *puVar11;
  long *plVar12;
  ulong uVar13;
  undefined1 *puVar14;
  undefined1 *puVar15;
  undefined1 *puVar16;
  undefined1 *puVar17;
  long lVar18;
  void *pvVar19;
  void *pvVar20;
  undefined1 *puVar21;
  undefined8 *puVar22;
  byte *__ptr;
  undefined8 *puVar23;
  long in_FS_OFFSET;
  undefined8 *local_60;
  undefined1 *local_58;
  undefined1 *puStack_50;
  undefined1 *local_48;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  local_58 = (undefined1 *)0x0;
  puStack_50 = (undefined1 *)0x0;
  local_48 = (undefined1 *)0x0;
  if (param_2 == '\x01') {
    plVar5 = (long *)*param_1;
    uVar1 = plVar5[2];
    if (uVar1 == 0) {
      plVar8 = (long *)*plVar5;
      if (plVar8 != plVar5 + 1) goto LAB_00117a99;
    }
    else {
      if (uVar1 >> 0x3c != 0) {
                    /* WARNING: Subroutine does not return */
        FUN_00118290("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
      local_58 = (undefined1 *)FUN_0011e900(uVar1 * 0x10);
      local_48 = local_58 + uVar1 * 0x10;
      plVar8 = (long *)*plVar5;
      puStack_50 = local_58;
      if (plVar8 != plVar5 + 1) {
LAB_00117a99:
        local_58 = puStack_50;
        if (local_48 <= puStack_50) goto LAB_00117ac2;
LAB_00117ae0:
        *puStack_50 = (char)plVar8[7];
        *(long *)(puStack_50 + 8) = plVar8[8];
        *(undefined1 *)(plVar8 + 7) = 0;
        plVar8[8] = 0;
        puStack_50 = puStack_50 + 0x10;
        plVar7 = (long *)plVar8[1];
        plVar12 = plVar8;
        if ((long *)plVar8[1] == (long *)0x0) goto LAB_00117b20;
        do {
          do {
            plVar8 = plVar7;
            plVar7 = (long *)*plVar8;
          } while ((long *)*plVar8 != (long *)0x0);
          while( true ) {
            if (plVar8 == plVar5 + 1) goto LAB_00117b61;
            if (puStack_50 < local_48) goto LAB_00117ae0;
LAB_00117ac2:
                    /* try { // try from 00117ac6 to 00117acd has its CatchHandler @ 00118182 */
            FUN_00118300(&local_58,plVar8 + 7);
            plVar7 = (long *)plVar8[1];
            plVar12 = plVar8;
            if ((long *)plVar8[1] != (long *)0x0) break;
LAB_00117b20:
            plVar8 = (long *)plVar12[2];
            if ((long *)*plVar8 != plVar12) {
              do {
                plVar12 = (long *)plVar12[2];
                plVar8 = (long *)plVar12[2];
              } while ((long *)*plVar8 != plVar12);
            }
          }
        } while( true );
      }
    }
  }
  else if (param_2 == '\x02') {
    puVar23 = (undefined8 *)*param_1;
    puVar14 = (undefined1 *)*puVar23;
    puVar15 = (undefined1 *)puVar23[1];
    lVar18 = (long)puVar15 - (long)puVar14;
    if (lVar18 == 0) {
      if (puVar14 != puVar15) goto LAB_00117a1e;
    }
    else {
      if (lVar18 < 0) {
                    /* try { // try from 00118163 to 0011817a has its CatchHandler @ 00118180 */
                    /* WARNING: Subroutine does not return */
        FUN_00118290("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
                    /* try { // try from 0011798f to 001179e6 has its CatchHandler @ 00118180 */
      local_58 = (undefined1 *)FUN_0011e900();
      local_48 = local_58 + (lVar18 >> 4) * 0x10;
      puVar14 = (undefined1 *)*puVar23;
      puVar15 = (undefined1 *)puVar23[1];
      puStack_50 = local_58;
      if (puVar14 != puVar15) {
LAB_00117a1e:
        local_58 = puStack_50;
        if (local_48 <= puStack_50) goto LAB_00117a6c;
        do {
          *puStack_50 = *puVar14;
          *(undefined8 *)(puStack_50 + 8) = *(undefined8 *)(puVar14 + 8);
          *puVar14 = 0;
          *(undefined8 *)(puVar14 + 8) = 0;
          puStack_50 = puStack_50 + 0x10;
          while( true ) {
            puVar14 = puVar14 + 0x10;
            if (puVar14 == puVar15) goto LAB_00117b61;
            if (puStack_50 < local_48) break;
LAB_00117a6c:
                    /* try { // try from 00117a6c to 00117a76 has its CatchHandler @ 00118184 */
            FUN_00118300(&local_58,puVar14);
          }
        } while( true );
      }
    }
  }
LAB_00117b61:
  do {
    if (local_58 == puStack_50) break;
    cVar4 = puStack_50[-0x10];
    local_60 = *(undefined8 **)(puStack_50 + -8);
    puStack_50[-0x10] = 0;
    *(undefined8 *)(puStack_50 + -8) = 0;
    puVar14 = puStack_50 + -0x10;
    FUN_00117920(puStack_50 + -8,puStack_50[-0x10]);
    puStack_50 = puVar14;
    if (cVar4 == '\x01') {
      puVar10 = (undefined8 *)*local_60;
      puVar23 = local_60 + 1;
      if (puVar10 != puVar23) {
        if (local_48 <= puVar14) goto LAB_00117e40;
        do {
          *puStack_50 = *(undefined1 *)(puVar10 + 7);
          *(undefined8 *)(puStack_50 + 8) = puVar10[8];
          *(undefined1 *)(puVar10 + 7) = 0;
          puVar10[8] = 0;
          puStack_50 = puStack_50 + 0x10;
          puVar22 = puVar10;
          while( true ) {
            puVar6 = (undefined8 *)puVar22[1];
            if ((undefined8 *)puVar22[1] == (undefined8 *)0x0) {
              puVar10 = (undefined8 *)puVar22[2];
              if ((undefined8 *)*puVar10 != puVar22) {
                do {
                  puVar22 = (undefined8 *)puVar22[2];
                  puVar10 = (undefined8 *)puVar22[2];
                } while ((undefined8 *)*puVar10 != puVar22);
              }
            }
            else {
              do {
                puVar10 = puVar6;
                puVar6 = (undefined8 *)*puVar10;
              } while ((undefined8 *)*puVar10 != (undefined8 *)0x0);
            }
            if (puVar10 == puVar23) goto LAB_00117fec;
            if (puStack_50 < local_48) break;
LAB_00117e40:
            puVar14 = puStack_50;
            puVar15 = local_58;
            lVar18 = (long)puStack_50 - (long)local_58 >> 4;
            uVar1 = lVar18 + 1;
            if (0xfffffffffffffff < uVar1) goto LAB_00118141;
            uVar13 = (long)local_48 - (long)local_58 >> 3;
            if (uVar13 < uVar1) {
              uVar13 = uVar1;
            }
            if (0x7fffffffffffffef < (ulong)((long)local_48 - (long)local_58)) {
              uVar13 = 0xfffffffffffffff;
            }
            if (0xfffffffffffffff < uVar13) {
                    /* try { // try from 00118157 to 00118162 has its CatchHandler @ 0011818d */
                    /* WARNING: Subroutine does not return */
              FUN_00118290("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
            }
                    /* try { // try from 00117e8b to 00117e92 has its CatchHandler @ 00118189 */
            lVar9 = FUN_0011e900(uVar13 * 0x10);
            puVar16 = local_58;
            lVar18 = lVar18 * 0x10;
            puVar21 = (undefined1 *)(lVar9 + lVar18);
            local_48 = (undefined1 *)(uVar13 * 0x10 + lVar9);
            *(undefined1 *)(lVar9 + lVar18) = *(undefined1 *)(puVar10 + 7);
            *(undefined8 *)(lVar9 + 8 + lVar18) = puVar10[8];
            *(undefined1 *)(puVar10 + 7) = 0;
            puVar10[8] = 0;
            puVar11 = (undefined1 *)(lVar9 + lVar18 + 0x10);
            if (puVar14 != puVar15) {
              do {
                puVar21[-0x10] = puVar14[-0x10];
                *(undefined8 *)(puVar21 + -8) = *(undefined8 *)(puVar14 + -8);
                puVar14[-0x10] = 0;
                *(undefined8 *)(puVar14 + -8) = 0;
                puVar14 = puVar14 + -0x10;
                puVar21 = puVar21 + -0x10;
              } while (puVar14 != puVar15);
              puVar14 = puVar16;
              if (puStack_50 != local_58) {
                puVar15 = puStack_50 + -8;
                local_58 = puVar21;
                puStack_50 = puVar11;
                do {
                  puVar3 = puVar15 + -8;
                  FUN_00117920(puVar15,puVar15[-8]);
                  puVar15 = puVar15 + -0x10;
                  puVar21 = local_58;
                  puVar11 = puStack_50;
                } while (puVar3 != puVar16);
              }
            }
            puStack_50 = puVar11;
            local_58 = puVar21;
            puVar22 = puVar10;
            if (puVar14 != (undefined1 *)0x0) {
              free(puVar14);
            }
          }
        } while( true );
      }
LAB_00117fec:
      puVar10 = local_60;
      puVar23 = local_60 + 1;
      FUN_00118480(local_60,local_60[1]);
      *puVar10 = puVar23;
      puVar10[1] = 0;
      puVar10[2] = 0;
    }
    else if (cVar4 == '\x02') {
      puVar21 = (undefined1 *)*local_60;
      puVar15 = (undefined1 *)local_60[1];
      if (puVar21 != puVar15) {
        if (local_48 <= puVar14) goto LAB_00117c03;
        do {
          *puVar14 = *puVar21;
          *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar21 + 8);
          *puVar21 = 0;
          *(undefined8 *)(puVar21 + 8) = 0;
          puStack_50 = puVar14 + 0x10;
          while( true ) {
            puVar21 = puVar21 + 0x10;
            if (puVar21 == puVar15) {
              puVar21 = (undefined1 *)*local_60;
              puVar23 = local_60 + 1;
              if ((undefined1 *)local_60[1] != puVar21) {
                puVar14 = (undefined1 *)local_60[1] + -8;
                do {
                  puVar15 = puVar14 + -8;
                  FUN_00117920(puVar14,puVar14[-8]);
                  puVar14 = puVar14 + -0x10;
                } while (puVar15 != puVar21);
              }
              goto LAB_00117b4f;
            }
            puVar14 = puStack_50;
            if (puStack_50 < local_48) break;
LAB_00117c03:
            puVar14 = local_58;
            lVar18 = (long)puStack_50 - (long)local_58 >> 4;
            uVar1 = lVar18 + 1;
            if (0xfffffffffffffff < uVar1) {
                    /* try { // try from 00118137 to 00118140 has its CatchHandler @ 0011818f */
              FUN_00120270(&local_58);
LAB_00118141:
                    /* try { // try from 00118141 to 0011814a has its CatchHandler @ 0011818d */
              FUN_00120270(&local_58);
LAB_0011814b:
                    /* try { // try from 0011814b to 00118156 has its CatchHandler @ 0011818f */
                    /* WARNING: Subroutine does not return */
              FUN_00118290("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
            }
            uVar13 = (long)local_48 - (long)local_58 >> 3;
            if (uVar13 < uVar1) {
              uVar13 = uVar1;
            }
            if (0x7fffffffffffffef < (ulong)((long)local_48 - (long)local_58)) {
              uVar13 = 0xfffffffffffffff;
            }
            if (0xfffffffffffffff < uVar13) goto LAB_0011814b;
                    /* try { // try from 00117c4b to 00117c52 has its CatchHandler @ 0011818b */
            lVar9 = FUN_0011e900(uVar13 * 0x10);
            puVar3 = local_58;
            lVar18 = lVar18 * 0x10;
            puVar11 = (undefined1 *)(lVar9 + lVar18);
            local_48 = (undefined1 *)(uVar13 * 0x10 + lVar9);
            *(undefined1 *)(lVar9 + lVar18) = *puVar21;
            *(undefined8 *)(lVar9 + 8 + lVar18) = *(undefined8 *)(puVar21 + 8);
            *puVar21 = 0;
            *(undefined8 *)(puVar21 + 8) = 0;
            puVar17 = (undefined1 *)(lVar9 + lVar18 + 0x10);
            puVar16 = puStack_50;
            if (puStack_50 != puVar14) {
              do {
                puVar11[-0x10] = puVar16[-0x10];
                *(undefined8 *)(puVar11 + -8) = *(undefined8 *)(puVar16 + -8);
                puVar16[-0x10] = 0;
                *(undefined8 *)(puVar16 + -8) = 0;
                puVar16 = puVar16 + -0x10;
                puVar11 = puVar11 + -0x10;
              } while (puVar16 != puVar14);
              puVar14 = puVar3;
              if (puStack_50 != local_58) {
                puVar16 = puStack_50 + -8;
                local_58 = puVar11;
                puStack_50 = puVar17;
                do {
                  puVar2 = puVar16 + -8;
                  FUN_00117920(puVar16,puVar16[-8]);
                  puVar16 = puVar16 + -0x10;
                  puVar11 = local_58;
                  puVar17 = puStack_50;
                } while (puVar2 != puVar3);
              }
            }
            puStack_50 = puVar17;
            local_58 = puVar11;
            if (puVar14 != (undefined1 *)0x0) {
              free(puVar14);
            }
          }
        } while( true );
      }
      puVar23 = local_60 + 1;
LAB_00117b4f:
      *puVar23 = puVar21;
    }
    FUN_00117920(&local_60,cVar4);
  } while( true );
  switch(param_2) {
  case '\x01':
    FUN_00118480(*param_1,*(undefined8 *)(*param_1 + 8));
LAB_001180c3:
    __ptr = (byte *)*param_1;
    break;
  case '\x02':
    __ptr = (byte *)*param_1;
    pvVar20 = *(void **)__ptr;
    if (pvVar20 != (void *)0x0) {
      pvVar19 = pvVar20;
      if (*(void **)(__ptr + 8) != pvVar20) {
        lVar18 = (long)*(void **)(__ptr + 8) + -8;
        do {
          pvVar19 = (void *)(lVar18 + -8);
          FUN_00117920(lVar18,*(undefined1 *)(lVar18 + -8));
          lVar18 = lVar18 + -0x10;
        } while (pvVar19 != pvVar20);
        pvVar19 = *(void **)__ptr;
      }
      *(void **)(__ptr + 8) = pvVar20;
      free(pvVar19);
      __ptr = (byte *)*param_1;
    }
    break;
  case '\x03':
    __ptr = (byte *)*param_1;
    if ((*__ptr & 1) != 0) {
      pvVar20 = *(void **)(__ptr + 0x10);
LAB_001180be:
      free(pvVar20);
      goto LAB_001180c3;
    }
    break;
  default:
    goto switchD_0011802a_caseD_4;
  case '\b':
    __ptr = (byte *)*param_1;
    pvVar20 = *(void **)__ptr;
    if (pvVar20 != (void *)0x0) {
      *(void **)(__ptr + 8) = pvVar20;
      goto LAB_001180be;
    }
  }
  free(__ptr);
switchD_0011802a_caseD_4:
  puVar14 = local_58;
  if (local_58 != (undefined1 *)0x0) {
    if (puStack_50 != local_58) {
      puVar15 = puStack_50 + -8;
      do {
        puVar21 = puVar15 + -8;
        FUN_00117920(puVar15,puVar15[-8]);
        puVar15 = puVar15 + -0x10;
      } while (puVar21 != puVar14);
    }
    puStack_50 = puVar14;
    free(local_58);
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_001181c0 @ 001181c0

void FUN_001181c0(long *param_1)

{
  void *pvVar1;
  long lVar2;
  void *pvVar3;
  
  pvVar1 = (void *)*param_1;
  if (pvVar1 == (void *)0x0) {
    return;
  }
  pvVar3 = pvVar1;
  if ((void *)param_1[1] != pvVar1) {
    lVar2 = param_1[1] + -8;
    do {
      pvVar3 = (void *)(lVar2 + -8);
      FUN_00117920(lVar2,*(undefined1 *)(lVar2 + -8));
      lVar2 = lVar2 + -0x10;
    } while (pvVar3 != pvVar1);
    pvVar3 = (void *)*param_1;
  }
  param_1[1] = (long)pvVar1;
  free(pvVar3);
  return;
}


// ==== FUN_00118230 @ 00118230

void FUN_00118230(undefined8 *param_1)

{
  long lVar1;
  long lVar2;
  
  lVar1 = param_1[1];
  lVar2 = param_1[2];
  while (lVar2 != lVar1) {
    param_1[2] = lVar2 + -0x10;
    FUN_00117920(lVar2 + -8,*(undefined1 *)(lVar2 + -0x10));
    lVar2 = param_1[2];
  }
  if ((void *)*param_1 == (void *)0x0) {
    return;
  }
  free((void *)*param_1);
  return;
}


// ==== FUN_00118290 @ 00118290

void FUN_00118290(undefined8 param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = FUN_001202b0(0x10);
                    /* try { // try from 001182a4 to 001182ae has its CatchHandler @ 001182c5 */
  FUN_001182e0(uVar1,param_1);
  uVar2 = FUN_00120320(uVar1,&PTR_PTR_00140870,&LAB_00135bd0);
                    /* catch() { ... } // from try @ 001182a4 with catch @ 001182c5 */
  FUN_00120300(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_00136230(uVar2);
}


// ==== FUN_001182e0 @ 001182e0

void FUN_001182e0(undefined8 *param_1)

{
  FUN_0011e970();
  *param_1 = &PTR_LAB_00140858;
  return;
}


// ==== FUN_00118300 @ 00118300

void FUN_00118300(long *param_1,undefined1 *param_2)

{
  ulong uVar1;
  void *__ptr;
  long lVar2;
  long lVar3;
  void *pvVar4;
  long lVar5;
  ulong uVar6;
  ulong uVar7;
  long lVar8;
  
  lVar5 = param_1[1] - *param_1 >> 4;
  uVar1 = lVar5 + 1;
  if (uVar1 >> 0x3c == 0) {
    uVar6 = param_1[2] - *param_1;
    uVar7 = (long)uVar6 >> 3;
    if (uVar7 < uVar1) {
      uVar7 = uVar1;
    }
    if (0x7fffffffffffffef < uVar6) {
      uVar7 = 0xfffffffffffffff;
    }
    if (uVar7 < 0x1000000000000000) {
      lVar2 = FUN_0011e900(uVar7 * 0x10);
      lVar5 = lVar5 * 0x10;
      lVar3 = lVar2 + lVar5;
      lVar8 = uVar7 * 0x10 + lVar2;
      *(undefined1 *)(lVar2 + lVar5) = *param_2;
      *(undefined8 *)(lVar2 + 8 + lVar5) = *(undefined8 *)(param_2 + 8);
      *param_2 = 0;
      *(undefined8 *)(param_2 + 8) = 0;
      lVar5 = lVar2 + lVar5 + 0x10;
      __ptr = (void *)*param_1;
      pvVar4 = (void *)param_1[1];
      if (pvVar4 == __ptr) {
        *param_1 = lVar3;
        param_1[1] = lVar5;
        param_1[2] = lVar8;
      }
      else {
        do {
          *(undefined1 *)(lVar3 + -0x10) = *(undefined1 *)((long)pvVar4 + -0x10);
          *(undefined8 *)(lVar3 + -8) = *(undefined8 *)((long)pvVar4 + -8);
          *(undefined1 *)((long)pvVar4 + -0x10) = 0;
          *(undefined8 *)((long)pvVar4 + -8) = 0;
          pvVar4 = (void *)((long)pvVar4 + -0x10);
          lVar3 = lVar3 + -0x10;
        } while (pvVar4 != __ptr);
        __ptr = (void *)*param_1;
        pvVar4 = (void *)param_1[1];
        *param_1 = lVar3;
        param_1[1] = lVar5;
        param_1[2] = lVar8;
        if (pvVar4 != __ptr) {
          lVar5 = (long)pvVar4 + -8;
          do {
            pvVar4 = (void *)(lVar5 + -8);
            FUN_00117920(lVar5,*(undefined1 *)(lVar5 + -8));
            lVar5 = lVar5 + -0x10;
          } while (pvVar4 != __ptr);
        }
      }
      if (__ptr == (void *)0x0) {
        return;
      }
      free(__ptr);
      return;
    }
  }
  else {
    FUN_00120270(param_1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00118290("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
}


// ==== FUN_00118480 @ 00118480

void FUN_00118480(undefined8 param_1,undefined8 *param_2)

{
  if (param_2 == (undefined8 *)0x0) {
    return;
  }
  FUN_00118480(param_1,*param_2);
  FUN_00118480(param_1,param_2[1]);
  FUN_00117920(param_2 + 8,*(undefined1 *)(param_2 + 7));
  if ((*(byte *)(param_2 + 4) & 1) != 0) {
    free((void *)param_2[6]);
  }
  free(param_2);
  return;
}


// ==== FUN_001184d0 @ 001184d0

void FUN_001184d0(long *param_1)

{
  void *pvVar1;
  long lVar2;
  void *pvVar3;
  
  pvVar1 = (void *)*param_1;
  if (pvVar1 == (void *)0x0) {
    return;
  }
  pvVar3 = pvVar1;
  if ((void *)param_1[1] != pvVar1) {
    lVar2 = param_1[1] + -8;
    do {
      pvVar3 = (void *)(lVar2 + -8);
      FUN_00117920(lVar2,*(undefined1 *)(lVar2 + -8));
      lVar2 = lVar2 + -0x10;
    } while (pvVar3 != pvVar1);
    pvVar3 = (void *)*param_1;
  }
  param_1[1] = (long)pvVar1;
  free(pvVar3);
  return;
}


// ==== FUN_00118540 @ 00118540

undefined8 * FUN_00118540(undefined8 *param_1,undefined4 param_2,byte *param_3)

{
  ulong *puVar1;
  ulong uVar2;
  byte *pbVar3;
  void *pvVar4;
  long in_FS_OFFSET;
  byte local_68;
  undefined8 local_67;
  undefined2 local_5f;
  undefined1 local_5d;
  void *local_58;
  byte local_50 [16];
  void *local_40;
  undefined8 local_38;
  ulong uStack_30;
  void *local_28;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  local_68 = 0x14;
  local_67 = 0x7272655f65707974;
  local_5f = 0x726f;
  local_5d = 0;
                    /* try { // try from 0011857e to 0011858d has its CatchHandler @ 00118697 */
  FUN_001187f0(local_50,&local_68,param_2);
  if ((*param_3 & 1) == 0) {
    pbVar3 = param_3 + 1;
    uVar2 = (ulong)(*param_3 >> 1);
  }
  else {
    uVar2 = *(ulong *)(param_3 + 8);
    pbVar3 = *(byte **)(param_3 + 0x10);
  }
                    /* try { // try from 001185a8 to 001185b4 has its CatchHandler @ 00118681 */
  puVar1 = (ulong *)FUN_0011ef80(local_50,pbVar3,uVar2);
  local_28 = (void *)puVar1[2];
  local_38 = *puVar1;
  uStack_30 = puVar1[1];
  *puVar1 = 0;
  puVar1[1] = 0;
  puVar1[2] = 0;
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  if ((local_68 & 1) != 0) {
    free(local_58);
  }
  if ((local_38 & 1) == 0) {
    pvVar4 = (void *)((long)&local_38 + 1);
  }
  else {
    pvVar4 = local_28;
  }
  *param_1 = &PTR_LAB_0013e3e0;
  *(undefined4 *)(param_1 + 1) = param_2;
                    /* try { // try from 00118627 to 0011862b has its CatchHandler @ 00118668 */
  FUN_0011ea90(param_1 + 2,pvVar4);
  *param_1 = &PTR_LAB_0013e3b8;
  if ((local_38 & 1) != 0) {
    free(local_28);
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_20) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_001186c0 @ 001186c0

void FUN_001186c0(ulong *param_1,char *param_2)

{
  size_t __n;
  ulong uVar1;
  char *__dest;
  
  __n = strlen(param_2);
  if (0xffffffffffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(param_1);
  }
  if (__n < 0x17) {
    *(char *)param_1 = (char)__n * '\x02';
    __dest = (char *)((long)param_1 + 1);
    if (__n == 0) goto LAB_0011872a;
  }
  else {
    uVar1 = __n + 0x10 & 0xfffffffffffffff0;
    __dest = (char *)FUN_0011e900(uVar1);
    param_1[2] = (ulong)__dest;
    *param_1 = uVar1 | 1;
    param_1[1] = __n;
  }
  memcpy(__dest,param_2,__n);
LAB_0011872a:
  __dest[__n] = '\0';
  return;
}


// ==== FUN_00118770 @ 00118770

char * FUN_00118770(char *param_1)

{
  if ((ulong)(long)*param_1 < 10) {
    return &DAT_0010bbb0 + *(int *)(&DAT_0010bbb0 + (long)*param_1 * 4);
  }
  return "number";
}


// ==== FUN_001187a0 @ 001187a0

undefined8 * FUN_001187a0(undefined8 *param_1,undefined8 param_2,byte *param_3)

{
  undefined8 uVar1;
  ulong uVar2;
  undefined8 *puVar3;
  byte *pbVar4;
  
  if ((*param_3 & 1) == 0) {
    pbVar4 = param_3 + 1;
    uVar2 = (ulong)(*param_3 >> 1);
  }
  else {
    uVar2 = *(ulong *)(param_3 + 8);
    pbVar4 = *(byte **)(param_3 + 0x10);
  }
  puVar3 = (undefined8 *)FUN_0011ef80(param_2,pbVar4,uVar2);
  param_1[2] = puVar3[2];
  uVar1 = puVar3[1];
  *param_1 = *puVar3;
  param_1[1] = uVar1;
  *puVar3 = 0;
  puVar3[1] = 0;
  puVar3[2] = 0;
  return param_1;
}


// ==== FUN_001187f0 @ 001187f0

undefined8 * FUN_001187f0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  undefined8 uVar1;
  ulong *puVar2;
  undefined8 *puVar3;
  undefined1 *puVar4;
  long in_FS_OFFSET;
  byte local_88;
  undefined1 local_87 [7];
  ulong local_80;
  undefined1 *local_78;
  byte local_70 [16];
  void *local_60;
  ulong local_58;
  ulong uStack_50;
  void *local_48;
  ulong local_38;
  ulong uStack_30;
  void *local_28;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  FUN_0011f2d0(local_70,"[json.exception.",param_2);
                    /* try { // try from 00118822 to 00118830 has its CatchHandler @ 001189c7 */
  puVar2 = (ulong *)FUN_0011f1c0(local_70,&DAT_00109aac);
  local_48 = (void *)puVar2[2];
  local_58 = *puVar2;
  uStack_50 = puVar2[1];
  *puVar2 = 0;
  puVar2[1] = 0;
  puVar2[2] = 0;
                    /* try { // try from 00118850 to 00118859 has its CatchHandler @ 001189aa */
  FUN_0011f460(&local_88,param_3);
  if ((local_88 & 1) == 0) {
    local_80 = (ulong)(local_88 >> 1);
    puVar4 = local_87;
  }
  else {
    puVar4 = local_78;
  }
                    /* try { // try from 00118877 to 00118880 has its CatchHandler @ 0011898e */
  puVar2 = (ulong *)FUN_0011ef80(&local_58,puVar4,local_80);
  local_28 = (void *)puVar2[2];
  local_38 = *puVar2;
  uStack_30 = puVar2[1];
  *puVar2 = 0;
  puVar2[1] = 0;
  puVar2[2] = 0;
                    /* try { // try from 001188a0 to 001188b0 has its CatchHandler @ 00118956 */
  puVar3 = (undefined8 *)FUN_0011f1c0(&local_38,&DAT_00109d32);
  param_1[2] = puVar3[2];
  uVar1 = puVar3[1];
  *param_1 = *puVar3;
  param_1[1] = uVar1;
  *puVar3 = 0;
  puVar3[1] = 0;
  puVar3[2] = 0;
  if ((local_38 & 1) != 0) {
    free(local_28);
  }
  if ((local_88 & 1) != 0) {
    free(local_78);
  }
  if ((local_58 & 1) != 0) {
    free(local_48);
  }
  if ((local_70[0] & 1) == 0) {
    if (*(long *)(in_FS_OFFSET + 0x28) != local_20) {
LAB_00118951:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  else {
    free(local_60);
    if (*(long *)(in_FS_OFFSET + 0x28) != local_20) goto LAB_00118951;
  }
  return param_1;
}


// ==== FUN_00118a60 @ 00118a60

void FUN_00118a60(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  long *plVar5;
  long lVar6;
  long *__ptr;
  long lVar7;
  undefined8 uVar8;
  undefined8 *puVar9;
  long lVar10;
  
  uVar1 = *param_2;
  *param_1 = uVar1;
  *(undefined8 *)(param_1 + 8) = 0;
  switch(uVar1) {
  case 1:
    puVar2 = *(undefined8 **)(param_2 + 8);
    __ptr = (long *)FUN_0011e900(0x18);
    __ptr[1] = 0;
    __ptr[2] = 0;
    *__ptr = (long)(__ptr + 1);
    puVar9 = (undefined8 *)*puVar2;
    while (puVar4 = puVar9, puVar4 != puVar2 + 1) {
                    /* try { // try from 00118b20 to 00118b2d has its CatchHandler @ 00118c1d */
      FUN_00118c40(__ptr,__ptr + 1,puVar4 + 4);
      puVar3 = (undefined8 *)puVar4[1];
      if ((undefined8 *)puVar4[1] == (undefined8 *)0x0) {
        puVar9 = (undefined8 *)puVar4[2];
        if (*(undefined8 **)puVar4[2] != puVar4) {
          do {
            puVar4 = (undefined8 *)puVar4[2];
            puVar9 = (undefined8 *)puVar4[2];
          } while (*(undefined8 **)puVar4[2] != puVar4);
        }
      }
      else {
        do {
          puVar9 = puVar3;
          puVar3 = (undefined8 *)*puVar9;
        } while (puVar3 != (undefined8 *)0x0);
      }
    }
    break;
  case 2:
    plVar5 = *(long **)(param_2 + 8);
    __ptr = (long *)FUN_0011e900(0x18);
    *__ptr = 0;
    __ptr[1] = 0;
    __ptr[2] = 0;
    lVar10 = plVar5[1] - *plVar5;
    if (lVar10 != 0) {
      if (lVar10 < 0) {
                    /* try { // try from 00118bfa to 00118c01 has its CatchHandler @ 00118c07 */
        uVar8 = FUN_00120270(__ptr);
                    /* catch() { ... } // from try @ 00118aaf with catch @ 00118c02 */
        free(__ptr);
                    /* WARNING: Subroutine does not return */
        FUN_00136230(uVar8);
      }
                    /* try { // try from 00118ba7 to 00118bab has its CatchHandler @ 00118c07 */
      lVar7 = FUN_0011e900();
      __ptr[1] = lVar7;
      *__ptr = lVar7;
      __ptr[2] = (lVar10 >> 4) * 0x10 + lVar7;
      lVar6 = plVar5[1];
      for (lVar10 = *plVar5; lVar10 != lVar6; lVar10 = lVar10 + 0x10) {
                    /* try { // try from 00118bd0 to 00118bda has its CatchHandler @ 00118c0c */
        FUN_00118a60(lVar7,lVar10);
        lVar7 = lVar7 + 0x10;
      }
      __ptr[1] = lVar7;
    }
    break;
  case 3:
    uVar8 = *(undefined8 *)(param_2 + 8);
    __ptr = (long *)FUN_0011e900(0x18);
                    /* try { // try from 00118aaf to 00118ab9 has its CatchHandler @ 00118c02 */
    FUN_0011ecd0(__ptr,uVar8);
    break;
  case 4:
    __ptr = (long *)(ulong)(byte)param_2[8];
    break;
  case 5:
  case 6:
  case 7:
    __ptr = *(long **)(param_2 + 8);
    break;
  case 8:
    __ptr = (long *)FUN_001193d0(*(undefined8 *)(param_2 + 8));
    break;
  default:
    goto switchD_00118a93_default;
  }
  *(long **)(param_1 + 8) = __ptr;
switchD_00118a93_default:
  return;
}


// ==== FUN_00118c40 @ 00118c40

undefined8 * FUN_00118c40(long *param_1,undefined8 param_2,undefined8 param_3,long param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  long in_FS_OFFSET;
  undefined1 auStack_58 [8];
  undefined8 local_50;
  undefined8 *local_48;
  long *local_40;
  undefined1 local_38;
  long local_30;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  puVar1 = (undefined8 *)FUN_00118d50(param_1,param_2,&local_50,auStack_58,param_3);
  puVar2 = (undefined8 *)*puVar1;
  if ((undefined8 *)*puVar1 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)FUN_0011e900(0x48);
    local_38 = 0;
    local_48 = puVar2;
    local_40 = param_1 + 1;
                    /* try { // try from 00118ca0 to 00118caa has its CatchHandler @ 00118d2f */
    FUN_0011ecd0(puVar2 + 4,param_4);
                    /* try { // try from 00118cb6 to 00118cbd has its CatchHandler @ 00118d1a */
    FUN_00118a60(puVar2 + 7,param_4 + 0x18);
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = local_50;
    *puVar1 = puVar2;
    if (*(long *)*param_1 != 0) {
      *param_1 = *(long *)*param_1;
      puVar2 = (undefined8 *)*puVar1;
    }
    FUN_00119260(param_1[1],puVar2);
    param_1[2] = param_1[2] + 1;
    puVar2 = local_48;
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_30) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar2;
}


// ==== FUN_00118d50 @ 00118d50

long * FUN_00118d50(undefined8 *param_1,long *param_2,undefined8 *param_3,long *param_4,
                   byte *param_5)

{
  byte bVar1;
  long lVar2;
  long *plVar3;
  int iVar4;
  long *plVar5;
  ulong __n;
  long *plVar6;
  ulong uVar7;
  ulong uVar8;
  ulong uVar9;
  byte *pbVar10;
  void *pvVar11;
  ulong uVar12;
  
  if (param_1 + 1 != param_2) {
    bVar1 = *(byte *)(param_2 + 4);
    if ((bVar1 & 1) == 0) {
      uVar8 = (ulong)(bVar1 >> 1);
      uVar12 = (ulong)*param_5;
      if ((*param_5 & 1) == 0) goto LAB_00118d8f;
LAB_00118da6:
      uVar9 = *(ulong *)(param_5 + 8);
    }
    else {
      uVar8 = param_2[5];
      uVar12 = (ulong)*param_5;
      if ((*param_5 & 1) != 0) goto LAB_00118da6;
LAB_00118d8f:
      uVar9 = uVar12 >> 1;
    }
    uVar7 = uVar9;
    if (uVar8 < uVar9) {
      uVar7 = uVar8;
    }
    if (uVar7 == 0) {
      if (uVar8 <= uVar9) {
LAB_00118f29:
        if (uVar9 <= uVar8) {
LAB_00118f1e:
          *param_3 = param_2;
          *param_4 = (long)param_2;
          return param_4;
        }
LAB_00118f2e:
        plVar5 = (long *)param_2[1];
        if (plVar5 == (long *)0x0) {
          plVar6 = (long *)param_2[2];
          plVar3 = param_2;
          if ((long *)*plVar6 != param_2) {
            do {
              plVar3 = (long *)plVar3[2];
              plVar6 = (long *)plVar3[2];
            } while ((long *)*plVar6 != plVar3);
          }
        }
        else {
          plVar3 = plVar5;
          do {
            plVar6 = plVar3;
            plVar3 = (long *)*plVar6;
          } while ((long *)*plVar6 != (long *)0x0);
        }
        if (plVar6 == param_1 + 1) goto LAB_00119084;
        bVar1 = *(byte *)(plVar6 + 4);
        if ((bVar1 & 1) == 0) {
          uVar8 = (ulong)(bVar1 >> 1);
        }
        else {
          uVar8 = plVar6[5];
        }
        uVar7 = uVar9;
        if (uVar8 < uVar9) {
          uVar7 = uVar8;
        }
        if (uVar7 != 0) {
          if ((bVar1 & 1) == 0) {
            pvVar11 = (void *)((long)plVar6 + 0x21);
            if ((uVar12 & 1) == 0) goto LAB_00119027;
LAB_00119041:
            pbVar10 = *(byte **)(param_5 + 0x10);
          }
          else {
            pvVar11 = (void *)plVar6[6];
            if ((uVar12 & 1) != 0) goto LAB_00119041;
LAB_00119027:
            pbVar10 = param_5 + 1;
          }
          iVar4 = memcmp(pbVar10,pvVar11,uVar7);
          if (iVar4 != 0) {
            if (iVar4 < 0) goto LAB_00119084;
            goto LAB_00119066;
          }
        }
        if (uVar9 < uVar8) {
LAB_00119084:
          if (plVar5 == (long *)0x0) {
            *param_3 = param_2;
            return param_2 + 1;
          }
          *param_3 = plVar6;
          return plVar6;
        }
        goto LAB_00119066;
      }
    }
    else {
      if ((bVar1 & 1) == 0) {
        pvVar11 = (void *)((long)param_2 + 0x21);
      }
      else {
        pvVar11 = (void *)param_2[6];
      }
      if ((uVar12 & 1) == 0) {
        pbVar10 = param_5 + 1;
      }
      else {
        pbVar10 = *(byte **)(param_5 + 0x10);
      }
      iVar4 = memcmp(pbVar10,pvVar11,uVar7);
      if (iVar4 == 0) {
        if (uVar8 <= uVar9) goto LAB_00118ef4;
      }
      else if (-1 < iVar4) {
LAB_00118ef4:
        iVar4 = memcmp(pvVar11,pbVar10,uVar7);
        if (iVar4 == 0) goto LAB_00118f29;
        if (-1 < iVar4) goto LAB_00118f1e;
        goto LAB_00118f2e;
      }
    }
  }
  plVar6 = (long *)*param_2;
  plVar5 = param_2;
  if ((long *)*param_1 == param_2) goto LAB_00118f9b;
  if (plVar6 == (long *)0x0) {
    plVar5 = param_2 + 2;
    if (*(long **)param_2[2] == param_2) {
      do {
        lVar2 = *plVar5;
        plVar5 = (long *)(lVar2 + 0x10);
      } while (**(long **)(lVar2 + 0x10) == lVar2);
    }
    plVar5 = (long *)*plVar5;
    uVar8 = (ulong)*param_5;
    if ((*param_5 & 1) != 0) goto LAB_00118e54;
LAB_00118e9b:
    uVar12 = uVar8 >> 1;
    uVar9 = (ulong)*(byte *)(plVar5 + 4);
    if ((*(byte *)(plVar5 + 4) & 1) == 0) goto LAB_00118e61;
LAB_00118eaa:
    uVar7 = plVar5[5];
  }
  else {
    plVar3 = plVar6;
    do {
      plVar5 = plVar3;
      plVar3 = (long *)plVar5[1];
    } while ((long *)plVar5[1] != (long *)0x0);
    uVar8 = (ulong)*param_5;
    if ((*param_5 & 1) == 0) goto LAB_00118e9b;
LAB_00118e54:
    uVar12 = *(ulong *)(param_5 + 8);
    uVar9 = (ulong)*(byte *)(plVar5 + 4);
    if ((*(byte *)(plVar5 + 4) & 1) != 0) goto LAB_00118eaa;
LAB_00118e61:
    uVar7 = uVar9 >> 1;
  }
  __n = uVar7;
  if (uVar12 < uVar7) {
    __n = uVar12;
  }
  if (__n != 0) {
    if ((uVar8 & 1) == 0) {
      pbVar10 = param_5 + 1;
    }
    else {
      pbVar10 = *(byte **)(param_5 + 0x10);
    }
    if ((uVar9 & 1) == 0) {
      pvVar11 = (void *)((long)plVar5 + 0x21);
    }
    else {
      pvVar11 = (void *)plVar5[6];
    }
    iVar4 = memcmp(pvVar11,pbVar10,__n);
    if (iVar4 != 0) {
      if (-1 < iVar4) goto LAB_00119066;
      goto LAB_00118f9b;
    }
  }
  if (uVar12 <= uVar7) {
LAB_00119066:
    plVar5 = (long *)FUN_001190f0(param_1,param_3,param_5);
    return plVar5;
  }
LAB_00118f9b:
  if (plVar6 == (long *)0x0) {
    *param_3 = param_2;
    return param_2;
  }
  *param_3 = plVar5;
  return plVar5 + 1;
}


// ==== FUN_001190b0 @ 001190b0

void FUN_001190b0(undefined8 *param_1)

{
  void *__ptr;
  
  __ptr = (void *)*param_1;
  *param_1 = 0;
  if (__ptr == (void *)0x0) {
    return;
  }
  if (*(char *)(param_1 + 2) != '\0') {
    FUN_00117920((long)__ptr + 0x40,*(undefined1 *)((long)__ptr + 0x38));
    if ((*(byte *)((long)__ptr + 0x20) & 1) != 0) {
      free(*(void **)((long)__ptr + 0x30));
    }
  }
  free(__ptr);
  return;
}


// ==== FUN_001190f0 @ 001190f0

long * FUN_001190f0(long param_1,undefined8 *param_2,byte *param_3)

{
  byte bVar1;
  int iVar2;
  long *plVar3;
  ulong __n;
  long *plVar4;
  long *plVar5;
  void *__s2;
  ulong uVar6;
  ulong uVar7;
  
  plVar4 = *(long **)(param_1 + 8);
  plVar5 = (long *)(param_1 + 8);
  if (plVar4 == (long *)0x0) {
    *param_2 = plVar5;
    return plVar5;
  }
  if ((*param_3 & 1) == 0) {
    uVar6 = (ulong)(*param_3 >> 1);
    param_3 = param_3 + 1;
  }
  else {
    uVar6 = *(ulong *)(param_3 + 8);
    param_3 = *(byte **)(param_3 + 0x10);
  }
  do {
    bVar1 = *(byte *)(plVar4 + 4);
    if ((bVar1 & 1) == 0) {
      uVar7 = (ulong)(bVar1 >> 1);
    }
    else {
      uVar7 = plVar4[5];
    }
    __n = uVar6;
    if (uVar7 < uVar6) {
      __n = uVar7;
    }
    if (__n == 0) {
      if (uVar6 < uVar7) goto LAB_00119140;
LAB_00119210:
      if (uVar6 <= uVar7) {
LAB_0011923d:
        *param_2 = plVar4;
        return plVar5;
      }
LAB_00119215:
      plVar3 = (long *)plVar4[1];
      plVar5 = plVar4 + 1;
      if (plVar3 == (long *)0x0) {
        *param_2 = plVar4;
        return plVar4 + 1;
      }
    }
    else {
      if ((bVar1 & 1) == 0) {
        __s2 = (void *)((long)plVar4 + 0x21);
      }
      else {
        __s2 = (void *)plVar4[6];
      }
      iVar2 = memcmp(param_3,__s2,__n);
      if (iVar2 == 0) {
        if (uVar7 <= uVar6) goto LAB_001191ec;
      }
      else if (-1 < iVar2) {
LAB_001191ec:
        iVar2 = memcmp(__s2,param_3,__n);
        if (iVar2 == 0) goto LAB_00119210;
        if (-1 < iVar2) goto LAB_0011923d;
        goto LAB_00119215;
      }
LAB_00119140:
      plVar3 = (long *)*plVar4;
      plVar5 = plVar4;
      if (plVar3 == (long *)0x0) {
        *param_2 = plVar4;
        return plVar4;
      }
    }
    plVar4 = plVar3;
  } while( true );
}


// ==== FUN_00119260 @ 00119260

void FUN_00119260(long *param_1,long *param_2)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  long lVar4;
  long *plVar5;
  bool bVar6;
  
  bVar6 = param_2 == param_1;
  *(bool *)(param_2 + 3) = bVar6;
  do {
    if ((bVar6) || (plVar5 = (long *)param_2[2], (char)plVar5[3] != '\0')) {
      return;
    }
    plVar3 = (long *)plVar5[2];
    lVar4 = *plVar3;
    if ((long *)lVar4 == plVar5) {
      lVar4 = plVar3[1];
      if ((lVar4 == 0) || (*(char *)(lVar4 + 0x18) != '\0')) {
        if ((long *)*plVar5 != param_2) {
          plVar1 = (long *)plVar5[1];
          lVar4 = *plVar1;
          plVar5[1] = lVar4;
          if (lVar4 != 0) {
            *(long **)(lVar4 + 0x10) = plVar5;
            plVar3 = (long *)plVar5[2];
          }
          plVar1[2] = (long)plVar3;
          ((long *)plVar5[2])[(long *)*(long *)plVar5[2] != plVar5] = (long)plVar1;
          *plVar1 = (long)plVar5;
          plVar5[2] = (long)plVar1;
          plVar3 = (long *)plVar1[2];
          plVar5 = plVar1;
        }
        *(undefined1 *)(plVar5 + 3) = 1;
        *(undefined1 *)(plVar3 + 3) = 0;
        lVar4 = *plVar3;
        lVar2 = *(long *)(lVar4 + 8);
        *plVar3 = lVar2;
        if (lVar2 != 0) {
          *(long **)(lVar2 + 0x10) = plVar3;
        }
        *(long *)(lVar4 + 0x10) = plVar3[2];
        ((undefined8 *)plVar3[2])[*(long **)plVar3[2] != plVar3] = lVar4;
        *(long **)(lVar4 + 8) = plVar3;
        plVar3[2] = lVar4;
        return;
      }
    }
    else if ((lVar4 == 0) || (*(char *)(lVar4 + 0x18) != '\0')) {
      if ((long *)*plVar5 == param_2) {
        lVar4 = param_2[1];
        *plVar5 = lVar4;
        if (lVar4 != 0) {
          *(long **)(lVar4 + 0x10) = plVar5;
          plVar3 = (long *)plVar5[2];
        }
        param_2[2] = (long)plVar3;
        ((undefined8 *)plVar5[2])[*(long **)plVar5[2] != plVar5] = param_2;
        param_2[1] = (long)plVar5;
        plVar5[2] = (long)param_2;
        plVar3 = (long *)param_2[2];
      }
      else {
        param_2 = plVar5;
      }
      *(undefined1 *)(param_2 + 3) = 1;
      *(undefined1 *)(plVar3 + 3) = 0;
      plVar5 = (long *)plVar3[1];
      lVar4 = *plVar5;
      plVar3[1] = lVar4;
      if (lVar4 != 0) {
        *(long **)(lVar4 + 0x10) = plVar3;
      }
      plVar5[2] = plVar3[2];
      ((undefined8 *)plVar3[2])[*(long **)plVar3[2] != plVar3] = plVar5;
      *plVar5 = (long)plVar3;
      plVar3[2] = (long)plVar5;
      return;
    }
    *(undefined1 *)(plVar5 + 3) = 1;
    bVar6 = plVar3 == param_1;
    *(bool *)(plVar3 + 3) = bVar6;
    *(undefined1 *)(lVar4 + 0x18) = 1;
    param_2 = plVar3;
  } while( true );
}


// ==== FUN_001193d0 @ 001193d0

undefined8 * FUN_001193d0(undefined8 *param_1)

{
  void *pvVar1;
  undefined8 *__ptr;
  void *__dest;
  undefined8 uVar2;
  size_t __n;
  
  __ptr = (undefined8 *)FUN_0011e900(0x20);
  *__ptr = 0;
  __ptr[1] = 0;
  __ptr[2] = 0;
  pvVar1 = (void *)*param_1;
  __n = param_1[1] - (long)pvVar1;
  if (__n != 0) {
    if ((long)__n < 0) {
                    /* try { // try from 00119447 to 0011944e has its CatchHandler @ 0011944f */
      uVar2 = FUN_00120270(__ptr);
                    /* catch() { ... } // from try @ 00119405 with catch @ 0011944f
                       catch() { ... } // from try @ 00119447 with catch @ 0011944f */
      pvVar1 = (void *)*__ptr;
      if (pvVar1 != (void *)0x0) {
        __ptr[1] = pvVar1;
        free(pvVar1);
      }
      free(__ptr);
                    /* WARNING: Subroutine does not return */
      FUN_00136230(uVar2);
    }
                    /* try { // try from 00119405 to 0011940c has its CatchHandler @ 0011944f */
    __dest = (void *)FUN_0011e900(__n);
    *__ptr = __dest;
    __ptr[2] = (long)__dest + __n;
    memcpy(__dest,pvVar1,__n);
    __ptr[1] = (long)__dest + __n;
  }
  *(undefined2 *)(__ptr + 3) = *(undefined2 *)(param_1 + 3);
  return __ptr;
}


// ==== FUN_00119480 @ 00119480

void FUN_00119480(long *param_1,long param_2,long param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  ulong uVar3;
  long in_FS_OFFSET;
  undefined1 local_48 [8];
  undefined8 local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_3 - param_2;
  if (uVar3 != 0) {
    if ((long)uVar3 < 0) {
                    /* try { // try from 00119587 to 0011958e has its CatchHandler @ 00119594 */
      FUN_00120270(param_1);
      goto LAB_0011958f;
    }
                    /* try { // try from 001194d2 to 001194d6 has its CatchHandler @ 00119594 */
    puVar2 = (undefined1 *)FUN_0011e900(uVar3 >> 1);
    param_1[1] = (long)puVar2;
    *param_1 = (long)puVar2;
    param_1[2] = (long)(puVar2 + ((long)uVar3 >> 5) * 0x10);
    if (param_2 != param_3) {
      do {
        puVar1 = *(undefined1 **)(param_2 + 0x10);
        if (*(char *)(param_2 + 0x18) == '\0') {
                    /* try { // try from 0011955a to 00119561 has its CatchHandler @ 00119599 */
          FUN_00118a60(local_48);
        }
        else {
          local_48[0] = *puVar1;
          local_40 = *(undefined8 *)(puVar1 + 8);
          *puVar1 = 0;
          *(undefined8 *)(puVar1 + 8) = 0;
        }
        *puVar2 = local_48[0];
        *(undefined8 *)(puVar2 + 8) = local_40;
        local_48[0] = 0;
        local_40 = 0;
        FUN_00117920(&local_40,0);
        param_2 = param_2 + 0x20;
        puVar2 = puVar2 + 0x10;
      } while (param_2 != param_3);
    }
    param_1[1] = (long)puVar2;
  }
  if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
    return;
  }
LAB_0011958f:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_001195b0 @ 001195b0

void FUN_001195b0(long *param_1,undefined8 param_2)

{
  ulong uVar1;
  long lVar2;
  long lVar3;
  void *pvVar4;
  void *pvVar5;
  ulong uVar6;
  ulong uVar7;
  long lVar8;
  long in_FS_OFFSET;
  long local_50;
  
  lVar2 = *(long *)(in_FS_OFFSET + 0x28);
  lVar8 = param_1[1] - *param_1 >> 4;
  uVar1 = lVar8 + 1;
  if (uVar1 >> 0x3c != 0) {
    FUN_00120270(param_1);
LAB_0011973c:
                    /* WARNING: Subroutine does not return */
    FUN_00118290("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
  }
  uVar6 = param_1[2] - *param_1;
  uVar7 = (long)uVar6 >> 3;
  if (uVar7 < uVar1) {
    uVar7 = uVar1;
  }
  if (0x7fffffffffffffef < uVar6) {
    uVar7 = 0xfffffffffffffff;
  }
  if (uVar7 == 0) {
    lVar3 = 0;
  }
  else {
    if (0xfffffffffffffff < uVar7) goto LAB_0011973c;
    lVar3 = FUN_0011e900(uVar7 << 4);
  }
  local_50 = lVar8 * 0x10 + lVar3;
                    /* try { // try from 00119668 to 00119672 has its CatchHandler @ 0011974d */
  FUN_00118a60(local_50,param_2);
  lVar8 = local_50 + 0x10;
  pvVar5 = (void *)*param_1;
  pvVar4 = (void *)param_1[1];
  if (pvVar4 == pvVar5) {
    pvVar4 = pvVar5;
  }
  else {
    do {
      *(undefined1 *)(local_50 + -0x10) = *(undefined1 *)((long)pvVar4 + -0x10);
      *(undefined8 *)(local_50 + -8) = *(undefined8 *)((long)pvVar4 + -8);
      *(undefined1 *)((long)pvVar4 + -0x10) = 0;
      *(undefined8 *)((long)pvVar4 + -8) = 0;
      pvVar4 = (void *)((long)pvVar4 + -0x10);
      local_50 = local_50 + -0x10;
    } while (pvVar4 != pvVar5);
    pvVar5 = (void *)param_1[1];
    pvVar4 = (void *)*param_1;
  }
  *param_1 = local_50;
  param_1[1] = lVar8;
  param_1[2] = uVar7 * 0x10 + lVar3;
  if (pvVar5 != pvVar4) {
    lVar8 = (long)pvVar5 + -8;
    do {
      pvVar5 = (void *)(lVar8 + -8);
      FUN_00117920(lVar8,*(undefined1 *)(lVar8 + -8));
      lVar8 = lVar8 + -0x10;
    } while (pvVar5 != pvVar4);
  }
  if (pvVar4 != (void *)0x0) {
    free(pvVar4);
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != lVar2) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00119760 @ 00119760

void FUN_00119760(long param_1)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  
  plVar3 = *(long **)(param_1 + 8);
  if (plVar3 != (long *)0x0) {
    LOCK();
    plVar1 = plVar3 + 1;
    lVar2 = *plVar1;
    *plVar1 = *plVar1 + -1;
    UNLOCK();
    if (lVar2 == 0) {
      (**(code **)(*plVar3 + 0x10))(plVar3);
      FUN_0011e880(plVar3);
      return;
    }
  }
  return;
}


// ==== FUN_00119790 @ 00119790

void FUN_00119790(long param_1)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  
  plVar3 = *(long **)(param_1 + 8);
  if (plVar3 != (long *)0x0) {
    LOCK();
    plVar1 = plVar3 + 1;
    lVar2 = *plVar1;
    *plVar1 = *plVar1 + -1;
    UNLOCK();
    if (lVar2 == 0) {
      (**(code **)(*plVar3 + 0x10))(plVar3);
      FUN_0011e880(plVar3);
      return;
    }
  }
  return;
}


// ==== FUN_001197c0 @ 001197c0

void FUN_001197c0(undefined8 *param_1,undefined1 *param_2,char param_3,undefined1 param_4,
                 int param_5,int param_6)

{
  double dVar1;
  byte *pbVar2;
  bool bVar3;
  uint uVar4;
  byte bVar5;
  byte bVar6;
  char cVar7;
  long *plVar8;
  long lVar9;
  long lVar10;
  ulong uVar11;
  undefined8 uVar12;
  long *plVar13;
  ulong uVar14;
  uint uVar15;
  char *pcVar16;
  byte *pbVar17;
  long lVar18;
  char *pcVar19;
  ulong uVar20;
  undefined8 *puVar21;
  undefined8 *puVar22;
  long *plVar23;
  long in_FS_OFFSET;
  undefined4 local_40;
  undefined4 local_3c;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  switch(*param_2) {
  case 0:
switchD_00119805_caseD_0:
    plVar13 = (long *)*param_1;
    lVar18 = *plVar13;
    pcVar19 = "null";
    uVar11 = 4;
    break;
  case 1:
    plVar13 = (long *)*param_1;
    if (*(long *)(*(long *)(param_2 + 8) + 0x10) == 0) {
      lVar18 = *plVar13;
      pcVar19 = "{}";
      goto LAB_00119b76;
    }
    if (param_3 != '\0') {
      (**(code **)(*plVar13 + 8))(plVar13,&DAT_0010ac2e,2);
      uVar11 = (ulong)(uint)(param_5 + param_6);
      if ((*(byte *)(param_1 + 0x4c) & 1) == 0) {
        uVar20 = (ulong)(*(byte *)(param_1 + 0x4c) >> 1);
      }
      else {
        uVar20 = param_1[0x4d];
      }
      if (uVar20 < uVar11) {
        FUN_0011f280(param_1 + 0x4c,uVar20 * 2,0x20);
      }
      plVar13 = (long *)**(undefined8 **)(param_2 + 8);
      puVar22 = (undefined8 *)((long)param_1 + 0x261);
      if ((*(undefined8 **)(param_2 + 8))[2] != 1) {
        uVar20 = 0;
        plVar23 = plVar13;
        do {
          puVar21 = puVar22;
          if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
            puVar21 = (undefined8 *)param_1[0x4e];
          }
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,puVar21,uVar11);
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
          FUN_0011a7e0(param_1,plVar23 + 4,param_4);
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a52a,3);
          FUN_001197c0(param_1,plVar23 + 7,1,param_4,param_5,uVar11);
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a62f,2);
          uVar20 = uVar20 + 1;
          plVar8 = (long *)plVar23[1];
          if ((long *)plVar23[1] == (long *)0x0) {
            plVar13 = (long *)plVar23[2];
            if ((long *)*plVar13 != plVar23) {
              do {
                plVar23 = (long *)plVar23[2];
                plVar13 = (long *)plVar23[2];
              } while ((long *)*plVar13 != plVar23);
            }
          }
          else {
            do {
              plVar13 = plVar8;
              plVar8 = (long *)*plVar13;
            } while ((long *)*plVar13 != (long *)0x0);
          }
          plVar23 = plVar13;
        } while (uVar20 < *(long *)(*(long *)(param_2 + 8) + 0x10) - 1U);
      }
      puVar21 = puVar22;
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        puVar21 = (undefined8 *)param_1[0x4e];
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,puVar21,uVar11);
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
      FUN_0011a7e0(param_1,plVar13 + 4,param_4);
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a52a,3);
      FUN_001197c0(param_1,plVar13 + 7,1,param_4,param_5,uVar11);
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,10);
      plVar13 = (long *)*param_1;
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        puVar22 = (undefined8 *)param_1[0x4e];
      }
      goto LAB_0011a61e;
    }
    (**(code **)*plVar13)(plVar13,0x7b);
    plVar13 = (long *)**(undefined8 **)(param_2 + 8);
    if ((*(undefined8 **)(param_2 + 8))[2] != 1) {
      uVar11 = 0;
      do {
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
        FUN_0011a7e0(param_1,plVar13 + 4,param_4);
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010ad46,2);
        FUN_001197c0(param_1,plVar13 + 7,0,param_4,param_5,param_6);
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x2c);
        uVar11 = uVar11 + 1;
        plVar23 = (long *)plVar13[1];
        if ((long *)plVar13[1] == (long *)0x0) {
          plVar8 = (long *)plVar13[2];
          if (*(long **)plVar13[2] != plVar13) {
            do {
              plVar13 = (long *)plVar13[2];
              plVar8 = (long *)plVar13[2];
            } while (*(long **)plVar13[2] != plVar13);
          }
        }
        else {
          do {
            plVar8 = plVar23;
            plVar23 = (long *)*plVar8;
          } while (plVar23 != (long *)0x0);
        }
        plVar13 = plVar8;
      } while (uVar11 < *(long *)(*(long *)(param_2 + 8) + 0x10) - 1U);
    }
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
    FUN_0011a7e0(param_1,plVar13 + 4,param_4);
    (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010ad46,2);
    FUN_001197c0(param_1,plVar13 + 7,0,param_4,param_5,param_6);
    goto LAB_0011a68a;
  case 2:
    plVar13 = (long *)*param_1;
    if (**(long **)(param_2 + 8) != (*(long **)(param_2 + 8))[1]) {
      if (param_3 == '\0') {
        (**(code **)*plVar13)(plVar13,0x5b);
        lVar18 = **(long **)(param_2 + 8);
        if (lVar18 != (*(long **)(param_2 + 8))[1] + -0x10) {
          do {
            FUN_001197c0(param_1,lVar18,0,param_4,param_5,param_6);
            (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x2c);
            lVar18 = lVar18 + 0x10;
          } while (lVar18 != *(long *)(*(long *)(param_2 + 8) + 8) + -0x10);
        }
        FUN_001197c0(param_1,lVar18,0,param_4,param_5,param_6);
      }
      else {
        (**(code **)(*plVar13 + 8))(plVar13,&DAT_0010a32d,2);
        uVar11 = (ulong)(uint)(param_6 + param_5);
        if ((*(byte *)(param_1 + 0x4c) & 1) == 0) {
          uVar20 = (ulong)(*(byte *)(param_1 + 0x4c) >> 1);
        }
        else {
          uVar20 = param_1[0x4d];
        }
        if (uVar20 < uVar11) {
          FUN_0011f280(param_1 + 0x4c,uVar20 * 2,0x20);
        }
        lVar18 = **(long **)(param_2 + 8);
        lVar9 = (long)param_1 + 0x261;
        if (lVar18 != (*(long **)(param_2 + 8))[1] + -0x10) {
          do {
            lVar10 = lVar9;
            if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
              lVar10 = param_1[0x4e];
            }
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar10,uVar11);
            FUN_001197c0(param_1,lVar18,1,param_4,param_5,uVar11);
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a62f,2);
            lVar18 = lVar18 + 0x10;
          } while (lVar18 != *(long *)(*(long *)(param_2 + 8) + 8) + -0x10);
        }
        lVar18 = lVar9;
        if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
          lVar18 = param_1[0x4e];
        }
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar18,uVar11);
        FUN_001197c0(param_1,*(long *)(*(long *)(param_2 + 8) + 8) + -0x10,1,param_4,param_5,uVar11)
        ;
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,10);
        if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
          lVar9 = param_1[0x4e];
        }
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar9,param_6);
      }
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x5d);
      if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
        return;
      }
      goto LAB_0011a6ab;
    }
    lVar18 = *plVar13;
    pcVar19 = "[]";
LAB_00119b76:
    uVar11 = 2;
    break;
  case 3:
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
    FUN_0011a7e0(param_1,*(undefined8 *)(param_2 + 8),param_4);
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
    if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
      return;
    }
    goto LAB_0011a6ab;
  case 4:
    plVar13 = (long *)*param_1;
    if (param_2[8] == '\0') {
      (**(code **)(*plVar13 + 8))(plVar13,"false",5);
      if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
        return;
      }
    }
    else {
      (**(code **)(*plVar13 + 8))(plVar13,&DAT_0010a52e,4);
      if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
        return;
      }
    }
    goto LAB_0011a6ab;
  case 5:
    FUN_0011af10(param_1,*(undefined8 *)(param_2 + 8));
    if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
      return;
    }
    goto LAB_0011a6ab;
  case 6:
    uVar20 = *(ulong *)(param_2 + 8);
    if (uVar20 == 0) {
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
      if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
        return;
      }
      goto LAB_0011a6ab;
    }
    pcVar19 = (char *)(param_1 + 2);
    if (uVar20 < 10) {
      lVar18 = (long)param_1 + 0x11;
      uVar11 = 1;
LAB_0011a3ff:
      *(char *)(lVar18 + -1) = (char)uVar20 + '0';
    }
    else {
      uVar11 = uVar20;
      uVar4 = 4;
      do {
        uVar15 = uVar4;
        if (uVar11 < 100) {
          uVar15 = uVar15 - 2;
          goto LAB_0011a382;
        }
        if (uVar11 < 1000) {
          uVar15 = uVar15 - 1;
          goto LAB_0011a382;
        }
        if (uVar11 < 10000) goto LAB_0011a382;
        bVar3 = 99999 < uVar11;
        uVar11 = uVar11 / 10000;
        uVar4 = uVar15 + 4;
      } while (bVar3);
      uVar15 = uVar15 + 1;
LAB_0011a382:
      uVar11 = (ulong)uVar15;
      lVar18 = (long)param_1 + uVar11 + 0x10;
      uVar14 = uVar20;
      if (99 < uVar20) {
        do {
          uVar20 = uVar14 / 100;
          *(undefined2 *)(lVar18 + -2) =
               *(undefined2 *)
                (
                "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
                + (uVar14 % 100) * 2);
          lVar18 = lVar18 + -2;
          bVar3 = 9999 < uVar14;
          uVar14 = uVar20;
        } while (bVar3);
      }
      if (uVar20 < 10) goto LAB_0011a3ff;
      *(undefined2 *)(lVar18 + -2) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
            + uVar20 * 2);
    }
    plVar13 = (long *)*param_1;
    lVar18 = *plVar13;
    break;
  case 7:
    dVar1 = *(double *)(param_2 + 8);
    if (ABS(dVar1) == INFINITY) goto switchD_00119805_caseD_0;
    pcVar19 = (char *)(param_1 + 2);
    if ((long)dVar1 < 0) {
      pcVar16 = (char *)((long)param_1 + 0x11);
      *(undefined1 *)(param_1 + 2) = 0x2d;
      if ((-dVar1 == 0.0) && (!NAN(-dVar1))) goto LAB_001199a0;
LAB_00119ee7:
      local_3c = 0;
      local_40 = 0;
      FUN_0011b1e0(pcVar16,&local_3c,&local_40);
      pcVar16 = (char *)FUN_0011b460(pcVar16,local_3c,local_40,0xfffffffc,0xf);
    }
    else {
      pcVar16 = pcVar19;
      if ((dVar1 != 0.0) || (NAN(dVar1))) goto LAB_00119ee7;
LAB_001199a0:
      pcVar16[0] = '0';
      pcVar16[1] = '.';
      pcVar16[2] = '0';
      pcVar16 = pcVar16 + 3;
    }
    plVar13 = (long *)*param_1;
    uVar11 = (long)pcVar16 - (long)pcVar19;
    lVar18 = *plVar13;
    break;
  case 8:
    plVar13 = (long *)*param_1;
    if (param_3 == '\0') {
      (**(code **)(*plVar13 + 8))(plVar13,"{\"bytes\":[",10);
      pbVar17 = (byte *)**(undefined8 **)(param_2 + 8);
      pbVar2 = (byte *)(*(undefined8 **)(param_2 + 8))[1];
      if (pbVar17 != pbVar2) {
        if (pbVar17 != pbVar2 + -1) {
          do {
            bVar5 = *pbVar17;
            uVar11 = (ulong)bVar5;
            if (uVar11 == 0) {
              (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
            }
            else {
              uVar12 = 1;
              bVar6 = bVar5;
              if (bVar5 < 10) {
LAB_00119b22:
                cVar7 = bVar6 + 0x30;
              }
              else {
                if (99 < bVar5) {
                  bVar6 = (byte)((uint)bVar5 + (uint)bVar5 * 0x28 >> 0xc);
                  *(undefined2 *)((long)param_1 + 0x11) =
                       *(undefined2 *)(&DAT_0010b465 + (ulong)(byte)(bVar5 + bVar6 * -100) * 2);
                  uVar12 = 3;
                  goto LAB_00119b22;
                }
                cVar7 = (&DAT_0010b465)[uVar11 * 2];
                *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b466)[uVar11 * 2];
                uVar12 = 2;
              }
              *(char *)(param_1 + 2) = cVar7;
              (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar12);
            }
            (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x2c);
            pbVar17 = pbVar17 + 1;
          } while (pbVar17 != (byte *)(*(long *)(*(long *)(param_2 + 8) + 8) + -1));
        }
        bVar5 = *pbVar17;
        uVar11 = (ulong)bVar5;
        if (uVar11 == 0) {
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
        }
        else {
          uVar12 = 1;
          bVar6 = bVar5;
          if (bVar5 < 10) {
LAB_0011a43e:
            cVar7 = bVar6 + 0x30;
          }
          else {
            if (99 < bVar5) {
              bVar6 = (byte)((uint)bVar5 + (uint)bVar5 * 0x28 >> 0xc);
              *(undefined2 *)((long)param_1 + 0x11) =
                   *(undefined2 *)(&DAT_0010b465 + (ulong)(byte)(bVar5 + bVar6 * -100) * 2);
              uVar12 = 3;
              goto LAB_0011a43e;
            }
            cVar7 = (&DAT_0010b465)[uVar11 * 2];
            *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b466)[uVar11 * 2];
            uVar12 = 2;
          }
          *(char *)(param_1 + 2) = cVar7;
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar12);
        }
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,"],\"subtype\":",0xc);
      if (*(char *)(*(long *)(param_2 + 8) + 0x19) == '\0') {
        plVar13 = (long *)*param_1;
        lVar18 = *plVar13;
        pcVar19 = "null}";
        uVar11 = 5;
        break;
      }
      bVar5 = *(byte *)(*(long *)(param_2 + 8) + 0x18);
      uVar11 = (ulong)bVar5;
      if (uVar11 == 0) {
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
        goto LAB_0011a68a;
      }
      puVar22 = param_1 + 2;
      param_6 = 1;
      bVar6 = bVar5;
      if (bVar5 < 10) {
LAB_0011a615:
        cVar7 = bVar6 + 0x30;
      }
      else {
        if (99 < bVar5) {
          bVar6 = (byte)((uint)bVar5 + (uint)bVar5 * 0x28 >> 0xc);
          *(undefined2 *)((long)param_1 + 0x11) =
               *(undefined2 *)(&DAT_0010b465 + (ulong)(byte)(bVar5 + bVar6 * -100) * 2);
          param_6 = 3;
          goto LAB_0011a615;
        }
        cVar7 = (&DAT_0010b465)[uVar11 * 2];
        *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b466)[uVar11 * 2];
        param_6 = 2;
      }
      *(char *)(param_1 + 2) = cVar7;
      plVar13 = (long *)*param_1;
LAB_0011a61e:
      lVar18 = *plVar13;
    }
    else {
      (**(code **)(*plVar13 + 8))(plVar13,&DAT_0010ac2e,2);
      uVar11 = (ulong)(uint)(param_5 + param_6);
      bVar5 = *(byte *)(param_1 + 0x4c) & 1;
      if (bVar5 == 0) {
        uVar20 = (ulong)(*(byte *)(param_1 + 0x4c) >> 1);
      }
      else {
        uVar20 = param_1[0x4d];
      }
      if (uVar20 < uVar11) {
        FUN_0011f280(param_1 + 0x4c,uVar20 * 2,0x20);
        bVar5 = *(byte *)(param_1 + 0x4c) & 1;
      }
      puVar22 = (undefined8 *)((long)param_1 + 0x261);
      puVar21 = puVar22;
      if (bVar5 != 0) {
        puVar21 = (undefined8 *)param_1[0x4e];
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,puVar21,uVar11);
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,"\"bytes\": [",10);
      pbVar17 = (byte *)**(undefined8 **)(param_2 + 8);
      pbVar2 = (byte *)(*(undefined8 **)(param_2 + 8))[1];
      if (pbVar17 != pbVar2) {
        if (pbVar17 != pbVar2 + -1) {
          do {
            bVar5 = *pbVar17;
            uVar20 = (ulong)bVar5;
            if (uVar20 == 0) {
              (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
            }
            else {
              uVar12 = 1;
              bVar6 = bVar5;
              if (bVar5 < 10) {
LAB_00119e62:
                cVar7 = bVar6 + 0x30;
              }
              else {
                if (99 < bVar5) {
                  bVar6 = (byte)((uint)bVar5 + (uint)bVar5 * 0x28 >> 0xc);
                  *(undefined2 *)((long)param_1 + 0x11) =
                       *(undefined2 *)(&DAT_0010b465 + (ulong)(byte)(bVar5 + bVar6 * -100) * 2);
                  uVar12 = 3;
                  goto LAB_00119e62;
                }
                cVar7 = (&DAT_0010b465)[uVar20 * 2];
                *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b466)[uVar20 * 2];
                uVar12 = 2;
              }
              *(char *)(param_1 + 2) = cVar7;
              (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar12);
            }
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010add3,2);
            pbVar17 = pbVar17 + 1;
          } while (pbVar17 != (byte *)(*(long *)(*(long *)(param_2 + 8) + 8) + -1));
        }
        bVar5 = *pbVar17;
        uVar20 = (ulong)bVar5;
        if (uVar20 == 0) {
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
        }
        else {
          uVar12 = 1;
          bVar6 = bVar5;
          if (bVar5 < 10) {
LAB_0011a523:
            cVar7 = bVar6 + 0x30;
          }
          else {
            if (99 < bVar5) {
              bVar6 = (byte)((uint)bVar5 + (uint)bVar5 * 0x28 >> 0xc);
              *(undefined2 *)((long)param_1 + 0x11) =
                   *(undefined2 *)(&DAT_0010b465 + (ulong)(byte)(bVar5 + bVar6 * -100) * 2);
              uVar12 = 3;
              goto LAB_0011a523;
            }
            cVar7 = (&DAT_0010b465)[uVar20 * 2];
            *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b466)[uVar20 * 2];
            uVar12 = 2;
          }
          *(char *)(param_1 + 2) = cVar7;
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar12);
        }
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a755,3);
      puVar21 = puVar22;
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        puVar21 = (undefined8 *)param_1[0x4e];
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,puVar21,uVar11);
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,"\"subtype\": ",0xb);
      if (*(char *)(*(long *)(param_2 + 8) + 0x19) == '\0') {
        plVar13 = (long *)*param_1;
        lVar18 = *plVar13;
        puVar21 = (undefined8 *)&DAT_00109b2d;
        uVar12 = 4;
LAB_0011a65a:
        (**(code **)(lVar18 + 8))(plVar13,puVar21,uVar12);
      }
      else {
        bVar5 = *(byte *)(*(long *)(param_2 + 8) + 0x18);
        uVar11 = (ulong)bVar5;
        if (uVar11 != 0) {
          puVar21 = param_1 + 2;
          uVar12 = 1;
          bVar6 = bVar5;
          if (bVar5 < 10) {
LAB_0011a64e:
            cVar7 = bVar6 + 0x30;
          }
          else {
            if (99 < bVar5) {
              bVar6 = (byte)((uint)bVar5 + (uint)bVar5 * 0x28 >> 0xc);
              *(undefined2 *)((long)param_1 + 0x11) =
                   *(undefined2 *)(&DAT_0010b465 + (ulong)(byte)(bVar5 + bVar6 * -100) * 2);
              uVar12 = 3;
              goto LAB_0011a64e;
            }
            cVar7 = (&DAT_0010b465)[uVar11 * 2];
            *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b466)[uVar11 * 2];
            uVar12 = 2;
          }
          *(char *)(param_1 + 2) = cVar7;
          plVar13 = (long *)*param_1;
          lVar18 = *plVar13;
          goto LAB_0011a65a;
        }
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
      }
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,10);
      plVar13 = (long *)*param_1;
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        puVar22 = (undefined8 *)param_1[0x4e];
      }
      lVar18 = *plVar13;
    }
    (**(code **)(lVar18 + 8))(plVar13,puVar22,param_6);
LAB_0011a68a:
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x7d);
    if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
      return;
    }
    goto LAB_0011a6ab;
  case 9:
    plVar13 = (long *)*param_1;
    lVar18 = *plVar13;
    pcVar19 = "<discarded>";
    uVar11 = 0xb;
    break;
  default:
    goto switchD_00119805_default;
  }
  (**(code **)(lVar18 + 8))(plVar13,pcVar19,uVar11);
switchD_00119805_default:
  if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
    return;
  }
LAB_0011a6ab:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0011a700 @ 0011a700

void FUN_0011a700(long param_1)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  
  if ((*(byte *)(param_1 + 0x260) & 1) != 0) {
    free(*(void **)(param_1 + 0x270));
  }
  plVar3 = *(long **)(param_1 + 8);
  if (plVar3 != (long *)0x0) {
    LOCK();
    plVar1 = plVar3 + 1;
    lVar2 = *plVar1;
    *plVar1 = *plVar1 + -1;
    UNLOCK();
    if (lVar2 == 0) {
      (**(code **)(*plVar3 + 0x10))(plVar3);
      FUN_0011e880(plVar3);
      return;
    }
  }
  return;
}


// ==== FUN_0011a780 @ 0011a780

void FUN_0011a780(long param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0011a788. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(long *)(param_1 + 0x18) + 0x10))(param_1 + 0x18);
  return;
}


// ==== FUN_0011a7e0 @ 0011a7e0

/* WARNING: Type propagation algorithm not settling */

void FUN_0011a7e0(undefined8 *param_1,byte *param_2,char param_3)

{
  long lVar1;
  byte bVar2;
  int iVar3;
  byte bVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  undefined1 uVar7;
  undefined1 uVar8;
  ulong uVar9;
  ulong uVar10;
  byte *pbVar11;
  long lVar12;
  long lVar13;
  long *plVar14;
  uint unaff_R13D;
  long lVar15;
  long lVar16;
  long in_FS_OFFSET;
  bool bVar17;
  byte *local_d0;
  undefined1 local_c0 [24];
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined1 local_68 [24];
  undefined1 local_50;
  undefined4 local_4f [5];
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  bVar17 = (*param_2 & 1) == 0;
  if (bVar17) {
    if (*param_2 >> 1 != 0) goto LAB_0011a830;
  }
  else if (*(long *)(param_2 + 8) != 0) {
LAB_0011a830:
    local_d0 = param_2 + 1;
    lVar1 = (long)param_1 + 0x5a;
    lVar15 = 0;
    uVar10 = 0;
    lVar13 = 0;
    lVar16 = 0;
    bVar4 = 0;
LAB_0011a86e:
    do {
      pbVar11 = local_d0;
      if (!bVar17) {
        pbVar11 = *(byte **)(param_2 + 0x10);
      }
      bVar2 = pbVar11[uVar10];
      if (bVar4 == 0) {
        unaff_R13D = 0xffU >> ((&DAT_0010b2d5)[bVar2] & 0x1f) & (uint)bVar2;
      }
      else {
        unaff_R13D = unaff_R13D << 6 | bVar2 & 0x3f;
      }
      bVar4 = (&DAT_0010b3d5)[(ulong)(byte)(&DAT_0010b2d5)[bVar2] + (ulong)bVar4 * 0x10];
      if (bVar4 == 1) {
        iVar3 = *(int *)(param_1 + 0x4f);
        if (1 < iVar3 - 1U) {
          bVar4 = 1;
          if (iVar3 != 0) goto LAB_0011aabc;
          local_50 = 6;
          local_4f[0] = 0;
                    /* try { // try from 0011ad0b to 0011ad22 has its CatchHandler @ 0011aee2 */
          FUN_0011b120(local_4f,0x17,3,&DAT_0010a632);
          uVar5 = FUN_001202b0(0x20);
                    /* try { // try from 0011ad30 to 0011ad3c has its CatchHandler @ 0011aecb */
          FUN_0011f580(local_c0,uVar10);
                    /* try { // try from 0011ad3d to 0011ad4f has its CatchHandler @ 0011aeb5 */
          puVar6 = (undefined8 *)FUN_0011f030(local_c0,0,"invalid UTF-8 byte at index ");
          local_98 = puVar6[2];
          local_a8 = *puVar6;
          uStack_a0 = puVar6[1];
          *puVar6 = 0;
          puVar6[1] = 0;
          puVar6[2] = 0;
                    /* try { // try from 0011ad6f to 0011ad7f has its CatchHandler @ 0011ae76 */
          puVar6 = (undefined8 *)FUN_0011f1c0(&local_a8,&DAT_0010aac9);
          local_78 = puVar6[2];
          local_88 = *puVar6;
          uStack_80 = puVar6[1];
          *puVar6 = 0;
          puVar6[1] = 0;
          puVar6[2] = 0;
                    /* try { // try from 0011ad9f to 0011adb5 has its CatchHandler @ 0011ae56 */
          FUN_001187a0(local_68,&local_88,&local_50);
                    /* try { // try from 0011adb9 to 0011ade3 has its CatchHandler @ 0011ae1f */
          FUN_00118540(uVar5,0x13c,local_68);
          FUN_00120320(uVar5,&PTR_PTR_0013e390,&LAB_00118750);
          goto LAB_0011ade4;
        }
        uVar10 = (uVar10 - 1) + (ulong)(lVar13 == 0);
        if (iVar3 == 1) {
          if (param_3 == '\0') {
            lVar15 = lVar16 + 1;
            *(undefined1 *)((long)param_1 + lVar16 + 0x5a) = 0xef;
            uVar7 = 0xbd;
            lVar13 = 3;
            uVar8 = 0xbf;
            lVar12 = 2;
          }
          else {
            *(undefined4 *)((long)param_1 + lVar16 + 0x5a) = 0x6666755c;
            lVar15 = lVar16 + 4;
            uVar7 = 100;
            lVar13 = 6;
            uVar8 = 0x66;
            lVar12 = 5;
          }
          *(undefined1 *)((long)param_1 + lVar15 + 0x5a) = uVar8;
          lVar15 = lVar16 + lVar13;
          *(undefined1 *)((long)param_1 + lVar12 + lVar16 + 0x5a) = uVar7;
          if (0xc < (lVar16 + lVar13) - 500U) {
            bVar4 = 0;
            lVar13 = 0;
            lVar16 = lVar15;
            goto LAB_0011aabc;
          }
          plVar14 = (long *)*param_1;
          lVar13 = *plVar14;
          goto LAB_0011aa9f;
        }
LAB_0011aa40:
        bVar4 = 0;
        lVar13 = 0;
        lVar15 = lVar16;
      }
      else if (bVar4 == 0) {
        switch(unaff_R13D) {
        case 8:
          *(undefined2 *)((long)param_1 + lVar15 + 0x5a) = 0x625c;
          break;
        case 9:
          *(undefined2 *)((long)param_1 + lVar15 + 0x5a) = 0x745c;
          break;
        case 10:
          *(undefined2 *)((long)param_1 + lVar15 + 0x5a) = 0x6e5c;
          break;
        case 0xb:
        case 0xe:
        case 0xf:
        case 0x10:
        case 0x11:
        case 0x12:
        case 0x13:
        case 0x14:
        case 0x15:
        case 0x16:
        case 0x17:
        case 0x18:
        case 0x19:
        case 0x1a:
        case 0x1b:
        case 0x1c:
        case 0x1d:
        case 0x1e:
        case 0x1f:
        case 0x20:
        case 0x21:
LAB_0011a9e1:
          if (unaff_R13D < 0x20) {
LAB_0011a9eb:
            FUN_0011b120((long)param_1 + lVar15 + 0x5a,0xffffffffffffffff,7,"\\u%04x",unaff_R13D);
            lVar16 = lVar15 + 6;
            uVar9 = lVar15 - 0x1ee;
          }
          else if ((param_3 == '\0') || (unaff_R13D < 0x7f)) {
            *(byte *)((long)param_1 + lVar15 + 0x5a) = bVar2;
            lVar16 = lVar15 + 1;
            uVar9 = lVar15 - 499;
          }
          else {
            if (unaff_R13D < 0x10000) goto LAB_0011a9eb;
            FUN_0011b120((long)param_1 + lVar15 + 0x5a,0xffffffffffffffff,0xd,"\\u%04x\\u%04x",
                         (unaff_R13D >> 10) + 0xd7c0 & 0xffff,unaff_R13D & 0x3ff | 0xdc00);
            lVar16 = lVar15 + 0xc;
            uVar9 = lVar15 - 0x1e8;
          }
          goto joined_r0x0011ab67;
        case 0xc:
          *(undefined2 *)((long)param_1 + lVar15 + 0x5a) = 0x665c;
          break;
        case 0xd:
          *(undefined2 *)((long)param_1 + lVar15 + 0x5a) = 0x725c;
          break;
        case 0x22:
          *(undefined2 *)((long)param_1 + lVar15 + 0x5a) = 0x225c;
          break;
        default:
          if (unaff_R13D != 0x5c) goto LAB_0011a9e1;
          *(undefined2 *)((long)param_1 + lVar15 + 0x5a) = 0x5c5c;
        }
        lVar16 = lVar15 + 2;
        uVar9 = lVar15 - 0x1f2;
joined_r0x0011ab67:
        if (0xc < uVar9) goto LAB_0011aa40;
        plVar14 = (long *)*param_1;
        lVar13 = *plVar14;
        lVar15 = lVar16;
LAB_0011aa9f:
        (**(code **)(lVar13 + 8))(plVar14,lVar1,lVar15);
        bVar4 = 0;
        lVar13 = 0;
        lVar16 = 0;
        lVar15 = 0;
      }
      else {
        if (param_3 == '\0') {
          *(byte *)((long)param_1 + lVar15 + 0x5a) = bVar2;
          lVar15 = lVar15 + 1;
        }
        lVar13 = lVar13 + 1;
      }
LAB_0011aabc:
      uVar10 = uVar10 + 1;
      bVar2 = *param_2;
      bVar17 = (bVar2 & 1) == 0;
      if (bVar17) {
        uVar9 = (ulong)(bVar2 >> 1);
        if (uVar9 <= uVar10) break;
        goto LAB_0011a86e;
      }
      uVar9 = *(ulong *)(param_2 + 8);
    } while (uVar10 < uVar9);
    if (bVar4 == 0) {
      if (lVar15 != 0) {
        plVar14 = (long *)*param_1;
        lVar13 = *plVar14;
        lVar16 = lVar15;
LAB_0011abab:
        (**(code **)(lVar13 + 8))(plVar14,lVar1,lVar16);
      }
    }
    else {
      iVar3 = *(int *)(param_1 + 0x4f);
      if (iVar3 == 1) {
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar1);
        plVar14 = (long *)*param_1;
        if (param_3 == '\0') {
          (**(code **)(*plVar14 + 8))(plVar14,&DAT_0010abe8,3);
        }
        else {
          (**(code **)(*plVar14 + 8))(plVar14,"\\ufffd",6);
        }
      }
      else {
        if (iVar3 == 2) {
          plVar14 = (long *)*param_1;
          lVar13 = *plVar14;
          goto LAB_0011abab;
        }
        if (iVar3 == 0) {
          local_50 = 6;
          local_4f[0] = 0;
          if ((bVar2 & 1) != 0) {
            local_d0 = *(byte **)(param_2 + 0x10);
          }
                    /* try { // try from 0011ac2a to 0011ac41 has its CatchHandler @ 0011ae09 */
          FUN_0011b120(local_4f,0x17,3,&DAT_0010a632,local_d0[uVar9 - 1]);
          uVar5 = FUN_001202b0(0x20);
                    /* try { // try from 0011ac4f to 0011ac67 has its CatchHandler @ 0011ae04 */
          FUN_0011f2d0(local_68,"incomplete UTF-8 string; last byte: 0x",&local_50);
                    /* try { // try from 0011ac6b to 0011ac95 has its CatchHandler @ 0011ade9 */
          FUN_00118540(uVar5,0x13c,local_68);
          FUN_00120320(uVar5,&PTR_PTR_0013e390,&LAB_00118750);
          goto LAB_0011ade4;
        }
      }
    }
  }
  if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
    return;
  }
LAB_0011ade4:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0011af10 @ 0011af10

/* WARNING: Type propagation algorithm not settling */

void FUN_0011af10(undefined8 *param_1,ulong param_2)

{
  bool bVar1;
  uint uVar2;
  long lVar3;
  ulong uVar4;
  uint uVar5;
  ulong uVar6;
  
  if (param_2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0011af4a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
    return;
  }
  if ((long)param_2 < 0) {
    *(undefined1 *)(param_1 + 2) = 0x2d;
    param_2 = -param_2;
    uVar5 = 1;
    if (9 < param_2) {
      uVar6 = param_2;
      uVar2 = 4;
      do {
        uVar5 = uVar2;
        if (uVar6 < 100) {
          uVar5 = uVar5 - 1;
          goto joined_r0x0011b03f;
        }
        if (uVar6 < 1000) {
          uVar5 = uVar5 - 1;
          goto joined_r0x0011b0ef;
        }
        if (uVar6 < 10000) goto joined_r0x0011b0ef;
        bVar1 = 99999 < uVar6;
        uVar6 = uVar6 / 10000;
        uVar2 = uVar5 + 4;
      } while (bVar1);
      uVar5 = uVar5 + 1;
    }
joined_r0x0011b0ef:
    uVar5 = uVar5 + 1;
joined_r0x0011b03f:
    uVar6 = (ulong)uVar5;
    lVar3 = (long)param_1 + uVar6 + 0x10;
    if (99 < param_2) {
      do {
        uVar4 = param_2 / 100;
        *(undefined2 *)(lVar3 + -2) = *(undefined2 *)(&DAT_0010b52d + (param_2 % 100) * 2);
        lVar3 = lVar3 + -2;
        bVar1 = 9999 < param_2;
        param_2 = uVar4;
      } while (bVar1);
    }
    if (9 < param_2) {
      *(undefined2 *)(lVar3 + -2) = *(undefined2 *)(&DAT_0010b52d + param_2 * 2);
      goto LAB_0011b109;
    }
  }
  else {
    if (9 < param_2) {
      uVar6 = param_2;
      uVar2 = 4;
      do {
        uVar5 = uVar2;
        if (uVar6 < 100) {
          uVar5 = uVar5 - 2;
          goto joined_r0x0011b03f;
        }
        if (uVar6 < 1000) {
          uVar5 = uVar5 - 1;
          goto joined_r0x0011b03f;
        }
        if (uVar6 < 10000) goto joined_r0x0011b03f;
        bVar1 = 99999 < uVar6;
        uVar6 = uVar6 / 10000;
        uVar2 = uVar5 + 4;
      } while (bVar1);
      goto joined_r0x0011b0ef;
    }
    lVar3 = (long)param_1 + 0x11;
    uVar6 = 1;
  }
  *(char *)(lVar3 + -1) = (char)param_2 + '0';
LAB_0011b109:
                    /* WARNING: Could not recover jumptable at 0x0011b117. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar6);
  return;
}


// ==== FUN_0011b120 @ 0011b120

void FUN_0011b120(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined1 param_15)

{
  char in_AL;
  long in_FS_OFFSET;
  undefined1 auStack_d8 [32];
  undefined8 local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  undefined8 local_98;
  undefined8 local_88;
  undefined8 local_78;
  undefined8 local_68;
  undefined8 local_58;
  undefined8 local_48;
  undefined8 local_38;
  undefined8 local_28;
  undefined1 *local_20;
  undefined1 *local_18;
  long local_8;
  
  local_18 = auStack_d8;
  if (in_AL != '\0') {
    local_a8 = param_1;
    local_98 = param_2;
    local_88 = param_3;
    local_78 = param_4;
    local_68 = param_5;
    local_58 = param_6;
    local_48 = param_7;
    local_38 = param_8;
  }
  local_8 = *(long *)(in_FS_OFFSET + 0x28);
  local_20 = &param_15;
  local_28 = 0x3000000020;
  local_b8 = param_13;
  local_b0 = param_14;
  __vsnprintf_chk(param_9,param_11,0,param_10,param_12,&local_28);
  if (*(long *)(in_FS_OFFSET + 0x28) != local_8) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0011b1e0 @ 0011b1e0

void FUN_0011b1e0(ulong param_1,undefined8 param_2,undefined8 param_3,int *param_4)

{
  long lVar1;
  ulong uVar2;
  ulong uVar3;
  short sVar4;
  int iVar5;
  int iVar6;
  ulong uVar7;
  short sVar8;
  int iVar9;
  ulong uVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  long lVar14;
  ulong uVar15;
  int iVar16;
  long lVar17;
  ulong uVar18;
  int iVar19;
  ulong uVar20;
  ulong uVar21;
  ulong uVar22;
  long in_FS_OFFSET;
  uint uVar23;
  undefined4 uStack_4c;
  undefined4 local_48;
  
  uVar23 = (uint)(param_1 >> 0x20);
  lVar1 = *(long *)(in_FS_OFFSET + 0x28);
  uVar2 = 0x10000000000000;
  param_1 = param_1 & 0xfffffffffffff;
  if (uVar23 >> 0x14 == 0) {
    uVar18 = param_1 * 2 + 1;
    iVar19 = -0x432;
    iVar16 = -0x433;
    uVar2 = param_1;
  }
  else {
    iVar19 = (uVar23 >> 0x14) - 0x433;
    iVar16 = (uVar23 >> 0x14) - 0x434;
    uVar18 = (param_1 | 0x10000000000000) * 2 + 1;
    if ((uVar23 >> 0x15 != 0) && (param_1 == 0)) {
      iVar5 = (uVar23 >> 0x14) - 0x435;
      lVar14 = 0x3fffffffffffff;
      goto LAB_0011b297;
    }
    uVar2 = param_1 | 0x10000000000000;
  }
  lVar14 = uVar2 * 2 + -1;
  iVar5 = iVar16;
LAB_0011b297:
  for (; -1 < (long)uVar18; uVar18 = uVar18 * 2) {
    iVar16 = iVar16 + -1;
  }
  for (; -1 < (long)uVar2; uVar2 = uVar2 * 2) {
    iVar19 = iVar19 + -1;
  }
  uVar15 = lVar14 << ((char)iVar5 - (char)iVar16 & 0x3fU);
  iVar6 = -0x3d - iVar16;
  iVar9 = iVar6 * 0x13441;
  iVar5 = iVar9 + 0x3ffff;
  if (-1 < iVar9) {
    iVar5 = iVar9;
  }
  sVar8 = (short)(iVar5 >> 0x12);
  sVar4 = (ushort)(0 < iVar6) + sVar8 + 0x133;
  sVar8 = (ushort)(0 < iVar6) + sVar8 + 0x13a;
  if (-1 < sVar4) {
    sVar8 = sVar4;
  }
  lVar14 = (long)((int)sVar8 >> 3) * 0x10;
  uVar20 = *(ulong *)(&DAT_0010b6c0 + lVar14) & 0xffffffff;
  uVar22 = *(ulong *)(&DAT_0010b6c0 + lVar14) >> 0x20;
  uVar7 = (uVar2 & 0xffffffff) * uVar22;
  uVar11 = uVar20 * (uVar2 >> 0x20);
  lVar17 = (uVar7 & 0xffffffff) + (uVar20 * (uVar2 & 0xffffffff) >> 0x20);
  iVar5 = (int)*(undefined8 *)(&UNK_0010b6c8 + lVar14);
  uVar12 = uVar15 & 0xffffffff;
  uVar15 = uVar15 >> 0x20;
  uVar13 = uVar12 * uVar22;
  uVar10 = uVar20 * uVar15;
  iVar16 = iVar16 + iVar5 + 0x40;
  uVar3 = (uVar18 & 0xffffffff) * uVar22;
  uVar21 = uVar20 * (uVar18 >> 0x20);
  *param_4 = -(int)((ulong)*(undefined8 *)(&UNK_0010b6c8 + lVar14) >> 0x20);
  local_48 = (undefined4)
             (((uVar11 & 0xffffffff) + lVar17 + 0x80000000 >> 0x20) +
             (uVar11 >> 0x20) + (uVar2 >> 0x20) * uVar22 + (uVar7 >> 0x20));
  FUN_0011b600(param_2,param_3,param_4,
               ((uVar10 & 0xffffffff) + (uVar13 & 0xffffffff) + (uVar20 * uVar12 >> 0x20) +
                0x80000000 >> 0x20) + (uVar10 >> 0x20) + uVar15 * uVar22 + (uVar13 >> 0x20) + 1,
               iVar16,lVar17,local_48,iVar19 + iVar5 + 0x40,
               ((uVar21 & 0xffffffff) +
                (uVar3 & 0xffffffff) + (uVar20 * (uVar18 & 0xffffffff) >> 0x20) + 0x80000000 >> 0x20
               ) + (uVar21 >> 0x20) + (uVar18 >> 0x20) * uVar22 + (uVar3 >> 0x20) + -1,
               CONCAT44(uStack_4c,iVar16));
  if (*(long *)(in_FS_OFFSET + 0x28) != lVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0011b460 @ 0011b460

long FUN_0011b460(undefined2 *param_1,int param_2,int param_3,int param_4,int param_5)

{
  char cVar1;
  byte bVar2;
  uint uVar3;
  long lVar4;
  uint uVar5;
  long lVar6;
  ulong uVar7;
  
  uVar5 = param_3 + param_2;
  if ((-1 < param_3) && ((int)uVar5 <= param_5)) {
    lVar6 = (long)(int)uVar5;
    memset((void *)((long)param_1 + (long)param_2),0x30,lVar6 - param_2);
    *(undefined2 *)((long)param_1 + lVar6) = 0x302e;
    return (long)param_1 + lVar6 + 2;
  }
  if ((0 < (int)uVar5) && ((int)uVar5 <= param_5)) {
    uVar7 = (ulong)uVar5;
    memmove((void *)((long)param_1 + uVar7 + 1),(void *)((long)param_1 + uVar7),
            (long)param_2 - uVar7);
    *(undefined1 *)((long)param_1 + uVar7) = 0x2e;
    return (long)param_1 + (long)param_2 + 1;
  }
  if ((param_4 < (int)uVar5) && ((int)uVar5 < 1)) {
    uVar7 = (ulong)-uVar5;
    memmove((void *)((long)param_1 + uVar7 + 2),param_1,(long)param_2);
    *param_1 = 0x2e30;
    memset(param_1 + 1,0x30,uVar7);
    return uVar7 + (long)param_2 + 2 + (long)param_1;
  }
  lVar6 = 1;
  if (param_2 != 1) {
    memmove(param_1 + 1,(void *)((long)param_1 + 1),(long)param_2 - 1);
    *(undefined1 *)((long)param_1 + 1) = 0x2e;
    lVar6 = (long)param_2 + 1;
  }
  *(undefined1 *)((long)param_1 + lVar6) = 0x65;
  uVar3 = 1 - uVar5;
  if (0 < (int)uVar5) {
    uVar3 = uVar5 - 1;
  }
  *(char *)((long)param_1 + lVar6 + 1) = ((int)uVar5 < 1) * '\x02' + '+';
  if (uVar3 < 10) {
    *(undefined1 *)((long)param_1 + lVar6 + 2) = 0x30;
    bVar2 = (char)uVar3 + 0x30;
  }
  else {
    if (99 < uVar3) {
      *(char *)((long)param_1 + lVar6 + 2) = (char)(uVar3 / 100) + '0';
      bVar2 = (byte)((uVar3 % 100) / 10);
      *(byte *)((long)param_1 + lVar6 + 3) = bVar2 | 0x30;
      *(byte *)((long)param_1 + lVar6 + 4) = (char)(uVar3 % 100) + bVar2 * -10 | 0x30;
      lVar4 = 2;
      goto LAB_0011b5ef;
    }
    cVar1 = (char)((uVar3 & 0xff) / 10);
    *(char *)((long)param_1 + lVar6 + 2) = cVar1 + '0';
    bVar2 = (char)uVar3 + cVar1 * -10 | 0x30;
  }
  *(byte *)((long)param_1 + lVar6 + 3) = bVar2;
  lVar4 = 1;
LAB_0011b5ef:
  return (long)param_1 + lVar4 + lVar6 + 3;
}


// ==== FUN_0011b600 @ 0011b600

void FUN_0011b600(long param_1,int *param_2,int *param_3,long param_4,undefined8 param_5,
                 undefined8 param_6,long param_7,undefined8 param_8,ulong param_9,char param_10)

{
  char *pcVar1;
  int iVar2;
  ulong uVar3;
  ulong uVar4;
  byte bVar5;
  ulong uVar6;
  int iVar7;
  ulong uVar8;
  uint uVar9;
  ulong uVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  ulong uVar14;
  ulong uVar15;
  ulong uVar16;
  bool bVar17;
  
  bVar5 = -param_10;
  uVar3 = 1L << (bVar5 & 0x3f);
  uVar10 = param_9 >> (bVar5 & 0x3f);
  uVar9 = (uint)uVar10;
  if (uVar9 < 1000000000) {
    if (uVar9 < 100000000) {
      if (uVar9 < 10000000) {
        if (uVar9 < 1000000) {
          if (uVar9 < 100000) {
            if (uVar9 < 10000) {
              if (uVar9 < 1000) {
                if (uVar9 < 100) {
                  uVar12 = (ulong)((uint)(9 < uVar9) * 9 + 1);
                  iVar7 = (9 < uVar9) + 1;
                }
                else {
                  iVar7 = 3;
                  uVar12 = 100;
                }
              }
              else {
                iVar7 = 4;
                uVar12 = 1000;
              }
            }
            else {
              iVar7 = 5;
              uVar12 = 10000;
            }
          }
          else {
            iVar7 = 6;
            uVar12 = 100000;
          }
        }
        else {
          iVar7 = 7;
          uVar12 = 1000000;
        }
      }
      else {
        iVar7 = 8;
        uVar12 = 10000000;
      }
    }
    else {
      iVar7 = 9;
      uVar12 = 100000000;
    }
  }
  else {
    iVar7 = 10;
    uVar12 = 1000000000;
  }
  uVar16 = param_9 - param_4;
  uVar14 = param_9 - param_7;
  uVar15 = uVar3 - 1 & param_9;
  do {
    if (iVar7 < 1) {
      iVar7 = 0;
      do {
        uVar13 = uVar16;
        uVar12 = uVar14;
        uVar10 = uVar15 * 10;
        uVar15 = uVar10 & uVar3 - 1;
        iVar2 = *param_2;
        *param_2 = iVar2 + 1;
        *(char *)(param_1 + iVar2) = (char)(uVar10 >> (bVar5 & 0x3f)) + '0';
        uVar16 = uVar13 * 10;
        uVar14 = uVar12 * 10;
        iVar7 = iVar7 + -1;
      } while (uVar16 < uVar15);
      *param_3 = *param_3 + iVar7;
      if ((uVar15 < uVar14) && (uVar3 <= uVar16 - uVar15)) {
        iVar7 = *param_2;
        uVar10 = uVar12 * 10 - uVar15;
        uVar15 = uVar15 + uVar3;
        uVar16 = uVar13 * 10 - uVar15;
        do {
          if ((uVar14 <= uVar15) && (uVar10 <= uVar12 * -10 + uVar15)) {
            return;
          }
          pcVar1 = (char *)(param_1 + -1 + (long)iVar7);
          *pcVar1 = *pcVar1 + -1;
          bVar17 = uVar3 <= uVar16;
          uVar16 = uVar16 - uVar3;
          if (uVar14 <= uVar15) {
            return;
          }
          uVar10 = uVar10 - uVar3;
          uVar15 = uVar15 + uVar3;
        } while (bVar17);
      }
      return;
    }
    uVar13 = uVar10 & 0xffffffff;
    uVar10 = uVar13 % uVar12;
    iVar2 = *param_2;
    *param_2 = iVar2 + 1;
    *(char *)(param_1 + iVar2) = (char)(uVar13 / uVar12) + '0';
    iVar7 = iVar7 + -1;
    uVar13 = (uVar10 << (bVar5 & 0x3f)) + uVar15;
    if (uVar16 < uVar13) {
      uVar12 = uVar12 / 10;
    }
    else {
      *param_3 = *param_3 + iVar7;
      uVar11 = uVar12 << (bVar5 & 0x3f);
      if (uVar14 <= uVar13) {
        return;
      }
      if (uVar16 - uVar13 < uVar11) {
        return;
      }
      iVar2 = *param_2;
      uVar4 = (param_9 - param_7) - uVar13;
      uVar8 = uVar13 + uVar11;
      uVar6 = (param_9 - param_4) - uVar8;
      do {
        if ((uVar14 <= uVar8) && (uVar4 <= (param_7 - param_9) + uVar8)) break;
        pcVar1 = (char *)(param_1 + -1 + (long)iVar2);
        *pcVar1 = *pcVar1 + -1;
        bVar17 = uVar11 <= uVar6;
        uVar6 = uVar6 - uVar11;
        if (uVar14 <= uVar8) break;
        uVar4 = uVar4 - uVar11;
        uVar8 = uVar8 + uVar11;
      } while (bVar17);
    }
    if (uVar13 <= uVar16) {
      return;
    }
  } while( true );
}


// ==== FUN_0011b910 @ 0011b910

void FUN_0011b910(undefined8 *param_1,undefined8 *param_2)

{
  ulong uVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  long lVar10;
  long lVar11;
  size_t __n;
  ulong uVar12;
  void *__dest;
  void *__src;
  
  puVar2 = (undefined8 *)param_1[1];
  if (puVar2 < (undefined8 *)param_1[2]) {
    uVar3 = param_2[9];
    puVar2[8] = param_2[8];
    puVar2[9] = uVar3;
    uVar3 = *param_2;
    uVar4 = param_2[1];
    uVar5 = param_2[2];
    uVar6 = param_2[3];
    uVar7 = param_2[4];
    uVar8 = param_2[5];
    uVar9 = param_2[7];
    puVar2[6] = param_2[6];
    puVar2[7] = uVar9;
    puVar2[4] = uVar7;
    puVar2[5] = uVar8;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    *puVar2 = uVar3;
    puVar2[1] = uVar4;
    param_1[1] = puVar2 + 10;
  }
  else {
    __src = (void *)*param_1;
    __n = (long)puVar2 - (long)__src;
    uVar1 = ((long)__n >> 4) * -0x3333333333333333 + 1;
    if (0x333333333333333 < uVar1) {
      FUN_00120270(param_1);
LAB_0011ba98:
                    /* WARNING: Subroutine does not return */
      FUN_00118290("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
    }
    lVar10 = (long)param_1[2] - (long)__src >> 4;
    uVar12 = lVar10 * -0x6666666666666666;
    if (uVar12 < uVar1) {
      uVar12 = uVar1;
    }
    if (0x199999999999998 < (ulong)(lVar10 * -0x3333333333333333)) {
      uVar12 = 0x333333333333333;
    }
    if (uVar12 == 0) {
      lVar10 = 0;
    }
    else {
      if (0x333333333333333 < uVar12) goto LAB_0011ba98;
      lVar10 = FUN_0011e900(uVar12 * 0x50);
    }
    lVar11 = ((long)__n >> 4) * 0x10;
    uVar3 = param_2[9];
    puVar2 = (undefined8 *)(lVar10 + 0x40 + lVar11);
    *puVar2 = param_2[8];
    puVar2[1] = uVar3;
    uVar3 = *param_2;
    uVar4 = param_2[1];
    uVar5 = param_2[2];
    uVar6 = param_2[3];
    uVar7 = param_2[4];
    uVar8 = param_2[5];
    uVar9 = param_2[7];
    puVar2 = (undefined8 *)(lVar10 + 0x30 + lVar11);
    *puVar2 = param_2[6];
    puVar2[1] = uVar9;
    puVar2 = (undefined8 *)(lVar10 + 0x20 + lVar11);
    *puVar2 = uVar7;
    puVar2[1] = uVar8;
    puVar2 = (undefined8 *)(lVar10 + 0x10 + lVar11);
    *puVar2 = uVar5;
    puVar2[1] = uVar6;
    *(undefined8 *)(lVar10 + lVar11) = uVar3;
    ((undefined8 *)(lVar10 + lVar11))[1] = uVar4;
    __dest = (void *)((lVar10 + lVar11) - __n);
    if (0 < (long)__n) {
      memcpy(__dest,__src,__n);
      __src = (void *)*param_1;
    }
    *param_1 = __dest;
    param_1[1] = lVar10 + lVar11 + 0x50;
    param_1[2] = uVar12 * 0x50 + lVar10;
    if (__src != (void *)0x0) {
      free(__src);
      return;
    }
  }
  return;
}


// ==== _INIT_0 @ 0011bab0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _INIT_0(void)

{
  DAT_00144ec0 = 1000;
  _DAT_00144ec8 = 0;
  uRam0000000000144ed0 = 0;
  _DAT_00144ed8 = 0;
  uRam0000000000144ee0 = 0;
  _DAT_00144ee8 = 0;
  uRam0000000000144ef0 = 0;
  _DAT_00144ef8 = 0;
  uRam0000000000144f00 = 0;
  _DAT_00144f08 = 0;
  uRam0000000000144f10 = 0;
  _DAT_00144f18 = 0;
  DAT_00144f20 = 0;
  DAT_00144f28 = 0;
  _DAT_00144f30 = 0;
                    /* try { // try from 0011baf0 to 0011baf9 has its CatchHandler @ 0011bb34 */
  DAT_00144f20 = FUN_0011e900(80000);
  _DAT_00144f30 = DAT_00144f20 + 80000;
  DAT_00144f28 = DAT_00144f20;
  __cxa_atexit(&LAB_00116050,&DAT_00144ec0,&PTR_LOOP_0013e320);
  return;
}


// ==== thunk_FUN_0011bba0 @ 0011bb60

undefined8 thunk_FUN_0011bba0(char *param_1,char *param_2,long param_3,undefined8 param_4)

{
  int iVar1;
  undefined8 *__ptr;
  char *pcVar2;
  undefined8 uVar3;
  long in_FS_OFFSET;
  uchar *puStack_50;
  ulong uStack_48;
  ulong uStack_40;
  reg_syntax_t rStack_38;
  char *pcStack_30;
  
  pcStack_30 = *(char **)(in_FS_OFFSET + 0x28);
  uVar3 = 0x3ea;
  if (((param_1 != (char *)0x0) && (param_2 != (char *)0x0)) && (param_3 != 0)) {
    if (DAT_00144f50 == 0) {
      iVar1 = regcomp((regex_t *)&puStack_50,param_1,4);
      if (iVar1 == 0) {
        __ptr = malloc(0x48);
        uVar3 = 0x3eb;
        if (__ptr != (undefined8 *)0x0) {
          pcVar2 = strdup(param_2);
          __ptr[4] = pcVar2;
          if (pcVar2 == (char *)0x0) {
            free(__ptr);
          }
          else {
            __ptr[2] = uStack_40;
            __ptr[3] = rStack_38;
            *__ptr = puStack_50;
            __ptr[1] = uStack_48;
            __ptr[5] = param_3;
            __ptr[6] = param_4;
            pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
            __ptr[7] = 0;
            __ptr[8] = PTR_DAT_00144e50;
            *(undefined8 **)PTR_DAT_00144e50 = __ptr;
            PTR_DAT_00144e50 = (undefined *)(__ptr + 7);
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
            uVar3 = 0;
          }
        }
      }
    }
    else if (DAT_00144e6c < 7) {
      __android_log_print(6,"xhook","do not register hook after refresh(): %s, %s",param_1,param_2);
    }
  }
  if (*(char **)(in_FS_OFFSET + 0x28) != pcStack_30) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar3;
}


// ==== thunk_FUN_0011bcf0 @ 0011bb70

undefined8 thunk_FUN_0011bcf0(int param_1)

{
  int iVar1;
  pthread_mutex_t *__mutex;
  undefined8 uVar2;
  long in_FS_OFFSET;
  undefined1 auStack_38 [8];
  undefined1 *puStack_30;
  undefined1 auStack_28 [16];
  ulong uStack_18;
  
  uStack_18 = *(ulong *)(in_FS_OFFSET + 0x28);
  if (DAT_00144f50 == 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
    if (DAT_00144f50 == 0) {
      DAT_00144f50 = 1;
      if (DAT_00144e6c < 5) {
        FUN_0011e840();
        __android_log_print(4,"xhook",&DAT_0010b0c1);
      }
      if (DAT_00144e68 == 0) {
LAB_0011bd9d:
        DAT_00144f7c = 1;
      }
      else {
        iVar1 = sigemptyset((sigset_t *)auStack_28);
        if (iVar1 == 0) {
          puStack_30 = &LAB_0011c770;
          iVar1 = sigaction(0xb,(sigaction *)auStack_38,(sigaction *)&DAT_00145000);
          if (iVar1 == 0) goto LAB_0011bd9d;
        }
      }
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
  }
  uVar2 = 0x3e9;
  if (DAT_00144f7c != 0) {
    if (param_1 == 0) {
      __mutex = (pthread_mutex_t *)&DAT_00144fb8;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00144fb8);
      FUN_0011c870();
    }
    else {
      if (DAT_00144ff0 == 0) {
        pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
        if (DAT_00144ff0 == 0) {
          DAT_00144ff0 = 1;
          DAT_00144fe0 = 1;
          iVar1 = pthread_create(&DAT_00144fe8,(pthread_attr_t *)0x0,
                                 (__start_routine *)&LAB_0011c7a0,(void *)0x0);
          if (iVar1 == 0) {
            DAT_00144f80 = 1;
          }
          else {
            DAT_00144fe0 = 0;
          }
        }
        pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
      }
      if (DAT_00144f80 == 0) goto LAB_0011be86;
      __mutex = (pthread_mutex_t *)&DAT_00144f54;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
      DAT_00144f84 = 1;
      pthread_cond_signal((pthread_cond_t *)&DAT_00144f88);
    }
    pthread_mutex_unlock(__mutex);
    uVar2 = 0;
  }
LAB_0011be86:
  if (*(ulong *)(in_FS_OFFSET + 0x28) != uStack_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar2;
}


// ==== FUN_0011bb80 @ 0011bb80

void FUN_0011bb80(void)

{
  FUN_0011beb0();
  return;
}


// ==== thunk_FUN_0011c760 @ 0011bb90

void thunk_FUN_0011c760(int param_1)

{
  DAT_00144e68 = (uint)(param_1 != 0);
  return;
}


// ==== FUN_0011bba0 @ 0011bba0

undefined8 FUN_0011bba0(char *param_1,char *param_2,long param_3,undefined8 param_4)

{
  int iVar1;
  undefined8 *__ptr;
  char *pcVar2;
  undefined8 uVar3;
  long in_FS_OFFSET;
  uchar *local_50;
  ulong uStack_48;
  ulong local_40;
  reg_syntax_t rStack_38;
  char *local_30;
  
  local_30 = *(char **)(in_FS_OFFSET + 0x28);
  uVar3 = 0x3ea;
  if (((param_1 != (char *)0x0) && (param_2 != (char *)0x0)) && (param_3 != 0)) {
    if (DAT_00144f50 == 0) {
      iVar1 = regcomp((regex_t *)&local_50,param_1,4);
      if (iVar1 == 0) {
        __ptr = malloc(0x48);
        uVar3 = 0x3eb;
        if (__ptr != (undefined8 *)0x0) {
          pcVar2 = strdup(param_2);
          __ptr[4] = pcVar2;
          if (pcVar2 == (char *)0x0) {
            free(__ptr);
          }
          else {
            __ptr[2] = local_40;
            __ptr[3] = rStack_38;
            *__ptr = local_50;
            __ptr[1] = uStack_48;
            __ptr[5] = param_3;
            __ptr[6] = param_4;
            pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
            __ptr[7] = 0;
            __ptr[8] = PTR_DAT_00144e50;
            *(undefined8 **)PTR_DAT_00144e50 = __ptr;
            PTR_DAT_00144e50 = (undefined *)(__ptr + 7);
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
            uVar3 = 0;
          }
        }
      }
    }
    else if (DAT_00144e6c < 7) {
      __android_log_print(6,"xhook","do not register hook after refresh(): %s, %s",param_1,param_2);
    }
  }
  if (*(char **)(in_FS_OFFSET + 0x28) != local_30) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar3;
}


// ==== FUN_0011bcf0 @ 0011bcf0

undefined8 FUN_0011bcf0(int param_1)

{
  int iVar1;
  pthread_mutex_t *__mutex;
  undefined8 uVar2;
  long in_FS_OFFSET;
  undefined1 auStack_38 [8];
  undefined1 *local_30;
  undefined1 local_28 [16];
  ulong local_18;
  
  local_18 = *(ulong *)(in_FS_OFFSET + 0x28);
  if (DAT_00144f50 == 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
    if (DAT_00144f50 == 0) {
      DAT_00144f50 = 1;
      if (DAT_00144e6c < 5) {
        FUN_0011e840();
        __android_log_print(4,"xhook",&DAT_0010b0c1);
      }
      if (DAT_00144e68 == 0) {
LAB_0011bd9d:
        DAT_00144f7c = 1;
      }
      else {
        iVar1 = sigemptyset((sigset_t *)local_28);
        if (iVar1 == 0) {
          local_30 = &LAB_0011c770;
          iVar1 = sigaction(0xb,(sigaction *)auStack_38,(sigaction *)&DAT_00145000);
          if (iVar1 == 0) goto LAB_0011bd9d;
        }
      }
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
  }
  uVar2 = 0x3e9;
  if (DAT_00144f7c != 0) {
    if (param_1 == 0) {
      __mutex = (pthread_mutex_t *)&DAT_00144fb8;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00144fb8);
      FUN_0011c870();
    }
    else {
      if (DAT_00144ff0 == 0) {
        pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
        if (DAT_00144ff0 == 0) {
          DAT_00144ff0 = 1;
          DAT_00144fe0 = 1;
          iVar1 = pthread_create(&DAT_00144fe8,(pthread_attr_t *)0x0,
                                 (__start_routine *)&LAB_0011c7a0,(void *)0x0);
          if (iVar1 == 0) {
            DAT_00144f80 = 1;
          }
          else {
            DAT_00144fe0 = 0;
          }
        }
        pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
      }
      if (DAT_00144f80 == 0) goto LAB_0011be86;
      __mutex = (pthread_mutex_t *)&DAT_00144f54;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
      DAT_00144f84 = 1;
      pthread_cond_signal((pthread_cond_t *)&DAT_00144f88);
    }
    pthread_mutex_unlock(__mutex);
    uVar2 = 0;
  }
LAB_0011be86:
  if (*(ulong *)(in_FS_OFFSET + 0x28) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar2;
}


// ==== FUN_0011beb0 @ 0011beb0

void FUN_0011beb0(void)

{
  regex_t *prVar1;
  regex_t *prVar2;
  long *plVar3;
  undefined8 *puVar4;
  undefined8 *__ptr;
  undefined8 *puVar5;
  
  if (DAT_00144f80 != 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
    DAT_00144fe0 = 0;
    pthread_cond_signal((pthread_cond_t *)&DAT_00144f88);
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
    pthread_join(DAT_00144fe8,(void **)0x0);
    DAT_00144f80 = 0;
  }
  DAT_00144ff0 = 0;
  if (DAT_00144f7c != 0) {
    if (DAT_00144e68 != 0) {
      sigaction(0xb,(sigaction *)&DAT_00145000,(sigaction *)0x0);
    }
    DAT_00144f7c = 0;
  }
  DAT_00144f50 = 0;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00144f54);
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00144fb8);
  plVar3 = &DAT_00144ff8;
  puVar4 = (undefined8 *)0x0;
  do {
    __ptr = puVar4;
    puVar4 = (undefined8 *)*plVar3;
    plVar3 = puVar4 + 0x18;
  } while (puVar4 != (undefined8 *)0x0);
  do {
    if (__ptr == (undefined8 *)0x0) {
      prVar2 = DAT_00144e48;
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = *(regex_t **)&prVar2->field_0x38;
        plVar3 = (long *)prVar2[1].buffer;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_00144e50 = (undefined *)plVar3;
        }
        else {
          prVar1[1].buffer = (uchar *)plVar3;
          plVar3 = (long *)prVar2[1].buffer;
        }
        *plVar3 = (long)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      prVar2 = DAT_00144e58;
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = (regex_t *)prVar2->translate;
        plVar3 = (long *)prVar2->re_nsub;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_00144e60 = (undefined *)plVar3;
        }
        else {
          prVar1->re_nsub = (size_t)plVar3;
          plVar3 = (long *)prVar2->re_nsub;
        }
        *plVar3 = (long)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144fb8);
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00144f54);
      return;
    }
    puVar4 = (undefined8 *)__ptr[0x19];
    if ((undefined8 *)__ptr[0x19] == (undefined8 *)0x0) {
      puVar5 = (undefined8 *)__ptr[0x1a];
      if (puVar5 != (undefined8 *)0x0) {
        if ((undefined8 *)puVar5[0x18] == __ptr) goto LAB_0011c04d;
        puVar4 = __ptr;
        do {
          if (puVar4 != (undefined8 *)puVar5[0x19]) goto LAB_0011c04d;
          plVar3 = puVar5 + 0x1a;
          puVar4 = puVar5;
          puVar5 = (undefined8 *)*plVar3;
        } while ((undefined8 *)*plVar3 != (undefined8 *)0x0);
      }
      puVar5 = (undefined8 *)0x0;
    }
    else {
      do {
        puVar5 = puVar4;
        puVar4 = (undefined8 *)puVar5[0x18];
      } while ((undefined8 *)puVar5[0x18] != (undefined8 *)0x0);
    }
LAB_0011c04d:
    FUN_0011c110(__ptr);
    if ((void *)*__ptr != (void *)0x0) {
      free((void *)*__ptr);
    }
    free(__ptr);
    __ptr = puVar5;
  } while( true );
}


// ==== FUN_0011c110 @ 0011c110

void FUN_0011c110(long param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long lVar5;
  long *plVar6;
  long lVar7;
  long lVar8;
  long lVar9;
  long lVar10;
  
  lVar5 = *(long *)(param_1 + 0xc0);
  lVar7 = *(long *)(param_1 + 200);
  if (lVar5 == 0) {
    lVar8 = *(long *)(param_1 + 0xd0);
    iVar1 = *(int *)(param_1 + 0xd8);
    if (lVar7 == 0) {
      lVar5 = 0;
    }
    else {
      *(long *)(lVar7 + 0xd0) = lVar8;
      lVar5 = lVar7;
    }
  }
  else {
    if (lVar7 != 0) {
      do {
        lVar10 = lVar7;
        lVar7 = *(long *)(lVar10 + 0xc0);
      } while (*(long *)(lVar10 + 0xc0) != 0);
      lVar5 = *(long *)(lVar10 + 200);
      lVar8 = *(long *)(lVar10 + 0xd0);
      iVar1 = *(int *)(lVar10 + 0xd8);
      if (lVar5 != 0) {
        *(long *)(lVar5 + 0xd0) = lVar8;
      }
      plVar6 = &DAT_00144ff8;
      if (lVar8 != 0) {
        plVar6 = (long *)(lVar8 + 200);
        if (*(long *)(lVar8 + 0xc0) == lVar10) {
          plVar6 = (long *)(lVar8 + 0xc0);
        }
      }
      *plVar6 = lVar5;
      if (*(long *)(lVar10 + 0xd0) == param_1) {
        lVar8 = lVar10;
      }
      uVar2 = *(undefined8 *)(param_1 + 0xc0);
      uVar3 = *(undefined8 *)(param_1 + 200);
      uVar4 = *(undefined8 *)(param_1 + 0xd8);
      *(undefined8 *)(lVar10 + 0xd0) = *(undefined8 *)(param_1 + 0xd0);
      *(undefined8 *)(lVar10 + 0xd8) = uVar4;
      *(undefined8 *)(lVar10 + 0xc0) = uVar2;
      *(undefined8 *)(lVar10 + 200) = uVar3;
      lVar7 = *(long *)(param_1 + 0xd0);
      plVar6 = &DAT_00144ff8;
      if (lVar7 != 0) {
        plVar6 = (long *)(lVar7 + 200);
        if (*(long *)(lVar7 + 0xc0) == param_1) {
          plVar6 = (long *)(lVar7 + 0xc0);
        }
      }
      *plVar6 = lVar10;
      *(long *)(*(long *)(param_1 + 0xc0) + 0xd0) = lVar10;
      lVar7 = DAT_00144ff8;
      if (*(long *)(param_1 + 200) != 0) {
        *(long *)(*(long *)(param_1 + 200) + 0xd0) = lVar10;
        lVar7 = DAT_00144ff8;
      }
      goto joined_r0x0011c26c;
    }
    lVar8 = *(long *)(param_1 + 0xd0);
    iVar1 = *(int *)(param_1 + 0xd8);
    *(long *)(lVar5 + 0xd0) = lVar8;
  }
  if (lVar8 == 0) {
    lVar8 = 0;
    lVar7 = lVar5;
  }
  else {
    plVar6 = (long *)(lVar8 + 200);
    if (*(long *)(lVar8 + 0xc0) == param_1) {
      plVar6 = (long *)(lVar8 + 0xc0);
    }
    *plVar6 = lVar5;
    lVar7 = DAT_00144ff8;
  }
joined_r0x0011c26c:
  if (iVar1 != 0) {
    DAT_00144ff8 = lVar7;
    return;
  }
  DAT_00144ff8 = lVar7;
  do {
    if (lVar5 == 0) {
      if (lVar7 == 0) {
        return;
      }
    }
    else if ((*(int *)(lVar5 + 0xd8) != 0) || (lVar5 == lVar7)) goto LAB_0011c750;
    lVar10 = *(long *)(lVar8 + 0xc0);
    if (lVar10 == lVar5) {
      lVar5 = *(long *)(lVar8 + 200);
      lVar9 = lVar5;
      if (*(int *)(lVar5 + 0xd8) == 1) {
        *(undefined4 *)(lVar5 + 0xd8) = 0;
        *(undefined4 *)(lVar8 + 0xd8) = 1;
        lVar9 = *(long *)(lVar5 + 0xc0);
        *(long *)(lVar8 + 200) = lVar9;
        if (lVar9 != 0) {
          *(long *)(lVar9 + 0xd0) = lVar8;
        }
        lVar10 = *(long *)(lVar8 + 0xd0);
        *(long *)(lVar5 + 0xd0) = lVar10;
        if (lVar10 == 0) {
          lVar7 = lVar5;
          DAT_00144ff8 = lVar5;
        }
        else {
          lVar10 = *(long *)(lVar8 + 0xd0);
          if (lVar8 == *(long *)(lVar10 + 0xc0)) {
            *(long *)(lVar10 + 0xc0) = lVar5;
          }
          else {
            *(long *)(lVar10 + 200) = lVar5;
            lVar9 = *(long *)(lVar8 + 200);
          }
        }
        *(long *)(lVar5 + 0xc0) = lVar8;
        *(long *)(lVar8 + 0xd0) = lVar5;
      }
      lVar5 = *(long *)(lVar9 + 0xc0);
      if ((lVar5 != 0) && (*(int *)(lVar5 + 0xd8) != 0)) {
        lVar10 = *(long *)(lVar9 + 200);
        if ((lVar10 == 0) || (*(int *)(lVar10 + 0xd8) == 0)) {
          *(undefined4 *)(lVar5 + 0xd8) = 0;
          *(undefined4 *)(lVar9 + 0xd8) = 1;
          lVar10 = *(long *)(lVar5 + 200);
          *(long *)(lVar9 + 0xc0) = lVar10;
          if (lVar10 != 0) {
            *(long *)(lVar10 + 0xd0) = lVar9;
          }
          lVar10 = *(long *)(lVar9 + 0xd0);
          *(long *)(lVar5 + 0xd0) = lVar10;
          if (lVar10 == 0) {
            lVar7 = lVar5;
            plVar6 = &DAT_00144ff8;
          }
          else {
            lVar10 = *(long *)(lVar9 + 0xd0);
            plVar6 = (long *)(lVar10 + 200);
            if (lVar9 == *(long *)(lVar10 + 0xc0)) {
              plVar6 = (long *)(lVar10 + 0xc0);
            }
          }
          *plVar6 = lVar5;
          *(long *)(lVar5 + 200) = lVar9;
          *(long *)(lVar9 + 0xd0) = lVar5;
          lVar9 = *(long *)(lVar8 + 200);
          lVar10 = *(long *)(lVar9 + 200);
          *(undefined4 *)(lVar9 + 0xd8) = *(undefined4 *)(lVar8 + 0xd8);
          *(undefined4 *)(lVar8 + 0xd8) = 0;
          if (lVar10 != 0) goto LAB_0011c6d0;
        }
        else {
LAB_0011c4ea:
          *(undefined4 *)(lVar9 + 0xd8) = *(undefined4 *)(lVar8 + 0xd8);
          *(undefined4 *)(lVar8 + 0xd8) = 0;
LAB_0011c6d0:
          *(undefined4 *)(lVar10 + 0xd8) = 0;
        }
        lVar5 = *(long *)(lVar9 + 0xc0);
        *(long *)(lVar8 + 200) = lVar5;
        if (lVar5 != 0) {
          *(long *)(lVar5 + 0xd0) = lVar8;
        }
        lVar5 = *(long *)(lVar8 + 0xd0);
        *(long *)(lVar9 + 0xd0) = lVar5;
        if (lVar5 == 0) {
          lVar7 = lVar9;
          plVar6 = &DAT_00144ff8;
        }
        else {
          lVar5 = *(long *)(lVar8 + 0xd0);
          plVar6 = (long *)(lVar5 + 200);
          if (lVar8 == *(long *)(lVar5 + 0xc0)) {
            plVar6 = (long *)(lVar5 + 0xc0);
          }
        }
        *plVar6 = lVar9;
        *(long *)(lVar9 + 0xc0) = lVar8;
        goto LAB_0011c73d;
      }
      lVar10 = *(long *)(lVar9 + 200);
      if ((lVar10 != 0) && (*(int *)(lVar10 + 0xd8) != 0)) goto LAB_0011c4ea;
    }
    else {
      lVar9 = lVar10;
      if (*(int *)(lVar10 + 0xd8) == 1) {
        *(undefined4 *)(lVar10 + 0xd8) = 0;
        *(undefined4 *)(lVar8 + 0xd8) = 1;
        lVar9 = *(long *)(lVar10 + 200);
        *(long *)(lVar8 + 0xc0) = lVar9;
        if (lVar9 != 0) {
          *(long *)(lVar9 + 0xd0) = lVar8;
        }
        lVar5 = *(long *)(lVar8 + 0xd0);
        *(long *)(lVar10 + 0xd0) = lVar5;
        if (lVar5 == 0) {
          lVar7 = lVar10;
          DAT_00144ff8 = lVar10;
        }
        else {
          lVar5 = *(long *)(lVar8 + 0xd0);
          if (lVar8 == *(long *)(lVar5 + 0xc0)) {
            *(long *)(lVar5 + 0xc0) = lVar10;
            lVar9 = *(long *)(lVar8 + 0xc0);
          }
          else {
            *(long *)(lVar5 + 200) = lVar10;
          }
        }
        *(long *)(lVar10 + 200) = lVar8;
        *(long *)(lVar8 + 0xd0) = lVar10;
      }
      lVar5 = *(long *)(lVar9 + 0xc0);
      if ((lVar5 != 0) && (*(int *)(lVar5 + 0xd8) != 0)) goto LAB_0011c4b2;
      lVar10 = *(long *)(lVar9 + 200);
      if ((lVar10 != 0) && (*(int *)(lVar10 + 0xd8) != 0)) break;
    }
    *(undefined4 *)(lVar9 + 0xd8) = 1;
    lVar5 = lVar8;
    lVar8 = *(long *)(lVar8 + 0xd0);
  } while( true );
  if ((lVar5 == 0) || (*(int *)(lVar5 + 0xd8) == 0)) {
    *(undefined4 *)(lVar10 + 0xd8) = 0;
    *(undefined4 *)(lVar9 + 0xd8) = 1;
    lVar5 = *(long *)(lVar10 + 0xc0);
    *(long *)(lVar9 + 200) = lVar5;
    if (lVar5 != 0) {
      *(long *)(lVar5 + 0xd0) = lVar9;
    }
    lVar5 = *(long *)(lVar9 + 0xd0);
    *(long *)(lVar10 + 0xd0) = lVar5;
    if (lVar5 == 0) {
      lVar7 = lVar10;
      plVar6 = &DAT_00144ff8;
    }
    else {
      lVar5 = *(long *)(lVar9 + 0xd0);
      plVar6 = (long *)(lVar5 + 200);
      if (lVar9 == *(long *)(lVar5 + 0xc0)) {
        plVar6 = (long *)(lVar5 + 0xc0);
      }
    }
    *plVar6 = lVar10;
    *(long *)(lVar10 + 0xc0) = lVar9;
    *(long *)(lVar9 + 0xd0) = lVar10;
    lVar9 = *(long *)(lVar8 + 0xc0);
    lVar5 = *(long *)(lVar9 + 0xc0);
    *(undefined4 *)(lVar9 + 0xd8) = *(undefined4 *)(lVar8 + 0xd8);
    *(undefined4 *)(lVar8 + 0xd8) = 0;
    if (lVar5 == 0) goto LAB_0011c624;
  }
  else {
LAB_0011c4b2:
    *(undefined4 *)(lVar9 + 0xd8) = *(undefined4 *)(lVar8 + 0xd8);
    *(undefined4 *)(lVar8 + 0xd8) = 0;
  }
  *(undefined4 *)(lVar5 + 0xd8) = 0;
LAB_0011c624:
  lVar5 = *(long *)(lVar9 + 200);
  *(long *)(lVar8 + 0xc0) = lVar5;
  if (lVar5 != 0) {
    *(long *)(lVar5 + 0xd0) = lVar8;
  }
  lVar5 = *(long *)(lVar8 + 0xd0);
  *(long *)(lVar9 + 0xd0) = lVar5;
  if (lVar5 == 0) {
    lVar7 = lVar9;
    plVar6 = &DAT_00144ff8;
  }
  else {
    lVar5 = *(long *)(lVar8 + 0xd0);
    plVar6 = (long *)(lVar5 + 200);
    if (lVar8 == *(long *)(lVar5 + 0xc0)) {
      plVar6 = (long *)(lVar5 + 0xc0);
    }
  }
  *plVar6 = lVar9;
  *(long *)(lVar9 + 200) = lVar8;
LAB_0011c73d:
  *(long *)(lVar8 + 0xd0) = lVar9;
  lVar5 = lVar7;
  if (lVar7 == 0) {
    return;
  }
LAB_0011c750:
  *(undefined4 *)(lVar5 + 0xd8) = 0;
  return;
}


// ==== FUN_0011c760 @ 0011c760

void FUN_0011c760(int param_1)

{
  DAT_00144e68 = (uint)(param_1 != 0);
  return;
}


// ==== FUN_0011c870 @ 0011c870

void FUN_0011c870(void)

{
  bool bVar1;
  regex_t *__preg;
  int iVar2;
  FILE *__stream;
  char *pcVar3;
  long lVar4;
  long lVar5;
  size_t sVar6;
  undefined8 *puVar7;
  long *plVar8;
  undefined8 *__ptr;
  undefined8 *puVar9;
  regex_t *__preg_00;
  undefined8 uVar10;
  long in_FS_OFFSET;
  undefined8 *local_260;
  int local_254;
  ulong local_250;
  ulong local_248;
  char local_23d [3];
  char local_23a;
  char acStack_239 [513];
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  local_260 = (undefined8 *)0x0;
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    if (6 < DAT_00144e6c) goto LAB_0011cbe9;
    pcVar3 = "fopen /proc/self/maps failed";
    uVar10 = 6;
  }
  else {
    pcVar3 = fgets(acStack_239 + 1,0x200,__stream);
    if (pcVar3 != (char *)0x0) {
LAB_0011c939:
      iVar2 = sscanf(acStack_239 + 1,"%lx-%*lx %4s %lx %*x:%*x %*d%n",&local_248,local_23d,
                     &local_250,&local_254);
      if ((((iVar2 == 3) && (local_23d[0] == 'r')) && (local_23a == 'p')) && (local_250 == 0)) {
        lVar4 = (long)local_254;
        if ((acStack_239[lVar4 + 1] == 0x20 || (int)acStack_239[lVar4 + 1] - 9U < 5) &&
           (lVar5 = lVar4, local_254 < 0x1ff)) {
          do {
            lVar4 = lVar5 + 1;
            if (acStack_239[lVar5 + 2] != 0x20 && 4 < (int)acStack_239[lVar5 + 2] - 9U) break;
            bVar1 = lVar5 < 0x1fe;
            lVar5 = lVar4;
          } while (bVar1);
          local_254 = (int)lVar4;
        }
        if (local_254 < 0x1ff) {
          pcVar3 = acStack_239 + lVar4 + 1;
          sVar6 = strlen(pcVar3);
          if (((sVar6 != 0) &&
              ((acStack_239[sVar6 + lVar4] != '\n' || (pcVar3[sVar6 - 1] = '\0', sVar6 - 1 != 0))))
             && (__preg = DAT_00144e48, *pcVar3 != '[')) {
            for (; __preg != (regex_t *)0x0; __preg = *(regex_t **)&__preg->field_0x38) {
              iVar2 = regexec(__preg,pcVar3,0,(regmatch_t *)0x0,0);
              if (iVar2 == 0) {
                __preg_00 = DAT_00144e58;
                goto LAB_0011ca74;
              }
            }
          }
        }
      }
      goto LAB_0011c920;
    }
LAB_0011cb86:
    fclose(__stream);
    plVar8 = (long *)&DAT_00144ff8;
    puVar7 = (undefined8 *)0x0;
    do {
      __ptr = puVar7;
      puVar7 = (undefined8 *)*plVar8;
      plVar8 = puVar7 + 0x18;
    } while (puVar7 != (undefined8 *)0x0);
    while (__ptr != (undefined8 *)0x0) {
      puVar7 = (undefined8 *)__ptr[0x19];
      if ((undefined8 *)__ptr[0x19] == (undefined8 *)0x0) {
        puVar9 = (undefined8 *)__ptr[0x1a];
        if (puVar9 != (undefined8 *)0x0) {
          if ((undefined8 *)puVar9[0x18] == __ptr) goto LAB_0011cc9d;
          puVar7 = __ptr;
          do {
            if (puVar7 != (undefined8 *)puVar9[0x19]) goto LAB_0011cc9d;
            plVar8 = puVar9 + 0x1a;
            puVar7 = puVar9;
            puVar9 = (undefined8 *)*plVar8;
          } while ((undefined8 *)*plVar8 != (undefined8 *)0x0);
        }
        puVar9 = (undefined8 *)0x0;
      }
      else {
        do {
          puVar9 = puVar7;
          puVar7 = (undefined8 *)puVar9[0x18];
        } while ((undefined8 *)puVar9[0x18] != (undefined8 *)0x0);
      }
LAB_0011cc9d:
      FUN_0011c110(__ptr);
      if ((void *)*__ptr != (void *)0x0) {
        free((void *)*__ptr);
      }
      free(__ptr);
      __ptr = puVar9;
    }
    DAT_00144ff8 = local_260;
    if (4 < DAT_00144e6c) goto LAB_0011cbe9;
    pcVar3 = "map refreshed";
    uVar10 = 4;
  }
  __android_log_print(uVar10,"xhook",pcVar3);
LAB_0011cbe9:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
LAB_0011ca74:
  if (__preg_00 == (regex_t *)0x0) goto LAB_0011c907;
  iVar2 = regexec(__preg_00,pcVar3,0,(regmatch_t *)0x0,0);
  if ((iVar2 == 0) &&
     ((__preg_00->fastmap == (char *)0x0 ||
      (iVar2 = strcmp(__preg_00->fastmap,__preg->fastmap), iVar2 == 0)))) goto LAB_0011c920;
  __preg_00 = (regex_t *)__preg_00->translate;
  goto LAB_0011ca74;
LAB_0011c907:
  iVar2 = FUN_0011ccd0(local_248,pcVar3);
  puVar7 = DAT_00144ff8;
  if (iVar2 == 0) {
    for (; puVar7 != (undefined8 *)0x0; puVar7 = (undefined8 *)puVar7[0x18]) {
      while( true ) {
        iVar2 = strcmp(pcVar3,(char *)*puVar7);
        if (iVar2 < 0) break;
        if (iVar2 == 0) {
          FUN_0011c110(puVar7);
          lVar4 = FUN_0011cd60(&local_260,puVar7);
          if (lVar4 != 0) goto LAB_0011cb50;
          if (puVar7[1] == local_248) goto LAB_0011c920;
          puVar7[1] = local_248;
          goto LAB_0011cb79;
        }
        puVar7 = (undefined8 *)puVar7[0x19];
        if (puVar7 == (undefined8 *)0x0) goto LAB_0011caf2;
      }
    }
LAB_0011caf2:
    puVar7 = malloc(0xe0);
    if (puVar7 != (undefined8 *)0x0) {
      pcVar3 = strdup(pcVar3);
      *puVar7 = pcVar3;
      if (pcVar3 != (char *)0x0) {
        puVar7[1] = local_248;
        lVar4 = FUN_0011cd60(&local_260,puVar7);
        if (lVar4 == 0) {
LAB_0011cb79:
          FUN_0011d0e0(puVar7);
          goto LAB_0011c920;
        }
LAB_0011cb50:
        free((void *)*puVar7);
      }
      free(puVar7);
    }
  }
LAB_0011c920:
  pcVar3 = fgets(acStack_239 + 1,0x200,__stream);
  if (pcVar3 == (char *)0x0) goto LAB_0011cb86;
  goto LAB_0011c939;
}


// ==== FUN_0011ccd0 @ 0011ccd0

ulong FUN_0011ccd0(undefined8 param_1,undefined8 param_2)

{
  int iVar1;
  uint uVar2;
  ulong uVar3;
  
  if (DAT_00144e68 == 0) {
    uVar3 = FUN_0011d220(param_1);
    return uVar3;
  }
  DAT_00145020 = 1;
  iVar1 = sigsetjmp(&DAT_00145030,1);
  if (iVar1 == 0) {
    uVar2 = FUN_0011d220(param_1);
    uVar3 = (ulong)uVar2;
  }
  else {
    uVar3 = 0x3f1;
    if (DAT_00144e6c < 6) {
      __android_log_print(5,"xhook","catch SIGSEGV when check_elfheader: %s",param_2);
    }
  }
  DAT_00145020 = 0;
  return uVar3;
}


// ==== FUN_0011cd60 @ 0011cd60

undefined8 * FUN_0011cd60(long *param_1,undefined8 *param_2)

{
  char *__s1;
  undefined8 *puVar1;
  long lVar2;
  long lVar3;
  int iVar4;
  undefined8 *puVar5;
  long *plVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  
  if ((undefined8 *)*param_1 == (undefined8 *)0x0) {
    param_2[0x18] = 0;
    param_2[0x19] = 0;
    param_2[0x1a] = 0;
    *(undefined4 *)(param_2 + 0x1b) = 1;
    *param_1 = (long)param_2;
  }
  else {
    __s1 = (char *)*param_2;
    puVar1 = (undefined8 *)*param_1;
    do {
      while( true ) {
        puVar8 = puVar1;
        iVar4 = strcmp(__s1,(char *)*puVar8);
        if (iVar4 < 0) break;
        if (iVar4 == 0) {
          return puVar8;
        }
        puVar1 = (undefined8 *)puVar8[0x19];
        if ((undefined8 *)puVar8[0x19] == (undefined8 *)0x0) goto LAB_0011cdb6;
      }
      puVar1 = (undefined8 *)puVar8[0x18];
    } while ((undefined8 *)puVar8[0x18] != (undefined8 *)0x0);
LAB_0011cdb6:
    param_2[0x1a] = puVar8;
    param_2[0x18] = 0;
    param_2[0x19] = 0;
    *(undefined4 *)(param_2 + 0x1b) = 1;
    puVar8[(ulong)(-1 < iVar4) + 0x18] = param_2;
    do {
      if (*(int *)(puVar8 + 0x1b) != 1) break;
      puVar1 = (undefined8 *)puVar8[0x1a];
      puVar5 = (undefined8 *)puVar1[0x18];
      if (puVar8 == puVar5) {
        puVar5 = (undefined8 *)puVar1[0x19];
        if ((puVar5 != (undefined8 *)0x0) && (*(int *)(puVar5 + 0x1b) == 1)) goto LAB_0011cdf0;
        puVar5 = (undefined8 *)puVar8[0x19];
        if (puVar5 == param_2) {
          lVar2 = param_2[0x18];
          puVar8[0x19] = lVar2;
          if (lVar2 == 0) {
            param_2[0x1a] = puVar1;
LAB_0011cfd7:
            lVar2 = puVar8[0x1a];
            plVar6 = (long *)(lVar2 + 200);
            if (puVar8 == *(undefined8 **)(lVar2 + 0xc0)) {
              plVar6 = (long *)(lVar2 + 0xc0);
            }
          }
          else {
            *(undefined8 **)(lVar2 + 0xd0) = puVar8;
            lVar2 = puVar8[0x1a];
            param_2[0x1a] = lVar2;
            if (lVar2 != 0) goto LAB_0011cfd7;
            plVar6 = param_1;
          }
          *plVar6 = (long)param_2;
          param_2[0x18] = puVar8;
          puVar8[0x1a] = param_2;
          puVar7 = (undefined8 *)puVar1[0x18];
          puVar5 = (undefined8 *)puVar7[0x19];
          puVar9 = puVar8;
        }
        else {
          puVar7 = puVar8;
          puVar9 = param_2;
          param_2 = puVar8;
        }
        *(undefined4 *)(param_2 + 0x1b) = 0;
        *(undefined4 *)(puVar1 + 0x1b) = 1;
        puVar1[0x18] = puVar5;
        if (puVar5 != (undefined8 *)0x0) {
          puVar5[0x1a] = puVar1;
        }
        lVar2 = puVar1[0x1a];
        puVar7[0x1a] = lVar2;
        if (lVar2 == 0) {
          plVar6 = param_1;
        }
        else {
          lVar2 = puVar1[0x1a];
          plVar6 = (long *)(lVar2 + 200);
          if (puVar1 == *(undefined8 **)(lVar2 + 0xc0)) {
            plVar6 = (long *)(lVar2 + 0xc0);
          }
        }
        *plVar6 = (long)puVar7;
        puVar7[0x19] = puVar1;
        puVar1[0x1a] = puVar7;
      }
      else if ((puVar5 == (undefined8 *)0x0) || (*(int *)(puVar5 + 0x1b) != 1)) {
        if ((undefined8 *)puVar8[0x18] == param_2) {
          lVar2 = param_2[0x19];
          puVar8[0x18] = lVar2;
          if (lVar2 == 0) {
            param_2[0x1a] = puVar1;
LAB_0011cf19:
            lVar2 = puVar8[0x1a];
            plVar6 = (long *)(lVar2 + 200);
            if (puVar8 == *(undefined8 **)(lVar2 + 0xc0)) {
              plVar6 = (long *)(lVar2 + 0xc0);
            }
          }
          else {
            *(undefined8 **)(lVar2 + 0xd0) = puVar8;
            lVar2 = puVar8[0x1a];
            param_2[0x1a] = lVar2;
            if (lVar2 != 0) goto LAB_0011cf19;
            plVar6 = param_1;
          }
          *plVar6 = (long)param_2;
          param_2[0x19] = puVar8;
          puVar8[0x1a] = param_2;
          puVar5 = param_2;
        }
        else {
          puVar5 = puVar8;
          puVar8 = param_2;
        }
        *(undefined4 *)(puVar5 + 0x1b) = 0;
        *(undefined4 *)(puVar1 + 0x1b) = 1;
        lVar2 = puVar1[0x19];
        lVar3 = *(long *)(lVar2 + 0xc0);
        puVar1[0x19] = lVar3;
        if (lVar3 != 0) {
          *(undefined8 **)(lVar3 + 0xd0) = puVar1;
        }
        lVar3 = puVar1[0x1a];
        *(long *)(lVar2 + 0xd0) = lVar3;
        if (lVar3 == 0) {
          plVar6 = param_1;
        }
        else {
          lVar3 = puVar1[0x1a];
          plVar6 = (long *)(lVar3 + 200);
          if (puVar1 == *(undefined8 **)(lVar3 + 0xc0)) {
            plVar6 = (long *)(lVar3 + 0xc0);
          }
        }
        *plVar6 = lVar2;
        *(undefined8 **)(lVar2 + 0xc0) = puVar1;
        puVar1[0x1a] = lVar2;
        puVar9 = puVar8;
      }
      else {
LAB_0011cdf0:
        *(undefined4 *)(puVar5 + 0x1b) = 0;
        *(undefined4 *)(puVar8 + 0x1b) = 0;
        *(undefined4 *)(puVar1 + 0x1b) = 1;
        puVar9 = puVar1;
      }
      puVar8 = (undefined8 *)puVar9[0x1a];
      param_2 = puVar9;
    } while (puVar8 != (undefined8 *)0x0);
    param_2 = (undefined8 *)*param_1;
  }
  *(undefined4 *)(param_2 + 0x1b) = 0;
  return (undefined8 *)0x0;
}


// ==== FUN_0011d0e0 @ 0011d0e0

void FUN_0011d0e0(undefined8 *param_1)

{
  int iVar1;
  
  if (DAT_00144e68 == 0) {
    FUN_0011d160(param_1);
    return;
  }
  DAT_00145020 = 1;
  iVar1 = sigsetjmp(&DAT_00145030,1);
  if (iVar1 == 0) {
    FUN_0011d160(param_1);
    DAT_00145020 = 0;
    return;
  }
  if (DAT_00144e6c < 6) {
    __android_log_print(5,"xhook","catch SIGSEGV when init or hook: %s",*param_1);
  }
  DAT_00145020 = 0;
  return;
}


// ==== FUN_0011d160 @ 0011d160

void FUN_0011d160(undefined8 *param_1)

{
  int iVar1;
  regex_t *__preg;
  regex_t *__preg_00;
  
  iVar1 = FUN_0011d270(param_1 + 2,param_1[1],*param_1);
  if (iVar1 == 0) {
    for (__preg_00 = DAT_00144e48; __preg_00 != (regex_t *)0x0;
        __preg_00 = *(regex_t **)&__preg_00->field_0x38) {
      iVar1 = regexec(__preg_00,(char *)*param_1,0,(regmatch_t *)0x0,0);
      if (iVar1 == 0) {
        for (__preg = DAT_00144e58; __preg != (regex_t *)0x0; __preg = (regex_t *)__preg->translate)
        {
          iVar1 = regexec(__preg,(char *)*param_1,0,(regmatch_t *)0x0,0);
          if (iVar1 == 0) {
            if (__preg->fastmap == (char *)0x0) {
              return;
            }
            iVar1 = strcmp(__preg->fastmap,__preg_00->fastmap);
            if (iVar1 == 0) goto LAB_0011d1a7;
          }
        }
        FUN_0011d790(param_1 + 2,__preg_00->fastmap,__preg_00->translate);
      }
LAB_0011d1a7:
    }
  }
  return;
}


// ==== FUN_0011d220 @ 0011d220

undefined8 FUN_0011d220(int *param_1)

{
  undefined8 uVar1;
  
  if ((((*param_1 != 0x464c457f) || ((char)param_1[1] != '\x02')) ||
      (*(char *)((long)param_1 + 5) != '\x01')) ||
     (((*(char *)((long)param_1 + 6) != '\x01' || ((*(ushort *)(param_1 + 4) & 0xfffe) != 2)) ||
      (*(short *)((long)param_1 + 0x12) != 0x3e)))) {
    return 0x3ef;
  }
  uVar1 = 0x3ef;
  if (param_1[5] == 1) {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_0011d270 @ 0011d270

undefined8 FUN_0011d270(long *param_1,uint *param_2,long param_3)

{
  uint uVar1;
  long lVar2;
  int *piVar3;
  uint *puVar4;
  char *pcVar5;
  long *plVar6;
  int *piVar7;
  long lVar8;
  undefined *puVar9;
  uint uVar10;
  long *plVar11;
  
  if (param_2 == (uint *)0x0) {
    return 0x3ea;
  }
  if (param_3 == 0) {
    return 0x3ea;
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = param_3;
  param_1[1] = (long)param_2;
  param_1[3] = (long)param_2;
  piVar7 = (int *)(*(long *)(param_2 + 8) + (long)param_2);
  param_1[4] = (long)piVar7;
  uVar10 = param_2[0xe];
  if ((ulong)(ushort)uVar10 != 0) {
    piVar3 = piVar7;
    do {
      if ((*piVar3 == 1) && (*(long *)(piVar3 + 2) == 0)) {
        if (param_2 < *(uint **)(piVar3 + 4)) {
          return 0x3ef;
        }
        lVar8 = (long)param_2 - (long)*(uint **)(piVar3 + 4);
        param_1[2] = lVar8;
        piVar3 = piVar7;
        goto LAB_0011d340;
      }
      piVar3 = piVar3 + 0xe;
    } while (piVar3 < piVar7 + (ulong)(ushort)uVar10 * 0xe);
  }
  if (6 < DAT_00144e6c) {
    return 0x3ef;
  }
  pcVar5 = "Can NOT found the first load segment. %s";
  goto LAB_0011d38a;
  while (piVar3 = piVar3 + 0xe, piVar3 < piVar7 + (ulong)(ushort)uVar10 * 0xe) {
LAB_0011d340:
    if (*piVar3 == 2) {
      plVar6 = (long *)(*(long *)(piVar3 + 4) + lVar8);
      param_1[5] = (long)plVar6;
      uVar10 = piVar3[10];
      *(uint *)(param_1 + 6) = uVar10;
      uVar10 = uVar10 >> 4;
      if (uVar10 == 0) goto LAB_0011d54f;
      plVar11 = (long *)((ulong)(uVar10 << 4) + (long)plVar6);
      goto LAB_0011d3f6;
    }
  }
  if (6 < DAT_00144e6c) {
    return 0x3ef;
  }
  pcVar5 = "Can NOT found dynamic segment. %s";
  goto LAB_0011d38a;
LAB_0011d3f6:
  do {
    lVar2 = *plVar6;
    switch(lVar2) {
    case 0:
      plVar6 = plVar11;
      break;
    case 1:
    case 3:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x10:
    case 0x13:
    case 0x15:
    case 0x16:
      break;
    case 2:
      *(int *)(param_1 + 10) = (int)plVar6[1];
      break;
    case 4:
      if (*(int *)((long)param_1 + 0xac) != 1) {
        puVar4 = (uint *)(plVar6[1] + lVar8);
        if (puVar4 < param_2) {
          return 0x3ef;
        }
        uVar10 = *puVar4;
        *(uint *)(param_1 + 0x10) = uVar10;
        *(uint *)(param_1 + 0x12) = puVar4[1];
        param_1[0xf] = (long)(puVar4 + 2);
        param_1[0x11] = (long)(puVar4 + (ulong)uVar10 + 2);
      }
      break;
    case 5:
      puVar4 = (uint *)(plVar6[1] + lVar8);
      param_1[7] = (long)puVar4;
      goto LAB_0011d3e4;
    case 6:
      puVar4 = (uint *)(plVar6[1] + lVar8);
      param_1[8] = (long)puVar4;
      goto LAB_0011d3e4;
    case 7:
    case 0x11:
      puVar4 = (uint *)(plVar6[1] + lVar8);
      param_1[0xb] = (long)puVar4;
      goto LAB_0011d3e4;
    case 8:
    case 0x12:
      *(int *)(param_1 + 0xc) = (int)plVar6[1];
      break;
    case 0x14:
      *(uint *)(param_1 + 0x15) = (uint)(plVar6[1] == 7);
      break;
    case 0x17:
      puVar4 = (uint *)(plVar6[1] + lVar8);
      param_1[9] = (long)puVar4;
LAB_0011d3e4:
      if (puVar4 < param_2) {
        return 0x3ef;
      }
      break;
    default:
      switch(lVar2) {
      case 0x6000000f:
      case 0x60000011:
        puVar4 = (uint *)(plVar6[1] + lVar8);
        param_1[0xd] = (long)puVar4;
        goto LAB_0011d3e4;
      case 0x60000010:
      case 0x60000012:
        *(int *)(param_1 + 0xe) = (int)plVar6[1];
        break;
      default:
        if (lVar2 == 0x6ffffef5) {
          puVar4 = (uint *)(plVar6[1] + lVar8);
          if (puVar4 < param_2) {
            return 0x3ef;
          }
          uVar10 = *puVar4;
          *(uint *)(param_1 + 0x10) = uVar10;
          *(uint *)((long)param_1 + 0x94) = puVar4[1];
          uVar1 = puVar4[2];
          *(uint *)(param_1 + 0x14) = uVar1;
          *(uint *)((long)param_1 + 0xa4) = puVar4[3];
          param_1[0x13] = (long)(puVar4 + 4);
          param_1[0xf] = (long)(puVar4 + (ulong)uVar1 * 2 + 4);
          param_1[0x11] = (long)(puVar4 + (ulong)uVar1 * 2 + 4 + uVar10);
          *(undefined4 *)((long)param_1 + 0xac) = 1;
        }
      }
    }
    plVar6 = plVar6 + 2;
  } while (plVar6 < plVar11);
LAB_0011d54f:
  pcVar5 = (char *)param_1[0xd];
  if (pcVar5 != (char *)0x0) {
    if ((((*(uint *)(param_1 + 0xe) < 4) || (*pcVar5 != 'A')) || (pcVar5[1] != 'P')) ||
       ((pcVar5[2] != 'S' || (pcVar5[3] != '2')))) {
      if (DAT_00144e6c < 7) {
        __android_log_print(6,"xhook","android rel/rela format error\n");
        return 0x3ef;
      }
      return 0x3ef;
    }
    param_1[0xd] = (long)(pcVar5 + 4);
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) - 4;
  }
  if (lVar8 == 0) {
    if (6 < DAT_00144e6c) {
      return 0x3ef;
    }
    pcVar5 = "bias_addr == 0\n";
  }
  else if (piVar7 == (int *)0x0) {
    if (6 < DAT_00144e6c) {
      return 0x3ef;
    }
    pcVar5 = "phdr == NULL\n";
  }
  else if (param_1[7] == 0) {
    if (6 < DAT_00144e6c) {
      return 0x3ef;
    }
    pcVar5 = "strtab == NULL\n";
  }
  else if (param_1[8] == 0) {
    if (6 < DAT_00144e6c) {
      return 0x3ef;
    }
    pcVar5 = "symtab == NULL\n";
  }
  else if (param_1[0xf] == 0) {
    if (6 < DAT_00144e6c) {
      return 0x3ef;
    }
    pcVar5 = "bucket == NULL\n";
  }
  else if (param_1[0x11] == 0) {
    if (6 < DAT_00144e6c) {
      return 0x3ef;
    }
    pcVar5 = "chain == NULL\n";
  }
  else {
    if ((*(int *)((long)param_1 + 0xac) != 1) || (param_1[0x13] != 0)) {
      if (4 < DAT_00144e6c) {
        return 0;
      }
      puVar9 = &DAT_0010a359;
      if ((int)param_1[0x15] == 0) {
        puVar9 = &DAT_0010a28e;
      }
      pcVar5 = "GNU_HASH";
      if (*(int *)((long)param_1 + 0xac) == 0) {
        pcVar5 = "ELF_HASH";
      }
      __android_log_print(4,"xhook","init OK: %s (%s %s PLT:%u DYN:%u ANDROID:%u)\n",param_3,puVar9,
                          pcVar5,(int)param_1[10],(int)param_1[0xc],(int)param_1[0xe]);
      return 0;
    }
    if (6 < DAT_00144e6c) {
      return 0x3ef;
    }
    pcVar5 = "bloom == NULL\n";
  }
  __android_log_print(6,"xhook",pcVar5);
  if (6 < DAT_00144e6c) {
    return 0x3ef;
  }
  pcVar5 = "elf init check failed. %s";
LAB_0011d38a:
  __android_log_print(6,"xhook",pcVar5,param_3);
  return 0x3ef;
}


// ==== FUN_0011d790 @ 0011d790

int FUN_0011d790(long *param_1,byte *param_2,long param_3,undefined8 param_4)

{
  byte *pbVar1;
  uint uVar2;
  long lVar3;
  long lVar4;
  ulong uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  byte *pbVar9;
  byte *pbVar10;
  ulong uVar11;
  ulong *puVar12;
  byte bVar13;
  ulong uVar14;
  char *pcVar15;
  uint *puVar16;
  ulong uVar17;
  ulong uVar18;
  ulong uVar19;
  ulong uVar20;
  uint uVar21;
  ulong uVar22;
  ulong uVar23;
  long in_FS_OFFSET;
  ulong local_120;
  long local_118;
  ulong local_110;
  ulong local_f8;
  int local_c4;
  byte *local_c0;
  byte *local_b8;
  ulong local_b0;
  ulong uStack_a8;
  ulong local_a0;
  ulong uStack_98;
  ulong local_90;
  ulong uStack_88;
  ulong local_80;
  ulong uStack_78;
  long local_70;
  ulong uStack_68;
  ulong local_60;
  ulong uStack_58;
  ulong local_50;
  long lStack_48;
  ulong local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  if (*param_1 == 0) {
    iVar7 = 0x3f0;
    if (DAT_00144e6c < 7) {
      pcVar15 = "not inited\n";
LAB_0011d881:
      __android_log_print(6,"xhook",pcVar15);
    }
  }
  else {
    iVar7 = 0x3ea;
    if ((param_2 == (byte *)0x0) || (param_3 == 0)) goto LAB_0011e1ad;
    if (DAT_00144e6c < 5) {
      __android_log_print(4,"xhook","hooking %s in %s\n",param_2);
    }
    bVar13 = *param_2;
    if (*(int *)((long)param_1 + 0xac) == 0) {
      iVar7 = 0;
      uVar21 = 0;
      if (bVar13 != 0) {
        uVar21 = 0;
        pbVar9 = param_2;
        do {
          pbVar9 = pbVar9 + 1;
          uVar21 = (uint)bVar13 + uVar21 * 0x10;
          uVar21 = uVar21 >> 0x18 & 0xfffffff0 ^ uVar21 & 0xfffffff;
          bVar13 = *pbVar9;
        } while (bVar13 != 0);
      }
      uVar21 = *(uint *)(param_1[0xf] + ((ulong)uVar21 % (ulong)*(uint *)(param_1 + 0x10)) * 4);
      if (uVar21 != 0) {
        lVar4 = param_1[7];
        lVar3 = param_1[8];
        do {
          uVar22 = (ulong)uVar21;
          iVar6 = strcmp((char *)param_2,(char *)((ulong)*(uint *)(lVar3 + uVar22 * 0x18) + lVar4));
          if (iVar6 == 0) {
            if (4 < DAT_00144e6c) goto LAB_0011dac0;
            pcVar15 = "found %s at symidx: %u (ELF_HASH)\n";
            goto LAB_0011dab6;
          }
          uVar21 = *(uint *)(param_1[0x11] + uVar22 * 4);
        } while (uVar21 != 0);
      }
      goto LAB_0011e1ad;
    }
    if (bVar13 == 0) {
      uVar14 = 0x1505;
    }
    else {
      uVar14 = 0x1505;
      pbVar9 = param_2;
      do {
        pbVar9 = pbVar9 + 1;
        uVar14 = (ulong)((int)uVar14 * 0x21 + (uint)bVar13);
        bVar13 = *pbVar9;
      } while (bVar13 != 0);
    }
    if (((1L << ((byte)(uVar14 >> (*(byte *)((long)param_1 + 0xa4) & 0x3f)) & 0x3f) |
         1L << (uVar14 & 0x3f)) &
        ~*(ulong *)(param_1[0x13] + ((uVar14 >> 6) % (ulong)*(uint *)(param_1 + 0x14)) * 8)) == 0) {
      uVar21 = *(uint *)(param_1[0xf] + (uVar14 % (ulong)*(uint *)(param_1 + 0x10)) * 4);
      uVar8 = *(uint *)((long)param_1 + 0x94);
      if (uVar21 < uVar8) goto LAB_0011da58;
      lVar4 = param_1[0x11];
      do {
        uVar22 = (ulong)uVar21;
        uVar2 = *(uint *)(lVar4 + (ulong)(uVar21 - uVar8) * 4);
        if (((uVar2 ^ (uint)uVar14) < 2) &&
           (iVar7 = strcmp((char *)param_2,
                           (char *)((ulong)*(uint *)(param_1[8] + uVar22 * 0x18) + param_1[7])),
           iVar7 == 0)) {
          if (4 < DAT_00144e6c) goto LAB_0011dac0;
          pcVar15 = "found %s at symidx: %u (GNU_HASH DEF)\n";
          goto LAB_0011dab6;
        }
        uVar21 = uVar21 + 1;
      } while ((uVar2 & 1) == 0);
    }
    else {
      uVar8 = *(uint *)((long)param_1 + 0x94);
    }
    if (uVar8 != 0) {
LAB_0011da58:
      lVar4 = param_1[7];
      puVar16 = (uint *)param_1[8];
      uVar22 = 0;
LAB_0011da70:
      iVar7 = strcmp((char *)((ulong)*puVar16 + lVar4),(char *)param_2);
      if (iVar7 != 0) goto code_r0x0011da82;
      if (DAT_00144e6c < 5) {
        pcVar15 = "found %s at symidx: %u (GNU_HASH UNDEF)\n";
LAB_0011dab6:
        __android_log_print(4,"xhook",pcVar15,param_2,uVar22 & 0xffffffff);
      }
LAB_0011dac0:
      uVar14 = param_1[9];
      if (uVar14 != 0) {
        uVar23 = *(uint *)(param_1 + 10) + uVar14;
        lVar4 = param_1[0x15];
        do {
          if (uVar23 <= uVar14) break;
          pcVar15 = ".rel.plt";
          if ((int)param_1[0x15] != 0) {
            pcVar15 = ".rela.plt";
          }
          iVar7 = FUN_0011e2a0(param_1,pcVar15,1,param_2,param_3,param_4,uVar22,uVar14,&local_c4);
          if (iVar7 != 0) goto LAB_0011e1ad;
          uVar14 = uVar14 + (ulong)((int)lVar4 != 0) * 8 + 0x10;
        } while (local_c4 == 0);
      }
      uVar14 = param_1[0xb];
      if (uVar14 != 0) {
        uVar21 = *(uint *)(param_1 + 0xc);
        lVar4 = param_1[0x15];
        uVar23 = uVar14;
        while (uVar23 < uVar21 + uVar14) {
          pcVar15 = ".rel.dyn";
          if ((int)param_1[0x15] != 0) {
            pcVar15 = ".rela.dyn";
          }
          iVar7 = FUN_0011e2a0(param_1,pcVar15,0,param_2,param_3,param_4,uVar22,uVar23,0);
          uVar23 = uVar23 + (ulong)((int)lVar4 != 0) * 8 + 0x10;
          if (iVar7 != 0) goto LAB_0011e1ad;
        }
      }
      pbVar9 = (byte *)param_1[0xd];
      if (pbVar9 == (byte *)0x0) goto LAB_0011e1ab;
      uVar21 = *(uint *)(param_1 + 0x15);
      pbVar1 = pbVar9 + *(uint *)(param_1 + 0xe);
      local_50 = 0;
      lStack_48 = 0;
      local_60 = 0;
      uStack_58 = 0;
      local_70 = 0;
      uStack_68 = 0;
      local_80 = 0;
      uStack_78 = 0;
      local_90 = 0;
      uStack_88 = 0;
      local_a0 = 0;
      uStack_98 = 0;
      local_b0 = 0;
      uStack_a8 = 0;
      local_40 = (ulong)uVar21;
      if ((ulong)*(uint *)(param_1 + 0xe) == 0) {
LAB_0011dc79:
        local_c0 = pbVar9;
      }
      else {
        uVar14 = 0;
        uVar23 = 0;
        while( true ) {
          bVar13 = *pbVar9;
          uVar23 = (ulong)(bVar13 & 0x7f) << ((byte)uVar14 & 0x3f) | uVar23;
          pbVar9 = pbVar9 + 1;
          uVar14 = uVar14 + 7;
          if ((bVar13 & 0x80) == 0) break;
          if (pbVar1 <= pbVar9) goto LAB_0011dc79;
        }
        local_b0 = -1L << ((byte)uVar14 & 0x3f);
        if ((bVar13 & 0x40) == 0) {
          local_b0 = 0;
        }
        if (0x3f < uVar14) {
          local_b0 = 0;
        }
        local_b0 = uVar23 | local_b0;
        uVar14 = 0;
        uVar23 = 0;
        local_c0 = pbVar9;
        do {
          if (pbVar1 <= local_c0) goto LAB_0011dc84;
          pbVar9 = local_c0 + 1;
          bVar13 = *local_c0;
          uVar14 = uVar14 | (ulong)(bVar13 & 0x7f) << ((byte)uVar23 & 0x3f);
          uVar23 = uVar23 + 7;
          local_c0 = pbVar9;
        } while ((bVar13 & 0x80) != 0);
        uStack_58 = -1L << ((byte)uVar23 & 0x3f);
        if ((bVar13 & 0x40) == 0) {
          uStack_58 = 0;
        }
        if (0x3f < uVar23) {
          uStack_58 = 0;
        }
        uStack_58 = uVar14 | uStack_58;
      }
LAB_0011dc84:
      uVar5 = local_b0;
      uVar18 = 0;
      local_118 = 0;
      local_110 = 0;
      uVar23 = 0;
      uVar14 = 0;
      local_f8 = 0;
      local_120 = 0;
      uVar20 = uStack_58;
      pbVar9 = local_c0;
      local_b8 = pbVar1;
      while( true ) {
        if (uVar5 <= local_120) goto LAB_0011e1ab;
        if (local_f8 == uVar14) break;
        local_f8 = local_f8 + 1;
joined_r0x0011df96:
        if ((uVar23 & 2) == 0) {
          uVar17 = 0;
          uVar11 = 0;
          pbVar10 = pbVar9;
          do {
            if (pbVar1 <= pbVar10) goto LAB_0011e1ab;
            pbVar9 = pbVar10 + 1;
            bVar13 = *pbVar10;
            uVar17 = uVar17 | (ulong)(bVar13 & 0x7f) << ((byte)uVar11 & 0x3f);
            uVar11 = uVar11 + 7;
            pbVar10 = pbVar9;
            local_c0 = pbVar9;
          } while ((bVar13 & 0x80) != 0);
          uVar19 = -1L << ((byte)uVar11 & 0x3f);
          if ((bVar13 & 0x40) == 0) {
            uVar19 = 0;
          }
          if (0x3f < uVar11) {
            uVar19 = 0;
          }
          uVar17 = uVar17 | uVar19;
        }
        else {
          uVar17 = local_110;
        }
        uVar20 = uVar20 + uVar17;
        uStack_58 = uVar20;
        if ((uVar23 & 1) == 0) {
          uVar18 = 0;
          uVar17 = 0;
          pbVar10 = pbVar9;
          do {
            if (pbVar1 <= pbVar10) goto LAB_0011e1ab;
            pbVar9 = pbVar10 + 1;
            bVar13 = *pbVar10;
            uVar18 = uVar18 | (ulong)(bVar13 & 0x7f) << ((byte)uVar17 & 0x3f);
            uVar17 = uVar17 + 7;
            pbVar10 = pbVar9;
            local_c0 = pbVar9;
          } while ((bVar13 & 0x80) != 0);
          uVar11 = -1L << ((byte)uVar17 & 0x3f);
          if ((bVar13 & 0x40) == 0) {
            uVar11 = 0;
          }
          if (0x3f < uVar17) {
            uVar11 = 0;
          }
          uVar18 = uVar18 | uVar11;
          local_50 = uVar18;
        }
        if (uVar21 == 0) {
          puVar12 = &uStack_68;
          uStack_68 = uVar20;
          local_60 = uVar18;
        }
        else {
          if (((uint)uVar23 & 0xc) == 8) {
            uVar17 = 0;
            uVar11 = 0;
            pbVar10 = pbVar9;
            do {
              if (pbVar1 <= pbVar10) goto LAB_0011e1ab;
              pbVar9 = pbVar10 + 1;
              bVar13 = *pbVar10;
              uVar17 = uVar17 | (ulong)(bVar13 & 0x7f) << ((byte)uVar11 & 0x3f);
              uVar11 = uVar11 + 7;
              pbVar10 = pbVar9;
              local_c0 = pbVar9;
            } while ((bVar13 & 0x80) != 0);
            uVar19 = -1L << ((byte)uVar11 & 0x3f);
            if ((bVar13 & 0x40) == 0) {
              uVar19 = 0;
            }
            if (0x3f < uVar11) {
              uVar19 = 0;
            }
            local_118 = local_118 + (uVar17 | uVar19);
            lStack_48 = local_118;
          }
          puVar12 = &local_80;
          local_80 = uVar20;
          uStack_78 = uVar18;
          local_70 = local_118;
        }
        local_120 = local_120 + 1;
        pcVar15 = ".rela.android";
        if ((int)param_1[0x15] == 0) {
          pcVar15 = ".rel.android";
        }
        local_90 = local_120;
        uStack_88 = local_f8;
        iVar7 = FUN_0011e2a0(param_1,pcVar15,0,param_2,param_3,param_4,uVar22,puVar12,0);
        if (iVar7 != 0) goto LAB_0011e1ad;
      }
      uVar23 = 0;
      uVar14 = 0;
      do {
        if (pbVar1 <= pbVar9) goto LAB_0011e1ab;
        local_c0 = pbVar9 + 1;
        bVar13 = *pbVar9;
        uVar23 = uVar23 | (ulong)(bVar13 & 0x7f) << ((byte)uVar14 & 0x3f);
        uVar14 = uVar14 + 7;
        pbVar9 = local_c0;
      } while ((bVar13 & 0x80) != 0);
      uStack_a8 = -1L << ((byte)uVar14 & 0x3f);
      if ((bVar13 & 0x40) == 0) {
        uStack_a8 = 0;
      }
      if (0x3f < uVar14) {
        uStack_a8 = 0;
      }
      uStack_a8 = uVar23 | uStack_a8;
      uVar23 = 0;
      uVar14 = 0;
      do {
        if (pbVar1 <= local_c0) goto LAB_0011e1ab;
        pbVar9 = local_c0 + 1;
        bVar13 = *local_c0;
        uVar23 = uVar23 | (ulong)(bVar13 & 0x7f) << ((byte)uVar14 & 0x3f);
        uVar14 = uVar14 + 7;
        local_c0 = pbVar9;
      } while ((bVar13 & 0x80) != 0);
      local_a0 = -1L << ((byte)uVar14 & 0x3f);
      if ((bVar13 & 0x40) == 0) {
        local_a0 = 0;
      }
      if (0x3f < uVar14) {
        local_a0 = 0;
      }
      local_a0 = uVar23 | local_a0;
      if ((local_a0 & 2) != 0) {
        local_110 = 0;
        uVar14 = 0;
        do {
          if (pbVar1 <= local_c0) goto LAB_0011e1ab;
          pbVar9 = local_c0 + 1;
          bVar13 = *local_c0;
          local_110 = local_110 | (ulong)(bVar13 & 0x7f) << ((byte)uVar14 & 0x3f);
          uVar14 = uVar14 + 7;
          local_c0 = pbVar9;
        } while ((bVar13 & 0x80) != 0);
        uVar23 = -1L << ((byte)uVar14 & 0x3f);
        if ((bVar13 & 0x40) == 0) {
          uVar23 = 0;
        }
        if (0x3f < uVar14) {
          uVar23 = 0;
        }
        local_110 = local_110 | uVar23;
        uStack_98 = local_110;
      }
      if ((local_a0 & 1) == 0) {
      }
      else {
        uVar18 = 0;
        uVar14 = 0;
        do {
          if (pbVar1 <= local_c0) goto LAB_0011e1ab;
          pbVar9 = local_c0 + 1;
          bVar13 = *local_c0;
          uVar18 = uVar18 | (ulong)(bVar13 & 0x7f) << ((byte)uVar14 & 0x3f);
          uVar14 = uVar14 + 7;
          local_c0 = pbVar9;
        } while ((bVar13 & 0x80) != 0);
        uVar23 = -1L << ((byte)uVar14 & 0x3f);
        if ((bVar13 & 0x40) == 0) {
          uVar23 = 0;
        }
        if (0x3f < uVar14) {
          uVar23 = 0;
        }
        uVar18 = uVar18 | uVar23;
        local_50 = uVar18;
      }
      if ((~(uint)local_a0 & 0xc) != 0) {
        if ((local_a0 & 8) == 0) {
          local_118 = 0;
          goto LAB_0011df6a;
        }
LAB_0011df77:
        uStack_88 = 0;
        local_f8 = 1;
        uVar14 = uStack_a8;
        uVar23 = local_a0;
        pbVar9 = local_c0;
        goto joined_r0x0011df96;
      }
      if (uVar21 != 0) {
        uVar14 = 0;
        uVar23 = 0;
        do {
          if (pbVar1 <= local_c0) goto LAB_0011e1ab;
          pbVar9 = local_c0 + 1;
          bVar13 = *local_c0;
          uVar14 = uVar14 | (ulong)(bVar13 & 0x7f) << ((byte)uVar23 & 0x3f);
          uVar23 = uVar23 + 7;
          local_c0 = pbVar9;
        } while ((bVar13 & 0x80) != 0);
        uVar17 = -1L << ((byte)uVar23 & 0x3f);
        if ((bVar13 & 0x40) == 0) {
          uVar17 = 0;
        }
        if (0x3f < uVar23) {
          uVar17 = 0;
        }
        local_118 = local_118 + (uVar14 | uVar17);
LAB_0011df6a:
        lStack_48 = local_118;
        goto LAB_0011df77;
      }
      iVar7 = 0;
      if (6 < DAT_00144e6c) goto LAB_0011e1ad;
      pcVar15 = "unexpected r_addend in android.rel section";
      iVar7 = 0;
      goto LAB_0011d881;
    }
LAB_0011e1ab:
    iVar7 = 0;
  }
LAB_0011e1ad:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar7;
code_r0x0011da82:
  uVar22 = uVar22 + 1;
  puVar16 = puVar16 + 6;
  if (uVar8 == uVar22) goto LAB_0011e1ab;
  goto LAB_0011da70;
}


// ==== FUN_0011e2a0 @ 0011e2a0

int FUN_0011e2a0(undefined8 *param_1,undefined8 param_2,int param_3,undefined8 param_4,long param_5,
                long *param_6,uint param_7,long *param_8,undefined4 *param_9)

{
  long lVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  long *plVar5;
  long in_FS_OFFSET;
  int local_3c;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_9 != (undefined4 *)0x0) {
    *param_9 = 0;
  }
  iVar3 = 0;
  if ((ulong)param_8[1] >> 0x20 != (ulong)param_7) goto LAB_0011e4db;
  lVar1 = *param_8;
  iVar2 = (int)param_8[1];
  if (((param_3 != 0) && (iVar2 != 7)) || ((param_3 == 0 && ((iVar2 != 6 && (iVar2 != 1))))))
  goto LAB_0011e4db;
  if (DAT_00144e6c < 5) {
    __android_log_print(4,"xhook","found %s at %s offset: %p\n",param_4,param_2,lVar1);
  }
  if (param_9 != (undefined4 *)0x0) {
    *param_9 = 1;
  }
  plVar5 = (long *)(lVar1 + param_1[2]);
  iVar3 = 0x3ef;
  if (plVar5 < (long *)param_1[1]) goto LAB_0011e4db;
  local_3c = 0;
  if (*plVar5 == param_5) {
LAB_0011e4d9:
    iVar3 = 0;
  }
  else {
    iVar3 = FUN_0011e790(plVar5,*param_1,&local_3c);
    if (iVar3 == 0) {
      if ((local_3c == 3) || (iVar3 = FUN_0011e7a0(plVar5,3), iVar3 == 0)) {
        lVar1 = *plVar5;
        if (param_6 != (long *)0x0) {
          *param_6 = lVar1;
        }
        *plVar5 = param_5;
        if (((local_3c != 3) && (iVar3 = FUN_0011e7a0(plVar5), iVar3 != 0)) && (DAT_00144e6c < 6)) {
          __android_log_print(5,"xhook","restore addr prot failed. ret: %d",iVar3);
        }
        FUN_0011e820(plVar5);
        if (DAT_00144e6c < 5) {
          __android_log_print(4,"xhook","XH_HK_OK %p: %p -> %p %s %s\n",plVar5,lVar1,param_5,param_4
                              ,*param_1);
        }
        goto LAB_0011e4d9;
      }
      if (6 < DAT_00144e6c) goto LAB_0011e4db;
      pcVar4 = "set addr prot failed. ret: %d";
    }
    else {
      if (6 < DAT_00144e6c) goto LAB_0011e4db;
      pcVar4 = "get addr prot failed. ret: %d";
    }
    __android_log_print(6,"xhook",pcVar4,iVar3);
    if (DAT_00144e6c < 7) {
      __android_log_print(6,"xhook","replace function failed: %s at %s\n",param_4,param_2);
    }
  }
LAB_0011e4db:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar3;
}


// ==== FUN_0011e510 @ 0011e510

int FUN_0011e510(ulong param_1,long param_2,char *param_3,uint *param_4)

{
  int iVar1;
  uint uVar2;
  FILE *__stream;
  char *pcVar3;
  long in_FS_OFFSET;
  int local_26c;
  ulong local_260;
  ulong local_250;
  ulong local_248;
  char local_23d;
  char local_23c;
  char local_23b;
  char local_23a;
  char local_238 [512];
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  *param_4 = 0;
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    local_26c = 0x3ee;
    if (*(long *)(in_FS_OFFSET + 0x28) != local_38) goto LAB_0011e77f;
  }
  else {
    pcVar3 = fgets(local_238,0x200,__stream);
    if (pcVar3 != (char *)0x0) {
      local_26c = 1;
      local_260 = param_1;
      do {
        if (param_3 == (char *)0x0) {
          while ((iVar1 = sscanf(local_238,"%lx-%lx %4s ",&local_248,&local_250,&local_23d),
                 iVar1 != 3 || (local_23a != 'p'))) {
            pcVar3 = fgets(local_238,0x200,__stream);
            if (pcVar3 == (char *)0x0) goto LAB_0011e72e;
          }
        }
        else {
          while (((pcVar3 = strstr(local_238,param_3), pcVar3 == (char *)0x0 ||
                  (iVar1 = sscanf(local_238,"%lx-%lx %4s ",&local_248,&local_250,&local_23d),
                  iVar1 != 3)) || (local_23a != 'p'))) {
            pcVar3 = fgets(local_238,0x200,__stream);
            if (pcVar3 == (char *)0x0) goto LAB_0011e72e;
          }
        }
        if ((local_260 < local_248) || (local_250 <= local_260)) {
        }
        else {
          if (local_26c == 0) {
            if (local_23d != 'r') {
              *(byte *)param_4 = (byte)*param_4 & 0xfe;
            }
            if (local_23c != 'w') {
              *(byte *)param_4 = (byte)*param_4 & 0xfd;
            }
            if (local_23b != 'x') {
              uVar2 = *param_4 & 0xfffffffb;
              goto LAB_0011e6ff;
            }
          }
          else {
            if (local_23d == 'r') {
              *(byte *)param_4 = (byte)*param_4 | 1;
            }
            if (local_23c == 'w') {
              *(byte *)param_4 = (byte)*param_4 | 2;
            }
            if (local_23b == 'x') {
              uVar2 = *param_4 | 4;
LAB_0011e6ff:
              *param_4 = uVar2;
            }
          }
          local_26c = 0;
          local_260 = local_250;
          if (param_2 + param_1 <= local_250) goto LAB_0011e736;
        }
        pcVar3 = fgets(local_238,0x200,__stream);
      } while (pcVar3 != (char *)0x0);
    }
LAB_0011e72e:
    local_26c = 0x3f1;
LAB_0011e736:
    fclose(__stream);
    if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
LAB_0011e77f:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  return local_26c;
}


// ==== FUN_0011e790 @ 0011e790

void FUN_0011e790(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  FUN_0011e510(param_1,8,param_2,param_3);
  return;
}


// ==== FUN_0011e7a0 @ 0011e7a0

int FUN_0011e7a0(ulong param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  iVar1 = getpagesize();
  iVar2 = getpagesize();
  iVar3 = getpagesize();
  iVar4 = getpagesize();
  iVar1 = mprotect((void *)((long)-iVar1 & param_1),
                   ((long)iVar3 + ((long)-iVar2 & param_1 + 7)) - ((long)-iVar4 & param_1),param_2);
  if (iVar1 == 0) {
    iVar1 = 0;
  }
  else {
    piVar5 = (int *)__errno();
    iVar1 = 0x3e9;
    if (*piVar5 != 0) {
      iVar1 = *piVar5;
    }
  }
  return iVar1;
}


// ==== FUN_0011e820 @ 0011e820

undefined8 FUN_0011e820(void)

{
  undefined8 in_RAX;
  
  getpagesize();
  getpagesize();
  getpagesize();
  return in_RAX;
}


// ==== FUN_0011e840 @ 0011e840

char * FUN_0011e840(void)

{
  return "libxhook 1.2.0 (x86_64)";
}


// ==== FUN_0011e850 @ 0011e850

undefined8 FUN_0011e850(pthread_cond_t *param_1)

{
  undefined8 in_RAX;
  
                    /* try { // try from 0011e851 to 0011e855 has its CatchHandler @ 0011e858 */
  pthread_cond_signal(param_1);
  return in_RAX;
}


// ==== FUN_0011e860 @ 0011e860

undefined8 FUN_0011e860(pthread_cond_t *param_1)

{
  undefined8 in_RAX;
  
                    /* try { // try from 0011e861 to 0011e865 has its CatchHandler @ 0011e868 */
  pthread_cond_destroy(param_1);
  return in_RAX;
}


// ==== FUN_0011e870 @ 0011e870

void FUN_0011e870(void)

{
  return;
}


// ==== FUN_0011e880 @ 0011e880

void FUN_0011e880(long *param_1)

{
  long *plVar1;
  long lVar2;
  
  if (param_1[2] != 0) {
    LOCK();
    plVar1 = param_1 + 2;
    lVar2 = *plVar1;
    *plVar1 = *plVar1 + -1;
    UNLOCK();
    if (lVar2 != 0) {
      return;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0011e89f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x20))();
  return;
}


// ==== FUN_0011e8c0 @ 0011e8c0

undefined8 FUN_0011e8c0(pthread_mutex_t *param_1)

{
  code *pcVar1;
  int iVar2;
  undefined8 in_RAX;
  undefined8 uVar3;
  
  iVar2 = pthread_mutex_lock(param_1);
  if (iVar2 == 0) {
    return in_RAX;
  }
  FUN_001200f0(iVar2,"mutex lock failed");
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}


// ==== FUN_0011e8e0 @ 0011e8e0

undefined8 FUN_0011e8e0(pthread_mutex_t *param_1)

{
  undefined8 in_RAX;
  
                    /* try { // try from 0011e8e1 to 0011e8e5 has its CatchHandler @ 0011e8e8 */
  pthread_mutex_unlock(param_1);
  return in_RAX;
}


// ==== FUN_0011e8f0 @ 0011e8f0

undefined8 FUN_0011e8f0(pthread_mutex_t *param_1)

{
  undefined8 in_RAX;
  
                    /* try { // try from 0011e8f1 to 0011e8f5 has its CatchHandler @ 0011e8f8 */
  pthread_mutex_destroy(param_1);
  return in_RAX;
}


// ==== FUN_0011e900 @ 0011e900

void FUN_0011e900(size_t param_1)

{
  void *pvVar1;
  code *pcVar2;
  undefined8 uVar3;
  size_t __size;
  
  __size = 1;
  if (param_1 != 0) {
    __size = param_1;
  }
  while( true ) {
    pvVar1 = malloc(__size);
    if (pvVar1 != (void *)0x0) {
      return;
    }
    pcVar2 = (code *)FUN_001209f0();
    if (pcVar2 == (code *)0x0) break;
    (*pcVar2)();
  }
  uVar3 = FUN_001202b0(8);
  FUN_00135ba0(uVar3);
  FUN_00120320(uVar3,&PTR_PTR_001407c8,FUN_00135b70);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}


// ==== free @ 0011e960

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== FUN_0011e970 @ 0011e970

void FUN_0011e970(undefined8 *param_1,void *param_2)

{
  long lVar1;
  long *plVar2;
  
  *param_1 = &PTR_LAB_001407f0;
                    /* try { // try from 0011e98c to 0011e9a6 has its CatchHandler @ 0011e9de */
  lVar1 = __strlen_chk(param_2,0xffffffffffffffff);
  plVar2 = (long *)FUN_0011e900(lVar1 + 0x19);
  *plVar2 = lVar1;
  plVar2[1] = lVar1;
  *(undefined4 *)(plVar2 + 2) = 0;
  memcpy(plVar2 + 3,param_2,lVar1 + 1);
  param_1[1] = plVar2 + 3;
  return;
}


// ==== FUN_0011ea00 @ 0011ea00

void FUN_0011ea00(undefined8 *param_1,byte *param_2)

{
  long lVar1;
  long *plVar2;
  
  *param_1 = &PTR_FUN_00140818;
  if ((*param_2 & 1) == 0) {
    param_2 = param_2 + 1;
  }
  else {
    param_2 = *(byte **)(param_2 + 0x10);
  }
                    /* try { // try from 0011ea2b to 0011ea45 has its CatchHandler @ 0011ea7d */
  lVar1 = __strlen_chk(param_2,0xffffffffffffffff);
  plVar2 = (long *)FUN_0011e900(lVar1 + 0x19);
  *plVar2 = lVar1;
  plVar2[1] = lVar1;
  *(undefined4 *)(plVar2 + 2) = 0;
  memcpy(plVar2 + 3,param_2,lVar1 + 1);
  param_1[1] = plVar2 + 3;
  return;
}


// ==== FUN_0011ea90 @ 0011ea90

void FUN_0011ea90(undefined8 *param_1,void *param_2)

{
  long lVar1;
  long *plVar2;
  
  *param_1 = &PTR_FUN_00140818;
                    /* try { // try from 0011eaac to 0011eac6 has its CatchHandler @ 0011eafe */
  lVar1 = __strlen_chk(param_2,0xffffffffffffffff);
  plVar2 = (long *)FUN_0011e900(lVar1 + 0x19);
  *plVar2 = lVar1;
  plVar2[1] = lVar1;
  *(undefined4 *)(plVar2 + 2) = 0;
  memcpy(plVar2 + 3,param_2,lVar1 + 1);
  param_1[1] = plVar2 + 3;
  return;
}


// ==== FUN_0011eb20 @ 0011eb20

void FUN_0011eb20(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_00118290("basic_string");
}


// ==== FUN_0011eb30 @ 0011eb30

void FUN_0011eb30(void)

{
  code *pcVar1;
  
  FUN_0011eb40("basic_string");
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_0011eb40 @ 0011eb40

void FUN_0011eb40(undefined8 param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = FUN_001202b0(0x10);
                    /* try { // try from 0011eb54 to 0011eb5e has its CatchHandler @ 0011eb75 */
  FUN_0011f640(uVar1,param_1);
  uVar2 = FUN_00120320(uVar1,&PTR_PTR_001408b0,&LAB_00135bd0);
                    /* catch() { ... } // from try @ 0011eb54 with catch @ 0011eb75 */
  FUN_00120300(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_00136230(uVar2);
}


// ==== FUN_0011eb90 @ 0011eb90

void FUN_0011eb90(ulong *param_1,ulong param_2,ulong param_3,long param_4,size_t param_5,
                 long param_6,size_t param_7,void *param_8)

{
  byte *__src;
  void *__dest;
  ulong uVar1;
  size_t __n;
  ulong uVar2;
  
  if (-param_2 - 0x12 < param_3) {
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20();
  }
  if ((*param_1 & 1) == 0) {
    __src = (byte *)((long)param_1 + 1);
  }
  else {
    __src = (byte *)param_1[2];
  }
  uVar2 = 0xffffffffffffffef;
  if (param_2 < 0x7fffffffffffffe7) {
    uVar1 = param_3 + param_2;
    if (param_3 + param_2 < param_2 * 2) {
      uVar1 = param_2 * 2;
    }
    uVar2 = 0x17;
    if (0x16 < uVar1) {
      uVar2 = uVar1 + 0x10 & 0xfffffffffffffff0;
    }
  }
  __dest = (void *)FUN_0011e900(uVar2);
  if (param_5 != 0) {
    memcpy(__dest,__src,param_5);
  }
  if (param_7 != 0) {
    memcpy((void *)((long)__dest + param_5),param_8,param_7);
  }
  __n = param_4 - (param_5 + param_6);
  if (__n != 0) {
    memcpy((void *)((long)__dest + param_7 + param_5),__src + param_6 + param_5,__n);
  }
  if (param_2 != 0x16) {
    free(__src);
  }
  param_1[2] = (ulong)__dest;
  *param_1 = uVar2 | 1;
  uVar2 = param_7 + param_5 + __n;
  param_1[1] = uVar2;
  *(undefined1 *)((long)__dest + uVar2) = 0;
  return;
}


// ==== FUN_0011ecd0 @ 0011ecd0

void FUN_0011ecd0(ulong *param_1,ulong *param_2)

{
  ulong uVar1;
  void *__src;
  char *__dest;
  ulong uVar2;
  
  if ((*param_2 & 1) == 0) {
    param_1[2] = param_2[2];
    uVar1 = param_2[1];
    *param_1 = *param_2;
    param_1[1] = uVar1;
    return;
  }
  uVar1 = param_2[1];
  __src = (void *)param_2[2];
  if (uVar1 < 0x17) {
    *(char *)param_1 = (char)uVar1 * '\x02';
    __dest = (char *)((long)param_1 + 1);
  }
  else {
    if (0xffffffffffffffef < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_0011eb20(param_1);
    }
    uVar2 = uVar1 + 0x10 & 0xfffffffffffffff0;
    __dest = (char *)FUN_0011e900(uVar2);
    param_1[2] = (ulong)__dest;
    *param_1 = uVar2 | 1;
    param_1[1] = uVar1;
  }
  memcpy(__dest,__src,uVar1 + 1);
  return;
}


// ==== FUN_0011ed70 @ 0011ed70

void FUN_0011ed70(ulong *param_1,ulong param_2,ulong param_3,long param_4,size_t param_5,
                 long param_6,long param_7)

{
  byte *__src;
  void *__dest;
  ulong uVar1;
  ulong uVar2;
  size_t __n;
  
  if (-param_2 - 0x11 < param_3) {
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(param_1);
  }
  if ((*param_1 & 1) == 0) {
    __src = (byte *)((long)param_1 + 1);
  }
  else {
    __src = (byte *)param_1[2];
  }
  uVar2 = 0xffffffffffffffef;
  if (param_2 < 0x7fffffffffffffe7) {
    uVar1 = param_3 + param_2;
    if (param_3 + param_2 < param_2 * 2) {
      uVar1 = param_2 * 2;
    }
    uVar2 = 0x17;
    if (0x16 < uVar1) {
      uVar2 = uVar1 + 0x10 & 0xfffffffffffffff0;
    }
  }
  __dest = (void *)FUN_0011e900(uVar2);
  if (param_5 != 0) {
    memcpy(__dest,__src,param_5);
  }
  __n = param_4 - (param_5 + param_6);
  if (__n != 0) {
    memcpy((void *)((long)__dest + param_7 + param_5),__src + param_6 + param_5,__n);
  }
  if (param_2 != 0x16) {
    free(__src);
  }
  param_1[2] = (ulong)__dest;
  *param_1 = uVar2 | 1;
  return;
}


// ==== FUN_0011ee70 @ 0011ee70

ulong * FUN_0011ee70(ulong *param_1,ulong param_2,byte *param_3,ulong param_4)

{
  byte bVar1;
  code *pcVar2;
  ulong uVar3;
  ulong *puVar4;
  ulong uVar5;
  byte *pbVar6;
  long lVar7;
  byte *__src;
  
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar5 = (ulong)(bVar1 >> 1);
  }
  else {
    uVar5 = param_1[1];
  }
  if (uVar5 < param_2) {
    FUN_0011eb30(param_1);
    pcVar2 = (code *)swi(3);
    puVar4 = (ulong *)(*pcVar2)();
    return puVar4;
  }
  lVar7 = 0x16;
  if ((bVar1 & 1) != 0) {
    lVar7 = (*param_1 & 0xfffffffffffffffe) - 1;
  }
  if (lVar7 - uVar5 < param_4) {
    FUN_0011eb90(param_1,lVar7,(uVar5 + param_4) - lVar7,uVar5,param_2,0,param_4,param_3);
  }
  else if (param_4 != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar6 = (byte *)((long)param_1 + 1);
    }
    else {
      pbVar6 = (byte *)param_1[2];
    }
    if (uVar5 - param_2 != 0) {
      __src = pbVar6 + param_2;
      uVar3 = 0;
      if (param_3 < pbVar6 + uVar5) {
        uVar3 = param_4;
      }
      if (param_3 < __src) {
        uVar3 = 0;
      }
      param_3 = param_3 + uVar3;
      memmove(__src + param_4,__src,uVar5 - param_2);
    }
    memmove(pbVar6 + param_2,param_3,param_4);
    uVar5 = uVar5 + param_4;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar5 * '\x02';
    }
    else {
      param_1[1] = uVar5;
    }
    pbVar6[uVar5] = 0;
  }
  return param_1;
}


// ==== FUN_0011ef80 @ 0011ef80

ulong * FUN_0011ef80(ulong *param_1,void *param_2,ulong param_3)

{
  byte bVar1;
  ulong uVar2;
  long lVar3;
  byte *pbVar4;
  
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar2 = (ulong)(bVar1 >> 1);
    lVar3 = 0x16;
  }
  else {
    lVar3 = (*param_1 & 0xfffffffffffffffe) - 1;
    uVar2 = param_1[1];
  }
  if (lVar3 - uVar2 < param_3) {
    FUN_0011eb90(param_1,lVar3,(uVar2 + param_3) - lVar3,uVar2,uVar2,0,param_3,param_2);
  }
  else if (param_3 != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar4 = (byte *)((long)param_1 + 1);
    }
    else {
      pbVar4 = (byte *)param_1[2];
    }
    memcpy(pbVar4 + uVar2,param_2,param_3);
    uVar2 = uVar2 + param_3;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar2 * '\x02';
    }
    else {
      param_1[1] = uVar2;
    }
    pbVar4[uVar2] = 0;
  }
  return param_1;
}


// ==== FUN_0011f030 @ 0011f030

void FUN_0011f030(undefined8 param_1,undefined8 param_2,char *param_3)

{
  size_t sVar1;
  
  sVar1 = strlen(param_3);
  FUN_0011ee70(param_1,param_2,param_3,sVar1);
  return;
}


// ==== FUN_0011f060 @ 0011f060

void FUN_0011f060(ulong *param_1,byte param_2)

{
  byte bVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  byte *pbVar5;
  
  if (((byte)*param_1 & 1) == 0) {
    bVar1 = (byte)*param_1 >> 1;
    uVar3 = (ulong)bVar1;
    uVar4 = 0x16;
    uVar2 = 0x16;
    if (bVar1 == 0x16) {
LAB_0011f09c:
      uVar3 = uVar2;
      FUN_0011ed70(param_1,uVar4,1,uVar4,uVar4,0,0);
      if ((*param_1 & 1) != 0) goto LAB_0011f0d0;
    }
    *(byte *)param_1 = (char)uVar3 * '\x02' + 2;
    pbVar5 = (byte *)((long)param_1 + 1);
  }
  else {
    uVar3 = param_1[1];
    uVar4 = (*param_1 & 0xfffffffffffffffe) - 1;
    uVar2 = uVar3;
    if (uVar3 == uVar4) goto LAB_0011f09c;
LAB_0011f0d0:
    pbVar5 = (byte *)param_1[2];
    param_1[1] = uVar3 + 1;
  }
  pbVar5[uVar3] = param_2;
  pbVar5[uVar3 + 1] = 0;
  return;
}


// ==== FUN_0011f100 @ 0011f100

ulong * FUN_0011f100(ulong *param_1,ulong param_2,uint param_3)

{
  ulong uVar1;
  ulong uVar2;
  ulong uVar3;
  long lVar4;
  byte *pbVar5;
  
  if (param_2 != 0) {
    uVar2 = *param_1;
    if (((byte)*param_1 & 1) == 0) {
      uVar3 = (ulong)(byte)((byte)*param_1 >> 1);
      lVar4 = 0x16;
    }
    else {
      lVar4 = (uVar2 & 0xfffffffffffffffe) - 1;
      uVar3 = param_1[1];
    }
    uVar1 = param_2 + uVar3;
    if (lVar4 - uVar3 < param_2) {
      FUN_0011ed70(param_1,lVar4,uVar1 - lVar4,uVar3,uVar3,0,0);
      uVar2 = (ulong)(byte)*param_1;
    }
    if ((uVar2 & 1) == 0) {
      pbVar5 = (byte *)((long)param_1 + 1);
    }
    else {
      pbVar5 = (byte *)param_1[2];
    }
    memset(pbVar5 + uVar3,param_3 & 0xff,param_2);
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar1 * '\x02';
    }
    else {
      param_1[1] = uVar1;
    }
    pbVar5[uVar1] = 0;
  }
  return param_1;
}


// ==== FUN_0011f1c0 @ 0011f1c0

ulong * FUN_0011f1c0(ulong *param_1,char *param_2)

{
  byte bVar1;
  size_t __n;
  long lVar2;
  ulong uVar3;
  byte *pbVar4;
  
  __n = strlen(param_2);
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar3 = (ulong)(bVar1 >> 1);
    lVar2 = 0x16;
  }
  else {
    lVar2 = (*param_1 & 0xfffffffffffffffe) - 1;
    uVar3 = param_1[1];
  }
  if (lVar2 - uVar3 < __n) {
    FUN_0011eb90(param_1,lVar2,(__n + uVar3) - lVar2,uVar3,uVar3,0,__n,param_2);
  }
  else if (__n != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar4 = (byte *)((long)param_1 + 1);
    }
    else {
      pbVar4 = (byte *)param_1[2];
    }
    memcpy(pbVar4 + uVar3,param_2,__n);
    uVar3 = __n + uVar3;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar3 * '\x02';
    }
    else {
      param_1[1] = uVar3;
    }
    pbVar4[uVar3] = 0;
  }
  return param_1;
}


// ==== FUN_0011f280 @ 0011f280

undefined8 FUN_0011f280(byte *param_1,ulong param_2,char param_3)

{
  byte bVar1;
  undefined8 in_RAX;
  ulong uVar2;
  
  bVar1 = *param_1;
  if ((bVar1 & 1) == 0) {
    uVar2 = (ulong)(bVar1 >> 1);
  }
  else {
    uVar2 = *(ulong *)(param_1 + 8);
  }
  if (uVar2 < param_2) {
    FUN_0011f100(param_1,param_2 - uVar2,(int)param_3);
    return in_RAX;
  }
  if ((bVar1 & 1) == 0) {
    param_1[param_2 + 1] = 0;
    *param_1 = (char)param_2 * '\x02';
    return in_RAX;
  }
  *(undefined1 *)(*(long *)(param_1 + 0x10) + param_2) = 0;
  *(ulong *)(param_1 + 8) = param_2;
  return in_RAX;
}


// ==== FUN_0011f2d0 @ 0011f2d0

ulong * FUN_0011f2d0(ulong *param_1,char *param_2,byte *param_3)

{
  byte bVar1;
  size_t __n;
  byte *pbVar2;
  ulong uVar3;
  long lVar4;
  ulong __n_00;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  __n = strlen(param_2);
  bVar1 = *param_3;
  if ((bVar1 & 1) == 0) {
    __n_00 = (ulong)(bVar1 >> 1);
  }
  else {
    __n_00 = *(ulong *)(param_3 + 8);
  }
  uVar3 = __n_00 + __n;
  if (0xffffffffffffffef < uVar3) {
                    /* try { // try from 0011f43d to 0011f444 has its CatchHandler @ 0011f445 */
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(param_1);
  }
  if (uVar3 < 0x17) {
    *(char *)param_1 = (char)__n * '\x02';
    pbVar2 = (byte *)((long)param_1 + 1);
  }
  else {
    uVar3 = uVar3 + 0x10 & 0xfffffffffffffff0;
                    /* try { // try from 0011f370 to 0011f3ea has its CatchHandler @ 0011f445 */
    pbVar2 = (byte *)FUN_0011e900(uVar3);
    param_1[2] = (ulong)pbVar2;
    *param_1 = uVar3 | 1;
    param_1[1] = __n;
  }
  if (__n != 0) {
    memcpy(pbVar2,param_2,__n);
  }
  pbVar2[__n] = 0;
  if ((bVar1 & 1) == 0) {
    param_3 = param_3 + 1;
  }
  else {
    param_3 = *(byte **)(param_3 + 0x10);
  }
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar3 = (ulong)(bVar1 >> 1);
    lVar4 = 0x16;
  }
  else {
    lVar4 = (*param_1 & 0xfffffffffffffffe) - 1;
    uVar3 = param_1[1];
  }
  if (lVar4 - uVar3 < __n_00) {
    FUN_0011eb90(param_1,lVar4,(uVar3 + __n_00) - lVar4,uVar3,uVar3,0,__n_00,param_3);
  }
  else if (__n_00 != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar2 = (byte *)((long)param_1 + 1);
    }
    else {
      pbVar2 = (byte *)param_1[2];
    }
    memcpy(pbVar2 + uVar3,param_3,__n_00);
    uVar3 = uVar3 + __n_00;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar3 * '\x02';
    }
    else {
      param_1[1] = uVar3;
    }
    pbVar2[uVar3] = 0;
  }
  return param_1;
}


// ==== FUN_0011f460 @ 0011f460

/* WARNING: Type propagation algorithm not settling */

ulong * FUN_0011f460(ulong *param_1,uint param_2)

{
  undefined1 *puVar1;
  long *plVar2;
  uint uVar3;
  ulong __n;
  ulong uVar4;
  char *__dest;
  long in_FS_OFFSET;
  undefined8 local_43;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  plVar2 = &local_38;
  if ((int)param_2 < 0) {
    puVar1 = (undefined1 *)((long)&local_43 + 1);
    local_43._0_1_ = 0x2d;
    param_2 = -param_2;
  }
  else {
    puVar1 = (undefined1 *)&local_43;
  }
  if ((long)plVar2 - (long)puVar1 < 10) {
    uVar3 = 0x1f;
    if ((param_2 | 1) != 0) {
      for (; (param_2 | 1) >> uVar3 == 0; uVar3 = uVar3 - 1) {
      }
    }
    uVar3 = (uVar3 ^ 0xffffffe0) * 0x4d1 + 0x9ef1 >> 0xc;
    if ((long)plVar2 - (long)puVar1 <
        (long)(ulong)((uVar3 - (param_2 < *(uint *)(&DAT_0010bc50 + (ulong)uVar3 * 4))) + 1))
    goto LAB_0011f4e9;
  }
  plVar2 = (long *)FUN_0011f660(param_2,puVar1);
LAB_0011f4e9:
  __n = (long)plVar2 - (long)&local_43;
  if (0xffffffffffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(param_1);
  }
  if (__n < 0x17) {
    *(char *)param_1 = (char)__n * '\x02';
    __dest = (char *)((long)param_1 + 1);
  }
  else {
    uVar4 = __n + 0x10 & 0xfffffffffffffff0;
    __dest = (char *)FUN_0011e900(uVar4);
    param_1[2] = (ulong)__dest;
    *param_1 = uVar4 | 1;
    param_1[1] = __n;
  }
  if (&local_43 != plVar2) {
    memcpy(__dest,&local_43,__n);
    __dest = __dest + __n;
  }
  *__dest = '\0';
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_0011f580 @ 0011f580

ulong * FUN_0011f580(ulong *param_1,undefined8 param_2)

{
  undefined1 *puVar1;
  ulong __n;
  ulong uVar2;
  char *__dest;
  long in_FS_OFFSET;
  undefined1 auStack_58 [32];
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  puVar1 = (undefined1 *)FUN_0011f8f0(param_2,auStack_58);
  __n = (long)puVar1 - (long)auStack_58;
  if (0xffffffffffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(param_1);
  }
  if (__n < 0x17) {
    *(char *)param_1 = (char)__n * '\x02';
    __dest = (char *)((long)param_1 + 1);
  }
  else {
    uVar2 = __n + 0x10 & 0xfffffffffffffff0;
    __dest = (char *)FUN_0011e900(uVar2);
    param_1[2] = (ulong)__dest;
    *param_1 = uVar2 | 1;
    param_1[1] = __n;
  }
  if (auStack_58 != puVar1) {
    memcpy(__dest,auStack_58,__n);
    __dest = __dest + __n;
  }
  *__dest = '\0';
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_0011f640 @ 0011f640

void FUN_0011f640(undefined8 *param_1)

{
  FUN_0011e970();
  *param_1 = &PTR_LAB_00140898;
  return;
}


// ==== FUN_0011f660 @ 0011f660

char * FUN_0011f660(uint param_1,char *param_2)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  ulong uVar5;
  long lVar6;
  
  if (param_1 < 100000000) {
    pcVar1 = (char *)FUN_0011f740(param_2,param_1);
    return pcVar1;
  }
  if (param_1 < 1000000000) {
    *param_2 = (char)(param_1 / 100000000) + '0';
    lVar6 = 1;
  }
  else {
    *(undefined2 *)param_2 =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)(param_1 / 100000000) * 2);
    lVar6 = 2;
  }
  uVar5 = (ulong)(param_1 % 100000000) / 10000;
  uVar3 = (uint)(uVar5 >> 2) / 0x19;
  *(undefined2 *)(param_2 + lVar6) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar3 * 2);
  iVar4 = (int)uVar5;
  *(undefined2 *)(param_2 + lVar6 + 2) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(iVar4 + uVar3 * -100 & 0xffff) * 2);
  uVar2 = param_1 % 100000000 + iVar4 * -10000;
  uVar3 = (uVar2 & 0xffff) / 100;
  *(undefined2 *)(param_2 + lVar6 + 4) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar3 * 2);
  *(undefined2 *)(param_2 + lVar6 + 6) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(uVar2 + uVar3 * -100 & 0xffff) * 2);
  return param_2 + lVar6 + 8;
}


// ==== FUN_0011f740 @ 0011f740

char * FUN_0011f740(char *param_1,uint param_2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  
  if (9999 < param_2) {
    uVar2 = (ulong)param_2 / 10000;
    if (param_2 < 1000000) {
      if (param_2 < 100000) {
        *param_1 = (char)uVar2 + '0';
        lVar3 = 1;
      }
      else {
        *(undefined2 *)param_1 =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + uVar2 * 2);
        lVar3 = 2;
      }
    }
    else if (param_2 < 10000000) {
      uVar1 = (uint)((uVar2 & 0xffff) >> 2) / 0x19;
      *param_1 = (char)uVar1 + '0';
      *(undefined2 *)(param_1 + 1) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(param_2 / 10000 + uVar1 * -100 & 0xffff) * 2);
      lVar3 = 3;
    }
    else {
      *(undefined2 *)param_1 =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + ((ulong)param_2 / 1000000) * 2);
      *(undefined2 *)(param_1 + 2) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(param_2 / 10000 + (param_2 / 1000000) * -100) * 2);
      lVar3 = 4;
    }
    *(undefined2 *)(param_1 + lVar3) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)((param_2 % 10000) / 100) * 2);
    *(undefined2 *)(param_1 + lVar3 + 2) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)((param_2 % 10000) % 100) * 2);
    return param_1 + lVar3 + 4;
  }
  if (param_2 < 100) {
    if (param_2 < 10) {
      *param_1 = (char)param_2 + '0';
      return param_1 + 1;
    }
    *(undefined2 *)param_1 =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)param_2 * 2);
    return param_1 + 2;
  }
  uVar1 = (param_2 & 0xffff) / 100;
  if (param_2 < 1000) {
    *param_1 = (char)uVar1 + '0';
    *(undefined2 *)(param_1 + 1) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)((param_2 & 0xffff) % 100) * 2);
    return param_1 + 3;
  }
  *(undefined2 *)param_1 =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar1 * 2);
  *(undefined2 *)(param_1 + 2) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(param_2 + uVar1 * -100 & 0xffff) * 2);
  return param_1 + 4;
}


// ==== FUN_0011f8f0 @ 0011f8f0

char * FUN_0011f8f0(ulong param_1,char *param_2)

{
  int iVar1;
  char *pcVar2;
  undefined2 *puVar3;
  uint uVar4;
  ulong uVar5;
  ulong uVar6;
  uint uVar7;
  ulong uVar8;
  long lVar9;
  
  if (param_1 < 100000000) {
    pcVar2 = (char *)FUN_0011f740(param_2,param_1 & 0xffffffff);
    return pcVar2;
  }
  if (param_1 < 10000000000000000) {
    uVar5 = param_1 % 100000000;
    puVar3 = (undefined2 *)FUN_0011f740(param_2,param_1 / 100000000 & 0xffffffff);
    uVar7 = (uint)(uVar5 / 10000 >> 2) / 0x19;
    *puVar3 = *(undefined2 *)
               (
               "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
               + (ulong)uVar7 * 2);
    iVar1 = (int)(uVar5 / 10000);
    puVar3[1] = *(undefined2 *)
                 (
                 "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
                 + (ulong)(iVar1 + uVar7 * -100 & 0xffff) * 2);
    uVar4 = (int)uVar5 + iVar1 * -10000;
    uVar7 = (uVar4 & 0xffff) / 100;
    puVar3[2] = *(undefined2 *)
                 (
                 "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
                 + (ulong)uVar7 * 2);
    puVar3[3] = *(undefined2 *)
                 (
                 "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
                 + (ulong)(uVar4 + uVar7 * -100 & 0xffff) * 2);
    return (char *)(puVar3 + 4);
  }
  uVar5 = param_1 / 10000000000000000;
  uVar7 = (uint)uVar5;
  if (uVar7 < 100) {
    if (uVar7 < 10) {
      *param_2 = (char)uVar5 + '0';
      lVar9 = 1;
    }
    else {
      *(undefined2 *)param_2 =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + uVar5 * 2);
      lVar9 = 2;
    }
  }
  else {
    uVar4 = (uint)(uVar5 >> 2) / 0x19;
    if (uVar7 < 1000) {
      *param_2 = (char)uVar4 + '0';
      *(undefined2 *)(param_2 + 1) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(uVar7 % 100) * 2);
      lVar9 = 3;
    }
    else {
      *(undefined2 *)param_2 =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)uVar4 * 2);
      *(undefined2 *)(param_2 + 2) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(uVar7 + uVar4 * -100 & 0xffff) * 2);
      lVar9 = 4;
    }
  }
  uVar5 = (param_1 % 10000000000000000) / 100000000;
  uVar6 = (param_1 % 10000000000000000) % 100000000;
  uVar8 = uVar5 / 10000;
  uVar7 = (uint)(uVar8 >> 2) / 0x19;
  *(undefined2 *)(param_2 + lVar9) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar7 * 2);
  iVar1 = (int)uVar8;
  *(undefined2 *)(param_2 + lVar9 + 2) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(iVar1 + uVar7 * -100 & 0xffff) * 2);
  uVar4 = (int)uVar5 + iVar1 * -10000;
  uVar7 = (uVar4 & 0xffff) / 100;
  *(undefined2 *)(param_2 + lVar9 + 4) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar7 * 2);
  *(undefined2 *)(param_2 + lVar9 + 6) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(uVar4 + uVar7 * -100 & 0xffff) * 2);
  uVar7 = (uint)(uVar6 / 10000 >> 2) / 0x19;
  *(undefined2 *)(param_2 + lVar9 + 8) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar7 * 2);
  iVar1 = (int)(uVar6 / 10000);
  *(undefined2 *)(param_2 + lVar9 + 10) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(iVar1 + uVar7 * -100 & 0xffff) * 2);
  uVar4 = (int)uVar6 + iVar1 * -10000;
  uVar7 = (uVar4 & 0xffff) / 100;
  *(undefined2 *)(param_2 + lVar9 + 0xc) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar7 * 2);
  *(undefined2 *)(param_2 + lVar9 + 0xe) =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(uVar4 + uVar7 * -100 & 0xffff) * 2);
  return param_2 + lVar9 + 0x10;
}


// ==== FUN_0011fbd0 @ 0011fbd0

ulong * FUN_0011fbd0(ulong *param_1,undefined8 param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char *pcVar4;
  size_t __n;
  ulong uVar5;
  char *__s;
  long in_FS_OFFSET;
  char acStack_438 [1032];
  long local_30;
  
  __s = acStack_438;
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  piVar3 = (int *)__errno();
  iVar1 = *piVar3;
  pcVar4 = strerror_r(param_3,acStack_438,0x400);
  iVar2 = (int)pcVar4;
  if (iVar2 != 0) {
    if (iVar2 == -1) {
      iVar2 = *piVar3;
    }
    if (iVar2 != 0x16) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    __s = "";
  }
  if (*__s == '\0') {
    FUN_001201b0(acStack_438);
    __s = acStack_438;
  }
  *piVar3 = iVar1;
  __n = strlen(__s);
  if (0xffffffffffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(param_1);
  }
  if (__n < 0x17) {
    *(char *)param_1 = (char)__n * '\x02';
    pcVar4 = (char *)((long)param_1 + 1);
    if (__n == 0) goto LAB_0011fca4;
  }
  else {
    uVar5 = __n + 0x10 & 0xfffffffffffffff0;
    pcVar4 = (char *)FUN_0011e900(uVar5);
    param_1[2] = (ulong)pcVar4;
    *param_1 = uVar5 | 1;
    param_1[1] = __n;
  }
  memcpy(pcVar4,__s,__n);
LAB_0011fca4:
  pcVar4[__n] = '\0';
  if (*(long *)(in_FS_OFFSET + 0x28) != local_30) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_0011fe60 @ 0011fe60

undefined8 * FUN_0011fe60(undefined8 *param_1,int *param_2,byte *param_3)

{
  undefined8 uVar1;
  int iVar2;
  undefined1 *puVar3;
  long in_FS_OFFSET;
  byte local_38;
  undefined1 local_37 [7];
  ulong local_30;
  undefined1 *local_28;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  iVar2 = *param_2;
  if (iVar2 == 0) goto LAB_0011fef4;
  if ((*param_3 & 1) == 0) {
    if (*param_3 >> 1 != 0) goto LAB_0011fea0;
  }
  else if (*(long *)(param_3 + 8) != 0) {
LAB_0011fea0:
    FUN_0011f1c0(param_3,&DAT_0010a7a7);
    iVar2 = *param_2;
  }
  (**(code **)(**(long **)(param_2 + 2) + 0x30))(&local_38,*(long **)(param_2 + 2),iVar2);
  if ((local_38 & 1) == 0) {
    local_30 = (ulong)(local_38 >> 1);
    puVar3 = local_37;
  }
  else {
    puVar3 = local_28;
  }
                    /* try { // try from 0011fedc to 0011fee3 has its CatchHandler @ 0011ff33 */
  FUN_0011ef80(param_3,puVar3,local_30);
  if ((local_38 & 1) != 0) {
    free(local_28);
  }
LAB_0011fef4:
  param_1[2] = *(undefined8 *)(param_3 + 0x10);
  uVar1 = *(undefined8 *)(param_3 + 8);
  *param_1 = *(undefined8 *)param_3;
  param_1[1] = uVar1;
  param_3[0] = 0;
  param_3[1] = 0;
  param_3[2] = 0;
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  param_3[6] = 0;
  param_3[7] = 0;
  param_3[8] = 0;
  param_3[9] = 0;
  param_3[10] = 0;
  param_3[0xb] = 0;
  param_3[0xc] = 0;
  param_3[0xd] = 0;
  param_3[0xe] = 0;
  param_3[0xf] = 0;
  param_3[0x10] = 0;
  param_3[0x11] = 0;
  param_3[0x12] = 0;
  param_3[0x13] = 0;
  param_3[0x14] = 0;
  param_3[0x15] = 0;
  param_3[0x16] = 0;
  param_3[0x17] = 0;
  if (*(long *)(in_FS_OFFSET + 0x28) != local_20) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_0011ff50 @ 0011ff50

void FUN_0011ff50(undefined8 *param_1,undefined4 param_2,undefined8 param_3,char *param_4)

{
  size_t __n;
  void *__dest;
  ulong uVar1;
  long in_FS_OFFSET;
  undefined8 local_70;
  size_t local_68;
  void *local_60;
  byte local_58 [16];
  void *local_48;
  undefined4 local_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  long local_30;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  local_40 = param_2;
  uStack_38 = param_3;
  __n = strlen(param_4);
  if (0xffffffffffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0011eb20(&local_70);
  }
  if (__n < 0x17) {
    local_70 = CONCAT71(local_70._1_7_,(char)__n * '\x02');
    __dest = (void *)((long)&local_70 + 1);
    if (__n == 0) goto LAB_0011ffe1;
  }
  else {
    uVar1 = __n + 0x10 & 0xfffffffffffffff0;
    __dest = (void *)FUN_0011e900(uVar1);
    local_70 = uVar1 | 1;
    local_68 = __n;
    local_60 = __dest;
  }
  memcpy(__dest,param_4,__n);
LAB_0011ffe1:
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 0011ffe6 to 0011fff9 has its CatchHandler @ 0012009a */
  FUN_0011fe60(local_58,&local_40,&local_70);
                    /* try { // try from 0011fffa to 00120006 has its CatchHandler @ 0012006e */
  FUN_0011ea00(param_1,local_58);
  if ((local_58[0] & 1) != 0) {
    free(local_48);
  }
  if ((local_70 & 1) != 0) {
    free(local_60);
  }
  *param_1 = &PTR_LAB_0013e470;
  *(undefined4 *)(param_1 + 2) = local_40;
  *(undefined4 *)((long)param_1 + 0x14) = uStack_3c;
  *(undefined4 *)(param_1 + 3) = (undefined4)uStack_38;
  *(undefined4 *)((long)param_1 + 0x1c) = uStack_38._4_4_;
  if (*(long *)(in_FS_OFFSET + 0x28) != local_30) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_001200f0 @ 001200f0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_001200f0(undefined4 param_1,undefined8 param_2)

{
  int iVar1;
  undefined8 uVar2;
  
  uVar2 = FUN_001202b0(0x20);
  if (DAT_001450a8 == '\0') goto LAB_0012013a;
  do {
                    /* try { // try from 00120110 to 00120123 has its CatchHandler @ 00120166 */
    FUN_0011ff50(uVar2,param_1,&DAT_001450a0,param_2);
    FUN_00120320(uVar2,&DAT_0013e488,&LAB_001200c0);
LAB_0012013a:
    iVar1 = FUN_00120630(&DAT_001450a8);
    if (iVar1 != 0) {
      _DAT_001450a0 = &PTR_LAB_0013e538;
      FUN_00120770(&DAT_001450a8);
    }
  } while( true );
}


// ==== FUN_001201b0 @ 001201b0

void FUN_001201b0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 char *param_9)

{
  char in_AL;
  undefined8 in_R8;
  undefined8 in_R9;
  long in_FS_OFFSET;
  undefined1 uStack0000000000000008;
  undefined1 auStack_d8 [32];
  undefined8 local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  undefined8 local_98;
  undefined8 local_88;
  undefined8 local_78;
  undefined8 local_68;
  undefined8 local_58;
  undefined8 local_48;
  undefined8 local_38;
  undefined8 local_28;
  undefined1 *local_20;
  undefined1 *local_18;
  long local_8;
  
  local_18 = auStack_d8;
  if (in_AL != '\0') {
    local_a8 = param_1;
    local_98 = param_2;
    local_88 = param_3;
    local_78 = param_4;
    local_68 = param_5;
    local_58 = param_6;
    local_48 = param_7;
    local_38 = param_8;
  }
  local_8 = *(long *)(in_FS_OFFSET + 0x28);
  local_20 = &uStack0000000000000008;
  local_28 = 0x3000000020;
  local_b8 = in_R8;
  local_b0 = in_R9;
  vsnprintf(param_9,0x400,"Unknown error %d",&local_28);
  if (*(long *)(in_FS_OFFSET + 0x28) != local_8) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00120270 @ 00120270

void FUN_00120270(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_00118290("vector");
}


// ==== FUN_00120280 @ 00120280

undefined8 FUN_00120280(undefined8 *param_1)

{
  return *param_1;
}


// ==== FUN_00120290 @ 00120290

undefined8 FUN_00120290(ulong *param_1)

{
  return CONCAT71((uint7)(*param_1 >> 0x10),*param_1 >> 8 == 0x434c4e47432b2b);
}


// ==== FUN_001202b0 @ 001202b0

long FUN_001202b0(long param_1)

{
  void *__s;
  ulong __n;
  
  __n = param_1 + 0x8fU & 0xfffffffffffffff0;
                    /* try { // try from 001202c2 to 001202c9 has its CatchHandler @ 001202f3 */
  __s = (void *)FUN_00135240(__n);
  if (__s == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_00120930();
  }
  memset(__s,0,__n);
  return (long)__s + 0x80;
}


// ==== FUN_00120300 @ 00120300

undefined8 FUN_00120300(long param_1)

{
  undefined8 in_RAX;
  
                    /* try { // try from 00120305 to 00120309 has its CatchHandler @ 0012030c */
  FUN_00135390(param_1 + -0x80);
  return in_RAX;
}


// ==== FUN_00120320 @ 00120320

void FUN_00120320(long param_1,undefined8 param_2,undefined8 param_3)

{
  code *pcVar1;
  long lVar2;
  undefined8 uVar3;
  
  lVar2 = FUN_00120610();
  uVar3 = FUN_00120920();
  *(undefined8 *)(param_1 + -0x60) = uVar3;
  uVar3 = FUN_001209a0();
  *(undefined8 *)(param_1 + -0x58) = uVar3;
  *(undefined8 *)(param_1 + -0x70) = param_2;
  *(undefined8 *)(param_1 + -0x68) = param_3;
  FUN_00120390(param_1 + -0x20);
  *(undefined8 *)(param_1 + -0x78) = 1;
  *(int *)(lVar2 + 8) = *(int *)(lVar2 + 8) + 1;
  *(undefined1 **)(param_1 + -0x18) = &LAB_001203a0;
  FUN_00136020(param_1 + -0x20);
  FUN_001203f0(param_1 + -0x80);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_00120390 @ 00120390

void FUN_00120390(undefined8 *param_1)

{
  *param_1 = 0x434c4e47432b2b00;
  return;
}


// ==== FUN_001203f0 @ 001203f0

void FUN_001203f0(long param_1)

{
  code *pcVar1;
  
  FUN_00120410(param_1 + 0x60);
  FUN_001209b0(*(undefined8 *)(param_1 + 0x28));
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_00120410 @ 00120410

ulong * FUN_00120410(ulong *param_1)

{
  ulong *puVar1;
  ulong uVar2;
  long *plVar3;
  int iVar4;
  
  uVar2 = *param_1;
                    /* try { // try from 0012041a to 0012041e has its CatchHandler @ 0012047e */
  plVar3 = (long *)FUN_00120610();
  puVar1 = param_1 + -0xc;
  if (uVar2 >> 8 == 0x434c4e47432b2b) {
    iVar4 = -(int)param_1[-5];
    if (iVar4 < 0) {
      iVar4 = (int)param_1[-5];
    }
    *(int *)(param_1 + -5) = iVar4 + 1;
    if ((ulong *)*plVar3 != puVar1) {
      param_1[-6] = (ulong)*plVar3;
      *plVar3 = (long)puVar1;
    }
    *(int *)(plVar3 + 1) = (int)plVar3[1] + -1;
    param_1 = (ulong *)param_1[-1];
  }
  else {
    if (*plVar3 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)puVar1;
    param_1 = param_1 + 4;
  }
  return param_1;
}


// ==== FUN_00120490 @ 00120490

void FUN_00120490(void)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  long lVar4;
  
  plVar2 = (long *)FUN_00120620();
  lVar3 = *plVar2;
  if (lVar3 == 0) {
    return;
  }
  if (*(ulong *)(lVar3 + 0x60) >> 8 == 0x434c4e47432b2b) {
    iVar1 = *(int *)(lVar3 + 0x38);
    if (-1 < iVar1) {
      *(int *)(lVar3 + 0x38) = iVar1 + -1;
      if (iVar1 + -1 != 0) {
        return;
      }
      *plVar2 = *(long *)(lVar3 + 0x30);
      lVar4 = lVar3;
      if (*(char *)(lVar3 + 0x60) == '\x01') {
        lVar4 = *(long *)(lVar3 + 8) + -0x80;
        FUN_00135390(lVar3);
      }
      LOCK();
      plVar2 = (long *)(lVar4 + 8);
      *plVar2 = *plVar2 + -1;
      UNLOCK();
      if (*plVar2 != 0) {
        return;
      }
      if (*(code **)(lVar4 + 0x18) != (code *)0x0) {
                    /* try { // try from 00120502 to 00120503 has its CatchHandler @ 00120534 */
        (**(code **)(lVar4 + 0x18))(lVar4 + 0x80);
      }
                    /* try { // try from 00120504 to 0012050b has its CatchHandler @ 0012053c */
      FUN_00135390(lVar4);
      return;
    }
    *(int *)(lVar3 + 0x38) = iVar1 + 1;
    if (iVar1 + 1 != 0) {
      return;
    }
    lVar3 = *(long *)(lVar3 + 0x30);
  }
  else {
    FUN_001363e0(lVar3 + 0x60);
    lVar3 = 0;
  }
  *plVar2 = lVar3;
  return;
}


// ==== FUN_00120550 @ 00120550

void FUN_00120550(void)

{
  long lVar1;
  ulong uVar2;
  long *plVar3;
  undefined8 uVar4;
  int iVar5;
  ulong uVar6;
  
  plVar3 = (long *)FUN_00120610();
  lVar1 = *plVar3;
  if (lVar1 != 0) {
    uVar6 = *(ulong *)(lVar1 + 0x60) & 0xffffffffffffff00;
    if (uVar6 == 0x434c4e47432b2b00) {
      *(int *)(lVar1 + 0x38) = -*(int *)(lVar1 + 0x38);
      *(int *)(plVar3 + 1) = (int)plVar3[1] + 1;
    }
    else {
      *plVar3 = 0;
    }
    FUN_00136020((ulong *)(lVar1 + 0x60));
    uVar2 = *(ulong *)(lVar1 + 0x60);
                    /* try { // try from 001205a4 to 001205a8 has its CatchHandler @ 00120604 */
    plVar3 = (long *)FUN_00120610();
    if ((uVar2 & 0xffffffffffffff00) == 0x434c4e47432b2b00) {
      iVar5 = -*(int *)(lVar1 + 0x38);
      if (iVar5 < 0) {
        iVar5 = *(int *)(lVar1 + 0x38);
      }
      *(int *)(lVar1 + 0x38) = iVar5 + 1;
      if (*plVar3 != lVar1) {
        *(long *)(lVar1 + 0x30) = *plVar3;
        *plVar3 = lVar1;
      }
      *(int *)(plVar3 + 1) = (int)plVar3[1] + -1;
    }
    else {
      if (*plVar3 != 0) goto LAB_00120566;
      *plVar3 = lVar1;
    }
    if (uVar6 == 0x434c4e47432b2b00) {
      uVar4 = FUN_001209b0(*(undefined8 *)(lVar1 + 0x28));
                    /* catch() { ... } // from try @ 001205a4 with catch @ 00120604 */
                    /* WARNING: Subroutine does not return */
      FUN_00134dc0(uVar4);
    }
  }
LAB_00120566:
                    /* WARNING: Subroutine does not return */
  FUN_00120930();
}


// ==== FUN_00120610 @ 00120610

void FUN_00120610(void)

{
  FUN_00135d80(&DAT_00144e70);
  return;
}


// ==== FUN_00120620 @ 00120620

void FUN_00120620(void)

{
  FUN_00135d80(&DAT_00144e70);
  return;
}


// ==== FUN_00120630 @ 00120630

undefined8 FUN_00120630(char *param_1)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  long lVar4;
  undefined8 uVar5;
  int unaff_R14D;
  
  uVar5 = 0;
  if (*param_1 == '\0') {
    iVar3 = pthread_mutex_lock((pthread_mutex_t *)&DAT_001450b0);
    if (iVar3 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120800("%s failed to acquire mutex","__cxa_guard_acquire");
    }
    bVar1 = param_1[1];
    if ((bVar1 & 2) != 0) {
      iVar3 = *(int *)(param_1 + 4);
                    /* try { // try from 00120668 to 00120673 has its CatchHandler @ 00120725 */
      lVar4 = syscall(0xba);
      unaff_R14D = (int)lVar4;
      if (iVar3 == unaff_R14D) {
                    /* try { // try from 00120717 to 00120724 has its CatchHandler @ 00120725 */
                    /* WARNING: Subroutine does not return */
        FUN_00120800("__cxa_guard_acquire detected recursive initialization");
      }
    }
    while (bVar2 = param_1[1], (bVar2 & 2) != 0) {
      param_1[1] = bVar2 | 4;
                    /* try { // try from 0012069d to 001206a7 has its CatchHandler @ 0012072f */
      pthread_cond_wait((pthread_cond_t *)&DAT_001450d8,(pthread_mutex_t *)&DAT_001450b0);
    }
    uVar5 = 0;
    if (bVar2 != 1) {
      if ((bVar1 & 2) == 0) {
                    /* try { // try from 001206b6 to 001206c1 has its CatchHandler @ 00120725 */
        lVar4 = syscall(0xba);
        unaff_R14D = (int)lVar4;
      }
      *(int *)(param_1 + 4) = unaff_R14D;
      param_1[1] = '\x02';
      uVar5 = 1;
    }
                    /* try { // try from 001206d2 to 001206dd has its CatchHandler @ 00120727 */
    iVar3 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_001450b0);
    if (iVar3 != 0) {
                    /* try { // try from 00120702 to 00120716 has its CatchHandler @ 00120727 */
                    /* WARNING: Subroutine does not return */
      FUN_00120800("%s failed to release mutex","__cxa_guard_acquire");
    }
  }
  return uVar5;
}


// ==== FUN_00120770 @ 00120770

void FUN_00120770(undefined1 *param_1)

{
  byte bVar1;
  int iVar2;
  char *pcVar3;
  
  *param_1 = 1;
  iVar2 = pthread_mutex_lock((pthread_mutex_t *)&DAT_001450b0);
  if (iVar2 != 0) {
    pcVar3 = "%s failed to acquire mutex";
LAB_001207e3:
                    /* WARNING: Subroutine does not return */
    FUN_00120800(pcVar3,"__cxa_guard_release");
  }
  bVar1 = param_1[1];
  param_1[1] = 1;
                    /* try { // try from 00120791 to 0012079c has its CatchHandler @ 001207f1 */
  iVar2 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_001450b0);
  if (iVar2 != 0) {
                    /* try { // try from 001207c7 to 001207db has its CatchHandler @ 001207f1 */
                    /* WARNING: Subroutine does not return */
    FUN_00120800("%s failed to release mutex","__cxa_guard_release");
  }
  if ((bVar1 & 4) != 0) {
    iVar2 = pthread_cond_broadcast((pthread_cond_t *)&DAT_001450d8);
    if (iVar2 != 0) {
      pcVar3 = "%s failed to broadcast";
      goto LAB_001207e3;
    }
  }
  return;
}


// ==== FUN_00120800 @ 00120800

void FUN_00120800(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 char *param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined1 param_15)

{
  char in_AL;
  char *local_120;
  undefined8 local_118;
  undefined1 *local_110;
  undefined1 *local_108;
  undefined8 local_f8;
  undefined1 *local_f0;
  undefined1 *local_e8;
  undefined1 local_d8 [8];
  undefined8 local_d0;
  undefined8 local_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  undefined8 local_98;
  undefined8 local_88;
  undefined8 local_78;
  undefined8 local_68;
  undefined8 local_58;
  undefined8 local_48;
  undefined8 local_38;
  
  if (in_AL != '\0') {
    local_a8 = param_1;
    local_98 = param_2;
    local_88 = param_3;
    local_78 = param_4;
    local_68 = param_5;
    local_58 = param_6;
    local_48 = param_7;
    local_38 = param_8;
  }
  local_f8 = 0x3000000008;
  local_f0 = &param_15;
  local_e8 = local_d8;
  local_d0 = param_10;
  local_c8 = param_11;
  local_c0 = param_12;
  local_b8 = param_13;
  local_b0 = param_14;
  vfprintf((FILE *)0x146348,param_9,&local_f8);
  fputc(10,(FILE *)0x146348);
  local_118 = 0x3000000008;
  local_110 = &param_15;
  local_108 = local_d8;
  vasprintf(&local_120,param_9,&local_118);
  android_set_abort_message(local_120);
  openlog("libc++abi",0,0);
  syslog(2,"%s",local_120);
  closelog();
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_00120920 @ 00120920

undefined * FUN_00120920(void)

{
  return PTR_LAB_00144e98;
}


// ==== FUN_00120930 @ 00120930

void FUN_00120930(void)

{
  char cVar1;
  long *plVar2;
  undefined8 uVar3;
  long unaff_RBX;
  
                    /* try { // try from 00120931 to 00120935 has its CatchHandler @ 00120970 */
  plVar2 = (long *)FUN_00120620();
  if ((plVar2 != (long *)0x0) && (unaff_RBX = *plVar2, unaff_RBX != 0)) goto LAB_00120952;
  do {
    FUN_001209b0(PTR_LAB_00144e90);
LAB_00120952:
                    /* try { // try from 00120956 to 0012095a has its CatchHandler @ 00120968 */
    cVar1 = FUN_00120290(unaff_RBX + 0x60);
  } while (cVar1 == '\0');
  uVar3 = FUN_001209b0(*(undefined8 *)(unaff_RBX + 0x28));
                    /* catch(type#1 @ 00000000) { ... } // from try @ 00120956 with catch @ 00120968
                        */
                    /* WARNING: Subroutine does not return */
  FUN_00117910(uVar3);
}


// ==== FUN_00120980 @ 00120980

void FUN_00120980(code *param_1)

{
  (*param_1)();
                    /* WARNING: Subroutine does not return */
  FUN_00120800("unexpected_handler unexpectedly returned");
}


// ==== FUN_001209a0 @ 001209a0

undefined * FUN_001209a0(void)

{
  return PTR_LAB_00144e90;
}


// ==== FUN_001209b0 @ 001209b0

void FUN_001209b0(code *param_1)

{
                    /* try { // try from 001209b1 to 001209c0 has its CatchHandler @ 001209c1 */
  (*param_1)();
                    /* WARNING: Subroutine does not return */
  FUN_00120800("terminate_handler unexpectedly returned");
}


// ==== FUN_001209f0 @ 001209f0

undefined8 FUN_001209f0(void)

{
  return DAT_00145108;
}


// ==== FUN_00120b30 @ 00120b30

void * FUN_00120b30(char *param_1,void *param_2,ulong *param_3,undefined4 *param_4)

{
  char *pcVar1;
  undefined8 *puVar2;
  size_t sVar3;
  long *plVar4;
  undefined8 *puVar5;
  undefined4 uVar6;
  char *pcVar7;
  long lVar8;
  void *pvVar9;
  ulong uVar10;
  char *pcVar11;
  char *pcVar12;
  char *pcVar13;
  long in_FS_OFFSET;
  void *local_13a8;
  ulong uStack_13a0;
  size_t local_1398;
  undefined8 local_1390;
  long local_1380;
  char *local_1378;
  char *local_1370;
  undefined8 *local_1368;
  undefined8 *local_1360;
  undefined8 **local_1358;
  undefined8 local_1350;
  undefined8 uStack_1348;
  undefined8 local_1340;
  undefined8 uStack_1338;
  undefined8 local_1330;
  undefined8 uStack_1328;
  undefined8 local_1320;
  undefined8 uStack_1318;
  undefined8 local_1310;
  undefined8 uStack_1308;
  undefined8 local_1300;
  undefined8 uStack_12f8;
  undefined8 local_12f0;
  undefined8 uStack_12e8;
  undefined8 local_12e0;
  undefined8 uStack_12d8;
  undefined8 local_12d0;
  undefined8 uStack_12c8;
  undefined8 local_12c0;
  undefined8 uStack_12b8;
  undefined8 local_12b0;
  undefined8 uStack_12a8;
  undefined8 local_12a0;
  undefined8 uStack_1298;
  undefined8 local_1290;
  undefined8 uStack_1288;
  undefined8 local_1280;
  undefined8 uStack_1278;
  undefined8 local_1270;
  undefined8 uStack_1268;
  undefined8 local_1260;
  undefined8 uStack_1258;
  undefined8 *local_1250;
  undefined8 *local_1248;
  undefined8 **local_1240;
  undefined8 local_1238;
  undefined8 uStack_1230;
  undefined8 local_1228;
  undefined8 uStack_1220;
  undefined8 local_1218;
  undefined8 uStack_1210;
  undefined8 local_1208;
  undefined8 uStack_1200;
  undefined8 local_11f8;
  undefined8 uStack_11f0;
  undefined8 local_11e8;
  undefined8 uStack_11e0;
  undefined8 local_11d8;
  undefined8 uStack_11d0;
  undefined8 local_11c8;
  undefined8 uStack_11c0;
  undefined8 local_11b8;
  undefined8 uStack_11b0;
  undefined8 local_11a8;
  undefined8 uStack_11a0;
  undefined8 local_1198;
  undefined8 uStack_1190;
  undefined8 local_1188;
  undefined8 uStack_1180;
  undefined8 local_1178;
  undefined8 uStack_1170;
  undefined8 local_1168;
  undefined8 uStack_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined8 local_1148;
  undefined8 uStack_1140;
  undefined8 *local_1138;
  undefined8 *local_1130;
  undefined8 **local_1128;
  undefined8 local_1120;
  undefined8 uStack_1118;
  undefined8 local_1110;
  undefined8 uStack_1108;
  undefined8 local_1100;
  undefined8 uStack_10f8;
  undefined8 local_10f0;
  undefined8 uStack_10e8;
  undefined8 *local_10e0;
  undefined8 *local_10d8;
  undefined8 **local_10d0;
  undefined8 local_10c8;
  undefined8 uStack_10c0;
  undefined8 local_10b8;
  undefined8 uStack_10b0;
  undefined8 *local_10a8;
  undefined8 *local_10a0;
  undefined2 *local_1098;
  undefined8 local_1090;
  undefined8 uStack_1088;
  undefined8 local_1080;
  undefined8 uStack_1078;
  undefined2 local_1070 [4];
  undefined8 local_1068;
  undefined8 local_1060;
  undefined4 local_1058;
  undefined8 local_1048;
  undefined8 uStack_1040;
  undefined8 *local_48;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  if ((param_1 == (char *)0x0) || ((param_2 != (void *)0x0 && (param_3 == (ulong *)0x0)))) {
    if (param_4 == (undefined4 *)0x0) {
      pvVar9 = (void *)0x0;
    }
    else {
      *param_4 = 0xfffffffd;
      pvVar9 = (void *)0x0;
    }
    goto LAB_00120fe2;
  }
  sVar3 = strlen(param_1);
  local_1370 = param_1 + sVar3;
  local_1368 = &local_1350;
  local_1358 = &local_1250;
  local_1350 = 0;
  uStack_1348 = 0;
  local_1340 = 0;
  uStack_1338 = 0;
  local_1330 = 0;
  uStack_1328 = 0;
  local_1320 = 0;
  uStack_1318 = 0;
  local_1310 = 0;
  uStack_1308 = 0;
  local_1300 = 0;
  uStack_12f8 = 0;
  local_12f0 = 0;
  uStack_12e8 = 0;
  local_12e0 = 0;
  uStack_12d8 = 0;
  local_12d0 = 0;
  uStack_12c8 = 0;
  local_12c0 = 0;
  uStack_12b8 = 0;
  local_12b0 = 0;
  uStack_12a8 = 0;
  local_12a0 = 0;
  uStack_1298 = 0;
  local_1290 = 0;
  uStack_1288 = 0;
  local_1280 = 0;
  uStack_1278 = 0;
  local_1270 = 0;
  uStack_1268 = 0;
  local_1260 = 0;
  uStack_1258 = 0;
  local_1250 = &local_1238;
  local_1240 = &local_1138;
  local_1238 = 0;
  uStack_1230 = 0;
  local_1228 = 0;
  uStack_1220 = 0;
  local_1218 = 0;
  uStack_1210 = 0;
  local_1208 = 0;
  uStack_1200 = 0;
  local_11f8 = 0;
  uStack_11f0 = 0;
  local_11e8 = 0;
  uStack_11e0 = 0;
  local_11d8 = 0;
  uStack_11d0 = 0;
  local_11c8 = 0;
  uStack_11c0 = 0;
  local_11b8 = 0;
  uStack_11b0 = 0;
  local_11a8 = 0;
  uStack_11a0 = 0;
  local_1198 = 0;
  uStack_1190 = 0;
  local_1188 = 0;
  uStack_1180 = 0;
  local_1178 = 0;
  uStack_1170 = 0;
  local_1168 = 0;
  uStack_1160 = 0;
  local_1158 = 0;
  uStack_1150 = 0;
  local_1148 = 0;
  uStack_1140 = 0;
  local_1138 = &local_1120;
  local_1128 = &local_10e0;
  local_1120 = 0;
  uStack_1118 = 0;
  local_1110 = 0;
  uStack_1108 = 0;
  local_1100 = 0;
  uStack_10f8 = 0;
  local_10f0 = 0;
  uStack_10e8 = 0;
  local_10e0 = &local_10c8;
  local_10d0 = &local_10a8;
  local_10c8 = 0;
  uStack_10c0 = 0;
  local_10b8 = 0;
  uStack_10b0 = 0;
  local_10a8 = &local_1090;
  local_1098 = local_1070;
  local_1080 = 0;
  uStack_1078 = 0;
  local_1090 = 0;
  uStack_1088 = 0;
  local_1070[0] = 1;
  local_1068 = 0xffffffffffffffff;
  local_1058 = 0;
  local_1060 = 0;
  local_1048 = 0;
  uStack_1040 = 0;
  local_13a8 = (void *)0x0;
  uStack_13a0 = 0;
  local_1398 = 0;
  local_1390 = 0xffffffffffffffff;
  local_1360 = local_1368;
  local_1248 = local_1250;
  local_1130 = local_1138;
  local_10d8 = local_10e0;
  local_10a0 = local_10a8;
  local_48 = &local_1048;
  if ((sVar3 < 2) || (*param_1 != '_')) {
LAB_00120f19:
    local_1378 = param_1;
    plVar4 = (long *)FUN_00121da0(&local_1378);
    if (local_1370 == local_1378) {
LAB_001211f4:
      if (plVar4 != (long *)0x0) goto LAB_001211fd;
    }
    uVar6 = 0xfffffffe;
LAB_00120f3b:
    pvVar9 = (void *)0x0;
  }
  else {
    lVar8 = 2;
    if (param_1[1] != 'Z') {
      if ((sVar3 < 3) || (param_1[1] != '_')) goto LAB_00120f19;
      lVar8 = 3;
      if (param_1[2] == 'Z') goto LAB_00120e32;
      if ((sVar3 < 4) ||
         (((param_1[2] != '_' || (lVar8 = 4, param_1[3] != 'Z')) &&
          ((sVar3 < 5 ||
           (((param_1[2] != '_' || (param_1[3] != '_')) || (lVar8 = 5, param_1[4] != 'Z'))))))))
      goto LAB_00120f19;
      local_1378 = param_1 + lVar8;
      local_1380 = FUN_001213e0();
      if ((((local_1380 == 0) || ((ulong)((long)local_1370 - (long)local_1378) < 0xd)) ||
          ((((*local_1378 != '_' || ((local_1378[1] != 'b' || (local_1378[2] != 'l')))) ||
            (local_1378[3] != 'o')) ||
           (((((local_1378[4] != 'c' || (local_1378[5] != 'k')) || (local_1378[6] != '_')) ||
             ((local_1378[7] != 'i' || (local_1378[8] != 'n')))) ||
            ((local_1378[9] != 'v' || ((local_1378[10] != 'o' || (local_1378[0xb] != 'k'))))))))))
         || (local_1378[0xc] != 'e')) {
LAB_001211f1:
        plVar4 = (long *)0x0;
      }
      else {
        pcVar1 = local_1378 + 0xd;
        if (pcVar1 != local_1370) {
          pcVar12 = pcVar1;
          if (*pcVar1 == '_') {
            pcVar12 = local_1378 + 0xe;
          }
          local_1378 = pcVar12;
          pcVar12 = local_1370;
          if (local_1370 == local_1378) {
            pcVar7 = (char *)0x0;
            pcVar13 = (char *)0x0;
          }
          else {
            pcVar11 = local_1378;
            if ((int)*local_1378 - 0x3aU < 0xfffffff6) {
              pcVar7 = (char *)0x0;
              pcVar12 = local_1378;
              pcVar13 = (char *)0x0;
            }
            else {
              do {
                pcVar11 = pcVar11 + 1;
                pcVar7 = local_1378;
                if (pcVar11 == local_1370) {
                  pcVar13 = local_1370;
                  local_1378 = pcVar11;
                  goto LAB_001211bd;
                }
              } while (0xfffffff5 < (int)*pcVar11 - 0x3aU);
              pcVar12 = pcVar11;
              pcVar13 = pcVar11;
              local_1378 = pcVar11;
            }
          }
LAB_001211bd:
          if ((*pcVar1 == '_') && (pcVar7 == pcVar13)) goto LAB_001211f1;
          pcVar1 = local_1378;
          if (local_1370 != pcVar12) {
            if (*pcVar12 != '.') goto LAB_001211f1;
            local_1378 = local_1370;
            pcVar1 = local_1378;
          }
        }
        local_1378 = pcVar1;
        plVar4 = (long *)FUN_00121cf0(&local_1378,"invocation function for block in ",&local_1380);
      }
      goto LAB_001211f4;
    }
LAB_00120e32:
    local_1378 = param_1 + lVar8;
                    /* try { // try from 00120e3a to 0012125a has its CatchHandler @ 001212e0 */
    plVar4 = (long *)FUN_001213e0(&local_1378);
    puVar2 = local_48;
    pcVar12 = local_1370;
    pcVar1 = local_1378;
    uVar6 = 0xfffffffe;
    if (plVar4 == (long *)0x0) goto LAB_00120f3b;
    if (local_1370 != local_1378) {
      if (*local_1378 != '.') goto LAB_00120f3b;
      lVar8 = local_48[1];
      if (lVar8 - 0xfc0U < 0xfffffffffffff010) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (undefined8 *)0x0) goto LAB_001212d6;
        *puVar5 = puVar2;
        puVar5[1] = 0;
        lVar8 = 0;
        local_48 = puVar5;
      }
      local_48[1] = lVar8 + 0x30;
      *(undefined4 *)((long)local_48 + lVar8 + 0x18) = 0x1010101;
      *(undefined ***)((long)local_48 + lVar8 + 0x10) = &PTR_LAB_0013ffe8;
      *(long **)((long)local_48 + lVar8 + 0x20) = plVar4;
      plVar4 = (long *)((long)local_48 + lVar8 + 0x10);
      *(char **)((long)local_48 + lVar8 + 0x28) = pcVar1;
      *(char **)((long)local_48 + lVar8 + 0x30) = pcVar12;
      local_1378 = local_1370;
    }
LAB_001211fd:
    if (param_2 == (void *)0x0) {
      uVar10 = 0x400;
      param_2 = malloc(0x400);
      if (param_2 == (void *)0x0) {
        uVar6 = 0xffffffff;
        goto LAB_00120f3b;
      }
    }
    else {
      uVar10 = *param_3;
    }
    uStack_13a0 = 0;
    local_13a8 = param_2;
    local_1398 = uVar10;
    (**(code **)(*plVar4 + 0x20))(plVar4,&local_13a8);
    if (*(char *)((long)plVar4 + 9) != '\x01') {
      (**(code **)(*plVar4 + 0x28))(plVar4,&local_13a8);
    }
    uVar10 = uStack_13a0 + 1;
    if (local_1398 <= uVar10) {
      local_1398 = local_1398 * 2;
      if (local_1398 < uVar10) {
        local_1398 = uVar10;
      }
      local_13a8 = realloc(local_13a8,local_1398);
      if (local_13a8 == (void *)0x0) {
LAB_001212d6:
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
      uVar10 = uStack_13a0 + 1;
    }
    *(undefined1 *)((long)local_13a8 + uStack_13a0) = 0;
    if (param_3 != (ulong *)0x0) {
      *param_3 = uVar10;
    }
    uVar6 = 0;
    pvVar9 = local_13a8;
    uStack_13a0 = uVar10;
  }
  if (param_4 != (undefined4 *)0x0) {
    *param_4 = uVar6;
  }
  while (puVar2 = local_48, puVar2 != (undefined8 *)0x0) {
    local_48 = (undefined8 *)*puVar2;
    if (&local_1048 != puVar2) {
      free(puVar2);
    }
  }
  local_1048 = 0;
  uStack_1040 = 0;
  local_48 = &local_1048;
  if (local_10a8 != &local_1090) {
    free(local_10a8);
  }
  if (local_10e0 != &local_10c8) {
    free(local_10e0);
  }
  if (local_1138 != &local_1120) {
    free(local_1138);
  }
  if (local_1250 != &local_1238) {
    free(local_1250);
  }
  if (local_1368 != &local_1350) {
    free(local_1368);
  }
LAB_00120fe2:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return pvVar9;
}


// ==== FUN_00121300 @ 00121300

void FUN_00121300(long param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *__ptr;
  
  puVar1 = (undefined8 *)(param_1 + 0x330);
  puVar2 = *(undefined8 **)(param_1 + 0x1330);
  while (__ptr = puVar2, __ptr != (undefined8 *)0x0) {
    puVar2 = (undefined8 *)*__ptr;
    *(undefined8 **)(param_1 + 0x1330) = puVar2;
    if (puVar1 != __ptr) {
      free(__ptr);
      puVar2 = *(undefined8 **)(param_1 + 0x1330);
    }
  }
  *puVar1 = 0;
  *(undefined8 *)(param_1 + 0x338) = 0;
  *(undefined8 **)(param_1 + 0x1330) = puVar1;
  if (*(void **)(param_1 + 0x2d0) != (void *)(param_1 + 0x2e8)) {
    free(*(void **)(param_1 + 0x2d0));
  }
  if (*(void **)(param_1 + 0x298) != (void *)(param_1 + 0x2b0)) {
    free(*(void **)(param_1 + 0x298));
  }
  if (*(void **)(param_1 + 0x240) != (void *)(param_1 + 600)) {
    free(*(void **)(param_1 + 0x240));
  }
  if (*(void **)(param_1 + 0x128) != (void *)(param_1 + 0x140)) {
    free(*(void **)(param_1 + 0x128));
  }
  if (*(void **)(param_1 + 0x10) == (void *)(param_1 + 0x28)) {
    return;
  }
  free(*(void **)(param_1 + 0x10));
  return;
}


// ==== FUN_001213e0 @ 001213e0

long FUN_001213e0(undefined8 *param_1)

{
  long *plVar1;
  byte *pbVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  char cVar22;
  byte bVar23;
  ulong uVar24;
  char *pcVar25;
  long lVar26;
  long *plVar27;
  char *pcVar28;
  long lVar29;
  byte *pbVar30;
  long lVar31;
  ulong uVar32;
  long lVar33;
  ulong uVar34;
  long in_FS_OFFSET;
  bool bVar35;
  undefined1 auVar36 [16];
  long local_80;
  undefined1 local_78 [16];
  undefined8 local_60;
  long local_58;
  undefined8 local_50;
  undefined1 local_48 [8];
  ulong local_40;
  long local_38;
  
  auVar19._8_8_ = local_78._8_8_;
  auVar19._0_8_ = local_78._0_8_;
  auVar18._8_8_ = local_78._8_8_;
  auVar18._0_8_ = local_78._0_8_;
  auVar36._8_8_ = local_78._8_8_;
  auVar36._0_8_ = local_78._0_8_;
  auVar16._8_8_ = local_78._8_8_;
  auVar16._0_8_ = local_78._0_8_;
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar28 = (char *)*param_1;
  pcVar25 = (char *)param_1[1];
  if ((pcVar25 == pcVar28) || ((cVar22 = *pcVar28, cVar22 != 'T' && (cVar22 != 'G')))) {
    local_50 = (local_50 >> 0x10 & 0xffff) << 0x10;
    local_48[0] = 0;
    local_40 = (long)(param_1[0x5b] - param_1[0x5a]) >> 3;
    lVar29 = FUN_00122fc0(param_1,&local_50);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    auVar15._8_8_ = local_78._8_8_;
    auVar15._0_8_ = local_78._0_8_;
    auVar14._8_8_ = local_78._8_8_;
    auVar14._0_8_ = local_78._0_8_;
    auVar13._8_8_ = local_78._8_8_;
    auVar13._0_8_ = local_78._0_8_;
    auVar12._8_8_ = local_78._8_8_;
    auVar12._0_8_ = local_78._0_8_;
    auVar11._8_8_ = local_78._8_8_;
    auVar11._0_8_ = local_78._0_8_;
    auVar10._8_8_ = local_78._8_8_;
    auVar10._0_8_ = local_78._0_8_;
    auVar9._8_8_ = local_78._8_8_;
    auVar9._0_8_ = local_78._0_8_;
    auVar8._8_8_ = local_78._8_8_;
    auVar8._0_8_ = local_78._0_8_;
    auVar7._8_8_ = local_78._8_8_;
    auVar7._0_8_ = local_78._0_8_;
    auVar6._8_8_ = local_78._8_8_;
    auVar6._0_8_ = local_78._0_8_;
    auVar5._8_8_ = local_78._8_8_;
    auVar5._0_8_ = local_78._0_8_;
    auVar4._8_8_ = local_78._8_8_;
    auVar4._0_8_ = local_78._0_8_;
    auVar3._8_8_ = local_78._8_8_;
    auVar3._0_8_ = local_78._0_8_;
    local_58 = lVar29;
    if (lVar29 != 0) {
      lVar26 = param_1[0x5a];
      uVar32 = param_1[0x5b] - lVar26 >> 3;
      if (uVar32 <= local_40) {
LAB_001215e1:
        param_1[0x5b] = lVar26 + local_40 * 8;
LAB_001215ec:
        pcVar25 = (char *)*param_1;
        pcVar28 = (char *)param_1[1];
        local_78 = auVar16;
        if (pcVar28 == pcVar25) goto LAB_00121c5f;
        bVar23 = *pcVar25 - 0x2e;
        if ((bVar23 < 0x32) && ((0x2000000800001U >> ((ulong)bVar23 & 0x3f) & 1) != 0))
        goto LAB_00121c5f;
        local_60 = 0;
        local_78 = auVar3;
        if (((((0xc < (ulong)((long)pcVar28 - (long)pcVar25)) &&
              (((local_78 = auVar4, *pcVar25 == 'U' && (local_78 = auVar5, pcVar25[1] == 'a')) &&
               (local_78 = auVar6, pcVar25[2] == '9')))) &&
             (((local_78 = auVar7, pcVar25[3] == 'e' && (local_78 = auVar8, pcVar25[4] == 'n')) &&
              (local_78 = auVar9, pcVar25[5] == 'a')))) &&
            ((local_78 = auVar10, pcVar25[6] == 'b' && (local_78 = auVar11, pcVar25[7] == 'l')))) &&
           (((local_78 = auVar12, pcVar25[8] == 'e' &&
             (((local_78 = auVar13, pcVar25[9] == '_' && (local_78 = auVar14, pcVar25[10] == 'i'))
              && (local_78 = auVar15, pcVar25[0xb] == 'f')))) &&
            (local_78 = auVar16, pcVar25[0xc] == 'I')))) {
          pcVar25 = pcVar25 + 0xd;
          *param_1 = pcVar25;
          lVar29 = param_1[3];
          lVar26 = param_1[2];
          if (pcVar25 == pcVar28) goto LAB_001216e4;
          while (*pcVar25 != 'E') {
LAB_001216e4:
            do {
              local_78._0_8_ = FUN_00123b60(param_1);
              auVar16._8_8_ = local_78._8_8_;
              auVar16._0_8_ = local_78._0_8_;
              if (local_78._0_8_ == 0) goto LAB_00121c5c;
              FUN_00123d20(param_1 + 2,local_78);
              pcVar25 = (char *)*param_1;
            } while (pcVar25 == (char *)param_1[1]);
          }
          *param_1 = pcVar25 + 1;
          lVar29 = (lVar29 - lVar26 >> 3) * 8;
          local_78 = FUN_0012da70(param_1,param_1[2] + lVar29,param_1[3]);
          param_1[3] = lVar29 + param_1[2];
          local_60 = FUN_00123dc0(param_1,local_78);
        }
        local_80 = 0;
        if (((char)local_50 == '\0') && (local_50._1_1_ != '\0')) {
          local_80 = FUN_00121da0(param_1);
          auVar16 = local_78;
          if (local_80 == 0) goto LAB_00121c5c;
        }
        pcVar28 = (char *)*param_1;
        if ((pcVar28 == (char *)param_1[1]) || (*pcVar28 != 'v')) {
          lVar29 = param_1[3];
          lVar26 = param_1[2];
          do {
            lVar31 = FUN_00121da0(param_1);
            auVar16._8_8_ = local_78._8_8_;
            auVar16._0_8_ = lVar31;
            if (lVar31 == 0) goto LAB_00121c5c;
            local_78._0_8_ = lVar31;
            FUN_00123d20(param_1 + 2,local_78);
            auVar17._8_8_ = local_78._8_8_;
            auVar17._0_8_ = local_78._0_8_;
          } while (((char *)param_1[1] != (char *)*param_1) &&
                  ((bVar23 = *(char *)*param_1 - 0x2e, 0x31 < bVar23 ||
                   (local_78 = auVar17, (0x2000000800001U >> ((ulong)bVar23 & 0x3f) & 1) == 0))));
          lVar29 = (lVar29 - lVar26 >> 3) * 8;
          local_78 = FUN_0012da70(param_1,param_1[2] + lVar29,param_1[3]);
          param_1[3] = lVar29 + param_1[2];
        }
        else {
          *param_1 = pcVar28 + 1;
          local_78 = ZEXT816(0);
        }
        lVar29 = FUN_00123e50(param_1,&local_80,&local_58,local_78,&local_60,(long)&local_50 + 4,
                              local_48);
        goto LAB_00121c5f;
      }
      plVar1 = (long *)param_1[0x53];
      if ((plVar1 != (long *)param_1[0x54]) && (plVar27 = (long *)*plVar1, plVar27 != (long *)0x0))
      {
        lVar31 = *(long *)(lVar26 + local_40 * 8);
        uVar34 = *(ulong *)(lVar31 + 0x10);
        lVar33 = *plVar27;
        if (uVar34 < (ulong)(plVar27[1] - lVar33 >> 3)) {
          uVar24 = local_40;
          do {
            uVar24 = uVar24 + 1;
            *(undefined8 *)(lVar31 + 0x18) = *(undefined8 *)(lVar33 + uVar34 * 8);
            if (uVar32 == uVar24) goto LAB_001215e1;
            plVar27 = (long *)*plVar1;
            if (plVar27 == (long *)0x0) break;
            lVar31 = *(long *)(lVar26 + uVar24 * 8);
            uVar34 = *(ulong *)(lVar31 + 0x10);
            lVar33 = *plVar27;
          } while (uVar34 < (ulong)(plVar27[1] - lVar33 >> 3));
          if (uVar32 <= uVar24) goto LAB_001215ec;
        }
      }
    }
    goto LAB_00121c5c;
  }
  if (pcVar25 == pcVar28) goto LAB_00121c5c;
  if (cVar22 == 'G') {
    auVar16 = auVar18;
    if (1 < (ulong)((long)pcVar25 - (long)pcVar28)) {
      if (pcVar28[1] == 'R') {
        *param_1 = pcVar28 + 2;
        lVar29 = 0;
        lVar26 = FUN_00122fc0(param_1,0);
        if (lVar26 == 0) goto LAB_00121c5f;
        pbVar30 = (byte *)*param_1;
        pbVar2 = (byte *)param_1[1];
        if (pbVar2 != pbVar30) {
          bVar23 = *pbVar30;
          bVar35 = true;
          if (('/' < (char)bVar23) && ((bVar23 < 0x3a || ((byte)(bVar23 + 0xbf) < 0x1a)))) {
            pbVar30 = pbVar30 + 1;
            lVar29 = 0;
            do {
              if ((0x39 < bVar23) && (0x19 < (byte)(bVar23 + 0xbf))) break;
              *param_1 = pbVar30;
              if (pbVar30 == pbVar2) goto LAB_00121c5f;
              bVar23 = *pbVar30;
              pbVar30 = pbVar30 + 1;
            } while ('/' < (char)bVar23);
            pbVar30 = pbVar30 + -1;
            bVar35 = false;
          }
          if ((pbVar30 == pbVar2) || (bVar23 != 0x5f)) {
            auVar16 = local_78;
            if (!bVar35) goto LAB_00121c5c;
          }
          else {
            *param_1 = pbVar30 + 1;
          }
        }
        plVar1 = (long *)param_1[0x266];
        lVar31 = plVar1[1];
        plVar27 = plVar1;
        if (lVar31 - 0xfc0U < 0xfffffffffffff010) {
          plVar27 = malloc(0x1000);
          if (plVar27 == (long *)0x0) {
LAB_00121c81:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar27 = (long)plVar1;
          plVar27[1] = 0;
          param_1[0x266] = plVar27;
          lVar31 = 0;
        }
        plVar27[1] = lVar31 + 0x30;
        lVar29 = lVar31 + (long)plVar27;
        *(undefined4 *)((long)plVar27 + lVar31 + 0x18) = 0x1010114;
        *(undefined ***)((long)plVar27 + lVar31 + 0x10) = &PTR_LAB_0013e598;
        *(char **)((long)plVar27 + lVar31 + 0x20) = "reference temporary for ";
        pcVar28 = "";
      }
      else {
        auVar16 = auVar19;
        if (pcVar28[1] != 'V') goto LAB_00121c5c;
        *param_1 = pcVar28 + 2;
        lVar29 = 0;
        lVar26 = FUN_00122fc0(param_1,0);
        if (lVar26 == 0) goto LAB_00121c5f;
        plVar1 = (long *)param_1[0x266];
        lVar31 = plVar1[1];
        plVar27 = plVar1;
        if (lVar31 - 0xfc0U < 0xfffffffffffff010) {
          plVar27 = malloc(0x1000);
          if (plVar27 == (long *)0x0) goto LAB_00121c81;
          *plVar27 = (long)plVar1;
          plVar27[1] = 0;
          param_1[0x266] = plVar27;
          lVar31 = 0;
        }
        plVar27[1] = lVar31 + 0x30;
        lVar29 = lVar31 + (long)plVar27;
        *(undefined4 *)((long)plVar27 + lVar31 + 0x18) = 0x1010114;
        *(undefined ***)((long)plVar27 + lVar31 + 0x10) = &PTR_LAB_0013e598;
        *(char **)((long)plVar27 + lVar31 + 0x20) = "guard variable for ";
        pcVar28 = "";
      }
      lVar29 = lVar29 + 0x10;
      *(char **)((long)plVar27 + lVar31 + 0x28) = pcVar28;
      *(long *)((long)plVar27 + lVar31 + 0x30) = lVar26;
      goto LAB_00121c5f;
    }
    goto LAB_00121c5c;
  }
  auVar16 = auVar36;
  if (cVar22 != 'T') goto LAB_00121c5c;
  if ((ulong)((long)pcVar25 - (long)pcVar28) < 2) {
switchD_00121465_caseD_44:
    pcVar28 = pcVar28 + 1;
    *param_1 = pcVar28;
    if (pcVar25 == pcVar28) {
      bVar35 = false;
    }
    else {
      bVar35 = *pcVar28 == 'v';
    }
    cVar22 = FUN_001241b0(param_1);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    if (cVar22 == '\0') {
      local_50 = FUN_001213e0(param_1);
      auVar16._8_8_ = local_78._8_8_;
      auVar16._0_8_ = local_78._0_8_;
      if (local_50 != 0) {
        if (bVar35) {
          lVar29 = FUN_00124520();
        }
        else {
          lVar29 = FUN_001245c0(param_1,&local_50);
        }
        goto LAB_00121c5f;
      }
    }
    goto LAB_00121c5c;
  }
  switch(pcVar28[1]) {
  case 'C':
    *param_1 = pcVar28 + 2;
    local_50 = FUN_00121da0(param_1);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    if (local_50 != 0) {
      auVar36 = FUN_00121c90(param_1,1);
      auVar21._8_8_ = local_78._8_8_;
      auVar21._0_8_ = local_78._0_8_;
      auVar20._8_8_ = local_78._8_8_;
      auVar20._0_8_ = local_78._0_8_;
      auVar16._8_8_ = local_78._8_8_;
      auVar16._0_8_ = local_78._0_8_;
      if (((auVar36._0_8_ != auVar36._8_8_) &&
          (pcVar28 = (char *)*param_1, auVar16 = auVar20, pcVar28 != (char *)param_1[1])) &&
         (auVar16 = auVar21, *pcVar28 == '_')) {
        *param_1 = pcVar28 + 1;
        local_78._0_8_ = FUN_00121da0(param_1);
        auVar16._8_8_ = local_78._8_8_;
        auVar16._0_8_ = local_78._0_8_;
        if (local_78._0_8_ != 0) {
          lVar29 = FUN_001243e0(param_1,local_78,&local_50);
          goto LAB_00121c5f;
        }
      }
    }
    break;
  default:
    goto switchD_00121465_caseD_44;
  case 'H':
    *param_1 = pcVar28 + 2;
    lVar29 = 0;
    local_50 = FUN_00122fc0(param_1,0);
    if (local_50 != 0) {
      lVar29 = FUN_00124480(param_1,&local_50);
    }
    goto LAB_00121c5f;
  case 'I':
    *param_1 = pcVar28 + 2;
    local_50 = FUN_00121da0(param_1);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    if (local_50 != 0) {
      lVar29 = FUN_00124070(param_1,&local_50);
      goto LAB_00121c5f;
    }
    break;
  case 'S':
    *param_1 = pcVar28 + 2;
    local_50 = FUN_00121da0(param_1);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    if (local_50 != 0) {
      lVar29 = FUN_00124110(param_1,&local_50);
      goto LAB_00121c5f;
    }
    break;
  case 'T':
    *param_1 = pcVar28 + 2;
    local_50 = FUN_00121da0(param_1);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    if (local_50 != 0) {
      lVar29 = FUN_00123fd0(param_1,&local_50);
      goto LAB_00121c5f;
    }
    break;
  case 'V':
    *param_1 = pcVar28 + 2;
    local_50 = FUN_00121da0(param_1);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    if (local_50 != 0) {
      lVar29 = FUN_00123f30(param_1,&local_50);
      goto LAB_00121c5f;
    }
    break;
  case 'W':
    *param_1 = pcVar28 + 2;
    lVar29 = 0;
    local_50 = FUN_00122fc0(param_1,0);
    if (local_50 != 0) {
      lVar29 = FUN_00121cf0(param_1,"thread-local wrapper routine for ",&local_50);
    }
    goto LAB_00121c5f;
  case 'c':
    *param_1 = pcVar28 + 2;
    cVar22 = FUN_001241b0(param_1);
    auVar16._8_8_ = local_78._8_8_;
    auVar16._0_8_ = local_78._0_8_;
    if (cVar22 == '\0') {
      cVar22 = FUN_001241b0(param_1);
      auVar16._8_8_ = local_78._8_8_;
      auVar16._0_8_ = local_78._0_8_;
      if (cVar22 == '\0') {
        local_50 = FUN_001213e0(param_1);
        auVar16._8_8_ = local_78._8_8_;
        auVar16._0_8_ = local_78._0_8_;
        if (local_50 != 0) {
          lVar29 = FUN_00124340(param_1,&local_50);
          goto LAB_00121c5f;
        }
      }
    }
  }
LAB_00121c5c:
  lVar29 = 0;
  local_78 = auVar16;
LAB_00121c5f:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar29;
}


// ==== FUN_00121c90 @ 00121c90

undefined1  [16] FUN_00121c90(undefined1 (*param_1) [16],int param_2)

{
  char *pcVar1;
  char *pcVar2;
  undefined1 auVar3 [16];
  
  pcVar1 = *(char **)*param_1;
  pcVar2 = *(char **)(*param_1 + 8);
  auVar3._8_8_ = pcVar1;
  if (((param_2 != 0) && (pcVar1 != pcVar2)) && (*pcVar1 == 'n')) {
    auVar3._8_8_ = pcVar1 + 1;
    *(char **)*param_1 = auVar3._8_8_;
  }
  if ((pcVar2 == auVar3._8_8_) || ((int)*auVar3._8_8_ - 0x3aU < 0xfffffff6)) {
    return ZEXT816(0);
  }
  do {
    auVar3._8_8_ = auVar3._8_8_ + 1;
    *(char **)*param_1 = auVar3._8_8_;
    if (auVar3._8_8_ == pcVar2) {
      return *param_1;
    }
  } while (0xfffffff5 < (int)*auVar3._8_8_ - 0x3aU);
  auVar3._0_8_ = pcVar1;
  return auVar3;
}


// ==== FUN_00121cf0 @ 00121cf0

long FUN_00121cf0(long param_1,char *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  size_t sVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar3 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar5 = 0;
  }
  plVar3[1] = lVar5 + 0x30;
  sVar4 = strlen(param_2);
  uVar2 = *param_3;
  *(undefined4 *)((long)plVar3 + lVar5 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar5 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar5 + 0x20) = param_2;
  *(char **)((long)plVar3 + lVar5 + 0x28) = param_2 + sVar4;
  *(undefined8 *)((long)plVar3 + lVar5 + 0x30) = uVar2;
  return (long)plVar3 + lVar5 + 0x10;
}


// ==== FUN_00121da0 @ 00121da0

char * FUN_00121da0(long *param_1)

{
  char *pcVar1;
  char cVar2;
  long *plVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  uint uVar12;
  ulong uVar13;
  long *plVar14;
  char *pcVar15;
  char *pcVar16;
  char *pcVar17;
  long lVar18;
  ulong uVar19;
  char **ppcVar20;
  char *pcVar21;
  char **ppcVar22;
  long lVar23;
  long in_FS_OFFSET;
  char *local_38;
  undefined1 local_30 [16];
  char *local_20;
  long local_18;
  
  auVar6._8_8_ = local_30._8_8_;
  auVar6._0_8_ = local_30._0_8_;
  auVar5._8_8_ = local_30._8_8_;
  auVar5._0_8_ = local_30._0_8_;
  auVar4._8_8_ = local_30._8_8_;
  auVar4._0_8_ = local_30._0_8_;
  local_18 = *(long *)(in_FS_OFFSET + 0x28);
  local_38 = (char *)0x0;
  pcVar17 = (char *)*param_1;
  pcVar15 = (char *)param_1[1];
  uVar19 = (long)pcVar15 - (long)pcVar17;
  if (pcVar15 == pcVar17) {
switchD_00121df0_caseD_42:
    local_38 = (char *)FUN_00132710(param_1);
    goto LAB_00122579;
  }
  cVar2 = *pcVar17;
  switch(cVar2) {
  case 'A':
    pcVar16 = (char *)0x0;
    local_30 = auVar5;
    if ((pcVar17 != pcVar15) && (local_30 = auVar6, cVar2 == 'A')) {
      pcVar16 = pcVar17 + 1;
      *param_1 = (long)pcVar16;
      local_20 = (char *)0x0;
      if (pcVar15 == pcVar16) {
LAB_00122d14:
        pcVar17 = (char *)FUN_00125e60(param_1);
        auVar8._8_8_ = local_30._8_8_;
        auVar8._0_8_ = local_30._0_8_;
        auVar7._8_8_ = local_30._8_8_;
        auVar7._0_8_ = local_30._0_8_;
        if (((pcVar17 == (char *)0x0) ||
            (pcVar15 = (char *)*param_1, local_30 = auVar7, pcVar15 == (char *)param_1[1])) ||
           (local_30 = auVar8, *pcVar15 != '_')) goto LAB_00122e72;
        *param_1 = (long)(pcVar15 + 1);
        local_20 = pcVar17;
      }
      else if ((int)*pcVar16 - 0x3aU < 0xfffffff6) {
        if (*pcVar16 != '_') goto LAB_00122d14;
        *param_1 = (long)(pcVar17 + 2);
      }
      else {
        pcVar16 = (char *)0x0;
        local_30 = FUN_00121c90(param_1,0);
        local_20 = (char *)FUN_001333f0(param_1,local_30);
        pcVar17 = (char *)*param_1;
        if (pcVar17 == (char *)param_1[1]) goto LAB_00122e69;
        if (*pcVar17 != '_') goto LAB_00122e72;
        *param_1 = (long)(pcVar17 + 1);
      }
      pcVar17 = (char *)FUN_00121da0(param_1);
      local_30._0_8_ = pcVar17;
      if (pcVar17 == (char *)0x0) goto LAB_00122e72;
      pcVar16 = (char *)FUN_001337a0(param_1,local_30,&local_20);
LAB_00122e66:
    }
LAB_00122e69:
    local_38 = pcVar16;
    goto LAB_00122580;
  default:
    goto switchD_00121df0_caseD_42;
  case 'C':
    *param_1 = (long)(pcVar17 + 1);
    local_30._0_8_ = FUN_00121da0(param_1);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    if ((char *)local_30._0_8_ == (char *)0x0) goto LAB_00122f5f;
    local_38 = (char *)FUN_00132980(param_1,local_30);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    goto LAB_00122589;
  case 'D':
    if (uVar19 < 2) goto LAB_00122f5f;
    pcVar15 = (char *)0x0;
    switch(pcVar17[1]) {
    case 'O':
    case 'o':
    case 'w':
    case 'x':
      goto switchD_00121df0_caseD_46;
    case 'T':
    case 't':
      local_38 = (char *)FUN_001255e0(param_1);
      goto LAB_00122579;
    case 'a':
      *param_1 = (long)(pcVar17 + 2);
      pcVar15 = (char *)FUN_00125c60(param_1,&DAT_00109e8a);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      break;
    case 'c':
      *param_1 = (long)(pcVar17 + 2);
      pcVar17 = "decltype(auto)";
      goto LAB_00122f26;
    case 'd':
      *param_1 = (long)(pcVar17 + 2);
      pcVar17 = "decimal64";
      goto LAB_00122efe;
    case 'e':
      *param_1 = (long)(pcVar17 + 2);
      pcVar15 = (char *)FUN_0012eef0(param_1,"decimal128");
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      break;
    case 'f':
      *param_1 = (long)(pcVar17 + 2);
      pcVar17 = "decimal32";
      goto LAB_00122efe;
    case 'h':
      *param_1 = (long)(pcVar17 + 2);
      pcVar17 = "decimal16";
LAB_00122efe:
      pcVar15 = (char *)FUN_0012ef90(param_1,pcVar17);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      break;
    case 'i':
      *param_1 = (long)(pcVar17 + 2);
      pcVar17 = "char32_t";
      goto LAB_00122f87;
    case 'n':
      *param_1 = (long)(pcVar17 + 2);
      pcVar17 = "std::nullptr_t";
LAB_00122f26:
      pcVar15 = (char *)FUN_0012f290(param_1,pcVar17);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      break;
    case 'p':
      *param_1 = (long)(pcVar17 + 2);
      local_30._0_8_ = FUN_00121da0(param_1);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      if ((char *)local_30._0_8_ != (char *)0x0) {
        local_38 = (char *)FUN_00129930(param_1,local_30);
        auVar6._8_8_ = local_30._8_8_;
        auVar6._0_8_ = local_30._0_8_;
        goto LAB_00122589;
      }
      goto LAB_00122f5f;
    case 's':
      *param_1 = (long)(pcVar17 + 2);
      pcVar17 = "char16_t";
LAB_00122f87:
      pcVar15 = (char *)FUN_00132360(param_1,pcVar17);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      break;
    case 'u':
      *param_1 = (long)(pcVar17 + 2);
      pcVar15 = (char *)FUN_0012a100(param_1,"char8_t");
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      break;
    case 'v':
      local_38 = (char *)FUN_00132400(param_1);
      goto LAB_00122579;
    }
    break;
  case 'F':
    goto switchD_00121df0_caseD_46;
  case 'G':
    *param_1 = (long)(pcVar17 + 1);
    local_30._0_8_ = FUN_00121da0(param_1);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    if ((char *)local_30._0_8_ != (char *)0x0) {
      local_38 = (char *)FUN_00132a20(param_1,local_30);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      goto LAB_00122589;
    }
    goto LAB_00122f5f;
  case 'K':
  case 'V':
  case 'r':
    uVar13 = (ulong)(cVar2 == 'r');
    if ((uVar13 < uVar19) && (pcVar17[uVar13] == 'V')) {
      uVar13 = (ulong)((cVar2 == 'r') + 1);
    }
    uVar12 = (uint)uVar13;
    if (uVar13 < uVar19) {
      uVar12 = uVar12 + (pcVar17[uVar13] == 'K');
      uVar13 = (ulong)uVar12;
    }
    if ((uVar19 <= uVar13) ||
       ((pcVar17[uVar13] != 'F' &&
        ((((pcVar17[uVar13] != 'D' || (uVar19 <= (ulong)uVar12 + 1)) ||
          (0x29 < (byte)(pcVar17[(ulong)uVar12 + 1] + 0xb1U))) ||
         ((0x30100000001U >> ((ulong)(byte)(pcVar17[(ulong)uVar12 + 1] + 0xb1U) & 0x3f) & 1) == 0)))
        ))) goto switchD_00121df0_caseD_55;
    goto switchD_00121df0_caseD_46;
  case 'M':
    pcVar16 = (char *)0x0;
    if ((pcVar17 == pcVar15) || (local_30 = auVar4, cVar2 != 'M')) goto LAB_00122e69;
    *param_1 = (long)(pcVar17 + 1);
    local_30._0_8_ = FUN_00121da0(param_1);
    if ((char *)local_30._0_8_ != (char *)0x0) {
      local_20 = (char *)FUN_00121da0(param_1);
      if (local_20 != (char *)0x0) {
        pcVar16 = (char *)FUN_001339b0(param_1,local_30,&local_20);
        goto LAB_00122e66;
      }
    }
LAB_00122e72:
    local_38 = (char *)0x0;
LAB_00122580:
    auVar6 = local_30;
    if (local_38 != (char *)0x0) {
LAB_00122589:
      local_30 = auVar6;
      FUN_00123d20(param_1 + 0x25,&local_38);
      pcVar15 = local_38;
      auVar6 = local_30;
      break;
    }
    goto LAB_00122f5f;
  case 'O':
    *param_1 = (long)(pcVar17 + 1);
    local_30._0_8_ = FUN_00121da0(param_1);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    if ((char *)local_30._0_8_ != (char *)0x0) {
      local_20 = (char *)CONCAT44(local_20._4_4_,1);
LAB_00122b55:
      local_38 = (char *)FUN_001328d0(param_1,local_30,&local_20);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      goto LAB_00122589;
    }
    goto LAB_00122f5f;
  case 'P':
    *param_1 = (long)(pcVar17 + 1);
    local_30._0_8_ = FUN_00121da0(param_1);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    if ((char *)local_30._0_8_ != (char *)0x0) {
      local_38 = (char *)FUN_00132840(param_1,local_30);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      goto LAB_00122589;
    }
    goto LAB_00122f5f;
  case 'R':
    *param_1 = (long)(pcVar17 + 1);
    local_30._0_8_ = FUN_00121da0(param_1);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    if ((char *)local_30._0_8_ != (char *)0x0) {
      local_20 = (char *)((ulong)local_20 & 0xffffffff00000000);
      goto LAB_00122b55;
    }
    goto LAB_00122f5f;
  case 'S':
    if (((uVar19 < 2) || (pcVar17[1] == '\0')) || (pcVar17[1] == 't'))
    goto switchD_00121df0_caseD_42;
    pcVar15 = (char *)FUN_001248a0(param_1);
    auVar11._8_8_ = local_30._8_8_;
    auVar11._0_8_ = pcVar15;
    auVar10._8_8_ = local_30._8_8_;
    auVar10._0_8_ = pcVar15;
    auVar9._8_8_ = local_30._8_8_;
    auVar9._0_8_ = pcVar15;
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = pcVar15;
    if ((((pcVar15 == (char *)0x0) || (auVar6 = auVar9, (char)param_1[0x61] == '\0')) ||
        (auVar6 = auVar10, (char *)param_1[1] == (char *)*param_1)) ||
       (auVar6 = auVar11, *(char *)*param_1 != 'I')) break;
    local_30._0_8_ = pcVar15;
    local_20 = (char *)FUN_00124c50(param_1,0);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    if (local_20 != (char *)0x0) {
      ppcVar22 = (char **)local_30;
      ppcVar20 = &local_20;
LAB_00122da8:
      local_38 = (char *)FUN_00125180(param_1,ppcVar22,ppcVar20);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      goto LAB_00122589;
    }
    goto LAB_00122f5f;
  case 'T':
    if (((1 < uVar19) && ((byte)(pcVar17[1] + 0x9bU) < 0x11)) &&
       ((0x14001UL >> ((ulong)(byte)(pcVar17[1] + 0x9bU) & 0x3f) & 1) != 0))
    goto switchD_00121df0_caseD_42;
    local_38 = (char *)FUN_00125220(param_1);
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    if (local_38 != (char *)0x0) {
      if ((((char)param_1[0x61] == '\0') || ((char *)param_1[1] == (char *)*param_1)) ||
         (*(char *)*param_1 != 'I')) goto LAB_00122589;
      local_30._0_8_ = FUN_00124c50(param_1,0);
      auVar6._8_8_ = local_30._8_8_;
      auVar6._0_8_ = local_30._0_8_;
      ppcVar22 = &local_38;
      if ((char *)local_30._0_8_ != (char *)0x0) {
        ppcVar20 = (char **)local_30;
        goto LAB_00122da8;
      }
    }
    goto LAB_00122f5f;
  case 'U':
switchD_00121df0_caseD_55:
    local_38 = (char *)FUN_00131f30(param_1);
    goto LAB_00122579;
  case 'a':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) {
LAB_00122fb6:
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "signed char";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'b':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(undefined **)((long)plVar14 + lVar18 + 0x20) = &DAT_0010a7c9;
    *(undefined **)((long)plVar14 + lVar18 + 0x28) = &DAT_0010a7cd;
    break;
  case 'c':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(undefined **)((long)plVar14 + lVar18 + 0x20) = &DAT_0010a433;
    *(undefined **)((long)plVar14 + lVar18 + 0x28) = &DAT_0010a437;
    break;
  case 'd':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "double";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'e':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "long double";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'f':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "float";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'g':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "__float128";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'h':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "unsigned char";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'i':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(undefined **)((long)plVar14 + lVar18 + 0x20) = &DAT_00109fc7;
    *(undefined **)((long)plVar14 + lVar18 + 0x28) = &DAT_00109fca;
    break;
  case 'j':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "unsigned int";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'l':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(undefined **)((long)plVar14 + lVar18 + 0x20) = &DAT_00109a0a;
    *(undefined **)((long)plVar14 + lVar18 + 0x28) = &DAT_00109a0e;
    break;
  case 'm':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "unsigned long";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'n':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "__int128";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'o':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "unsigned __int128";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 's':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "short";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 't':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "unsigned short";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'u':
    pcVar16 = pcVar17 + 1;
    *param_1 = (long)pcVar16;
    if ((pcVar15 != pcVar16) && (0xf5 < (byte)(*pcVar16 - 0x3aU))) {
      pcVar21 = pcVar17 + 2;
      lVar18 = 0;
      uVar19 = 0;
      do {
        uVar13 = uVar19;
        lVar23 = lVar18;
        *param_1 = (long)pcVar21;
        pcVar1 = pcVar21 + -1;
        uVar19 = ((long)*pcVar1 + uVar13 * 10) - 0x30;
        if (pcVar21 == pcVar15) {
          pcVar21 = pcVar15;
          local_30._0_8_ = pcVar15;
          goto LAB_00122dbf;
        }
        cVar2 = *pcVar21;
        lVar18 = lVar23 + -1;
        pcVar21 = pcVar21 + 1;
      } while ((byte)(cVar2 - 0x30U) < 10);
      pcVar21 = pcVar17 + (1 - lVar18);
      local_30._0_8_ = pcVar16 + -lVar18;
LAB_00122dbf:
      if (uVar19 <= (ulong)((long)pcVar15 - (long)pcVar21)) {
        local_30._8_8_ = pcVar17 + (((long)*pcVar1 + uVar13 * 10) - lVar23) + -0x2e;
        auVar6._8_8_ = local_30._8_8_;
        auVar6._0_8_ = local_30._0_8_;
        *param_1 = local_30._8_8_;
        if (uVar19 != 0) {
          local_38 = (char *)FUN_0012e2e0(param_1,local_30);
          auVar6._8_8_ = local_30._8_8_;
          auVar6._0_8_ = local_30._0_8_;
          goto LAB_00122589;
        }
      }
    }
LAB_00122f5f:
    pcVar15 = (char *)0x0;
    break;
  case 'v':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(undefined **)((long)plVar14 + lVar18 + 0x20) = &DAT_0010aebc;
    *(undefined **)((long)plVar14 + lVar18 + 0x28) = &DAT_0010aec0;
    break;
  case 'w':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(undefined **)((long)plVar14 + lVar18 + 0x20) = &DAT_00109af3;
    *(undefined **)((long)plVar14 + lVar18 + 0x28) = &DAT_00109afa;
    break;
  case 'x':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "long long";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'y':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(char **)((long)plVar14 + lVar18 + 0x20) = "unsigned long long";
    *(char **)((long)plVar14 + lVar18 + 0x28) = "";
    break;
  case 'z':
    *param_1 = (long)(pcVar17 + 1);
    plVar3 = (long *)param_1[0x266];
    lVar18 = plVar3[1];
    plVar14 = plVar3;
    if (lVar18 - 0xfd0U < 0xfffffffffffff010) {
      plVar14 = malloc(0x1000);
      if (plVar14 == (long *)0x0) goto LAB_00122fb6;
      *plVar14 = (long)plVar3;
      plVar14[1] = 0;
      param_1[0x266] = (long)plVar14;
      lVar18 = 0;
    }
    auVar6._8_8_ = local_30._8_8_;
    auVar6._0_8_ = local_30._0_8_;
    plVar14[1] = lVar18 + 0x20;
    pcVar15 = (char *)((long)plVar14 + lVar18 + 0x10);
    *(undefined4 *)((long)plVar14 + lVar18 + 0x18) = 0x1010107;
    *(undefined ***)((long)plVar14 + lVar18 + 0x10) = &PTR_LAB_0013e688;
    *(undefined **)((long)plVar14 + lVar18 + 0x20) = &DAT_0010a939;
    *(undefined **)((long)plVar14 + lVar18 + 0x28) = &DAT_0010a93c;
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_18) {
    local_30 = auVar6;
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return pcVar15;
switchD_00121df0_caseD_46:
  local_38 = (char *)FUN_00131a40(param_1);
LAB_00122579:
  goto LAB_00122580;
}


// ==== FUN_00122fc0 @ 00122fc0

long FUN_00122fc0(long *param_1,undefined1 *param_2)

{
  char cVar1;
  byte bVar2;
  int iVar3;
  char *pcVar4;
  byte *pbVar5;
  long lVar6;
  byte bVar7;
  long lVar8;
  long *plVar9;
  long lVar10;
  long lVar11;
  long *plVar12;
  char *pcVar13;
  undefined1 uVar14;
  char *pcVar15;
  char *pcVar16;
  ulong uVar17;
  uint uVar18;
  byte *pbVar19;
  byte *pbVar20;
  long lVar21;
  long in_FS_OFFSET;
  long local_48;
  long local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar15 = (char *)*param_1;
  pcVar4 = (char *)param_1[1];
  if ((pcVar15 != pcVar4) && (*pcVar15 == 'L')) {
    pcVar15 = pcVar15 + 1;
    *param_1 = (long)pcVar15;
  }
  if (pcVar4 == pcVar15) {
LAB_0012308b:
    local_40 = FUN_00125870(param_1,param_2);
    if (local_40 != 0) {
LAB_001230a7:
      lVar11 = local_40;
      if (((char *)param_1[1] == (char *)*param_1) || (*(char *)*param_1 != 'I')) goto LAB_00123b2a;
      FUN_00123d20(param_1 + 0x25,&local_40);
      lVar8 = FUN_00124c50(param_1,param_2 != (undefined1 *)0x0);
      if (lVar8 != 0) {
        if (param_2 != (undefined1 *)0x0) {
          param_2[1] = 1;
        }
        plVar12 = (long *)param_1[0x266];
        lVar10 = plVar12[1];
        plVar9 = plVar12;
        if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
          plVar9 = malloc(0x1000);
          if (plVar9 == (long *)0x0) goto LAB_00123b4c;
          *plVar9 = (long)plVar12;
          plVar9[1] = 0;
          param_1[0x266] = (long)plVar9;
          lVar10 = 0;
        }
        plVar9[1] = lVar10 + 0x20;
        *(undefined4 *)((long)plVar9 + lVar10 + 0x18) = 0x1010125;
        *(undefined ***)((long)plVar9 + lVar10 + 0x10) = &PTR_LAB_0013fdb8;
        *(long *)((long)plVar9 + lVar10 + 0x20) = lVar11;
        lVar11 = (long)plVar9 + lVar10 + 0x10;
        *(long *)((long)plVar9 + lVar10 + 0x28) = lVar8;
        goto LAB_00123b2a;
      }
    }
  }
  else {
    cVar1 = *pcVar15;
    if (cVar1 == 'Z') {
      if (pcVar15 != pcVar4) {
        *param_1 = (long)(pcVar15 + 1);
        local_40 = FUN_001213e0(param_1);
        if (local_40 != 0) {
          pcVar15 = (char *)*param_1;
          if ((pcVar15 != (char *)param_1[1]) && (*pcVar15 == 'E')) {
            pcVar4 = pcVar15 + 1;
            *param_1 = (long)pcVar4;
            if (pcVar4 == (char *)param_1[1]) {
LAB_00123aaf:
              local_48 = FUN_00122fc0(param_1,param_2);
              if (local_48 != 0) {
                lVar11 = FUN_00130be0(*param_1,param_1[1]);
                *param_1 = lVar11;
LAB_00123ad3:
                lVar11 = FUN_00130c60(param_1,&local_40,&local_48);
                goto LAB_00123b2a;
              }
            }
            else {
              if (*pcVar4 != 'd') {
                if (*pcVar4 != 's') goto LAB_00123aaf;
                *param_1 = (long)(pcVar15 + 2);
                lVar11 = FUN_00130be0();
                *param_1 = lVar11;
                local_48 = FUN_0012f290(param_1,"string literal");
                goto LAB_00123ad3;
              }
              *param_1 = (long)(pcVar15 + 2);
              FUN_00121c90(param_1,1);
              pcVar15 = (char *)*param_1;
              if ((pcVar15 != (char *)param_1[1]) && (*pcVar15 == '_')) {
                *param_1 = (long)(pcVar15 + 1);
                local_48 = FUN_00122fc0(param_1,param_2);
                if (local_48 != 0) goto LAB_00123ad3;
              }
            }
          }
        }
      }
    }
    else if (cVar1 == 'S') {
      if (((ulong)((long)pcVar4 - (long)pcVar15) < 2) || (pcVar15[1] != 't')) {
        local_40 = FUN_001248a0(param_1);
        if (local_40 != 0) {
          if (((char *)param_1[1] != (char *)*param_1) && (*(char *)*param_1 == 'I')) {
            local_48 = FUN_00124c50(param_1,param_2 != (undefined1 *)0x0);
            if (local_48 != 0) {
              if (param_2 != (undefined1 *)0x0) {
                param_2[1] = 1;
              }
              lVar11 = FUN_00125180(param_1,&local_40,&local_48);
              goto LAB_00123b2a;
            }
          }
        }
      }
      else {
        if (((ulong)((long)pcVar4 - (long)pcVar15) < 3) || (lVar11 = 3, pcVar15[2] != 'L')) {
          lVar11 = 2;
        }
        *param_1 = (long)(pcVar15 + lVar11);
        lVar11 = FUN_00125870(param_1,param_2);
        if (lVar11 != 0) {
          plVar12 = (long *)param_1[0x266];
          lVar8 = plVar12[1];
          plVar9 = plVar12;
          if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
            plVar9 = malloc(0x1000);
            if (plVar9 == (long *)0x0) goto LAB_00123b4c;
            *plVar9 = (long)plVar12;
            plVar9[1] = 0;
            param_1[0x266] = (long)plVar9;
            lVar8 = 0;
          }
          plVar9[1] = lVar8 + 0x20;
          local_40 = (long)plVar9 + lVar8 + 0x10;
          *(undefined4 *)((long)plVar9 + lVar8 + 0x18) = 0x1010127;
          *(undefined ***)((long)plVar9 + lVar8 + 0x10) = &PTR_LAB_0013fe28;
          *(long *)((long)plVar9 + lVar8 + 0x20) = lVar11;
          goto LAB_001230a7;
        }
      }
    }
    else {
      if (cVar1 != 'N') goto LAB_0012308b;
      uVar18 = 0;
      lVar11 = 0;
      if (pcVar15 == pcVar4) goto LAB_00123b2a;
      pcVar16 = pcVar15 + 1;
      *param_1 = (long)pcVar16;
      pcVar13 = pcVar4;
      if (pcVar16 != pcVar4) {
        uVar18 = 0;
        if (*pcVar16 == 'r') {
          pcVar16 = pcVar15 + 2;
          *param_1 = (long)pcVar16;
          uVar18 = 4;
        }
        if (pcVar16 != pcVar4) {
          if (*pcVar16 == 'V') {
            pcVar16 = pcVar16 + 1;
            *param_1 = (long)pcVar16;
            uVar18 = uVar18 | 2;
          }
          if (pcVar16 != pcVar4) {
            if (*pcVar16 == 'K') {
              pcVar16 = pcVar16 + 1;
              *param_1 = (long)pcVar16;
              uVar18 = uVar18 | 1;
            }
            pcVar13 = pcVar16;
          }
        }
      }
      if (param_2 != (undefined1 *)0x0) {
        *(uint *)(param_2 + 4) = uVar18;
      }
      if (pcVar13 == pcVar4) {
LAB_0012334a:
        if (param_2 != (undefined1 *)0x0) {
          uVar14 = 0;
          goto LAB_00123361;
        }
      }
      else {
        if (*pcVar13 == 'R') {
          *param_1 = (long)(pcVar13 + 1);
          uVar14 = 1;
        }
        else {
          if (*pcVar13 != 'O') goto LAB_0012334a;
          *param_1 = (long)(pcVar13 + 1);
          uVar14 = 2;
        }
        pcVar13 = pcVar13 + 1;
        if (param_2 != (undefined1 *)0x0) {
LAB_00123361:
          param_2[8] = uVar14;
        }
      }
      local_40 = 0;
      if (((1 < (ulong)((long)pcVar4 - (long)pcVar13)) && (*pcVar13 == 'S')) && (pcVar13[1] == 't'))
      {
        *param_1 = (long)(pcVar13 + 2);
        plVar12 = (long *)param_1[0x266];
        lVar11 = plVar12[1];
        plVar9 = plVar12;
        if (lVar11 - 0xfd0U < 0xfffffffffffff010) {
          plVar9 = malloc(0x1000);
          if (plVar9 == (long *)0x0) {
LAB_00123b4c:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar9 = (long)plVar12;
          plVar9[1] = 0;
          param_1[0x266] = (long)plVar9;
          lVar11 = 0;
        }
        plVar9[1] = lVar11 + 0x20;
        local_40 = (long)plVar9 + lVar11 + 0x10;
        *(undefined4 *)((long)plVar9 + lVar11 + 0x18) = 0x1010107;
        *(undefined ***)((long)plVar9 + lVar11 + 0x10) = &PTR_LAB_0013e688;
        *(undefined **)((long)plVar9 + lVar11 + 0x20) = &DAT_00109e3b;
        *(undefined **)((long)plVar9 + lVar11 + 0x28) = &DAT_00109e3e;
      }
      do {
        while( true ) {
          pbVar19 = (byte *)*param_1;
          pbVar5 = (byte *)param_1[1];
          if (pbVar19 == pbVar5) break;
          if (*pbVar19 != 0x4c) {
            if (*pbVar19 != 0x45) break;
            *param_1 = (long)(pbVar19 + 1);
            if (local_40 != 0) {
              if (param_1[0x25] != param_1[0x26]) {
                param_1[0x26] = param_1[0x26] + -8;
                lVar11 = local_40;
                goto LAB_00123b2a;
              }
            }
            goto LAB_00123b28;
          }
          pbVar19 = pbVar19 + 1;
          *param_1 = (long)pbVar19;
          if (pbVar19 != pbVar5) goto LAB_001234cc;
LAB_001234f0:
          uVar17 = (long)pbVar5 - (long)pbVar19;
          if (pbVar5 == pbVar19) goto switchD_0012351c_caseD_45;
          switch(*pbVar19) {
          case 0x44:
            if (1 < uVar17) {
              bVar7 = pbVar19[1];
              if (bVar7 == 0x43) goto switchD_0012351c_caseD_45;
              if ((bVar7 == 0x74) || (bVar7 == 0x54)) {
                lVar11 = FUN_001255e0(param_1);
                lVar8 = local_40;
                goto joined_r0x001237ae;
              }
            }
          case 0x43:
            if (local_40 == 0) goto LAB_00123b28;
            if ((*(char *)(local_40 + 8) == ')') &&
               (iVar3 = *(int *)(local_40 + 0xc), iVar3 - 2U < 4)) {
              plVar12 = (long *)param_1[0x266];
              lVar11 = plVar12[1];
              plVar9 = plVar12;
              if (lVar11 - 0xfe0U < 0xfffffffffffff010) {
                plVar9 = malloc(0x1000);
                if (plVar9 == (long *)0x0) goto LAB_00123b4c;
                *plVar9 = (long)plVar12;
                plVar9[1] = 0;
                param_1[0x266] = (long)plVar9;
                lVar11 = 0;
              }
              plVar9[1] = lVar11 + 0x10;
              local_40 = (long)plVar9 + lVar11 + 0x10;
              *(undefined4 *)((long)plVar9 + lVar11 + 0x18) = 0x1010128;
              *(undefined ***)((long)plVar9 + lVar11 + 0x10) = &PTR_LAB_0013fa38;
              *(int *)((long)plVar9 + lVar11 + 0x1c) = iVar3;
            }
            lVar8 = local_40;
            if (pbVar19 == pbVar5) {
              bVar7 = *pbVar5;
LAB_001238e5:
              if (bVar7 != 0x44) goto LAB_00123b28;
              lVar11 = 0;
              if (uVar17 == 1) goto LAB_00123b2a;
              bVar7 = pbVar19[1];
              if (0x35 < (ulong)bVar7) goto LAB_00123b28;
              lVar11 = 0;
              if ((0x37000000000000U >> ((ulong)bVar7 & 0x3f) & 1) == 0) goto LAB_00123b2a;
              *param_1 = (long)(pbVar19 + 2);
              if (param_2 != (undefined1 *)0x0) {
                *param_2 = 1;
              }
              plVar12 = (long *)param_1[0x266];
              lVar11 = plVar12[1];
              plVar9 = plVar12;
              if (lVar11 - 0xfd0U < 0xfffffffffffff010) {
                plVar9 = malloc(0x1000);
                if (plVar9 == (long *)0x0) goto LAB_00123b4c;
                *plVar9 = (long)plVar12;
                plVar9[1] = 0;
                param_1[0x266] = (long)plVar9;
                lVar11 = 0;
              }
              lVar10 = lVar11 + 0x20;
              plVar9[1] = lVar10;
              uVar14 = 1;
            }
            else {
              bVar7 = *pbVar19;
              if (bVar7 != 0x43) goto LAB_001238e5;
              pbVar20 = pbVar19 + 1;
              *param_1 = (long)pbVar20;
              if (pbVar20 == pbVar5) goto LAB_00123b28;
              bVar2 = *pbVar20;
              if (bVar2 == 0x49) {
                pbVar20 = pbVar19 + 2;
                *param_1 = (long)pbVar20;
              }
              if ((pbVar5 == pbVar20) || (bVar7 = *pbVar20, 4 < (byte)(bVar7 - 0x31)))
              goto LAB_00123b28;
              *param_1 = (long)(pbVar20 + 1);
              if (param_2 != (undefined1 *)0x0) {
                *param_2 = 1;
              }
              if ((bVar2 == 0x49) && (lVar11 = FUN_00122fc0(param_1,param_2), lVar11 == 0))
              goto LAB_00123b28;
              plVar12 = (long *)param_1[0x266];
              lVar11 = plVar12[1];
              plVar9 = plVar12;
              if (lVar11 - 0xfd0U < 0xfffffffffffff010) {
                plVar9 = malloc(0x1000);
                if (plVar9 == (long *)0x0) goto LAB_00123b4c;
                *plVar9 = (long)plVar12;
                plVar9[1] = 0;
                param_1[0x266] = (long)plVar9;
                lVar11 = 0;
              }
              lVar10 = lVar11 + 0x20;
              plVar9[1] = lVar10;
              uVar14 = 0;
            }
            lVar6 = local_40;
            lVar21 = (long)plVar9 + lVar11 + 0x10;
            *(undefined4 *)((long)plVar9 + lVar11 + 0x18) = 0x101012a;
            *(undefined ***)((long)plVar9 + lVar11 + 0x10) = &PTR_LAB_0013faa8;
            *(long *)((long)plVar9 + lVar11 + 0x20) = lVar8;
            *(undefined1 *)((long)plVar9 + lVar11 + 0x28) = uVar14;
            *(uint *)((long)plVar9 + lVar11 + 0x2c) = bVar7 - 0x30;
            if (local_40 != 0) {
              plVar12 = plVar9;
              if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
                plVar12 = malloc(0x1000);
                if (plVar12 == (long *)0x0) goto LAB_00123b4c;
                *plVar12 = (long)plVar9;
                plVar12[1] = 0;
                param_1[0x266] = (long)plVar12;
                lVar10 = 0;
              }
              plVar12[1] = lVar10 + 0x20;
              *(undefined4 *)((long)plVar12 + lVar10 + 0x18) = 0x1010117;
              *(undefined ***)((long)plVar12 + lVar10 + 0x10) = &PTR_LAB_0013e6f8;
              *(long *)((long)plVar12 + lVar10 + 0x20) = lVar6;
              *(long *)((long)plVar12 + lVar10 + 0x28) = lVar21;
              lVar21 = (long)plVar12 + lVar10 + 0x10;
            }
            if (param_2 != (undefined1 *)0x0) {
              param_2[1] = 0;
            }
            local_40 = FUN_00125700(param_1,lVar21);
            if (local_40 == 0) goto LAB_00123b28;
LAB_00123480:
            FUN_00123d20(param_1 + 0x25,&local_40);
            break;
          default:
            goto switchD_0012351c_caseD_45;
          case 0x49:
            lVar10 = FUN_00124c50(param_1,param_2 != (undefined1 *)0x0);
            lVar8 = local_40;
            if (lVar10 != 0) {
              lVar11 = 0;
              if (local_40 == 0) goto LAB_00123b2a;
              plVar12 = (long *)param_1[0x266];
              lVar11 = plVar12[1];
              plVar9 = plVar12;
              if (lVar11 - 0xfd0U < 0xfffffffffffff010) {
                plVar9 = malloc(0x1000);
                if (plVar9 == (long *)0x0) goto LAB_00123b4c;
                *plVar9 = (long)plVar12;
                plVar9[1] = 0;
                param_1[0x266] = (long)plVar9;
                lVar11 = 0;
              }
              plVar9[1] = lVar11 + 0x20;
              local_40 = (long)plVar9 + lVar11 + 0x10;
              *(undefined4 *)((long)plVar9 + lVar11 + 0x18) = 0x1010125;
              *(undefined ***)((long)plVar9 + lVar11 + 0x10) = &PTR_LAB_0013fdb8;
              *(long *)((long)plVar9 + lVar11 + 0x20) = lVar8;
              *(long *)((long)plVar9 + lVar11 + 0x28) = lVar10;
              if (param_2 != (undefined1 *)0x0) {
                param_2[1] = 1;
              }
              goto LAB_00123480;
            }
            goto LAB_00123b28;
          case 0x53:
            if ((1 < uVar17) && (pbVar19[1] == 0x74)) {
switchD_0012351c_caseD_45:
              lVar11 = FUN_00125870(param_1,param_2);
              lVar8 = local_40;
joined_r0x001237ae:
              local_40 = lVar8;
              if (lVar11 != 0) {
                local_40 = lVar11;
                if (lVar8 != 0) {
                  plVar12 = (long *)param_1[0x266];
                  lVar10 = plVar12[1];
                  plVar9 = plVar12;
                  if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
                    local_40 = lVar8;
                    plVar9 = malloc(0x1000);
                    if (plVar9 == (long *)0x0) goto LAB_00123b4c;
                    *plVar9 = (long)plVar12;
                    plVar9[1] = 0;
                    param_1[0x266] = (long)plVar9;
                    lVar10 = 0;
                  }
                  plVar9[1] = lVar10 + 0x20;
                  *(undefined4 *)((long)plVar9 + lVar10 + 0x18) = 0x1010117;
                  *(undefined ***)((long)plVar9 + lVar10 + 0x10) = &PTR_LAB_0013e6f8;
                  *(long *)((long)plVar9 + lVar10 + 0x20) = lVar8;
                  *(long *)((long)plVar9 + lVar10 + 0x28) = lVar11;
                  local_40 = (long)plVar9 + lVar10 + 0x10;
                }
                if (param_2 != (undefined1 *)0x0) {
                  param_2[1] = 0;
                }
                goto LAB_00123480;
              }
              goto LAB_00123b28;
            }
            lVar8 = FUN_001248a0(param_1);
            lVar11 = local_40;
            local_48 = lVar8;
            if (lVar8 == 0) goto LAB_00123b28;
            lVar10 = lVar8;
            if (local_40 != 0) {
              plVar12 = (long *)param_1[0x266];
              lVar10 = plVar12[1];
              plVar9 = plVar12;
              if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
                plVar9 = malloc(0x1000);
                if (plVar9 == (long *)0x0) goto LAB_00123b4c;
                *plVar9 = (long)plVar12;
                plVar9[1] = 0;
                param_1[0x266] = (long)plVar9;
                lVar10 = 0;
              }
              plVar9[1] = lVar10 + 0x20;
              *(undefined4 *)((long)plVar9 + lVar10 + 0x18) = 0x1010117;
              *(undefined ***)((long)plVar9 + lVar10 + 0x10) = &PTR_LAB_0013e6f8;
              *(long *)((long)plVar9 + lVar10 + 0x20) = lVar11;
              *(long *)((long)plVar9 + lVar10 + 0x28) = lVar8;
              lVar10 = (long)plVar9 + lVar10 + 0x10;
            }
            local_40 = lVar10;
            if (param_2 != (undefined1 *)0x0) {
              param_2[1] = 0;
            }
            if (local_40 != lVar8) {
              FUN_00123d20(param_1 + 0x25,&local_48);
            }
            break;
          case 0x54:
            lVar11 = FUN_00125220(param_1);
            lVar8 = local_40;
            goto joined_r0x001237ae;
          }
        }
        if (pbVar19 == pbVar5) goto LAB_001234f0;
LAB_001234cc:
        if (*pbVar19 != 0x4d) goto LAB_001234f0;
        *param_1 = (long)(pbVar19 + 1);
      } while (local_40 != 0);
    }
  }
LAB_00123b28:
  lVar11 = 0;
LAB_00123b2a:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar11;
}


// ==== FUN_00123b60 @ 00123b60

long FUN_00123b60(undefined8 *param_1)

{
  char cVar1;
  char *pcVar2;
  long *plVar3;
  long lVar4;
  char *pcVar5;
  long *plVar6;
  long lVar7;
  long in_FS_OFFSET;
  undefined1 auVar8 [16];
  long local_30;
  long local_28;
  
  local_28 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar5 = (char *)*param_1;
  pcVar2 = (char *)param_1[1];
  if (pcVar2 == pcVar5) {
LAB_00123bcb:
    lVar4 = FUN_00121da0(param_1);
  }
  else {
    cVar1 = *pcVar5;
    if (cVar1 == 'J') {
      pcVar5 = pcVar5 + 1;
      *param_1 = pcVar5;
      lVar7 = param_1[3];
      lVar4 = param_1[2];
      if (pcVar5 == pcVar2) goto LAB_00123c25;
      while (*pcVar5 != 'E') {
LAB_00123c25:
        do {
          local_30 = FUN_00123b60(param_1);
          if (local_30 == 0) goto LAB_00123bf8;
          FUN_00123d20(param_1 + 2,&local_30);
          pcVar5 = (char *)*param_1;
        } while (pcVar5 == (char *)param_1[1]);
      }
      *param_1 = pcVar5 + 1;
      lVar7 = (lVar7 - lVar4 >> 3) * 8;
      auVar8 = FUN_0012da70(param_1,param_1[2] + lVar7,param_1[3]);
      param_1[3] = lVar7 + param_1[2];
      plVar3 = (long *)param_1[0x266];
      lVar7 = plVar3[1];
      plVar6 = plVar3;
      if (lVar7 - 0xfd0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        *plVar6 = (long)plVar3;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar7 = 0;
      }
      plVar6[1] = lVar7 + 0x20;
      lVar4 = (long)plVar6 + lVar7 + 0x10;
      *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x1010121;
      *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013fe98;
      *(long *)((long)plVar6 + lVar7 + 0x20) = auVar8._0_8_;
      *(long *)((long)plVar6 + lVar7 + 0x28) = auVar8._8_8_;
      goto LAB_00123cfa;
    }
    if (cVar1 == 'L') {
      if (((ulong)((long)pcVar2 - (long)pcVar5) < 2) || (pcVar5[1] != 'Z')) {
        lVar4 = FUN_00126f90(param_1);
        goto LAB_00123cfa;
      }
      *param_1 = pcVar5 + 2;
      lVar4 = FUN_001213e0(param_1);
    }
    else {
      if (cVar1 != 'X') goto LAB_00123bcb;
      *param_1 = pcVar5 + 1;
      lVar4 = FUN_00125e60(param_1);
    }
    if (((lVar4 == 0) || (pcVar2 = (char *)*param_1, pcVar2 == (char *)param_1[1])) ||
       (*pcVar2 != 'E')) {
LAB_00123bf8:
      lVar4 = 0;
    }
    else {
      *param_1 = pcVar2 + 1;
    }
  }
LAB_00123cfa:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar4;
}


// ==== FUN_00123d20 @ 00123d20

void FUN_00123d20(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *__src;
  undefined8 uVar1;
  void *__dest;
  size_t __n;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)param_1[1];
  if (puVar2 == (undefined8 *)param_1[2]) {
    __src = (undefined8 *)*param_1;
    __n = (long)puVar2 - (long)__src;
    if (__src == param_1 + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_00123dbb;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *param_1 = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *param_1 = __dest;
      if (__dest == (void *)0x0) {
LAB_00123dbb:
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
    }
    puVar2 = (undefined8 *)((long)__dest + ((long)__n >> 3) * 8);
    param_1[1] = puVar2;
    param_1[2] = (void *)((long)__dest + ((long)__n >> 2) * 8);
  }
  uVar1 = *param_2;
  param_1[1] = puVar2 + 1;
  *puVar2 = uVar1;
  return;
}


// ==== FUN_00123dc0 @ 00123dc0

long FUN_00123dc0(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar2[1];
  plVar5 = plVar2;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar2;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  uVar3 = *param_2;
  uVar4 = param_2[1];
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x1010109;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013ff08;
  puVar1 = (undefined8 *)((long)plVar5 + lVar6 + 0x20);
  *puVar1 = uVar3;
  puVar1[1] = uVar4;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00123e50 @ 00123e50

long FUN_00123e50(long param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4,
                 undefined8 *param_5,undefined4 *param_6,undefined1 *param_7)

{
  undefined8 *puVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  long *plVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  long *plVar10;
  long lVar11;
  
  plVar4 = *(long **)(param_1 + 0x1330);
  lVar11 = plVar4[1];
  plVar10 = plVar4;
  if (lVar11 - 0xfb0U < 0xfffffffffffff010) {
    plVar10 = malloc(0x1000);
    if (plVar10 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar10 = (long)plVar4;
    plVar10[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar10;
    lVar11 = 0;
  }
  plVar10[1] = lVar11 + 0x40;
  uVar5 = *param_2;
  uVar6 = *param_3;
  uVar8 = *param_4;
  uVar9 = param_4[1];
  uVar7 = *param_5;
  uVar3 = *param_6;
  uVar2 = *param_7;
  *(undefined4 *)((long)plVar10 + lVar11 + 0x18) = 0x10012;
  *(undefined ***)((long)plVar10 + lVar11 + 0x10) = &PTR_LAB_0013ff78;
  *(undefined8 *)((long)plVar10 + lVar11 + 0x20) = uVar5;
  *(undefined8 *)((long)plVar10 + lVar11 + 0x28) = uVar6;
  puVar1 = (undefined8 *)((long)plVar10 + lVar11 + 0x30);
  *puVar1 = uVar8;
  puVar1[1] = uVar9;
  *(undefined8 *)((long)plVar10 + lVar11 + 0x40) = uVar7;
  *(undefined4 *)((long)plVar10 + lVar11 + 0x48) = uVar3;
  *(undefined1 *)((long)plVar10 + lVar11 + 0x4c) = uVar2;
  return (long)plVar10 + lVar11 + 0x10;
}


// ==== FUN_00123f30 @ 00123f30

long FUN_00123f30(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "vtable for ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00123fd0 @ 00123fd0

long FUN_00123fd0(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "VTT for ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00124070 @ 00124070

long FUN_00124070(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "typeinfo for ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00124110 @ 00124110

long FUN_00124110(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "typeinfo name for ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_001241b0 @ 001241b0

undefined8 FUN_001241b0(long *param_1)

{
  char *pcVar1;
  undefined8 uVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  
  pcVar3 = (char *)*param_1;
  pcVar1 = (char *)param_1[1];
  uVar2 = 1;
  if (pcVar3 == pcVar1) {
    return 1;
  }
  if (*pcVar3 == 'h') {
    pcVar6 = pcVar3 + 1;
    *param_1 = (long)pcVar6;
    if (pcVar6 == pcVar1) {
      return 1;
    }
    pcVar5 = pcVar6;
    if (*pcVar6 == 'n') {
      pcVar5 = pcVar3 + 2;
      *param_1 = (long)pcVar5;
    }
    if (pcVar1 == pcVar5) {
      return 1;
    }
    if ((int)*pcVar5 - 0x3aU < 0xfffffff6) {
      return 1;
    }
    pcVar3 = pcVar5 + 1;
    do {
      pcVar5 = pcVar3;
      *param_1 = (long)pcVar5;
      if (pcVar5 == pcVar1) goto LAB_00124314;
      pcVar3 = pcVar5 + 1;
    } while (0xfffffff5 < (int)*pcVar5 - 0x3aU);
  }
  else {
    if (*pcVar3 != 'v') {
      return 1;
    }
    pcVar6 = pcVar3 + 1;
    *param_1 = (long)pcVar6;
    if (pcVar6 == pcVar1) {
      return 1;
    }
    pcVar5 = pcVar6;
    if (*pcVar6 == 'n') {
      pcVar5 = pcVar3 + 2;
      *param_1 = (long)pcVar5;
    }
    if (pcVar1 == pcVar5) {
      return 1;
    }
    if ((int)*pcVar5 - 0x3aU < 0xfffffff6) {
      return 1;
    }
    do {
      pcVar3 = pcVar5;
      pcVar5 = pcVar3 + 1;
      *param_1 = (long)pcVar5;
      if (pcVar5 == pcVar1) {
        pcVar4 = pcVar1;
        goto LAB_001242b3;
      }
    } while (0xfffffff5 < (int)*pcVar5 - 0x3aU);
    pcVar4 = pcVar5;
LAB_001242b3:
    if (pcVar6 == pcVar4) {
      return 1;
    }
    if (pcVar5 == pcVar1) {
      return 1;
    }
    if (*pcVar5 != '_') {
      return 1;
    }
    pcVar6 = pcVar3 + 2;
    *param_1 = (long)pcVar6;
    if (pcVar6 == pcVar1) {
      return 1;
    }
    pcVar5 = pcVar6;
    if (*pcVar6 == 'n') {
      pcVar5 = pcVar3 + 3;
      *param_1 = (long)pcVar5;
    }
    if (pcVar1 == pcVar5) {
      return 1;
    }
    if ((int)*pcVar5 - 0x3aU < 0xfffffff6) {
      return 1;
    }
    pcVar3 = pcVar5 + 1;
    do {
      pcVar5 = pcVar3;
      *param_1 = (long)pcVar5;
      if (pcVar5 == pcVar1) goto LAB_00124314;
      pcVar3 = pcVar5 + 1;
    } while (0xfffffff5 < (int)*pcVar5 - 0x3aU);
  }
  if (pcVar6 == pcVar3 + -1) {
    return 1;
  }
LAB_0012431c:
  if ((pcVar5 != pcVar1) && (*pcVar5 == '_')) {
    *param_1 = (long)(pcVar5 + 1);
    uVar2 = 0;
  }
  return uVar2;
LAB_00124314:
  if (pcVar6 == pcVar1) {
    return 1;
  }
  goto LAB_0012431c;
}


// ==== FUN_00124340 @ 00124340

long FUN_00124340(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "covariant return thunk to ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_001243e0 @ 001243e0

long FUN_001243e0(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x20;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010115;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013e618;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00124480 @ 00124480

long FUN_00124480(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "thread-local initialization routine for ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00124520 @ 00124520

long FUN_00124520(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "virtual thunk to ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_001245c0 @ 001245c0

long FUN_001245c0(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010114;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e598;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "non-virtual thunk to ";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00124750 @ 00124750

void FUN_00124750(void)

{
  return;
}


// ==== FUN_001248a0 @ 001248a0

long FUN_001248a0(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  long *plVar3;
  byte *pbVar4;
  undefined4 uVar5;
  long lVar6;
  long lVar7;
  byte bVar8;
  long lVar9;
  long *plVar10;
  long in_FS_OFFSET;
  long local_28;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  pbVar4 = (byte *)*param_1;
  pbVar2 = (byte *)param_1[1];
  if ((pbVar4 != pbVar2) && (*pbVar4 == 0x53)) {
    pbVar1 = pbVar4 + 1;
    *param_1 = (long)pbVar1;
    if (pbVar2 != pbVar1) {
      if (0xffffffe5 < (int)(char)*pbVar1 - 0x7bU) {
        lVar7 = 0;
        switch((int)(char)*pbVar1) {
        case 0x61:
          *param_1 = (long)(pbVar4 + 2);
          plVar10 = (long *)param_1[0x266];
          lVar6 = plVar10[1];
          uVar5 = 0;
          if (lVar6 - 0xfe0U < 0xfffffffffffff010) {
            plVar3 = malloc(0x1000);
            if (plVar3 == (long *)0x0) {
LAB_00124c3d:
                    /* WARNING: Subroutine does not return */
              FUN_00120930();
            }
            uVar5 = 0;
LAB_00124b34:
            *plVar3 = (long)plVar10;
            plVar3[1] = 0;
            param_1[0x266] = (long)plVar3;
            lVar6 = 0;
            plVar10 = plVar3;
          }
          break;
        case 0x62:
          *param_1 = (long)(pbVar4 + 2);
          plVar10 = (long *)param_1[0x266];
          lVar6 = plVar10[1];
          uVar5 = 1;
          if (lVar6 - 0xfe0U < 0xfffffffffffff010) {
            plVar3 = malloc(0x1000);
            if (plVar3 == (long *)0x0) goto LAB_00124c3d;
            uVar5 = 1;
            goto LAB_00124b34;
          }
          break;
        default:
          goto switchD_00124932_caseD_63;
        case 100:
          *param_1 = (long)(pbVar4 + 2);
          plVar10 = (long *)param_1[0x266];
          lVar6 = plVar10[1];
          uVar5 = 5;
          if (lVar6 - 0xfe0U < 0xfffffffffffff010) {
            plVar3 = malloc(0x1000);
            if (plVar3 == (long *)0x0) goto LAB_00124c3d;
            uVar5 = 5;
            goto LAB_00124b34;
          }
          break;
        case 0x69:
          *param_1 = (long)(pbVar4 + 2);
          plVar10 = (long *)param_1[0x266];
          lVar6 = plVar10[1];
          uVar5 = 3;
          if (lVar6 - 0xfe0U < 0xfffffffffffff010) {
            plVar3 = malloc(0x1000);
            if (plVar3 == (long *)0x0) goto LAB_00124c3d;
            uVar5 = 3;
            goto LAB_00124b34;
          }
          break;
        case 0x6f:
          *param_1 = (long)(pbVar4 + 2);
          plVar10 = (long *)param_1[0x266];
          lVar6 = plVar10[1];
          uVar5 = 4;
          if (lVar6 - 0xfe0U < 0xfffffffffffff010) {
            plVar3 = malloc(0x1000);
            if (plVar3 == (long *)0x0) goto LAB_00124c3d;
            uVar5 = 4;
            goto LAB_00124b34;
          }
          break;
        case 0x73:
          *param_1 = (long)(pbVar4 + 2);
          plVar10 = (long *)param_1[0x266];
          lVar6 = plVar10[1];
          uVar5 = 2;
          if (lVar6 - 0xfe0U < 0xfffffffffffff010) {
            plVar3 = malloc(0x1000);
            if (plVar3 == (long *)0x0) goto LAB_00124c3d;
            uVar5 = 2;
            goto LAB_00124b34;
          }
        }
        plVar10[1] = lVar6 + 0x10;
        lVar7 = (long)plVar10 + lVar6 + 0x10;
        *(undefined4 *)((long)plVar10 + lVar6 + 0x18) = 0x1010129;
        *(undefined ***)((long)plVar10 + lVar6 + 0x10) = &PTR_LAB_0013fc68;
        *(undefined4 *)((long)plVar10 + lVar6 + 0x1c) = uVar5;
        lVar6 = FUN_00125700(param_1,lVar7);
        local_28 = lVar6;
        if (lVar6 != lVar7) {
          FUN_00123d20(param_1 + 0x25,&local_28);
          lVar7 = lVar6;
        }
        goto switchD_00124932_caseD_63;
      }
      if (*pbVar1 == 0x5f) {
        *param_1 = (long)(pbVar4 + 2);
        if ((long *)param_1[0x25] != (long *)param_1[0x26]) {
          lVar7 = *(long *)param_1[0x25];
          goto switchD_00124932_caseD_63;
        }
      }
      else {
        bVar8 = *pbVar1;
        if (('/' < (char)bVar8) && ((bVar8 < 0x3a || ((byte)(bVar8 + 0xbf) < 0x1a)))) {
          pbVar4 = pbVar4 + 2;
          lVar6 = 0;
          do {
            lVar9 = -0x30;
            if ((0x39 < bVar8) && (lVar9 = -0x37, 0x19 < (byte)(bVar8 + 0xbf))) break;
            *param_1 = (long)pbVar4;
            lVar7 = 0;
            if (pbVar4 == pbVar2) goto switchD_00124932_caseD_63;
            lVar6 = (ulong)bVar8 + lVar6 * 0x24 + lVar9;
            bVar8 = *pbVar4;
            pbVar4 = pbVar4 + 1;
          } while ('/' < (char)bVar8);
          if ((pbVar4 + -1 != pbVar2) && (pbVar4[-1] == 0x5f)) {
            *param_1 = (long)pbVar4;
            if (lVar6 + 1U < (ulong)(param_1[0x26] - param_1[0x25] >> 3)) {
              lVar7 = *(long *)(param_1[0x25] + 8 + lVar6 * 8);
              goto switchD_00124932_caseD_63;
            }
          }
        }
      }
    }
  }
  lVar7 = 0;
switchD_00124932_caseD_63:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_20) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar7;
}


// ==== FUN_00124c50 @ 00124c50

long FUN_00124c50(undefined8 *param_1,char param_2)

{
  undefined8 *puVar1;
  char *pcVar2;
  long *plVar3;
  long lVar4;
  long lVar5;
  undefined8 *puVar6;
  long *plVar7;
  long lVar8;
  long lVar9;
  long lVar10;
  long lVar11;
  long lVar12;
  undefined8 *__src;
  long in_FS_OFFSET;
  undefined1 auVar13 [16];
  long local_80;
  long local_78;
  undefined8 *local_70;
  undefined8 *local_68;
  long *plStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar2 = (char *)*param_1;
  if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'I')) {
    *param_1 = pcVar2 + 1;
    if (param_2 != '\0') {
      param_1[0x54] = param_1[0x53];
      local_70 = param_1 + 0x48;
      FUN_00125bc0(param_1 + 0x53,&local_70);
      param_1[0x49] = param_1[0x48];
    }
    lVar12 = param_1[3];
    lVar8 = param_1[2];
    puVar1 = param_1 + 0x56;
LAB_00124d19:
    do {
      pcVar2 = (char *)*param_1;
      if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'E')) {
        *param_1 = pcVar2 + 1;
        lVar12 = (lVar12 - lVar8 >> 3) * 8;
        auVar13 = FUN_0012da70(param_1,param_1[2] + lVar12,param_1[3]);
        param_1[3] = lVar12 + param_1[2];
        plVar3 = (long *)param_1[0x266];
        lVar12 = plVar3[1];
        plVar7 = plVar3;
        if (lVar12 - 0xfd0U < 0xfffffffffffff010) {
          plVar7 = malloc(0x1000);
          if (plVar7 == (long *)0x0) {
LAB_0012514f:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar7 = (long)plVar3;
          plVar7[1] = 0;
          param_1[0x266] = plVar7;
          lVar12 = 0;
        }
        plVar7[1] = lVar12 + 0x20;
        lVar8 = (long)plVar7 + lVar12 + 0x10;
        *(undefined4 *)((long)plVar7 + lVar12 + 0x18) = 0x1010123;
        *(undefined ***)((long)plVar7 + lVar12 + 0x10) = &PTR_LAB_0013fd48;
        *(long *)((long)plVar7 + lVar12 + 0x20) = auVar13._0_8_;
        *(long *)((long)plVar7 + lVar12 + 0x28) = auVar13._8_8_;
        goto LAB_00125088;
      }
      if (param_2 == '\0') {
        local_70 = (undefined8 *)FUN_00123b60(param_1);
        if (local_70 == (undefined8 *)0x0) break;
        FUN_00123d20(param_1 + 2,&local_70);
        goto LAB_00124d19;
      }
      local_48 = 0;
      uStack_40 = 0;
      local_58 = 0;
      uStack_50 = 0;
      local_70 = (undefined8 *)param_1[0x53];
      plStack_60 = &local_38;
      if (local_70 == puVar1) {
        if (param_1[0x54] - (long)puVar1 == 0) {
          lVar5 = 0;
          puVar6 = puVar1;
          local_70 = &local_58;
        }
        else {
          local_70 = &local_58;
          local_68 = &local_58;
          __memmove_chk(&local_58,puVar1,param_1[0x54] - (long)puVar1,0x20);
          lVar5 = param_1[0x54] - (long)param_1[0x53] >> 3;
          puVar6 = (undefined8 *)param_1[0x53];
        }
        local_68 = local_70 + lVar5;
        param_1[0x54] = puVar6;
      }
      else {
        local_68 = (undefined8 *)param_1[0x54];
        plStack_60 = (long *)param_1[0x55];
        param_1[0x53] = puVar1;
        param_1[0x54] = puVar1;
        param_1[0x55] = param_1 + 0x5a;
      }
                    /* try { // try from 00124e05 to 00124e0c has its CatchHandler @ 00125159 */
      lVar5 = FUN_00123b60(param_1);
      puVar6 = (undefined8 *)param_1[0x53];
      local_78 = lVar5;
      if (local_70 == &local_58) {
        if (puVar6 == puVar1) {
          __src = &local_58;
        }
        else {
          free(puVar6);
          param_1[0x53] = puVar1;
          param_1[0x54] = puVar1;
          param_1[0x55] = param_1 + 0x5a;
          __src = local_70;
          puVar6 = puVar1;
        }
        if ((long)local_68 - (long)__src == 0) {
          lVar9 = 0;
          puVar6 = puVar1;
        }
        else {
          memmove(puVar6,__src,(long)local_68 - (long)__src);
          lVar9 = (long)local_68 - (long)local_70 >> 3;
          puVar6 = (undefined8 *)param_1[0x53];
          __src = local_70;
        }
        param_1[0x54] = puVar6 + lVar9;
        puVar6 = __src;
      }
      else {
        param_1[0x53] = local_70;
        if (puVar6 == puVar1) {
          param_1[0x54] = local_68;
          param_1[0x55] = plStack_60;
          puVar6 = &local_58;
          local_70 = &local_58;
          plStack_60 = &local_38;
        }
        else {
          plVar3 = (long *)param_1[0x55];
          param_1[0x54] = local_68;
          param_1[0x55] = plStack_60;
          local_70 = puVar6;
          plStack_60 = plVar3;
        }
      }
      local_68 = puVar6;
      if (lVar5 != 0) {
        FUN_00123d20(param_1 + 2,&local_78);
        local_80 = lVar5;
        if (*(char *)(lVar5 + 8) == '!') {
          lVar9 = *(long *)(lVar5 + 0x10);
          lVar4 = *(long *)(lVar5 + 0x18);
          plVar3 = (long *)param_1[0x266];
          lVar10 = plVar3[1];
          plVar7 = plVar3;
          if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
            plVar7 = malloc(0x1000);
            if (plVar7 == (long *)0x0) goto LAB_0012514f;
            *plVar7 = (long)plVar3;
            plVar7[1] = 0;
            param_1[0x266] = plVar7;
            lVar10 = 0;
          }
          plVar7[1] = lVar10 + 0x20;
          local_80 = (long)plVar7 + lVar10 + 0x10;
          *(undefined4 *)((long)plVar7 + lVar10 + 0x18) = 0x2020220;
          *(undefined ***)((long)plVar7 + lVar10 + 0x10) = &PTR_LAB_0013fcd8;
          *(long *)((long)plVar7 + lVar10 + 0x20) = lVar9;
          *(long *)((long)plVar7 + lVar10 + 0x28) = lVar4;
          if (lVar4 != 0) {
            lVar11 = 0;
            do {
              if (*(char *)(*(long *)(lVar9 + lVar11) + 10) != '\x01') goto LAB_00124fe7;
              lVar11 = lVar11 + 8;
            } while (lVar4 * 8 != lVar11);
          }
          *(undefined1 *)((long)plVar7 + lVar10 + 0x1a) = 1;
LAB_00124fe7:
          if (lVar4 != 0) {
            lVar11 = 0;
            do {
              if (*(char *)(*(long *)(lVar9 + lVar11) + 0xb) != '\x01') goto LAB_00125017;
              lVar11 = lVar11 + 8;
            } while (lVar4 * 8 != lVar11);
          }
          *(undefined1 *)((long)plVar7 + lVar10 + 0x1b) = 1;
LAB_00125017:
          if (lVar4 != 0) {
            lVar11 = 0;
            do {
              if (*(char *)(*(long *)(lVar9 + lVar11) + 9) != '\x01') goto LAB_00125056;
              lVar11 = lVar11 + 8;
            } while (lVar4 * 8 != lVar11);
          }
          *(undefined1 *)((long)plVar7 + lVar10 + 0x19) = 1;
        }
LAB_00125056:
        FUN_0012be90(*(undefined8 *)(param_1[0x54] + -8),&local_80);
        puVar6 = local_70;
      }
      if (puVar6 != &local_58) {
        free(puVar6);
      }
    } while (lVar5 != 0);
  }
  lVar8 = 0;
LAB_00125088:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar8;
}


// ==== FUN_00125180 @ 00125180

long FUN_00125180(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x20;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010125;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013fdb8;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00125220 @ 00125220

long FUN_00125220(long *param_1)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  long *__src;
  long *plVar4;
  void *__dest;
  long lVar5;
  ulong uVar6;
  long lVar7;
  ulong uVar8;
  char *pcVar9;
  size_t __n;
  ulong uVar10;
  long *plVar11;
  long in_FS_OFFSET;
  undefined8 local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar2 = (char *)*param_1;
  pcVar3 = (char *)param_1[1];
  if ((pcVar2 != pcVar3) && (*pcVar2 == 'T')) {
    pcVar9 = pcVar2 + 1;
    *param_1 = (long)pcVar9;
    if (pcVar9 != pcVar3) {
      if (*pcVar9 == 'L') {
        pcVar9 = pcVar2 + 2;
        *param_1 = (long)pcVar9;
        if ((pcVar3 != pcVar9) && (0xf5 < (byte)(*pcVar9 - 0x3aU))) {
          lVar5 = 0;
          pcVar2 = pcVar2 + 4;
          do {
            pcVar9 = pcVar2;
            pcVar1 = pcVar9 + -1;
            *param_1 = (long)pcVar1;
            lVar7 = (long)pcVar9[-2] + lVar5 * 10;
            lVar5 = lVar7 + -0x30;
            if (pcVar1 == pcVar3) break;
            pcVar2 = pcVar9 + 1;
          } while ((byte)(pcVar9[-1] - 0x30U) < 10);
          if ((pcVar1 != pcVar3) && (pcVar9[-1] == '_')) {
            uVar6 = lVar7 - 0x2f;
            *param_1 = (long)pcVar9;
            goto joined_r0x001252fb;
          }
        }
      }
      else {
        uVar6 = 0;
joined_r0x001252fb:
        if (pcVar9 != pcVar3) {
          if (*pcVar9 == '_') {
            uVar10 = 0;
LAB_0012530d:
            *param_1 = (long)(pcVar9 + 1);
            if ((*(char *)((long)param_1 + 0x309) == '\0') || (uVar6 != 0)) {
              uVar8 = param_1[0x54] - param_1[0x53] >> 3;
              if ((uVar6 < uVar8) &&
                 ((plVar11 = *(long **)(param_1[0x53] + uVar6 * 8), plVar11 != (long *)0x0 &&
                  (uVar10 < (ulong)(plVar11[1] - *plVar11 >> 3))))) {
                lVar5 = *(long *)(*plVar11 + uVar10 * 8);
              }
              else {
                lVar5 = 0;
                if (param_1[0x62] == uVar6) {
                  if (uVar6 <= uVar8) {
                    if (uVar6 == uVar8) {
                      local_40 = 0;
                      FUN_00125bc0(param_1 + 0x53,&local_40);
                    }
                    plVar11 = (long *)param_1[0x266];
                    lVar7 = plVar11[1];
                    plVar4 = plVar11;
                    if (lVar7 - 0xfd0U < 0xfffffffffffff010) {
                      plVar4 = malloc(0x1000);
                      if (plVar4 == (long *)0x0) goto LAB_001255cd;
                      *plVar4 = (long)plVar11;
                      plVar4[1] = 0;
                      param_1[0x266] = (long)plVar4;
                      lVar7 = 0;
                    }
                    plVar4[1] = lVar7 + 0x20;
                    lVar5 = (long)plVar4 + lVar7 + 0x10;
                    *(undefined4 *)((long)plVar4 + lVar7 + 0x18) = 0x1010107;
                    *(undefined ***)((long)plVar4 + lVar7 + 0x10) = &PTR_LAB_0013e688;
                    *(undefined **)((long)plVar4 + lVar7 + 0x20) = &DAT_00109e8a;
                    *(undefined **)((long)plVar4 + lVar7 + 0x28) = &DAT_00109e8e;
                  }
                }
              }
            }
            else {
              plVar11 = (long *)param_1[0x266];
              lVar5 = plVar11[1];
              plVar4 = plVar11;
              if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
                plVar4 = malloc(0x1000);
                if (plVar4 == (long *)0x0) goto LAB_001255cd;
                *plVar4 = (long)plVar11;
                plVar4[1] = 0;
                param_1[0x266] = (long)plVar4;
                lVar5 = 0;
              }
              plVar4[1] = lVar5 + 0x30;
              *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x2020224;
              *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013e768;
              *(ulong *)((long)plVar4 + lVar5 + 0x20) = uVar10;
              *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = 0;
              *(undefined1 *)((long)plVar4 + lVar5 + 0x30) = 0;
              plVar11 = (long *)param_1[0x5b];
              if (plVar11 == (long *)param_1[0x5c]) {
                __src = (long *)param_1[0x5a];
                __n = (long)plVar11 - (long)__src;
                if (__src == param_1 + 0x5d) {
                  __dest = malloc(__n * 2);
                  if (__dest == (void *)0x0) goto LAB_001255cd;
                  if (__n != 0) {
                    memmove(__dest,__src,__n);
                  }
                  param_1[0x5a] = (long)__dest;
                }
                else {
                  __dest = realloc(__src,__n * 2);
                  param_1[0x5a] = (long)__dest;
                  if (__dest == (void *)0x0) {
LAB_001255cd:
                    /* WARNING: Subroutine does not return */
                    FUN_00120930();
                  }
                }
                plVar11 = (long *)((long)__dest + ((long)__n >> 3) * 8);
                param_1[0x5c] = (long)((long)__dest + ((long)__n >> 2) * 8);
              }
              lVar5 = lVar5 + 0x10 + (long)plVar4;
              param_1[0x5b] = (long)(plVar11 + 1);
              *plVar11 = lVar5;
            }
            goto LAB_00125451;
          }
          if (0xf5 < (byte)(*pcVar9 - 0x3aU)) {
            lVar5 = 0;
            pcVar2 = pcVar9;
            do {
              pcVar9 = pcVar2 + 1;
              *param_1 = (long)pcVar9;
              lVar7 = (long)*pcVar2 + lVar5 * 10;
              lVar5 = lVar7 + -0x30;
              if (pcVar9 == pcVar3) break;
              pcVar2 = pcVar9;
            } while ((byte)(*pcVar9 - 0x30U) < 10);
            if ((pcVar9 != pcVar3) && (*pcVar9 == '_')) {
              uVar10 = lVar7 - 0x2f;
              goto LAB_0012530d;
            }
          }
        }
      }
    }
  }
  lVar5 = 0;
LAB_00125451:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar5;
}


// ==== FUN_001255e0 @ 001255e0

long FUN_001255e0(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  char *pcVar3;
  long *plVar4;
  long lVar5;
  long *plVar6;
  long lVar7;
  
  pbVar2 = (byte *)*param_1;
  if ((pbVar2 != (byte *)param_1[1]) && (*pbVar2 == 0x44)) {
    pbVar1 = pbVar2 + 1;
    *param_1 = (long)pbVar1;
    if ((pbVar1 != (byte *)param_1[1]) && ((*pbVar1 | 0x20) == 0x74)) {
      *param_1 = (long)(pbVar2 + 2);
      lVar5 = FUN_00125e60(param_1);
      if (((lVar5 != 0) && (pcVar3 = (char *)*param_1, pcVar3 != (char *)param_1[1])) &&
         (*pcVar3 == 'E')) {
        *param_1 = (long)(pcVar3 + 1);
        plVar4 = (long *)param_1[0x266];
        lVar7 = plVar4[1];
        plVar6 = plVar4;
        if (lVar7 - 0xfb0U < 0xfffffffffffff010) {
          plVar6 = malloc(0x1000);
          if (plVar6 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar6 = (long)plVar4;
          plVar6[1] = 0;
          param_1[0x266] = (long)plVar6;
          lVar7 = 0;
        }
        plVar6[1] = lVar7 + 0x40;
        *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x1010134;
        *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013f798;
        *(char **)((long)plVar6 + lVar7 + 0x20) = "decltype(";
        *(char **)((long)plVar6 + lVar7 + 0x28) = "";
        *(long *)((long)plVar6 + lVar7 + 0x30) = lVar5;
        *(undefined **)((long)plVar6 + lVar7 + 0x38) = &DAT_0010af8a;
        *(undefined **)((long)plVar6 + lVar7 + 0x40) = &DAT_0010af8b;
        return (long)plVar6 + lVar7 + 0x10;
      }
    }
  }
  return 0;
}


// ==== FUN_00125700 @ 00125700

long FUN_00125700(long *param_1,long param_2)

{
  undefined1 uVar1;
  char cVar2;
  undefined2 uVar3;
  long *plVar4;
  long *plVar5;
  ulong uVar6;
  ulong uVar7;
  long lVar8;
  char *pcVar9;
  char *pcVar10;
  char *pcVar11;
  long lVar12;
  
  pcVar9 = (char *)*param_1;
  pcVar11 = (char *)param_1[1];
  lVar12 = param_2;
  if (pcVar9 != pcVar11) {
    do {
      if (*pcVar9 != 'B') {
        return lVar12;
      }
      pcVar10 = pcVar9 + 1;
      *param_1 = (long)pcVar10;
      if ((pcVar11 == pcVar10) || ((byte)(*pcVar10 - 0x3aU) < 0xf6)) {
        return 0;
      }
      uVar7 = 0;
      pcVar9 = pcVar9 + 2;
      do {
        pcVar10 = pcVar9;
        uVar6 = uVar7;
        *param_1 = (long)pcVar10;
        cVar2 = pcVar10[-1];
        uVar7 = ((long)cVar2 + uVar6 * 10) - 0x30;
        if (pcVar10 == pcVar11) {
          pcVar9 = pcVar11;
          goto LAB_001257e3;
        }
        pcVar9 = pcVar10 + 1;
      } while ((byte)(*pcVar10 - 0x30U) < 10);
      pcVar9 = pcVar10;
LAB_001257e3:
      if ((ulong)((long)pcVar11 - (long)pcVar9) < uVar7) {
        return 0;
      }
      *param_1 = (long)(pcVar10 + (long)cVar2 + uVar6 * 10 + -0x30);
      if (uVar7 == 0) {
        return 0;
      }
      plVar4 = (long *)param_1[0x266];
      lVar8 = plVar4[1];
      plVar5 = plVar4;
      if (lVar8 - 0xfc0U < 0xfffffffffffff010) {
        plVar5 = malloc(0x1000);
        if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        *plVar5 = (long)plVar4;
        plVar5[1] = 0;
        param_1[0x266] = (long)plVar5;
        lVar8 = 0;
      }
      plVar5[1] = lVar8 + 0x30;
      param_2 = (long)plVar5 + lVar8 + 0x10;
      uVar3 = *(undefined2 *)(lVar12 + 9);
      uVar1 = *(undefined1 *)(lVar12 + 0xb);
      *(undefined1 *)((long)plVar5 + lVar8 + 0x18) = 8;
      *(undefined2 *)((long)plVar5 + lVar8 + 0x19) = uVar3;
      *(undefined1 *)((long)plVar5 + lVar8 + 0x1b) = uVar1;
      *(undefined ***)((long)plVar5 + lVar8 + 0x10) = &PTR_LAB_0013fb18;
      *(long *)((long)plVar5 + lVar8 + 0x20) = lVar12;
      *(char **)((long)plVar5 + lVar8 + 0x28) = pcVar9;
      *(char **)((long)plVar5 + lVar8 + 0x30) = pcVar10 + (long)cVar2 + uVar6 * 10 + -0x30;
      pcVar9 = (char *)*param_1;
      pcVar11 = (char *)param_1[1];
      lVar12 = param_2;
    } while (pcVar9 != pcVar11);
  }
  return param_2;
}


// ==== FUN_00125870 @ 00125870

undefined8 FUN_00125870(undefined8 *param_1)

{
  char *pcVar1;
  long *plVar2;
  long lVar3;
  long *plVar4;
  undefined8 uVar5;
  long lVar6;
  long in_FS_OFFSET;
  undefined1 auVar7 [16];
  long local_30;
  long local_28;
  
  local_28 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar1 = (char *)*param_1;
  if ((char *)param_1[1] == pcVar1) {
LAB_001258d3:
    if ((((ulong)((long)param_1[1] - (long)pcVar1) < 2) || (*pcVar1 != 'D')) || (pcVar1[1] != 'C'))
    {
      lVar3 = FUN_0012e440(param_1);
joined_r0x00125a0d:
      if (lVar3 != 0) goto LAB_00125a0f;
    }
    else {
      *param_1 = pcVar1 + 2;
      lVar3 = param_1[3];
      lVar6 = param_1[2];
      local_30 = FUN_0012e110(param_1);
      if (local_30 != 0) {
        do {
          FUN_00123d20(param_1 + 2,&local_30);
          pcVar1 = (char *)*param_1;
          if ((pcVar1 != (char *)param_1[1]) && (*pcVar1 == 'E')) {
            *param_1 = pcVar1 + 1;
            lVar3 = (lVar3 - lVar6 >> 3) * 8;
            auVar7 = FUN_0012da70(param_1,param_1[2] + lVar3,param_1[3]);
            param_1[3] = lVar3 + param_1[2];
            plVar2 = (long *)param_1[0x266];
            lVar6 = plVar2[1];
            plVar4 = plVar2;
            if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
              plVar4 = malloc(0x1000);
              if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
                FUN_00120930();
              }
              *plVar4 = (long)plVar2;
              plVar4[1] = 0;
              param_1[0x266] = plVar4;
              lVar6 = 0;
            }
            plVar4[1] = lVar6 + 0x20;
            lVar3 = (long)plVar4 + lVar6 + 0x10;
            *(undefined4 *)((long)plVar4 + lVar6 + 0x18) = 0x101012e;
            *(undefined ***)((long)plVar4 + lVar6 + 0x10) = &PTR_LAB_0013fb88;
            *(long *)((long)plVar4 + lVar6 + 0x20) = auVar7._0_8_;
            *(long *)((long)plVar4 + lVar6 + 0x28) = auVar7._8_8_;
            goto LAB_00125a0f;
          }
          local_30 = FUN_0012e110(param_1);
        } while (local_30 != 0);
      }
    }
LAB_00125a2c:
    if (*(long *)(in_FS_OFFSET + 0x28) != local_28) {
LAB_00125a4f:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
    uVar5 = 0;
  }
  else {
    if (*pcVar1 == 'U') {
      lVar3 = FUN_0012a1a0(param_1);
      goto joined_r0x00125a0d;
    }
    if (8 < (byte)(*pcVar1 - 0x31U)) goto LAB_001258d3;
    lVar3 = FUN_0012e110(param_1);
    if (lVar3 == 0) goto LAB_00125a2c;
LAB_00125a0f:
    uVar5 = FUN_00125700(param_1,lVar3);
    if (*(long *)(in_FS_OFFSET + 0x28) != local_28) goto LAB_00125a4f;
  }
  return uVar5;
}


// ==== FUN_00125bc0 @ 00125bc0

void FUN_00125bc0(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *__src;
  undefined8 uVar1;
  void *__dest;
  size_t __n;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)param_1[1];
  if (puVar2 == (undefined8 *)param_1[2]) {
    __src = (undefined8 *)*param_1;
    __n = (long)puVar2 - (long)__src;
    if (__src == param_1 + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_00125c5b;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *param_1 = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *param_1 = __dest;
      if (__dest == (void *)0x0) {
LAB_00125c5b:
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
    }
    puVar2 = (undefined8 *)((long)__dest + ((long)__n >> 3) * 8);
    param_1[1] = puVar2;
    param_1[2] = (void *)((long)__dest + ((long)__n >> 2) * 8);
  }
  uVar1 = *param_2;
  param_1[1] = puVar2 + 1;
  *puVar2 = uVar1;
  return;
}


// ==== FUN_00125c60 @ 00125c60

long FUN_00125c60(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_00125e60 @ 00125e60

undefined8 FUN_00125e60(long *param_1)

{
  char *pcVar1;
  long lVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined8 uVar15;
  char *pcVar16;
  undefined *puVar17;
  char cVar18;
  ulong uVar19;
  undefined *puVar20;
  char *pcVar21;
  long lVar22;
  long in_FS_OFFSET;
  long local_58;
  undefined1 local_50 [16];
  ulong local_40;
  undefined1 local_31;
  long local_30;
  
  auVar14._8_8_ = local_50._8_8_;
  auVar14._0_8_ = local_50._0_8_;
  auVar13._8_8_ = local_50._8_8_;
  auVar13._0_8_ = local_50._0_8_;
  auVar12._8_8_ = local_50._8_8_;
  auVar12._0_8_ = local_50._0_8_;
  auVar11._8_8_ = local_50._8_8_;
  auVar11._0_8_ = local_50._0_8_;
  auVar10._8_8_ = local_50._8_8_;
  auVar10._0_8_ = local_50._0_8_;
  auVar9._8_8_ = local_50._8_8_;
  auVar9._0_8_ = local_50._0_8_;
  auVar8._8_8_ = local_50._8_8_;
  auVar8._0_8_ = local_50._0_8_;
  auVar7._8_8_ = local_50._8_8_;
  auVar7._0_8_ = local_50._0_8_;
  auVar6._8_8_ = local_50._8_8_;
  auVar6._0_8_ = local_50._0_8_;
  auVar5._8_8_ = local_50._8_8_;
  auVar5._0_8_ = local_50._0_8_;
  auVar4._8_8_ = local_50._8_8_;
  auVar4._0_8_ = local_50._0_8_;
  auVar3._8_8_ = local_50._8_8_;
  auVar3._0_8_ = local_50._0_8_;
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar16 = (char *)*param_1;
  pcVar21 = (char *)param_1[1];
  uVar19 = (long)pcVar21 - (long)pcVar16;
  if (uVar19 < 2) goto LAB_00125e8e;
  cVar18 = *pcVar16;
  if ((cVar18 == 'g') && (pcVar16[1] == 's')) {
    pcVar16 = pcVar16 + 2;
    *param_1 = (long)pcVar16;
    uVar19 = (long)pcVar21 - (long)pcVar16;
    local_31 = 1;
    if (uVar19 < 2) goto LAB_00125e8e;
    cVar18 = *pcVar16;
  }
  else {
    local_31 = 0;
  }
  switch(cVar18) {
  case '1':
  case '2':
  case '3':
  case '4':
  case '5':
  case '6':
  case '7':
  case '8':
  case '9':
switchD_00125f01_caseD_31:
    uVar15 = FUN_00128710(param_1);
    goto switchD_00125f6a_caseD_66;
  default:
    uVar15 = 0;
    local_50 = auVar3;
    if ((uVar19 < 0xb) || (local_50 = auVar4, cVar18 != 'u')) goto switchD_00125f6a_caseD_66;
    if ((pcVar16[1] == '8') && (pcVar16[2] == '_')) {
      if (((((pcVar16[3] == '_') && (pcVar16[4] == 'u')) && (pcVar16[5] == 'u')) &&
          ((pcVar16[6] == 'i' && (pcVar16[7] == 'd')))) &&
         ((pcVar16[8] == 'o' && ((pcVar16[9] == 'f' && (pcVar16[10] == 't')))))) {
        *param_1 = (long)(pcVar16 + 0xb);
        local_50._0_8_ = FUN_00121da0(param_1);
      }
      else {
        if ((((pcVar16[3] != '_') ||
             (((pcVar16[4] != 'u' || (pcVar16[5] != 'u')) || (pcVar16[6] != 'i')))) ||
            (((pcVar16[7] != 'd' || (pcVar16[8] != 'o')) || (pcVar16[9] != 'f')))) ||
           (pcVar16[10] != 'z')) goto LAB_00125e8e;
        *param_1 = (long)(pcVar16 + 0xb);
        local_50._0_8_ = FUN_00125e60(param_1);
      }
      if (local_50._0_8_ != 0) {
        uVar15 = FUN_00129e30(param_1,local_50);
        goto switchD_00125f6a_caseD_66;
      }
    }
    goto LAB_00125e8e;
  case 'L':
    uVar15 = FUN_00126f90(param_1);
    goto switchD_00125f6a_caseD_66;
  case 'T':
    uVar15 = FUN_00125220(param_1);
    goto switchD_00125f6a_caseD_66;
  case 'a':
    uVar15 = 0;
    switch(pcVar16[1]) {
    case 'N':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a292;
      puVar17 = &DAT_0010a294;
      break;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'S':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a6ad;
      puVar17 = &DAT_0010a6ae;
      break;
    case 'a':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010ad6a;
      puVar17 = &DAT_0010ad6c;
      break;
    case 'd':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010ae19;
      puVar17 = &DAT_0010ae1a;
      goto LAB_00126c86;
    case 'n':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010ae19;
      puVar17 = &DAT_0010ae1a;
      break;
    case 't':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00121da0(param_1);
      goto LAB_00126a25;
    case 'z':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
LAB_00126a25:
      if (local_50._0_8_ != 0) {
        uVar15 = FUN_00126ed0(param_1,"alignof (",local_50);
        goto switchD_00125f6a_caseD_66;
      }
      goto LAB_00125e8e;
    }
    break;
  case 'c':
    uVar15 = 0;
    local_50 = auVar14;
    switch(pcVar16[1]) {
    case 'c':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00121da0(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        uVar15 = FUN_001281a0(param_1,local_50,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
      break;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'l':
      *param_1 = (long)(pcVar16 + 2);
      local_40 = FUN_00125e60(param_1);
      if (local_40 != 0) {
        lVar22 = param_1[3];
        lVar2 = param_1[2];
        while( true ) {
          pcVar21 = (char *)*param_1;
          if ((pcVar21 != (char *)param_1[1]) && (*pcVar21 == 'E')) {
            *param_1 = (long)(pcVar21 + 1);
            lVar22 = (lVar22 - lVar2 >> 3) * 8;
            local_50 = FUN_0012da70(param_1,param_1[2] + lVar22,param_1[3]);
            param_1[3] = lVar22 + param_1[2];
            uVar15 = FUN_00128250(param_1,&local_40,local_50);
            goto switchD_00125f6a_caseD_66;
          }
          local_50._0_8_ = FUN_00125e60(param_1);
          if (local_50._0_8_ == 0) break;
          FUN_00123d20(param_1 + 2,local_50);
        }
      }
      break;
    case 'm':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a16c;
      puVar17 = &DAT_0010a16d;
      goto LAB_00126d85;
    case 'o':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010ae1b;
      puVar17 = &DAT_0010ae1c;
      goto LAB_00126c86;
    case 'v':
      uVar15 = FUN_001282f0(param_1);
      goto switchD_00125f6a_caseD_66;
    }
    goto LAB_00125e8e;
  case 'd':
    uVar15 = 0;
    local_50 = auVar13;
    switch(pcVar16[1]) {
    case 'V':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_00109e3f;
      puVar17 = &DAT_00109e41;
      goto LAB_00126d85;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'a':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if (local_50._0_8_ != 0) {
        local_40 = CONCAT71(local_40._1_7_,1);
LAB_00126cb6:
        uVar15 = FUN_001285b0(param_1,local_50,&local_31,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
      break;
    case 'c':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00121da0(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        uVar15 = FUN_00128660(param_1,local_50,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
      break;
    case 'e':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a0a2;
      puVar17 = &DAT_0010a0a3;
      goto LAB_00126c86;
    case 'l':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if (local_50._0_8_ != 0) {
        local_40 = local_40 & 0xffffffffffffff00;
        goto LAB_00126cb6;
      }
      break;
    case 'n':
      goto switchD_00125f01_caseD_31;
    case 's':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        puVar17 = &DAT_0010a560;
LAB_00126d0d:
        uVar15 = FUN_00128d20(param_1,local_50,puVar17,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
      break;
    case 't':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        uVar15 = FUN_00128de0(param_1,local_50,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
      break;
    case 'v':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_00109aeb;
      puVar17 = &DAT_00109aec;
      goto LAB_00126d85;
    }
    goto LAB_00125e8e;
  case 'e':
    cVar18 = pcVar16[1];
    if (cVar18 == 'O') {
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a501;
      puVar17 = &DAT_0010a503;
    }
    else if (cVar18 == 'q') {
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a504;
      puVar17 = &DAT_0010a506;
    }
    else {
      if (cVar18 != 'o') goto LAB_00125e8e;
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a7aa;
      puVar17 = &DAT_0010a7ab;
    }
    break;
  case 'f':
    if ((pcVar16[1] == 'p') ||
       (((pcVar16[1] == 'L' && (2 < uVar19)) && (0xfffffff5 < (int)pcVar16[2] - 0x3aU)))) {
      uVar15 = FUN_001278d0(param_1);
    }
    else {
      uVar15 = FUN_00127b70(param_1);
    }
    goto switchD_00125f6a_caseD_66;
  case 'g':
    if (pcVar16[1] == 't') {
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a507;
      puVar17 = &DAT_0010a508;
    }
    else {
      if (pcVar16[1] != 'e') goto LAB_00125e8e;
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_001099e6;
      puVar17 = &DAT_001099e8;
    }
    break;
  case 'i':
    if (pcVar16[1] == 'l') {
      pcVar16 = pcVar16 + 2;
      *param_1 = (long)pcVar16;
      lVar22 = param_1[3];
      lVar2 = param_1[2];
      if (pcVar16 == pcVar21) goto LAB_0012646e;
      while (*pcVar16 != 'E') {
LAB_0012646e:
        do {
          local_50._0_8_ = FUN_00128f30(param_1);
          if (local_50._0_8_ == 0) goto LAB_00125e8e;
          FUN_00123d20(param_1 + 2,local_50);
          pcVar16 = (char *)*param_1;
        } while (pcVar16 == (char *)param_1[1]);
      }
      *param_1 = (long)(pcVar16 + 1);
      lVar22 = (lVar22 - lVar2 >> 3) * 8;
      local_50 = FUN_0012da70(param_1,param_1[2] + lVar22,param_1[3]);
      param_1[3] = lVar22 + param_1[2];
      uVar15 = FUN_001291c0(param_1,&local_40,local_50);
      goto switchD_00125f6a_caseD_66;
    }
    if (pcVar16[1] == 'x') {
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        uVar15 = FUN_00128e90(param_1,local_50,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
    }
    goto LAB_00125e8e;
  case 'l':
    uVar15 = 0;
    local_50 = auVar12;
    switch(pcVar16[1]) {
    case 'S':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a876;
      puVar17 = &DAT_0010a879;
      break;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'e':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010abec;
      puVar17 = &DAT_0010abee;
      break;
    case 's':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010aa26;
      puVar17 = &DAT_0010aa28;
      break;
    case 't':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_00109978;
      puVar17 = &DAT_00109979;
    }
    break;
  case 'm':
    uVar15 = 0;
    local_50 = auVar11;
    switch(pcVar16[1]) {
    case 'I':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_00109e42;
      puVar17 = &DAT_00109e44;
      break;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'L':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a16e;
      puVar17 = &DAT_0010a170;
      break;
    case 'i':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_00109e8f;
      puVar17 = &DAT_00109e90;
      break;
    case 'l':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a0a2;
      puVar17 = &DAT_0010a0a3;
      break;
    case 'm':
      pcVar1 = pcVar16 + 2;
      *param_1 = (long)pcVar1;
      if ((pcVar1 != pcVar21) && (*pcVar1 == '_')) {
        *param_1 = (long)(pcVar16 + 3);
        puVar20 = &DAT_0010af8c;
        puVar17 = &DAT_0010af8e;
        goto LAB_00126c86;
      }
      local_50._0_8_ = FUN_00125e60(param_1);
      if (local_50._0_8_ != 0) {
        puVar17 = &DAT_0010af8c;
LAB_00126daf:
        uVar15 = FUN_00129250(param_1,local_50,puVar17);
        goto switchD_00125f6a_caseD_66;
      }
      goto LAB_00125e8e;
    }
    break;
  case 'n':
    uVar15 = 0;
    local_50 = auVar10;
    switch(pcVar16[1]) {
    case 'a':
    case 'w':
      uVar15 = FUN_00129300(param_1);
    default:
      goto switchD_00125f6a_caseD_66;
    case 'e':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010ab43;
      puVar17 = &DAT_0010ab45;
      goto LAB_00126d85;
    case 'g':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_00109e8f;
      puVar17 = &DAT_00109e90;
      break;
    case 't':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a426;
      puVar17 = &DAT_0010a427;
      break;
    case 'x':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if (local_50._0_8_ != 0) {
        uVar15 = FUN_00129660(param_1,local_50);
        goto switchD_00125f6a_caseD_66;
      }
      goto LAB_00125e8e;
    }
LAB_00126c86:
    uVar15 = FUN_001280f0(param_1,puVar20,puVar17);
    goto switchD_00125f6a_caseD_66;
  case 'o':
    uVar15 = 0;
    local_50 = auVar9;
    switch(pcVar16[1]) {
    case 'R':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a7ac;
      puVar17 = &DAT_0010a7ae;
      break;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'n':
      goto switchD_00125f01_caseD_31;
    case 'o':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a6af;
      puVar17 = &DAT_0010a6b1;
      break;
    case 'r':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010ad6d;
      puVar17 = &DAT_0010ad6e;
    }
    break;
  case 'p':
    uVar15 = 0;
    local_50 = auVar8;
    switch(pcVar16[1]) {
    case 'L':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a5ac;
      puVar17 = &DAT_0010a5ae;
      break;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'l':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a7af;
      puVar17 = &DAT_0010a7b0;
      break;
    case 'm':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a295;
      puVar17 = &DAT_0010a298;
      break;
    case 'p':
      pcVar1 = pcVar16 + 2;
      *param_1 = (long)pcVar1;
      if ((pcVar1 != pcVar21) && (*pcVar1 == '_')) {
        *param_1 = (long)(pcVar16 + 3);
        puVar20 = &DAT_0010997a;
        puVar17 = &DAT_0010997c;
        goto LAB_00126c86;
      }
      local_50._0_8_ = FUN_00125e60(param_1);
      if (local_50._0_8_ != 0) {
        puVar17 = &DAT_0010997a;
        goto LAB_00126daf;
      }
      goto LAB_00125e8e;
    case 's':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a7af;
      puVar17 = &DAT_0010a7b0;
      goto LAB_00126c86;
    case 't':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        puVar17 = &DAT_0010a936;
        goto LAB_00126d0d;
      }
      goto LAB_00125e8e;
    }
    break;
  case 'q':
    if (pcVar16[1] == 'u') {
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        local_58 = FUN_00125e60(param_1);
        if (local_58 != 0) {
          uVar15 = FUN_00129720(param_1,local_50,&local_40,&local_58);
          goto switchD_00125f6a_caseD_66;
        }
      }
    }
    goto LAB_00125e8e;
  case 'r':
    uVar15 = 0;
    local_50 = auVar7;
    switch(pcVar16[1]) {
    case 'M':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010abef;
      puVar17 = &DAT_0010abf1;
      break;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'S':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010a5af;
      puVar17 = &DAT_0010a5b2;
      break;
    case 'c':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00121da0(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        uVar15 = FUN_001297d0(param_1,local_50,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
      goto LAB_00125e8e;
    case 'm':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_0010b20d;
      puVar17 = &DAT_0010b20e;
      break;
    case 's':
      *param_1 = (long)(pcVar16 + 2);
      puVar20 = &DAT_00109c01;
      puVar17 = &DAT_00109c03;
    }
    break;
  case 's':
    uVar15 = 0;
    local_50 = auVar6;
    switch(pcVar16[1]) {
    case 'P':
      pcVar16 = pcVar16 + 2;
      *param_1 = (long)pcVar16;
      lVar22 = param_1[3];
      lVar2 = param_1[2];
      if (pcVar16 == pcVar21) goto LAB_00126239;
      while (*pcVar16 != 'E') {
LAB_00126239:
        do {
          local_50._0_8_ = FUN_00123b60(param_1);
          if (local_50._0_8_ == 0) goto LAB_00125e8e;
          FUN_00123d20(param_1 + 2,local_50);
          pcVar16 = (char *)*param_1;
        } while (pcVar16 == (char *)param_1[1]);
      }
      *param_1 = (long)(pcVar16 + 1);
      lVar22 = (lVar22 - lVar2 >> 3) * 8;
      local_50 = FUN_0012da70(param_1,param_1[2] + lVar22,param_1[3]);
      param_1[3] = lVar22 + param_1[2];
      lVar22 = FUN_00129bd0(param_1,local_50);
      local_50._0_8_ = lVar22;
LAB_00126eaf:
      uVar15 = FUN_00129b10(param_1,local_50);
    default:
      goto switchD_00125f6a_caseD_66;
    case 'Z':
      pcVar16 = pcVar16 + 2;
      *param_1 = (long)pcVar16;
      if (pcVar21 != pcVar16) {
        if (*pcVar16 == 'f') {
          local_50._0_8_ = FUN_001278d0(param_1);
          if (local_50._0_8_ != 0) goto LAB_00126eaf;
        }
        else if ((*pcVar16 == 'T') && (local_50._0_8_ = FUN_00125220(param_1), local_50._0_8_ != 0))
        {
          uVar15 = FUN_00129a80(param_1,local_50);
          goto switchD_00125f6a_caseD_66;
        }
      }
      break;
    case 'c':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00121da0(param_1);
      if ((local_50._0_8_ != 0) && (local_40 = FUN_00125e60(param_1), local_40 != 0)) {
        uVar15 = FUN_00129880(param_1,local_50,&local_40);
        goto switchD_00125f6a_caseD_66;
      }
      break;
    case 'p':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if (local_50._0_8_ != 0) {
        uVar15 = FUN_00129930(param_1,local_50);
        goto switchD_00125f6a_caseD_66;
      }
      break;
    case 'r':
      goto switchD_00125f01_caseD_31;
    case 't':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00121da0(param_1);
      goto LAB_00126b34;
    case 'z':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
LAB_00126b34:
      if (local_50._0_8_ != 0) {
        pcVar21 = "sizeof (";
LAB_00126b49:
        uVar15 = FUN_001299c0(param_1,pcVar21,local_50);
        goto switchD_00125f6a_caseD_66;
      }
    }
    goto LAB_00125e8e;
  case 't':
    uVar15 = 0;
    local_50 = auVar5;
    switch(pcVar16[1]) {
    case 'e':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      goto LAB_0012656b;
    default:
      goto switchD_00125f6a_caseD_66;
    case 'i':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00121da0(param_1);
LAB_0012656b:
      if (local_50._0_8_ == 0) break;
      pcVar21 = "typeid (";
      goto LAB_00126b49;
    case 'l':
      *param_1 = (long)(pcVar16 + 2);
      local_40 = FUN_00121da0(param_1);
      if (local_40 != 0) {
        lVar22 = param_1[3];
        lVar2 = param_1[2];
        while( true ) {
          pcVar21 = (char *)*param_1;
          if ((pcVar21 != (char *)param_1[1]) && (*pcVar21 == 'E')) {
            *param_1 = (long)(pcVar21 + 1);
            lVar22 = (lVar22 - lVar2 >> 3) * 8;
            local_50 = FUN_0012da70(param_1,param_1[2] + lVar22,param_1[3]);
            param_1[3] = lVar22 + param_1[2];
            uVar15 = FUN_00129c60(param_1,&local_40,local_50);
            goto switchD_00125f6a_caseD_66;
          }
          local_50._0_8_ = FUN_00128f30(param_1);
          if (local_50._0_8_ == 0) break;
          FUN_00123d20(param_1 + 2,local_50);
        }
      }
      break;
    case 'r':
      *param_1 = (long)(pcVar16 + 2);
      uVar15 = FUN_00129d00(param_1,"throw");
      goto switchD_00125f6a_caseD_66;
    case 'w':
      *param_1 = (long)(pcVar16 + 2);
      local_50._0_8_ = FUN_00125e60(param_1);
      if (local_50._0_8_ != 0) {
        uVar15 = FUN_00129da0(param_1,local_50);
        goto switchD_00125f6a_caseD_66;
      }
    }
LAB_00125e8e:
    uVar15 = 0;
    goto switchD_00125f6a_caseD_66;
  }
LAB_00126d85:
  uVar15 = FUN_00128020(param_1,puVar20,puVar17);
switchD_00125f6a_caseD_66:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_30) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar15;
}


// ==== FUN_00126ed0 @ 00126ed0

long FUN_00126ed0(long param_1,char *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  size_t sVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar3 = plVar1;
  if (lVar5 - 0xfb0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar5 = 0;
  }
  plVar3[1] = lVar5 + 0x40;
  sVar4 = strlen(param_2);
  uVar2 = *param_3;
  *(undefined4 *)((long)plVar3 + lVar5 + 0x18) = 0x1010134;
  *(undefined ***)((long)plVar3 + lVar5 + 0x10) = &PTR_LAB_0013f798;
  *(char **)((long)plVar3 + lVar5 + 0x20) = param_2;
  *(char **)((long)plVar3 + lVar5 + 0x28) = param_2 + sVar4;
  *(undefined8 *)((long)plVar3 + lVar5 + 0x30) = uVar2;
  *(undefined **)((long)plVar3 + lVar5 + 0x38) = &DAT_0010af8a;
  *(undefined **)((long)plVar3 + lVar5 + 0x40) = &DAT_0010af8b;
  return (long)plVar3 + lVar5 + 0x10;
}


// ==== FUN_00126f90 @ 00126f90

long FUN_00126f90(long *param_1)

{
  char cVar1;
  long *plVar2;
  char *pcVar3;
  long lVar4;
  long *plVar5;
  undefined **ppuVar6;
  char *pcVar7;
  long lVar8;
  ulong uVar9;
  char *pcVar10;
  char *pcVar11;
  long in_FS_OFFSET;
  undefined8 local_50;
  char *local_48;
  long local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar7 = (char *)*param_1;
  pcVar11 = (char *)param_1[1];
  if ((pcVar7 == pcVar11) || (*pcVar7 != 'L')) goto LAB_0012705a;
  pcVar10 = pcVar7 + 1;
  *param_1 = (long)pcVar10;
  uVar9 = (long)pcVar11 - (long)pcVar10;
  if (pcVar11 == pcVar10) {
switchD_00126ff3_caseD_42:
    local_40 = FUN_00121da0(param_1);
    if (local_40 != 0) {
      pcVar7 = (char *)*param_1;
      pcVar11 = (char *)param_1[1];
      if (pcVar11 != pcVar7) {
        pcVar10 = pcVar7;
        if (0xfffffff5 < (int)*pcVar7 - 0x3aU) {
          do {
            pcVar3 = pcVar10;
            pcVar10 = pcVar3 + 1;
            *param_1 = (long)pcVar10;
            if (pcVar10 == pcVar11) {
              local_48 = pcVar11;
              goto LAB_001270b4;
            }
          } while (0xfffffff5 < (int)*pcVar10 - 0x3aU);
          local_48 = pcVar10;
LAB_001270b4:
          lVar4 = 0;
          local_50 = pcVar7;
          if ((pcVar7 != local_48) && (pcVar10 != pcVar11)) {
            if (*pcVar10 != 'E') goto LAB_0012705a;
            *param_1 = (long)(pcVar3 + 2);
            lVar4 = FUN_0012a890(param_1,&local_40,&local_50);
          }
          goto switchD_00126ff3_caseD_54;
        }
      }
    }
    goto LAB_0012705a;
  }
  cVar1 = *pcVar10;
  lVar4 = 0;
  switch(cVar1) {
  case 'A':
    local_50 = (char *)FUN_00121da0(param_1);
    if (((local_50 == (char *)0x0) || (pcVar7 = (char *)*param_1, pcVar7 == (char *)param_1[1])) ||
       (*pcVar7 != 'E')) goto LAB_0012705a;
    *param_1 = (long)(pcVar7 + 1);
    lVar4 = FUN_0012a070(param_1,&local_50);
    goto switchD_00126ff3_caseD_54;
  default:
    goto switchD_00126ff3_caseD_42;
  case 'D':
    lVar4 = 0;
    if ((uVar9 < 3) || (cVar1 != 'D')) goto switchD_00126ff3_caseD_54;
    if ((pcVar7[2] != 'n') || (pcVar7[3] != 'E')) goto LAB_0012705a;
    *param_1 = (long)(pcVar7 + 4);
    lVar4 = FUN_0012a100(param_1,"nullptr");
    goto LAB_001277f0;
  case 'T':
    goto switchD_00126ff3_caseD_54;
  case 'U':
    if ((uVar9 < 2) || (pcVar7[2] != 'l')) goto LAB_0012705a;
    lVar4 = 0;
    local_50 = (char *)FUN_0012a1a0(param_1,0);
    if (local_50 != (char *)0x0) {
      pcVar7 = (char *)*param_1;
      if ((pcVar7 == (char *)param_1[1]) || (*pcVar7 != 'E')) goto LAB_0012705a;
      *param_1 = (long)(pcVar7 + 1);
      lVar4 = FUN_0012a800(param_1,&local_50);
    }
    goto switchD_00126ff3_caseD_54;
  case '_':
    lVar4 = 0;
    if ((1 < uVar9) && (cVar1 == '_')) {
      if (pcVar7[2] == 'Z') {
        *param_1 = (long)(pcVar7 + 3);
        lVar4 = FUN_001213e0(param_1);
        if (((lVar4 != 0) && (pcVar7 = (char *)*param_1, pcVar7 != (char *)param_1[1])) &&
           (*pcVar7 == 'E')) {
          *param_1 = (long)(pcVar7 + 1);
          goto switchD_00126ff3_caseD_54;
        }
      }
      goto LAB_0012705a;
    }
    goto switchD_00126ff3_caseD_54;
  case 'a':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "signed char";
    pcVar7 = "";
    break;
  case 'b':
    lVar4 = 0;
    if ((2 < uVar9) && (cVar1 == 'b')) {
      if (pcVar7[2] == '1') {
        if (pcVar7[3] == 'E') {
          *param_1 = (long)(pcVar7 + 4);
          local_50 = (char *)CONCAT44(local_50._4_4_,1);
          goto LAB_00127823;
        }
      }
      else if ((pcVar7[2] == '0') && (pcVar7[3] == 'E')) {
        *param_1 = (long)(pcVar7 + 4);
        local_50 = (char *)((ulong)local_50._4_4_ << 0x20);
LAB_00127823:
        lVar4 = FUN_00129fe0(param_1,&local_50);
        goto switchD_00126ff3_caseD_54;
      }
      goto LAB_0012705a;
    }
    goto switchD_00126ff3_caseD_54;
  case 'c':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "char";
    pcVar7 = "";
    break;
  case 'd':
    *param_1 = (long)(pcVar7 + 2);
    if (((((0x10 < (ulong)((long)pcVar11 - (long)(pcVar7 + 2))) &&
          ((0xfffffff5 < (int)pcVar7[2] - 0x3aU ||
           (0xfffffff9 < ((int)pcVar7[2] & 0xffffffdfU) - 0x47)))) &&
         (((0xfffffff5 < (int)pcVar7[3] - 0x3aU ||
           (0xfffffff9 < ((int)pcVar7[3] & 0xffffffdfU) - 0x47)) &&
          ((((0xfffffff5 < (int)pcVar7[4] - 0x3aU ||
             (0xfffffff9 < ((int)pcVar7[4] & 0xffffffdfU) - 0x47)) &&
            ((0xfffffff5 < (int)pcVar7[5] - 0x3aU ||
             (0xfffffff9 < ((int)pcVar7[5] & 0xffffffdfU) - 0x47)))) &&
           ((0xfffffff5 < (int)pcVar7[6] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[6] & 0xffffffdfU) - 0x47)))))))) &&
        (((0xfffffff5 < (int)pcVar7[7] - 0x3aU ||
          (0xfffffff9 < ((int)pcVar7[7] & 0xffffffdfU) - 0x47)) &&
         ((((0xfffffff5 < (int)pcVar7[8] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[8] & 0xffffffdfU) - 0x47)) &&
           ((0xfffffff5 < (int)pcVar7[9] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[9] & 0xffffffdfU) - 0x47)))) &&
          (((0xfffffff5 < (int)pcVar7[10] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[10] & 0xffffffdfU) - 0x47)) &&
           ((0xfffffff5 < (int)pcVar7[0xb] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[0xb] & 0xffffffdfU) - 0x47)))))))))) &&
       ((((((0xfffffff5 < (int)pcVar7[0xc] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[0xc] & 0xffffffdfU) - 0x47)) &&
           ((0xfffffff5 < (int)pcVar7[0xd] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[0xd] & 0xffffffdfU) - 0x47)))) &&
          ((0xfffffff5 < (int)pcVar7[0xe] - 0x3aU ||
           (0xfffffff9 < ((int)pcVar7[0xe] & 0xffffffdfU) - 0x47)))) &&
         ((0xfffffff5 < (int)pcVar7[0xf] - 0x3aU ||
          (0xfffffff9 < ((int)pcVar7[0xf] & 0xffffffdfU) - 0x47)))) &&
        (((0xfffffff5 < (int)pcVar7[0x10] - 0x3aU ||
          (0xfffffff9 < ((int)pcVar7[0x10] & 0xffffffdfU) - 0x47)) &&
         ((0xfffffff5 < (int)pcVar7[0x11] - 0x3aU ||
          (0xfffffff9 < ((int)pcVar7[0x11] & 0xffffffdfU) - 0x47)))))))) {
      pcVar10 = pcVar7 + 0x12;
      *param_1 = (long)pcVar10;
      if ((pcVar10 != pcVar11) && (*pcVar10 == 'E')) {
        *param_1 = (long)(pcVar7 + 0x13);
        plVar2 = (long *)param_1[0x266];
        lVar8 = plVar2[1];
        plVar5 = plVar2;
        if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
          plVar5 = malloc(0x1000);
          if (plVar5 == (long *)0x0) {
LAB_001278c9:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar5 = (long)plVar2;
          plVar5[1] = 0;
          param_1[0x266] = (long)plVar5;
          lVar8 = 0;
        }
        plVar5[1] = lVar8 + 0x20;
        lVar4 = (long)plVar5 + lVar8 + 0x10;
        *(undefined4 *)((long)plVar5 + lVar8 + 0x18) = 0x1010147;
        ppuVar6 = &PTR_LAB_0013e928;
LAB_001278b5:
        *(undefined ***)((long)plVar5 + lVar8 + 0x10) = ppuVar6;
        *(char **)((long)plVar5 + lVar8 + 0x20) = pcVar7 + 2;
        *(char **)((long)plVar5 + lVar8 + 0x28) = pcVar10;
        goto switchD_00126ff3_caseD_54;
      }
    }
    goto LAB_0012705a;
  case 'e':
    *param_1 = (long)(pcVar7 + 2);
    if (0x14 < (ulong)((long)pcVar11 - (long)(pcVar7 + 2))) {
      pcVar10 = pcVar7 + 0x16;
      lVar8 = 3;
      lVar4 = 0;
      do {
        if ((((int)pcVar7[lVar8 + -1] - 0x3aU < 0xfffffff6) &&
            (((int)pcVar7[lVar8 + -1] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
           (((int)pcVar7[lVar8] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar7[lVar8] & 0xffffffdfU) - 0x47 < 0xfffffffa))))
        goto switchD_00126ff3_caseD_54;
        lVar8 = lVar8 + 2;
      } while (lVar8 != 0x17);
      *param_1 = (long)pcVar10;
      if ((pcVar10 != pcVar11) && (*pcVar10 == 'E')) {
        *param_1 = (long)(pcVar7 + 0x17);
        plVar2 = (long *)param_1[0x266];
        lVar8 = plVar2[1];
        plVar5 = plVar2;
        if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
          plVar5 = malloc(0x1000);
          if (plVar5 == (long *)0x0) goto LAB_001278c9;
          *plVar5 = (long)plVar2;
          plVar5[1] = 0;
          param_1[0x266] = (long)plVar5;
          lVar8 = 0;
        }
        plVar5[1] = lVar8 + 0x20;
        lVar4 = (long)plVar5 + lVar8 + 0x10;
        *(undefined4 *)((long)plVar5 + lVar8 + 0x18) = 0x1010148;
        ppuVar6 = &PTR_LAB_0013e998;
        goto LAB_001278b5;
      }
    }
    goto LAB_0012705a;
  case 'f':
    *param_1 = (long)(pcVar7 + 2);
    if ((((((8 < (ulong)((long)pcVar11 - (long)(pcVar7 + 2))) &&
           ((0xfffffff5 < (int)pcVar7[2] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[2] & 0xffffffdfU) - 0x47)))) &&
          ((0xfffffff5 < (int)pcVar7[3] - 0x3aU ||
           (0xfffffff9 < ((int)pcVar7[3] & 0xffffffdfU) - 0x47)))) &&
         ((((0xfffffff5 < (int)pcVar7[4] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[4] & 0xffffffdfU) - 0x47)) &&
           ((0xfffffff5 < (int)pcVar7[5] - 0x3aU ||
            (0xfffffff9 < ((int)pcVar7[5] & 0xffffffdfU) - 0x47)))) &&
          ((0xfffffff5 < (int)pcVar7[6] - 0x3aU ||
           (0xfffffff9 < ((int)pcVar7[6] & 0xffffffdfU) - 0x47)))))) &&
        ((0xfffffff5 < (int)pcVar7[7] - 0x3aU ||
         (0xfffffff9 < ((int)pcVar7[7] & 0xffffffdfU) - 0x47)))) &&
       (((0xfffffff5 < (int)pcVar7[8] - 0x3aU ||
         (0xfffffff9 < ((int)pcVar7[8] & 0xffffffdfU) - 0x47)) &&
        ((0xfffffff5 < (int)pcVar7[9] - 0x3aU ||
         (0xfffffff9 < ((int)pcVar7[9] & 0xffffffdfU) - 0x47)))))) {
      pcVar10 = pcVar7 + 10;
      *param_1 = (long)pcVar10;
      if ((pcVar10 != pcVar11) && (*pcVar10 == 'E')) {
        *param_1 = (long)(pcVar7 + 0xb);
        plVar2 = (long *)param_1[0x266];
        lVar8 = plVar2[1];
        plVar5 = plVar2;
        if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
          plVar5 = malloc(0x1000);
          if (plVar5 == (long *)0x0) goto LAB_001278c9;
          *plVar5 = (long)plVar2;
          plVar5[1] = 0;
          param_1[0x266] = (long)plVar5;
          lVar8 = 0;
        }
        plVar5[1] = lVar8 + 0x20;
        lVar4 = (long)plVar5 + lVar8 + 0x10;
        *(undefined4 *)((long)plVar5 + lVar8 + 0x18) = 0x1010146;
        ppuVar6 = &PTR_LAB_0013e8b8;
        goto LAB_001278b5;
      }
    }
LAB_0012705a:
    lVar4 = 0;
switchD_00126ff3_caseD_54:
    if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
      return lVar4;
    }
    goto LAB_00127804;
  case 'h':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "unsigned char";
    pcVar7 = "";
    break;
  case 'i':
    *param_1 = (long)(pcVar7 + 2);
    pcVar7 = "";
    pcVar11 = "";
    break;
  case 'j':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "u";
    pcVar7 = "";
    break;
  case 'l':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "l";
    pcVar7 = "";
    break;
  case 'm':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "ul";
    pcVar7 = "";
    break;
  case 'n':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "__int128";
    pcVar7 = "";
    break;
  case 'o':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "unsigned __int128";
    pcVar7 = "";
    break;
  case 's':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "short";
    pcVar7 = "";
    break;
  case 't':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "unsigned short";
    pcVar7 = "";
    break;
  case 'w':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "wchar_t";
    pcVar7 = "";
    break;
  case 'x':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "ll";
    pcVar7 = "";
    break;
  case 'y':
    *param_1 = (long)(pcVar7 + 2);
    pcVar11 = "ull";
    pcVar7 = "";
  }
  lVar4 = FUN_00129ec0(param_1,pcVar11,pcVar7);
LAB_001277f0:
  if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
    return lVar4;
  }
LAB_00127804:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_001278d0 @ 001278d0

long FUN_001278d0(long *param_1)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  long *plVar4;
  long *plVar5;
  long lVar6;
  char *pcVar7;
  char *pcVar8;
  char *pcVar9;
  char *pcVar10;
  
  pcVar9 = (char *)*param_1;
  pcVar3 = (char *)param_1[1];
  if ((ulong)((long)pcVar3 - (long)pcVar9) < 2) {
    return 0;
  }
  if (*pcVar9 != 'f') {
    return 0;
  }
  pcVar10 = pcVar3;
  if (pcVar9[1] == 'p') {
    pcVar7 = pcVar9 + 2;
    *param_1 = (long)pcVar7;
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 == 'r') {
      pcVar7 = pcVar9 + 3;
      *param_1 = (long)pcVar7;
    }
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 == 'V') {
      pcVar7 = pcVar7 + 1;
      *param_1 = (long)pcVar7;
    }
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 == 'K') {
      pcVar7 = pcVar7 + 1;
      *param_1 = (long)pcVar7;
    }
    if (pcVar3 == pcVar7) {
      return 0;
    }
    pcVar9 = pcVar7;
    if ((int)*pcVar7 - 0x3aU < 0xfffffff6) {
      pcVar7 = (char *)0x0;
      pcVar10 = (char *)0x0;
    }
    else {
      do {
        pcVar9 = pcVar9 + 1;
        *param_1 = (long)pcVar9;
        if (pcVar9 == pcVar3) goto LAB_00127a8a;
      } while (0xfffffff5 < (int)*pcVar9 - 0x3aU);
      pcVar10 = pcVar9;
    }
LAB_00127a8a:
    if (pcVar9 == pcVar3) {
      return 0;
    }
    cVar2 = *pcVar9;
  }
  else {
    if (*pcVar9 != 'f') {
      return 0;
    }
    if (pcVar9[1] != 'L') {
      return 0;
    }
    pcVar7 = pcVar9 + 2;
    *param_1 = (long)pcVar7;
    if (pcVar3 == pcVar7) {
      return 0;
    }
    if ((int)*pcVar7 - 0x3aU < 0xfffffff6) {
      return 0;
    }
    pcVar9 = pcVar9 + 5;
    do {
      pcVar8 = pcVar9;
      pcVar1 = pcVar8 + -2;
      *param_1 = (long)pcVar1;
      if (pcVar1 == pcVar3) {
        pcVar9 = pcVar3;
        goto LAB_001279fa;
      }
      pcVar9 = pcVar8 + 1;
    } while (0xfffffff5 < (int)pcVar8[-2] - 0x3aU);
    pcVar9 = pcVar8 + -2;
LAB_001279fa:
    if (pcVar7 == pcVar9) {
      return 0;
    }
    if (pcVar1 == pcVar3) {
      return 0;
    }
    if (pcVar8[-2] != 'p') {
      return 0;
    }
    pcVar7 = pcVar8 + -1;
    *param_1 = (long)pcVar7;
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 == 'r') {
      *param_1 = (long)pcVar8;
      pcVar7 = pcVar8;
    }
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 == 'V') {
      pcVar7 = pcVar7 + 1;
      *param_1 = (long)pcVar7;
    }
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 == 'K') {
      pcVar7 = pcVar7 + 1;
      *param_1 = (long)pcVar7;
    }
    if (pcVar3 == pcVar7) {
      return 0;
    }
    pcVar9 = pcVar7;
    if ((int)*pcVar7 - 0x3aU < 0xfffffff6) {
      pcVar7 = (char *)0x0;
      pcVar10 = (char *)0x0;
    }
    else {
      do {
        pcVar9 = pcVar9 + 1;
        *param_1 = (long)pcVar9;
        if (pcVar9 == pcVar3) goto LAB_00127b44;
      } while (0xfffffff5 < (int)*pcVar9 - 0x3aU);
      pcVar10 = pcVar9;
    }
LAB_00127b44:
    if (pcVar9 == pcVar3) {
      return 0;
    }
    cVar2 = *pcVar9;
  }
  if (cVar2 != '_') {
    return 0;
  }
  *param_1 = (long)(pcVar9 + 1);
  plVar4 = (long *)param_1[0x266];
  lVar6 = plVar4[1];
  plVar5 = plVar4;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar4;
    plVar5[1] = 0;
    param_1[0x266] = (long)plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x101013b;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013ee68;
  *(char **)((long)plVar5 + lVar6 + 0x20) = pcVar7;
  *(char **)((long)plVar5 + lVar6 + 0x28) = pcVar10;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00127b70 @ 00127b70

long FUN_00127b70(long *param_1)

{
  byte *pbVar1;
  byte bVar2;
  byte bVar3;
  byte *pbVar4;
  byte *pbVar5;
  long *plVar6;
  long lVar7;
  long lVar8;
  long *plVar9;
  undefined *puVar10;
  undefined *puVar11;
  char cVar12;
  long lVar13;
  
  pbVar4 = (byte *)*param_1;
  pbVar5 = (byte *)param_1[1];
  if ((pbVar4 != pbVar5) && (*pbVar4 == 0x66)) {
    pbVar1 = pbVar4 + 1;
    *param_1 = (long)pbVar1;
    if (pbVar5 != pbVar1) {
      bVar2 = *pbVar1;
      if ((bVar2 & 0xdf) == 0x4c) {
        cVar12 = '\x01';
      }
      else {
        if ((bVar2 & 0xdf) != 0x52) {
          return 0;
        }
        cVar12 = '\0';
      }
      pbVar1 = pbVar4 + 2;
      *param_1 = (long)pbVar1;
      if (1 < (ulong)((long)pbVar5 - (long)pbVar1)) {
        switch(*pbVar1) {
        case 0x61:
          puVar10 = &DAT_0010ad6a;
          puVar11 = &DAT_0010ad6c;
          switch(pbVar4[3]) {
          case 0x4e:
            puVar10 = &DAT_0010a292;
            puVar11 = &DAT_0010a294;
            break;
          default:
            goto LAB_00127bcb;
          case 0x53:
            puVar10 = &DAT_0010a6ad;
            puVar11 = &DAT_0010a6ae;
            break;
          case 0x61:
            break;
          case 0x6e:
            puVar10 = &DAT_0010ae19;
            puVar11 = &DAT_0010ae1a;
          }
          break;
        default:
          goto LAB_00127bcb;
        case 99:
          if (pbVar4[3] != 0x6d) {
            return 0;
          }
          puVar10 = &DAT_0010a16c;
          puVar11 = &DAT_0010a16d;
          break;
        case 100:
          bVar3 = pbVar4[3];
          if (bVar3 == 0x56) {
            puVar10 = &DAT_00109e3f;
            puVar11 = &DAT_00109e41;
          }
          else if (bVar3 == 0x73) {
            puVar10 = &DAT_0010a560;
            puVar11 = &UNK_0010a562;
          }
          else {
            if (bVar3 != 0x76) {
              return 0;
            }
            puVar10 = &DAT_00109aeb;
            puVar11 = &DAT_00109aec;
          }
          break;
        case 0x65:
          bVar3 = pbVar4[3];
          if (bVar3 == 0x4f) {
            puVar10 = &DAT_0010a501;
            puVar11 = &DAT_0010a503;
          }
          else if (bVar3 == 0x6f) {
            puVar10 = &DAT_0010a7aa;
            puVar11 = &DAT_0010a7ab;
          }
          else {
            if (bVar3 != 0x71) {
              return 0;
            }
            puVar10 = &DAT_0010a504;
            puVar11 = &DAT_0010a506;
          }
          break;
        case 0x67:
          if (pbVar4[3] == 0x65) {
            puVar10 = &DAT_001099e6;
            puVar11 = &DAT_001099e8;
          }
          else {
            if (pbVar4[3] != 0x74) {
              return 0;
            }
            puVar10 = &DAT_0010a507;
            puVar11 = &DAT_0010a508;
          }
          break;
        case 0x6c:
          puVar10 = &DAT_0010abec;
          puVar11 = &DAT_0010abee;
          switch(pbVar4[3]) {
          case 0x53:
            puVar10 = &DAT_0010a876;
            puVar11 = &DAT_0010a879;
            break;
          default:
            goto LAB_00127bcb;
          case 0x65:
            break;
          case 0x73:
            puVar10 = &DAT_0010aa26;
            puVar11 = &DAT_0010aa28;
            break;
          case 0x74:
            puVar10 = &DAT_00109978;
            puVar11 = &DAT_00109979;
          }
          break;
        case 0x6d:
          puVar10 = &DAT_00109e8f;
          puVar11 = &DAT_00109e90;
          switch(pbVar4[3]) {
          case 0x49:
            puVar10 = &DAT_00109e42;
            puVar11 = &DAT_00109e44;
            break;
          default:
            goto LAB_00127bcb;
          case 0x4c:
            puVar10 = &DAT_0010a16e;
            puVar11 = &DAT_0010a170;
            break;
          case 0x69:
            break;
          case 0x6c:
            puVar10 = &DAT_0010a0a2;
            puVar11 = &DAT_0010a0a3;
          }
          break;
        case 0x6e:
          if (pbVar4[3] != 0x65) {
            return 0;
          }
          puVar10 = &DAT_0010ab43;
          puVar11 = &DAT_0010ab45;
          break;
        case 0x6f:
          bVar3 = pbVar4[3];
          if (bVar3 == 0x52) {
            puVar10 = &DAT_0010a7ac;
            puVar11 = &DAT_0010a7ae;
          }
          else if (bVar3 == 0x6f) {
            puVar10 = &DAT_0010a6af;
            puVar11 = &DAT_0010a6b1;
          }
          else {
            if (bVar3 != 0x72) {
              return 0;
            }
            puVar10 = &DAT_0010ad6d;
            puVar11 = &DAT_0010ad6e;
          }
          break;
        case 0x70:
          if (pbVar4[3] == 0x4c) {
            puVar10 = &DAT_0010a5ac;
            puVar11 = &DAT_0010a5ae;
          }
          else {
            if (pbVar4[3] != 0x6c) {
              return 0;
            }
            puVar10 = &DAT_0010a7af;
            puVar11 = &DAT_0010a7b0;
          }
          break;
        case 0x72:
          puVar10 = &DAT_0010b20d;
          puVar11 = &DAT_0010b20e;
          switch(pbVar4[3]) {
          case 0x4d:
            puVar10 = &DAT_0010abef;
            puVar11 = &DAT_0010abf1;
            break;
          default:
            goto LAB_00127bcb;
          case 0x53:
            puVar10 = &DAT_0010a5af;
            puVar11 = &DAT_0010a5b2;
            break;
          case 0x6d:
            break;
          case 0x73:
            puVar10 = &DAT_00109c01;
            puVar11 = &DAT_00109c03;
          }
        }
        *param_1 = (long)(pbVar4 + 4);
        lVar7 = FUN_00125e60(param_1);
        if (lVar7 != 0) {
          if ((bVar2 == 0x52) || (bVar2 == 0x4c)) {
            lVar8 = FUN_00125e60(param_1);
            if (lVar8 == 0) {
              return 0;
            }
            lVar13 = lVar8;
            if (cVar12 != '\0') {
              lVar13 = lVar7;
              lVar7 = lVar8;
            }
          }
          else {
            lVar13 = 0;
          }
          plVar6 = (long *)param_1[0x266];
          lVar8 = plVar6[1];
          plVar9 = plVar6;
          if (lVar8 - 0xfb0U < 0xfffffffffffff010) {
            plVar9 = malloc(0x1000);
            if (plVar9 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
              FUN_00120930();
            }
            *plVar9 = (long)plVar6;
            plVar9[1] = 0;
            param_1[0x266] = (long)plVar9;
            lVar8 = 0;
          }
          plVar9[1] = lVar8 + 0x40;
          *(undefined4 *)((long)plVar9 + lVar8 + 0x18) = 0x101013e;
          *(undefined ***)((long)plVar9 + lVar8 + 0x10) = &PTR_LAB_0013eed8;
          *(long *)((long)plVar9 + lVar8 + 0x20) = lVar7;
          *(long *)((long)plVar9 + lVar8 + 0x28) = lVar13;
          *(undefined **)((long)plVar9 + lVar8 + 0x30) = puVar10;
          *(undefined **)((long)plVar9 + lVar8 + 0x38) = puVar11;
          *(char *)((long)plVar9 + lVar8 + 0x40) = cVar12;
          return (long)plVar9 + lVar8 + 0x10;
        }
      }
    }
  }
LAB_00127bcb:
  return 0;
}


// ==== FUN_00128020 @ 00128020

long FUN_00128020(long param_1,undefined8 param_2,undefined8 param_3)

{
  long *plVar1;
  long lVar2;
  long lVar3;
  long *plVar4;
  long lVar5;
  
  lVar2 = FUN_00125e60();
  if ((lVar2 == 0) || (lVar3 = FUN_00125e60(param_1), lVar3 == 0)) {
    return 0;
  }
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x30;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x101012f;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013efb8;
  *(long *)((long)plVar4 + lVar5 + 0x20) = lVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = param_2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x30) = param_3;
  *(long *)((long)plVar4 + lVar5 + 0x38) = lVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_001280f0 @ 001280f0

long FUN_001280f0(long param_1,undefined8 param_2,undefined8 param_3)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  long lVar4;
  long lVar5;
  
  lVar2 = FUN_00125e60();
  if (lVar2 == 0) {
    lVar4 = 0;
  }
  else {
    plVar1 = *(long **)(param_1 + 0x1330);
    lVar5 = plVar1[1];
    plVar3 = plVar1;
    if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
      plVar3 = malloc(0x1000);
      if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
      *plVar3 = (long)plVar1;
      plVar3[1] = 0;
      *(long **)(param_1 + 0x1330) = plVar3;
      lVar5 = 0;
    }
    plVar3[1] = lVar5 + 0x30;
    lVar4 = (long)plVar3 + lVar5 + 0x10;
    *(undefined4 *)((long)plVar3 + lVar5 + 0x18) = 0x101013a;
    *(undefined ***)((long)plVar3 + lVar5 + 0x10) = &PTR_LAB_0013f028;
    *(undefined8 *)((long)plVar3 + lVar5 + 0x20) = param_2;
    *(undefined8 *)((long)plVar3 + lVar5 + 0x28) = param_3;
    *(long *)((long)plVar3 + lVar5 + 0x30) = lVar2;
  }
  return lVar4;
}


// ==== FUN_001281a0 @ 001281a0

long FUN_001281a0(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x30;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010135;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013f098;
  *(char **)((long)plVar4 + lVar5 + 0x20) = "const_cast";
  *(char **)((long)plVar4 + lVar5 + 0x28) = "";
  *(undefined8 *)((long)plVar4 + lVar5 + 0x30) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x38) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00128250 @ 00128250

long FUN_00128250(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  long *plVar6;
  long lVar7;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar7 = plVar2[1];
  plVar6 = plVar2;
  if (lVar7 - 0xfc0U < 0xfffffffffffff010) {
    plVar6 = malloc(0x1000);
    if (plVar6 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar6 = (long)plVar2;
    plVar6[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar6;
    lVar7 = 0;
  }
  plVar6[1] = lVar7 + 0x30;
  uVar3 = *param_2;
  uVar4 = *param_3;
  uVar5 = param_3[1];
  *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x1010137;
  *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013f108;
  *(undefined8 *)((long)plVar6 + lVar7 + 0x20) = uVar3;
  puVar1 = (undefined8 *)((long)plVar6 + lVar7 + 0x28);
  *puVar1 = uVar4;
  puVar1[1] = uVar5;
  return (long)plVar6 + lVar7 + 0x10;
}


// ==== FUN_001282f0 @ 001282f0

long FUN_001282f0(undefined8 *param_1)

{
  undefined1 uVar1;
  long *plVar2;
  long lVar3;
  char *pcVar4;
  long *plVar5;
  long *plVar6;
  long lVar7;
  long lVar8;
  long lVar9;
  long in_FS_OFFSET;
  undefined1 auVar10 [16];
  long local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar4 = (char *)*param_1;
  if (((1 < (ulong)(param_1[1] - (long)pcVar4)) && (*pcVar4 == 'c')) && (pcVar4[1] == 'v')) {
    *param_1 = pcVar4 + 2;
    uVar1 = *(undefined1 *)(param_1 + 0x61);
    *(undefined1 *)(param_1 + 0x61) = 0;
                    /* try { // try from 0012834b to 0012834f has its CatchHandler @ 0012859e */
    lVar3 = FUN_00121da0();
    *(undefined1 *)(param_1 + 0x61) = uVar1;
    if (lVar3 != 0) {
      pcVar4 = (char *)*param_1;
      if ((pcVar4 != (char *)param_1[1]) && (*pcVar4 == '_')) {
        pcVar4 = pcVar4 + 1;
        *param_1 = pcVar4;
        lVar9 = param_1[3];
        lVar7 = param_1[2];
        if (pcVar4 == (char *)param_1[1]) goto LAB_001283a9;
        while (*pcVar4 != 'E') {
LAB_001283a9:
          do {
            local_40 = FUN_00125e60(param_1);
            if (local_40 == 0) goto LAB_001284ca;
            FUN_00123d20(param_1 + 2,&local_40);
            pcVar4 = (char *)*param_1;
          } while (pcVar4 == (char *)param_1[1]);
        }
        *param_1 = pcVar4 + 1;
        lVar9 = (lVar9 - lVar7 >> 3) * 8;
        auVar10 = FUN_0012da70(param_1,param_1[2] + lVar9,param_1[3]);
        param_1[3] = lVar9 + param_1[2];
        plVar2 = (long *)param_1[0x266];
        lVar9 = plVar2[1];
        plVar6 = plVar2;
        if (lVar9 - 0xfc0U < 0xfffffffffffff010) {
          plVar6 = malloc(0x1000);
          if (plVar6 == (long *)0x0) {
LAB_00128594:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar6 = (long)plVar2;
          plVar6[1] = 0;
          param_1[0x266] = plVar6;
          lVar9 = 0;
        }
        plVar6[1] = lVar9 + 0x30;
        lVar7 = (long)plVar6 + lVar9 + 0x10;
        *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x101013c;
        *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013f178;
        *(long *)((long)plVar6 + lVar9 + 0x20) = lVar3;
        *(long *)((long)plVar6 + lVar9 + 0x28) = auVar10._0_8_;
        *(long *)((long)plVar6 + lVar9 + 0x30) = auVar10._8_8_;
        goto LAB_001284cc;
      }
      local_40 = FUN_00125e60(param_1);
      if (local_40 != 0) {
        plVar2 = (long *)param_1[0x266];
        lVar9 = plVar2[1];
        plVar6 = plVar2;
        if (lVar9 - 0xfe0U < 0xfffffffffffff010) {
          plVar6 = malloc(0x1000);
          if (plVar6 == (long *)0x0) goto LAB_00128594;
          *plVar6 = (long)plVar2;
          plVar6[1] = 0;
          param_1[0x266] = plVar6;
          lVar9 = 0;
        }
        plVar6[1] = lVar9 + 0x10;
        *(long *)((long)plVar6 + lVar9 + 0x10) = local_40;
        plVar2 = (long *)param_1[0x266];
        lVar8 = plVar2[1];
        plVar5 = plVar2;
        if (lVar8 - 0xfc0U < 0xfffffffffffff010) {
          plVar5 = malloc(0x1000);
          if (plVar5 == (long *)0x0) goto LAB_00128594;
          *plVar5 = (long)plVar2;
          plVar5[1] = 0;
          param_1[0x266] = plVar5;
          lVar8 = 0;
        }
        plVar5[1] = lVar8 + 0x30;
        lVar7 = (long)plVar5 + lVar8 + 0x10;
        *(undefined4 *)((long)plVar5 + lVar8 + 0x18) = 0x101013c;
        *(undefined ***)((long)plVar5 + lVar8 + 0x10) = &PTR_LAB_0013f178;
        *(long *)((long)plVar5 + lVar8 + 0x20) = lVar3;
        *(long *)((long)plVar5 + lVar8 + 0x28) = (long)plVar6 + lVar9 + 0x10;
        *(undefined8 *)((long)plVar5 + lVar8 + 0x30) = 1;
        goto LAB_001284cc;
      }
    }
  }
LAB_001284ca:
  lVar7 = 0;
LAB_001284cc:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar7;
}


// ==== FUN_001285b0 @ 001285b0

long FUN_001285b0(long param_1,undefined8 *param_2,undefined1 *param_3,undefined1 *param_4)

{
  undefined1 uVar1;
  undefined1 uVar2;
  long *plVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  
  plVar3 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar3[1];
  plVar5 = plVar3;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar3;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  uVar4 = *param_2;
  uVar1 = *param_3;
  uVar2 = *param_4;
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x1010139;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013f1e8;
  *(undefined8 *)((long)plVar5 + lVar6 + 0x20) = uVar4;
  *(undefined1 *)((long)plVar5 + lVar6 + 0x28) = uVar1;
  *(undefined1 *)((long)plVar5 + lVar6 + 0x29) = uVar2;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00128660 @ 00128660

long FUN_00128660(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x30;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010135;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013f098;
  *(char **)((long)plVar4 + lVar5 + 0x20) = "dynamic_cast";
  *(char **)((long)plVar4 + lVar5 + 0x28) = "";
  *(undefined8 *)((long)plVar4 + lVar5 + 0x30) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x38) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00128710 @ 00128710

long FUN_00128710(undefined8 *param_1)

{
  long lVar1;
  char *pcVar2;
  long *plVar3;
  bool bVar4;
  char *pcVar5;
  long *plVar6;
  long lVar7;
  long lVar8;
  long lVar9;
  char cVar10;
  long unaff_R14;
  long in_FS_OFFSET;
  bool bVar11;
  long local_48;
  long local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar5 = (char *)*param_1;
  pcVar2 = (char *)param_1[1];
  if ((ulong)((long)pcVar2 - (long)pcVar5) < 3) {
    if ((long)pcVar2 - (long)pcVar5 != 2) {
LAB_0012887a:
      lVar7 = FUN_0012df30(param_1);
      if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
        return lVar7;
      }
      goto LAB_00128d1a;
    }
    cVar10 = *pcVar5;
LAB_0012883f:
    bVar11 = cVar10 == 'g';
    if (bVar11) {
      if (pcVar5[1] != 's') goto LAB_0012887a;
      pcVar5 = pcVar5 + 2;
      *param_1 = pcVar5;
      bVar4 = true;
      if (1 < (ulong)((long)pcVar2 - (long)pcVar5)) {
        cVar10 = *pcVar5;
        goto LAB_0012886a;
      }
    }
    else {
LAB_0012886a:
      bVar4 = bVar11;
      if (cVar10 == 's') goto LAB_0012893f;
    }
LAB_001289d8:
    unaff_R14 = FUN_0012df30(param_1);
    if ((bVar4) && (unaff_R14 != 0)) {
      plVar3 = (long *)param_1[0x266];
      lVar7 = plVar3[1];
      plVar6 = plVar3;
      if (lVar7 - 0xfd0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_00128d15;
        *plVar6 = (long)plVar3;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar7 = 0;
      }
      plVar6[1] = lVar7 + 0x20;
      *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x1010126;
      *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013f418;
      *(long *)((long)plVar6 + lVar7 + 0x20) = unaff_R14;
      unaff_R14 = (long)plVar6 + lVar7 + 0x10;
    }
  }
  else {
    cVar10 = *pcVar5;
    if (cVar10 != 's') goto LAB_0012883f;
    if (pcVar5[1] == 'r') {
      if (pcVar5[2] != 'N') {
        bVar11 = false;
        cVar10 = pcVar5[1];
        goto joined_r0x001289d0;
      }
      *param_1 = pcVar5 + 3;
      lVar7 = FUN_0012ddc0(param_1);
      if (lVar7 == 0) goto LAB_00128c6b;
      if (((char *)param_1[1] == (char *)*param_1) || (*(char *)*param_1 != 'I')) {
LAB_001288e2:
        while( true ) {
          pcVar5 = (char *)*param_1;
          if ((pcVar5 != (char *)param_1[1]) && (*pcVar5 == 'E')) {
            *param_1 = pcVar5 + 1;
            local_40 = unaff_R14;
            lVar8 = FUN_0012df30(param_1);
            if (lVar8 == 0) goto LAB_00128c6b;
            plVar3 = (long *)param_1[0x266];
            lVar9 = plVar3[1];
            plVar6 = plVar3;
            if (lVar9 - 0xfd0U < 0xfffffffffffff010) {
              plVar6 = malloc(0x1000);
              if (plVar6 == (long *)0x0) goto LAB_00128d15;
              *plVar6 = (long)plVar3;
              plVar6[1] = 0;
              param_1[0x266] = plVar6;
              lVar9 = 0;
            }
            plVar6[1] = lVar9 + 0x20;
            lVar1 = lVar9 + (long)plVar6;
            *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x1010116;
            *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013f258;
            goto LAB_00128c5a;
          }
          lVar8 = FUN_0012de60(param_1);
          if (lVar8 == 0) break;
          plVar3 = (long *)param_1[0x266];
          lVar9 = plVar3[1];
          plVar6 = plVar3;
          if (lVar9 - 0xfd0U < 0xfffffffffffff010) {
            plVar6 = malloc(0x1000);
            if (plVar6 == (long *)0x0) goto LAB_00128d15;
            *plVar6 = (long)plVar3;
            plVar6[1] = 0;
            param_1[0x266] = plVar6;
            lVar9 = 0;
          }
          plVar6[1] = lVar9 + 0x20;
          unaff_R14 = (long)plVar6 + lVar9 + 0x10;
          *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x1010116;
          *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013f258;
          *(long *)((long)plVar6 + lVar9 + 0x20) = lVar7;
          *(long *)((long)plVar6 + lVar9 + 0x28) = lVar8;
          lVar7 = unaff_R14;
        }
        local_40 = unaff_R14;
        goto LAB_00128c6b;
      }
      unaff_R14 = 0;
      lVar8 = FUN_00124c50(param_1,0);
      if (lVar8 != 0) {
        plVar3 = (long *)param_1[0x266];
        lVar9 = plVar3[1];
        plVar6 = plVar3;
        if (lVar9 - 0xfd0U < 0xfffffffffffff010) {
          plVar6 = malloc(0x1000);
          if (plVar6 == (long *)0x0) goto LAB_00128d15;
          *plVar6 = (long)plVar3;
          plVar6[1] = 0;
          param_1[0x266] = plVar6;
          lVar9 = 0;
        }
        plVar6[1] = lVar9 + 0x20;
        *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x1010125;
        *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013fdb8;
        *(long *)((long)plVar6 + lVar9 + 0x20) = lVar7;
        lVar7 = (long)plVar6 + lVar9 + 0x10;
        *(long *)((long)plVar6 + lVar9 + 0x28) = lVar8;
        goto LAB_001288e2;
      }
    }
    else {
      bVar11 = false;
LAB_0012893f:
      cVar10 = pcVar5[1];
joined_r0x001289d0:
      if (cVar10 != 'r') {
        bVar4 = bVar11;
        goto LAB_001289d8;
      }
      pcVar5 = pcVar5 + 2;
      *param_1 = pcVar5;
      if ((pcVar2 == pcVar5) || ((int)*pcVar5 - 0x3aU < 0xfffffff6)) {
        local_40 = FUN_0012ddc0(param_1);
        if (local_40 != 0) {
          if (((char *)param_1[1] != (char *)*param_1) && (*(char *)*param_1 == 'I')) {
            local_48 = FUN_00124c50(param_1,0);
            if (local_48 == 0) goto LAB_00128c6b;
            local_40 = FUN_00125180(param_1,&local_40,&local_48);
          }
LAB_00128be0:
          lVar7 = local_40;
          lVar8 = FUN_0012df30(param_1);
          if (lVar8 != 0) {
            plVar3 = (long *)param_1[0x266];
            lVar9 = plVar3[1];
            plVar6 = plVar3;
            if (lVar9 - 0xfd0U < 0xfffffffffffff010) {
              plVar6 = malloc(0x1000);
              if (plVar6 == (long *)0x0) {
LAB_00128d15:
                    /* WARNING: Subroutine does not return */
                FUN_00120930();
              }
              *plVar6 = (long)plVar3;
              plVar6[1] = 0;
              param_1[0x266] = plVar6;
              lVar9 = 0;
            }
            plVar6[1] = lVar9 + 0x20;
            lVar1 = lVar9 + (long)plVar6;
            *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x1010116;
            *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013f258;
LAB_00128c5a:
            unaff_R14 = lVar1 + 0x10;
            *(long *)((long)plVar6 + lVar9 + 0x20) = lVar7;
            *(long *)((long)plVar6 + lVar9 + 0x28) = lVar8;
            goto LAB_00128c6e;
          }
        }
      }
      else {
        lVar7 = FUN_0012de60(param_1);
        if (lVar7 != 0) {
          unaff_R14 = 0;
          lVar8 = 0;
          do {
            if (lVar8 == 0) {
              if (bVar11) {
                plVar3 = (long *)param_1[0x266];
                lVar8 = plVar3[1];
                plVar6 = plVar3;
                if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
                  plVar6 = malloc(0x1000);
                  if (plVar6 == (long *)0x0) goto LAB_00128d15;
                  *plVar6 = (long)plVar3;
                  plVar6[1] = 0;
                  param_1[0x266] = plVar6;
                  lVar8 = 0;
                }
                plVar6[1] = lVar8 + 0x20;
                *(undefined4 *)((long)plVar6 + lVar8 + 0x18) = 0x1010126;
                *(undefined ***)((long)plVar6 + lVar8 + 0x10) = &PTR_LAB_0013f418;
                *(long *)((long)plVar6 + lVar8 + 0x20) = lVar7;
                local_40 = (long)plVar6 + lVar8 + 0x10;
              }
              else {
                local_40 = lVar7;
              }
            }
            else {
              plVar3 = (long *)param_1[0x266];
              lVar9 = plVar3[1];
              plVar6 = plVar3;
              if (lVar9 - 0xfd0U < 0xfffffffffffff010) {
                plVar6 = malloc(0x1000);
                if (plVar6 == (long *)0x0) goto LAB_00128d15;
                *plVar6 = (long)plVar3;
                plVar6[1] = 0;
                param_1[0x266] = plVar6;
                lVar9 = 0;
              }
              plVar6[1] = lVar9 + 0x20;
              *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x1010116;
              *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013f258;
              *(long *)((long)plVar6 + lVar9 + 0x20) = lVar8;
              *(long *)((long)plVar6 + lVar9 + 0x28) = lVar7;
              local_40 = (long)plVar6 + lVar9 + 0x10;
            }
            lVar8 = local_40;
            pcVar5 = (char *)*param_1;
            if ((pcVar5 != (char *)param_1[1]) && (*pcVar5 == 'E')) {
              *param_1 = pcVar5 + 1;
              goto LAB_00128be0;
            }
            lVar7 = FUN_0012de60(param_1);
          } while (lVar7 != 0);
          goto LAB_00128c6e;
        }
      }
LAB_00128c6b:
      unaff_R14 = 0;
    }
  }
LAB_00128c6e:
  if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
    return unaff_R14;
  }
LAB_00128d1a:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00128d20 @ 00128d20

long FUN_00128d20(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  size_t sVar5;
  long lVar6;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar1[1];
  plVar4 = plVar1;
  if (lVar6 - 0xfc0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar6 = 0;
  }
  plVar4[1] = lVar6 + 0x30;
  uVar2 = *param_2;
  sVar5 = strlen(param_3);
  uVar3 = *param_4;
  *(undefined4 *)((long)plVar4 + lVar6 + 0x18) = 0x1010133;
  *(undefined ***)((long)plVar4 + lVar6 + 0x10) = &PTR_LAB_0013f488;
  *(undefined8 *)((long)plVar4 + lVar6 + 0x20) = uVar2;
  *(char **)((long)plVar4 + lVar6 + 0x28) = param_3;
  *(char **)((long)plVar4 + lVar6 + 0x30) = param_3 + sVar5;
  *(undefined8 *)((long)plVar4 + lVar6 + 0x38) = uVar3;
  return (long)plVar4 + lVar6 + 0x10;
}


// ==== FUN_00128de0 @ 00128de0

long FUN_00128de0(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x30;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010133;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013f488;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = uVar2;
  *(undefined **)((long)plVar4 + lVar5 + 0x28) = &DAT_00109aac;
  *(undefined **)((long)plVar4 + lVar5 + 0x30) = &DAT_00109aad;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x38) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00128e90 @ 00128e90

long FUN_00128e90(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x20;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010130;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013f4f8;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00128f30 @ 00128f30

long FUN_00128f30(undefined8 *param_1)

{
  char cVar1;
  char *pcVar2;
  long *plVar3;
  long lVar4;
  long lVar5;
  long *plVar6;
  long lVar7;
  long lVar8;
  
  pcVar2 = (char *)*param_1;
  if ((((char *)param_1[1] == pcVar2) || (*pcVar2 != 'd')) || ((long)param_1[1] - (long)pcVar2 == 1)
     ) {
LAB_0012902d:
    lVar4 = FUN_00125e60(param_1);
    return lVar4;
  }
  cVar1 = pcVar2[1];
  if (cVar1 == 'X') {
    *param_1 = pcVar2 + 2;
    lVar4 = FUN_00125e60(param_1);
    if (((lVar4 != 0) && (lVar5 = FUN_00125e60(param_1), lVar5 != 0)) &&
       (lVar7 = FUN_00128f30(param_1), lVar7 != 0)) {
      plVar3 = (long *)param_1[0x266];
      lVar8 = plVar3[1];
      plVar6 = plVar3;
      if (lVar8 - 0xfc0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) {
LAB_001291ae:
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        *plVar6 = (long)plVar3;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar8 = 0;
      }
      plVar6[1] = lVar8 + 0x30;
      *(undefined4 *)((long)plVar6 + lVar8 + 0x18) = 0x101014a;
      *(undefined ***)((long)plVar6 + lVar8 + 0x10) = &PTR_LAB_0013f5d8;
      *(long *)((long)plVar6 + lVar8 + 0x20) = lVar4;
      *(long *)((long)plVar6 + lVar8 + 0x28) = lVar5;
      *(long *)((long)plVar6 + lVar8 + 0x30) = lVar7;
      return (long)plVar6 + lVar8 + 0x10;
    }
  }
  else if (cVar1 == 'x') {
    *param_1 = pcVar2 + 2;
    lVar4 = FUN_00125e60(param_1);
    if ((lVar4 != 0) && (lVar5 = FUN_00128f30(param_1), lVar5 != 0)) {
      plVar3 = (long *)param_1[0x266];
      lVar7 = plVar3[1];
      plVar6 = plVar3;
      if (lVar7 - 0xfc0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_001291ae;
        *plVar6 = (long)plVar3;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar7 = 0;
      }
      plVar6[1] = lVar7 + 0x30;
      *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x1010149;
      *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013f568;
      *(long *)((long)plVar6 + lVar7 + 0x20) = lVar4;
      *(long *)((long)plVar6 + lVar7 + 0x28) = lVar5;
      *(undefined1 *)((long)plVar6 + lVar7 + 0x30) = 1;
      return (long)plVar6 + lVar7 + 0x10;
    }
  }
  else {
    if (cVar1 != 'i') goto LAB_0012902d;
    *param_1 = pcVar2 + 2;
    lVar4 = FUN_0012e110(param_1);
    if ((lVar4 != 0) && (lVar5 = FUN_00128f30(param_1), lVar5 != 0)) {
      plVar3 = (long *)param_1[0x266];
      lVar7 = plVar3[1];
      plVar6 = plVar3;
      if (lVar7 - 0xfc0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_001291ae;
        *plVar6 = (long)plVar3;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar7 = 0;
      }
      plVar6[1] = lVar7 + 0x30;
      *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x1010149;
      *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013f568;
      *(long *)((long)plVar6 + lVar7 + 0x20) = lVar4;
      *(long *)((long)plVar6 + lVar7 + 0x28) = lVar5;
      *(undefined1 *)((long)plVar6 + lVar7 + 0x30) = 0;
      return (long)plVar6 + lVar7 + 0x10;
    }
  }
  return 0;
}


// ==== FUN_001291c0 @ 001291c0

long FUN_001291c0(long param_1,undefined8 param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar2[1];
  plVar5 = plVar2;
  if (lVar6 - 0xfc0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar2;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x30;
  uVar3 = *param_3;
  uVar4 = param_3[1];
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x101013d;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013f648;
  *(undefined8 *)((long)plVar5 + lVar6 + 0x20) = 0;
  puVar1 = (undefined8 *)((long)plVar5 + lVar6 + 0x28);
  *puVar1 = uVar3;
  puVar1[1] = uVar4;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00129250 @ 00129250

long FUN_00129250(long param_1,undefined8 *param_2,char *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  size_t sVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar3 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar5 = 0;
  }
  plVar3[1] = lVar5 + 0x30;
  uVar2 = *param_2;
  sVar4 = strlen(param_3);
  *(undefined4 *)((long)plVar3 + lVar5 + 0x18) = 0x1010131;
  *(undefined ***)((long)plVar3 + lVar5 + 0x10) = &PTR_LAB_0013f6b8;
  *(undefined8 *)((long)plVar3 + lVar5 + 0x20) = uVar2;
  *(char **)((long)plVar3 + lVar5 + 0x28) = param_3;
  *(char **)((long)plVar3 + lVar5 + 0x30) = param_3 + sVar4;
  return (long)plVar3 + lVar5 + 0x10;
}


// ==== FUN_00129300 @ 00129300

long FUN_00129300(undefined8 *param_1)

{
  undefined8 *puVar1;
  char cVar2;
  char *pcVar3;
  long *plVar4;
  char *pcVar5;
  long *plVar6;
  long lVar7;
  char cVar8;
  long lVar9;
  long lVar10;
  undefined1 uVar11;
  long in_FS_OFFSET;
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  long local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar5 = (char *)*param_1;
  pcVar3 = (char *)param_1[1];
  if (1 < (ulong)((long)pcVar3 - (long)pcVar5)) {
    cVar8 = *pcVar5;
    if (cVar8 == 'g') {
      if (pcVar5[1] == 's') {
        pcVar5 = pcVar5 + 2;
        *param_1 = pcVar5;
        if (1 < (ulong)((long)pcVar3 - (long)pcVar5)) {
          cVar8 = *pcVar5;
          uVar11 = 1;
          goto LAB_00129368;
        }
      }
    }
    else {
      uVar11 = 0;
LAB_00129368:
      cVar2 = pcVar5[1];
      if ((cVar8 == 'n') && ((cVar2 == 'w' || (cVar2 == 'a')))) {
        pcVar5 = pcVar5 + 2;
        *param_1 = pcVar5;
        lVar10 = param_1[3];
        lVar9 = param_1[2];
        if (pcVar5 == pcVar3) goto LAB_001293b5;
        while (*pcVar5 != '_') {
LAB_001293b5:
          do {
            local_40 = FUN_00125e60(param_1);
            if (local_40 == 0) goto LAB_0012954e;
            FUN_00123d20(param_1 + 2,&local_40);
            pcVar5 = (char *)*param_1;
          } while (pcVar5 == (char *)param_1[1]);
        }
        *param_1 = pcVar5 + 1;
        lVar10 = (lVar10 - lVar9 >> 3) * 8;
        auVar12 = FUN_0012da70(param_1,param_1[2] + lVar10,param_1[3]);
        param_1[3] = lVar10 + param_1[2];
        lVar10 = FUN_00121da0(param_1);
        if (lVar10 != 0) {
          pcVar5 = (char *)*param_1;
          pcVar3 = (char *)param_1[1];
          if (((1 < (ulong)((long)pcVar3 - (long)pcVar5)) && (*pcVar5 == 'p')) && (pcVar5[1] == 'i')
             ) {
            pcVar5 = pcVar5 + 2;
            *param_1 = pcVar5;
            lVar9 = param_1[3];
            lVar7 = param_1[2];
            if (pcVar5 == pcVar3) goto LAB_00129473;
            while (*pcVar5 != 'E') {
LAB_00129473:
              do {
                local_40 = FUN_00125e60(param_1);
                if (local_40 == 0) goto LAB_0012954e;
                FUN_00123d20(param_1 + 2,&local_40);
                pcVar5 = (char *)*param_1;
              } while (pcVar5 == (char *)param_1[1]);
            }
            *param_1 = pcVar5 + 1;
            lVar9 = (lVar9 - lVar7 >> 3) * 8;
            auVar13 = FUN_0012da70(param_1,param_1[2] + lVar9,param_1[3]);
            param_1[3] = lVar9 + param_1[2];
            plVar4 = (long *)param_1[0x266];
            lVar9 = plVar4[1];
            plVar6 = plVar4;
            if (lVar9 - 0xfb0U < 0xfffffffffffff010) {
              plVar6 = malloc(0x1000);
              if (plVar6 == (long *)0x0) {
LAB_00129648:
                    /* WARNING: Subroutine does not return */
                FUN_00120930();
              }
              *plVar6 = (long)plVar4;
              plVar6[1] = 0;
              param_1[0x266] = plVar6;
              lVar9 = 0;
            }
            plVar6[1] = lVar9 + 0x40;
            lVar7 = (long)plVar6 + lVar9 + 0x10;
            *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x1010138;
            *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013f728;
            *(long *)((long)plVar6 + lVar9 + 0x20) = auVar12._0_8_;
            *(long *)((long)plVar6 + lVar9 + 0x28) = auVar12._8_8_;
            *(long *)((long)plVar6 + lVar9 + 0x30) = lVar10;
            *(long *)((long)plVar6 + lVar9 + 0x38) = auVar13._0_8_;
            *(long *)((long)plVar6 + lVar9 + 0x40) = auVar13._8_8_;
            *(undefined1 *)((long)plVar6 + lVar9 + 0x48) = uVar11;
            *(bool *)((long)plVar6 + lVar9 + 0x49) = cVar2 == 'a';
            goto LAB_00129550;
          }
          if ((pcVar5 != pcVar3) && (*pcVar5 == 'E')) {
            *param_1 = pcVar5 + 1;
            plVar4 = (long *)param_1[0x266];
            lVar9 = plVar4[1];
            plVar6 = plVar4;
            if (lVar9 - 0xfb0U < 0xfffffffffffff010) {
              plVar6 = malloc(0x1000);
              if (plVar6 == (long *)0x0) goto LAB_00129648;
              *plVar6 = (long)plVar4;
              plVar6[1] = 0;
              param_1[0x266] = plVar6;
              lVar9 = 0;
            }
            plVar6[1] = lVar9 + 0x40;
            lVar7 = (long)plVar6 + lVar9 + 0x10;
            *(undefined4 *)((long)plVar6 + lVar9 + 0x18) = 0x1010138;
            *(undefined ***)((long)plVar6 + lVar9 + 0x10) = &PTR_LAB_0013f728;
            *(long *)((long)plVar6 + lVar9 + 0x20) = auVar12._0_8_;
            *(long *)((long)plVar6 + lVar9 + 0x28) = auVar12._8_8_;
            *(long *)((long)plVar6 + lVar9 + 0x30) = lVar10;
            puVar1 = (undefined8 *)((long)plVar6 + lVar9 + 0x38);
            *puVar1 = 0;
            puVar1[1] = 0;
            *(undefined1 *)((long)plVar6 + lVar9 + 0x48) = uVar11;
            *(bool *)((long)plVar6 + lVar9 + 0x49) = cVar2 == 'a';
            goto LAB_00129550;
          }
        }
      }
    }
  }
LAB_0012954e:
  lVar7 = 0;
LAB_00129550:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar7;
}


// ==== FUN_00129660 @ 00129660

long FUN_00129660(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfb0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x40;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010134;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013f798;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "noexcept (";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  *(undefined **)((long)plVar3 + lVar4 + 0x38) = &DAT_0010af8a;
  *(undefined **)((long)plVar3 + lVar4 + 0x40) = &DAT_0010af8b;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00129720 @ 00129720

long FUN_00129720(long param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar1[1];
  plVar5 = plVar1;
  if (lVar6 - 0xfc0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar1;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x30;
  uVar2 = *param_2;
  uVar3 = *param_3;
  uVar4 = *param_4;
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x1010132;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013f808;
  *(undefined8 *)((long)plVar5 + lVar6 + 0x20) = uVar2;
  *(undefined8 *)((long)plVar5 + lVar6 + 0x28) = uVar3;
  *(undefined8 *)((long)plVar5 + lVar6 + 0x30) = uVar4;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_001297d0 @ 001297d0

long FUN_001297d0(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x30;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010135;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013f098;
  *(char **)((long)plVar4 + lVar5 + 0x20) = "reinterpret_cast";
  *(char **)((long)plVar4 + lVar5 + 0x28) = "";
  *(undefined8 *)((long)plVar4 + lVar5 + 0x30) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x38) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00129880 @ 00129880

long FUN_00129880(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x30;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010135;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013f098;
  *(char **)((long)plVar4 + lVar5 + 0x20) = "static_cast";
  *(char **)((long)plVar4 + lVar5 + 0x28) = "";
  *(undefined8 *)((long)plVar4 + lVar5 + 0x30) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x38) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_00129930 @ 00129930

long FUN_00129930(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010122;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013ef48;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_001299c0 @ 001299c0

long FUN_001299c0(long param_1,char *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  size_t sVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar3 = plVar1;
  if (lVar5 - 0xfb0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar5 = 0;
  }
  plVar3[1] = lVar5 + 0x40;
  sVar4 = strlen(param_2);
  uVar2 = *param_3;
  *(undefined4 *)((long)plVar3 + lVar5 + 0x18) = 0x1010134;
  *(undefined ***)((long)plVar3 + lVar5 + 0x10) = &PTR_LAB_0013f798;
  *(char **)((long)plVar3 + lVar5 + 0x20) = param_2;
  *(char **)((long)plVar3 + lVar5 + 0x28) = param_2 + sVar4;
  *(undefined8 *)((long)plVar3 + lVar5 + 0x30) = uVar2;
  *(undefined **)((long)plVar3 + lVar5 + 0x38) = &DAT_0010af8a;
  *(undefined **)((long)plVar3 + lVar5 + 0x40) = &DAT_0010af8b;
  return (long)plVar3 + lVar5 + 0x10;
}


// ==== FUN_00129a80 @ 00129a80

long FUN_00129a80(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010136;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013f878;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00129b10 @ 00129b10

long FUN_00129b10(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfb0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x40;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010134;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013f798;
  *(char **)((long)plVar3 + lVar4 + 0x20) = "sizeof... (";
  *(char **)((long)plVar3 + lVar4 + 0x28) = "";
  *(undefined8 *)((long)plVar3 + lVar4 + 0x30) = uVar2;
  *(undefined **)((long)plVar3 + lVar4 + 0x38) = &DAT_0010af8a;
  *(undefined **)((long)plVar3 + lVar4 + 0x40) = &DAT_0010af8b;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00129bd0 @ 00129bd0

long FUN_00129bd0(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar2[1];
  plVar5 = plVar2;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar2;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  uVar3 = *param_2;
  uVar4 = param_2[1];
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x1010100;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013f8e8;
  puVar1 = (undefined8 *)((long)plVar5 + lVar6 + 0x20);
  *puVar1 = uVar3;
  puVar1[1] = uVar4;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00129c60 @ 00129c60

long FUN_00129c60(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  long *plVar6;
  long lVar7;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar7 = plVar2[1];
  plVar6 = plVar2;
  if (lVar7 - 0xfc0U < 0xfffffffffffff010) {
    plVar6 = malloc(0x1000);
    if (plVar6 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar6 = (long)plVar2;
    plVar6[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar6;
    lVar7 = 0;
  }
  plVar6[1] = lVar7 + 0x30;
  uVar3 = *param_2;
  uVar4 = *param_3;
  uVar5 = param_3[1];
  *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x101013d;
  *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013f648;
  *(undefined8 *)((long)plVar6 + lVar7 + 0x20) = uVar3;
  puVar1 = (undefined8 *)((long)plVar6 + lVar7 + 0x28);
  *puVar1 = uVar4;
  puVar1[1] = uVar5;
  return (long)plVar6 + lVar7 + 0x10;
}


// ==== FUN_00129d00 @ 00129d00

long FUN_00129d00(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_00129da0 @ 00129da0

long FUN_00129da0(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x101013f;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013f958;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00129e30 @ 00129e30

long FUN_00129e30(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010140;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013f9c8;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00129ec0 @ 00129ec0

long FUN_00129ec0(long *param_1,undefined8 param_2,undefined8 param_3)

{
  char *pcVar1;
  char *pcVar2;
  long *plVar3;
  long *plVar4;
  long lVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  
  pcVar1 = (char *)*param_1;
  pcVar2 = (char *)param_1[1];
  pcVar6 = pcVar1;
  if ((pcVar1 != pcVar2) && (*pcVar1 == 'n')) {
    pcVar6 = pcVar1 + 1;
    *param_1 = (long)pcVar6;
  }
  if ((pcVar2 != pcVar6) && (0xfffffff5 < (int)*pcVar6 - 0x3aU)) {
    do {
      pcVar7 = pcVar6;
      pcVar6 = pcVar7 + 1;
      *param_1 = (long)pcVar6;
      if (pcVar6 == pcVar2) {
        pcVar8 = pcVar2;
        goto LAB_00129f44;
      }
    } while (0xfffffff5 < (int)*pcVar6 - 0x3aU);
    pcVar8 = pcVar6;
LAB_00129f44:
    if (pcVar1 == pcVar8) {
      return 0;
    }
    if (pcVar6 == pcVar2) {
      return 0;
    }
    if (*pcVar6 == 'E') {
      *param_1 = (long)(pcVar7 + 2);
      plVar3 = (long *)param_1[0x266];
      lVar5 = plVar3[1];
      plVar4 = plVar3;
      if (lVar5 - 0xfc0U < 0xfffffffffffff010) {
        plVar4 = malloc(0x1000);
        if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        *plVar4 = (long)plVar3;
        plVar4[1] = 0;
        param_1[0x266] = (long)plVar4;
        lVar5 = 0;
      }
      plVar4[1] = lVar5 + 0x30;
      *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010145;
      *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013e7d8;
      *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = param_2;
      *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = param_3;
      *(char **)((long)plVar4 + lVar5 + 0x30) = pcVar1;
      *(char **)((long)plVar4 + lVar5 + 0x38) = pcVar8;
      return (long)plVar4 + lVar5 + 0x10;
    }
  }
  return 0;
}


// ==== FUN_00129fe0 @ 00129fe0

long FUN_00129fe0(long param_1,int *param_2)

{
  int iVar1;
  long *plVar2;
  long *plVar3;
  long lVar4;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar2[1];
  plVar3 = plVar2;
  if (lVar4 - 0xfe0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar2;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x10;
  iVar1 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010141;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013e848;
  *(bool *)((long)plVar3 + lVar4 + 0x1c) = iVar1 != 0;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_0012a070 @ 0012a070

long FUN_0012a070(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010142;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013ea08;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_0012a100 @ 0012a100

long FUN_0012a100(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_0012a1a0 @ 0012a1a0

long FUN_0012a1a0(long *param_1,long param_2)

{
  char *pcVar1;
  long *plVar2;
  size_t __n;
  undefined *puVar3;
  ulong uVar4;
  char *pcVar5;
  long *plVar6;
  char cVar7;
  long lVar8;
  long lVar9;
  char *pcVar10;
  char *pcVar11;
  long extraout_RDX;
  long lVar12;
  ulong uVar13;
  long lVar14;
  long lVar15;
  long in_FS_OFFSET;
  bool bVar16;
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined8 **local_a8;
  long *local_a0;
  long local_98;
  undefined8 *local_90;
  undefined8 *local_88;
  long *local_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_2 != 0) {
    param_1[0x54] = param_1[0x53];
  }
  pcVar10 = (char *)*param_1;
  pcVar1 = (char *)param_1[1];
  if ((1 < (ulong)((long)pcVar1 - (long)pcVar10)) && (*pcVar10 == 'U')) {
    cVar7 = pcVar10[1];
    if (cVar7 == 'b') {
      pcVar11 = pcVar10 + 2;
      *param_1 = (long)pcVar11;
      if (pcVar1 != pcVar11) {
        if (0xfffffff5 < (int)*pcVar11 - 0x3aU) {
          lVar14 = 0;
          pcVar10 = pcVar10 + 3;
          do {
            pcVar11 = pcVar10;
            *param_1 = (long)pcVar11;
            if (pcVar11 == pcVar1) goto LAB_0012a6fe;
            pcVar10 = pcVar11 + 1;
          } while (0xfffffff5 < (int)*pcVar11 - 0x3aU);
        }
        if ((pcVar11 != pcVar1) && (*pcVar11 == '_')) {
          *param_1 = (long)(pcVar11 + 1);
          plVar2 = (long *)param_1[0x266];
          lVar8 = plVar2[1];
          plVar6 = plVar2;
          if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
            plVar6 = malloc(0x1000);
            if (plVar6 == (long *)0x0) goto LAB_0012a7a1;
            *plVar6 = (long)plVar2;
            plVar6[1] = 0;
            param_1[0x266] = (long)plVar6;
            lVar8 = 0;
          }
          plVar6[1] = lVar8 + 0x20;
          lVar14 = (long)plVar6 + lVar8 + 0x10;
          *(undefined4 *)((long)plVar6 + lVar8 + 0x18) = 0x1010107;
          *(undefined ***)((long)plVar6 + lVar8 + 0x10) = &PTR_LAB_0013e688;
          *(char **)((long)plVar6 + lVar8 + 0x20) = "\'block-literal\'";
          *(char **)((long)plVar6 + lVar8 + 0x28) = "";
          goto LAB_0012a6fe;
        }
      }
    }
    else {
      if (cVar7 == 'l') {
        *param_1 = (long)(pcVar10 + 2);
        lVar8 = param_1[0x62];
        local_98 = param_1[0x54] - param_1[0x53] >> 3;
        param_1[0x62] = local_98;
        local_a8 = &local_90;
        local_90 = &local_78;
        local_80 = &local_38;
        local_78 = 0;
        uStack_70 = 0;
        local_68 = 0;
        uStack_60 = 0;
        local_58 = 0;
        uStack_50 = 0;
        local_48 = 0;
        uStack_40 = 0;
        local_a0 = param_1;
        local_88 = local_90;
        FUN_00125bc0(param_1 + 0x53,&local_a8);
        lVar14 = param_1[3];
        lVar15 = param_1[2];
        pcVar10 = (char *)*param_1;
        lVar9 = lVar15;
        lVar12 = lVar14;
        if ((char *)param_1[1] != pcVar10) {
          lVar9 = lVar14;
          while (*pcVar10 == 'T') {
                    /* try { // try from 0012a3f5 to 0012a401 has its CatchHandler @ 0012a7af */
            __n = __strlen_chk(&DAT_0010aa29,5,lVar9);
            if ((ulong)(param_1[1] - *param_1) < 2) {
              cVar7 = '\0';
            }
            else {
              cVar7 = *(char *)(*param_1 + 1);
            }
            if (((__n == 0) ||
                (puVar3 = memchr(&DAT_0010aa29,(int)cVar7,__n), puVar3 == (undefined *)0x0)) ||
               (puVar3 == &DAT_0010aa28)) break;
                    /* try { // try from 0012a43b to 0012a442 has its CatchHandler @ 0012a7ad */
            local_a8 = (undefined8 **)FUN_0012b6c0(param_1);
            if (local_a8 == (undefined8 **)0x0) {
              lVar14 = 0;
              goto LAB_0012a75b;
            }
            FUN_00123d20(param_1 + 2,&local_a8);
            pcVar10 = (char *)*param_1;
            lVar9 = extraout_RDX;
            if ((char *)param_1[1] == pcVar10) break;
          }
          lVar9 = param_1[2];
          lVar12 = param_1[3];
        }
        lVar14 = lVar14 - lVar15 >> 3;
        lVar15 = lVar14 * 8;
        auVar17 = FUN_0012da70(param_1,lVar9 + lVar14 * 8,lVar12);
        param_1[3] = param_1[2] + lVar15;
        if (auVar17._8_8_ == 0) {
          param_1[0x54] = param_1[0x54] + -8;
        }
                    /* try { // try from 0012a4ab to 0012a4be has its CatchHandler @ 0012a7ab */
        uVar4 = __strlen_chk(&DAT_0010a7b1,3);
        lVar14 = *param_1;
        if ((ulong)(param_1[1] - lVar14) < uVar4) {
LAB_0012a4ce:
          do {
                    /* try { // try from 0012a4e0 to 0012a4e7 has its CatchHandler @ 0012a7b1 */
            local_a8 = (undefined8 **)FUN_00121da0(param_1);
            if (local_a8 == (undefined8 **)0x0) goto LAB_0012a758;
            FUN_00123d20(param_1 + 2,&local_a8);
            pcVar10 = (char *)*param_1;
          } while ((pcVar10 == (char *)param_1[1]) || (*pcVar10 != 'E'));
          pcVar10 = pcVar10 + 1;
        }
        else {
          if (uVar4 != 0) {
            uVar13 = 0;
            do {
              if ((&DAT_0010a7b1)[uVar13] != *(char *)(lVar14 + uVar13)) goto LAB_0012a4ce;
              uVar13 = uVar13 + 1;
            } while (uVar4 != uVar13);
          }
          pcVar10 = (char *)(lVar14 + uVar4);
        }
        *param_1 = (long)pcVar10;
        auVar18 = FUN_0012da70(param_1,param_1[2] + lVar15,param_1[3]);
        param_1[3] = lVar15 + param_1[2];
        pcVar10 = (char *)*param_1;
        pcVar1 = (char *)param_1[1];
        pcVar11 = pcVar10;
        if ((pcVar1 == pcVar10) || ((int)*pcVar10 - 0x3aU < 0xfffffff6)) {
          bVar16 = pcVar10 != pcVar1;
          pcVar10 = (char *)0x0;
          pcVar5 = (char *)0x0;
          if (bVar16) goto LAB_0012a583;
LAB_0012a758:
          lVar14 = 0;
        }
        else {
          lVar14 = 0;
          do {
            pcVar11 = pcVar11 + 1;
            *param_1 = (long)pcVar11;
            if (pcVar11 == pcVar1) goto LAB_0012a75b;
          } while (0xfffffff5 < (int)*pcVar11 - 0x3aU);
          pcVar5 = pcVar11;
          if (pcVar11 == pcVar1) goto LAB_0012a758;
LAB_0012a583:
          if (*pcVar11 != '_') goto LAB_0012a758;
          *param_1 = (long)(pcVar11 + 1);
          plVar2 = (long *)param_1[0x266];
          lVar15 = plVar2[1];
          plVar6 = plVar2;
          if (lVar15 - 0xfb0U < 0xfffffffffffff010) {
            plVar6 = malloc(0x1000);
            if (plVar6 == (long *)0x0) {
LAB_0012a7a1:
                    /* WARNING: Subroutine does not return */
              FUN_00120930();
            }
            *plVar6 = (long)plVar2;
            plVar6[1] = 0;
            param_1[0x266] = (long)plVar6;
            lVar15 = 0;
          }
          plVar6[1] = lVar15 + 0x40;
          lVar14 = (long)plVar6 + lVar15 + 0x10;
          *(undefined4 *)((long)plVar6 + lVar15 + 0x18) = 0x101012d;
          *(undefined ***)((long)plVar6 + lVar15 + 0x10) = &PTR_LAB_0013ed18;
          *(long *)((long)plVar6 + lVar15 + 0x20) = auVar17._0_8_;
          *(long *)((long)plVar6 + lVar15 + 0x28) = auVar17._8_8_;
          *(long *)((long)plVar6 + lVar15 + 0x30) = auVar18._0_8_;
          *(long *)((long)plVar6 + lVar15 + 0x38) = auVar18._8_8_;
          *(char **)((long)plVar6 + lVar15 + 0x40) = pcVar10;
          *(char **)((long)plVar6 + lVar15 + 0x48) = pcVar5;
        }
LAB_0012a75b:
        local_a0[0x54] = local_98 * 8 + local_a0[0x53];
        if (local_90 != &local_78) {
          free(local_90);
        }
        param_1[0x62] = lVar8;
        goto LAB_0012a6fe;
      }
      if (cVar7 == 't') {
        pcVar11 = pcVar10 + 2;
        *param_1 = (long)pcVar11;
        if (pcVar1 != pcVar11) {
          if ((int)*pcVar11 - 0x3aU < 0xfffffff6) {
            pcVar5 = pcVar11;
            pcVar11 = (char *)0x0;
            pcVar10 = (char *)0x0;
          }
          else {
            lVar14 = 0;
            pcVar10 = pcVar10 + 3;
            do {
              pcVar5 = pcVar10;
              *param_1 = (long)pcVar5;
              if (pcVar5 == pcVar1) goto LAB_0012a6fe;
              pcVar10 = pcVar5 + 1;
            } while (0xfffffff5 < (int)*pcVar5 - 0x3aU);
            pcVar10 = pcVar5;
          }
          if ((pcVar5 != pcVar1) && (*pcVar5 == '_')) {
            *param_1 = (long)(pcVar5 + 1);
            plVar2 = (long *)param_1[0x266];
            lVar8 = plVar2[1];
            plVar6 = plVar2;
            if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
              plVar6 = malloc(0x1000);
              if (plVar6 == (long *)0x0) goto LAB_0012a7a1;
              *plVar6 = (long)plVar2;
              plVar6[1] = 0;
              param_1[0x266] = (long)plVar6;
              lVar8 = 0;
            }
            plVar6[1] = lVar8 + 0x20;
            lVar14 = (long)plVar6 + lVar8 + 0x10;
            *(undefined4 *)((long)plVar6 + lVar8 + 0x18) = 0x101012c;
            *(undefined ***)((long)plVar6 + lVar8 + 0x10) = &PTR_LAB_0013ea78;
            *(char **)((long)plVar6 + lVar8 + 0x20) = pcVar11;
            *(char **)((long)plVar6 + lVar8 + 0x28) = pcVar10;
            goto LAB_0012a6fe;
          }
        }
      }
    }
  }
  lVar14 = 0;
LAB_0012a6fe:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar14;
}


// ==== FUN_0012a800 @ 0012a800

long FUN_0012a800(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010143;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013ed88;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_0012a890 @ 0012a890

long FUN_0012a890(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  long *plVar6;
  long lVar7;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar7 = plVar2[1];
  plVar6 = plVar2;
  if (lVar7 - 0xfc0U < 0xfffffffffffff010) {
    plVar6 = malloc(0x1000);
    if (plVar6 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar6 = (long)plVar2;
    plVar6[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar6;
    lVar7 = 0;
  }
  plVar6[1] = lVar7 + 0x30;
  uVar3 = *param_2;
  uVar4 = *param_3;
  uVar5 = param_3[1];
  *(undefined4 *)((long)plVar6 + lVar7 + 0x18) = 0x1010144;
  *(undefined ***)((long)plVar6 + lVar7 + 0x10) = &PTR_LAB_0013edf8;
  *(undefined8 *)((long)plVar6 + lVar7 + 0x20) = uVar3;
  puVar1 = (undefined8 *)((long)plVar6 + lVar7 + 0x28);
  *puVar1 = uVar4;
  puVar1[1] = uVar5;
  return (long)plVar6 + lVar7 + 0x10;
}


// ==== FUN_0012aea0 @ 0012aea0

void FUN_0012aea0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined1 param_15)

{
  char in_AL;
  long in_FS_OFFSET;
  undefined1 auStack_d8 [32];
  undefined8 local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  undefined8 local_98;
  undefined8 local_88;
  undefined8 local_78;
  undefined8 local_68;
  undefined8 local_58;
  undefined8 local_48;
  undefined8 local_38;
  undefined8 local_28;
  undefined1 *local_20;
  undefined1 *local_18;
  long local_8;
  
  local_18 = auStack_d8;
  if (in_AL != '\0') {
    local_a8 = param_1;
    local_98 = param_2;
    local_88 = param_3;
    local_78 = param_4;
    local_68 = param_5;
    local_58 = param_6;
    local_48 = param_7;
    local_38 = param_8;
  }
  local_8 = *(long *)(in_FS_OFFSET + 0x28);
  local_20 = &param_15;
  local_28 = 0x3000000020;
  local_b8 = param_13;
  local_b0 = param_14;
  __vsnprintf_chk(param_9,param_11,0,param_10,param_12,&local_28);
  if (*(long *)(in_FS_OFFSET + 0x28) != local_8) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0012b6c0 @ 0012b6c0

long FUN_0012b6c0(long *param_1)

{
  int iVar1;
  char *pcVar2;
  long lVar3;
  ulong uVar4;
  long *plVar5;
  undefined **ppuVar6;
  long lVar7;
  long *plVar8;
  ulong uVar9;
  long lVar10;
  long *plVar11;
  long in_FS_OFFSET;
  undefined1 auVar12 [16];
  undefined8 **local_a8;
  long *local_a0;
  long local_98;
  undefined8 *local_90;
  undefined8 *local_88;
  long *local_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar2 = (char *)*param_1;
  if ((1 < (ulong)(param_1[1] - (long)pcVar2)) && (*pcVar2 == 'T')) {
    lVar10 = 0;
    switch(pcVar2[1]) {
    case 'n':
      *param_1 = (long)(pcVar2 + 2);
      iVar1 = *(int *)((long)param_1 + 0x31c);
      *(int *)((long)param_1 + 0x31c) = iVar1 + 1;
      plVar8 = (long *)param_1[0x266];
      lVar10 = plVar8[1];
      plVar5 = plVar8;
      if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
        plVar5 = malloc(0x1000);
        if (plVar5 == (long *)0x0) goto LAB_0012bc83;
        *plVar5 = (long)plVar8;
        plVar5[1] = 0;
        param_1[0x266] = (long)plVar5;
        lVar10 = 0;
      }
      plVar5[1] = lVar10 + 0x20;
      plVar8 = (long *)((long)plVar5 + lVar10 + 0x10);
      *(undefined8 *)((long)plVar5 + lVar10 + 0x18) = 0x10101011b;
      *(undefined ***)((long)plVar5 + lVar10 + 0x10) = &PTR_LAB_0013eae8;
      *(int *)((long)plVar5 + lVar10 + 0x20) = iVar1;
      local_a0 = plVar8;
      FUN_0012be90(*(undefined8 *)(param_1[0x54] + -8),&local_a0);
      lVar3 = FUN_00121da0(param_1);
      if (lVar3 != 0) {
        plVar5 = (long *)param_1[0x266];
        lVar7 = plVar5[1];
        plVar11 = plVar5;
        if (lVar7 - 0xfd0U < 0xfffffffffffff010) {
          plVar11 = malloc(0x1000);
          if (plVar11 == (long *)0x0) {
LAB_0012bc83:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar11 = (long)plVar5;
          plVar11[1] = 0;
          param_1[0x266] = (long)plVar11;
          lVar7 = 0;
        }
        plVar11[1] = lVar7 + 0x20;
        lVar10 = (long)plVar11 + lVar7 + 0x10;
        *(undefined4 *)((long)plVar11 + lVar7 + 0x18) = 0x101001d;
        *(undefined ***)((long)plVar11 + lVar7 + 0x10) = &PTR_LAB_0013ebc8;
        *(long **)((long)plVar11 + lVar7 + 0x20) = plVar8;
        *(long *)((long)plVar11 + lVar7 + 0x28) = lVar3;
        goto switchD_0012b724_caseD_6f;
      }
      break;
    default:
      goto switchD_0012b724_caseD_6f;
    case 'p':
      *param_1 = (long)(pcVar2 + 2);
      plVar11 = (long *)FUN_0012b6c0(param_1);
      if (plVar11 != (long *)0x0) {
        plVar8 = (long *)param_1[0x266];
        lVar3 = plVar8[1];
        plVar5 = plVar8;
        if (lVar3 - 0xfd0U < 0xfffffffffffff010) {
          plVar5 = malloc(0x1000);
          if (plVar5 == (long *)0x0) goto LAB_0012bc83;
          *plVar5 = (long)plVar8;
          plVar5[1] = 0;
          param_1[0x266] = (long)plVar5;
          lVar3 = 0;
        }
        plVar5[1] = lVar3 + 0x20;
        lVar10 = lVar3 + (long)plVar5;
        *(undefined4 *)((long)plVar5 + lVar3 + 0x18) = 0x101001f;
        ppuVar6 = &PTR_LAB_0013eca8;
        goto LAB_0012bc6d;
      }
      break;
    case 't':
      *param_1 = (long)(pcVar2 + 2);
      lVar3 = param_1[100];
      *(int *)(param_1 + 100) = (int)lVar3 + 1;
      plVar8 = (long *)param_1[0x266];
      lVar10 = plVar8[1];
      plVar5 = plVar8;
      if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
        plVar5 = malloc(0x1000);
        if (plVar5 == (long *)0x0) goto LAB_0012bc83;
        *plVar5 = (long)plVar8;
        plVar5[1] = 0;
        param_1[0x266] = (long)plVar5;
        lVar10 = 0;
      }
      plVar5[1] = lVar10 + 0x20;
      plVar8 = (long *)((long)plVar5 + lVar10 + 0x10);
      *(undefined8 *)((long)plVar5 + lVar10 + 0x18) = 0x20101011b;
      *(undefined ***)((long)plVar5 + lVar10 + 0x10) = &PTR_LAB_0013eae8;
      *(int *)((long)plVar5 + lVar10 + 0x20) = (int)lVar3;
      local_a0 = plVar8;
      FUN_0012be90(*(undefined8 *)(param_1[0x54] + -8),&local_a0);
      lVar10 = param_1[3];
      lVar3 = param_1[2];
      local_98 = param_1[0x54] - param_1[0x53] >> 3;
      local_a8 = &local_90;
      local_90 = &local_78;
      local_80 = &local_38;
      local_78 = 0;
      uStack_70 = 0;
      local_68 = 0;
      uStack_60 = 0;
      local_58 = 0;
      uStack_50 = 0;
      local_48 = 0;
      uStack_40 = 0;
      local_a0 = param_1;
      local_88 = local_90;
      FUN_00125bc0(param_1 + 0x53,&local_a8);
      do {
                    /* try { // try from 0012b987 to 0012b993 has its CatchHandler @ 0012bc8f */
        uVar4 = __strlen_chk(&DAT_0010af8f,2);
        lVar7 = *param_1;
        if (uVar4 <= (ulong)(param_1[1] - lVar7)) {
          if (uVar4 == 0) {
LAB_0012b9e2:
            *param_1 = lVar7 + uVar4;
            lVar10 = (lVar10 - lVar3 >> 3) * 8;
            auVar12 = FUN_0012da70(param_1,param_1[2] + lVar10,param_1[3]);
            param_1[3] = lVar10 + param_1[2];
            plVar5 = (long *)param_1[0x266];
            lVar3 = plVar5[1];
            plVar11 = plVar5;
            if (lVar3 - 0xfc0U < 0xfffffffffffff010) {
              plVar11 = malloc(0x1000);
              if (plVar11 == (long *)0x0) goto LAB_0012bc83;
              *plVar11 = (long)plVar5;
              plVar11[1] = 0;
              param_1[0x266] = (long)plVar11;
              lVar3 = 0;
            }
            plVar11[1] = lVar3 + 0x30;
            lVar10 = (long)plVar11 + lVar3 + 0x10;
            *(undefined4 *)((long)plVar11 + lVar3 + 0x18) = 0x101001e;
            *(undefined ***)((long)plVar11 + lVar3 + 0x10) = &PTR_LAB_0013ec38;
            *(long **)((long)plVar11 + lVar3 + 0x20) = plVar8;
            *(long *)((long)plVar11 + lVar3 + 0x28) = auVar12._0_8_;
            *(long *)((long)plVar11 + lVar3 + 0x30) = auVar12._8_8_;
            goto LAB_0012ba89;
          }
          uVar9 = 0;
          while ((&DAT_0010af8f)[uVar9] == *(char *)(lVar7 + uVar9)) {
            uVar9 = uVar9 + 1;
            if (uVar4 == uVar9) goto LAB_0012b9e2;
          }
        }
                    /* try { // try from 0012b9a3 to 0012b9aa has its CatchHandler @ 0012bc8d */
        local_a8 = (undefined8 **)FUN_0012b6c0(param_1);
        if (local_a8 == (undefined8 **)0x0) goto LAB_0012bc7c;
        FUN_00123d20(param_1 + 2,&local_a8);
      } while( true );
    case 'y':
      *param_1 = (long)(pcVar2 + 2);
      lVar3 = param_1[99];
      *(int *)(param_1 + 99) = (int)lVar3 + 1;
      plVar8 = (long *)param_1[0x266];
      lVar10 = plVar8[1];
      plVar5 = plVar8;
      if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
        plVar5 = malloc(0x1000);
        if (plVar5 == (long *)0x0) goto LAB_0012bc83;
        *plVar5 = (long)plVar8;
        plVar5[1] = 0;
        param_1[0x266] = (long)plVar5;
        lVar10 = 0;
      }
      plVar5[1] = lVar10 + 0x20;
      plVar11 = (long *)((long)plVar5 + lVar10 + 0x10);
      *(undefined8 *)((long)plVar5 + lVar10 + 0x18) = 0x101011b;
      *(undefined ***)((long)plVar5 + lVar10 + 0x10) = &PTR_LAB_0013eae8;
      *(int *)((long)plVar5 + lVar10 + 0x20) = (int)lVar3;
      local_a0 = plVar11;
      FUN_0012be90(*(undefined8 *)(param_1[0x54] + -8),&local_a0);
      plVar8 = (long *)param_1[0x266];
      lVar3 = plVar8[1];
      plVar5 = plVar8;
      if (lVar3 - 0xfd0U < 0xfffffffffffff010) {
        plVar5 = malloc(0x1000);
        if (plVar5 == (long *)0x0) goto LAB_0012bc83;
        *plVar5 = (long)plVar8;
        plVar5[1] = 0;
        param_1[0x266] = (long)plVar5;
        lVar3 = 0;
      }
      plVar5[1] = lVar3 + 0x20;
      lVar10 = lVar3 + (long)plVar5;
      *(undefined4 *)((long)plVar5 + lVar3 + 0x18) = 0x101001c;
      ppuVar6 = &PTR_LAB_0013eb58;
LAB_0012bc6d:
      lVar10 = lVar10 + 0x10;
      *(undefined ***)((long)plVar5 + lVar3 + 0x10) = ppuVar6;
      *(long **)((long)plVar5 + lVar3 + 0x20) = plVar11;
      goto switchD_0012b724_caseD_6f;
    }
  }
  lVar10 = 0;
switchD_0012b724_caseD_6f:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar10;
LAB_0012bc7c:
  lVar10 = 0;
LAB_0012ba89:
  local_a0[0x54] = local_98 * 8 + local_a0[0x53];
  if (local_90 != &local_78) {
    free(local_90);
  }
  goto switchD_0012b724_caseD_6f;
}


// ==== FUN_0012bcd0 @ 0012bcd0

long FUN_0012bcd0(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_0012be90 @ 0012be90

void FUN_0012be90(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *__src;
  undefined8 uVar1;
  void *__dest;
  size_t __n;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)param_1[1];
  if (puVar2 == (undefined8 *)param_1[2]) {
    __src = (undefined8 *)*param_1;
    __n = (long)puVar2 - (long)__src;
    if (__src == param_1 + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_0012bf2b;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *param_1 = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *param_1 = __dest;
      if (__dest == (void *)0x0) {
LAB_0012bf2b:
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
    }
    puVar2 = (undefined8 *)((long)__dest + ((long)__n >> 3) * 8);
    param_1[1] = puVar2;
    param_1[2] = (void *)((long)__dest + ((long)__n >> 2) * 8);
  }
  uVar1 = *param_2;
  param_1[1] = puVar2 + 1;
  *puVar2 = uVar1;
  return;
}


// ==== FUN_0012bf30 @ 0012bf30

void FUN_0012bf30(long param_1,undefined8 *param_2)

{
  int iVar1;
  bool bVar2;
  uint uVar3;
  long lVar4;
  ulong uVar5;
  void *pvVar6;
  long lVar7;
  ulong uVar8;
  long lVar9;
  long in_FS_OFFSET;
  byte abStack_34 [12];
  long local_28;
  
  local_28 = *(long *)(in_FS_OFFSET + 0x28);
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 == 2) {
    lVar4 = param_2[1];
    uVar5 = lVar4 + 3;
    if (uVar5 < (ulong)param_2[2]) {
      pvVar6 = (void *)*param_2;
    }
    else {
      uVar8 = param_2[2] * 2;
      if (uVar8 < uVar5) {
        uVar8 = uVar5;
      }
      param_2[2] = uVar8;
      pvVar6 = realloc((void *)*param_2,uVar8);
      *param_2 = pvVar6;
      if (pvVar6 == (void *)0x0) goto LAB_0012c189;
      lVar4 = param_2[1];
    }
    *(undefined1 *)((long)pvVar6 + lVar4 + 2) = 0x54;
    *(undefined2 *)((long)pvVar6 + lVar4) = 0x5424;
    lVar4 = 3;
LAB_0012c066:
    param_2[1] = param_2[1] + lVar4;
  }
  else {
    if (iVar1 == 1) {
      lVar4 = param_2[1];
      uVar5 = lVar4 + 2;
      if (uVar5 < (ulong)param_2[2]) {
        pvVar6 = (void *)*param_2;
      }
      else {
        uVar8 = param_2[2] * 2;
        if (uVar8 < uVar5) {
          uVar8 = uVar5;
        }
        param_2[2] = uVar8;
        pvVar6 = realloc((void *)*param_2,uVar8);
        *param_2 = pvVar6;
        if (pvVar6 == (void *)0x0) goto LAB_0012c189;
        lVar4 = param_2[1];
      }
      *(undefined2 *)((long)pvVar6 + lVar4) = 0x4e24;
      lVar4 = 2;
      goto LAB_0012c066;
    }
    if (iVar1 == 0) {
      lVar4 = param_2[1];
      uVar5 = lVar4 + 2;
      if (uVar5 < (ulong)param_2[2]) {
        pvVar6 = (void *)*param_2;
      }
      else {
        uVar8 = param_2[2] * 2;
        if (uVar8 < uVar5) {
          uVar8 = uVar5;
        }
        param_2[2] = uVar8;
        pvVar6 = realloc((void *)*param_2,uVar8);
        *param_2 = pvVar6;
        if (pvVar6 == (void *)0x0) goto LAB_0012c189;
        lVar4 = param_2[1];
      }
      *(undefined2 *)((long)pvVar6 + lVar4) = 0x5424;
      lVar4 = 2;
      goto LAB_0012c066;
    }
  }
  if (*(int *)(param_1 + 0x10) != 0) {
    uVar3 = *(int *)(param_1 + 0x10) - 1;
    if (uVar3 == 0) {
      lVar4 = param_2[1];
      uVar5 = lVar4 + 1;
      if (uVar5 < (ulong)param_2[2]) {
        pvVar6 = (void *)*param_2;
      }
      else {
        uVar8 = param_2[2] * 2;
        if (uVar8 < uVar5) {
          uVar8 = uVar5;
        }
        param_2[2] = uVar8;
        pvVar6 = realloc((void *)*param_2,uVar8);
        *param_2 = pvVar6;
        if (pvVar6 == (void *)0x0) {
LAB_0012c189:
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        lVar4 = param_2[1];
        uVar5 = lVar4 + 1;
      }
      param_2[1] = uVar5;
      *(undefined1 *)((long)pvVar6 + lVar4) = 0x30;
    }
    else {
      uVar5 = (ulong)uVar3;
      lVar4 = 0;
      do {
        lVar7 = lVar4;
        abStack_34[lVar7] = (char)uVar5 + (char)(uVar5 / 10) * -10 | 0x30;
        lVar4 = lVar7 + -1;
        bVar2 = 9 < uVar5;
        uVar5 = uVar5 / 10;
      } while (bVar2);
      if (lVar4 != 0) {
        lVar9 = param_2[1];
        uVar5 = lVar9 - lVar4;
        if (uVar5 < (ulong)param_2[2]) {
          pvVar6 = (void *)*param_2;
        }
        else {
          uVar8 = param_2[2] * 2;
          if (uVar8 < uVar5) {
            uVar8 = uVar5;
          }
          param_2[2] = uVar8;
          pvVar6 = realloc((void *)*param_2,uVar8);
          *param_2 = pvVar6;
          if (pvVar6 == (void *)0x0) goto LAB_0012c189;
          lVar9 = param_2[1];
        }
        memmove((void *)(lVar9 + (long)pvVar6),abStack_34 + lVar7,-lVar4);
        param_2[1] = param_2[1] - lVar4;
      }
    }
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0012c450 @ 0012c450

void FUN_0012c450(long *param_1,undefined8 *param_2)

{
  ulong uVar1;
  long *plVar2;
  void *pvVar3;
  long lVar4;
  ulong __size;
  long lVar5;
  long lVar6;
  bool bVar7;
  
  if (param_1[1] != 0) {
    lVar6 = param_2[1];
    bVar7 = true;
    lVar5 = 0;
    do {
      lVar4 = lVar6;
      if (!bVar7) {
        uVar1 = lVar6 + 2;
        if (uVar1 < (ulong)param_2[2]) {
          pvVar3 = (void *)*param_2;
        }
        else {
          __size = param_2[2] * 2;
          if (__size < uVar1) {
            __size = uVar1;
          }
          param_2[2] = __size;
          pvVar3 = realloc((void *)*param_2,__size);
          *param_2 = pvVar3;
          if (pvVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          lVar4 = param_2[1];
        }
        *(undefined2 *)((long)pvVar3 + lVar4) = 0x202c;
        lVar4 = param_2[1] + 2;
        param_2[1] = lVar4;
      }
      plVar2 = *(long **)(*param_1 + lVar5 * 8);
      (**(code **)(*plVar2 + 0x20))(plVar2,param_2);
      if (*(char *)((long)plVar2 + 9) != '\x01') {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2);
      }
      if (lVar4 == param_2[1]) {
        param_2[1] = lVar6;
      }
      else {
        bVar7 = false;
        lVar6 = param_2[1];
      }
      lVar5 = lVar5 + 1;
    } while (lVar5 != param_1[1]);
  }
  return;
}


// ==== FUN_0012c700 @ 0012c700

void FUN_0012c700(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  void *pvVar2;
  long lVar3;
  ulong uVar4;
  
  lVar3 = param_2[1];
  if (*(long *)(param_1 + 0x18) != 0) {
    uVar1 = lVar3 + 1;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar2 = (void *)*param_2;
    }
    else {
      uVar4 = param_2[2] * 2;
      if (uVar4 < uVar1) {
        uVar4 = uVar1;
      }
      param_2[2] = uVar4;
      pvVar2 = realloc((void *)*param_2,uVar4);
      *param_2 = pvVar2;
      if (pvVar2 == (void *)0x0) goto LAB_0012c847;
      lVar3 = param_2[1];
    }
    *(undefined1 *)((long)pvVar2 + lVar3) = 0x3c;
    param_2[1] = param_2[1] + 1;
    FUN_0012c450(param_1 + 0x10,param_2);
    lVar3 = param_2[1];
    uVar1 = lVar3 + 1;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar2 = (void *)*param_2;
    }
    else {
      uVar4 = param_2[2] * 2;
      if (uVar4 < uVar1) {
        uVar4 = uVar1;
      }
      param_2[2] = uVar4;
      pvVar2 = realloc((void *)*param_2,uVar4);
      *param_2 = pvVar2;
      if (pvVar2 == (void *)0x0) goto LAB_0012c847;
      lVar3 = param_2[1];
    }
    *(undefined1 *)((long)pvVar2 + lVar3) = 0x3e;
    lVar3 = param_2[1] + 1;
    param_2[1] = lVar3;
  }
  uVar1 = lVar3 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] * 2;
    if (uVar4 < uVar1) {
      uVar4 = uVar1;
    }
    param_2[2] = uVar4;
    pvVar2 = realloc((void *)*param_2,uVar4);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_0012c847;
    lVar3 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar3) = 0x28;
  param_2[1] = param_2[1] + 1;
  FUN_0012c450(param_1 + 0x20,param_2);
  lVar3 = param_2[1];
  uVar1 = lVar3 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] * 2;
    if (uVar4 < uVar1) {
      uVar4 = uVar1;
    }
    param_2[2] = uVar4;
    pvVar2 = realloc((void *)*param_2,uVar4);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_0012c847:
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    lVar3 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar3) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_0012d0e0 @ 0012d0e0

void FUN_0012d0e0(long *param_1)

{
  undefined8 *puVar1;
  void *pvVar2;
  ulong uVar3;
  long lVar4;
  long lVar5;
  ulong uVar6;
  long in_FS_OFFSET;
  undefined **local_38;
  undefined4 local_30;
  undefined8 local_28;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  puVar1 = (undefined8 *)*param_1;
  lVar5 = param_1[1];
  lVar4 = puVar1[1];
  uVar3 = lVar4 + 1;
  if (uVar3 < (ulong)puVar1[2]) {
    pvVar2 = (void *)*puVar1;
  }
  else {
    uVar6 = puVar1[2] * 2;
    if (uVar6 < uVar3) {
      uVar6 = uVar3;
    }
    puVar1[2] = uVar6;
    pvVar2 = realloc((void *)*puVar1,uVar6);
    *puVar1 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_0012d1d1;
    lVar4 = puVar1[1];
    uVar3 = lVar4 + 1;
  }
  puVar1[1] = uVar3;
  *(undefined1 *)((long)pvVar2 + lVar4) = 0x28;
  local_28 = *(undefined8 *)(lVar5 + 0x10);
  local_30 = 0x1010122;
  local_38 = &PTR_LAB_0013ef48;
  FUN_0012d1e0(&local_38,*param_1);
  puVar1 = (undefined8 *)*param_1;
  lVar5 = puVar1[1];
  uVar3 = lVar5 + 1;
  if (uVar3 < (ulong)puVar1[2]) {
    pvVar2 = (void *)*puVar1;
  }
  else {
    uVar6 = puVar1[2] * 2;
    if (uVar6 < uVar3) {
      uVar6 = uVar3;
    }
    puVar1[2] = uVar6;
    pvVar2 = realloc((void *)*puVar1,uVar6);
    *puVar1 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_0012d1d1:
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    lVar5 = puVar1[1];
    uVar3 = lVar5 + 1;
  }
  puVar1[1] = uVar3;
  *(undefined1 *)((long)pvVar2 + lVar5) = 0x29;
  if (*(long *)(in_FS_OFFSET + 0x28) != local_20) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0012d1e0 @ 0012d1e0

void FUN_0012d1e0(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  long *plVar5;
  size_t sVar6;
  void *pvVar7;
  uint uVar8;
  ulong uVar9;
  long lVar10;
  
  uVar2 = *(undefined4 *)(param_2 + 3);
  uVar3 = *(undefined4 *)((long)param_2 + 0x1c);
  param_2[3] = 0xffffffffffffffff;
  lVar10 = param_2[1];
  plVar5 = *(long **)(param_1 + 0x10);
                    /* try { // try from 0012d211 to 0012d228 has its CatchHandler @ 0012d3a6 */
  (**(code **)(*plVar5 + 0x20))(plVar5);
  if (*(char *)((long)plVar5 + 9) != '\x01') {
    (**(code **)(*plVar5 + 0x28))(plVar5,param_2);
  }
  uVar4 = *(uint *)((long)param_2 + 0x1c);
  if (uVar4 == 0xffffffff) {
                    /* try { // try from 0012d30d to 0012d31d has its CatchHandler @ 0012d3a6 */
    sVar6 = __strlen_chk(&DAT_0010a939,4);
    if (sVar6 == 0) goto LAB_0012d381;
    lVar10 = param_2[1];
    uVar1 = lVar10 + sVar6;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar7 = (void *)*param_2;
    }
    else {
      uVar9 = param_2[2] * 2;
      if (uVar9 < uVar1) {
        uVar9 = uVar1;
      }
      param_2[2] = uVar9;
      pvVar7 = realloc((void *)*param_2,uVar9);
      *param_2 = pvVar7;
      if (pvVar7 == (void *)0x0) {
LAB_0012d3a1:
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
      lVar10 = param_2[1];
    }
    memcpy((void *)(lVar10 + (long)pvVar7),&DAT_0010a939,sVar6);
    lVar10 = sVar6 + param_2[1];
  }
  else if (uVar4 != 0) {
    if (1 < uVar4) {
      uVar8 = 1;
      do {
                    /* try { // try from 0012d26c to 0012d278 has its CatchHandler @ 0012d3a8 */
        sVar6 = __strlen_chk(&DAT_0010add3,3);
        if (sVar6 != 0) {
          lVar10 = param_2[1];
          uVar1 = lVar10 + sVar6;
          if (uVar1 < (ulong)param_2[2]) {
            pvVar7 = (void *)*param_2;
          }
          else {
            uVar9 = param_2[2] * 2;
            if (uVar9 < uVar1) {
              uVar9 = uVar1;
            }
            param_2[2] = uVar9;
            pvVar7 = realloc((void *)*param_2,uVar9);
            *param_2 = pvVar7;
            if (pvVar7 == (void *)0x0) goto LAB_0012d3a1;
            lVar10 = param_2[1];
          }
          memcpy((void *)(lVar10 + (long)pvVar7),&DAT_0010add3,sVar6);
          param_2[1] = param_2[1] + sVar6;
        }
        *(uint *)(param_2 + 3) = uVar8;
        plVar5 = *(long **)(param_1 + 0x10);
                    /* try { // try from 0012d2e9 to 0012d307 has its CatchHandler @ 0012d3a8 */
        (**(code **)(*plVar5 + 0x20))(plVar5,param_2);
        if (*(char *)((long)plVar5 + 9) != '\x01') {
          (**(code **)(*plVar5 + 0x28))(plVar5,param_2);
        }
        uVar8 = uVar8 + 1;
      } while (uVar4 != uVar8);
    }
    goto LAB_0012d381;
  }
  param_2[1] = lVar10;
LAB_0012d381:
  *(undefined4 *)((long)param_2 + 0x1c) = uVar3;
  *(undefined4 *)(param_2 + 3) = uVar2;
  return;
}


// ==== FUN_0012da70 @ 0012da70

undefined1  [16] FUN_0012da70(long param_1,void *param_2,long param_3)

{
  long *plVar1;
  undefined8 *puVar2;
  long *plVar3;
  long lVar4;
  uint uVar5;
  ulong uVar6;
  size_t __n;
  undefined1 auVar7 [16];
  
  __n = param_3 - (long)param_2;
  uVar5 = (int)__n + 0xfU & 0xfffffff0;
  uVar6 = (ulong)uVar5;
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (0xfef < lVar4 + uVar6) {
    if (0xff0 < uVar5) {
      puVar2 = malloc(uVar6 + 0x10);
      if (puVar2 == (undefined8 *)0x0) {
LAB_0012db3e:
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
      *puVar2 = *plVar1;
      puVar2[1] = 0;
      *plVar1 = (long)puVar2;
      puVar2 = puVar2 + 2;
      goto joined_r0x0012db1a;
    }
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) goto LAB_0012db3e;
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = uVar6 + lVar4;
  puVar2 = (undefined8 *)((long)plVar3 + lVar4 + 0x10);
joined_r0x0012db1a:
  if (__n != 0) {
    memmove(puVar2,param_2,__n);
  }
  auVar7._8_8_ = (long)__n >> 3;
  auVar7._0_8_ = puVar2;
  return auVar7;
}


// ==== FUN_0012ddc0 @ 0012ddc0

long FUN_0012ddc0(undefined8 *param_1)

{
  char cVar1;
  long lVar2;
  long in_FS_OFFSET;
  long local_20;
  long local_18;
  
  local_18 = *(long *)(in_FS_OFFSET + 0x28);
  if ((char *)param_1[1] == (char *)*param_1) {
LAB_0012ddf5:
    lVar2 = FUN_001248a0(param_1);
    if (*(long *)(in_FS_OFFSET + 0x28) != local_18) goto LAB_0012de53;
  }
  else {
    cVar1 = *(char *)*param_1;
    if (cVar1 == 'D') {
      lVar2 = FUN_001255e0(param_1);
    }
    else {
      if (cVar1 != 'T') goto LAB_0012ddf5;
      lVar2 = FUN_00125220(param_1);
    }
    local_20 = lVar2;
    if (lVar2 != 0) {
      FUN_00123d20(param_1 + 0x25,&local_20);
    }
    if (*(long *)(in_FS_OFFSET + 0x28) != local_18) {
LAB_0012de53:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  return lVar2;
}


// ==== FUN_0012de60 @ 0012de60

long FUN_0012de60(undefined8 *param_1)

{
  long *plVar1;
  long lVar2;
  long lVar3;
  long *plVar4;
  long lVar5;
  
  lVar2 = FUN_0012e110();
  if (lVar2 != 0) {
    if ((char *)param_1[1] == (char *)*param_1) {
      return lVar2;
    }
    if (*(char *)*param_1 != 'I') {
      return lVar2;
    }
    lVar3 = FUN_00124c50(param_1,0);
    if (lVar3 != 0) {
      plVar1 = (long *)param_1[0x266];
      lVar5 = plVar1[1];
      plVar4 = plVar1;
      if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
        plVar4 = malloc(0x1000);
        if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        *plVar4 = (long)plVar1;
        plVar4[1] = 0;
        param_1[0x266] = plVar4;
        lVar5 = 0;
      }
      plVar4[1] = lVar5 + 0x20;
      *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010125;
      *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013fdb8;
      *(long *)((long)plVar4 + lVar5 + 0x20) = lVar2;
      *(long *)((long)plVar4 + lVar5 + 0x28) = lVar3;
      return (long)plVar4 + lVar5 + 0x10;
    }
  }
  return 0;
}


// ==== FUN_0012df30 @ 0012df30

long FUN_0012df30(undefined8 *param_1)

{
  char *pcVar1;
  long *plVar2;
  char *pcVar3;
  long lVar4;
  long lVar5;
  long lVar6;
  long *plVar7;
  
  pcVar3 = (char *)*param_1;
  pcVar1 = (char *)param_1[1];
  if ((pcVar1 != pcVar3) && (0xfffffff5 < (int)*pcVar3 - 0x3aU)) {
    lVar4 = FUN_0012de60(param_1);
    return lVar4;
  }
  if (1 < (ulong)((long)pcVar1 - (long)pcVar3)) {
    if (*pcVar3 == 'o') {
      if (pcVar3[1] == 'n') {
        *param_1 = pcVar3 + 2;
      }
    }
    else if ((*pcVar3 == 'd') && (pcVar3[1] == 'n')) {
      pcVar3 = pcVar3 + 2;
      *param_1 = pcVar3;
      if ((pcVar1 == pcVar3) || ((int)*pcVar3 - 0x3aU < 0xfffffff6)) {
        lVar4 = FUN_0012ddc0(param_1);
      }
      else {
        lVar4 = FUN_0012de60(param_1);
      }
      if (lVar4 == 0) {
        return 0;
      }
      plVar2 = (long *)param_1[0x266];
      lVar5 = plVar2[1];
      plVar7 = plVar2;
      if (0xfffffffffffff00f < lVar5 - 0xfd0U) {
LAB_0012e0ce:
        plVar7[1] = lVar5 + 0x20;
        *(undefined4 *)((long)plVar7 + lVar5 + 0x18) = 0x101012b;
        *(undefined ***)((long)plVar7 + lVar5 + 0x10) = &PTR_LAB_0013f2c8;
        *(long *)((long)plVar7 + lVar5 + 0x20) = lVar4;
        return (long)plVar7 + lVar5 + 0x10;
      }
      plVar7 = malloc(0x1000);
      if (plVar7 != (long *)0x0) {
        *plVar7 = (long)plVar2;
        plVar7[1] = 0;
        param_1[0x266] = plVar7;
        lVar5 = 0;
        goto LAB_0012e0ce;
      }
      goto LAB_0012e106;
    }
  }
  lVar5 = FUN_0012e440(param_1,0);
  lVar4 = 0;
  if (lVar5 != 0) {
    if (((char *)param_1[1] == (char *)*param_1) || (*(char *)*param_1 != 'I')) {
      lVar4 = lVar5;
    }
    else {
      lVar6 = FUN_00124c50(param_1,0);
      lVar4 = 0;
      if (lVar6 != 0) {
        plVar2 = (long *)param_1[0x266];
        lVar4 = plVar2[1];
        plVar7 = plVar2;
        if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
          plVar7 = malloc(0x1000);
          if (plVar7 == (long *)0x0) {
LAB_0012e106:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar7 = (long)plVar2;
          plVar7[1] = 0;
          param_1[0x266] = plVar7;
          lVar4 = 0;
        }
        plVar7[1] = lVar4 + 0x20;
        *(undefined4 *)((long)plVar7 + lVar4 + 0x18) = 0x1010125;
        *(undefined ***)((long)plVar7 + lVar4 + 0x10) = &PTR_LAB_0013fdb8;
        *(long *)((long)plVar7 + lVar4 + 0x20) = lVar5;
        *(long *)((long)plVar7 + lVar4 + 0x28) = lVar6;
        lVar4 = (long)plVar7 + lVar4 + 0x10;
      }
    }
  }
  return lVar4;
}


// ==== FUN_0012e110 @ 0012e110

long FUN_0012e110(long *param_1)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  long *plVar4;
  long lVar5;
  char *pcVar6;
  ulong uVar7;
  ulong uVar8;
  long *plVar9;
  char *pcVar10;
  char *pcVar11;
  
  pcVar11 = (char *)*param_1;
  pcVar1 = (char *)param_1[1];
  if ((pcVar1 == pcVar11) || ((byte)(*pcVar11 - 0x3aU) < 0xf6)) {
    return 0;
  }
  pcVar2 = pcVar11 + -0x2f;
  pcVar11 = pcVar1 + ~(ulong)pcVar11;
  uVar8 = 0;
  do {
    uVar7 = uVar8;
    pcVar6 = pcVar11;
    pcVar3 = pcVar2;
    pcVar10 = pcVar3 + 0x30;
    *param_1 = (long)pcVar10;
    lVar5 = (long)pcVar3[0x2f] + uVar7 * 10;
    uVar8 = lVar5 - 0x30;
    if (pcVar10 == pcVar1) break;
    pcVar2 = pcVar3 + 1;
    pcVar11 = pcVar6 + -1;
  } while ((byte)(pcVar3[0x30] - 0x30U) < 10);
  if (pcVar6 <= (char *)(lVar5 - 0x31U)) {
    return 0;
  }
  pcVar11 = pcVar3 + (long)pcVar3[0x2f] + uVar7 * 10;
  *param_1 = (long)pcVar11;
  if ((((((uVar8 < 10) || (*pcVar10 != '_')) || (pcVar3[0x31] != 'G')) ||
       ((pcVar3[0x32] != 'L' || (pcVar3[0x33] != 'O')))) ||
      ((pcVar3[0x34] != 'B' || ((pcVar3[0x35] != 'A' || (pcVar3[0x36] != 'L')))))) ||
     ((pcVar3[0x37] != '_' || ((pcVar3[0x38] != '_' || (pcVar3[0x39] != 'N')))))) {
    plVar9 = (long *)param_1[0x266];
    lVar5 = plVar9[1];
    if (0xfffffffffffff00f < lVar5 - 0xfd0U) goto LAB_0012e294;
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) goto LAB_0012e2d6;
  }
  else {
    plVar9 = (long *)param_1[0x266];
    lVar5 = plVar9[1];
    if (0xfffffffffffff00f < lVar5 - 0xfd0U) {
      pcVar11 = "";
      pcVar10 = "(anonymous namespace)";
      goto LAB_0012e294;
    }
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
LAB_0012e2d6:
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    pcVar11 = "";
    pcVar10 = "(anonymous namespace)";
  }
  *plVar4 = (long)plVar9;
  plVar4[1] = 0;
  param_1[0x266] = (long)plVar4;
  lVar5 = 0;
  plVar9 = plVar4;
LAB_0012e294:
  plVar9[1] = lVar5 + 0x20;
  *(undefined4 *)((long)plVar9 + lVar5 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar9 + lVar5 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar9 + lVar5 + 0x20) = pcVar10;
  *(char **)((long)plVar9 + lVar5 + 0x28) = pcVar11;
  return (long)plVar9 + lVar5 + 0x10;
}


// ==== FUN_0012e2e0 @ 0012e2e0

long FUN_0012e2e0(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar2[1];
  plVar5 = plVar2;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar2;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  uVar3 = *param_2;
  uVar4 = param_2[1];
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013e688;
  puVar1 = (undefined8 *)((long)plVar5 + lVar6 + 0x20);
  *puVar1 = uVar3;
  puVar1[1] = uVar4;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_0012e440 @ 0012e440

long FUN_0012e440(undefined8 *param_1,undefined1 *param_2)

{
  char cVar1;
  undefined1 uVar2;
  undefined1 *puVar3;
  long *plVar4;
  long lVar5;
  long *plVar6;
  long lVar7;
  long lVar8;
  ulong uVar9;
  char *pcVar10;
  long in_FS_OFFSET;
  long local_30;
  long local_28;
  
  local_28 = *(long *)(in_FS_OFFSET + 0x28);
  puVar3 = (undefined1 *)*param_1;
  uVar9 = (long)param_1[1] - (long)puVar3;
  if ((undefined1 *)param_1[1] == puVar3) goto LAB_0012ecb2;
  lVar7 = 0;
  switch(*puVar3) {
  case 0x61:
    if (uVar9 < 2) break;
    lVar7 = 0;
    switch(puVar3[1]) {
    case 0x4e:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator&=";
      break;
    default:
      goto switchD_0012e48d_caseD_62;
    case 0x53:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator=";
      goto LAB_0012edb1;
    case 0x61:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator&&";
      break;
    case 100:
    case 0x6e:
      *param_1 = puVar3 + 2;
      plVar4 = (long *)param_1[0x266];
      lVar5 = plVar4[1];
      plVar6 = plVar4;
      if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_0012ee44;
        *plVar6 = (long)plVar4;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar5 = 0;
      }
      plVar6[1] = lVar5 + 0x20;
      lVar7 = (long)plVar6 + lVar5 + 0x10;
      *(undefined4 *)((long)plVar6 + lVar5 + 0x18) = 0x1010107;
      *(undefined ***)((long)plVar6 + lVar5 + 0x10) = &PTR_LAB_0013e688;
      *(char **)((long)plVar6 + lVar5 + 0x20) = "operator&";
      *(char **)((long)plVar6 + lVar5 + 0x28) = "";
      goto switchD_0012e48d_caseD_62;
    }
LAB_0012ee22:
    lVar7 = FUN_0012eef0(param_1,pcVar10);
  default:
    goto switchD_0012e48d_caseD_62;
  case 99:
    if (uVar9 < 2) break;
    lVar7 = 0;
    switch(puVar3[1]) {
    case 0x6c:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator()";
      goto LAB_0012ee22;
    case 0x6d:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator,";
      break;
    default:
      goto switchD_0012e48d_caseD_62;
    case 0x6f:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator~";
      break;
    case 0x76:
      *param_1 = puVar3 + 2;
      uVar2 = *(undefined1 *)(param_1 + 0x61);
      cVar1 = *(char *)((long)param_1 + 0x309);
      *(undefined1 *)(param_1 + 0x61) = 0;
      *(bool *)((long)param_1 + 0x309) = param_2 != (undefined1 *)0x0 || cVar1 != '\0';
                    /* try { // try from 0012ec42 to 0012ec49 has its CatchHandler @ 0012ee4e */
      local_30 = FUN_00121da0(param_1);
      if (local_30 == 0) {
        lVar7 = 0;
      }
      else {
        if (param_2 != (undefined1 *)0x0) {
          *param_2 = 1;
        }
        lVar7 = FUN_0012f030(param_1,&local_30);
      }
      *(char *)((long)param_1 + 0x309) = cVar1;
      *(undefined1 *)(param_1 + 0x61) = uVar2;
      goto switchD_0012e48d_caseD_62;
    }
    goto LAB_0012edb1;
  case 100:
    if (uVar9 < 2) break;
    lVar7 = 0;
    switch(puVar3[1]) {
    case 0x56:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator/=";
      goto LAB_0012ee22;
    case 0x61:
      *param_1 = puVar3 + 2;
      lVar7 = FUN_0012f0c0(param_1,"operator delete[]");
      break;
    case 0x65:
switchD_0012e974_caseD_6c:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator*";
      goto LAB_0012edb1;
    case 0x6c:
      *param_1 = puVar3 + 2;
      lVar7 = FUN_0012bcd0(param_1,"operator delete");
      break;
    case 0x76:
      *param_1 = puVar3 + 2;
      pcVar10 = "operator/";
LAB_0012edb1:
      lVar7 = FUN_0012ef90(param_1,pcVar10);
    }
    goto switchD_0012e48d_caseD_62;
  case 0x65:
    if (1 < uVar9) {
      cVar1 = puVar3[1];
      if (cVar1 == 'O') {
        *param_1 = puVar3 + 2;
        pcVar10 = "operator^=";
      }
      else {
        if (cVar1 != 'q') {
          if (cVar1 == 'o') {
            *param_1 = puVar3 + 2;
            pcVar10 = "operator^";
            goto LAB_0012edb1;
          }
          break;
        }
        *param_1 = puVar3 + 2;
        pcVar10 = "operator==";
      }
      goto LAB_0012ee22;
    }
    break;
  case 0x67:
    if (1 < uVar9) {
      if (puVar3[1] == 't') {
        *param_1 = puVar3 + 2;
        plVar4 = (long *)param_1[0x266];
        lVar5 = plVar4[1];
        plVar6 = plVar4;
        if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
          plVar6 = malloc(0x1000);
          if (plVar6 == (long *)0x0) {
LAB_0012ee44:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar6 = (long)plVar4;
          plVar6[1] = 0;
          param_1[0x266] = plVar6;
          lVar5 = 0;
        }
        plVar6[1] = lVar5 + 0x20;
        lVar7 = (long)plVar6 + lVar5 + 0x10;
        *(undefined4 *)((long)plVar6 + lVar5 + 0x18) = 0x1010107;
        *(undefined ***)((long)plVar6 + lVar5 + 0x10) = &PTR_LAB_0013e688;
        *(char **)((long)plVar6 + lVar5 + 0x20) = "operator>";
        *(char **)((long)plVar6 + lVar5 + 0x28) = "";
        goto switchD_0012e48d_caseD_62;
      }
      if (puVar3[1] == 'e') {
        *param_1 = puVar3 + 2;
        plVar4 = (long *)param_1[0x266];
        lVar5 = plVar4[1];
        plVar6 = plVar4;
        if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
          plVar6 = malloc(0x1000);
          if (plVar6 == (long *)0x0) goto LAB_0012ee44;
          *plVar6 = (long)plVar4;
          plVar6[1] = 0;
          param_1[0x266] = plVar6;
          lVar5 = 0;
        }
        plVar6[1] = lVar5 + 0x20;
        lVar7 = (long)plVar6 + lVar5 + 0x10;
        *(undefined4 *)((long)plVar6 + lVar5 + 0x18) = 0x1010107;
        *(undefined ***)((long)plVar6 + lVar5 + 0x10) = &PTR_LAB_0013e688;
        *(char **)((long)plVar6 + lVar5 + 0x20) = "operator>=";
        *(char **)((long)plVar6 + lVar5 + 0x28) = "";
        goto switchD_0012e48d_caseD_62;
      }
    }
    break;
  case 0x69:
    if ((1 < uVar9) && (puVar3[1] == 'x')) {
      *param_1 = puVar3 + 2;
      plVar4 = (long *)param_1[0x266];
      lVar5 = plVar4[1];
      plVar6 = plVar4;
      if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_0012ee44;
        *plVar6 = (long)plVar4;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar5 = 0;
      }
      plVar6[1] = lVar5 + 0x20;
      lVar7 = (long)plVar6 + lVar5 + 0x10;
      *(undefined4 *)((long)plVar6 + lVar5 + 0x18) = 0x1010107;
      *(undefined ***)((long)plVar6 + lVar5 + 0x10) = &PTR_LAB_0013e688;
      *(char **)((long)plVar6 + lVar5 + 0x20) = "operator[]";
      *(char **)((long)plVar6 + lVar5 + 0x28) = "";
      goto switchD_0012e48d_caseD_62;
    }
    break;
  case 0x6c:
    if (1 < uVar9) {
      lVar7 = 0;
      switch(puVar3[1]) {
      case 0x53:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator<<=";
LAB_0012edf7:
        lVar7 = FUN_0012f1f0(param_1,pcVar10);
      default:
        goto switchD_0012e48d_caseD_62;
      case 0x65:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator<=";
        break;
      case 0x69:
        *param_1 = puVar3 + 2;
        local_30 = FUN_0012e110(param_1);
        if (local_30 != 0) {
          lVar7 = FUN_0012f160(param_1,&local_30);
          goto switchD_0012e48d_caseD_62;
        }
        goto LAB_0012ecb2;
      case 0x73:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator<<";
        break;
      case 0x74:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator<";
        goto LAB_0012edb1;
      }
      goto LAB_0012ee22;
    }
    break;
  case 0x6d:
    if (1 < uVar9) {
      lVar7 = 0;
      switch(puVar3[1]) {
      case 0x49:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator-=";
        break;
      default:
        goto switchD_0012e48d_caseD_62;
      case 0x4c:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator*=";
        break;
      case 0x69:
switchD_0012ea96_caseD_67:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator-";
        goto LAB_0012edb1;
      case 0x6c:
        goto switchD_0012e974_caseD_6c;
      case 0x6d:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator--";
      }
      goto LAB_0012ee22;
    }
    break;
  case 0x6e:
    if (1 < uVar9) {
      lVar7 = 0;
      switch(puVar3[1]) {
      case 0x61:
        *param_1 = puVar3 + 2;
        lVar7 = FUN_0012f290(param_1,"operator new[]");
        break;
      case 0x65:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator!=";
        goto LAB_0012ee22;
      case 0x67:
        goto switchD_0012ea96_caseD_67;
      case 0x74:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator!";
        goto LAB_0012edb1;
      case 0x77:
        *param_1 = puVar3 + 2;
        lVar7 = FUN_0012f330(param_1,"operator new");
      }
      goto switchD_0012e48d_caseD_62;
    }
    break;
  case 0x6f:
    if (1 < uVar9) {
      cVar1 = puVar3[1];
      if (cVar1 == 'R') {
        *param_1 = puVar3 + 2;
        pcVar10 = "operator|=";
      }
      else {
        if (cVar1 == 'r') {
          *param_1 = puVar3 + 2;
          pcVar10 = "operator|";
          goto LAB_0012edb1;
        }
        if (cVar1 != 'o') break;
        *param_1 = puVar3 + 2;
        pcVar10 = "operator||";
      }
      goto LAB_0012ee22;
    }
    break;
  case 0x70:
    if (1 < uVar9) {
      lVar7 = 0;
      switch(puVar3[1]) {
      case 0x4c:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator+=";
        break;
      default:
        goto switchD_0012e48d_caseD_62;
      case 0x6c:
      case 0x73:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator+";
        goto LAB_0012edb1;
      case 0x6d:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator->*";
        goto LAB_0012edf7;
      case 0x70:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator++";
        break;
      case 0x74:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator->";
      }
      goto LAB_0012ee22;
    }
    break;
  case 0x71:
    if ((1 < uVar9) && (puVar3[1] == 'u')) {
      *param_1 = puVar3 + 2;
      plVar4 = (long *)param_1[0x266];
      lVar5 = plVar4[1];
      plVar6 = plVar4;
      if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_0012ee44;
        *plVar6 = (long)plVar4;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar5 = 0;
      }
      plVar6[1] = lVar5 + 0x20;
      lVar7 = (long)plVar6 + lVar5 + 0x10;
      *(undefined4 *)((long)plVar6 + lVar5 + 0x18) = 0x1010107;
      *(undefined ***)((long)plVar6 + lVar5 + 0x10) = &PTR_LAB_0013e688;
      *(char **)((long)plVar6 + lVar5 + 0x20) = "operator?";
      *(char **)((long)plVar6 + lVar5 + 0x28) = "";
      goto switchD_0012e48d_caseD_62;
    }
    break;
  case 0x72:
    if (1 < uVar9) {
      lVar7 = 0;
      switch(puVar3[1]) {
      case 0x4d:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator%=";
        break;
      default:
        goto switchD_0012e48d_caseD_62;
      case 0x53:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator>>=";
        goto LAB_0012edf7;
      case 0x6d:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator%";
        goto LAB_0012edb1;
      case 0x73:
        *param_1 = puVar3 + 2;
        pcVar10 = "operator>>";
      }
      goto LAB_0012ee22;
    }
    break;
  case 0x73:
    if ((1 < uVar9) && (puVar3[1] == 's')) {
      *param_1 = puVar3 + 2;
      plVar4 = (long *)param_1[0x266];
      lVar5 = plVar4[1];
      plVar6 = plVar4;
      if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_0012ee44;
        *plVar6 = (long)plVar4;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar5 = 0;
      }
      plVar6[1] = lVar5 + 0x20;
      lVar7 = (long)plVar6 + lVar5 + 0x10;
      *(undefined4 *)((long)plVar6 + lVar5 + 0x18) = 0x1010107;
      *(undefined ***)((long)plVar6 + lVar5 + 0x10) = &PTR_LAB_0013e688;
      *(char **)((long)plVar6 + lVar5 + 0x20) = "operator<=>";
      *(char **)((long)plVar6 + lVar5 + 0x28) = "";
      goto switchD_0012e48d_caseD_62;
    }
    break;
  case 0x76:
    if ((1 < uVar9) && (0xfffffff5 < (int)(char)puVar3[1] - 0x3aU)) {
      *param_1 = puVar3 + 2;
      lVar5 = FUN_0012e110(param_1);
      if (lVar5 != 0) {
        plVar4 = (long *)param_1[0x266];
        lVar8 = plVar4[1];
        plVar6 = plVar4;
        if (lVar8 - 0xfd0U < 0xfffffffffffff010) {
          plVar6 = malloc(0x1000);
          if (plVar6 == (long *)0x0) goto LAB_0012ee44;
          *plVar6 = (long)plVar4;
          plVar6[1] = 0;
          param_1[0x266] = plVar6;
          lVar8 = 0;
        }
        plVar6[1] = lVar8 + 0x20;
        lVar7 = (long)plVar6 + lVar8 + 0x10;
        *(undefined4 *)((long)plVar6 + lVar8 + 0x18) = 0x1010104;
        *(undefined ***)((long)plVar6 + lVar8 + 0x10) = &PTR_LAB_0013f338;
        *(long *)((long)plVar6 + lVar8 + 0x20) = lVar5;
        goto switchD_0012e48d_caseD_62;
      }
    }
  }
LAB_0012ecb2:
  lVar7 = 0;
switchD_0012e48d_caseD_62:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar7;
}


// ==== FUN_0012eef0 @ 0012eef0

long FUN_0012eef0(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_0012ef90 @ 0012ef90

long FUN_0012ef90(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_0012f030 @ 0012f030

long FUN_0012f030(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010104;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013f338;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_0012f0c0 @ 0012f0c0

long FUN_0012f0c0(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_0012f160 @ 0012f160

long FUN_0012f160(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010113;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_0013f3a8;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_0012f1f0 @ 0012f1f0

long FUN_0012f1f0(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_0012f290 @ 0012f290

long FUN_0012f290(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_0012f330 @ 0012f330

long FUN_0012f330(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_00130be0 @ 00130be0

char * FUN_00130be0(char *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  char *pcVar4;
  
  pcVar2 = param_1;
  if (param_1 != param_2) {
    iVar3 = (int)*param_1;
    if (iVar3 == 0x5f) {
      if (param_1 + 1 != param_2) {
        cVar1 = param_1[1];
        if (0xfffffff5 < (int)cVar1 - 0x3aU) {
          return param_1 + 2;
        }
        if (cVar1 == '_') {
          pcVar4 = param_1 + 2;
          while (pcVar4 != param_2) {
            cVar1 = *pcVar4;
            pcVar4 = pcVar4 + 1;
            if ((int)cVar1 - 0x3aU < 0xfffffff6) {
              if (cVar1 == '_') {
                param_1 = pcVar4;
              }
              return param_1;
            }
          }
        }
      }
    }
    else {
      while (0xfffffff5 < iVar3 - 0x3aU) {
        param_1 = param_1 + 1;
        if (param_1 == param_2) {
          return param_2;
        }
        iVar3 = (int)*param_1;
      }
    }
  }
  return pcVar2;
}


// ==== FUN_00130c60 @ 00130c60

long FUN_00130c60(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x20;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010118;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_0013fbf8;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_001318f0 @ 001318f0

void FUN_001318f0(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  long *plVar2;
  void *pvVar3;
  void *pvVar4;
  ulong uVar5;
  long lVar6;
  size_t __n;
  
  plVar2 = *(long **)(param_1 + 0x10);
  (**(code **)(*plVar2 + 0x20))(plVar2);
  if (*(char *)((long)plVar2 + 9) != '\x01') {
    (**(code **)(*plVar2 + 0x28))(plVar2,param_2);
  }
  lVar6 = param_2[1];
  uVar1 = lVar6 + 2;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar4 = (void *)*param_2;
  }
  else {
    uVar5 = param_2[2] * 2;
    if (uVar5 < uVar1) {
      uVar5 = uVar1;
    }
    param_2[2] = uVar5;
    pvVar4 = realloc((void *)*param_2,uVar5);
    *param_2 = pvVar4;
    if (pvVar4 == (void *)0x0) goto LAB_00131a26;
    lVar6 = param_2[1];
  }
  *(undefined2 *)((long)pvVar4 + lVar6) = 0x2820;
  lVar6 = param_2[1] + 2;
  param_2[1] = lVar6;
  pvVar4 = *(void **)(param_1 + 0x18);
  __n = *(long *)(param_1 + 0x20) - (long)pvVar4;
  if (__n != 0) {
    uVar1 = lVar6 + __n;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar3 = (void *)*param_2;
    }
    else {
      uVar5 = param_2[2] * 2;
      if (uVar5 < uVar1) {
        uVar5 = uVar1;
      }
      param_2[2] = uVar5;
      pvVar3 = realloc((void *)*param_2,uVar5);
      *param_2 = pvVar3;
      if (pvVar3 == (void *)0x0) goto LAB_00131a26;
      lVar6 = param_2[1];
    }
    memmove((void *)(lVar6 + (long)pvVar3),pvVar4,__n);
    lVar6 = __n + param_2[1];
    param_2[1] = lVar6;
  }
  uVar1 = lVar6 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar4 = (void *)*param_2;
  }
  else {
    uVar5 = param_2[2] * 2;
    if (uVar5 < uVar1) {
      uVar5 = uVar1;
    }
    param_2[2] = uVar5;
    pvVar4 = realloc((void *)*param_2,uVar5);
    *param_2 = pvVar4;
    if (pvVar4 == (void *)0x0) {
LAB_00131a26:
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    lVar6 = param_2[1];
  }
  *(undefined1 *)((long)pvVar4 + lVar6) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_00131a40 @ 00131a40

long FUN_00131a40(long *param_1)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  long *plVar4;
  char *pcVar5;
  long lVar6;
  long lVar7;
  long lVar8;
  long *plVar9;
  uint uVar10;
  long lVar11;
  long lVar12;
  long in_FS_OFFSET;
  undefined1 auVar13 [16];
  undefined1 local_50;
  long local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar3 = (char *)*param_1;
  pcVar5 = (char *)param_1[1];
  uVar10 = 0;
  if ((pcVar3 != pcVar5) && (*pcVar3 == 'r')) {
    pcVar3 = pcVar3 + 1;
    *param_1 = (long)pcVar3;
    uVar10 = 4;
  }
  if (pcVar3 == pcVar5) {
LAB_00131aac:
    pcVar3 = pcVar5;
  }
  else {
    if (*pcVar3 == 'V') {
      pcVar3 = pcVar3 + 1;
      *param_1 = (long)pcVar3;
      uVar10 = uVar10 | 2;
    }
    if (pcVar3 == pcVar5) goto LAB_00131aac;
    if (*pcVar3 == 'K') {
      *param_1 = (long)(pcVar3 + 1);
      uVar10 = uVar10 | 1;
      pcVar3 = pcVar3 + 1;
    }
  }
  if (((ulong)((long)pcVar5 - (long)pcVar3) < 2) || (*pcVar3 != 'D')) {
LAB_00131b6f:
    lVar11 = 0;
  }
  else {
    cVar2 = pcVar3[1];
    if (cVar2 == 'O') {
      *param_1 = (long)(pcVar3 + 2);
      lVar6 = FUN_00125e60(param_1);
      if (((lVar6 == 0) || (pcVar5 = (char *)*param_1, pcVar5 == (char *)param_1[1])) ||
         (*pcVar5 != 'E')) goto LAB_00131d70;
      *param_1 = (long)(pcVar5 + 1);
      plVar9 = (long *)param_1[0x266];
      lVar12 = plVar9[1];
      plVar4 = plVar9;
      if (lVar12 - 0xfd0U < 0xfffffffffffff010) {
        plVar4 = malloc(0x1000);
        if (plVar4 == (long *)0x0) goto LAB_00131f1e;
        *plVar4 = (long)plVar9;
        plVar4[1] = 0;
        param_1[0x266] = (long)plVar4;
        lVar12 = 0;
      }
      plVar4[1] = lVar12 + 0x20;
      lVar11 = (long)plVar4 + lVar12 + 0x10;
      *(undefined4 *)((long)plVar4 + lVar12 + 0x18) = 0x1010110;
      *(undefined ***)((long)plVar4 + lVar12 + 0x10) = &PTR_LAB_00140058;
      *(long *)((long)plVar4 + lVar12 + 0x20) = lVar6;
    }
    else if (cVar2 == 'w') {
      pcVar3 = pcVar3 + 2;
      *param_1 = (long)pcVar3;
      lVar6 = param_1[3];
      lVar12 = param_1[2];
      if (pcVar3 == pcVar5) goto LAB_00131d45;
      while (*pcVar3 != 'E') {
LAB_00131d45:
        do {
          local_40 = FUN_00121da0(param_1);
          if (local_40 == 0) goto LAB_00131d70;
          FUN_00123d20(param_1 + 2,&local_40);
          pcVar3 = (char *)*param_1;
        } while (pcVar3 == (char *)param_1[1]);
      }
      *param_1 = (long)(pcVar3 + 1);
      lVar6 = (lVar6 - lVar12 >> 3) * 8;
      auVar13 = FUN_0012da70(param_1,param_1[2] + lVar6,param_1[3]);
      param_1[3] = lVar6 + param_1[2];
      plVar9 = (long *)param_1[0x266];
      lVar6 = plVar9[1];
      plVar4 = plVar9;
      if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
        plVar4 = malloc(0x1000);
        if (plVar4 == (long *)0x0) {
LAB_00131f1e:
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        *plVar4 = (long)plVar9;
        plVar4[1] = 0;
        param_1[0x266] = (long)plVar4;
        lVar6 = 0;
      }
      plVar4[1] = lVar6 + 0x20;
      lVar11 = (long)plVar4 + lVar6 + 0x10;
      *(undefined4 *)((long)plVar4 + lVar6 + 0x18) = 0x1010111;
      *(undefined ***)((long)plVar4 + lVar6 + 0x10) = &PTR_LAB_001400c8;
      *(long *)((long)plVar4 + lVar6 + 0x20) = auVar13._0_8_;
      *(long *)((long)plVar4 + lVar6 + 0x28) = auVar13._8_8_;
    }
    else {
      if (cVar2 != 'o') goto LAB_00131b6f;
      *param_1 = (long)(pcVar3 + 2);
      plVar9 = (long *)param_1[0x266];
      lVar6 = plVar9[1];
      plVar4 = plVar9;
      if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
        plVar4 = malloc(0x1000);
        if (plVar4 == (long *)0x0) goto LAB_00131f1e;
        *plVar4 = (long)plVar9;
        plVar4[1] = 0;
        param_1[0x266] = (long)plVar4;
        lVar6 = 0;
      }
      plVar4[1] = lVar6 + 0x20;
      lVar11 = (long)plVar4 + lVar6 + 0x10;
      *(undefined4 *)((long)plVar4 + lVar6 + 0x18) = 0x1010107;
      *(undefined ***)((long)plVar4 + lVar6 + 0x10) = &PTR_LAB_0013e688;
      *(char **)((long)plVar4 + lVar6 + 0x20) = "noexcept";
      *(char **)((long)plVar4 + lVar6 + 0x28) = "";
    }
  }
  pcVar5 = (char *)*param_1;
  pcVar3 = (char *)param_1[1];
  if (((1 < (ulong)((long)pcVar3 - (long)pcVar5)) && (*pcVar5 == 'D')) && (pcVar5[1] == 'x')) {
    pcVar5 = pcVar5 + 2;
    *param_1 = (long)pcVar5;
  }
  if ((pcVar5 != pcVar3) && (*pcVar5 == 'F')) {
    pcVar1 = pcVar5 + 1;
    *param_1 = (long)pcVar1;
    if ((pcVar1 != pcVar3) && (*pcVar1 == 'Y')) {
      *param_1 = (long)(pcVar5 + 2);
    }
    lVar6 = FUN_00121da0(param_1);
    if (lVar6 != 0) {
      lVar12 = param_1[3];
      lVar7 = param_1[2];
      do {
        while( true ) {
          pcVar5 = (char *)*param_1;
          if (pcVar5 == (char *)param_1[1]) break;
          if (*pcVar5 != 'v') {
            if (*pcVar5 != 'E') break;
            lVar8 = 1;
            local_50 = 0;
LAB_00131e59:
            *param_1 = (long)(pcVar5 + lVar8);
            lVar12 = (lVar12 - lVar7 >> 3) * 8;
            auVar13 = FUN_0012da70(param_1,param_1[2] + lVar12,param_1[3]);
            param_1[3] = lVar12 + param_1[2];
            plVar9 = (long *)param_1[0x266];
            lVar12 = plVar9[1];
            if (lVar12 - 0xfb0U < 0xfffffffffffff010) {
              plVar4 = malloc(0x1000);
              if (plVar4 == (long *)0x0) goto LAB_00131f1e;
              *plVar4 = (long)plVar9;
              plVar4[1] = 0;
              param_1[0x266] = (long)plVar4;
              lVar12 = 0;
              plVar9 = plVar4;
            }
            plVar9[1] = lVar12 + 0x40;
            lVar7 = (long)plVar9 + lVar12 + 0x10;
            *(undefined4 *)((long)plVar9 + lVar12 + 0x18) = 0x1000f;
            *(undefined ***)((long)plVar9 + lVar12 + 0x10) = &PTR_LAB_00140138;
            *(long *)((long)plVar9 + lVar12 + 0x20) = lVar6;
            *(long *)((long)plVar9 + lVar12 + 0x28) = auVar13._0_8_;
            *(long *)((long)plVar9 + lVar12 + 0x30) = auVar13._8_8_;
            *(uint *)((long)plVar9 + lVar12 + 0x38) = uVar10;
            *(undefined1 *)((long)plVar9 + lVar12 + 0x3c) = local_50;
            *(long *)((long)plVar9 + lVar12 + 0x40) = lVar11;
            goto LAB_00131d72;
          }
          *param_1 = (long)(pcVar5 + 1);
        }
        if (1 < (ulong)(param_1[1] - (long)pcVar5)) {
          if (*pcVar5 == 'O') {
            if (pcVar5[1] == 'E') {
              local_50 = 2;
              goto LAB_00131e50;
            }
          }
          else if ((*pcVar5 == 'R') && (pcVar5[1] == 'E')) {
            local_50 = 1;
LAB_00131e50:
            lVar8 = 2;
            goto LAB_00131e59;
          }
        }
        local_40 = FUN_00121da0(param_1);
        if (local_40 == 0) break;
        FUN_00123d20(param_1 + 2,&local_40);
      } while( true );
    }
  }
LAB_00131d70:
  lVar7 = 0;
LAB_00131d72:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar7;
}


// ==== FUN_00131f30 @ 00131f30

long FUN_00131f30(long *param_1)

{
  char *pcVar1;
  undefined1 uVar2;
  char cVar3;
  char cVar4;
  undefined2 uVar5;
  char *pcVar6;
  long *plVar7;
  char *pcVar8;
  long lVar9;
  long *plVar10;
  long lVar11;
  char *pcVar12;
  char *pcVar13;
  ulong uVar14;
  ulong uVar15;
  long lVar16;
  long lVar17;
  char *pcVar18;
  char *pcVar19;
  char *pcVar20;
  char *pcVar21;
  uint uVar22;
  char *local_40;
  
  pcVar8 = (char *)*param_1;
  pcVar6 = (char *)param_1[1];
  uVar22 = 0;
  if (pcVar8 != pcVar6) {
    if (*pcVar8 == 'r') {
      pcVar8 = pcVar8 + 1;
      *param_1 = (long)pcVar8;
      uVar22 = 4;
    }
    else if (*pcVar8 == 'U') {
      pcVar12 = pcVar8 + 1;
      *param_1 = (long)pcVar12;
      if (pcVar6 == pcVar12) {
        return 0;
      }
      if ((byte)(*pcVar12 - 0x3aU) < 0xf6) {
        return 0;
      }
      lVar9 = 0;
      uVar15 = 0;
      do {
        uVar14 = uVar15;
        lVar11 = lVar9;
        pcVar12 = pcVar8 + lVar11 + 2;
        *param_1 = (long)pcVar12;
        lVar17 = (long)pcVar8[lVar11 + 1];
        uVar15 = (lVar17 + uVar14 * 10) - 0x30;
        if (pcVar12 == pcVar6) {
          pcVar12 = pcVar6;
          goto LAB_001320b2;
        }
        lVar9 = lVar11 + 1;
      } while ((byte)(*pcVar12 - 0x30U) < 10);
      pcVar12 = pcVar8 + lVar11 + 2;
LAB_001320b2:
      if ((ulong)((long)pcVar6 - (long)pcVar12) < uVar15) {
        return 0;
      }
      lVar9 = lVar17 + uVar14 * 10;
      pcVar21 = pcVar8 + lVar11 + lVar9 + -0x2e;
      *param_1 = (long)pcVar21;
      if (uVar15 == 0) {
        return 0;
      }
      if ((((((8 < uVar15) && (*pcVar12 == 'o')) && (pcVar12[1] == 'b')) &&
           ((pcVar12[2] == 'j' && (pcVar12[3] == 'c')))) &&
          ((pcVar12[4] == 'p' && ((pcVar12[5] == 'r' && (pcVar12[6] == 'o')))))) &&
         ((pcVar12[7] == 't' && (pcVar12[8] == 'o')))) {
        pcVar1 = pcVar12 + 9;
        *param_1 = (long)pcVar1;
        param_1[1] = (long)pcVar21;
        if ((pcVar21 != pcVar1) && (0xf5 < (byte)(*pcVar1 - 0x3aU))) {
          pcVar18 = pcVar8 + lVar11 + lVar9 + -0x2e;
          pcVar13 = pcVar12 + 10;
          lVar9 = 0;
          pcVar20 = (char *)0x0;
          do {
            pcVar19 = pcVar20;
            lVar16 = lVar9;
            *param_1 = (long)pcVar13;
            cVar3 = pcVar13[-1];
            pcVar20 = (char *)((long)cVar3 + (long)pcVar19 * 10 + -0x30);
            if (pcVar21 == pcVar13) {
              local_40 = pcVar21;
              goto LAB_0013226f;
            }
            cVar4 = *pcVar13;
            lVar9 = lVar16 + -1;
            pcVar13 = pcVar13 + 1;
          } while ((byte)(cVar4 - 0x30U) < 10);
          pcVar18 = pcVar12 + (9 - lVar9);
          local_40 = pcVar1 + -lVar9;
LAB_0013226f:
          if (pcVar20 <= pcVar8 + lVar11 + (uVar14 * 10 - (long)pcVar18) + lVar17 + -0x2e) {
            param_1[1] = (long)pcVar6;
            *param_1 = (long)pcVar21;
            if (pcVar20 == (char *)0x0) {
              return 0;
            }
            lVar9 = FUN_00131f30(param_1);
            if (lVar9 == 0) {
              return 0;
            }
            plVar7 = (long *)param_1[0x266];
            lVar11 = plVar7[1];
            plVar10 = plVar7;
            if (lVar11 - 0xfc0U < 0xfffffffffffff010) {
              plVar10 = malloc(0x1000);
              if (plVar10 == (long *)0x0) goto LAB_00132353;
              *plVar10 = (long)plVar7;
              plVar10[1] = 0;
              param_1[0x266] = (long)plVar10;
              lVar11 = 0;
            }
            plVar10[1] = lVar11 + 0x30;
            *(undefined4 *)((long)plVar10 + lVar11 + 0x18) = 0x101010a;
            *(undefined ***)((long)plVar10 + lVar11 + 0x10) = &PTR_LAB_001401a8;
            *(long *)((long)plVar10 + lVar11 + 0x20) = lVar9;
            *(char **)((long)plVar10 + lVar11 + 0x28) = local_40;
            *(char **)((long)plVar10 + lVar11 + 0x30) =
                 pcVar12 + (((long)cVar3 + (long)pcVar19 * 10) - lVar16) + -0x26;
            return (long)plVar10 + lVar11 + 0x10;
          }
        }
        param_1[1] = (long)pcVar6;
        *param_1 = (long)pcVar21;
        return 0;
      }
      lVar9 = FUN_00131f30(param_1);
      if (lVar9 == 0) {
        return 0;
      }
      plVar7 = (long *)param_1[0x266];
      lVar11 = plVar7[1];
      plVar10 = plVar7;
      if (0xfffffffffffff00f < lVar11 - 0xfc0U) {
LAB_00132235:
        plVar10[1] = lVar11 + 0x30;
        *(undefined4 *)((long)plVar10 + lVar11 + 0x18) = 0x1010102;
        *(undefined ***)((long)plVar10 + lVar11 + 0x10) = &PTR_LAB_00140218;
        *(long *)((long)plVar10 + lVar11 + 0x20) = lVar9;
        *(char **)((long)plVar10 + lVar11 + 0x28) = pcVar12;
        *(char **)((long)plVar10 + lVar11 + 0x30) = pcVar21;
        return (long)plVar10 + lVar11 + 0x10;
      }
      plVar10 = malloc(0x1000);
      if (plVar10 != (long *)0x0) {
        *plVar10 = (long)plVar7;
        plVar10[1] = 0;
        param_1[0x266] = (long)plVar10;
        lVar11 = 0;
        goto LAB_00132235;
      }
      goto LAB_00132353;
    }
  }
  if (pcVar8 != pcVar6) {
    if (*pcVar8 == 'V') {
      pcVar8 = pcVar8 + 1;
      *param_1 = (long)pcVar8;
      uVar22 = uVar22 | 2;
    }
    if ((pcVar8 != pcVar6) && (*pcVar8 == 'K')) {
      *param_1 = (long)(pcVar8 + 1);
      uVar22 = uVar22 | 1;
    }
  }
  lVar9 = FUN_00121da0(param_1);
  if (lVar9 == 0) {
    return 0;
  }
  if (uVar22 == 0) {
    return lVar9;
  }
  plVar7 = (long *)param_1[0x266];
  lVar11 = plVar7[1];
  plVar10 = plVar7;
  if (lVar11 - 0xfd0U < 0xfffffffffffff010) {
    plVar10 = malloc(0x1000);
    if (plVar10 == (long *)0x0) {
LAB_00132353:
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar10 = (long)plVar7;
    plVar10[1] = 0;
    param_1[0x266] = (long)plVar10;
    lVar11 = 0;
  }
  plVar10[1] = lVar11 + 0x20;
  uVar5 = *(undefined2 *)(lVar9 + 9);
  uVar2 = *(undefined1 *)(lVar9 + 0xb);
  *(undefined1 *)((long)plVar10 + lVar11 + 0x18) = 3;
  *(undefined2 *)((long)plVar10 + lVar11 + 0x19) = uVar5;
  *(undefined1 *)((long)plVar10 + lVar11 + 0x1b) = uVar2;
  *(undefined ***)((long)plVar10 + lVar11 + 0x10) = &PTR_LAB_00140288;
  *(uint *)((long)plVar10 + lVar11 + 0x1c) = uVar22;
  *(long *)((long)plVar10 + lVar11 + 0x20) = lVar9;
  return (long)plVar10 + lVar11 + 0x10;
}


// ==== FUN_00132360 @ 00132360

long FUN_00132360(long param_1,char *param_2)

{
  long *plVar1;
  long *plVar2;
  size_t sVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar2 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar2 = malloc(0x1000);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar2 = (long)plVar1;
    plVar2[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar2;
    lVar4 = 0;
  }
  plVar2[1] = lVar4 + 0x20;
  sVar3 = strlen(param_2);
  *(undefined4 *)((long)plVar2 + lVar4 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar2 + lVar4 + 0x10) = &PTR_LAB_0013e688;
  *(char **)((long)plVar2 + lVar4 + 0x20) = param_2;
  *(char **)((long)plVar2 + lVar4 + 0x28) = param_2 + sVar3;
  return (long)plVar2 + lVar4 + 0x10;
}


// ==== FUN_00132400 @ 00132400

long FUN_00132400(long *param_1)

{
  byte *pbVar1;
  char *pcVar2;
  byte bVar3;
  char *pcVar4;
  long *plVar5;
  byte *pbVar6;
  byte *pbVar7;
  long *plVar8;
  long lVar9;
  long lVar10;
  long lVar11;
  long lVar12;
  byte *pbVar13;
  long in_FS_OFFSET;
  long local_38;
  long local_30;
  long local_28;
  
  local_28 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar4 = (char *)*param_1;
  pbVar13 = (byte *)param_1[1];
  if ((((ulong)((long)pbVar13 - (long)pcVar4) < 2) || (*pcVar4 != 'D')) || (pcVar4[1] != 'v'))
  goto LAB_001326db;
  pbVar1 = (byte *)(pcVar4 + 2);
  *param_1 = (long)pbVar1;
  if (pbVar13 == pbVar1) {
LAB_001325fa:
    lVar10 = FUN_00125e60(param_1);
    if (((lVar10 != 0) && (pcVar4 = (char *)*param_1, pcVar4 != (char *)param_1[1])) &&
       (*pcVar4 == '_')) {
      *param_1 = (long)(pcVar4 + 1);
      lVar11 = FUN_00121da0(param_1);
      if (lVar11 != 0) {
        plVar5 = (long *)param_1[0x266];
        lVar12 = plVar5[1];
        plVar8 = plVar5;
        if (lVar12 - 0xfd0U < 0xfffffffffffff010) {
          plVar8 = malloc(0x1000);
          if (plVar8 == (long *)0x0) {
LAB_001326f9:
                    /* WARNING: Subroutine does not return */
            FUN_00120930();
          }
          *plVar8 = (long)plVar5;
          plVar8[1] = 0;
          param_1[0x266] = (long)plVar8;
          lVar12 = 0;
        }
        plVar8[1] = lVar12 + 0x20;
        lVar9 = (long)plVar8 + lVar12 + 0x10;
        *(undefined4 *)((long)plVar8 + lVar12 + 0x18) = 0x1010119;
        *(undefined ***)((long)plVar8 + lVar12 + 0x10) = &PTR_LAB_00140368;
        *(long *)((long)plVar8 + lVar12 + 0x20) = lVar11;
        *(long *)((long)plVar8 + lVar12 + 0x28) = lVar10;
        goto LAB_001326dd;
      }
    }
  }
  else {
    bVar3 = *pbVar1;
    if ((char)bVar3 < '1') goto LAB_001325fa;
    if (bVar3 < 0x3a) {
      pbVar6 = (byte *)(pcVar4 + 3);
      do {
        pbVar7 = pbVar6;
        *param_1 = (long)pbVar7;
        if (pbVar7 == pbVar13) goto LAB_0013248f;
        pbVar6 = pbVar7 + 1;
      } while (0xfffffff5 < (int)(char)*pbVar7 - 0x3aU);
      pbVar13 = pbVar7;
LAB_0013248f:
      plVar5 = (long *)param_1[0x266];
      lVar10 = plVar5[1];
      plVar8 = plVar5;
      if (lVar10 - 0xfd0U < 0xfffffffffffff010) {
        plVar8 = malloc(0x1000);
        if (plVar8 == (long *)0x0) goto LAB_001326f9;
        *plVar8 = (long)plVar5;
        plVar8[1] = 0;
        param_1[0x266] = (long)plVar8;
        lVar10 = 0;
      }
      plVar8[1] = lVar10 + 0x20;
      local_30 = (long)plVar8 + lVar10 + 0x10;
      *(undefined4 *)((long)plVar8 + lVar10 + 0x18) = 0x1010107;
      *(undefined ***)((long)plVar8 + lVar10 + 0x10) = &PTR_LAB_0013e688;
      *(byte **)((long)plVar8 + lVar10 + 0x20) = pbVar1;
      *(byte **)((long)plVar8 + lVar10 + 0x28) = pbVar13;
      pcVar4 = (char *)*param_1;
      if ((pcVar4 != (char *)param_1[1]) && (*pcVar4 == '_')) {
        pcVar2 = pcVar4 + 1;
        *param_1 = (long)pcVar2;
        if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'p')) {
          *param_1 = (long)(pcVar4 + 2);
          lVar9 = FUN_00133480(param_1,&local_30);
          goto LAB_001326dd;
        }
        local_38 = FUN_00121da0(param_1);
        if (local_38 != 0) {
          lVar9 = FUN_00133510(param_1,&local_38,&local_30);
          goto LAB_001326dd;
        }
      }
    }
    else {
      if (bVar3 != 0x5f) goto LAB_001325fa;
      *param_1 = (long)(pcVar4 + 3);
      lVar10 = FUN_00121da0(param_1);
      if (lVar10 != 0) {
        plVar5 = (long *)param_1[0x266];
        lVar11 = plVar5[1];
        plVar8 = plVar5;
        if (lVar11 - 0xfd0U < 0xfffffffffffff010) {
          plVar8 = malloc(0x1000);
          if (plVar8 == (long *)0x0) goto LAB_001326f9;
          *plVar8 = (long)plVar5;
          plVar8[1] = 0;
          param_1[0x266] = (long)plVar8;
          lVar11 = 0;
        }
        plVar8[1] = lVar11 + 0x20;
        lVar9 = (long)plVar8 + lVar11 + 0x10;
        *(undefined4 *)((long)plVar8 + lVar11 + 0x18) = 0x1010119;
        *(undefined ***)((long)plVar8 + lVar11 + 0x10) = &PTR_LAB_00140368;
        *(long *)((long)plVar8 + lVar11 + 0x20) = lVar10;
        *(undefined8 *)((long)plVar8 + lVar11 + 0x28) = 0;
        goto LAB_001326dd;
      }
    }
  }
LAB_001326db:
  lVar9 = 0;
LAB_001326dd:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar9;
}


// ==== FUN_00132710 @ 00132710

long FUN_00132710(undefined8 *param_1)

{
  char cVar1;
  char *pcVar2;
  long *plVar3;
  long lVar4;
  long lVar5;
  long *plVar6;
  char *pcVar7;
  char *pcVar8;
  
  pcVar2 = (char *)*param_1;
  if (((ulong)(param_1[1] - (long)pcVar2) < 2) || (*pcVar2 != 'T')) {
LAB_00132755:
    lVar4 = FUN_00122fc0(param_1,0);
    return lVar4;
  }
  cVar1 = pcVar2[1];
  if (cVar1 == 'e') {
    pcVar7 = "enum";
    pcVar8 = "";
  }
  else if (cVar1 == 's') {
    pcVar7 = "struct";
    pcVar8 = "";
  }
  else {
    if (cVar1 != 'u') goto LAB_00132755;
    pcVar7 = "union";
    pcVar8 = "";
  }
  *param_1 = pcVar2 + 2;
  lVar5 = FUN_00122fc0(param_1,0);
  lVar4 = 0;
  if (lVar5 != 0) {
    if (pcVar7 == pcVar8) {
      lVar4 = lVar5;
    }
    else {
      plVar3 = (long *)param_1[0x266];
      lVar4 = plVar3[1];
      plVar6 = plVar3;
      if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_00120930();
        }
        *plVar6 = (long)plVar3;
        plVar6[1] = 0;
        param_1[0x266] = plVar6;
        lVar4 = 0;
      }
      plVar6[1] = lVar4 + 0x30;
      *(undefined4 *)((long)plVar6 + lVar4 + 0x18) = 0x1010106;
      *(undefined ***)((long)plVar6 + lVar4 + 0x10) = &PTR_LAB_001404b8;
      *(char **)((long)plVar6 + lVar4 + 0x20) = pcVar7;
      *(char **)((long)plVar6 + lVar4 + 0x28) = pcVar8;
      *(long *)((long)plVar6 + lVar4 + 0x30) = lVar5;
      lVar4 = (long)plVar6 + lVar4 + 0x10;
    }
  }
  return lVar4;
}


// ==== FUN_00132840 @ 00132840

long FUN_00132840(long param_1,long *param_2)

{
  undefined1 uVar1;
  long *plVar2;
  long lVar3;
  long *plVar4;
  long lVar5;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar2[1];
  plVar4 = plVar2;
  if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar2;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x20;
  lVar3 = *param_2;
  uVar1 = *(undefined1 *)(lVar3 + 9);
  *(undefined1 *)((long)plVar4 + lVar5 + 0x18) = 0xb;
  *(undefined1 *)((long)plVar4 + lVar5 + 0x19) = uVar1;
  *(undefined2 *)((long)plVar4 + lVar5 + 0x1a) = 0x101;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_00140528;
  *(long *)((long)plVar4 + lVar5 + 0x20) = lVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_001328d0 @ 001328d0

long FUN_001328d0(long param_1,long *param_2,undefined4 *param_3)

{
  undefined1 uVar1;
  undefined4 uVar2;
  long *plVar3;
  long lVar4;
  long *plVar5;
  long lVar6;
  
  plVar3 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar3[1];
  plVar5 = plVar3;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar3;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  lVar4 = *param_2;
  uVar2 = *param_3;
  uVar1 = *(undefined1 *)(lVar4 + 9);
  *(undefined1 *)((long)plVar5 + lVar6 + 0x18) = 0xc;
  *(undefined1 *)((long)plVar5 + lVar6 + 0x19) = uVar1;
  *(undefined2 *)((long)plVar5 + lVar6 + 0x1a) = 0x101;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_00140598;
  *(long *)((long)plVar5 + lVar6 + 0x20) = lVar4;
  *(undefined4 *)((long)plVar5 + lVar6 + 0x28) = uVar2;
  *(undefined1 *)((long)plVar5 + lVar6 + 0x2c) = 0;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00132980 @ 00132980

long FUN_00132980(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010105;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_00140608;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  *(char **)((long)plVar3 + lVar4 + 0x28) = " complex";
  *(char **)((long)plVar3 + lVar4 + 0x30) = "";
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00132a20 @ 00132a20

long FUN_00132a20(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfc0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x30;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x1010105;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_00140608;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  *(char **)((long)plVar3 + lVar4 + 0x28) = " imaginary";
  *(char **)((long)plVar3 + lVar4 + 0x30) = "";
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_001333f0 @ 001333f0

long FUN_001333f0(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long *plVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar2[1];
  plVar5 = plVar2;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar2;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  uVar3 = *param_2;
  uVar4 = param_2[1];
  *(undefined4 *)((long)plVar5 + lVar6 + 0x18) = 0x1010107;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_0013e688;
  puVar1 = (undefined8 *)((long)plVar5 + lVar6 + 0x20);
  *puVar1 = uVar3;
  puVar1[1] = uVar4;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00133480 @ 00133480

long FUN_00133480(long param_1,undefined8 *param_2)

{
  long *plVar1;
  undefined8 uVar2;
  long *plVar3;
  long lVar4;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar4 = plVar1[1];
  plVar3 = plVar1;
  if (lVar4 - 0xfd0U < 0xfffffffffffff010) {
    plVar3 = malloc(0x1000);
    if (plVar3 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar3 = (long)plVar1;
    plVar3[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar3;
    lVar4 = 0;
  }
  plVar3[1] = lVar4 + 0x20;
  uVar2 = *param_2;
  *(undefined4 *)((long)plVar3 + lVar4 + 0x18) = 0x101011a;
  *(undefined ***)((long)plVar3 + lVar4 + 0x10) = &PTR_LAB_001402f8;
  *(undefined8 *)((long)plVar3 + lVar4 + 0x20) = uVar2;
  return (long)plVar3 + lVar4 + 0x10;
}


// ==== FUN_00133510 @ 00133510

long FUN_00133510(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x20;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x1010119;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_00140368;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_001337a0 @ 001337a0

long FUN_001337a0(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  
  plVar1 = *(long **)(param_1 + 0x1330);
  lVar5 = plVar1[1];
  plVar4 = plVar1;
  if (lVar5 - 0xfd0U < 0xfffffffffffff010) {
    plVar4 = malloc(0x1000);
    if (plVar4 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar4 = (long)plVar1;
    plVar4[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar4;
    lVar5 = 0;
  }
  plVar4[1] = lVar5 + 0x20;
  uVar2 = *param_2;
  uVar3 = *param_3;
  *(undefined4 *)((long)plVar4 + lVar5 + 0x18) = 0x100000e;
  *(undefined ***)((long)plVar4 + lVar5 + 0x10) = &PTR_LAB_001403d8;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x20) = uVar2;
  *(undefined8 *)((long)plVar4 + lVar5 + 0x28) = uVar3;
  return (long)plVar4 + lVar5 + 0x10;
}


// ==== FUN_001339b0 @ 001339b0

long FUN_001339b0(long param_1,undefined8 *param_2,long *param_3)

{
  undefined1 uVar1;
  long *plVar2;
  undefined8 uVar3;
  long lVar4;
  long *plVar5;
  long lVar6;
  
  plVar2 = *(long **)(param_1 + 0x1330);
  lVar6 = plVar2[1];
  plVar5 = plVar2;
  if (lVar6 - 0xfd0U < 0xfffffffffffff010) {
    plVar5 = malloc(0x1000);
    if (plVar5 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00120930();
    }
    *plVar5 = (long)plVar2;
    plVar5[1] = 0;
    *(long **)(param_1 + 0x1330) = plVar5;
    lVar6 = 0;
  }
  plVar5[1] = lVar6 + 0x20;
  uVar3 = *param_2;
  lVar4 = *param_3;
  uVar1 = *(undefined1 *)(lVar4 + 9);
  *(undefined1 *)((long)plVar5 + lVar6 + 0x18) = 0xd;
  *(undefined1 *)((long)plVar5 + lVar6 + 0x19) = uVar1;
  *(undefined2 *)((long)plVar5 + lVar6 + 0x1a) = 0x101;
  *(undefined ***)((long)plVar5 + lVar6 + 0x10) = &PTR_LAB_00140448;
  *(undefined8 *)((long)plVar5 + lVar6 + 0x20) = uVar3;
  *(long *)((long)plVar5 + lVar6 + 0x28) = lVar4;
  return (long)plVar5 + lVar6 + 0x10;
}


// ==== FUN_00134740 @ 00134740

void FUN_00134740(ulong *param_1,uint param_2,char param_3,long param_4,undefined8 param_5)

{
  byte bVar1;
  char cVar2;
  undefined1 *puVar3;
  long lVar4;
  ulong uVar5;
  ulong uVar6;
  ulong uVar7;
  long lVar8;
  ulong uVar9;
  long *plVar10;
  byte bVar11;
  byte bVar12;
  ushort uVar13;
  byte *pbVar14;
  byte *pbVar15;
  ulong uVar16;
  byte *pbVar17;
  long in_FS_OFFSET;
  byte *local_90;
  byte *local_60;
  byte *local_50;
  byte *local_48;
  byte *local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  param_1[2] = 0;
  param_1[3] = 0;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[4] = 0;
  *(undefined4 *)(param_1 + 5) = 3;
  if ((param_2 & 1) == 0) {
    if ((param_2 & 2) == 0) goto LAB_00134c55;
    if ((~param_2 & 0xc) == 0) {
      *(undefined4 *)(param_1 + 5) = 2;
      goto LAB_00134c55;
    }
  }
  else if ((param_2 & 0xe) != 0) goto LAB_00134c55;
  puVar3 = (undefined1 *)FUN_00136390(param_5);
  if (puVar3 != (undefined1 *)0x0) {
    param_1[2] = (ulong)puVar3;
    lVar4 = FUN_00136410(param_5);
    uVar5 = FUN_001363c0(param_5);
    local_48 = puVar3 + 1;
    uVar6 = FUN_00134ff0(&local_48,*puVar3);
    if (uVar6 == 0) {
      uVar6 = uVar5;
    }
    pbVar14 = local_48 + 1;
    uVar13 = (ushort)*local_48;
    if (uVar13 == 0xff) {
      local_60 = (byte *)0x0;
    }
    else {
      bVar12 = 0;
      uVar16 = 0;
      do {
        bVar11 = *pbVar14;
        pbVar14 = pbVar14 + 1;
        uVar16 = uVar16 | (ulong)(bVar11 & 0x7f) << (bVar12 & 0x3f);
        bVar12 = bVar12 + 7;
      } while ((bVar11 & 0x80) != 0);
      local_60 = pbVar14 + uVar16;
    }
    uVar5 = lVar4 + ~uVar5;
    pbVar15 = pbVar14 + 1;
    bVar12 = *pbVar14;
    bVar11 = 0;
    uVar16 = 0;
    do {
      bVar1 = *pbVar15;
      pbVar15 = pbVar15 + 1;
      uVar16 = uVar16 | (ulong)(bVar1 & 0x7f) << (bVar11 & 0x3f);
      bVar11 = bVar11 + 7;
    } while ((bVar1 & 0x80) != 0);
    local_50 = pbVar15;
    local_48 = pbVar15;
    do {
      if (pbVar15 + (uVar16 & 0xffffffff) <= local_50) break;
      uVar7 = FUN_00134ff0(&local_50,bVar12);
      lVar4 = FUN_00134ff0(&local_50,bVar12);
      lVar8 = FUN_00134ff0(&local_50,bVar12);
      bVar11 = 0;
      uVar9 = 0;
      do {
        bVar1 = *local_50;
        local_50 = local_50 + 1;
        uVar9 = uVar9 | (ulong)(bVar1 & 0x7f) << (bVar11 & 0x3f);
        bVar11 = bVar11 + 7;
      } while ((bVar1 & 0x80) != 0);
      if ((uVar7 <= uVar5) && (uVar5 < lVar4 + uVar7)) {
        if (lVar8 == 0) goto LAB_00134c49;
        uVar6 = lVar8 + uVar6;
        if (uVar9 != 0) {
          pbVar15 = pbVar15 + (uVar16 & 0xffffffff) + uVar9 + -1;
          local_90 = (byte *)(param_4 + 0x20);
          bVar12 = (byte)(uVar13 & 0xf);
          goto LAB_001349d0;
        }
        if ((param_2 & 6) != 2) goto LAB_00134c49;
        *param_1 = 0;
        param_1[3] = uVar6;
        *(undefined4 *)(param_1 + 5) = 6;
        goto LAB_00134c55;
      }
    } while (uVar7 <= uVar5);
LAB_00134d53:
    FUN_00120410(param_4);
    if (param_3 != '\0') {
      FUN_001209b0(*(undefined8 *)(param_4 + -0x38));
    }
                    /* WARNING: Subroutine does not return */
    FUN_00120930();
  }
  *(undefined4 *)(param_1 + 5) = 8;
LAB_00134c55:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
LAB_001349d0:
  uVar5 = 0;
  uVar16 = 0;
  pbVar14 = pbVar15;
  do {
    bVar11 = *pbVar14;
    pbVar14 = pbVar14 + 1;
    uVar16 = uVar16 | (ulong)(bVar11 & 0x7f) << ((byte)uVar5 & 0x3f);
    uVar5 = uVar5 + 7;
  } while ((bVar11 & 0x80) != 0);
  uVar7 = -1L << ((byte)uVar5 & 0x3f);
  if (0x3f < uVar5) {
    uVar7 = 0;
  }
  if ((bVar11 & 0x40) == 0) {
    uVar7 = 0;
  }
  uVar16 = uVar16 | uVar7;
  if ((long)uVar16 < 1) {
    if ((long)uVar16 < 0) {
      if (param_3 == '\0') {
        if ((param_2 & 5) != 0) goto LAB_00134c78;
        if ((param_2 & 8) == 0) goto LAB_00134da6;
      }
      else {
        lVar4 = FUN_00120280(param_4);
        pbVar17 = local_90;
        if (lVar4 == 0x434c4e47432b2b01) {
          pbVar17 = *(byte **)(param_4 + -0x58);
        }
        if ((pbVar17 == (byte *)0x0) || (*(long *)(param_4 + -0x50) == 0)) goto LAB_00134d98;
        cVar2 = FUN_00135100(uVar16,local_60,uVar13,*(long *)(param_4 + -0x50),pbVar17);
        if (cVar2 != '\0') {
          if ((param_2 & 1) == 0) goto LAB_00134bb1;
          *param_1 = uVar16;
          param_1[1] = (ulong)pbVar15;
          param_1[3] = uVar6;
          param_1[4] = (ulong)pbVar17;
          *(undefined4 *)(param_1 + 5) = 6;
          goto LAB_00134c55;
        }
      }
    }
    else if ((param_2 & 6) == 2) {
      *param_1 = 0;
      param_1[1] = (ulong)pbVar15;
      param_1[3] = uVar6;
      lVar4 = FUN_00120280(param_4);
      if (lVar4 == 0x434c4e47432b2b01) {
        local_90 = *(byte **)(param_4 + -0x58);
      }
      param_1[4] = (ulong)local_90;
      *(undefined4 *)(param_1 + 5) = 6;
      goto LAB_00134c55;
    }
  }
  else {
    if (((local_60 == (byte *)0x0) || (0xc < bVar12)) || ((0x1c1dU >> bVar12 & 1) == 0))
    goto LAB_00134d53;
    local_40 = local_60 + *(long *)(&DAT_0010df38 + (ulong)(uVar13 & 0xf) * 8) * uVar16;
    plVar10 = (long *)FUN_00134ff0(&local_40,uVar13);
    if (plVar10 == (long *)0x0) {
      if ((param_2 & 5) != 0) {
LAB_00134c78:
        *param_1 = uVar16;
        param_1[1] = (ulong)pbVar15;
        param_1[3] = uVar6;
        lVar4 = FUN_00120280(param_4);
        if (lVar4 == 0x434c4e47432b2b01) {
          local_90 = *(byte **)(param_4 + -0x58);
        }
        param_1[4] = (ulong)local_90;
        *(undefined4 *)(param_1 + 5) = 6;
        goto LAB_00134c55;
      }
      if ((param_2 & 8) == 0) goto LAB_00134d53;
    }
    else if (param_3 != '\0') {
      lVar4 = FUN_00120280(param_4);
      local_40 = local_90;
      if (lVar4 == 0x434c4e47432b2b01) {
        local_40 = *(byte **)(param_4 + -0x58);
      }
      if ((local_40 == (byte *)0x0) || (*(long *)(param_4 + -0x50) == 0)) {
        FUN_00120410(param_4);
        FUN_001209b0(*(undefined8 *)(param_4 + -0x38));
LAB_00134d98:
        FUN_00120410(param_4);
        FUN_001209b0(*(undefined8 *)(param_4 + -0x38));
LAB_00134da6:
        FUN_00120410(param_4);
                    /* WARNING: Subroutine does not return */
        FUN_00120930();
      }
      cVar2 = (**(code **)(*plVar10 + 0x20))(plVar10,*(long *)(param_4 + -0x50),&local_40);
      if (cVar2 != '\0') {
        if ((param_2 & 1) != 0) {
          *param_1 = uVar16;
          param_1[1] = (ulong)pbVar15;
          param_1[3] = uVar6;
          param_1[4] = (ulong)local_40;
          *(undefined4 *)(param_1 + 5) = 6;
          goto LAB_00134c55;
        }
LAB_00134bb1:
        if ((param_2 & 8) == 0) goto LAB_00134d98;
      }
    }
  }
  uVar16 = 0;
  uVar5 = 0;
  pbVar15 = pbVar14;
  do {
    bVar11 = *pbVar15;
    pbVar15 = pbVar15 + 1;
    uVar5 = uVar5 | (ulong)(bVar11 & 0x7f) << ((byte)uVar16 & 0x3f);
    uVar16 = uVar16 + 7;
  } while ((bVar11 & 0x80) != 0);
  uVar7 = -1L << ((byte)uVar16 & 0x3f);
  if (0x3f < uVar16) {
    uVar7 = 0;
  }
  if ((bVar11 & 0x40) == 0) {
    uVar7 = 0;
  }
  if ((uVar5 | uVar7) == 0) goto LAB_00134c49;
  pbVar15 = pbVar14 + (uVar5 | uVar7);
  goto LAB_001349d0;
LAB_00134c49:
  *(undefined4 *)(param_1 + 5) = 8;
  goto LAB_00134c55;
}


// ==== FUN_00134dc0 @ 00134dc0

void FUN_00134dc0(long param_1)

{
  byte bVar1;
  byte bVar2;
  long lVar3;
  char cVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  long lVar7;
  ulong *puVar8;
  byte bVar9;
  byte *pbVar10;
  undefined1 *unaff_RBP;
  undefined **unaff_R15;
  undefined **ppuVar11;
  undefined **local_50;
  long local_48;
  byte *local_40;
  long *local_38;
  
  if (param_1 == 0) {
    FUN_00120410(0);
                    /* WARNING: Subroutine does not return */
    FUN_00120930();
  }
  FUN_00120410();
  cVar4 = FUN_00120290(param_1);
  if (cVar4 == '\0') {
    uVar5 = FUN_001209a0();
    lVar7 = 0;
    uVar6 = FUN_00120920();
  }
  else {
    lVar7 = param_1 + -0x60;
    uVar6 = *(undefined8 *)(param_1 + -0x40);
    uVar5 = *(undefined8 *)(param_1 + -0x38);
    unaff_R15 = (undefined **)(long)*(int *)(param_1 + -0x24);
    unaff_RBP = *(undefined1 **)(param_1 + -0x18);
  }
                    /* try { // try from 00134e23 to 00134e27 has its CatchHandler @ 00134e28 */
  uVar6 = FUN_00120980(uVar6);
                    /* catch(type#1 @ 00000000) { ... } // from try @ 00134e23 with catch @ 00134e28
                        */
  FUN_00120410(uVar6);
  if (cVar4 == '\0') {
LAB_00134f62:
    FUN_00120490();
    FUN_001209b0(uVar5);
  }
  else {
    local_40 = unaff_RBP + 1;
                    /* try { // try from 00134e45 to 00134e4e has its CatchHandler @ 00134fd3 */
    FUN_00134ff0(&local_40,*unaff_RBP);
    bVar1 = *local_40;
    pbVar10 = local_40;
    ppuVar11 = unaff_R15;
    if (bVar1 != 0xff) goto LAB_00134e65;
    do {
      FUN_001209b0(uVar5);
      ppuVar11 = unaff_R15;
LAB_00134e65:
      pbVar10 = pbVar10 + 1;
      bVar9 = 0;
      unaff_R15 = (undefined **)0x0;
      do {
        bVar2 = *pbVar10;
        pbVar10 = pbVar10 + 1;
        unaff_R15 = (undefined **)((ulong)unaff_R15 | (ulong)(bVar2 & 0x7f) << (bVar9 & 0x3f));
        bVar9 = bVar9 + 7;
      } while ((bVar2 & 0x80) != 0);
                    /* try { // try from 00134e9a to 00134e9e has its CatchHandler @ 00134fd1 */
      local_38 = (long *)FUN_00120620();
      lVar3 = *local_38;
    } while (lVar3 == 0);
    local_48 = lVar3 + 0x60;
                    /* try { // try from 00134eb5 to 00134ebe has its CatchHandler @ 00134fcf */
    cVar4 = FUN_00120290();
    pbVar10 = pbVar10 + (long)unaff_R15;
    if ((cVar4 != '\0') && (lVar3 != lVar7)) {
      uVar6 = *(undefined8 *)(lVar3 + 0x10);
                    /* try { // try from 00134ed4 to 00134f1a has its CatchHandler @ 00134fcd */
      lVar7 = FUN_00120280(local_48);
      if (lVar7 == 0x434c4e47432b2b01) {
        lVar7 = *(long *)(lVar3 + 8);
      }
      else {
        lVar7 = lVar3 + 0x80;
      }
      cVar4 = FUN_00135100(ppuVar11,pbVar10,bVar1,uVar6,lVar7,param_1);
      if (cVar4 == '\0') {
        *(int *)(lVar3 + 0x38) = -*(int *)(lVar3 + 0x38);
        *(int *)(local_38 + 1) = (int)local_38[1] + 1;
                    /* try { // try from 00134fa5 to 00134fbd has its CatchHandler @ 00134fcd */
        FUN_00120490();
        FUN_00120490();
        FUN_00120410(local_48);
        uVar6 = FUN_00120550();
        goto LAB_00134fbe;
      }
    }
    unaff_R15 = &PTR_FUN_00140798;
    local_50 = &PTR_FUN_00140798;
                    /* try { // try from 00134f34 to 00134f53 has its CatchHandler @ 00134fbe */
    cVar4 = FUN_00135100(ppuVar11,pbVar10,bVar1,&PTR_PTR_001407b0,&local_50,param_1);
    if (cVar4 != '\0') {
      FUN_00135b70(&local_50);
      goto LAB_00134f62;
    }
  }
                    /* try { // try from 00134f6f to 00134f73 has its CatchHandler @ 00134fbe */
  FUN_00120490();
  puVar8 = (ulong *)FUN_001202b0(8);
  *puVar8 = (ulong)unaff_R15;
                    /* try { // try from 00134f81 to 00134f96 has its CatchHandler @ 00134fbe */
  uVar6 = FUN_00120320(puVar8,&PTR_PTR_001407b0,FUN_00135b70);
LAB_00134fbe:
                    /* catch(type#1 @ 00000000) { ... } // from try @ 00134f34 with catch @ 00134fbe
                       catch(type#1 @ 00000000) { ... } // from try @ 00134f6f with catch @ 00134fbe
                       catch(type#1 @ 00000000) { ... } // from try @ 00134f81 with catch @ 00134fbe
                        */
  FUN_00135b70(&local_50);
                    /* try { // try from 00134fd6 to 00134fda has its CatchHandler @ 00134fe3 */
  FUN_00120490();
                    /* WARNING: Subroutine does not return */
  FUN_00136230(uVar6);
}


// ==== FUN_00134ff0 @ 00134ff0

/* WARNING: Type propagation algorithm not settling */

byte * FUN_00134ff0(long *param_1,uint param_2)

{
  uint *puVar1;
  ulong uVar2;
  byte *pbVar3;
  byte bVar4;
  uint uVar5;
  ulong uVar6;
  ulong uVar7;
  uint *puVar8;
  
  if ((char)param_2 == -1) {
    return (byte *)0x0;
  }
  if (0xc < (param_2 & 0xf)) {
switchD_00135016_caseD_5:
                    /* WARNING: Subroutine does not return */
    abort();
  }
  puVar1 = (uint *)*param_1;
  puVar8 = puVar1;
  switch(param_2 & 0xf) {
  case 0:
  case 4:
  case 0xc:
    pbVar3 = *(byte **)puVar1;
    puVar8 = puVar1 + 2;
    break;
  case 1:
    bVar4 = 0;
    pbVar3 = (byte *)0x0;
    do {
      uVar5 = *puVar8;
      puVar8 = (uint *)((long)puVar8 + 1);
      pbVar3 = (byte *)((ulong)pbVar3 | (ulong)((byte)uVar5 & 0x7f) << (bVar4 & 0x3f));
      bVar4 = bVar4 + 7;
    } while (((byte)uVar5 & 0x80) != 0);
    break;
  case 2:
    pbVar3 = (byte *)(ulong)(ushort)*puVar1;
    goto LAB_00135063;
  case 3:
    pbVar3 = (byte *)(ulong)*puVar1;
    puVar8 = puVar1 + 1;
    break;
  default:
    goto switchD_00135016_caseD_5;
  case 9:
    uVar6 = 0;
    uVar2 = 0;
    do {
      bVar4 = (byte)*puVar8;
      puVar8 = (uint *)((long)puVar8 + 1);
      uVar2 = uVar2 | (ulong)(bVar4 & 0x7f) << ((byte)uVar6 & 0x3f);
      uVar6 = uVar6 + 7;
    } while ((bVar4 & 0x80) != 0);
    uVar7 = -1L << ((byte)uVar6 & 0x3f);
    if (0x3f < uVar6) {
      uVar7 = 0;
    }
    if ((bVar4 & 0x40) == 0) {
      uVar7 = 0;
    }
    pbVar3 = (byte *)(uVar2 | uVar7);
    break;
  case 10:
    pbVar3 = (byte *)(long)(short)(ushort)*puVar1;
LAB_00135063:
    puVar8 = (uint *)((long)puVar1 + 2);
    break;
  case 0xb:
    pbVar3 = (byte *)(long)(int)*puVar1;
    puVar8 = puVar1 + 1;
  }
  uVar5 = param_2 >> 4 & 7;
  if (uVar5 == 0) {
LAB_001350d5:
    if (pbVar3 != (byte *)0x0) {
      if ((param_2 & 0x80) != 0) {
        pbVar3 = *(byte **)pbVar3;
      }
      goto LAB_001350e7;
    }
  }
  else {
    if (uVar5 != 1) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    if (pbVar3 != (byte *)0x0) {
      pbVar3 = pbVar3 + (long)puVar1;
      goto LAB_001350d5;
    }
  }
  pbVar3 = (byte *)0x0;
LAB_001350e7:
  *param_1 = (long)puVar8;
  return pbVar3;
}


// ==== FUN_00135100 @ 00135100

bool FUN_00135100(ulong param_1,long param_2,ulong param_3,undefined8 param_4,long param_5,
                 long param_6)

{
  byte bVar1;
  char cVar2;
  long *plVar3;
  byte bVar4;
  ulong uVar5;
  byte *pbVar6;
  ulong uVar7;
  long in_FS_OFFSET;
  long local_40;
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_2 == 0) {
LAB_0013522a:
    FUN_00120410(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_00120930();
  }
  pbVar6 = (byte *)(~param_1 + param_2);
  bVar4 = 0;
  uVar5 = 0;
  do {
    do {
      bVar1 = *pbVar6;
      pbVar6 = pbVar6 + 1;
      uVar7 = uVar5 | (ulong)(bVar1 & 0x7f) << (bVar4 & 0x3f);
      bVar4 = bVar4 + 7;
      uVar5 = uVar7;
    } while ((bVar1 & 0x80) != 0);
    if (uVar7 == 0) break;
    if ((0xc < (byte)(param_3 & 0xf)) || ((0x1c1dU >> ((byte)param_3 & 0xf) & 1) == 0)) {
      FUN_00120410(param_6);
      FUN_001209b0(*(undefined8 *)(param_6 + -0x38));
      goto LAB_0013522a;
    }
    local_40 = *(long *)(&DAT_0010df38 + (param_3 & 0xf) * 8) * uVar7 + param_2;
    plVar3 = (long *)FUN_00134ff0(&local_40,(byte)param_3);
    local_40 = param_5;
    cVar2 = (**(code **)(*plVar3 + 0x20))(plVar3,param_4,&local_40);
    bVar4 = 0;
    uVar5 = 0;
  } while (cVar2 == '\0');
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar7 == 0;
}


// ==== FUN_00135240 @ 00135240

void * FUN_00135240(size_t param_1)

{
  int iVar1;
  size_t __size;
  long in_FS_OFFSET;
  void *local_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  __size = 1;
  if (param_1 != 0) {
    __size = param_1;
  }
  iVar1 = posix_memalign(&local_18,0x10,__size);
  if (iVar1 != 0) {
    local_18 = (void *)FUN_001352a0(__size);
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_10) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return local_18;
}


// ==== FUN_001352a0 @ 001352a0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ushort * FUN_001352a0(long param_1)

{
  ushort uVar1;
  ushort *puVar2;
  uint uVar3;
  ulong uVar4;
  ushort *puVar5;
  ushort *puVar6;
  ulong uVar7;
  
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00145110);
  if (DAT_00145138 == (ushort *)0x0) {
    DAT_00145138 = &DAT_00145140;
    _DAT_00145140 = 0x800080;
  }
  if (DAT_00145138 != (ushort *)&DAT_00145340) {
    uVar7 = (param_1 + 3U >> 2) + 1;
    puVar2 = DAT_00145138;
    puVar5 = (ushort *)0x0;
    do {
      puVar6 = puVar2;
      uVar1 = puVar6[1];
      if (uVar7 < uVar1) {
        uVar3 = (uint)uVar1 - (int)uVar7;
        puVar6[1] = (ushort)uVar3;
        uVar4 = (ulong)(uVar3 & 0xffff);
        puVar6[uVar4 * 2] = 0;
        puVar6[uVar4 * 2 + 1] = (ushort)uVar7;
        puVar6 = puVar6 + uVar4 * 2 + 2;
        goto LAB_0013536d;
      }
      if (uVar7 == uVar1) {
        if (puVar5 == (ushort *)0x0) {
          DAT_00145138 = &DAT_00145140 + (ulong)*puVar6 * 2;
        }
        else {
          *puVar5 = *puVar6;
        }
        *puVar6 = 0;
        puVar6 = puVar6 + 2;
        goto LAB_0013536d;
      }
      puVar2 = &DAT_00145140 + (ulong)*puVar6 * 2;
      puVar5 = puVar6;
    } while ((ulong)*puVar6 != 0x80);
  }
  puVar6 = (ushort *)0x0;
LAB_0013536d:
                    /* try { // try from 0013536d to 00135378 has its CatchHandler @ 00135384 */
  pthread_mutex_unlock((pthread_mutex_t *)&DAT_00145110);
  return puVar6;
}


// ==== FUN_00135390 @ 00135390

void FUN_00135390(undefined2 *param_1)

{
  ushort *puVar1;
  ushort uVar2;
  ushort *puVar3;
  ushort *puVar4;
  
  if ((param_1 < &DAT_00145140) || ((undefined2 *)0x14533f < param_1)) {
    free(param_1);
    return;
  }
  puVar1 = param_1 + -2;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00145110);
  if ((DAT_00145138 != (ushort *)0x0) && (DAT_00145138 != (ushort *)&DAT_00145340)) {
    puVar3 = (ushort *)0x0;
    puVar4 = DAT_00145138;
    do {
      uVar2 = puVar4[1];
      if (puVar4 + (ulong)uVar2 * 2 == puVar1) {
        puVar4[1] = param_1[-1] + uVar2;
        goto LAB_00135484;
      }
      if (puVar1 + (ulong)(ushort)param_1[-1] * 2 == puVar4) {
        param_1[-1] = param_1[-1] + uVar2;
        if (puVar3 == (ushort *)0x0) {
          DAT_00145138 = puVar1;
          *puVar1 = *puVar4;
        }
        else {
          *puVar3 = (ushort)((int)puVar1 - 0x145140U >> 2);
        }
        goto LAB_00135484;
      }
      uVar2 = *puVar4;
      puVar3 = puVar4;
      puVar4 = &DAT_00145140 + (ulong)uVar2 * 2;
    } while ((ulong)uVar2 != 0x80);
  }
  *puVar1 = (ushort)((int)DAT_00145138 - 0x145140U >> 2);
  DAT_00145138 = puVar1;
LAB_00135484:
                    /* try { // try from 00135484 to 0013548f has its CatchHandler @ 00135498 */
  pthread_mutex_unlock((pthread_mutex_t *)&DAT_00145110);
  return;
}


// ==== FUN_00135510 @ 00135510

ulong FUN_00135510(long param_1,long param_2,undefined8 *param_3)

{
  long *plVar1;
  undefined8 unaff_R15;
  ulong uVar2;
  long in_FS_OFFSET;
  long *local_70;
  undefined8 local_68;
  long local_60;
  undefined8 local_58;
  undefined8 local_50;
  undefined8 uStack_48;
  undefined8 local_40;
  undefined7 uStack_38;
  undefined1 local_31;
  undefined7 uStack_30;
  undefined8 uStack_29;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  if (*(long *)(param_1 + 8) == *(long *)(param_2 + 8)) {
    uVar2 = CONCAT71((int7)((ulong)unaff_R15 >> 8),1);
  }
  else {
    uVar2 = 0;
    plVar1 = (long *)FUN_001356a0(param_2,&PTR_PTR_00140668,&PTR_PTR_00140680,0);
    if (plVar1 != (long *)0x0) {
      local_68 = 0;
      local_58 = 0xffffffffffffffff;
      uStack_30 = 0;
      local_50 = 0;
      uStack_48 = 0;
      local_40 = 0;
      uStack_38 = 0;
      local_31 = 0;
      uStack_29 = 0x100;
      local_70 = plVar1;
      local_60 = param_1;
      (**(code **)(*plVar1 + 0x38))(plVar1,&local_70,*param_3,1);
      uVar2 = (ulong)((int)local_40 == 1);
      if ((int)local_40 == 1) {
        *param_3 = local_50;
      }
    }
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_20) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar2 & 0xffffffff;
}


// ==== FUN_001356a0 @ 001356a0

long FUN_001356a0(long *param_1,undefined8 param_2,long param_3,undefined8 param_4)

{
  long *plVar1;
  long lVar2;
  long lVar3;
  long in_FS_OFFSET;
  long local_68;
  long *local_60;
  undefined8 local_58;
  undefined8 local_50;
  long local_48;
  long lStack_40;
  undefined8 local_38;
  int iStack_30;
  int iStack_2c;
  int local_28;
  undefined3 uStack_24;
  undefined8 uStack_21;
  long local_18;
  
  local_18 = *(long *)(in_FS_OFFSET + 0x28);
  lVar2 = *(long *)(*param_1 + -0x10) + (long)param_1;
  plVar1 = *(long **)(*param_1 + -8);
  local_48 = 0;
  lStack_40 = 0;
  local_38 = 0;
  iStack_30 = 0;
  iStack_2c = 0;
  local_28 = 0;
  uStack_24 = 0;
  uStack_21 = 0;
  local_68 = param_3;
  local_60 = param_1;
  local_58 = param_2;
  local_50 = param_4;
  if (plVar1[1] == *(long *)(param_3 + 8)) {
    uStack_21 = 0x100;
    (**(code **)(*plVar1 + 0x28))(plVar1,&local_68,lVar2,lVar2,1,0);
    lVar3 = 0;
    if ((int)local_38 == 1) {
      lVar3 = lVar2;
    }
  }
  else {
    (**(code **)(*plVar1 + 0x30))(plVar1,&local_68,lVar2,1,0);
    if (iStack_2c == 1) {
      if (((int)local_38 == 1) ||
         (((lVar3 = 0, local_28 == 0 && (local_38._4_4_ == 1)) && (iStack_30 == 1)))) {
        lVar3 = local_48;
      }
    }
    else {
      lVar3 = 0;
      if (iStack_2c == 0) {
        if (iStack_30 == 1 && (local_38._4_4_ == 1 && local_28 == 1)) {
          lVar3 = lStack_40;
        }
        else {
          lVar3 = 0;
        }
      }
    }
  }
  if (*(long *)(in_FS_OFFSET + 0x28) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return lVar3;
}


// ==== FUN_00135b70 @ 00135b70

void FUN_00135b70(void)

{
  return;
}


// ==== FUN_00135ba0 @ 00135ba0

void FUN_00135ba0(undefined8 *param_1)

{
  *param_1 = &PTR_FUN_00140760;
  return;
}


// ==== FUN_00135c60 @ 00135c60

void FUN_00135c60(undefined8 *param_1)

{
  int *piVar1;
  int iVar2;
  long lVar3;
  
  *param_1 = &PTR_FUN_00140818;
  lVar3 = param_1[1];
  LOCK();
  piVar1 = (int *)(lVar3 + -8);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 + -1 < 0) {
    free((void *)(lVar3 + -0x18));
  }
  FUN_00135b70(param_1);
  return;
}


// ==== FUN_00135ce0 @ 00135ce0

undefined8 FUN_00135ce0(long param_1)

{
  return *(undefined8 *)(param_1 + 8);
}


// ==== FUN_00135d70 @ 00135d70

void FUN_00135d70(void)

{
  return;
}


// ==== FUN_00135d80 @ 00135d80

void * FUN_00135d80(size_t *param_1)

{
  size_t sVar1;
  undefined8 *__ptr;
  void *pvVar2;
  ulong uVar3;
  long lVar4;
  ulong uVar5;
  void *__s;
  size_t sVar6;
  
  sVar6 = param_1[2];
  if (sVar6 == 0) {
    pthread_once((pthread_once_t *)&DAT_00145350,(__init_routine *)&LAB_00135f70);
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00145354);
    sVar6 = param_1[2];
    if (sVar6 == 0) {
      sVar6 = DAT_00145348 + 1;
      DAT_00145348 = sVar6;
      param_1[2] = sVar6;
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00145354);
    __ptr = pthread_getspecific(DAT_00145344);
    if (__ptr == (undefined8 *)0x0) goto LAB_00135e61;
LAB_00135da9:
    uVar5 = __ptr[1];
    if (sVar6 <= uVar5) goto LAB_00135eb5;
    uVar3 = sVar6 + 0x11 & 0xfffffffffffffff0;
    __ptr = realloc(__ptr,uVar3 * 8);
    if (__ptr == (undefined8 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    lVar4 = uVar3 - 2;
    memset(__ptr + uVar5 + 2,0,(lVar4 - uVar5) * 8);
  }
  else {
    __ptr = pthread_getspecific(DAT_00145344);
    if (__ptr != (undefined8 *)0x0) goto LAB_00135da9;
LAB_00135e61:
    uVar5 = sVar6 + 0x11 & 0xfffffffffffffff0;
    sVar1 = uVar5 * 8;
    __ptr = malloc(sVar1);
    if (__ptr == (undefined8 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    lVar4 = uVar5 - 2;
    memset(__ptr + 2,0,sVar1 - 0x10);
    *__ptr = 1;
  }
  __ptr[1] = lVar4;
  pthread_setspecific(DAT_00145344,__ptr);
LAB_00135eb5:
  __s = (void *)__ptr[sVar6 + 1];
  if (__s == (void *)0x0) {
    uVar5 = 8;
    if (8 < param_1[1]) {
      uVar5 = param_1[1];
    }
    if ((uVar5 & uVar5 - 1) != 0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    sVar1 = *param_1;
    pvVar2 = malloc(uVar5 + sVar1 + 7);
    if (pvVar2 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    __s = (void *)(-uVar5 & uVar5 + 7 + (long)pvVar2);
    *(void **)((long)__s + -8) = pvVar2;
    if ((void *)param_1[3] == (void *)0x0) {
      memset(__s,0,sVar1);
    }
    else {
      memcpy(__s,(void *)param_1[3],sVar1);
    }
    __ptr[sVar6 + 1] = __s;
  }
  return __s;
}


// ==== FUN_00135f50 @ 00135f50

undefined8 FUN_00135f50(void)

{
  undefined8 in_RAX;
  
  if (DAT_00145340 == '\x01') {
    pthread_key_delete(DAT_00145344);
    DAT_00145340 = '\0';
  }
  return in_RAX;
}


// ==== FUN_00136020 @ 00136020

undefined4 FUN_00136020(undefined8 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 local_220;
  undefined1 local_218 [24];
  code *local_200;
  undefined1 local_1d0 [168];
  undefined1 local_128 [264];
  
  FUN_00139d60(local_1d0);
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00136440(local_128,local_1d0);
  iVar1 = FUN_00136570(local_128);
  if (iVar1 != 0) {
    do {
      if (iVar1 < 0) {
        return 3;
      }
      iVar1 = FUN_00136580(local_128,local_218);
      if (iVar1 != 0) {
        return 3;
      }
      if ((local_200 != (code *)0x0) &&
         (iVar1 = (*local_200)(1,1,*param_1,param_1,local_128), iVar1 != 8)) {
        if (iVar1 == 6) {
          FUN_001364a0(local_128,0xfffffffe,&local_220);
          param_1[3] = local_220;
          uVar2 = FUN_00136120(local_1d0,local_128,param_1);
          return uVar2;
        }
        return 3;
      }
      iVar1 = FUN_00136570(local_128);
    } while (iVar1 != 0);
  }
  return 5;
}


// ==== FUN_00136120 @ 00136120

undefined8 FUN_00136120(undefined8 param_1,undefined8 param_2,undefined8 *param_3)

{
  int iVar1;
  long local_78;
  undefined1 local_70 [24];
  code *local_58;
  
  FUN_00136440(param_2,param_1);
  iVar1 = FUN_00136570(param_2);
  if (iVar1 != 0) {
    do {
      if (iVar1 < 0) {
        return 2;
      }
      FUN_001364a0(param_2,0xfffffffe,&local_78);
      iVar1 = FUN_00136580(param_2,local_70);
      if (iVar1 != 0) {
        return 2;
      }
      if (local_58 != (code *)0x0) {
        iVar1 = (*local_58)(1,(local_78 == param_3[3]) * '\x04' + '\x02',*param_3,param_3,param_2);
        if (iVar1 != 8) {
          if (iVar1 == 7) {
            FUN_001365a0(param_2);
            return 2;
          }
          return 2;
        }
        if (local_78 == param_3[3]) {
          fprintf((FILE *)0x146348,"libunwind: %s - %s\n","unwind_phase2",
                  "during phase1 personality function said it would stop here, but now in phase2 it did not stop here"
                 );
          fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
          abort();
        }
      }
      iVar1 = FUN_00136570(param_2);
    } while (iVar1 != 0);
  }
  return 5;
}


// ==== FUN_00136230 @ 00136230

void FUN_00136230(long param_1)

{
  undefined1 auStack_1b8 [168];
  undefined1 local_110 [264];
  
  FUN_00139d60(auStack_1b8);
  if (*(long *)(param_1 + 0x10) == 0) {
    FUN_00136120(auStack_1b8,local_110,param_1);
  }
  else {
    FUN_001362b0(auStack_1b8,local_110,param_1,*(long *)(param_1 + 0x10),
                 *(undefined8 *)(param_1 + 0x18));
  }
  fprintf((FILE *)0x146348,"libunwind: %s - %s\n","_Unwind_Resume","_Unwind_Resume() can\'t return")
  ;
  fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_001362b0 @ 001362b0

void FUN_001362b0(undefined8 param_1,undefined8 param_2,undefined8 *param_3,code *param_4,
                 undefined8 param_5)

{
  int iVar1;
  undefined1 local_70 [24];
  code *local_58;
  
  FUN_00136440(param_2,param_1);
  iVar1 = FUN_00136570(param_2);
  if (0 < iVar1) {
    do {
      iVar1 = FUN_00136580(param_2,local_70);
      if (iVar1 != 0) {
        return;
      }
      iVar1 = (*param_4)(1,10,*param_3,param_3,param_2,param_5);
      if (iVar1 != 0) {
        return;
      }
      if ((local_58 != (code *)0x0) &&
         (iVar1 = (*local_58)(1,10,*param_3,param_3,param_2), iVar1 != 8)) {
        if (iVar1 != 7) {
          return;
        }
        FUN_001365a0(param_2);
      }
      iVar1 = FUN_00136570(param_2);
    } while (0 < iVar1);
  }
  (*param_4)(1,0x1a,*param_3,param_3,param_2,param_5);
  return;
}


// ==== FUN_00136390 @ 00136390

undefined8 FUN_00136390(undefined8 param_1)

{
  int iVar1;
  undefined1 auStack_48 [16];
  undefined8 local_38;
  
  iVar1 = FUN_00136580(param_1,auStack_48);
  if (iVar1 == 0) {
    return local_38;
  }
  return 0;
}


// ==== FUN_001363c0 @ 001363c0

undefined8 FUN_001363c0(undefined8 param_1)

{
  int iVar1;
  undefined8 local_48 [9];
  
  iVar1 = FUN_00136580(param_1,local_48);
  if (iVar1 == 0) {
    return local_48[0];
  }
  return 0;
}


// ==== FUN_001363e0 @ 001363e0

void FUN_001363e0(long param_1)

{
  if (*(code **)(param_1 + 8) == (code *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x001363f1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 8))(1,param_1);
  return;
}


// ==== thunk_FUN_001364e0 @ 00136400

undefined8 thunk_FUN_001364e0(long *param_1,int param_2,undefined8 param_3)

{
  char cVar1;
  long lVar2;
  undefined8 uVar3;
  undefined1 auStack_68 [32];
  long lStack_48;
  
  cVar1 = (**(code **)(*param_1 + 0x10))();
  uVar3 = 0xffffe672;
  if (cVar1 != '\0') {
    (**(code **)(*param_1 + 0x20))(param_1,param_2,param_3);
    uVar3 = 0;
    if (param_2 == -1) {
      (**(code **)(*param_1 + 0x48))(param_1,auStack_68);
      uVar3 = 0;
      (**(code **)(*param_1 + 0x68))(param_1,0);
      if (lStack_48 != 0) {
        lVar2 = (**(code **)(*param_1 + 0x18))(param_1,0xfffffffe);
        (**(code **)(*param_1 + 0x20))(param_1,0xfffffffe,lVar2 + lStack_48);
      }
    }
  }
  return uVar3;
}


// ==== FUN_00136410 @ 00136410

undefined8 FUN_00136410(undefined8 param_1)

{
  undefined8 in_RAX;
  undefined8 local_8;
  
  local_8 = in_RAX;
  FUN_001364a0(param_1,0xffffffff,&local_8);
  return local_8;
}


// ==== FUN_00136430 @ 00136430

void FUN_00136430(undefined8 param_1,undefined8 param_2)

{
  FUN_001364e0(param_1,0xffffffff,param_2);
  return;
}


// ==== FUN_00136440 @ 00136440

undefined8 FUN_00136440(undefined8 *param_1,void *param_2)

{
  *param_1 = &PTR_LAB_00140900;
  param_1[1] = &DAT_0014537c;
  memcpy(param_1 + 2,param_2,0xa8);
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  *(undefined8 *)((long)param_1 + 0xf2) = 0;
  *(undefined8 *)((long)param_1 + 0xfa) = 0;
  FUN_00136da0(param_1,0);
  return 0;
}


// ==== FUN_001364a0 @ 001364a0

undefined8 FUN_001364a0(long *param_1,undefined4 param_2,undefined8 *param_3)

{
  char cVar1;
  undefined8 uVar2;
  
  cVar1 = (**(code **)(*param_1 + 0x10))();
  uVar2 = 0xffffe672;
  if (cVar1 != '\0') {
    uVar2 = (**(code **)(*param_1 + 0x18))(param_1,param_2);
    *param_3 = uVar2;
    uVar2 = 0;
  }
  return uVar2;
}


// ==== FUN_001364e0 @ 001364e0

undefined8 FUN_001364e0(long *param_1,int param_2,undefined8 param_3)

{
  char cVar1;
  long lVar2;
  undefined8 uVar3;
  undefined1 auStack_68 [32];
  long local_48;
  
  cVar1 = (**(code **)(*param_1 + 0x10))();
  uVar3 = 0xffffe672;
  if (cVar1 != '\0') {
    (**(code **)(*param_1 + 0x20))(param_1,param_2,param_3);
    uVar3 = 0;
    if (param_2 == -1) {
      (**(code **)(*param_1 + 0x48))(param_1,auStack_68);
      uVar3 = 0;
      (**(code **)(*param_1 + 0x68))(param_1,0);
      if (local_48 != 0) {
        lVar2 = (**(code **)(*param_1 + 0x18))(param_1,0xfffffffe);
        (**(code **)(*param_1 + 0x20))(param_1,0xfffffffe,lVar2 + local_48);
      }
    }
  }
  return uVar3;
}


// ==== FUN_00136570 @ 00136570

void FUN_00136570(long *param_1)

{
  (**(code **)(*param_1 + 0x40))();
  return;
}


// ==== FUN_00136580 @ 00136580

undefined8 FUN_00136580(long *param_1,long param_2)

{
  undefined8 uVar1;
  
  (**(code **)(*param_1 + 0x48))();
  uVar1 = 0xffffe66b;
  if (*(long *)(param_2 + 8) != 0) {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_001365a0 @ 001365a0

undefined8 FUN_001365a0(long *param_1)

{
  (**(code **)(*param_1 + 0x50))();
  return 0xffffe674;
}


// ==== FUN_001365b0 @ 001365b0

char * FUN_001365b0(undefined8 param_1,uint *param_2,undefined8 *param_3,long *param_4,char param_5)

{
  uint *puVar1;
  char *pcVar2;
  long lVar3;
  undefined8 uVar4;
  ulong uVar5;
  long lVar6;
  long lVar7;
  uint *local_50;
  long local_48;
  uint *local_40;
  uint *local_38;
  
  uVar5 = (ulong)*param_2;
  if (uVar5 == 0xffffffff) {
    uVar5 = *(ulong *)(param_2 + 1);
    puVar1 = param_2 + 3;
  }
  else {
    puVar1 = param_2 + 1;
  }
  if (uVar5 == 0) {
    return "FDE has zero length";
  }
  if ((ulong)*puVar1 == 0) {
    return "FDE is really a CIE";
  }
  lVar7 = (long)puVar1 - (ulong)*puVar1;
  if (param_5 == '\0') {
    pcVar2 = (char *)FUN_00136740(param_1,lVar7,param_4);
    if (pcVar2 != (char *)0x0) {
      return pcVar2;
    }
  }
  else if (*param_4 != lVar7) {
    return "CIE start does not match";
  }
  lVar6 = uVar5 + (long)puVar1;
  local_50 = puVar1 + 1;
  local_48 = FUN_001383a0(param_1,&local_50,lVar6,(char)param_4[3],0);
  lVar7 = FUN_001383a0(param_1,&local_50,lVar6,*(byte *)(param_4 + 3) & 0xf,0);
  param_3[5] = 0;
  if (*(char *)((long)param_4 + 0x31) == '\0') {
    local_40 = local_50;
  }
  else {
    lVar3 = FUN_00138640(&local_50,lVar6);
    local_40 = (uint *)(lVar3 + (long)local_50);
    if (*(byte *)((long)param_4 + 0x19) != 0xff) {
      local_38 = local_50;
      lVar3 = FUN_001383a0(param_1,&local_50,lVar6,*(byte *)((long)param_4 + 0x19) & 0xf,0);
      if (lVar3 != 0) {
        local_50 = local_38;
        uVar4 = FUN_001383a0(param_1,&local_50,lVar6,*(undefined1 *)((long)param_4 + 0x19),0);
        param_3[5] = uVar4;
      }
    }
  }
  *param_3 = param_2;
  param_3[1] = lVar6 - (long)param_2;
  param_3[2] = local_40;
  param_3[3] = local_48;
  param_3[4] = lVar7 + local_48;
  return (char *)0x0;
}


// ==== FUN_00136740 @ 00136740

char * FUN_00136740(undefined8 param_1,uint *param_2,long *param_3)

{
  uint *puVar1;
  byte bVar2;
  byte *pbVar3;
  uint uVar4;
  undefined1 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  byte *pbVar10;
  long lVar11;
  ulong uVar12;
  byte *local_40;
  undefined8 local_38;
  
  *(undefined4 *)(param_3 + 3) = 0xff00;
  param_3[4] = 0;
  param_3[5] = 0;
  *(undefined2 *)(param_3 + 6) = 0;
  *param_3 = (long)param_2;
  uVar12 = (ulong)*param_2;
  puVar1 = param_2 + 1;
  if (uVar12 == 0xffffffff) {
    uVar12 = *(ulong *)(param_2 + 1);
    puVar1 = param_2 + 3;
    lVar11 = uVar12 + 0xc;
  }
  else {
    lVar11 = uVar12 + 4;
  }
  pbVar3 = (byte *)((long)param_2 + lVar11);
  if (uVar12 != 0) {
    if (*puVar1 != 0) {
      return "CIE ID is not zero";
    }
    uVar4 = puVar1[1];
    if (((byte)uVar4 & 0xfd) != 1) {
      return "CIE version is not 1 or 3";
    }
    pbVar10 = (byte *)((long)puVar1 + 5);
    local_40 = pbVar10;
    do {
      bVar2 = *local_40;
      local_40 = local_40 + 1;
    } while (bVar2 != 0);
    local_38 = param_1;
    uVar6 = FUN_00138640();
    *(undefined4 *)(param_3 + 5) = uVar6;
    lVar11 = 0;
    uVar12 = 0;
    pbVar9 = local_40;
    uVar7 = 0;
    do {
      uVar8 = uVar7;
      if (pbVar9 == pbVar3) {
        fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128","truncated sleb128 expression")
        ;
        fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
        abort();
      }
      bVar2 = *pbVar9;
      pbVar9 = pbVar9 + 1;
      uVar12 = uVar12 | (ulong)(bVar2 & 0x7f) << ((byte)uVar8 & 0x3f);
      lVar11 = lVar11 + -1;
      uVar7 = uVar8 + 7;
    } while ((bVar2 & 0x80) != 0);
    uVar7 = (uint)(-1L << ((byte)(uVar8 + 7) & 0x3f));
    if (0x38 < uVar8) {
      uVar7 = 0;
    }
    if ((bVar2 & 0x40) == 0) {
      uVar7 = 0;
    }
    local_40 = local_40 + -lVar11;
    *(uint *)((long)param_3 + 0x2c) = (uint)uVar12 | uVar7;
    if ((byte)uVar4 == 1) {
      local_40 = local_40 + 1;
      *(byte *)((long)param_3 + 0x32) = *pbVar9;
      bVar2 = *pbVar10;
    }
    else {
      uVar5 = FUN_00138640(&local_40,pbVar3);
      *(undefined1 *)((long)param_3 + 0x32) = uVar5;
      bVar2 = *pbVar10;
    }
    if (bVar2 == 0x7a) {
      FUN_00138640(&local_40,pbVar3);
LAB_001368ed:
      switch(*pbVar10) {
      case 0x4c:
        *(byte *)((long)param_3 + 0x19) = *local_40;
        goto LAB_00136958;
      case 0x4d:
      case 0x4e:
      case 0x4f:
      case 0x51:
      case 0x54:
      case 0x55:
      case 0x56:
      case 0x57:
      case 0x58:
      case 0x59:
      case 0x5a:
      case 0x5b:
      case 0x5c:
      case 0x5d:
      case 0x5e:
      case 0x5f:
      case 0x60:
      case 0x61:
      case 0x62:
      case 99:
      case 100:
      case 0x65:
      case 0x66:
      case 0x67:
      case 0x68:
      case 0x69:
      case 0x6a:
      case 0x6b:
      case 0x6c:
      case 0x6d:
      case 0x6e:
      case 0x6f:
      case 0x70:
      case 0x71:
      case 0x72:
      case 0x73:
      case 0x74:
      case 0x75:
      case 0x76:
      case 0x77:
      case 0x78:
      case 0x79:
        break;
      case 0x50:
        bVar2 = *local_40;
        *(byte *)((long)param_3 + 0x1a) = bVar2;
        local_40 = local_40 + 1;
        *(char *)((long)param_3 + 0x1b) = (char)local_40 - (char)param_2;
        lVar11 = FUN_001383a0(local_38,&local_40,pbVar3,bVar2,0);
        param_3[4] = lVar11;
        pbVar10 = pbVar10 + 1;
        goto LAB_001368ed;
      case 0x52:
        *(byte *)(param_3 + 3) = *local_40;
LAB_00136958:
        local_40 = local_40 + 1;
        pbVar10 = pbVar10 + 1;
        goto LAB_001368ed;
      case 0x53:
        *(undefined1 *)(param_3 + 6) = 1;
        break;
      case 0x7a:
        goto switchD_00136903_caseD_7a;
      default:
        if (*pbVar10 == 0) goto LAB_0013697d;
      }
      pbVar10 = pbVar10 + 1;
      goto LAB_001368ed;
    }
LAB_0013697d:
    param_3[1] = (long)pbVar3 - *param_3;
    param_3[2] = (long)local_40;
  }
  return (char *)0x0;
switchD_00136903_caseD_7a:
  *(undefined1 *)((long)param_3 + 0x31) = 1;
  pbVar10 = pbVar10 + 1;
  goto LAB_001368ed;
}


// ==== FUN_00136da0 @ 00136da0

void FUN_00136da0(long *param_1,uint param_2)

{
  char cVar1;
  int iVar2;
  long lVar3;
  undefined *puVar4;
  ulong uVar5;
  long local_2e0;
  undefined4 local_2d8;
  long local_2c8;
  long lStack_2c0;
  long local_2b8;
  undefined1 local_2b0 [16];
  long local_2a0;
  undefined1 local_280 [32];
  long local_260;
  long local_248;
  undefined1 *local_240;
  ulong local_238;
  
  lVar3 = (**(code **)(*param_1 + 0x18))(param_1,0xffffffff);
  if (lVar3 != 0) {
    uVar5 = lVar3 - (ulong)(param_2 & 0xff);
    local_248 = param_1[1];
    local_240 = local_2b0;
    local_238 = uVar5;
    iVar2 = dl_iterate_phdr(&LAB_00139720,&local_248);
    if (((iVar2 != 0) && (local_2a0 != 0)) &&
       (cVar1 = FUN_001393f0(param_1,uVar5,local_2b0,0), cVar1 != '\0')) {
      return;
    }
    pthread_rwlock_rdlock((pthread_rwlock_t *)&DAT_00145380);
    for (puVar4 = PTR_DAT_00144ea8; puVar4 < PTR_DAT_00144eb0; puVar4 = puVar4 + 0x20) {
      if ((*(ulong *)(puVar4 + 8) <= uVar5) && (uVar5 < *(ulong *)(puVar4 + 0x10))) {
        lVar3 = *(long *)(puVar4 + 0x18);
        pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00145380);
        if ((lVar3 != 0) &&
           (lVar3 = FUN_001365b0(param_1[1],lVar3,&local_2e0,local_280,0), lVar3 == 0)) {
          memset(&local_248,0,0x228);
          cVar1 = FUN_00137570(param_1[1],&local_2e0,local_280,uVar5,1,&local_248);
          if (cVar1 != '\0') {
            param_1[0x17] = local_2c8;
            param_1[0x18] = lStack_2c0;
            param_1[0x19] = local_2b8;
            param_1[0x1a] = local_260;
            param_1[0x1b] = local_238 & 0xffffffff;
            param_1[0x1c] = 0;
            *(undefined4 *)(param_1 + 0x1d) = 0x4000000;
            param_1[0x1e] = local_2e0;
            *(undefined4 *)((long)param_1 + 0xec) = local_2d8;
            param_1[0x1f] = 0;
            return;
          }
        }
        goto LAB_00136f5a;
      }
    }
    pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00145380);
  }
LAB_00136f5a:
  *(undefined1 *)(param_1 + 0x20) = 1;
  return;
}


// ==== FUN_00136fa0 @ 00136fa0

undefined8
FUN_00136fa0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 *param_4,
            undefined1 *param_5)

{
  char cVar1;
  long lVar2;
  undefined8 uVar3;
  ulong uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  int *piVar8;
  ulong uVar9;
  undefined8 local_400;
  undefined8 local_3f8;
  undefined8 local_3f0;
  undefined8 local_3e8;
  undefined8 local_3e0;
  undefined8 local_3d8;
  undefined8 local_3d0;
  undefined8 local_3c8;
  undefined8 local_3c0;
  undefined8 local_3b8;
  undefined8 local_3b0;
  undefined8 local_3a8;
  undefined8 local_3a0;
  undefined8 local_398;
  undefined8 local_390;
  undefined8 local_388;
  undefined8 *local_380;
  undefined8 *local_378;
  undefined8 *local_370;
  undefined8 *local_368;
  undefined8 *local_360;
  undefined8 *local_358;
  undefined8 *local_350;
  undefined8 *local_348;
  undefined8 *local_340;
  undefined8 *local_338;
  undefined8 *local_330;
  undefined8 *local_328;
  undefined8 *local_320;
  undefined8 *local_318;
  undefined8 *local_310;
  undefined8 *local_308;
  undefined1 *local_300;
  undefined8 *local_2f8;
  undefined8 local_2f0;
  undefined4 local_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined8 local_2d8;
  undefined8 uStack_2d0;
  undefined1 local_2c0 [48];
  undefined1 local_290;
  byte local_28e;
  undefined1 local_288 [48];
  undefined1 local_258 [24];
  int local_240 [132];
  
  lVar2 = FUN_001365b0(param_1,param_3,local_288,local_2c0,0);
  uVar7 = 0xffffe66e;
  if (lVar2 == 0) {
    memset(local_258,0,0x228);
    cVar1 = FUN_00137570(param_1,local_288,local_2c0,param_2,1,local_258);
    if (cVar1 != '\0') {
      local_300 = param_5;
      uVar3 = FUN_001380e0(param_1,local_258,param_4);
      local_388 = *param_4;
      local_310 = param_4 + 1;
      local_390 = param_4[1];
      local_318 = param_4 + 2;
      local_398 = param_4[2];
      local_320 = param_4 + 3;
      local_3a0 = param_4[3];
      local_328 = param_4 + 4;
      local_3a8 = param_4[4];
      local_330 = param_4 + 5;
      local_3b0 = param_4[5];
      local_338 = param_4 + 6;
      local_3b8 = param_4[6];
      local_340 = param_4 + 7;
      local_348 = param_4 + 8;
      local_3c8 = param_4[8];
      local_350 = param_4 + 9;
      local_3d0 = param_4[9];
      local_358 = param_4 + 10;
      local_3d8 = param_4[10];
      local_360 = param_4 + 0xb;
      local_3e0 = param_4[0xb];
      local_368 = param_4 + 0xc;
      local_3e8 = param_4[0xc];
      local_370 = param_4 + 0xd;
      local_3f0 = param_4[0xd];
      local_3f8 = param_4[0xe];
      local_400 = param_4[0xf];
      local_378 = param_4 + 0xe;
      local_2e8 = *(undefined4 *)(param_4 + 0x11);
      uStack_2e4 = *(undefined4 *)((long)param_4 + 0x8c);
      uStack_2e0 = *(undefined4 *)(param_4 + 0x12);
      uStack_2dc = *(undefined4 *)((long)param_4 + 0x94);
      local_2d8 = param_4[0x13];
      uStack_2d0 = param_4[0x14];
      local_380 = param_4 + 0xf;
      local_2f8 = param_4 + 0x10;
      local_308 = param_4 + 0x11;
      piVar8 = local_240;
      uVar9 = 0;
      uVar7 = 0;
      local_3c0 = uVar3;
      do {
        uVar4 = (ulong)local_28e;
        if (*piVar8 == 0) {
          if (uVar9 == uVar4) {
            puVar6 = local_2f8;
            switch(uVar4) {
            case 0:
              puVar6 = param_4;
              break;
            case 1:
              puVar6 = local_320;
              break;
            case 2:
              puVar6 = local_318;
              break;
            case 3:
              puVar6 = local_310;
              break;
            case 4:
              puVar6 = local_330;
              break;
            case 5:
              puVar6 = local_328;
              break;
            case 6:
              puVar6 = local_338;
              break;
            case 7:
              puVar6 = local_340;
              break;
            case 8:
              puVar6 = local_348;
              break;
            case 9:
              puVar6 = local_350;
              break;
            case 10:
              puVar6 = local_358;
              break;
            case 0xb:
              puVar6 = local_360;
              break;
            case 0xc:
              puVar6 = local_368;
              break;
            case 0xd:
              puVar6 = local_370;
              break;
            case 0xe:
              puVar6 = local_378;
              break;
            case 0xf:
              puVar6 = local_380;
              break;
            case 0x10:
              break;
            default:
              fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getRegister",
                      "unsupported x86_64 register");
              fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
              abort();
            }
            uVar7 = *puVar6;
          }
        }
        else if (uVar9 == uVar4) {
          uVar7 = FUN_00138220(param_1,param_4,uVar3,piVar8);
        }
        else {
          if (0x10 < uVar9) {
            return 0xffffe672;
          }
          uVar5 = FUN_00138220(param_1,param_4,uVar3,piVar8);
          if (0x10 < (uint)uVar9) {
            fprintf((FILE *)0x146348,"libunwind: %s - %s\n","setRegister",
                    "unsupported x86_64 register");
            fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          puVar6 = &local_2f0;
          switch(uVar9 & 0xffffffff) {
          case 0:
            puVar6 = &local_388;
          case 0x10:
            *puVar6 = uVar5;
            break;
          case 1:
            local_3a0 = uVar5;
            break;
          case 2:
            local_398 = uVar5;
            break;
          case 3:
            local_390 = uVar5;
            break;
          case 4:
            local_3b0 = uVar5;
            break;
          case 5:
            local_3a8 = uVar5;
            break;
          case 6:
            local_3b8 = uVar5;
            break;
          case 7:
            local_3c0 = uVar5;
            break;
          case 8:
            local_3c8 = uVar5;
            break;
          case 9:
            local_3d0 = uVar5;
            break;
          case 10:
            local_3d8 = uVar5;
            break;
          case 0xb:
            local_3e0 = uVar5;
            break;
          case 0xc:
            local_3e8 = uVar5;
            break;
          case 0xd:
            local_3f0 = uVar5;
            break;
          case 0xe:
            local_3f8 = uVar5;
            break;
          case 0xf:
            local_400 = uVar5;
          }
        }
        uVar9 = uVar9 + 1;
        piVar8 = piVar8 + 4;
      } while (uVar9 != 0x21);
      *local_300 = local_290;
      *param_4 = local_388;
      param_4[1] = local_390;
      param_4[2] = local_398;
      param_4[3] = local_3a0;
      param_4[4] = local_3a8;
      param_4[5] = local_3b0;
      param_4[6] = local_3b8;
      param_4[7] = local_3c0;
      param_4[8] = local_3c8;
      param_4[9] = local_3d0;
      param_4[10] = local_3d8;
      param_4[0xb] = local_3e0;
      param_4[0xc] = local_3e8;
      param_4[0xd] = local_3f0;
      param_4[0xe] = local_3f8;
      param_4[0xf] = local_400;
      param_4[0x10] = uVar7;
      local_308[2] = local_2d8;
      local_308[3] = uStack_2d0;
      *local_308 = CONCAT44(uStack_2e4,local_2e8);
      local_308[1] = CONCAT44(uStack_2dc,uStack_2e0);
      uVar7 = 1;
    }
  }
  return uVar7;
}


// ==== FUN_00137570 @ 00137570

undefined8
FUN_00137570(undefined8 param_1,long *param_2,long *param_3,long param_4,undefined8 param_5,
            undefined4 *param_6)

{
  long *plVar1;
  char cVar2;
  int iVar3;
  byte *pbVar4;
  long lVar5;
  undefined4 uVar6;
  ulong uVar7;
  long lVar8;
  ulong uVar9;
  uint uVar10;
  byte bVar11;
  byte *pbVar12;
  undefined1 *puVar13;
  size_t __size;
  char *pcVar14;
  ulong uVar15;
  byte *pbVar16;
  ulong uVar17;
  uint uVar18;
  undefined1 auStack_2c8 [32];
  long alStack_2a8 [67];
  long local_90;
  undefined8 local_88;
  long local_80;
  long local_78;
  long local_70;
  long local_68;
  long *local_60;
  undefined8 local_58;
  long *local_50;
  ulong local_48;
  long *local_40;
  byte *local_38;
  
  puVar13 = auStack_2c8;
  local_58 = param_1;
  alStack_2a8[0x42] = param_3[2];
  local_40 = param_3;
  local_60 = alStack_2a8 + 0x42;
  local_90 = param_3[1] + *param_3;
  local_88 = 0xffffffffffffffff;
  local_80 = param_2[2];
  local_78 = param_2[1] + *param_2;
  local_70 = param_4 - param_2[3];
  local_50 = (long *)0x0;
  do {
    local_38 = (byte *)*local_60;
    pbVar4 = (byte *)local_60[1];
    if ((local_38 < pbVar4) && (uVar7 = local_60[2], uVar7 != 0)) {
      uVar17 = 0;
      local_48 = uVar7;
      pbVar12 = local_38;
      do {
        plVar1 = local_50;
        bVar11 = *pbVar12;
        pbVar16 = pbVar12 + 1;
        local_38 = pbVar16;
        switch(bVar11) {
        case 0:
          break;
        case 1:
          lVar8 = local_40[3];
          *(undefined8 *)(puVar13 + -8) = 0x137669;
          uVar17 = FUN_001383a0(local_58,&local_38,pbVar4,(char)lVar8);
          break;
        case 2:
          uVar17 = uVar17 + (uint)pbVar12[1] * (int)local_40[5];
          local_38 = pbVar12 + 2;
          break;
        case 3:
          uVar17 = uVar17 + (uint)*(ushort *)(pbVar12 + 1) * (int)local_40[5];
          local_38 = pbVar12 + 3;
          break;
        case 4:
          uVar17 = uVar17 + (uint)((int)local_40[5] * *(int *)(pbVar12 + 1));
          local_38 = pbVar12 + 5;
          break;
        case 5:
          *(undefined8 *)(puVar13 + -8) = 0x1376d3;
          uVar7 = FUN_00138640(&local_38,pbVar4);
          *(undefined8 *)(puVar13 + -8) = 0x1376e1;
          lVar8 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar7) {
            pcVar14 = "libunwind: malformed DW_CFA_offset_extended DWARF unwind, reg too big\n";
            __size = 0x46;
            goto LAB_00137fa5;
          }
          iVar3 = *(int *)((long)local_40 + 0x2c);
          if (*(char *)(param_6 + uVar7 * 4 + 7) == '\0') {
            lVar5 = *(long *)((long)(param_6 + uVar7 * 4 + 6) + 8);
            alStack_2a8[uVar7 * 2] = *(long *)(param_6 + uVar7 * 4 + 6);
            alStack_2a8[uVar7 * 2 + 1] = lVar5;
            *(undefined1 *)(param_6 + uVar7 * 4 + 7) = 1;
          }
          param_6[uVar7 * 4 + 6] = 2;
          *(long *)(param_6 + uVar7 * 4 + 8) = lVar8 * iVar3;
          goto LAB_001378fd;
        case 6:
          *(undefined8 *)(puVar13 + -8) = 0x13773b;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = "libunwind: malformed DW_CFA_restore_extended DWARF unwind, reg too big\n";
LAB_00137ec9:
            __size = 0x47;
LAB_00137fa5:
            *(undefined8 *)(puVar13 + -8) = 0x137faf;
            fwrite(pcVar14,__size,1,(FILE *)0x146348);
            return 0;
          }
          if (*(char *)(param_6 + uVar9 * 4 + 7) != '\0') {
            lVar8 = alStack_2a8[uVar9 * 2 + 1];
            *(long *)(param_6 + uVar9 * 4 + 6) = alStack_2a8[uVar9 * 2];
            *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8) = lVar8;
          }
          break;
        case 7:
          *(undefined8 *)(puVar13 + -8) = 0x137774;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = "libunwind: malformed DW_CFA_undefined DWARF unwind, reg too big\n";
LAB_00137fa0:
            __size = 0x40;
            goto LAB_00137fa5;
          }
          if (*(char *)(param_6 + uVar9 * 4 + 7) == '\0') {
            lVar8 = *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8);
            alStack_2a8[uVar9 * 2] = *(long *)(param_6 + uVar9 * 4 + 6);
            alStack_2a8[uVar9 * 2 + 1] = lVar8;
            *(undefined1 *)(param_6 + uVar9 * 4 + 7) = 1;
          }
          param_6[uVar9 * 4 + 6] = 1;
          break;
        case 8:
          *(undefined8 *)(puVar13 + -8) = 0x1377bd;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = "libunwind: malformed DW_CFA_same_value DWARF unwind, reg too big\n";
            __size = 0x41;
            goto LAB_00137fa5;
          }
          if (*(char *)(param_6 + uVar9 * 4 + 7) == '\0') {
            lVar8 = *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8);
            alStack_2a8[uVar9 * 2] = *(long *)(param_6 + uVar9 * 4 + 6);
            alStack_2a8[uVar9 * 2 + 1] = lVar8;
            *(undefined1 *)(param_6 + uVar9 * 4 + 7) = 1;
          }
          param_6[uVar9 * 4 + 6] = 0;
          break;
        case 9:
          *(undefined8 *)(puVar13 + -8) = 0x137809;
          uVar7 = FUN_00138640(&local_38,pbVar4);
          *(undefined8 *)(puVar13 + -8) = 0x137817;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar7) {
            pcVar14 = "libunwind: malformed DW_CFA_register DWARF unwind, reg too big\n";
            __size = 0x3f;
            goto LAB_00137fa5;
          }
          if (0x20 < uVar9) {
            pcVar14 = "libunwind: malformed DW_CFA_register DWARF unwind, reg2 too big\n";
            goto LAB_00137fa0;
          }
          if (*(char *)(param_6 + uVar7 * 4 + 7) == '\0') {
            lVar8 = *(long *)((long)(param_6 + uVar7 * 4 + 6) + 8);
            alStack_2a8[uVar7 * 2] = *(long *)(param_6 + uVar7 * 4 + 6);
            alStack_2a8[uVar7 * 2 + 1] = lVar8;
            *(undefined1 *)(param_6 + uVar7 * 4 + 7) = 1;
          }
          param_6[uVar7 * 4 + 6] = 4;
          *(ulong *)(param_6 + uVar7 * 4 + 8) = uVar9;
          goto LAB_001378fd;
        case 10:
          plVar1 = (long *)(puVar13 + -0x230);
          *(long **)(puVar13 + -0x230) = local_50;
          *(undefined8 *)(puVar13 + -0x238) = 0x137890;
          memcpy(puVar13 + -0x228,param_6,0x228);
          puVar13 = puVar13 + -0x230;
          local_50 = plVar1;
          uVar7 = local_48;
          break;
        case 0xb:
          if (local_50 == (long *)0x0) {
            return 0;
          }
          *(undefined8 *)(puVar13 + -8) = 0x1378be;
          memcpy(param_6,local_50 + 1,0x228);
          local_50 = (long *)*plVar1;
          uVar7 = local_48;
          break;
        case 0xc:
          *(undefined8 *)(puVar13 + -8) = 0x1378dd;
          uVar7 = FUN_00138640(&local_38,pbVar4);
          *(undefined8 *)(puVar13 + -8) = 0x1378eb;
          uVar6 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar7) {
            pcVar14 = "libunwind: malformed DW_CFA_def_cfa DWARF unwind, reg too big\n";
            __size = 0x3e;
            goto LAB_00137fa5;
          }
          *param_6 = (int)uVar7;
          param_6[1] = uVar6;
LAB_001378fd:
          uVar7 = local_48;
          break;
        case 0xd:
          *(undefined8 *)(puVar13 + -8) = 0x137919;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = "libunwind: malformed DW_CFA_def_cfa_register DWARF unwind, reg too big\n";
            goto LAB_00137ec9;
          }
          *param_6 = (int)uVar9;
          break;
        case 0xe:
          *(undefined8 *)(puVar13 + -8) = 0x137938;
          uVar6 = FUN_00138640(&local_38,pbVar4);
          param_6[1] = uVar6;
          break;
        case 0xf:
          *param_6 = 0;
          *(byte **)(param_6 + 2) = pbVar16;
          goto LAB_00137cc1;
        case 0x10:
          *(undefined8 *)(puVar13 + -8) = 0x13795e;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = "libunwind: malformed DW_CFA_expression DWARF unwind, reg too big\n";
            __size = 0x41;
            goto LAB_00137fa5;
          }
          if (*(char *)(param_6 + uVar9 * 4 + 7) == '\0') {
            lVar8 = *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8);
            alStack_2a8[uVar9 * 2] = *(long *)(param_6 + uVar9 * 4 + 6);
            alStack_2a8[uVar9 * 2 + 1] = lVar8;
            *(undefined1 *)(param_6 + uVar9 * 4 + 7) = 1;
          }
          param_6[uVar9 * 4 + 6] = 5;
          goto LAB_00137cbc;
        case 0x11:
          *(undefined8 *)(puVar13 + -8) = 0x1379ab;
          uVar7 = FUN_00138640(&local_38);
          if (0x20 < uVar7) {
            pcVar14 = "libunwind: malformed DW_CFA_offset_extended_sf DWARF unwind, reg too big\n";
            __size = 0x49;
            goto LAB_00137fa5;
          }
          uVar9 = 0;
          pbVar12 = local_38;
          pbVar16 = local_38;
          uVar18 = 0;
          do {
            uVar10 = uVar18;
            if (pbVar12 == pbVar4) {
              *(undefined8 *)(puVar13 + -8) = 0x13801f;
              fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              *(undefined8 *)(puVar13 + -8) = 0x138027;
              fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
              *(undefined8 *)(puVar13 + -8) = 0x13802c;
              abort();
            }
            bVar11 = *pbVar12;
            pbVar12 = pbVar12 + 1;
            uVar9 = uVar9 | (ulong)(bVar11 & 0x7f) << ((byte)uVar10 & 0x3f);
            pbVar16 = pbVar16 + 1;
            uVar18 = uVar10 + 7;
          } while ((bVar11 & 0x80) != 0);
          uVar15 = -1L << ((byte)(uVar10 + 7) & 0x3f);
          if (0x38 < uVar10) {
            uVar15 = 0;
          }
          if ((bVar11 & 0x40) == 0) {
            uVar15 = 0;
          }
          local_38 = pbVar16;
          lVar8 = (long)*(int *)((long)local_40 + 0x2c) * (uVar9 | uVar15);
          if (*(char *)(param_6 + uVar7 * 4 + 7) == '\0') {
            lVar5 = *(long *)((long)(param_6 + uVar7 * 4 + 6) + 8);
            alStack_2a8[uVar7 * 2] = *(long *)(param_6 + uVar7 * 4 + 6);
            alStack_2a8[uVar7 * 2 + 1] = lVar5;
            *(undefined1 *)(param_6 + uVar7 * 4 + 7) = 1;
          }
          param_6[uVar7 * 4 + 6] = 2;
          goto LAB_00137c66;
        case 0x12:
          *(undefined8 *)(puVar13 + -8) = 0x137a57;
          uVar7 = FUN_00138640(&local_38,pbVar4);
          uVar9 = 0;
          pbVar12 = local_38;
          pbVar16 = local_38;
          uVar18 = 0;
          do {
            uVar10 = uVar18;
            if (pbVar16 == pbVar4) {
              *(undefined8 *)(puVar13 + -8) = 0x138057;
              fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              *(undefined8 *)(puVar13 + -8) = 0x13805f;
              fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
              *(undefined8 *)(puVar13 + -8) = 0x138064;
              abort();
            }
            bVar11 = *pbVar16;
            pbVar16 = pbVar16 + 1;
            uVar9 = uVar9 | (ulong)(bVar11 & 0x7f) << ((byte)uVar10 & 0x3f);
            pbVar12 = pbVar12 + 1;
            uVar18 = uVar10 + 7;
          } while ((bVar11 & 0x80) != 0);
          local_38 = pbVar12;
          if (0x20 < uVar7) {
            pcVar14 = "libunwind: malformed DW_CFA_def_cfa_sf DWARF unwind, reg too big\n";
            __size = 0x41;
            goto LAB_00137fa5;
          }
          uVar18 = (uint)(-1L << ((byte)(uVar10 + 7) & 0x3f));
          if (0x38 < uVar10) {
            uVar18 = 0;
          }
          if ((bVar11 & 0x40) == 0) {
            uVar18 = 0;
          }
          iVar3 = *(int *)((long)local_40 + 0x2c);
          *param_6 = (int)uVar7;
          param_6[1] = ((uint)uVar9 | uVar18) * iVar3;
          uVar7 = local_48;
          break;
        case 0x13:
          uVar7 = 0;
          pbVar12 = pbVar16;
          uVar18 = 0;
          do {
            uVar10 = uVar18;
            if (pbVar12 == pbVar4) {
              *(undefined8 *)(puVar13 + -8) = 0x13808f;
              fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              *(undefined8 *)(puVar13 + -8) = 0x138097;
              fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
              *(undefined8 *)(puVar13 + -8) = 0x13809c;
              abort();
            }
            bVar11 = *pbVar12;
            pbVar12 = pbVar12 + 1;
            uVar7 = uVar7 | (ulong)(bVar11 & 0x7f) << ((byte)uVar10 & 0x3f);
            pbVar16 = pbVar16 + 1;
            uVar18 = uVar10 + 7;
          } while ((bVar11 & 0x80) != 0);
          uVar18 = (uint)(-1L << ((byte)(uVar10 + 7) & 0x3f));
          if (0x38 < uVar10) {
            uVar18 = 0;
          }
          if ((bVar11 & 0x40) == 0) {
            uVar18 = 0;
          }
          local_38 = pbVar16;
          param_6[1] = ((uint)uVar7 | uVar18) * *(int *)((long)local_40 + 0x2c);
          uVar7 = local_48;
          break;
        case 0x14:
          *(undefined8 *)(puVar13 + -8) = 0x137b5a;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = 
            "libunwind: malformed DW_CFA_val_offset DWARF unwind, reg (%lu) out of range\n\n";
            goto LAB_00137fd6;
          }
          *(undefined8 *)(puVar13 + -8) = 0x137b73;
          lVar8 = FUN_00138640(&local_38,pbVar4);
          iVar3 = *(int *)((long)local_40 + 0x2c);
          if (*(char *)(param_6 + uVar9 * 4 + 7) == '\0') {
            lVar5 = *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8);
            alStack_2a8[uVar9 * 2] = *(long *)(param_6 + uVar9 * 4 + 6);
            alStack_2a8[uVar9 * 2 + 1] = lVar5;
            *(undefined1 *)(param_6 + uVar9 * 4 + 7) = 1;
          }
          param_6[uVar9 * 4 + 6] = 3;
          *(long *)(param_6 + uVar9 * 4 + 8) = iVar3 * lVar8;
          break;
        case 0x15:
          *(undefined8 *)(puVar13 + -8) = 0x137bc4;
          uVar7 = FUN_00138640(&local_38);
          if (0x20 < uVar7) {
            pcVar14 = "libunwind: malformed DW_CFA_val_offset_sf DWARF unwind, reg too big\n";
            __size = 0x44;
            goto LAB_00137fa5;
          }
          uVar9 = 0;
          pbVar12 = local_38;
          pbVar16 = local_38;
          uVar18 = 0;
          do {
            uVar10 = uVar18;
            if (pbVar12 == pbVar4) {
              *(undefined8 *)(puVar13 + -8) = 0x1380c7;
              fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              *(undefined8 *)(puVar13 + -8) = 0x1380cf;
              fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
              *(undefined **)(puVar13 + -8) = &UNK_001380d4;
              abort();
            }
            bVar11 = *pbVar12;
            pbVar12 = pbVar12 + 1;
            uVar9 = uVar9 | (ulong)(bVar11 & 0x7f) << ((byte)uVar10 & 0x3f);
            pbVar16 = pbVar16 + 1;
            uVar18 = uVar10 + 7;
          } while ((bVar11 & 0x80) != 0);
          uVar15 = -1L << ((byte)(uVar10 + 7) & 0x3f);
          if (0x38 < uVar10) {
            uVar15 = 0;
          }
          if ((bVar11 & 0x40) == 0) {
            uVar15 = 0;
          }
          local_38 = pbVar16;
          lVar8 = (long)*(int *)((long)local_40 + 0x2c) * (uVar9 | uVar15);
          if (*(char *)(param_6 + uVar7 * 4 + 7) == '\0') {
            lVar5 = *(long *)((long)(param_6 + uVar7 * 4 + 6) + 8);
            alStack_2a8[uVar7 * 2] = *(long *)(param_6 + uVar7 * 4 + 6);
            alStack_2a8[uVar7 * 2 + 1] = lVar5;
            *(undefined1 *)(param_6 + uVar7 * 4 + 7) = 1;
          }
          param_6[uVar7 * 4 + 6] = 3;
LAB_00137c66:
          *(long *)(param_6 + uVar7 * 4 + 8) = lVar8;
          uVar7 = local_48;
          break;
        case 0x16:
          *(undefined8 *)(puVar13 + -8) = 0x137c80;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = "libunwind: malformed DW_CFA_val_expression DWARF unwind, reg too big\n";
            __size = 0x45;
            goto LAB_00137fa5;
          }
          if (*(char *)(param_6 + uVar9 * 4 + 7) == '\0') {
            lVar8 = *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8);
            alStack_2a8[uVar9 * 2] = *(long *)(param_6 + uVar9 * 4 + 6);
            alStack_2a8[uVar9 * 2 + 1] = lVar8;
            *(undefined1 *)(param_6 + uVar9 * 4 + 7) = 1;
          }
          param_6[uVar9 * 4 + 6] = 6;
LAB_00137cbc:
          *(byte **)(param_6 + uVar9 * 4 + 8) = local_38;
LAB_00137cc1:
          *(undefined8 *)(puVar13 + -8) = 0x137ccd;
          lVar8 = FUN_00138640(&local_38,pbVar4);
          local_38 = local_38 + lVar8;
          break;
        default:
          uVar18 = bVar11 & 0x3f;
          uVar9 = (ulong)uVar18;
          bVar11 = bVar11 & 0xc0;
          if (bVar11 == 0x40) {
            uVar17 = uVar17 + uVar18 * (int)local_40[5];
          }
          else {
            if (bVar11 != 0xc0) {
              if (bVar11 != 0x80) {
                return 0;
              }
              if (0x20 < (byte)uVar18) {
                pcVar14 = 
                "libunwind: malformed DW_CFA_offset DWARF unwind, reg (%lu) out of range\n";
                goto LAB_00137fd6;
              }
              *(undefined8 *)(puVar13 + -8) = 0x137d11;
              lVar8 = FUN_00138640(&local_38,pbVar4);
              lVar8 = *(int *)((long)local_40 + 0x2c) * lVar8;
              cVar2 = *(char *)(param_6 + uVar9 * 4 + 7);
              goto joined_r0x00137d7e;
            }
            if (0x20 < (byte)uVar18) {
              pcVar14 = "libunwind: malformed DW_CFA_restore DWARF unwind, reg (%lu) out of range\n"
              ;
LAB_00137fd6:
              *(undefined8 *)(puVar13 + -8) = 0x137fdd;
              fprintf((FILE *)0x146348,pcVar14,uVar9);
              return 0;
            }
            if (*(char *)(param_6 + uVar9 * 4 + 7) != '\0') {
              lVar8 = alStack_2a8[uVar9 * 2 + 1];
              *(long *)(param_6 + uVar9 * 4 + 6) = alStack_2a8[uVar9 * 2];
              *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8) = lVar8;
            }
          }
          break;
        case 0x2e:
          *(undefined8 *)(puVar13 + -8) = 0x137d37;
          uVar6 = FUN_00138640(&local_38,pbVar4);
          param_6[4] = uVar6;
          break;
        case 0x2f:
          *(undefined8 *)(puVar13 + -8) = 0x137d4c;
          uVar9 = FUN_00138640(&local_38,pbVar4);
          if (0x20 < uVar9) {
            pcVar14 = 
            "libunwind: malformed DW_CFA_GNU_negative_offset_extended DWARF unwind, reg too big\n";
            __size = 0x53;
            goto LAB_00137fa5;
          }
          *(undefined8 *)(puVar13 + -8) = 0x137d65;
          lVar8 = FUN_00138640(&local_38,pbVar4);
          lVar8 = -(*(int *)((long)local_40 + 0x2c) * lVar8);
          cVar2 = *(char *)(param_6 + uVar9 * 4 + 7);
joined_r0x00137d7e:
          if (cVar2 == '\0') {
            lVar5 = *(long *)((long)(param_6 + uVar9 * 4 + 6) + 8);
            alStack_2a8[uVar9 * 2] = *(long *)(param_6 + uVar9 * 4 + 6);
            alStack_2a8[uVar9 * 2 + 1] = lVar5;
            *(undefined1 *)(param_6 + uVar9 * 4 + 7) = 1;
          }
          param_6[uVar9 * 4 + 6] = 2;
          *(long *)(param_6 + uVar9 * 4 + 8) = lVar8;
        }
      } while ((local_38 < pbVar4) && (pbVar12 = local_38, uVar17 < uVar7));
    }
    local_60 = local_60 + 3;
    if (local_60 == &local_68) {
      return CONCAT71((int7)((ulong)&local_68 >> 8),1);
    }
  } while( true );
}


// ==== FUN_001380e0 @ 001380e0

long FUN_001380e0(undefined8 param_1,undefined4 *param_2,long param_3)

{
  long lVar1;
  
  switch(*param_2) {
  case 0:
    lVar1 = FUN_00138840(*(undefined8 *)(param_2 + 2),param_1,param_3,0);
    return lVar1;
  case 1:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x18);
  case 2:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x10);
  case 3:
    return (long)(int)param_2[1] + *(long *)(param_3 + 8);
  case 4:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x28);
  case 5:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x20);
  case 6:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x30);
  case 8:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x40);
  case 9:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x48);
  case 10:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x50);
  case 0xb:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x58);
  case 0xc:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x60);
  case 0xd:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x68);
  case 0xe:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x70);
  case 0xf:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x78);
  case 0xfffffffe:
  case 7:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x38);
  case 0xffffffff:
  case 0x10:
    return (long)(int)param_2[1] + *(long *)(param_3 + 0x80);
  default:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getRegister","unsupported x86_64 register");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
}


// ==== FUN_00138220 @ 00138220

undefined8 FUN_00138220(undefined8 param_1,undefined8 *param_2,long param_3,undefined4 *param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0;
  switch(*param_4) {
  case 1:
    goto switchD_00138248_caseD_1;
  case 2:
    uVar2 = *(undefined8 *)(*(long *)(param_4 + 2) + param_3);
switchD_00138248_caseD_1:
    return uVar2;
  default:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSavedRegister",
            "unsupported restore location for register");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 4:
    switch(param_4[2]) {
    case 0:
      goto switchD_00138271_caseD_0;
    case 1:
      return param_2[3];
    case 2:
      return param_2[2];
    case 3:
      return param_2[1];
    case 4:
      return param_2[5];
    case 5:
      return param_2[4];
    case 6:
      return param_2[6];
    case 8:
      return param_2[8];
    case 9:
      return param_2[9];
    case 10:
      return param_2[10];
    case 0xb:
      return param_2[0xb];
    case 0xc:
      return param_2[0xc];
    case 0xd:
      return param_2[0xd];
    case 0xe:
      return param_2[0xe];
    case 0xf:
      return param_2[0xf];
    case 0xfffffffe:
    case 7:
      param_2 = param_2 + 7;
switchD_00138271_caseD_0:
      return *param_2;
    case 0xffffffff:
    case 0x10:
      return param_2[0x10];
    default:
      fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getRegister","unsupported x86_64 register");
      fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
      abort();
    }
  case 5:
    puVar1 = (undefined8 *)FUN_00138840(*(undefined8 *)(param_4 + 2),param_1,param_2,param_3);
    return *puVar1;
  case 6:
    uVar2 = FUN_00138840(*(undefined8 *)(param_4 + 2),param_1,param_2,param_3);
    return uVar2;
  }
}


// ==== FUN_001383a0 @ 001383a0

/* WARNING: Type propagation algorithm not settling */

byte * FUN_001383a0(undefined8 param_1,long *param_2,uint *param_3,uint param_4,long param_5)

{
  byte bVar1;
  uint *puVar2;
  uint uVar3;
  byte *pbVar4;
  ulong uVar5;
  uint uVar6;
  uint *puVar7;
  ulong uVar8;
  uint *puVar9;
  
  if (0xc < (param_4 & 0xf)) {
switchD_001383cd_caseD_5:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getEncodedP","unknown pointer encoding");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  puVar2 = (uint *)*param_2;
  switch(param_4 & 0xf) {
  case 0:
  case 4:
  case 0xc:
    pbVar4 = *(byte **)puVar2;
    *param_2 = (long)(puVar2 + 2);
    break;
  case 1:
    pbVar4 = (byte *)FUN_00138640(param_2,param_3);
    break;
  case 2:
    pbVar4 = (byte *)(ulong)(ushort)*puVar2;
    goto LAB_001383fd;
  case 3:
    pbVar4 = (byte *)(ulong)*puVar2;
    goto LAB_00138409;
  default:
    goto switchD_001383cd_caseD_5;
  case 9:
    uVar5 = 0;
    puVar7 = puVar2;
    puVar9 = puVar2;
    uVar3 = 0;
    do {
      uVar6 = uVar3;
      if (puVar7 == param_3) {
        fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128","truncated sleb128 expression")
        ;
        fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
        abort();
      }
      bVar1 = (byte)*puVar7;
      puVar7 = (uint *)((long)puVar7 + 1);
      uVar5 = uVar5 | (ulong)(bVar1 & 0x7f) << ((byte)uVar6 & 0x3f);
      puVar9 = (uint *)((long)puVar9 + 1);
      uVar3 = uVar6 + 7;
    } while ((bVar1 & 0x80) != 0);
    uVar8 = -1L << ((byte)(uVar6 + 7) & 0x3f);
    if (0x38 < uVar6) {
      uVar8 = 0;
    }
    if ((bVar1 & 0x40) == 0) {
      uVar8 = 0;
    }
    pbVar4 = (byte *)(uVar5 | uVar8);
    *param_2 = (long)puVar9;
    break;
  case 10:
    pbVar4 = (byte *)(long)(short)(ushort)*puVar2;
LAB_001383fd:
    *param_2 = (long)((long)puVar2 + 2);
    break;
  case 0xb:
    pbVar4 = (byte *)(long)(int)*puVar2;
LAB_00138409:
    *param_2 = (long)(puVar2 + 1);
  }
  switch(param_4 >> 4 & 7) {
  case 0:
    goto switchD_0013848a_caseD_0;
  case 1:
    pbVar4 = pbVar4 + (long)puVar2;
switchD_0013848a_caseD_0:
    if ((param_4 & 0x80) != 0) {
LAB_00138495:
      pbVar4 = *(byte **)pbVar4;
    }
    return pbVar4;
  case 2:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_textrel pointer encoding not supported");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 3:
    if (param_5 == 0) {
      fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getEncodedP",
              "DW_EH_PE_datarel is invalid with a datarelBase of 0");
      fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    pbVar4 = pbVar4 + param_5;
    if ((param_4 & 0x80) == 0) {
      return pbVar4;
    }
    goto LAB_00138495;
  case 4:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_funcrel pointer encoding not supported");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 5:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_aligned pointer encoding not supported");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  default:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getEncodedP","unknown pointer encoding");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
}


// ==== FUN_00138640 @ 00138640

ulong FUN_00138640(long *param_1,byte *param_2)

{
  byte *pbVar1;
  byte bVar2;
  byte *pbVar3;
  ulong uVar4;
  
  pbVar3 = (byte *)*param_1;
  if (pbVar3 != param_2) {
    uVar4 = (ulong)(*pbVar3 & 0x7f);
    if (-1 < (char)*pbVar3) {
      *param_1 = (long)(pbVar3 + 1);
      return uVar4;
    }
    if (pbVar3 + 1 != param_2) {
      uVar4 = uVar4 | (ulong)(pbVar3[1] & 0x7f) << 7;
      if (-1 < (char)pbVar3[1]) {
        *param_1 = (long)(pbVar3 + 2);
        return uVar4;
      }
      if (pbVar3 + 2 != param_2) {
        uVar4 = uVar4 | (ulong)(pbVar3[2] & 0x7f) << 0xe;
        if (-1 < (char)pbVar3[2]) {
          *param_1 = (long)(pbVar3 + 3);
          return uVar4;
        }
        if (pbVar3 + 3 != param_2) {
          uVar4 = uVar4 | (ulong)(pbVar3[3] & 0x7f) << 0x15;
          if (-1 < (char)pbVar3[3]) {
            *param_1 = (long)(pbVar3 + 4);
            return uVar4;
          }
          if (pbVar3 + 4 != param_2) {
            uVar4 = uVar4 | (ulong)(pbVar3[4] & 0x7f) << 0x1c;
            if (-1 < (char)pbVar3[4]) {
              *param_1 = (long)(pbVar3 + 5);
              return uVar4;
            }
            if (pbVar3 + 5 != param_2) {
              uVar4 = uVar4 | (ulong)(pbVar3[5] & 0x7f) << 0x23;
              if (-1 < (char)pbVar3[5]) {
                *param_1 = (long)(pbVar3 + 6);
                return uVar4;
              }
              if (pbVar3 + 6 != param_2) {
                uVar4 = uVar4 | (ulong)(pbVar3[6] & 0x7f) << 0x2a;
                if (-1 < (char)pbVar3[6]) {
                  *param_1 = (long)(pbVar3 + 7);
                  return uVar4;
                }
                if (pbVar3 + 7 != param_2) {
                  uVar4 = uVar4 | (ulong)(pbVar3[7] & 0x7f) << 0x31;
                  if (-1 < (char)pbVar3[7]) {
                    *param_1 = (long)(pbVar3 + 8);
                    return uVar4;
                  }
                  if (pbVar3 + 8 != param_2) {
                    uVar4 = uVar4 | (ulong)(pbVar3[8] & 0x7f) << 0x38;
                    pbVar1 = pbVar3 + 9;
                    if (-1 < (char)pbVar3[8]) {
                      *param_1 = (long)pbVar1;
                      return uVar4;
                    }
                    if (pbVar1 != param_2) {
                      bVar2 = *pbVar1;
                      if ((bVar2 & 0x7e) == 0) {
                        if (-1 < (char)bVar2) {
                          *param_1 = (long)(pbVar3 + 10);
                          return uVar4 | (ulong)bVar2 << 0x3f;
                        }
                        if (pbVar3 + 10 == param_2) goto LAB_001387cb;
                      }
                      fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getULEB128",
                              "malformed uleb128 expression");
                      fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
                      abort();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
LAB_001387cb:
  fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getULEB128","truncated uleb128 expression");
  fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_00138840 @ 00138840

ulong FUN_00138840(byte *param_1,undefined8 param_2,ulong *param_3,ulong param_4)

{
  undefined1 auVar1 [16];
  byte bVar2;
  byte bVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  long lVar7;
  ulong *puVar8;
  ulong *puVar9;
  uint uVar10;
  ulong uVar11;
  byte *pbVar12;
  ulong uVar13;
  byte *pbVar14;
  ulong *puVar15;
  ulong *puVar16;
  ulong *puVar17;
  byte *pbVar18;
  ulong *puVar19;
  undefined1 auVar20 [16];
  byte *local_3e0;
  ulong *local_3d8;
  ulong *local_3d0;
  ulong *local_3c8;
  ulong *local_3c0;
  ulong *local_3b8;
  ulong *puStack_3b0;
  ulong *local_3a8;
  ulong *local_3a0;
  ulong *local_398;
  ulong *local_390;
  ulong *local_388;
  ulong *local_380;
  ulong *local_378;
  ulong *local_370;
  ulong *local_368;
  ulong *local_360;
  ulong local_350 [100];
  
  local_3e0 = param_1;
  lVar7 = FUN_00138640(&local_3e0,param_1 + 0x14);
  pbVar18 = local_3e0 + lVar7;
  local_350[0] = param_4;
  if (local_3e0 < pbVar18) {
    puVar19 = local_350;
    puVar15 = param_3 + 0xf;
    puVar16 = param_3 + 0xe;
    puVar17 = param_3 + 0xd;
    puVar9 = param_3 + 0xc;
    local_370 = param_3 + 0xb;
    local_378 = param_3 + 10;
    local_380 = param_3 + 9;
    local_388 = param_3 + 8;
    local_3d0 = param_3 + 7;
    local_390 = param_3 + 6;
    local_398 = param_3 + 4;
    local_3a0 = param_3 + 5;
    local_3a8 = param_3 + 1;
    puStack_3b0 = param_3 + 2;
    local_3b8 = param_3 + 3;
    local_3c0 = param_3 + 0x10;
    do {
      pbVar12 = local_3e0 + 1;
      bVar2 = *local_3e0;
      switch(bVar2) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 0xb:
      case 0xc:
      case 0xd:
      case 0xe:
      case 0xf:
      case 0xf0:
      case 0xf1:
      case 0xf2:
      case 0xf3:
      case 0xf4:
      case 0xf5:
      case 0xf6:
      case 0xf7:
      case 0xf8:
      case 0xf9:
      case 0xfa:
      case 0xfb:
      case 0xfc:
      case 0xfd:
      case 0xfe:
      case 0xff:
        uVar11 = 0;
        local_3e0 = pbVar12;
        pbVar14 = pbVar12;
        uVar4 = 0;
        do {
          uVar10 = uVar4;
          if (pbVar14 == pbVar18) {
            local_3e0 = pbVar12;
            fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128",
                    "truncated sleb128 expression");
            fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          bVar3 = *pbVar14;
          pbVar14 = pbVar14 + 1;
          uVar11 = uVar11 | (ulong)(bVar3 & 0x7f) << ((byte)uVar10 & 0x3f);
          local_3e0 = local_3e0 + 1;
          uVar4 = uVar10 + 7;
        } while ((bVar3 & 0x80) != 0);
        uVar13 = -1L << ((byte)(uVar10 + 7) & 0x3f);
        if (0x38 < uVar10) {
          uVar13 = 0;
        }
        if ((bVar3 & 0x40) == 0) {
          uVar13 = 0;
        }
        puVar8 = local_3c0;
        switch(bVar2) {
        case 0x6e:
        case 0x77:
          puVar8 = local_3d0;
          break;
        case 0x6f:
          break;
        case 0x70:
          puVar8 = param_3;
          break;
        case 0x71:
          puVar8 = local_3b8;
          break;
        case 0x72:
          puVar8 = puStack_3b0;
          break;
        case 0x73:
          puVar8 = local_3a8;
          break;
        case 0x74:
          puVar8 = local_3a0;
          break;
        case 0x75:
          puVar8 = local_398;
          break;
        case 0x76:
          puVar8 = local_390;
          break;
        case 0x78:
          puVar8 = local_388;
          break;
        case 0x79:
          puVar8 = local_380;
          break;
        case 0x7a:
          puVar8 = local_378;
          break;
        case 0x7b:
          puVar8 = local_370;
          break;
        case 0x7c:
          puVar8 = puVar9;
          break;
        case 0x7d:
          puVar8 = puVar17;
          break;
        case 0x7e:
          puVar8 = puVar16;
          break;
        case 0x7f:
          puVar8 = puVar15;
          break;
        default:
          if (bVar2 != 0x80) {
            fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getRegister",
                    "unsupported x86_64 register");
            fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
        }
        uVar11 = uVar11 | uVar13;
        goto switchD_00138da6_caseD_ffffffff;
      case 0x10:
        local_3e0 = pbVar12;
        local_3d8 = param_3;
        local_368 = puVar9;
        uVar5 = FUN_00138640(&local_3e0,pbVar18);
        puVar9 = local_3c0;
        switch(uVar5) {
        case 0:
          puVar9 = local_3d8;
          break;
        case 1:
          puVar9 = local_3b8;
          break;
        case 2:
          puVar9 = puStack_3b0;
          break;
        case 3:
          puVar9 = local_3a8;
          break;
        case 4:
          puVar9 = local_3a0;
          break;
        case 5:
          puVar9 = local_398;
          break;
        case 6:
          puVar9 = local_390;
          break;
        case 8:
          puVar9 = local_388;
          break;
        case 9:
          puVar9 = local_380;
          break;
        case 10:
          puVar9 = local_378;
          break;
        case 0xb:
          puVar9 = local_370;
          break;
        case 0xc:
          puVar9 = local_368;
          break;
        case 0xd:
          puVar9 = puVar17;
          break;
        case 0xe:
          puVar9 = puVar16;
          break;
        case 0xf:
          puVar9 = puVar15;
          break;
        case 0xfffffffe:
        case 7:
          puVar9 = local_3d0;
          break;
        case 0xffffffff:
        case 0x10:
          break;
        default:
          fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getRegister",
                  "unsupported x86_64 register");
          fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
          abort();
        }
        puVar19[1] = *puVar9;
        puVar9 = local_368;
        param_3 = local_3d8;
        goto LAB_00138b6a;
      case 0x11:
        local_3e0 = pbVar12;
        fprintf((FILE *)0x146348,"libunwind: %s - %s\n","evaluateExpression",
                "DW_OP_fbreg not implemented");
        fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
        abort();
      case 0x12:
        local_3e0 = pbVar12;
        local_3d8 = puVar16;
        local_3c8 = puVar15;
        local_368 = puVar9;
        local_360 = puVar17;
        iVar6 = FUN_00138640(&local_3e0,pbVar18);
        uVar11 = 0;
        pbVar12 = local_3e0;
        pbVar14 = local_3e0;
        uVar4 = 0;
        do {
          uVar10 = uVar4;
          if (pbVar14 == pbVar18) {
            fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128",
                    "truncated sleb128 expression");
            fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          bVar2 = *pbVar14;
          pbVar14 = pbVar14 + 1;
          uVar11 = uVar11 | (ulong)(bVar2 & 0x7f) << ((byte)uVar10 & 0x3f);
          pbVar12 = pbVar12 + 1;
          uVar4 = uVar10 + 7;
        } while ((bVar2 & 0x80) != 0);
        uVar13 = -1L << ((byte)(uVar10 + 7) & 0x3f);
        if (0x38 < uVar10) {
          uVar13 = 0;
        }
        if ((bVar2 & 0x40) == 0) {
          uVar13 = 0;
        }
        local_3e0 = pbVar12;
        if (0x12 < iVar6 + 2U) {
          fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getRegister",
                  "unsupported x86_64 register");
          fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
          abort();
        }
        uVar11 = uVar11 | uVar13;
        puVar8 = local_3c0;
        puVar15 = local_3c8;
        puVar16 = local_3d8;
        puVar17 = local_360;
        puVar9 = local_368;
        switch(iVar6) {
        case 0:
          puVar8 = param_3;
          break;
        case 1:
          puVar8 = local_3b8;
          break;
        case 2:
          puVar8 = puStack_3b0;
          break;
        case 3:
          puVar8 = local_3a8;
          break;
        case 4:
          puVar8 = local_3a0;
          break;
        case 5:
          puVar8 = local_398;
          break;
        case 6:
          puVar8 = local_390;
          break;
        case 8:
          puVar8 = local_388;
          break;
        case 9:
          puVar8 = local_380;
          break;
        case 10:
          puVar8 = local_378;
          break;
        case 0xb:
          puVar8 = local_370;
          break;
        case 0xc:
          puVar8 = local_368;
          break;
        case 0xd:
          puVar8 = local_360;
          break;
        case 0xe:
          puVar8 = local_3d8;
          break;
        case 0xf:
          puVar8 = local_3c8;
          break;
        default:
          puVar8 = local_3d0;
          break;
        case -1:
        case 0x10:
          break;
        }
switchD_00138da6_caseD_ffffffff:
        puVar19[1] = uVar11 + *puVar8;
LAB_00138b6a:
        puVar19 = puVar19 + 1;
        break;
      case 0x13:
        local_3e0 = pbVar12;
        fprintf((FILE *)0x146348,"libunwind: %s - %s\n","evaluateExpression",
                "DW_OP_piece not implemented");
        fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
        abort();
      case 0x14:
        puVar8 = (ulong *)*puVar19;
        pbVar12 = local_3e0 + 2;
        pbVar14 = local_3e0 + 1;
        local_3e0 = pbVar12;
        switch(*pbVar14) {
        case 1:
          *puVar19 = (ulong)(byte)*puVar8;
          break;
        case 2:
          *puVar19 = (ulong)(ushort)*puVar8;
          break;
        default:
          fprintf((FILE *)0x146348,"libunwind: %s - %s\n","evaluateExpression",
                  "DW_OP_deref_size with bad size");
          fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
          abort();
        case 4:
          *puVar19 = (ulong)(uint)*puVar8;
          break;
        case 8:
          goto switchD_00138dfc_caseD_8;
        }
        break;
      default:
        local_3e0 = pbVar12;
        fprintf((FILE *)0x146348,"libunwind: %s - %s\n","evaluateExpression",
                "DWARF opcode not implemented");
        fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
        abort();
      case 0x83:
      case 0x8e:
      case 0x8f:
        uVar11 = *(ulong *)(local_3e0 + 1);
        local_3e0 = local_3e0 + 9;
        goto LAB_00138920;
      case 0x86:
        puVar8 = (ulong *)*puVar19;
        local_3e0 = pbVar12;
switchD_00138dfc_caseD_8:
        *puVar19 = *puVar8;
        break;
      case 0x88:
        uVar11 = (ulong)local_3e0[1];
        goto LAB_00138e22;
      case 0x89:
        uVar11 = (ulong)(char)local_3e0[1];
LAB_00138e22:
        local_3e0 = local_3e0 + 2;
        goto LAB_00138920;
      case 0x8a:
        uVar11 = (ulong)*(ushort *)(local_3e0 + 1);
        local_3e0 = local_3e0 + 3;
        goto LAB_00138920;
      case 0x8b:
        uVar11 = (ulong)*(short *)(local_3e0 + 1);
        local_3e0 = local_3e0 + 3;
        goto LAB_00138920;
      case 0x8c:
        uVar11 = (ulong)*(uint *)(local_3e0 + 1);
        local_3e0 = local_3e0 + 5;
        goto LAB_00138920;
      case 0x8d:
        uVar11 = (ulong)*(int *)(local_3e0 + 1);
        local_3e0 = local_3e0 + 5;
LAB_00138920:
LAB_00138925:
        puVar19[1] = uVar11;
LAB_00138929:
        puVar19 = puVar19 + 1;
        break;
      case 0x90:
        local_3e0 = pbVar12;
        local_3d8 = param_3;
        local_3c8 = puVar15;
        uVar11 = FUN_00138640(&local_3e0,pbVar18);
        puVar15 = local_3c8;
        param_3 = local_3d8;
        goto LAB_00138925;
      case 0x91:
        uVar11 = 0;
        local_3e0 = pbVar12;
        pbVar14 = pbVar12;
        uVar4 = 0;
        do {
          uVar10 = uVar4;
          if (pbVar14 == pbVar18) {
            local_3e0 = pbVar12;
            fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getSLEB128",
                    "truncated sleb128 expression");
            fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          bVar2 = *pbVar14;
          pbVar14 = pbVar14 + 1;
          uVar11 = uVar11 | (ulong)(bVar2 & 0x7f) << ((byte)uVar10 & 0x3f);
          local_3e0 = local_3e0 + 1;
          uVar4 = uVar10 + 7;
        } while ((bVar2 & 0x80) != 0);
        uVar13 = -1L << ((byte)(uVar10 + 7) & 0x3f);
        if (0x38 < uVar10) {
          uVar13 = 0;
        }
        if ((bVar2 & 0x40) == 0) {
          uVar13 = 0;
        }
        puVar19[1] = uVar11 | uVar13;
        goto LAB_00138929;
      case 0x92:
        uVar11 = *puVar19;
        local_3e0 = pbVar12;
        goto LAB_00138925;
      case 0x93:
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0x94:
        uVar11 = puVar19[-1];
        local_3e0 = pbVar12;
        goto LAB_00138925;
      case 0x95:
        uVar11 = puVar19[-(ulong)local_3e0[1]];
        local_3e0 = local_3e0 + 2;
        goto LAB_00138925;
      case 0x96:
        auVar1 = *(undefined1 (*) [16])(puVar19 + -1);
        auVar20._8_4_ = auVar1._0_4_;
        auVar20._0_8_ = auVar1._8_8_;
        auVar20._12_4_ = auVar1._4_4_;
        *(undefined1 (*) [16])(puVar19 + -1) = auVar20;
        local_3e0 = pbVar12;
        break;
      case 0x97:
        uVar11 = *puVar19;
        uVar13 = puVar19[-1];
        puVar19[-1] = puVar19[-2];
        *puVar19 = uVar13;
        puVar19[-2] = uVar11;
        local_3e0 = pbVar12;
        break;
      case 0x98:
        uVar11 = *(ulong *)*puVar19;
        goto LAB_00138f73;
      case 0x99:
        local_3e0 = pbVar12;
        if ((long)*puVar19 < 0) {
          *puVar19 = -*puVar19;
        }
        break;
      case 0x9a:
        puVar19[-1] = puVar19[-1] & *puVar19;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0x9b:
        uVar11 = puVar19[-1];
        uVar13 = *puVar19;
        if ((uVar11 | uVar13) >> 0x20 == 0) {
          uVar11 = (uVar11 & 0xffffffff) / (uVar13 & 0xffffffff);
        }
        else {
          uVar11 = (long)uVar11 / (long)uVar13;
        }
        puVar19[-1] = uVar11;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0x9c:
        puVar19[-1] = puVar19[-1] - *puVar19;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0x9d:
        uVar11 = puVar19[-1];
        uVar13 = *puVar19;
        if ((uVar11 | uVar13) >> 0x20 == 0) {
          uVar11 = (uVar11 & 0xffffffff) % (uVar13 & 0xffffffff);
        }
        else {
          uVar11 = (long)uVar11 % (long)uVar13;
        }
        puVar19[-1] = uVar11;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0x9e:
        uVar11 = puVar19[-1] * *puVar19;
LAB_00138f73:
        puVar19[-1] = uVar11;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0x9f:
        *puVar19 = -*puVar19;
        local_3e0 = pbVar12;
        break;
      case 0xa0:
        *puVar19 = ~*puVar19;
        local_3e0 = pbVar12;
        break;
      case 0xa1:
        puVar19[-1] = puVar19[-1] | *puVar19;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0xa2:
        puVar19[-1] = puVar19[-1] + *puVar19;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0xa3:
        local_3e0 = pbVar12;
        local_3d8 = param_3;
        local_3c8 = puVar15;
        lVar7 = FUN_00138640(&local_3e0,pbVar18);
        *puVar19 = *puVar19 + lVar7;
        puVar15 = local_3c8;
        param_3 = local_3d8;
        break;
      case 0xa4:
        puVar19[-1] = puVar19[-1] << ((byte)*puVar19 & 0x3f);
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0xa5:
        puVar19[-1] = puVar19[-1] >> ((byte)*puVar19 & 0x3f);
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0xa6:
        puVar19[-1] = (long)puVar19[-1] >> ((byte)*puVar19 & 0x3f);
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0xa7:
        puVar19[-1] = puVar19[-1] ^ *puVar19;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0xa8:
        if (*puVar19 == 0) {
          puVar19 = puVar19 + -1;
          local_3e0 = local_3e0 + 3;
        }
        else {
          puVar19 = puVar19 + -1;
          local_3e0 = local_3e0 + 3 + *(short *)(local_3e0 + 1);
        }
        break;
      case 0xa9:
        uVar11 = (ulong)(puVar19[-1] == *puVar19);
        goto LAB_00138fba;
      case 0xaa:
        uVar11 = (ulong)(*puVar19 <= puVar19[-1]);
        goto LAB_00138fba;
      case 0xab:
        uVar11 = (ulong)(*puVar19 < puVar19[-1]);
        goto LAB_00138fba;
      case 0xac:
        uVar11 = (ulong)(puVar19[-1] <= *puVar19);
        goto LAB_00138fba;
      case 0xad:
        uVar11 = (ulong)(puVar19[-1] < *puVar19);
        goto LAB_00138fba;
      case 0xae:
        uVar11 = (ulong)(puVar19[-1] != *puVar19);
LAB_00138fba:
        puVar19[-1] = uVar11;
        puVar19 = puVar19 + -1;
        local_3e0 = pbVar12;
        break;
      case 0xaf:
        local_3e0 = local_3e0 + (long)*(short *)(local_3e0 + 1) + 3;
        break;
      case 0xb0:
      case 0xb1:
      case 0xb2:
      case 0xb3:
      case 0xb4:
      case 0xb5:
      case 0xb6:
      case 0xb7:
      case 0xb8:
      case 0xb9:
      case 0xba:
      case 0xbb:
      case 0xbc:
      case 0xbd:
      case 0xbe:
      case 0xbf:
      case 0xc0:
      case 0xc1:
      case 0xc2:
      case 0xc3:
      case 0xc4:
      case 0xc5:
      case 0xc6:
      case 199:
      case 200:
      case 0xc9:
      case 0xca:
      case 0xcb:
      case 0xcc:
      case 0xcd:
      case 0xce:
      case 0xcf:
        puVar19[1] = (ulong)(bVar2 - 0x30);
        local_3e0 = pbVar12;
        goto LAB_00138929;
      case 0xd0:
      case 0xd1:
      case 0xd2:
      case 0xd3:
      case 0xd4:
      case 0xd5:
      case 0xd6:
      case 0xd7:
      case 0xd8:
      case 0xd9:
      case 0xda:
      case 0xdb:
      case 0xdc:
      case 0xdd:
      case 0xde:
      case 0xdf:
      case 0xe0:
      case 0xe1:
      case 0xe2:
      case 0xe3:
      case 0xe4:
      case 0xe5:
      case 0xe6:
      case 0xe7:
      case 0xe8:
      case 0xe9:
      case 0xea:
      case 0xeb:
      case 0xec:
      case 0xed:
      case 0xee:
      case 0xef:
        puVar8 = local_3c0;
        switch(bVar2) {
        case 0x50:
          puVar8 = param_3;
        case 0x60:
          uVar11 = *puVar8;
          local_3e0 = pbVar12;
          break;
        case 0x51:
          uVar11 = *local_3b8;
          local_3e0 = pbVar12;
          break;
        case 0x52:
          uVar11 = *puStack_3b0;
          local_3e0 = pbVar12;
          break;
        case 0x53:
          uVar11 = *local_3a8;
          local_3e0 = pbVar12;
          break;
        case 0x54:
          uVar11 = *local_3a0;
          local_3e0 = pbVar12;
          break;
        case 0x55:
          uVar11 = *local_398;
          local_3e0 = pbVar12;
          break;
        case 0x56:
          uVar11 = *local_390;
          local_3e0 = pbVar12;
          break;
        case 0x57:
          uVar11 = *local_3d0;
          local_3e0 = pbVar12;
          break;
        case 0x58:
          uVar11 = *local_388;
          local_3e0 = pbVar12;
          break;
        case 0x59:
          uVar11 = *local_380;
          local_3e0 = pbVar12;
          break;
        case 0x5a:
          uVar11 = *local_378;
          local_3e0 = pbVar12;
          break;
        case 0x5b:
          uVar11 = *local_370;
          local_3e0 = pbVar12;
          break;
        case 0x5c:
          uVar11 = *puVar9;
          local_3e0 = pbVar12;
          break;
        case 0x5d:
          uVar11 = *puVar17;
          local_3e0 = pbVar12;
          break;
        case 0x5e:
          uVar11 = *puVar16;
          local_3e0 = pbVar12;
          break;
        case 0x5f:
          uVar11 = *puVar15;
          local_3e0 = pbVar12;
          break;
        default:
          local_3e0 = pbVar12;
          fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getRegister",
                  "unsupported x86_64 register");
          fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
          abort();
        }
        goto LAB_00138925;
      }
    } while (local_3e0 < pbVar18);
    param_4 = *puVar19;
  }
  return param_4;
}


// ==== FUN_001393f0 @ 001393f0

ulong FUN_001393f0(long param_1,ulong param_2,long *param_3,uint param_4)

{
  long lVar1;
  undefined *__src;
  char cVar2;
  byte bVar3;
  long *plVar4;
  undefined *__dest;
  size_t __n;
  ulong uVar5;
  long local_2d8;
  undefined4 local_2d0;
  long local_2c0;
  long local_2b8;
  undefined8 uStack_2b0;
  long local_2a8;
  undefined8 uStack_2a0;
  undefined1 local_290 [32];
  undefined8 local_270;
  undefined1 local_258 [16];
  uint local_248;
  
  if (((param_4 == 0) ||
      (cVar2 = FUN_00139890(*(undefined8 *)(param_1 + 8),param_2,param_3[2],param_3[3],
                            (ulong)param_4 + param_3[2],&local_2d8,local_290), cVar2 == '\0')) &&
     ((param_3[4] == 0 ||
      (cVar2 = FUN_00139a70(*(undefined8 *)(param_1 + 8),param_2,param_3[4],(int)param_3[5],
                            &local_2d8,local_290), cVar2 == '\0')))) {
    lVar1 = *param_3;
    pthread_rwlock_rdlock((pthread_rwlock_t *)&DAT_00145380);
    if (PTR_DAT_00144ea8 < PTR_DAT_00144eb0) {
      plVar4 = (long *)PTR_DAT_00144ea8;
      if (lVar1 == -1) {
        do {
          if (((ulong)plVar4[1] <= param_2) && (param_2 < (ulong)plVar4[2])) goto LAB_001394d5;
          plVar4 = plVar4 + 4;
        } while (plVar4 < PTR_DAT_00144eb0);
      }
      else {
        do {
          if (((*plVar4 == lVar1) && ((ulong)plVar4[1] <= param_2)) && (param_2 < (ulong)plVar4[2]))
          goto LAB_001394d5;
          plVar4 = plVar4 + 4;
        } while (plVar4 < PTR_DAT_00144eb0);
      }
    }
    pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00145380);
    goto LAB_00139526;
  }
  bVar3 = 0;
LAB_0013955f:
  lVar1 = *param_3;
  memset(local_258,0,0x228);
  cVar2 = FUN_00137570(*(undefined8 *)(param_1 + 8),&local_2d8,local_290,param_2,1,local_258);
  if (cVar2 == '\0') {
    uVar5 = 0;
  }
  else {
    *(long *)(param_1 + 0xb8) = local_2c0;
    *(long *)(param_1 + 0xc0) = local_2b8;
    *(undefined8 *)(param_1 + 200) = uStack_2b0;
    *(undefined8 *)(param_1 + 0xd0) = local_270;
    *(ulong *)(param_1 + 0xd8) = (ulong)local_248;
    *(undefined8 *)(param_1 + 0xe0) = 0;
    *(undefined4 *)(param_1 + 0xe8) = 0x4000000;
    *(long *)(param_1 + 0xf0) = local_2d8;
    *(undefined4 *)(param_1 + 0xec) = local_2d0;
    *(long *)(param_1 + 0xf8) = lVar1;
    uVar5 = CONCAT71((int7)((ulong)lVar1 >> 8),1);
    if (((param_4 != 0 | bVar3) != 1) && (param_3[4] == 0)) {
      local_2a8 = local_2b8;
      uStack_2a0 = uStack_2b0;
      lVar1 = *param_3;
      pthread_rwlock_wrlock((pthread_rwlock_t *)&DAT_00145380);
      __src = PTR_DAT_00144ea8;
      if (DAT_00144eb8 <= PTR_DAT_00144eb0) {
        __n = (long)DAT_00144eb8 - (long)PTR_DAT_00144ea8;
        __dest = malloc(__n * 4);
        memcpy(__dest,__src,__n);
        if ((undefined8 *)__src != &DAT_001453c0) {
          free(__src);
        }
        PTR_DAT_00144eb0 = __dest + ((long)__n >> 5) * 0x20;
        DAT_00144eb8 = __dest + ((long)__n >> 3) * 0x20;
        PTR_DAT_00144ea8 = __dest;
      }
      *(long *)PTR_DAT_00144eb0 = lVar1;
      *(long *)((long)PTR_DAT_00144eb0 + 8) = local_2c0;
      *(long *)((long)PTR_DAT_00144eb0 + 0x10) = local_2a8;
      *(long *)((long)PTR_DAT_00144eb0 + 0x18) = local_2d8;
      PTR_DAT_00144eb0 = (undefined *)((long)PTR_DAT_00144eb0 + 0x20);
      pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00145380);
    }
  }
LAB_00139706:
  return uVar5 & 0xffffffff;
LAB_001394d5:
  lVar1 = plVar4[3];
  pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00145380);
  if (lVar1 == 0) {
LAB_00139526:
    bVar3 = 0;
  }
  else {
    bVar3 = FUN_00139890(*(undefined8 *)(param_1 + 8),param_2,param_3[2],param_3[3],lVar1,&local_2d8
                         ,local_290);
    if (bVar3 == 1) goto LAB_0013955f;
  }
  uVar5 = 0;
  cVar2 = FUN_00139890(*(undefined8 *)(param_1 + 8),param_2,param_3[2],param_3[3],0,&local_2d8,
                       local_290);
  if (cVar2 == '\0') goto LAB_00139706;
  goto LAB_0013955f;
}


// ==== FUN_00139890 @ 00139890

undefined8
FUN_00139890(undefined8 param_1,ulong param_2,uint *param_3,long param_4,uint *param_5,
            undefined8 *param_6,long param_7)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  uint *puVar4;
  uint *puVar5;
  ulong uVar6;
  uint *puVar7;
  uint *local_50;
  ulong local_48;
  undefined8 local_40;
  undefined8 *local_38;
  
  if (param_5 == (uint *)0x0) {
    param_5 = param_3;
  }
  puVar7 = (uint *)(param_4 + (long)param_3);
  if (param_4 == -1) {
    puVar7 = (uint *)0xffffffffffffffff;
  }
  if (param_5 < puVar7) {
    local_40 = param_1;
    local_38 = param_6;
    do {
      uVar6 = (ulong)*param_5;
      local_50 = param_5 + 1;
      if (uVar6 == 0xffffffff) {
        uVar6 = *(ulong *)(param_5 + 1);
        local_50 = param_5 + 3;
      }
      if (uVar6 == 0) {
        return 0;
      }
      puVar4 = (uint *)(uVar6 + (long)local_50);
      if ((((ulong)*local_50 != 0) &&
          (puVar5 = (uint *)((long)local_50 - (ulong)*local_50), param_3 <= puVar5)) &&
         (puVar5 < puVar7)) {
        lVar2 = FUN_00136740(local_40,puVar5,param_7);
        uVar3 = local_40;
        if (lVar2 == 0) {
          local_50 = local_50 + 1;
          local_48 = FUN_001383a0(local_40,&local_50,puVar4,*(undefined1 *)(param_7 + 0x18),0);
          lVar2 = FUN_001383a0(uVar3,&local_50,puVar4,*(byte *)(param_7 + 0x18) & 0xf);
          puVar1 = local_38;
          if ((local_48 < param_2) && (uVar6 = lVar2 + local_48, param_2 <= uVar6)) {
            local_38[5] = 0;
            if (*(char *)(param_7 + 0x31) != '\0') {
              lVar2 = FUN_00138640(&local_50,puVar4);
              puVar7 = local_50;
              puVar5 = (uint *)(lVar2 + (long)local_50);
              if ((*(byte *)(param_7 + 0x19) != 0xff) &&
                 (lVar2 = FUN_001383a0(local_40,&local_50,puVar4,*(byte *)(param_7 + 0x19) & 0xf,0),
                 lVar2 != 0)) {
                local_50 = puVar7;
                uVar3 = FUN_001383a0(local_40,&local_50,puVar4,*(undefined1 *)(param_7 + 0x19),0);
                puVar1[5] = uVar3;
              }
              local_50 = puVar5;
            }
            *puVar1 = param_5;
            puVar1[1] = (long)puVar4 - (long)param_5;
            puVar1[2] = local_50;
            puVar1[3] = local_48;
            puVar1[4] = uVar6;
            return 1;
          }
        }
      }
      param_5 = puVar4;
    } while (puVar4 < puVar7);
  }
  return 0;
}


// ==== FUN_00139a70 @ 00139a70

undefined8
FUN_00139a70(undefined8 param_1,ulong param_2,char *param_3,uint param_4,long param_5,
            undefined8 param_6)

{
  char cVar1;
  char cVar2;
  undefined8 uVar3;
  char *pcVar4;
  ulong uVar5;
  ulong uVar6;
  undefined8 uVar7;
  ulong uVar8;
  long lVar9;
  long lVar10;
  char *pcVar11;
  char *pcVar12;
  char *local_70;
  ulong local_68;
  long local_60;
  char *local_58;
  undefined8 local_50;
  char *local_48;
  undefined8 local_40;
  long local_38;
  
  local_68 = param_2;
  if (*param_3 == '\x01') {
    pcVar11 = param_3 + param_4;
    cVar1 = param_3[2];
    local_70 = param_3 + 4;
    cVar2 = param_3[3];
    FUN_001383a0(param_1,&local_70,pcVar11,param_3[1],param_3);
    if (cVar1 != -1) {
      local_48 = param_3;
      uVar5 = FUN_001383a0(param_1,&local_70,pcVar11,cVar1);
      if (uVar5 != 0) {
        local_58 = local_70;
        local_50 = param_1;
        local_40 = param_6;
        local_38 = param_5;
        local_60 = FUN_00139c60();
        lVar10 = 0;
        do {
          if (uVar5 < 2) {
            pcVar12 = local_58 + lVar10 * local_60;
            break;
          }
          uVar8 = uVar5 >> 1;
          lVar9 = uVar8 + lVar10;
          pcVar12 = local_58 + lVar9 * local_60;
          local_70 = pcVar12;
          uVar6 = FUN_001383a0(local_50,&local_70,pcVar11,cVar2,local_48);
          if (uVar6 < local_68) {
            uVar8 = uVar5 - uVar8;
            lVar10 = lVar9;
          }
          uVar5 = uVar8;
        } while (uVar6 != local_68);
        pcVar4 = local_48;
        uVar3 = local_50;
        local_70 = pcVar12;
        FUN_001383a0(local_50,&local_70,pcVar11,cVar2,local_48);
        uVar7 = FUN_001383a0(uVar3,&local_70,pcVar11,cVar2,pcVar4);
        lVar10 = local_38;
        lVar9 = FUN_001365b0(uVar3,uVar7,local_38,local_40,0);
        if (((lVar9 == 0) && (*(ulong *)(lVar10 + 0x18) <= local_68)) &&
           (local_68 < *(ulong *)(lVar10 + 0x20))) {
          return 1;
        }
      }
    }
  }
  else {
    fwrite("libunwind: Unsupported .eh_frame_hdr version\n",0x2d,1,(FILE *)0x146348);
  }
  return 0;
}


// ==== FUN_00139c60 @ 00139c60

undefined8 FUN_00139c60(uint param_1)

{
  undefined8 uVar1;
  
  uVar1 = 4;
  switch(param_1 & 0xf) {
  case 1:
  case 9:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getTableEntrySize",
            "Can\'t binary search on variable length encoded data.");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 2:
  case 10:
    goto switchD_00139c7f_caseD_2;
  case 3:
  case 0xb:
    uVar1 = 8;
switchD_00139c7f_caseD_2:
    return uVar1;
  case 4:
  case 0xc:
    return 0x10;
  default:
    fprintf((FILE *)0x146348,"libunwind: %s - %s\n","getTableEntrySize",
            "Unknown DWARF encoding for search table.");
    fflush((FILE *)0x146348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
}


// ==== FUN_00139d00 @ 00139d00

void FUN_00139d00(long param_1)

{
  long lVar1;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 *puVar2;
  
  lVar1 = *(long *)(param_1 + 0x38);
  puVar2 = (undefined8 *)(lVar1 + -0x10);
  *(undefined8 **)(param_1 + 0x38) = puVar2;
  *puVar2 = *(undefined8 *)(param_1 + 0x20);
  *(undefined8 *)(lVar1 + -8) = *(undefined8 *)(param_1 + 0x80);
  UNRECOVERED_JUMPTABLE = (code *)(*(undefined8 **)(param_1 + 0x38))[1];
                    /* WARNING: Could not recover jumptable at 0x00139d5b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)
            (**(undefined8 **)(param_1 + 0x38),*(undefined8 *)(param_1 + 0x28),
             *(undefined8 *)(param_1 + 0x18),UNRECOVERED_JUMPTABLE,*(undefined8 *)(param_1 + 0x40),
             *(undefined8 *)(param_1 + 0x48));
  return;
}


// ==== FUN_00139d60 @ 00139d60

undefined8
FUN_00139d60(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
            undefined8 param_5,undefined8 param_6)

{
  undefined8 in_RAX;
  undefined8 unaff_RBX;
  undefined8 unaff_RBP;
  undefined8 in_R10;
  undefined8 in_R11;
  undefined8 unaff_R12;
  undefined8 unaff_R13;
  undefined8 unaff_R14;
  undefined8 unaff_R15;
  undefined8 unaff_retaddr;
  
  *param_1 = in_RAX;
  param_1[1] = unaff_RBX;
  param_1[2] = param_4;
  param_1[3] = param_3;
  param_1[4] = param_1;
  param_1[5] = param_2;
  param_1[6] = unaff_RBP;
  param_1[7] = register0x00000020;
  param_1[7] = param_1[7] + 8;
  param_1[8] = param_5;
  param_1[9] = param_6;
  param_1[10] = in_R10;
  param_1[0xb] = in_R11;
  param_1[0xc] = unaff_R12;
  param_1[0xd] = unaff_R13;
  param_1[0xe] = unaff_R14;
  param_1[0xf] = unaff_R15;
  param_1[0x10] = unaff_retaddr;
  return 0;
}


// ==== FUN_00139dc0 @ 00139dc0

void FUN_00139dc0(void)

{
  (*(code *)(undefined *)0x0)();
  return;
}


// ==== __cxa_finalize @ 00139dd0

void __cxa_finalize(void)

{
  __cxa_finalize();
  return;
}


// ==== __cxa_atexit @ 00139de0

void __cxa_atexit(void)

{
  __cxa_atexit();
  return;
}


// ==== __stack_chk_fail @ 00139df0

void __stack_chk_fail(void)

{
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== strlen @ 00139e00

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
  size_t sVar1;
  
  sVar1 = strlen(__s);
  return sVar1;
}


// ==== memcpy @ 00139e10

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memcpy(__dest,__src,__n);
  return pvVar1;
}


// ==== localeconv @ 00139e20

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

lconv * localeconv(void)

{
  lconv *plVar1;
  
  plVar1 = localeconv();
  return plVar1;
}


// ==== memset @ 00139e30

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memset(__s,__c,__n);
  return pvVar1;
}


// ==== AMotionEvent_getAction @ 00139e40

void AMotionEvent_getAction(void)

{
  AMotionEvent_getAction();
  return;
}


// ==== AInputEvent_getDeviceId @ 00139e50

void AInputEvent_getDeviceId(void)

{
  AInputEvent_getDeviceId();
  return;
}


// ==== AInputEvent_getSource @ 00139e60

void AInputEvent_getSource(void)

{
  AInputEvent_getSource();
  return;
}


// ==== gettimeofday @ 00139e70

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
  int iVar1;
  
  iVar1 = gettimeofday(__tv,__tz);
  return iVar1;
}


// ==== AMotionEvent_getX @ 00139e80

void AMotionEvent_getX(void)

{
  AMotionEvent_getX();
  return;
}


// ==== AMotionEvent_getY @ 00139e90

void AMotionEvent_getY(void)

{
  AMotionEvent_getY();
  return;
}


// ==== AMotionEvent_getToolType @ 00139ea0

void AMotionEvent_getToolType(void)

{
  AMotionEvent_getToolType();
  return;
}


// ==== AMotionEvent_getPointerId @ 00139eb0

void AMotionEvent_getPointerId(void)

{
  AMotionEvent_getPointerId();
  return;
}


// ==== AMotionEvent_getPressure @ 00139ec0

void AMotionEvent_getPressure(void)

{
  AMotionEvent_getPressure();
  return;
}


// ==== AMotionEvent_getSize @ 00139ed0

void AMotionEvent_getSize(void)

{
  AMotionEvent_getSize();
  return;
}


// ==== AMotionEvent_getFlags @ 00139ee0

void AMotionEvent_getFlags(void)

{
  AMotionEvent_getFlags();
  return;
}


// ==== AMotionEvent_getPointerCount @ 00139ef0

void AMotionEvent_getPointerCount(void)

{
  AMotionEvent_getPointerCount();
  return;
}


// ==== AMotionEvent_getXPrecision @ 00139f00

void AMotionEvent_getXPrecision(void)

{
  AMotionEvent_getXPrecision();
  return;
}


// ==== AMotionEvent_getYPrecision @ 00139f10

void AMotionEvent_getYPrecision(void)

{
  AMotionEvent_getYPrecision();
  return;
}


// ==== AMotionEvent_getDownTime @ 00139f20

void AMotionEvent_getDownTime(void)

{
  AMotionEvent_getDownTime();
  return;
}


// ==== AMotionEvent_getEventTime @ 00139f30

void AMotionEvent_getEventTime(void)

{
  AMotionEvent_getEventTime();
  return;
}


// ==== memcmp @ 00139f40

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = memcmp(__s1,__s2,__n);
  return iVar1;
}


// ==== __vsnprintf_chk @ 00139f50

void __vsnprintf_chk(void)

{
  __vsnprintf_chk();
  return;
}


// ==== memmove @ 00139f60

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memmove(__dest,__src,__n);
  return pvVar1;
}


// ==== __android_log_print @ 00139f70

void __android_log_print(void)

{
  __android_log_print();
  return;
}


// ==== regcomp @ 00139f80

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
  int iVar1;
  
  iVar1 = regcomp(__preg,__pattern,__cflags);
  return iVar1;
}


// ==== malloc @ 00139f90

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = malloc(__size);
  return pvVar1;
}


// ==== strdup @ 00139fa0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
  char *pcVar1;
  
  pcVar1 = strdup(__s);
  return pcVar1;
}


// ==== pthread_mutex_lock @ 00139fb0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_lock(__mutex);
  return iVar1;
}


// ==== pthread_mutex_unlock @ 00139fc0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_unlock(__mutex);
  return iVar1;
}


// ==== free @ 00139fd0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== sigemptyset @ 00139fe0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigemptyset(sigset_t *__set)

{
  int iVar1;
  
  iVar1 = sigemptyset(__set);
  return iVar1;
}


// ==== sigaction @ 00139ff0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
  int iVar1;
  
  iVar1 = sigaction(__sig,__act,__oact);
  return iVar1;
}


// ==== pthread_create @ 0013a000

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
  int iVar1;
  
  iVar1 = pthread_create(__newthread,__attr,__start_routine,__arg);
  return iVar1;
}


// ==== pthread_cond_signal @ 0013a010

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_signal(__cond);
  return iVar1;
}


// ==== pthread_join @ 0013a020

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
  int iVar1;
  
  iVar1 = pthread_join(__th,__thread_return);
  return iVar1;
}


// ==== regfree @ 0013a030

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
  regfree(__preg);
  return;
}


// ==== siglongjmp @ 0013a040

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Subroutine does not return */
  siglongjmp(__env,__val);
}


// ==== pthread_self @ 0013a050

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
  pthread_t pVar1;
  
  pVar1 = pthread_self();
  return pVar1;
}


// ==== pthread_setname_np @ 0013a060

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
  int iVar1;
  
  iVar1 = pthread_setname_np(__target_thread,__name);
  return iVar1;
}


// ==== pthread_cond_wait @ 0013a070

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_cond_wait(__cond,__mutex);
  return iVar1;
}


// ==== fopen @ 0013a080

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
  FILE *pFVar1;
  
  pFVar1 = fopen(__filename,__modes);
  return pFVar1;
}


// ==== fgets @ 0013a090

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
  char *pcVar1;
  
  pcVar1 = fgets(__s,__n,__stream);
  return pcVar1;
}


// ==== sscanf @ 0013a0a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
  int iVar1;
  
  iVar1 = sscanf(__s,__format);
  return iVar1;
}


// ==== regexec @ 0013a0b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
  int iVar1;
  
  iVar1 = regexec(__preg,__string,__nmatch,__pmatch,__eflags);
  return iVar1;
}


// ==== strcmp @ 0013a0c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = strcmp(__s1,__s2);
  return iVar1;
}


// ==== fclose @ 0013a0d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fclose(__stream);
  return iVar1;
}


// ==== sigsetjmp @ 0013a0e0

void sigsetjmp(void)

{
  sigsetjmp();
  return;
}


// ==== getpagesize @ 0013a0f0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int getpagesize(void)

{
  int iVar1;
  
  iVar1 = getpagesize();
  return iVar1;
}


// ==== strstr @ 0013a100

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
  char *pcVar1;
  
  pcVar1 = strstr(__haystack,__needle);
  return pcVar1;
}


// ==== mprotect @ 0013a110

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
  int iVar1;
  
  iVar1 = mprotect(__addr,__len,__prot);
  return iVar1;
}


// ==== __errno @ 0013a120

void __errno(void)

{
  __errno();
  return;
}


// ==== pthread_cond_broadcast @ 0013a130

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_broadcast(__cond);
  return iVar1;
}


// ==== pthread_getspecific @ 0013a140

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
  void *pvVar1;
  
  pvVar1 = pthread_getspecific(__key);
  return pvVar1;
}


// ==== pthread_setspecific @ 0013a150

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
  int iVar1;
  
  iVar1 = pthread_setspecific(__key,__pointer);
  return iVar1;
}


// ==== pthread_cond_destroy @ 0013a160

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_destroy(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_destroy(__cond);
  return iVar1;
}


// ==== pthread_mutex_destroy @ 0013a170

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_destroy(__mutex);
  return iVar1;
}


// ==== posix_memalign @ 0013a180

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
  int iVar1;
  
  iVar1 = posix_memalign(__memptr,__alignment,__size);
  return iVar1;
}


// ==== __strlen_chk @ 0013a190

void __strlen_chk(void)

{
  __strlen_chk();
  return;
}


// ==== memchr @ 0013a1a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memchr(__s,__c,__n);
  return pvVar1;
}


// ==== strerror_r @ 0013a1b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
  char *pcVar1;
  
  pcVar1 = strerror_r(__errnum,__buf,__buflen);
  return pcVar1;
}


// ==== abort @ 0013a1c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== vsnprintf @ 0013a1d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vsnprintf(__s,__maxlen,__format,__arg);
  return iVar1;
}


// ==== pthread_key_create @ 0013a1e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
  int iVar1;
  
  iVar1 = pthread_key_create(__key,__destr_function);
  return iVar1;
}


// ==== syscall @ 0013a1f0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
  long lVar1;
  
  lVar1 = syscall(__sysno);
  return lVar1;
}


// ==== vfprintf @ 0013a200

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vfprintf(__s,__format,__arg);
  return iVar1;
}


// ==== fputc @ 0013a210

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
  int iVar1;
  
  iVar1 = fputc(__c,__stream);
  return iVar1;
}


// ==== vasprintf @ 0013a220

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vasprintf(__ptr,__f,__arg);
  return iVar1;
}


// ==== android_set_abort_message @ 0013a230

void android_set_abort_message(void)

{
  android_set_abort_message();
  return;
}


// ==== openlog @ 0013a240

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void openlog(char *__ident,int __option,int __facility)

{
  openlog(__ident,__option,__facility);
  return;
}


// ==== syslog @ 0013a250

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void syslog(int __pri,char *__fmt,...)

{
  syslog(__pri,__fmt);
  return;
}


// ==== closelog @ 0013a260

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void closelog(void)

{
  closelog();
  return;
}


// ==== realloc @ 0013a270

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
  void *pvVar1;
  
  pvVar1 = realloc(__ptr,__size);
  return pvVar1;
}


// ==== __memmove_chk @ 0013a280

void __memmove_chk(void)

{
  __memmove_chk();
  return;
}


// ==== pthread_once @ 0013a290

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
  int iVar1;
  
  iVar1 = pthread_once(__once_control,__init_routine);
  return iVar1;
}


// ==== pthread_key_delete @ 0013a2a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
  int iVar1;
  
  iVar1 = pthread_key_delete(__key);
  return iVar1;
}


// ==== fprintf @ 0013a2b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
  int iVar1;
  
  iVar1 = fprintf(__stream,__format);
  return iVar1;
}


// ==== fflush @ 0013a2c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fflush(__stream);
  return iVar1;
}


// ==== pthread_rwlock_wrlock @ 0013a2d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_wrlock(__rwlock);
  return iVar1;
}


// ==== pthread_rwlock_unlock @ 0013a2e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_unlock(__rwlock);
  return iVar1;
}


// ==== dl_iterate_phdr @ 0013a2f0

void dl_iterate_phdr(void)

{
  dl_iterate_phdr();
  return;
}


// ==== pthread_rwlock_rdlock @ 0013a300

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_rdlock(__rwlock);
  return iVar1;
}


// ==== fwrite @ 0013a310

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
  size_t sVar1;
  
  sVar1 = fwrite(__ptr,__size,__n,__s);
  return sVar1;
}


// ==== __cxa_finalize @ 00146000

/* WARNING: Control flow encountered bad instruction data */

void __cxa_finalize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __cxa_atexit @ 00146008

/* WARNING: Control flow encountered bad instruction data */

void __cxa_atexit(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __stack_chk_fail @ 00146010

/* WARNING: Control flow encountered bad instruction data */

void __stack_chk_fail(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strlen @ 00146018

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcpy @ 00146020

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== localeconv @ 00146028

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

lconv * localeconv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memset @ 00146030

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getAction @ 00146038

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getAction(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getDeviceId @ 00146040

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getDeviceId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getSource @ 00146048

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getSource(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== gettimeofday @ 00146050

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getX @ 00146058

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getX(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getY @ 00146060

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getY(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getToolType @ 00146068

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getToolType(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerId @ 00146070

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPressure @ 00146078

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPressure(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getSize @ 00146080

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getSize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getFlags @ 00146088

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getFlags(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerCount @ 00146090

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerCount(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getXPrecision @ 00146098

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getXPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getYPrecision @ 001460a0

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getYPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getDownTime @ 001460a8

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getDownTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getEventTime @ 001460b0

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getEventTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcmp @ 001460b8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __vsnprintf_chk @ 001460c0

/* WARNING: Control flow encountered bad instruction data */

void __vsnprintf_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memmove @ 001460c8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __android_log_print @ 001460d0

/* WARNING: Control flow encountered bad instruction data */

void __android_log_print(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regcomp @ 001460d8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== malloc @ 001460e0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strdup @ 001460e8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_lock @ 001460f0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_unlock @ 001460f8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== free @ 00146100

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigemptyset @ 00146108

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigemptyset(sigset_t *__set)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigaction @ 00146110

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_create @ 00146118

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_signal @ 00146120

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_join @ 00146128

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regfree @ 00146130

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== siglongjmp @ 00146138

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_self @ 00146140

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setname_np @ 00146148

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_wait @ 00146150

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fopen @ 00146158

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fgets @ 00146160

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sscanf @ 00146168

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regexec @ 00146170

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strcmp @ 00146178

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fclose @ 00146180

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigsetjmp @ 00146188

/* WARNING: Control flow encountered bad instruction data */

void sigsetjmp(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== getpagesize @ 00146190

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int getpagesize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strstr @ 00146198

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== mprotect @ 001461a0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __errno @ 001461a8

/* WARNING: Control flow encountered bad instruction data */

void __errno(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_broadcast @ 001461b0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_getspecific @ 001461b8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setspecific @ 001461c0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_destroy @ 001461c8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_destroy(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_destroy @ 001461d0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== posix_memalign @ 001461d8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __strlen_chk @ 001461e0

/* WARNING: Control flow encountered bad instruction data */

void __strlen_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memchr @ 001461e8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strerror_r @ 001461f0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== abort @ 001461f8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vsnprintf @ 00146200

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_create @ 00146208

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== syscall @ 00146210

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vfprintf @ 00146220

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fputc @ 00146228

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vasprintf @ 00146230

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== android_set_abort_message @ 00146238

/* WARNING: Control flow encountered bad instruction data */

void android_set_abort_message(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== openlog @ 00146240

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void openlog(char *__ident,int __option,int __facility)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== syslog @ 00146248

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void syslog(int __pri,char *__fmt,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== closelog @ 00146250

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void closelog(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== realloc @ 00146258

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __memmove_chk @ 00146260

/* WARNING: Control flow encountered bad instruction data */

void __memmove_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_once @ 00146268

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_delete @ 00146270

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fprintf @ 00146278

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fflush @ 00146280

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_wrlock @ 00146288

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_unlock @ 00146290

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== dl_iterate_phdr @ 00146298

/* WARNING: Control flow encountered bad instruction data */

void dl_iterate_phdr(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_rdlock @ 001462a0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fwrite @ 001462a8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


