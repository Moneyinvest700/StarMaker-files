// ==== _FINI_1 @ 00113a30

void _FINI_1(void)

{
  __cxa_finalize(&PTR_LOOP_0013c1e0);
  return;
}


// ==== FUN_00113a40 @ 00113a40

void FUN_00113a40(void)

{
  return;
}


// ==== _FINI_0 @ 00113a48

void _FINI_0(void)

{
  FUN_00133b10();
  return;
}


// ==== FUN_00113a50 @ 00113a50

void FUN_00113a50(code *UNRECOVERED_JUMPTABLE)

{
  if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00113a5c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}


// ==== FUN_00113a64 @ 00113a64

void FUN_00113a64(undefined8 param_1)

{
  __cxa_atexit(FUN_00113a50,param_1,&PTR_LOOP_0013c1e0);
  return;
}


// ==== FUN_00113a80 @ 00113a80

void FUN_00113a80(long param_1)

{
  void *__ptr;
  
  __ptr = *(void **)(param_1 + 0x60);
  if (__ptr != (void *)0x0) {
    *(void **)(param_1 + 0x68) = __ptr;
    free(__ptr);
  }
  FUN_0011b954(param_1 + 0x38);
  FUN_0011b87c(param_1 + 8);
  return;
}


// ==== FUN_001143f8 @ 001143f8

undefined8 * FUN_001143f8(char *param_1,char *param_2)

{
  long lVar1;
  ulong uVar2;
  undefined8 *puVar3;
  size_t __n;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  ulong *puVar7;
  long *plVar8;
  void *pvVar9;
  ulong uVar10;
  undefined8 local_78 [3];
  ulong local_60;
  ulong uStack_58;
  void *local_50;
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  if (*param_1 == '\0') {
    *param_1 = '\x01';
    puVar3 = (undefined8 *)FUN_0011b974(0x18);
    puVar3[2] = 0;
    *(undefined8 **)(param_1 + 8) = puVar3;
    puVar3[1] = 0;
    *puVar3 = puVar3 + 1;
LAB_0011445c:
    plVar8 = *(long **)(param_1 + 8);
    __n = strlen(param_2);
    if (__n < 0xfffffffffffffff0) {
      if (__n < 0x17) {
        pvVar9 = (void *)((ulong)&local_60 | 1);
        local_60 = CONCAT71(local_60._1_7_,(char)((int)__n << 1));
        if (__n != 0) goto LAB_001144b4;
      }
      else {
        uVar10 = __n + 0x10 & 0xfffffffffffffff0;
        pvVar9 = (void *)FUN_0011b974(uVar10);
        local_60 = uVar10 | 1;
        uStack_58 = __n;
        local_50 = pvVar9;
LAB_001144b4:
        memcpy(pvVar9,param_2,__n);
      }
      *(undefined1 *)((long)pvVar9 + __n) = 0;
                    /* try { // try from 001144c8 to 00114527 has its CatchHandler @ 00114620 */
      puVar4 = (undefined8 *)FUN_001165d4(plVar8,local_78,&local_60);
      puVar3 = (undefined8 *)*puVar4;
      if (puVar3 == (undefined8 *)0x0) {
        puVar3 = (undefined8 *)FUN_0011b974(0x48);
        pvVar9 = local_50;
        uVar2 = uStack_58;
        uVar10 = local_60;
        *(undefined1 *)(puVar3 + 7) = 0;
        uStack_58 = 0;
        local_50 = (void *)0x0;
        local_60 = 0;
        puVar3[6] = pvVar9;
        puVar3[5] = uVar2;
        puVar3[4] = uVar10;
        puVar3[8] = 0;
        *puVar3 = 0;
        puVar3[1] = 0;
        puVar3[2] = local_78[0];
        *puVar4 = puVar3;
        if (*(long *)*plVar8 == 0) {
          puVar4 = puVar3;
        }
        else {
          *plVar8 = *(long *)*plVar8;
          puVar4 = (undefined8 *)*puVar4;
        }
        FUN_001166ec(plVar8[1],puVar4);
        plVar8[2] = plVar8[2] + 1;
      }
      if ((local_60 & 1) != 0) {
        free(local_50);
      }
      if (*(long *)(lVar1 + 0x28) == local_48) {
        return puVar3 + 7;
      }
      goto LAB_0011461c;
    }
  }
  else {
    if (*param_1 == '\x01') goto LAB_0011445c;
    uVar5 = FUN_0011d504(0x20);
    uVar6 = FUN_00115c8c(param_1);
                    /* try { // try from 001145b0 to 001145b7 has its CatchHandler @ 00114688 */
    FUN_00115bbc(local_78,uVar6);
                    /* try { // try from 001145b8 to 001145cb has its CatchHandler @ 00114670 */
    puVar7 = (ulong *)FUN_0011c108(local_78,0,"cannot use operator[] with a string argument with ");
    local_50 = (void *)puVar7[2];
    uStack_58 = puVar7[1];
    local_60 = *puVar7;
    puVar7[1] = 0;
    puVar7[2] = 0;
    *puVar7 = 0;
                    /* try { // try from 001145e8 to 00114613 has its CatchHandler @ 0011463c */
    FUN_00115a40(uVar5,0x131,&local_60);
    FUN_0011d57c(uVar5,&PTR_PTR_0013c248,0x115c5c);
  }
  FUN_0011bb98(&local_60);
LAB_0011461c:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0011469c @ 0011469c

long FUN_0011469c(char *param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  long lVar5;
  ulong uVar6;
  undefined1 auStack_68 [24];
  undefined8 local_50;
  undefined8 uStack_48;
  undefined8 local_40;
  long local_38;
  
  lVar1 = tpidr_el0;
  local_38 = *(long *)(lVar1 + 0x28);
  if (*param_1 == '\0') {
    *param_1 = '\x02';
    puVar2 = (undefined8 *)FUN_0011b974(0x18);
    puVar2[1] = 0;
    puVar2[2] = 0;
    *puVar2 = 0;
    *(undefined8 **)(param_1 + 8) = puVar2;
    uVar6 = puVar2[1];
    if (uVar6 < (ulong)puVar2[2]) goto LAB_001146f8;
LAB_00114728:
    FUN_00116a6c(puVar2,param_2);
    lVar5 = puVar2[1];
  }
  else {
    if (*param_1 != '\x02') {
      uVar3 = FUN_0011d504(0x20);
      uVar4 = FUN_00115c8c(param_1);
                    /* try { // try from 00114778 to 0011477f has its CatchHandler @ 00114840 */
      FUN_00115bbc(auStack_68,uVar4);
                    /* try { // try from 00114780 to 00114793 has its CatchHandler @ 00114828 */
      puVar2 = (undefined8 *)FUN_0011c108(auStack_68,0,"cannot use emplace_back() with ");
      local_40 = puVar2[2];
      uStack_48 = puVar2[1];
      local_50 = *puVar2;
      puVar2[1] = 0;
      puVar2[2] = 0;
      *puVar2 = 0;
                    /* try { // try from 001147b0 to 001147db has its CatchHandler @ 001147f0 */
      FUN_00115a40(uVar3,0x137,&local_50);
      FUN_0011d57c(uVar3,&PTR_PTR_0013c248,0x115c5c);
      goto LAB_001147dc;
    }
    puVar2 = *(undefined8 **)(param_1 + 8);
    uVar6 = puVar2[1];
    if ((ulong)puVar2[2] <= uVar6) goto LAB_00114728;
LAB_001146f8:
                    /* try { // try from 001146f8 to 00114703 has its CatchHandler @ 001147e0 */
    FUN_00115f84(uVar6,param_2);
    lVar5 = uVar6 + 0x10;
    puVar2[1] = lVar5;
  }
  if (*(long *)(lVar1 + 0x28) == local_38) {
    return lVar5 + -0x10;
  }
LAB_001147dc:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00114854 @ 00114854

void FUN_00114854(undefined8 *param_1,undefined8 param_2,int param_3,undefined1 param_4,uint param_5
                 ,undefined4 param_6)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  long *plVar4;
  long lVar5;
  long *local_2e8;
  long *local_2e0;
  undefined8 local_2d8;
  undefined8 uStack_2d0;
  undefined8 local_2c8;
  undefined8 uStack_2c0;
  undefined8 local_2b8;
  undefined8 uStack_2b0;
  undefined8 local_2a8;
  undefined8 uStack_2a0;
  lconv *local_298;
  char local_290;
  char local_28f;
  undefined8 local_28e;
  undefined8 uStack_286;
  undefined8 local_27e;
  undefined8 uStack_276;
  undefined8 local_26e;
  undefined8 uStack_266;
  undefined8 local_25e;
  undefined8 uStack_256;
  undefined8 local_24e;
  undefined8 uStack_246;
  undefined8 local_23e;
  undefined8 uStack_236;
  undefined8 local_22e;
  undefined8 uStack_226;
  undefined8 local_21e;
  undefined8 uStack_216;
  undefined8 local_20e;
  undefined8 uStack_206;
  undefined8 local_1fe;
  undefined8 uStack_1f6;
  undefined8 local_1ee;
  undefined8 uStack_1e6;
  undefined8 local_1de;
  undefined8 uStack_1d6;
  undefined8 uStack_1ce;
  undefined8 uStack_1c6;
  undefined8 local_1be;
  undefined8 uStack_1b6;
  undefined8 uStack_1ae;
  undefined8 uStack_1a6;
  undefined8 local_19e;
  undefined8 uStack_196;
  undefined8 uStack_18e;
  undefined8 uStack_186;
  undefined8 local_17e;
  undefined8 uStack_176;
  undefined8 uStack_16e;
  undefined8 uStack_166;
  undefined8 local_15e;
  undefined8 uStack_156;
  undefined8 uStack_14e;
  undefined8 uStack_146;
  undefined8 local_13e;
  undefined8 uStack_136;
  undefined8 uStack_12e;
  undefined8 uStack_126;
  undefined8 local_11e;
  undefined8 uStack_116;
  undefined8 uStack_10e;
  undefined8 uStack_106;
  undefined8 local_fe;
  undefined8 uStack_f6;
  undefined8 uStack_ee;
  undefined8 uStack_e6;
  undefined8 local_de;
  undefined8 uStack_d6;
  undefined8 uStack_ce;
  undefined8 uStack_c6;
  undefined8 local_be;
  undefined8 uStack_b6;
  undefined8 uStack_ae;
  undefined8 uStack_a6;
  undefined8 local_9e;
  undefined8 uStack_96;
  undefined1 local_8e;
  ulong local_88;
  undefined8 uStack_80;
  undefined8 *local_78;
  undefined4 local_70;
  long local_68;
  
  lVar1 = tpidr_el0;
  local_68 = *(long *)(lVar1 + 0x28);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
                    /* try { // try from 001148a0 to 001148a7 has its CatchHandler @ 00114aec */
  plVar4 = (long *)FUN_0011b974(0x28);
  plVar4[2] = 0;
  plVar4[4] = (long)param_1;
  *plVar4 = (long)&PTR_LAB_0013c2c0;
  plVar4[1] = 0;
  plVar4[3] = (long)&PTR_LAB_0013c2f8;
  FUN_00133d70(1);
  uStack_2d0 = 0;
  local_2d8 = 0;
  uStack_2c0 = 0;
  local_2c8 = 0;
  uStack_2b0 = 0;
  local_2b8 = 0;
  uStack_2a0 = 0;
  local_2a8 = 0;
  local_2e8 = plVar4 + 3;
  local_2e0 = plVar4;
                    /* try { // try from 00114900 to 0011499b has its CatchHandler @ 00114af4 */
  local_298 = localeconv();
  local_290 = '\0';
  if (local_298->thousands_sep != (char *)0x0) {
    local_290 = *local_298->thousands_sep;
  }
  local_28f = '\0';
  if (local_298->decimal_point != (char *)0x0) {
    local_28f = *local_298->decimal_point;
  }
  uStack_1d6 = 0;
  local_1de = 0;
  uStack_1c6 = 0;
  uStack_1ce = 0;
  uStack_1b6 = 0;
  local_1be = 0;
  uStack_1a6 = 0;
  uStack_1ae = 0;
  uStack_196 = 0;
  local_19e = 0;
  uStack_186 = 0;
  uStack_18e = 0;
  uStack_176 = 0;
  local_17e = 0;
  uStack_166 = 0;
  uStack_16e = 0;
  uStack_156 = 0;
  local_15e = 0;
  uStack_146 = 0;
  uStack_14e = 0;
  uStack_136 = 0;
  local_13e = 0;
  uStack_126 = 0;
  uStack_12e = 0;
  uStack_116 = 0;
  local_11e = 0;
  uStack_106 = 0;
  uStack_10e = 0;
  uStack_f6 = 0;
  local_fe = 0;
  uStack_e6 = 0;
  uStack_ee = 0;
  uStack_d6 = 0;
  local_de = 0;
  uStack_c6 = 0;
  uStack_ce = 0;
  uStack_b6 = 0;
  local_be = 0;
  uStack_a6 = 0;
  uStack_ae = 0;
  uStack_96 = 0;
  local_9e = 0;
  uStack_286 = 0;
  local_28e = 0;
  uStack_276 = 0;
  local_27e = 0;
  uStack_266 = 0;
  local_26e = 0;
  uStack_256 = 0;
  local_25e = 0;
  uStack_246 = 0;
  local_24e = 0;
  uStack_236 = 0;
  local_23e = 0;
  uStack_226 = 0;
  local_22e = 0;
  uStack_216 = 0;
  local_21e = 0;
  uStack_206 = 0;
  local_20e = 0;
  uStack_1f6 = 0;
  local_1fe = 0;
  uStack_1e6 = 0;
  local_1ee = 0;
  local_8e = param_4;
  local_78 = (undefined8 *)FUN_0011b974(0x210);
  *(undefined1 *)(local_78 + 0x40) = 0;
  uStack_80 = 0x200;
  local_88 = 0x211;
  uVar2 = CONCAT17(param_4,CONCAT16(param_4,CONCAT15(param_4,CONCAT14(param_4,CONCAT13(param_4,
                                                  CONCAT12(param_4,CONCAT11(param_4,param_4)))))));
  uVar3 = CONCAT17(param_4,CONCAT16(param_4,CONCAT15(param_4,CONCAT14(param_4,CONCAT13(param_4,
                                                  CONCAT12(param_4,CONCAT11(param_4,param_4)))))));
  local_78[1] = uVar3;
  *local_78 = uVar2;
  local_78[3] = uVar3;
  local_78[2] = uVar2;
  local_78[5] = uVar3;
  local_78[4] = uVar2;
  local_78[7] = uVar3;
  local_78[6] = uVar2;
  local_78[9] = uVar3;
  local_78[8] = uVar2;
  local_78[0xb] = uVar3;
  local_78[10] = uVar2;
  local_78[0xd] = uVar3;
  local_78[0xc] = uVar2;
  local_78[0xf] = uVar3;
  local_78[0xe] = uVar2;
  local_78[0x11] = uVar3;
  local_78[0x10] = uVar2;
  local_78[0x13] = uVar3;
  local_78[0x12] = uVar2;
  local_78[0x15] = uVar3;
  local_78[0x14] = uVar2;
  local_78[0x17] = uVar3;
  local_78[0x16] = uVar2;
  local_78[0x19] = uVar3;
  local_78[0x18] = uVar2;
  local_78[0x1b] = uVar3;
  local_78[0x1a] = uVar2;
  local_78[0x1d] = uVar3;
  local_78[0x1c] = uVar2;
  local_78[0x1f] = uVar3;
  local_78[0x1e] = uVar2;
  local_78[0x21] = uVar3;
  local_78[0x20] = uVar2;
  local_78[0x23] = uVar3;
  local_78[0x22] = uVar2;
  local_78[0x25] = uVar3;
  local_78[0x24] = uVar2;
  local_78[0x27] = uVar3;
  local_78[0x26] = uVar2;
  local_78[0x29] = uVar3;
  local_78[0x28] = uVar2;
  local_78[0x2b] = uVar3;
  local_78[0x2a] = uVar2;
  local_78[0x2d] = uVar3;
  local_78[0x2c] = uVar2;
  local_78[0x2f] = uVar3;
  local_78[0x2e] = uVar2;
  local_78[0x31] = uVar3;
  local_78[0x30] = uVar2;
  local_78[0x33] = uVar3;
  local_78[0x32] = uVar2;
  local_78[0x35] = uVar3;
  local_78[0x34] = uVar2;
  local_78[0x37] = uVar3;
  local_78[0x36] = uVar2;
  local_78[0x39] = uVar3;
  local_78[0x38] = uVar2;
  local_78[0x3b] = uVar3;
  local_78[0x3a] = uVar2;
  local_78[0x3d] = uVar3;
  local_78[0x3c] = uVar2;
  local_78[0x3f] = uVar3;
  local_78[0x3e] = uVar2;
  local_70 = param_6;
  lVar5 = FUN_00133da0(0xffffffffffffffff,plVar4 + 1);
  if (lVar5 == 0) {
    (**(code **)(*plVar4 + 0x10))(plVar4);
    FUN_0011b8a4(plVar4);
  }
  if (param_3 < 0) {
                    /* try { // try from 00114a4c to 00114a67 has its CatchHandler @ 00114adc */
    FUN_00116ca4(&local_2e8,param_2,0,param_5 & 1,0,0);
  }
  else {
                    /* try { // try from 00114a10 to 00114a2b has its CatchHandler @ 00114adc */
    FUN_00116ca4(&local_2e8,param_2,1,param_5 & 1,param_3,0);
  }
  if ((local_88 & 1) != 0) {
    free(local_78);
  }
  plVar4 = local_2e0;
  if ((local_2e0 != (long *)0x0) &&
     (lVar5 = FUN_00133da0(0xffffffffffffffff,local_2e0 + 1), lVar5 == 0)) {
    (**(code **)(*plVar4 + 0x10))(plVar4);
    FUN_0011b8a4(plVar4);
  }
  if (*(long *)(lVar1 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== JNI_OnLoad @ 00114d8c

undefined4 JNI_OnLoad(long *param_1)

{
  long lVar1;
  byte bVar2;
  int iVar3;
  long lVar4;
  long lVar5;
  uint uVar6;
  undefined4 uVar7;
  long *local_98;
  char local_90 [48];
  char local_60 [40];
  long local_38;
  
  lVar1 = tpidr_el0;
  local_38 = *(long *)(lVar1 + 0x28);
  uVar7 = 0x10004;
  iVar3 = (**(code **)(*param_1 + 0x30))(param_1,&local_98,0x10004);
  if (iVar3 == 0) {
    lVar4 = (**(code **)(*local_98 + 0x30))(local_98,"com/netease/mobsec/xt/a");
    lVar5 = (**(code **)(*local_98 + 0x78))(local_98);
    if (lVar5 == 0) {
      if ((lVar4 != 0) &&
         (iVar3 = (**(code **)(*local_98 + 0x6b8))(local_98,lVar4,&PTR_DAT_0013c1e8,3), -1 < iVar3))
      {
        uVar6 = 0xda;
        local_60[8] = '\x1b';
        local_60[9] = '.';
        local_60[0] = -0x26;
        local_60[1] = -0x59;
        local_60[2] = -0x14;
        local_60[3] = -0x2c;
        local_60[4] = -0x15;
        local_60[5] = -0x2e;
        local_60[6] = -0x2f;
        local_60[7] = '\x18';
        local_60[0x12] = 'u';
        local_60[0x13] = ';';
        local_60[0x14] = -0x76;
        local_60[0x15] = '\x12';
        local_60[0x16] = -7;
        local_60[0x17] = 'G';
        local_60[0x18] = 'J';
        local_60[0x19] = -0x3c;
        local_60[10] = 'E';
        local_60[0xb] = 'P';
        local_60[0xc] = -0x31;
        local_60[0xd] = -0x1a;
        local_60[0xe] = '\x0e';
        local_60[0xf] = -0x6c;
        local_60[0x10] = -0x76;
        local_60[0x11] = '=';
        lVar4 = 0;
        while( true ) {
          uVar6 = uVar6 ^ (uint)lVar4 ^ 0xffffff9d;
          uVar6 = 2 - (uVar6 >> 3 & 0x1f | uVar6 << 5);
          bVar2 = (byte)lVar4;
          local_60[lVar4] =
               (-((((byte)(uVar6 >> 7) & 1 | (char)uVar6 * '\x02') ^ bVar2) + bVar2) ^ 0xe2) - bVar2
          ;
          if (lVar4 == 0x19) break;
          uVar6 = (uint)(byte)local_60[lVar4 + 1];
          lVar4 = lVar4 + 1;
        }
        uVar6 = 0xf3;
        local_90[8] = '\x13';
        local_90[9] = '\v';
        local_90[10] = 'o';
        local_90[0xb] = -0x55;
        local_90[0xc] = -0x65;
        local_90[0xd] = -0x75;
        local_90[0xe] = '\x13';
        local_90[0xf] = -0x60;
        local_90[0] = -0xd;
        local_90[1] = -0x31;
        local_90[2] = -0x79;
        local_90[3] = 'T';
        local_90[4] = '{';
        local_90[5] = '\x0f';
        local_90[6] = '\x7f';
        local_90[7] = -0x48;
        local_90[0x18] = 0xb7;
        local_90[0x10] = 'K';
        local_90[0x11] = '3';
        local_90[0x12] = 'G';
        local_90[0x13] = -0x25;
        local_90[0x14] = -0x50;
        local_90[0x15] = 'k';
        local_90[0x16] = 'G';
        local_90[0x17] = -0x40;
        local_90[0x21] = -0x65;
        local_90[0x22] = -0x41;
        local_90[0x23] = -0x7d;
        local_90[0x24] = '#';
        local_90[0x25] = '8';
        local_90[0x26] = 's';
        local_90[0x27] = -8;
        local_90[0x28] = -0x2e;
        local_90[0x19] = 'c';
        local_90[0x1a] = 'S';
        local_90[0x1b] = '_';
        local_90[0x1c] = -0x44;
        local_90[0x1d] = -0x11;
        local_90[0x1e] = -0x28;
        local_90[0x1f] = 'S';
        local_90[0x20] = 0x3b;
        lVar4 = 0;
        while( true ) {
          uVar6 = uVar6 - 1 ^ 0x5d;
          uVar6 = -(((uVar6 >> 1 & 0x7f | uVar6 << 7) ^ (uint)lVar4) + (uint)lVar4) - 10;
          uVar6 = (uVar6 >> 7 & 1 | uVar6 * 2) + 4;
          local_90[lVar4] = (((byte)(uVar6 >> 2) & 0x3f | (char)uVar6 * '@') ^ 0xce) + 1;
          if (lVar4 == 0x28) break;
          uVar6 = (uint)(byte)local_90[lVar4 + 1];
          lVar4 = lVar4 + 1;
        }
        iVar3 = thunk_FUN_00118f5c(local_60,local_90,&LAB_00114b3c,&DAT_00142e68);
        if (iVar3 == 0) {
          thunk_FUN_00119944(1);
          iVar3 = thunk_FUN_001190a8(0);
          if (iVar3 == 0) {
            thunk_FUN_001192d8();
            DAT_00142e60 = 1;
          }
        }
        goto LAB_00114e18;
      }
    }
    else {
      (**(code **)(*local_98 + 0x88))(local_98);
    }
  }
  uVar7 = 0xffffffff;
LAB_00114e18:
  if (*(long *)(lVar1 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar7;
}


// ==== FUN_00114fb8 @ 00114fb8

void FUN_00114fb8(void)

{
  FUN_0011d6a4();
                    /* WARNING: Subroutine does not return */
  FUN_0011dc6c();
}


// ==== FUN_00114fc4 @ 00114fc4

void FUN_00114fc4(long *param_1,char param_2)

{
  char cVar1;
  long lVar2;
  bool bVar3;
  long lVar4;
  long *plVar5;
  undefined1 *puVar6;
  undefined1 *puVar7;
  long *plVar8;
  undefined1 *puVar9;
  undefined1 *puVar10;
  ulong uVar11;
  undefined1 *puVar12;
  ulong uVar13;
  undefined8 *puVar14;
  byte *__ptr;
  undefined1 *puVar15;
  undefined1 *puVar16;
  long lVar17;
  undefined8 *puVar18;
  undefined1 *puVar19;
  undefined1 *puVar20;
  long *plVar21;
  undefined8 *local_88;
  undefined1 *local_80;
  undefined1 *local_78;
  undefined1 *local_70;
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  local_80 = (undefined1 *)0x0;
  local_78 = (undefined1 *)0x0;
  local_70 = (undefined1 *)0x0;
  if (param_2 == '\x01') {
    puVar18 = (undefined8 *)*param_1;
    uVar13 = puVar18[2];
    if (uVar13 == 0) {
      plVar21 = (long *)*puVar18;
      if (plVar21 != puVar18 + 1) goto LAB_001150d4;
    }
    else {
      if (uVar13 >> 0x3c != 0) {
                    /* WARNING: Subroutine does not return */
        FUN_001157bc("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
                    /* try { // try from 001150b8 to 001150bb has its CatchHandler @ 001156b4 */
      local_80 = (undefined1 *)FUN_0011b974(uVar13 << 4);
      local_70 = local_80 + uVar13 * 0x10;
      plVar21 = (long *)*puVar18;
      local_78 = local_80;
      if (plVar21 != puVar18 + 1) {
LAB_001150d4:
        local_80 = local_78;
        if (local_70 <= local_78) goto LAB_00115100;
        do {
          *local_78 = (char)plVar21[7];
          *(long *)(local_78 + 8) = plVar21[8];
          *(undefined1 *)(plVar21 + 7) = 0;
          plVar21[8] = 0;
          local_78 = local_78 + 0x10;
          while( true ) {
            plVar5 = (long *)plVar21[1];
            if ((long *)plVar21[1] == (long *)0x0) {
              plVar5 = plVar21 + 2;
              bVar3 = *(long **)*plVar5 != plVar21;
              plVar21 = (long *)*plVar5;
              if (bVar3) {
                do {
                  lVar17 = *plVar5;
                  plVar5 = (long *)(lVar17 + 0x10);
                  plVar21 = (long *)*plVar5;
                } while (*plVar21 != lVar17);
              }
            }
            else {
              do {
                plVar21 = plVar5;
                plVar5 = (long *)*plVar21;
              } while ((long *)*plVar21 != (long *)0x0);
            }
            if (plVar21 == puVar18 + 1) goto LAB_001151a0;
            if (local_78 < local_70) break;
LAB_00115100:
                    /* try { // try from 00115104 to 0011510b has its CatchHandler @ 001156b8 */
            FUN_0011583c(&local_80,plVar21 + 7);
          }
        } while( true );
      }
    }
  }
  else if (param_2 == '\x02') {
    puVar18 = (undefined8 *)*param_1;
    puVar15 = (undefined1 *)*puVar18;
    puVar19 = (undefined1 *)puVar18[1];
    lVar17 = (long)puVar19 - (long)puVar15;
    if (lVar17 == 0) {
      if (puVar15 != puVar19) goto LAB_0011504c;
    }
    else {
      if (lVar17 < 0) {
                    /* try { // try from 00115698 to 001156af has its CatchHandler @ 001156b4 */
                    /* WARNING: Subroutine does not return */
        FUN_001157bc("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
                    /* try { // try from 00115028 to 0011502f has its CatchHandler @ 001156b4 */
      local_80 = (undefined1 *)FUN_0011b974(lVar17);
      local_70 = local_80 + (lVar17 >> 4) * 0x10;
      puVar15 = (undefined1 *)*puVar18;
      puVar19 = (undefined1 *)puVar18[1];
      local_78 = local_80;
      if (puVar15 != puVar19) {
LAB_0011504c:
        local_80 = local_78;
        if (local_70 <= local_78) goto LAB_00115078;
        do {
          *local_78 = *puVar15;
          *(undefined8 *)(local_78 + 8) = *(undefined8 *)(puVar15 + 8);
          *puVar15 = 0;
          *(undefined8 *)(puVar15 + 8) = 0;
          local_78 = local_78 + 0x10;
          while( true ) {
            puVar15 = puVar15 + 0x10;
            if (puVar15 == puVar19) goto LAB_001151a0;
            if (local_78 < local_70) break;
LAB_00115078:
                    /* try { // try from 00115078 to 00115083 has its CatchHandler @ 001156bc */
            FUN_0011583c(&local_80,puVar15);
          }
        } while( true );
      }
    }
  }
LAB_001151a0:
  if (local_80 != local_78) {
    do {
      cVar1 = local_78[-0x10];
      local_88 = *(undefined8 **)(local_78 + -8);
      local_78[-0x10] = 0;
      *(undefined8 *)(local_78 + -8) = 0;
      puVar15 = local_78 + -0x10;
      FUN_00114fc4(local_78 + -8,*puVar15);
      local_78 = puVar15;
      if (cVar1 == '\x01') {
        plVar5 = local_88 + 1;
        plVar21 = (long *)*local_88;
        if (plVar21 != plVar5) {
          if (local_70 <= puVar15) goto LAB_001153a4;
          do {
            *local_78 = (char)plVar21[7];
            *(long *)(local_78 + 8) = plVar21[8];
            *(undefined1 *)(plVar21 + 7) = 0;
            plVar21[8] = 0;
            local_78 = local_78 + 0x10;
            while( true ) {
              plVar8 = (long *)plVar21[1];
              if ((long *)plVar21[1] == (long *)0x0) {
                plVar8 = plVar21 + 2;
                bVar3 = *(long **)*plVar8 != plVar21;
                plVar21 = (long *)*plVar8;
                if (bVar3) {
                  do {
                    lVar17 = *plVar8;
                    plVar8 = (long *)(lVar17 + 0x10);
                    plVar21 = (long *)*plVar8;
                  } while (*plVar21 != lVar17);
                }
              }
              else {
                do {
                  plVar21 = plVar8;
                  plVar8 = (long *)*plVar21;
                } while ((long *)*plVar21 != (long *)0x0);
              }
              if (plVar21 == plVar5) goto LAB_001154ec;
              if (local_78 < local_70) break;
LAB_001153a4:
              puVar15 = local_78;
              puVar19 = local_80;
              lVar17 = (long)local_78 - (long)local_80 >> 4;
              uVar13 = lVar17 + 1;
              if (uVar13 >> 0x3c != 0) {
                    /* try { // try from 00115670 to 00115677 has its CatchHandler @ 001156d0 */
                FUN_0011d4bc(&local_80);
                goto LAB_00115678;
              }
              uVar11 = (long)local_70 - (long)local_80 >> 3;
              if (uVar13 <= uVar11) {
                uVar13 = uVar11;
              }
              if (0x7fffffffffffffef < (ulong)((long)local_70 - (long)local_80)) {
                uVar13 = 0xfffffffffffffff;
              }
              if (uVar13 >> 0x3c != 0) goto LAB_00115680;
                    /* try { // try from 001153e0 to 001153e3 has its CatchHandler @ 001156c8 */
              lVar4 = FUN_0011b974(uVar13 << 4);
              puVar6 = local_80;
              puVar9 = (undefined1 *)(lVar4 + lVar17 * 0x10);
              puVar20 = puVar9 + 0x10;
              *puVar9 = (char)plVar21[7];
              local_70 = (undefined1 *)(lVar4 + uVar13 * 0x10);
              *(long *)(puVar9 + 8) = plVar21[8];
              *(undefined1 *)(plVar21 + 7) = 0;
              plVar21[8] = 0;
              if (puVar15 != puVar19) {
                do {
                  puVar16 = puVar15 + -0x10;
                  puVar10 = puVar9 + -0x10;
                  *puVar10 = *puVar16;
                  *(undefined8 *)(puVar9 + -8) = *(undefined8 *)(puVar15 + -8);
                  *puVar16 = 0;
                  *(undefined8 *)(puVar15 + -8) = 0;
                  puVar9 = puVar10;
                  puVar15 = puVar16;
                } while (puVar16 != puVar19);
                puVar15 = puVar6;
                if (local_78 != local_80) {
                  puVar19 = local_78 + -8;
                  local_80 = puVar10;
                  local_78 = puVar20;
                  do {
                    puVar10 = puVar19 + -8;
                    FUN_00114fc4(puVar19,*puVar10);
                    puVar19 = puVar19 + -0x10;
                    puVar9 = local_80;
                    puVar20 = local_78;
                  } while (puVar10 != puVar6);
                }
              }
              local_78 = puVar20;
              local_80 = puVar9;
              if (puVar15 != (undefined1 *)0x0) {
                free(puVar15);
              }
            }
          } while( true );
        }
LAB_001154ec:
        puVar18 = local_88;
        puVar14 = local_88 + 1;
        FUN_00115970(local_88,*puVar14);
        *puVar18 = puVar14;
        puVar18[2] = 0;
        *puVar14 = 0;
      }
      else if (cVar1 == '\x02') {
        puVar19 = (undefined1 *)*local_88;
        puVar18 = local_88 + 1;
        puVar20 = (undefined1 *)*puVar18;
        if (puVar19 != puVar20) {
          if (local_70 <= puVar15) goto LAB_00115264;
          do {
            *local_78 = *puVar19;
            *(undefined8 *)(local_78 + 8) = *(undefined8 *)(puVar19 + 8);
            *puVar19 = 0;
            *(undefined8 *)(puVar19 + 8) = 0;
            local_78 = local_78 + 0x10;
            while( true ) {
              puVar19 = puVar19 + 0x10;
              if (puVar19 == puVar20) {
                puVar19 = (undefined1 *)*local_88;
                puVar18 = local_88 + 1;
                if ((undefined1 *)*puVar18 != puVar19) {
                  puVar15 = (undefined1 *)*puVar18 + -8;
                  do {
                    puVar20 = puVar15 + -8;
                    FUN_00114fc4(puVar15,*puVar20);
                    puVar15 = puVar15 + -0x10;
                  } while (puVar20 != puVar19);
                }
                goto LAB_001151c4;
              }
              if (local_78 < local_70) break;
LAB_00115264:
              puVar15 = local_80;
              lVar17 = (long)local_78 - (long)local_80 >> 4;
              uVar13 = lVar17 + 1;
              if (uVar13 >> 0x3c != 0) {
LAB_00115678:
                    /* try { // try from 00115678 to 0011567f has its CatchHandler @ 001156cc */
                FUN_0011d4bc(&local_80);
LAB_00115680:
                    /* try { // try from 00115680 to 0011568b has its CatchHandler @ 001156d0 */
                    /* WARNING: Subroutine does not return */
                FUN_001157bc("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size"
                            );
              }
              uVar11 = (long)local_70 - (long)local_80 >> 3;
              if (uVar13 <= uVar11) {
                uVar13 = uVar11;
              }
              if (0x7fffffffffffffef < (ulong)((long)local_70 - (long)local_80)) {
                uVar13 = 0xfffffffffffffff;
              }
              if (uVar13 >> 0x3c != 0) {
                    /* try { // try from 0011568c to 00115697 has its CatchHandler @ 001156cc */
                    /* WARNING: Subroutine does not return */
                FUN_001157bc("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size"
                            );
              }
                    /* try { // try from 001152a0 to 001152a3 has its CatchHandler @ 001156c4 */
              lVar4 = FUN_0011b974(uVar13 << 4);
              puVar10 = local_80;
              puVar6 = (undefined1 *)(lVar4 + lVar17 * 0x10);
              puVar9 = puVar6 + 0x10;
              *puVar6 = *puVar19;
              *(undefined8 *)(puVar6 + 8) = *(undefined8 *)(puVar19 + 8);
              local_70 = (undefined1 *)(lVar4 + uVar13 * 0x10);
              *puVar19 = 0;
              *(undefined8 *)(puVar19 + 8) = 0;
              puVar16 = local_78;
              if (local_78 != puVar15) {
                do {
                  puVar12 = puVar16 + -0x10;
                  puVar7 = puVar6 + -0x10;
                  *puVar7 = *puVar12;
                  *(undefined8 *)(puVar6 + -8) = *(undefined8 *)(puVar16 + -8);
                  *puVar12 = 0;
                  *(undefined8 *)(puVar16 + -8) = 0;
                  puVar6 = puVar7;
                  puVar16 = puVar12;
                } while (puVar12 != puVar15);
                puVar15 = puVar10;
                if (local_78 != local_80) {
                  puVar16 = local_78 + -8;
                  local_80 = puVar7;
                  local_78 = puVar9;
                  do {
                    puVar7 = puVar16 + -8;
                    FUN_00114fc4(puVar16,*puVar7);
                    puVar16 = puVar16 + -0x10;
                    puVar6 = local_80;
                    puVar9 = local_78;
                  } while (puVar7 != puVar10);
                }
              }
              local_78 = puVar9;
              local_80 = puVar6;
              if (puVar15 != (undefined1 *)0x0) {
                free(puVar15);
              }
            }
          } while( true );
        }
LAB_001151c4:
        *puVar18 = puVar19;
      }
      FUN_00114fc4(&local_88,cVar1);
    } while (local_80 != local_78);
  }
  switch(param_2) {
  case '\x01':
    FUN_00115970(*param_1,*(undefined8 *)(*param_1 + 8));
LAB_001155f0:
    __ptr = (byte *)*param_1;
    break;
  case '\x02':
    __ptr = (byte *)*param_1;
    puVar19 = *(undefined1 **)__ptr;
    if (puVar19 != (undefined1 *)0x0) {
      puVar15 = puVar19;
      if (*(undefined1 **)(__ptr + 8) != puVar19) {
        puVar15 = *(undefined1 **)(__ptr + 8) + -8;
        do {
          puVar20 = puVar15 + -8;
          FUN_00114fc4(puVar15,*puVar20);
          puVar15 = puVar15 + -0x10;
        } while (puVar20 != puVar19);
        puVar15 = *(undefined1 **)__ptr;
      }
      *(undefined1 **)(__ptr + 8) = puVar19;
LAB_001155ec:
      free(puVar15);
      goto LAB_001155f0;
    }
    break;
  case '\x03':
    __ptr = (byte *)*param_1;
    if ((*__ptr & 1) != 0) {
      puVar15 = *(undefined1 **)(__ptr + 0x10);
      goto LAB_001155ec;
    }
    break;
  default:
    goto switchD_0011556c_caseD_4;
  case '\b':
    __ptr = (byte *)*param_1;
    puVar15 = *(undefined1 **)__ptr;
    if (puVar15 != (undefined1 *)0x0) {
      *(undefined1 **)(__ptr + 8) = puVar15;
      goto LAB_001155ec;
    }
  }
  free(__ptr);
switchD_0011556c_caseD_4:
  puVar15 = local_80;
  if (local_80 != (undefined1 *)0x0) {
    if (local_78 != local_80) {
      puVar19 = local_78 + -8;
      do {
        puVar20 = puVar19 + -8;
        FUN_00114fc4(puVar19,*puVar20);
        puVar19 = puVar19 + -0x10;
      } while (puVar20 != puVar15);
    }
    local_78 = puVar15;
    free(local_80);
  }
  if (*(long *)(lVar2 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_001156f0 @ 001156f0

void FUN_001156f0(undefined8 *param_1)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  puVar2 = (undefined1 *)*param_1;
  if (puVar2 == (undefined1 *)0x0) {
    return;
  }
  puVar1 = puVar2;
  if ((undefined1 *)param_1[1] != puVar2) {
    puVar1 = (undefined1 *)param_1[1] + -8;
    do {
      puVar3 = puVar1 + -8;
      FUN_00114fc4(puVar1,*puVar3);
      puVar1 = puVar1 + -0x10;
    } while (puVar3 != puVar2);
    puVar1 = (undefined1 *)*param_1;
  }
  param_1[1] = puVar2;
  free(puVar1);
  return;
}


// ==== FUN_00115764 @ 00115764

void FUN_00115764(undefined8 *param_1)

{
  long lVar1;
  undefined1 uVar2;
  long lVar3;
  
  lVar1 = param_1[1];
  lVar3 = param_1[2];
  while (lVar3 != lVar1) {
    uVar2 = *(undefined1 *)(lVar3 + -0x10);
    param_1[2] = (undefined1 *)(lVar3 + -0x10);
    FUN_00114fc4(lVar3 + -8,uVar2);
    lVar3 = param_1[2];
  }
  if ((void *)*param_1 == (void *)0x0) {
    return;
  }
  free((void *)*param_1);
  return;
}


// ==== FUN_001157bc @ 001157bc

void FUN_001157bc(undefined8 param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = FUN_0011d504(0x10);
                    /* try { // try from 001157d8 to 001157df has its CatchHandler @ 001157f8 */
  FUN_0011580c(uVar1,param_1);
  uVar2 = FUN_0011d57c(uVar1,&PTR_PTR_0013e728,FUN_001336f4);
                    /* catch() { ... } // from try @ 001157d8 with catch @ 001157f8 */
  FUN_0011d558(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_00134000(uVar2);
}


// ==== FUN_0011580c @ 0011580c

void FUN_0011580c(undefined8 *param_1)

{
  FUN_0011b9e8();
  *param_1 = &PTR_FUN_0013e710;
  return;
}


// ==== FUN_0011583c @ 0011583c

void FUN_0011583c(long *param_1,undefined1 *param_2)

{
  ulong uVar1;
  undefined1 *__ptr;
  long lVar2;
  ulong uVar3;
  undefined1 *puVar4;
  undefined1 *puVar5;
  ulong uVar6;
  undefined1 *puVar7;
  undefined8 uVar8;
  undefined1 *puVar9;
  long lVar10;
  undefined1 *puVar11;
  
  lVar10 = param_1[1] - *param_1 >> 4;
  uVar1 = lVar10 + 1;
  if (uVar1 >> 0x3c == 0) {
    uVar3 = param_1[2] - *param_1;
    uVar6 = (long)uVar3 >> 3;
    if (uVar1 <= uVar6) {
      uVar1 = uVar6;
    }
    if (0x7fffffffffffffef < uVar3) {
      uVar1 = 0xfffffffffffffff;
    }
    if (uVar1 >> 0x3c == 0) {
      lVar2 = FUN_0011b974(uVar1 * 0x10);
      uVar8 = *(undefined8 *)(param_2 + 8);
      *(undefined8 *)(param_2 + 8) = 0;
      puVar11 = (undefined1 *)(lVar2 + lVar10 * 0x10);
      __ptr = (undefined1 *)*param_1;
      puVar9 = (undefined1 *)param_1[1];
      lVar2 = lVar2 + uVar1 * 0x10;
      *puVar11 = *param_2;
      *(undefined8 *)(puVar11 + 8) = uVar8;
      *param_2 = 0;
      puVar4 = puVar11;
      if (puVar9 == __ptr) {
        *param_1 = (long)puVar11;
        param_1[1] = (long)(puVar11 + 0x10);
        param_1[2] = lVar2;
      }
      else {
        do {
          puVar7 = puVar9 + -0x10;
          puVar5 = puVar4 + -0x10;
          *puVar5 = *puVar7;
          *(undefined8 *)(puVar4 + -8) = *(undefined8 *)(puVar9 + -8);
          *puVar7 = 0;
          *(undefined8 *)(puVar9 + -8) = 0;
          puVar4 = puVar5;
          puVar9 = puVar7;
        } while (puVar7 != __ptr);
        __ptr = (undefined1 *)*param_1;
        puVar9 = (undefined1 *)param_1[1];
        *param_1 = (long)puVar5;
        param_1[1] = (long)(puVar11 + 0x10);
        param_1[2] = lVar2;
        if (puVar9 != __ptr) {
          puVar9 = puVar9 + -8;
          do {
            puVar11 = puVar9 + -8;
            FUN_00114fc4(puVar9,*puVar11);
            puVar9 = puVar9 + -0x10;
          } while (puVar11 != __ptr);
        }
      }
      if (__ptr == (undefined1 *)0x0) {
        return;
      }
      free(__ptr);
      return;
    }
  }
  else {
    FUN_0011d4bc(param_1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_001157bc("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
}


// ==== FUN_00115970 @ 00115970

void FUN_00115970(undefined8 param_1,undefined8 *param_2)

{
  if (param_2 == (undefined8 *)0x0) {
    return;
  }
  FUN_00115970(param_1,*param_2);
  FUN_00115970(param_1,param_2[1]);
  FUN_00114fc4(param_2 + 8,*(undefined1 *)(param_2 + 7));
  if ((*(byte *)(param_2 + 4) & 1) != 0) {
    free((void *)param_2[6]);
  }
  free(param_2);
  return;
}


// ==== FUN_001159cc @ 001159cc

void FUN_001159cc(undefined8 *param_1)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  puVar2 = (undefined1 *)*param_1;
  if (puVar2 == (undefined1 *)0x0) {
    return;
  }
  puVar1 = puVar2;
  if ((undefined1 *)param_1[1] != puVar2) {
    puVar1 = (undefined1 *)param_1[1] + -8;
    do {
      puVar3 = puVar1 + -8;
      FUN_00114fc4(puVar1,*puVar3);
      puVar1 = puVar1 + -0x10;
    } while (puVar3 != puVar2);
    puVar1 = (undefined1 *)*param_1;
  }
  param_1[1] = puVar2;
  free(puVar1);
  return;
}


// ==== FUN_00115a40 @ 00115a40

void FUN_00115a40(undefined8 *param_1,undefined4 param_2,byte *param_3)

{
  void *pvVar1;
  ulong uVar2;
  byte *pbVar3;
  long lVar4;
  ulong *puVar5;
  byte local_80;
  char local_7f [15];
  void *local_70;
  byte local_68 [16];
  void *local_58;
  ulong local_50;
  ulong uStack_48;
  void *local_40;
  long local_38;
  
  lVar4 = tpidr_el0;
  local_38 = *(long *)(lVar4 + 0x28);
  builtin_strncpy(local_7f,"type_error",0xb);
  local_80 = 0x14;
                    /* try { // try from 00115a90 to 00115a9f has its CatchHandler @ 00115ba0 */
  FUN_00115d08(local_68,&local_80,param_2);
  uVar2 = *(ulong *)(param_3 + 8);
  pbVar3 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar3 = param_3 + 1;
    uVar2 = (ulong)(*param_3 >> 1);
  }
                    /* try { // try from 00115ab8 to 00115abf has its CatchHandler @ 00115b88 */
  puVar5 = (ulong *)FUN_0011c03c(local_68,pbVar3,uVar2);
  local_40 = (void *)puVar5[2];
  uStack_48 = puVar5[1];
  local_50 = *puVar5;
  puVar5[1] = 0;
  puVar5[2] = 0;
  *puVar5 = 0;
  if ((local_68[0] & 1) != 0) {
    free(local_58);
  }
  if ((local_80 & 1) != 0) {
    free(local_70);
  }
  *(undefined4 *)(param_1 + 1) = param_2;
  pvVar1 = (void *)((ulong)&local_50 | 1);
  if ((local_50 & 1) != 0) {
    pvVar1 = local_40;
  }
  *param_1 = &DAT_0013c298;
                    /* try { // try from 00115b24 to 00115b27 has its CatchHandler @ 00115b6c */
  FUN_0011bb0c(param_1 + 2,pvVar1);
  *param_1 = &DAT_0013c270;
  if ((local_50 & 1) != 0) {
    free(local_40);
  }
  if (*(long *)(lVar4 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00115bbc @ 00115bbc

void FUN_00115bbc(ulong *param_1,char *param_2)

{
  size_t __n;
  undefined8 *puVar1;
  undefined1 *__dest;
  ulong uVar2;
  
  __n = strlen(param_2);
  if (0xffffffffffffffef < __n) {
    puVar1 = (undefined8 *)FUN_0011bb98(param_1);
    *puVar1 = &DAT_0013c298;
    FUN_001337b8(puVar1 + 2);
    FUN_001336a4(puVar1);
    return;
  }
  if (__n < 0x17) {
    __dest = (undefined1 *)((long)param_1 + 1);
    *(char *)param_1 = (char)((int)__n << 1);
    if (__n == 0) {
      *__dest = 0;
      return;
    }
  }
  else {
    uVar2 = __n + 0x10 & 0xfffffffffffffff0;
    __dest = (undefined1 *)FUN_0011b974(uVar2);
    param_1[1] = __n;
    param_1[2] = (ulong)__dest;
    *param_1 = uVar2 | 1;
  }
  memcpy(__dest,param_2,__n);
  __dest[__n] = 0;
  return;
}


// ==== FUN_00115c8c @ 00115c8c

char * FUN_00115c8c(char *param_1)

{
  if ((ulong)(long)*param_1 < 10) {
    return &DAT_0010be48 + *(int *)(&DAT_0010be48 + (long)*param_1 * 4);
  }
  return "number";
}


// ==== FUN_00115cb8 @ 00115cb8

void FUN_00115cb8(undefined8 *param_1,undefined8 param_2,byte *param_3)

{
  ulong uVar1;
  byte *pbVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  puVar3 = (undefined8 *)FUN_0011c03c(param_2,pbVar2,uVar1);
  uVar6 = puVar3[1];
  uVar5 = *puVar3;
  *puVar3 = 0;
  puVar3[1] = 0;
  uVar4 = puVar3[2];
  puVar3[2] = 0;
  param_1[1] = uVar6;
  *param_1 = uVar5;
  param_1[2] = uVar4;
  return;
}


// ==== FUN_00115d08 @ 00115d08

void FUN_00115d08(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  ulong *puVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  byte local_a0 [8];
  ulong local_98;
  void *local_90;
  byte local_88 [16];
  void *local_78;
  ulong local_70;
  ulong uStack_68;
  void *local_60;
  ulong local_50;
  ulong uStack_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_0011c428(local_88,"[json.exception.",param_2);
                    /* try { // try from 00115d44 to 00115d53 has its CatchHandler @ 00115ef0 */
  puVar4 = (ulong *)FUN_0011c2e4(local_88,&DAT_00109caa);
  local_60 = (void *)puVar4[2];
  uStack_68 = puVar4[1];
  local_70 = *puVar4;
  puVar4[1] = 0;
  puVar4[2] = 0;
  *puVar4 = 0;
                    /* try { // try from 00115d6c to 00115d7b has its CatchHandler @ 00115ed0 */
  FUN_0011c5b4(local_a0,param_3);
  uVar1 = (ulong)(local_a0[0] >> 1);
  pvVar3 = (void *)((ulong)local_a0 | 1);
  if ((local_a0[0] & 1) != 0) {
    uVar1 = local_98;
    pvVar3 = local_90;
  }
                    /* try { // try from 00115d98 to 00115d9f has its CatchHandler @ 00115eb0 */
  puVar4 = (ulong *)FUN_0011c03c(&local_70,pvVar3,uVar1);
  local_40 = (void *)puVar4[2];
  uStack_48 = puVar4[1];
  local_50 = *puVar4;
  puVar4[1] = 0;
  puVar4[2] = 0;
  *puVar4 = 0;
                    /* try { // try from 00115db8 to 00115dc7 has its CatchHandler @ 00115e70 */
  puVar5 = (undefined8 *)FUN_0011c2e4(&local_50,&DAT_00109f59);
  uVar6 = puVar5[2];
  uVar8 = puVar5[1];
  uVar7 = *puVar5;
  *puVar5 = 0;
  puVar5[1] = 0;
  puVar5[2] = 0;
  param_1[2] = uVar6;
  param_1[1] = uVar8;
  *param_1 = uVar7;
  if ((local_50 & 1) != 0) {
    free(local_40);
  }
  if ((local_a0[0] & 1) != 0) {
    free(local_90);
  }
  if ((local_70 & 1) != 0) {
    free(local_60);
  }
  if ((local_88[0] & 1) == 0) {
    if (*(long *)(lVar2 + 0x28) != local_38) {
LAB_00115e6c:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  else {
    free(local_78);
    if (*(long *)(lVar2 + 0x28) != local_38) goto LAB_00115e6c;
  }
  return;
}


// ==== FUN_00115f84 @ 00115f84

void FUN_00115f84(undefined1 *param_1,undefined1 *param_2)

{
  long lVar1;
  undefined1 uVar2;
  long *__ptr;
  long lVar3;
  long *plVar4;
  long lVar5;
  undefined8 uVar6;
  long *plVar7;
  undefined8 *puVar8;
  long *plVar9;
  
  uVar2 = *param_2;
  *(undefined8 *)(param_1 + 8) = 0;
  *param_1 = uVar2;
  switch(uVar2) {
  case 1:
    puVar8 = *(undefined8 **)(param_2 + 8);
    __ptr = (long *)FUN_0011b974(0x18);
    __ptr[2] = 0;
    plVar7 = __ptr + 1;
    *plVar7 = 0;
    *__ptr = (long)plVar7;
    plVar9 = (long *)*puVar8;
    while (plVar9 != puVar8 + 1) {
                    /* try { // try from 00116040 to 0011604f has its CatchHandler @ 0011614c */
      FUN_0011616c(__ptr,plVar7,plVar9 + 4,plVar9 + 4);
      plVar4 = (long *)plVar9[1];
      if ((long *)plVar9[1] == (long *)0x0) {
        plVar4 = plVar9 + 2;
        if (*(long **)*plVar4 == plVar9) {
          plVar9 = (long *)*plVar4;
        }
        else {
          do {
            lVar5 = *plVar4;
            plVar4 = (long *)(lVar5 + 0x10);
            plVar9 = (long *)*plVar4;
          } while (*plVar9 != lVar5);
        }
      }
      else {
        do {
          plVar9 = plVar4;
          plVar4 = (long *)*plVar9;
        } while ((long *)*plVar9 != (long *)0x0);
      }
    }
    break;
  case 2:
    plVar9 = *(long **)(param_2 + 8);
    __ptr = (long *)FUN_0011b974(0x18);
    __ptr[1] = 0;
    __ptr[2] = 0;
    *__ptr = 0;
    lVar5 = plVar9[1] - *plVar9;
    if (lVar5 != 0) {
      if (lVar5 < 0) {
                    /* try { // try from 00116120 to 00116127 has its CatchHandler @ 00116130 */
        uVar6 = FUN_0011d4bc(__ptr);
                    /* catch() { ... } // from try @ 00115fe4 with catch @ 00116128 */
        free(__ptr);
                    /* WARNING: Subroutine does not return */
        FUN_00134000(uVar6);
      }
                    /* try { // try from 001160c0 to 001160c7 has its CatchHandler @ 00116130 */
      lVar3 = FUN_0011b974(lVar5);
      *__ptr = lVar3;
      __ptr[1] = lVar3;
      __ptr[2] = lVar3 + (lVar5 >> 4) * 0x10;
      lVar1 = plVar9[1];
      for (lVar5 = *plVar9; lVar5 != lVar1; lVar5 = lVar5 + 0x10) {
                    /* try { // try from 001160e8 to 001160f3 has its CatchHandler @ 00116138 */
        FUN_00115f84(lVar3,lVar5);
        lVar3 = lVar3 + 0x10;
      }
      __ptr[1] = lVar3;
    }
    break;
  case 3:
    uVar6 = *(undefined8 *)(param_2 + 8);
    __ptr = (long *)FUN_0011b974(0x18);
                    /* try { // try from 00115fe4 to 00115feb has its CatchHandler @ 00116128 */
    FUN_0011bd5c(__ptr,uVar6);
    break;
  case 4:
    __ptr = (long *)(ulong)(byte)param_2[8];
    break;
  case 5:
  case 6:
  case 7:
    __ptr = *(long **)(param_2 + 8);
    break;
  case 8:
    __ptr = (long *)FUN_0011688c(*(undefined8 *)(param_2 + 8));
    break;
  default:
    goto switchD_00115fc8_default;
  }
  *(long **)(param_1 + 8) = __ptr;
switchD_00115fc8_default:
  return;
}


// ==== FUN_0011616c @ 0011616c

void FUN_0011616c(long *param_1,undefined8 param_2,undefined8 param_3,long param_4)

{
  long lVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined1 auStack_70 [8];
  undefined8 local_68;
  undefined8 *local_60;
  long *plStack_58;
  undefined1 local_50;
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  puVar2 = (undefined8 *)FUN_00116280(param_1,param_2,&local_68,auStack_70,param_3);
  puVar3 = (undefined8 *)*puVar2;
  if ((undefined8 *)*puVar2 == (undefined8 *)0x0) {
    puVar3 = (undefined8 *)FUN_0011b974(0x48);
    local_50 = 0;
    local_60 = puVar3;
    plStack_58 = param_1 + 1;
                    /* try { // try from 001161d0 to 001161db has its CatchHandler @ 0011626c */
    FUN_0011bd5c(puVar3 + 4,param_4);
                    /* try { // try from 001161e4 to 001161e7 has its CatchHandler @ 00116254 */
    FUN_00115f84(puVar3 + 7,param_4 + 0x18);
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = local_68;
    *puVar2 = puVar3;
    if (*(long *)*param_1 != 0) {
      *param_1 = *(long *)*param_1;
      puVar3 = (undefined8 *)*puVar2;
    }
    FUN_001166ec(param_1[1],puVar3);
    param_1[2] = param_1[2] + 1;
    puVar3 = local_60;
  }
  if (*(long *)(lVar1 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar3);
  }
  return;
}


// ==== FUN_00116280 @ 00116280

long * FUN_00116280(undefined8 *param_1,long *param_2,long *param_3,long *param_4,byte *param_5)

{
  ulong uVar1;
  ulong uVar2;
  size_t sVar3;
  byte bVar4;
  byte bVar5;
  long *plVar6;
  int iVar7;
  long *plVar8;
  long lVar9;
  void *pvVar10;
  byte *pbVar11;
  long *plVar12;
  
  if (param_1 + 1 == param_2) {
LAB_0011634c:
    plVar8 = (long *)*param_2;
    if ((long *)*param_1 == param_2) {
      plVar12 = param_2;
    }
    else {
      if (plVar8 == (long *)0x0) {
        plVar12 = param_2 + 2;
        if (*(long **)*plVar12 == param_2) {
          do {
            lVar9 = *plVar12;
            plVar12 = (long *)(lVar9 + 0x10);
          } while (*(long *)*plVar12 == lVar9);
        }
        plVar12 = (long *)*plVar12;
      }
      else {
        plVar6 = plVar8;
        do {
          plVar12 = plVar6;
          plVar6 = (long *)plVar12[1];
        } while ((long *)plVar12[1] != (long *)0x0);
      }
      bVar5 = *param_5;
      bVar4 = *(byte *)(plVar12 + 4);
      uVar2 = (ulong)(bVar5 >> 1);
      if ((bVar5 & 1) != 0) {
        uVar2 = *(ulong *)(param_5 + 8);
      }
      uVar1 = (ulong)(bVar4 >> 1);
      if ((bVar4 & 1) != 0) {
        uVar1 = plVar12[5];
      }
      sVar3 = uVar2;
      if (uVar1 <= uVar2) {
        sVar3 = uVar1;
      }
      if (sVar3 != 0) {
        pbVar11 = *(byte **)(param_5 + 0x10);
        pvVar10 = (void *)plVar12[6];
        if ((bVar5 & 1) == 0) {
          pbVar11 = param_5 + 1;
        }
        if ((bVar4 & 1) == 0) {
          pvVar10 = (void *)((long)plVar12 + 0x21);
        }
        iVar7 = memcmp(pvVar10,pbVar11,sVar3);
        if (iVar7 != 0) {
          if (-1 < iVar7) goto LAB_00116460;
          goto LAB_00116490;
        }
      }
      if (uVar2 <= uVar1) goto LAB_00116460;
    }
LAB_00116490:
    if (plVar8 != (long *)0x0) {
      *param_3 = (long)plVar12;
      return plVar12 + 1;
    }
    param_4 = param_2;
LAB_001164a4:
    *param_3 = (long)param_2;
  }
  else {
    bVar5 = *param_5;
    bVar4 = *(byte *)(param_2 + 4);
    uVar2 = (ulong)(bVar4 >> 1);
    if ((bVar4 & 1) != 0) {
      uVar2 = param_2[5];
    }
    uVar1 = (ulong)(bVar5 >> 1);
    if ((bVar5 & 1) != 0) {
      uVar1 = *(ulong *)(param_5 + 8);
    }
    sVar3 = uVar2;
    if (uVar1 <= uVar2) {
      sVar3 = uVar1;
    }
    if (sVar3 == 0) {
      if (uVar1 < uVar2) goto LAB_0011634c;
LAB_001163a8:
      if (uVar2 < uVar1) {
LAB_001163b0:
        plVar8 = (long *)param_2[1];
        if ((long *)param_2[1] == (long *)0x0) {
          plVar8 = param_2 + 2;
          plVar12 = (long *)*plVar8;
          if ((long *)*plVar12 != param_2) {
            do {
              lVar9 = *plVar8;
              plVar8 = (long *)(lVar9 + 0x10);
              plVar12 = (long *)*plVar8;
            } while (*plVar12 != lVar9);
          }
        }
        else {
          do {
            plVar12 = plVar8;
            plVar8 = (long *)*plVar12;
          } while ((long *)*plVar12 != (long *)0x0);
        }
        if (plVar12 != param_1 + 1) {
          bVar4 = *(byte *)(plVar12 + 4);
          uVar2 = (ulong)(bVar4 >> 1);
          if ((bVar4 & 1) != 0) {
            uVar2 = plVar12[5];
          }
          sVar3 = uVar2;
          if (uVar1 <= uVar2) {
            sVar3 = uVar1;
          }
          if (sVar3 != 0) {
            pvVar10 = (void *)plVar12[6];
            pbVar11 = *(byte **)(param_5 + 0x10);
            if ((bVar4 & 1) == 0) {
              pvVar10 = (void *)((long)plVar12 + 0x21);
            }
            if ((bVar5 & 1) == 0) {
              pbVar11 = param_5 + 1;
            }
            iVar7 = memcmp(pbVar11,pvVar10,sVar3);
            if (iVar7 != 0) {
              if (-1 < iVar7) goto LAB_00116460;
              goto LAB_00116544;
            }
          }
          if (uVar2 <= uVar1) {
LAB_00116460:
            plVar8 = (long *)FUN_001165d4(param_1,param_3,param_5);
            return plVar8;
          }
        }
LAB_00116544:
        if (param_2[1] != 0) {
          *param_3 = (long)plVar12;
          return plVar12;
        }
        param_4 = param_2 + 1;
        goto LAB_001164a4;
      }
    }
    else {
      pvVar10 = (void *)param_2[6];
      pbVar11 = *(byte **)(param_5 + 0x10);
      if ((bVar4 & 1) == 0) {
        pvVar10 = (void *)((long)param_2 + 0x21);
      }
      if ((bVar5 & 1) == 0) {
        pbVar11 = param_5 + 1;
      }
      iVar7 = memcmp(pbVar11,pvVar10,sVar3);
      if (iVar7 == 0) {
        if (uVar1 < uVar2) goto LAB_0011634c;
      }
      else if (iVar7 < 0) goto LAB_0011634c;
      iVar7 = memcmp(pvVar10,pbVar11,sVar3);
      if (iVar7 == 0) goto LAB_001163a8;
      if (iVar7 < 0) goto LAB_001163b0;
    }
    *param_3 = (long)param_2;
    *param_4 = (long)param_2;
  }
  return param_4;
}


// ==== FUN_0011657c @ 0011657c

void FUN_0011657c(undefined8 *param_1)

{
  void *__ptr;
  
  __ptr = (void *)*param_1;
  *param_1 = 0;
  if (__ptr == (void *)0x0) {
    return;
  }
  if ((*(char *)(param_1 + 2) != '\0') &&
     (FUN_00114fc4((long)__ptr + 0x40,*(undefined1 *)((long)__ptr + 0x38)),
     (*(byte *)((long)__ptr + 0x20) & 1) != 0)) {
    free(*(void **)((long)__ptr + 0x30));
  }
  free(__ptr);
  return;
}


// ==== FUN_001165d4 @ 001165d4

long * FUN_001165d4(long param_1,undefined8 *param_2,byte *param_3)

{
  ulong uVar1;
  size_t __n;
  byte *__s1;
  byte bVar2;
  int iVar3;
  long *plVar4;
  void *__s2;
  ulong uVar5;
  long *plVar6;
  long *plVar7;
  
  plVar6 = (long *)(param_1 + 8);
  plVar7 = (long *)*plVar6;
  if (plVar7 == (long *)0x0) {
    *param_2 = plVar6;
    return plVar6;
  }
  __s1 = *(byte **)(param_3 + 0x10);
  plVar6 = (long *)(param_1 + 8);
  uVar5 = (ulong)(*param_3 >> 1);
  if ((*param_3 & 1) == 0) {
    __s1 = param_3 + 1;
  }
  else {
    uVar5 = *(ulong *)(param_3 + 8);
  }
  do {
    bVar2 = *(byte *)(plVar7 + 4);
    uVar1 = (ulong)(bVar2 >> 1);
    if ((bVar2 & 1) != 0) {
      uVar1 = plVar7[5];
    }
    __n = uVar1;
    if (uVar5 <= uVar1) {
      __n = uVar5;
    }
    if (__n == 0) {
      if (uVar5 < uVar1) goto LAB_00116694;
LAB_0011661c:
      if (uVar5 <= uVar1) {
LAB_001166cc:
        *param_2 = plVar7;
        return plVar6;
      }
LAB_00116624:
      plVar6 = plVar7 + 1;
      plVar4 = (long *)*plVar6;
      if (plVar4 == (long *)0x0) goto LAB_001166cc;
    }
    else {
      __s2 = (void *)plVar7[6];
      if ((bVar2 & 1) == 0) {
        __s2 = (void *)((long)plVar7 + 0x21);
      }
      iVar3 = memcmp(__s1,__s2,__n);
      if (iVar3 == 0) {
        if (uVar1 <= uVar5) goto LAB_001166a4;
      }
      else if (-1 < iVar3) {
LAB_001166a4:
        iVar3 = memcmp(__s2,__s1,__n);
        if (iVar3 == 0) goto LAB_0011661c;
        if (iVar3 < 0) goto LAB_00116624;
        goto LAB_001166cc;
      }
LAB_00116694:
      plVar4 = (long *)*plVar7;
      plVar6 = plVar7;
      if (plVar4 == (long *)0x0) goto LAB_001166cc;
    }
    plVar7 = plVar4;
  } while( true );
}


// ==== FUN_001166ec @ 001166ec

void FUN_001166ec(long *param_1,long *param_2)

{
  bool bVar1;
  long *plVar2;
  long *plVar3;
  long lVar4;
  long *plVar5;
  
  bVar1 = param_2 == param_1;
  *(bool *)(param_2 + 3) = bVar1;
  do {
    if (bVar1) {
      return;
    }
    plVar3 = (long *)param_2[2];
    if ((char)plVar3[3] != '\0') {
      return;
    }
    plVar2 = (long *)plVar3[2];
    plVar5 = (long *)*plVar2;
    if (plVar5 == plVar3) {
      if ((plVar2[1] == 0) || (plVar5 = (long *)(plVar2[1] + 0x18), *(char *)plVar5 != '\0')) {
        if ((long *)*plVar3 != param_2) {
          plVar5 = (long *)plVar3[1];
          lVar4 = *plVar5;
          plVar3[1] = lVar4;
          if (lVar4 != 0) {
            *(long **)(lVar4 + 0x10) = plVar3;
            plVar2 = (long *)plVar3[2];
          }
          plVar5[2] = (long)plVar2;
          ((undefined8 *)plVar3[2])[*(long **)plVar3[2] != plVar3] = plVar5;
          plVar3[2] = (long)plVar5;
          plVar2 = (long *)plVar5[2];
          *plVar5 = (long)plVar3;
          plVar3 = plVar5;
        }
        plVar5 = (long *)*plVar2;
        lVar4 = plVar5[1];
        *(undefined1 *)(plVar3 + 3) = 1;
        *(undefined1 *)(plVar2 + 3) = 0;
        *plVar2 = lVar4;
        if (lVar4 != 0) {
          *(long **)(lVar4 + 0x10) = plVar2;
        }
        plVar3 = plVar2 + 2;
        plVar5[2] = *plVar3;
        ((undefined8 *)*plVar3)[*(long **)*plVar3 != plVar2] = plVar5;
        plVar5[1] = (long)plVar2;
        goto LAB_00116884;
      }
    }
    else if ((plVar5 == (long *)0x0) || (plVar5 = plVar5 + 3, (char)*plVar5 != '\0')) {
      if ((long *)*plVar3 == param_2) {
        lVar4 = param_2[1];
        *plVar3 = lVar4;
        if (lVar4 != 0) {
          *(long **)(lVar4 + 0x10) = plVar3;
          plVar2 = (long *)plVar3[2];
        }
        param_2[2] = (long)plVar2;
        ((undefined8 *)plVar3[2])[*(long **)plVar3[2] != plVar3] = param_2;
        plVar3[2] = (long)param_2;
        plVar2 = (long *)param_2[2];
        param_2[1] = (long)plVar3;
      }
      else {
        param_2 = plVar3;
      }
      plVar5 = (long *)plVar2[1];
      lVar4 = *plVar5;
      *(undefined1 *)(param_2 + 3) = 1;
      *(undefined1 *)(plVar2 + 3) = 0;
      plVar2[1] = lVar4;
      if (lVar4 != 0) {
        *(long **)(lVar4 + 0x10) = plVar2;
      }
      plVar3 = plVar2 + 2;
      plVar5[2] = *plVar3;
      ((undefined8 *)*plVar3)[*(long **)*plVar3 != plVar2] = plVar5;
      *plVar5 = (long)plVar2;
LAB_00116884:
      *plVar3 = (long)plVar5;
      return;
    }
    bVar1 = plVar2 == param_1;
    *(undefined1 *)(plVar3 + 3) = 1;
    *(bool *)(plVar2 + 3) = bVar1;
    *(char *)plVar5 = '\x01';
    param_2 = plVar2;
  } while( true );
}


// ==== FUN_0011688c @ 0011688c

undefined8 * FUN_0011688c(undefined8 *param_1)

{
  long lVar1;
  size_t __n;
  undefined8 *__ptr;
  void *__dest;
  undefined8 uVar2;
  void *pvVar3;
  
  __ptr = (undefined8 *)FUN_0011b974(0x20);
  pvVar3 = (void *)*param_1;
  lVar1 = param_1[1];
  __ptr[1] = 0;
  __ptr[2] = 0;
  *__ptr = 0;
  __n = lVar1 - (long)pvVar3;
  if (__n != 0) {
    if ((long)__n < 0) {
                    /* try { // try from 0011690c to 00116913 has its CatchHandler @ 00116914 */
      uVar2 = FUN_0011d4bc(__ptr);
                    /* catch() { ... } // from try @ 001168c8 with catch @ 00116914
                       catch() { ... } // from try @ 0011690c with catch @ 00116914 */
      pvVar3 = (void *)*__ptr;
      if (pvVar3 != (void *)0x0) {
        __ptr[1] = pvVar3;
        free(pvVar3);
      }
      free(__ptr);
                    /* WARNING: Subroutine does not return */
      FUN_00134000(uVar2);
    }
                    /* try { // try from 001168c8 to 001168cf has its CatchHandler @ 00116914 */
    __dest = (void *)FUN_0011b974(__n);
    *__ptr = __dest;
    __ptr[2] = (long)__dest + __n;
    memcpy(__dest,pvVar3,__n);
    __ptr[1] = (long)__dest + __n;
  }
  *(undefined2 *)(__ptr + 3) = *(undefined2 *)(param_1 + 3);
  return __ptr;
}


// ==== FUN_0011693c @ 0011693c

void FUN_0011693c(long *param_1,long param_2,long param_3)

{
  ulong uVar1;
  long lVar2;
  undefined1 uVar3;
  undefined1 *puVar4;
  undefined1 *puVar5;
  undefined1 local_58 [8];
  undefined8 local_50;
  long local_48;
  
  lVar2 = tpidr_el0;
  local_48 = *(long *)(lVar2 + 0x28);
  uVar1 = param_3 - param_2;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar1 != 0) {
    if ((long)uVar1 < 0) {
                    /* try { // try from 00116a40 to 00116a47 has its CatchHandler @ 00116a4c */
      FUN_0011d4bc(param_1);
      goto LAB_00116a48;
    }
                    /* try { // try from 00116984 to 00116987 has its CatchHandler @ 00116a4c */
    puVar4 = (undefined1 *)FUN_0011b974(uVar1 >> 1);
    *param_1 = (long)puVar4;
    param_1[1] = (long)puVar4;
    param_1[2] = (long)(puVar4 + ((long)uVar1 >> 5) * 0x10);
    if (param_2 != param_3) {
      do {
        puVar5 = *(undefined1 **)(param_2 + 0x10);
        if (*(char *)(param_2 + 0x18) == '\0') {
                    /* try { // try from 00116a08 to 00116a0f has its CatchHandler @ 00116a54 */
          FUN_00115f84(local_58);
        }
        else {
          local_58[0] = *puVar5;
          local_50 = *(undefined8 *)(puVar5 + 8);
          *puVar5 = 0;
          *(undefined8 *)(puVar5 + 8) = 0;
        }
        uVar3 = local_58[0];
        local_58[0] = 0;
        *puVar4 = uVar3;
        *(undefined8 *)(puVar4 + 8) = local_50;
        local_50 = 0;
        FUN_00114fc4(&local_50,0);
        param_2 = param_2 + 0x20;
        puVar4 = puVar4 + 0x10;
      } while (param_2 != param_3);
    }
    param_1[1] = (long)puVar4;
  }
  if (*(long *)(lVar2 + 0x28) == local_48) {
    return;
  }
LAB_00116a48:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00116a6c @ 00116a6c

void FUN_00116a6c(long *param_1,undefined8 param_2)

{
  ulong uVar1;
  long lVar2;
  long lVar3;
  long lVar4;
  ulong uVar5;
  undefined1 *puVar6;
  ulong uVar7;
  undefined1 *puVar8;
  long lVar9;
  undefined1 *__ptr;
  long local_68;
  
  lVar2 = tpidr_el0;
  lVar4 = *(long *)(lVar2 + 0x28);
  lVar9 = param_1[1] - *param_1 >> 4;
  uVar1 = lVar9 + 1;
  if (uVar1 >> 0x3c != 0) {
    FUN_0011d4bc(param_1);
LAB_00116be0:
                    /* WARNING: Subroutine does not return */
    FUN_001157bc("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
  }
  uVar5 = param_1[2] - *param_1;
  uVar7 = (long)uVar5 >> 3;
  if (uVar1 <= uVar7) {
    uVar1 = uVar7;
  }
  if (0x7fffffffffffffef < uVar5) {
    uVar1 = 0xfffffffffffffff;
  }
  if (uVar1 == 0) {
    lVar3 = 0;
  }
  else {
    if (uVar1 >> 0x3c != 0) goto LAB_00116be0;
    lVar3 = FUN_0011b974(uVar1 << 4);
  }
  local_68 = lVar3 + lVar9 * 0x10;
  lVar3 = lVar3 + uVar1 * 0x10;
                    /* try { // try from 00116b08 to 00116b13 has its CatchHandler @ 00116bf0 */
  FUN_00115f84(local_68,param_2);
  __ptr = (undefined1 *)*param_1;
  lVar9 = local_68 + 0x10;
  puVar8 = (undefined1 *)param_1[1];
  if ((undefined1 *)param_1[1] == __ptr) {
    *param_1 = local_68;
    param_1[1] = lVar9;
    param_1[2] = lVar3;
  }
  else {
    do {
      puVar6 = puVar8 + -0x10;
      *(undefined1 *)(local_68 + -0x10) = *puVar6;
      *(undefined8 *)(local_68 + -8) = *(undefined8 *)(puVar8 + -8);
      *puVar6 = 0;
      *(undefined8 *)(puVar8 + -8) = 0;
      local_68 = local_68 + -0x10;
      puVar8 = puVar6;
    } while (puVar6 != __ptr);
    __ptr = (undefined1 *)*param_1;
    puVar8 = (undefined1 *)param_1[1];
    *param_1 = local_68;
    param_1[1] = lVar9;
    param_1[2] = lVar3;
    if (puVar8 != __ptr) {
      puVar8 = puVar8 + -8;
      do {
        puVar6 = puVar8 + -8;
        FUN_00114fc4(puVar8,*puVar6);
        puVar8 = puVar8 + -0x10;
      } while (puVar6 != __ptr);
    }
  }
  if (__ptr != (undefined1 *)0x0) {
    free(__ptr);
  }
  if (*(long *)(lVar2 + 0x28) != lVar4) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00116c04 @ 00116c04

void FUN_00116c04(long param_1)

{
  long lVar1;
  long *plVar2;
  
  plVar2 = *(long **)(param_1 + 8);
  if ((plVar2 == (long *)0x0) || (lVar1 = FUN_00133da0(0xffffffffffffffff,plVar2 + 1), lVar1 != 0))
  {
    return;
  }
  (**(code **)(*plVar2 + 0x10))(plVar2);
  FUN_0011b8a4(plVar2);
  return;
}


// ==== FUN_00116c54 @ 00116c54

void FUN_00116c54(long param_1)

{
  long lVar1;
  long *plVar2;
  
  plVar2 = *(long **)(param_1 + 8);
  if ((plVar2 == (long *)0x0) || (lVar1 = FUN_00133da0(0xffffffffffffffff,plVar2 + 1), lVar1 != 0))
  {
    return;
  }
  (**(code **)(*plVar2 + 0x10))(plVar2);
  FUN_0011b8a4(plVar2);
  return;
}


// ==== FUN_00116ca4 @ 00116ca4

void FUN_00116ca4(undefined8 *param_1,undefined1 *param_2,ulong param_3,uint param_4,int param_5,
                 int param_6)

{
  long lVar1;
  byte *pbVar2;
  uint uVar3;
  long *plVar4;
  char *pcVar5;
  undefined8 *puVar6;
  ulong uVar7;
  undefined8 uVar8;
  byte bVar9;
  char cVar10;
  uint uVar11;
  code *pcVar12;
  long lVar13;
  long *plVar14;
  long lVar15;
  undefined2 *puVar16;
  ulong uVar17;
  ulong uVar18;
  undefined8 *puVar19;
  ulong uVar20;
  byte *pbVar21;
  long *plVar22;
  double dVar23;
  undefined4 local_70;
  undefined4 local_6c;
  long local_68;
  
  lVar13 = tpidr_el0;
  local_68 = *(long *)(lVar13 + 0x28);
  switch(*param_2) {
  case 0:
switchD_00116d04_caseD_0:
    plVar4 = (long *)*param_1;
    pcVar5 = "null";
    uVar7 = 4;
    goto LAB_00117978;
  case 1:
    plVar4 = (long *)*param_1;
    if (*(long *)(*(long *)(param_2 + 8) + 0x10) != 0) {
      if ((param_3 & 1) != 0) {
        (**(code **)(*plVar4 + 8))(plVar4,&DAT_0010ae91,2);
        uVar20 = (ulong)(uint)(param_6 + param_5);
        uVar7 = (ulong)(*(byte *)(param_1 + 0x4c) >> 1);
        if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
          uVar7 = param_1[0x4d];
        }
        if (uVar7 < uVar20) {
          FUN_0011c3c4(param_1 + 0x4c,uVar7 << 1,0x20);
          lVar15 = (*(undefined8 **)(param_2 + 8))[2];
          plVar4 = (long *)**(undefined8 **)(param_2 + 8);
        }
        else {
          lVar15 = (*(undefined8 **)(param_2 + 8))[2];
          plVar4 = (long *)**(undefined8 **)(param_2 + 8);
        }
        if (lVar15 != 1) {
          uVar7 = 0;
          plVar22 = plVar4;
          do {
            lVar15 = (long)param_1 + 0x261;
            if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
              lVar15 = param_1[0x4e];
            }
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar15,uVar20);
            (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
            FUN_00117d10(param_1,plVar22 + 4,param_4 & 1);
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a7e0,3);
            FUN_00116ca4(param_1,plVar22 + 7,1,param_4 & 1,param_5,uVar20);
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a8dc,2);
            plVar14 = (long *)plVar22[1];
            if ((long *)plVar22[1] == (long *)0x0) {
              plVar14 = plVar22 + 2;
              plVar4 = (long *)*plVar14;
              if ((long *)*plVar4 != plVar22) {
                do {
                  lVar15 = *plVar14;
                  plVar14 = (long *)(lVar15 + 0x10);
                  plVar4 = (long *)*plVar14;
                } while (*plVar4 != lVar15);
              }
            }
            else {
              do {
                plVar4 = plVar14;
                plVar14 = (long *)*plVar4;
              } while ((long *)*plVar4 != (long *)0x0);
            }
            uVar7 = uVar7 + 1;
            plVar22 = plVar4;
          } while (uVar7 < *(long *)(*(long *)(param_2 + 8) + 0x10) - 1U);
        }
        lVar15 = (long)param_1 + 0x261;
        if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
          lVar15 = param_1[0x4e];
        }
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar15,uVar20);
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
        FUN_00117d10(param_1,plVar4 + 4,param_4 & 1);
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a7e0,3);
        FUN_00116ca4(param_1,plVar4 + 7,1,param_4 & 1,param_5,uVar20);
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,10);
        lVar15 = (long)param_1 + 0x261;
        if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
          lVar15 = param_1[0x4e];
        }
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar15,param_6);
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x7d);
        lVar13 = *(long *)(lVar13 + 0x28);
        goto LAB_00117988;
      }
      (**(code **)*plVar4)(plVar4,0x7b);
      plVar4 = (long *)**(undefined8 **)(param_2 + 8);
      if ((*(undefined8 **)(param_2 + 8))[2] != 1) {
        uVar7 = 0;
        plVar22 = plVar4;
        do {
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
          FUN_00117d10(param_1,plVar22 + 4,param_4 & 1);
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010af91,2);
          FUN_00116ca4(param_1,plVar22 + 7,0,param_4 & 1,param_5,param_6);
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x2c);
          plVar14 = (long *)plVar22[1];
          if ((long *)plVar22[1] == (long *)0x0) {
            plVar14 = plVar22 + 2;
            plVar4 = (long *)*plVar14;
            if ((long *)*plVar4 != plVar22) {
              do {
                lVar15 = *plVar14;
                plVar14 = (long *)(lVar15 + 0x10);
                plVar4 = (long *)*plVar14;
              } while (*plVar4 != lVar15);
            }
          }
          else {
            do {
              plVar4 = plVar14;
              plVar14 = (long *)*plVar4;
            } while ((long *)*plVar4 != (long *)0x0);
          }
          uVar7 = uVar7 + 1;
          plVar22 = plVar4;
        } while (uVar7 < *(long *)(*(long *)(param_2 + 8) + 0x10) - 1U);
      }
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
      FUN_00117d10(param_1,plVar4 + 4,param_4 & 1);
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010af91,2);
      FUN_00116ca4(param_1,plVar4 + 7,0,param_4 & 1,param_5,param_6);
      goto LAB_00117ac4;
    }
    lVar15 = *plVar4;
    pcVar5 = "{}";
LAB_0011736c:
    pcVar12 = *(code **)(lVar15 + 8);
    uVar7 = 2;
    goto LAB_00117980;
  case 2:
    plVar4 = (long *)*param_1;
    if (**(long **)(param_2 + 8) == (*(long **)(param_2 + 8))[1]) {
      lVar15 = *plVar4;
      pcVar5 = "[]";
      goto LAB_0011736c;
    }
    if ((param_3 & 1) == 0) {
      (**(code **)*plVar4)(plVar4,0x5b);
      lVar15 = **(long **)(param_2 + 8);
      if (lVar15 != (*(long **)(param_2 + 8))[1] + -0x10) {
        do {
          FUN_00116ca4(param_1,lVar15,0,param_4 & 1,param_5,param_6);
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x2c);
          lVar15 = lVar15 + 0x10;
        } while (lVar15 != *(long *)(*(long *)(param_2 + 8) + 8) + -0x10);
      }
      FUN_00116ca4(param_1,lVar15,0,param_4 & 1,param_5,param_6);
    }
    else {
      (**(code **)(*plVar4 + 8))(plVar4,&DAT_0010a5db,2);
      uVar20 = (ulong)(uint)(param_6 + param_5);
      uVar7 = (ulong)(*(byte *)(param_1 + 0x4c) >> 1);
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        uVar7 = param_1[0x4d];
      }
      if (uVar7 < uVar20) {
        FUN_0011c3c4(param_1 + 0x4c,uVar7 << 1,0x20);
        lVar15 = **(long **)(param_2 + 8);
        if (lVar15 != (*(long **)(param_2 + 8))[1] + -0x10) goto LAB_00116ef4;
      }
      else {
        lVar15 = **(long **)(param_2 + 8);
        if (lVar15 != (*(long **)(param_2 + 8))[1] + -0x10) {
LAB_00116ef4:
          do {
            lVar1 = (long)param_1 + 0x261;
            if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
              lVar1 = param_1[0x4e];
            }
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar1,uVar20);
            FUN_00116ca4(param_1,lVar15,1,param_4 & 1,param_5,uVar20);
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010a8dc,2);
            lVar15 = lVar15 + 0x10;
          } while (lVar15 != *(long *)(*(long *)(param_2 + 8) + 8) + -0x10);
        }
      }
      lVar15 = (long)param_1 + 0x261;
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        lVar15 = param_1[0x4e];
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar15,uVar20);
      FUN_00116ca4(param_1,*(long *)(*(long *)(param_2 + 8) + 8) + -0x10,1,param_4 & 1,param_5,
                   uVar20);
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,10);
      lVar15 = (long)param_1 + 0x261;
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        lVar15 = param_1[0x4e];
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar15,param_6);
    }
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x5d);
    break;
  case 3:
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
    FUN_00117d10(param_1,*(undefined8 *)(param_2 + 8),param_4 & 1);
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x22);
    break;
  case 4:
    plVar4 = (long *)*param_1;
    pcVar12 = *(code **)(*plVar4 + 8);
    if (param_2[8] == '\0') {
      uVar7 = 5;
      pcVar5 = "false";
    }
    else {
      uVar7 = 4;
      pcVar5 = "true";
    }
    goto LAB_00117980;
  case 5:
    FUN_00118374(param_1,*(undefined8 *)(param_2 + 8));
    break;
  case 6:
    uVar20 = *(ulong *)(param_2 + 8);
    if (uVar20 != 0) {
      pcVar5 = (char *)(param_1 + 2);
      if (uVar20 < 10) {
        puVar16 = (undefined2 *)((long)param_1 + 0x11);
        uVar7 = 1;
LAB_0011779c:
        *(char *)((long)puVar16 + -1) = (char)uVar20 + '0';
      }
      else {
        uVar7 = uVar20;
        uVar3 = 4;
        do {
          uVar11 = uVar3;
          if (uVar7 < 100) {
            uVar11 = uVar11 - 2;
            goto LAB_0011771c;
          }
          if (uVar7 < 1000) {
            uVar11 = uVar11 - 1;
            goto LAB_0011771c;
          }
          if (uVar7 >> 4 < 0x271) goto LAB_0011771c;
          uVar17 = uVar7 >> 5;
          uVar7 = uVar7 / 10000;
          uVar3 = uVar11 + 4;
        } while (0xc34 < uVar17);
        uVar11 = uVar11 + 1;
LAB_0011771c:
        uVar7 = (ulong)uVar11;
        puVar16 = (undefined2 *)((long)param_1 + uVar7 + 0x10);
        if (uVar20 < 100) {
        }
        else {
          do {
            uVar18 = uVar20 >> 4;
            uVar17 = uVar20 / 100;
            puVar16 = puVar16 + -1;
            *puVar16 = *(undefined2 *)
                        (
                        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
                        + (uVar20 % 100) * 2);
            uVar20 = uVar17;
          } while (0x270 < uVar18);
        }
        if (uVar20 < 10) goto LAB_0011779c;
        puVar16[-1] = *(undefined2 *)
                       (
                       "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
                       + uVar20 * 2);
      }
      plVar4 = (long *)*param_1;
      goto LAB_00117978;
    }
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
    break;
  case 7:
    dVar23 = *(double *)(param_2 + 8);
    if ((INFINITY <= ABS(dVar23)) && (ABS(dVar23) == INFINITY)) goto switchD_00116d04_caseD_0;
    puVar6 = param_1 + 2;
    if ((long)dVar23 < 0) {
      puVar19 = (undefined8 *)((long)param_1 + 0x11);
      *(undefined1 *)(param_1 + 2) = 0x2d;
      if (-dVar23 != 0.0) goto LAB_0011755c;
LAB_00117228:
      lVar15 = (long)puVar19 + 3;
      *(undefined2 *)puVar19 = 0x2e30;
      *(undefined1 *)((long)puVar19 + 2) = 0x30;
    }
    else {
      puVar19 = puVar6;
      if (dVar23 == 0.0) goto LAB_00117228;
LAB_0011755c:
      local_6c = 0;
      local_70 = 0;
      FUN_0011866c(puVar19,&local_6c,&local_70);
      lVar15 = FUN_00118848(puVar19,local_6c,local_70,0xfffffffc,0xf);
    }
    (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,puVar6,lVar15 - (long)puVar6);
    break;
  case 8:
    plVar4 = (long *)*param_1;
    if ((param_3 & 1) == 0) {
      (**(code **)(*plVar4 + 8))(plVar4,"{\"bytes\":[",10);
      pbVar21 = (byte *)**(long **)(param_2 + 8);
      pbVar2 = (byte *)(*(long **)(param_2 + 8))[1];
      if (pbVar21 != pbVar2) {
        if (pbVar21 != pbVar2 + -1) {
          do {
            bVar9 = *pbVar21;
            if ((ulong)bVar9 == 0) {
              (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
            }
            else {
              if (bVar9 < 10) {
                uVar8 = 1;
LAB_00117320:
                cVar10 = bVar9 + 0x30;
              }
              else {
                if (99 < bVar9) {
                  uVar11 = (uint)bVar9;
                  uVar8 = 3;
                  uVar3 = uVar11 * 0x29 >> 0xc;
                  bVar9 = (byte)uVar3;
                  *(undefined2 *)((long)param_1 + 0x11) =
                       *(undefined2 *)(&DAT_0010b6fe + ((ulong)(uVar11 + uVar3 * -100) & 0xff) * 2);
                  goto LAB_00117320;
                }
                lVar15 = (ulong)bVar9 * 2;
                uVar8 = 2;
                cVar10 = (&DAT_0010b6fe)[lVar15];
                *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b6ff)[lVar15];
              }
              *(char *)(param_1 + 2) = cVar10;
              (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar8);
            }
            (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x2c);
            pbVar21 = pbVar21 + 1;
          } while (pbVar21 != (byte *)(*(long *)(*(long *)(param_2 + 8) + 8) + -1));
        }
        bVar9 = *pbVar21;
        if ((ulong)bVar9 == 0) {
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
        }
        else {
          if (bVar9 < 10) {
            uVar8 = 1;
LAB_00117908:
            cVar10 = bVar9 + 0x30;
          }
          else {
            if (99 < bVar9) {
              uVar11 = (uint)bVar9;
              uVar8 = 3;
              uVar3 = uVar11 * 0x29 >> 0xc;
              bVar9 = (byte)uVar3;
              *(undefined2 *)((long)param_1 + 0x11) =
                   *(undefined2 *)(&DAT_0010b6fe + ((ulong)(uVar11 + uVar3 * -100) & 0xff) * 2);
              goto LAB_00117908;
            }
            uVar8 = 2;
            lVar15 = (ulong)bVar9 * 2;
            cVar10 = (&DAT_0010b6fe)[lVar15];
            *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b6ff)[lVar15];
          }
          *(char *)(param_1 + 2) = cVar10;
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar8);
        }
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,"],\"subtype\":",0xc);
      if (*(char *)(*(long *)(param_2 + 8) + 0x19) == '\0') {
        plVar4 = (long *)*param_1;
        pcVar5 = "null}";
        uVar7 = 5;
        goto LAB_00117978;
      }
      bVar9 = *(byte *)(*(long *)(param_2 + 8) + 0x18);
      if ((ulong)bVar9 == 0) {
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
        goto LAB_00117ac4;
      }
      puVar6 = param_1 + 2;
      if (bVar9 < 10) {
        param_6 = 1;
LAB_00117aac:
        cVar10 = bVar9 + 0x30;
      }
      else {
        if (99 < bVar9) {
          uVar11 = (uint)bVar9;
          param_6 = 3;
          uVar3 = uVar11 * 0x29 >> 0xc;
          bVar9 = (byte)uVar3;
          *(undefined2 *)((long)param_1 + 0x11) =
               *(undefined2 *)(&DAT_0010b6fe + ((ulong)(uVar11 + uVar3 * -100) & 0xff) * 2);
          goto LAB_00117aac;
        }
        param_6 = 2;
        lVar15 = (ulong)bVar9 * 2;
        cVar10 = (&DAT_0010b6fe)[lVar15];
        *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b6ff)[lVar15];
      }
      plVar4 = (long *)*param_1;
      *(char *)(param_1 + 2) = cVar10;
      pcVar12 = *(code **)(*plVar4 + 8);
    }
    else {
      (**(code **)(*plVar4 + 8))(plVar4,&DAT_0010ae91,2);
      bVar9 = *(byte *)(param_1 + 0x4c);
      uVar20 = (ulong)(uint)(param_6 + param_5);
      uVar7 = (ulong)(bVar9 >> 1);
      if ((bVar9 & 1) != 0) {
        uVar7 = param_1[0x4d];
      }
      if (uVar7 < uVar20) {
        FUN_0011c3c4(param_1 + 0x4c,uVar7 << 1,0x20);
        bVar9 = *(byte *)(param_1 + 0x4c);
      }
      lVar15 = param_1[0x4e];
      if ((bVar9 & 1) == 0) {
        lVar15 = (long)param_1 + 0x261;
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,lVar15,uVar20);
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,"\"bytes\": [",10);
      pbVar21 = (byte *)**(long **)(param_2 + 8);
      pbVar2 = (byte *)(*(long **)(param_2 + 8))[1];
      if (pbVar21 != pbVar2) {
        if (pbVar21 != pbVar2 + -1) {
          do {
            bVar9 = *pbVar21;
            if ((ulong)bVar9 == 0) {
              (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
            }
            else {
              if (bVar9 < 10) {
                uVar8 = 1;
LAB_001171f0:
                cVar10 = bVar9 + 0x30;
              }
              else {
                if (99 < bVar9) {
                  uVar11 = (uint)bVar9;
                  uVar8 = 3;
                  uVar3 = uVar11 * 0x29 >> 0xc;
                  bVar9 = (byte)uVar3;
                  *(undefined2 *)((long)param_1 + 0x11) =
                       *(undefined2 *)(&DAT_0010b6fe + ((ulong)(uVar11 + uVar3 * -100) & 0xff) * 2);
                  goto LAB_001171f0;
                }
                lVar15 = (ulong)bVar9 * 2;
                uVar8 = 2;
                cVar10 = (&DAT_0010b6fe)[lVar15];
                *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b6ff)[lVar15];
              }
              *(char *)(param_1 + 2) = cVar10;
              (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar8);
            }
            (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010b032,2);
            pbVar21 = pbVar21 + 1;
          } while (pbVar21 != (byte *)(*(long *)(*(long *)(param_2 + 8) + 8) + -1));
        }
        bVar9 = *pbVar21;
        if ((ulong)bVar9 == 0) {
          (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
        }
        else {
          if (bVar9 < 10) {
            uVar8 = 1;
LAB_001177e0:
            cVar10 = bVar9 + 0x30;
          }
          else {
            if (99 < bVar9) {
              uVar11 = (uint)bVar9;
              uVar8 = 3;
              uVar3 = uVar11 * 0x29 >> 0xc;
              bVar9 = (byte)uVar3;
              *(undefined2 *)((long)param_1 + 0x11) =
                   *(undefined2 *)(&DAT_0010b6fe + ((ulong)(uVar11 + uVar3 * -100) & 0xff) * 2);
              goto LAB_001177e0;
            }
            uVar8 = 2;
            lVar15 = (ulong)bVar9 * 2;
            cVar10 = (&DAT_0010b6fe)[lVar15];
            *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b6ff)[lVar15];
          }
          *(char *)(param_1 + 2) = cVar10;
          (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar8);
        }
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,&DAT_0010aa18,3);
      puVar6 = (undefined8 *)((long)param_1 + 0x261);
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        puVar6 = (undefined8 *)param_1[0x4e];
      }
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,puVar6,uVar20);
      (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,"\"subtype\": ",0xb);
      if (*(char *)(*(long *)(param_2 + 8) + 0x19) == '\0') {
        plVar4 = (long *)*param_1;
        puVar6 = (undefined8 *)&DAT_00109d32;
        uVar8 = 4;
LAB_00117a34:
        (**(code **)(*plVar4 + 8))(plVar4,puVar6,uVar8);
      }
      else {
        bVar9 = *(byte *)(*(long *)(param_2 + 8) + 0x18);
        if ((ulong)bVar9 != 0) {
          puVar6 = param_1 + 2;
          if (bVar9 < 10) {
            uVar8 = 1;
LAB_00117a28:
            cVar10 = bVar9 + 0x30;
          }
          else {
            if (99 < bVar9) {
              uVar11 = (uint)bVar9;
              uVar8 = 3;
              uVar3 = uVar11 * 0x29 >> 0xc;
              bVar9 = (byte)uVar3;
              *(undefined2 *)((long)param_1 + 0x11) =
                   *(undefined2 *)(&DAT_0010b6fe + ((ulong)(uVar11 + uVar3 * -100) & 0xff) * 2);
              goto LAB_00117a28;
            }
            uVar8 = 2;
            lVar15 = (ulong)bVar9 * 2;
            cVar10 = (&DAT_0010b6fe)[lVar15];
            *(undefined *)((long)param_1 + 0x11) = (&DAT_0010b6ff)[lVar15];
          }
          plVar4 = (long *)*param_1;
          *(char *)(param_1 + 2) = cVar10;
          goto LAB_00117a34;
        }
        (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
      }
      (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,10);
      plVar4 = (long *)*param_1;
      puVar6 = (undefined8 *)((long)param_1 + 0x261);
      if ((*(byte *)(param_1 + 0x4c) & 1) != 0) {
        puVar6 = (undefined8 *)param_1[0x4e];
      }
      pcVar12 = *(code **)(*plVar4 + 8);
    }
    (*pcVar12)(plVar4,puVar6,param_6);
LAB_00117ac4:
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x7d);
    break;
  case 9:
    plVar4 = (long *)*param_1;
    pcVar5 = "<discarded>";
    uVar7 = 0xb;
LAB_00117978:
    pcVar12 = *(code **)(*plVar4 + 8);
LAB_00117980:
    (*pcVar12)(plVar4,pcVar5,uVar7);
  }
  lVar13 = *(long *)(lVar13 + 0x28);
LAB_00117988:
  if (lVar13 != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00117c5c @ 00117c5c

void FUN_00117c5c(long param_1)

{
  long lVar1;
  long *plVar2;
  
  if ((*(byte *)(param_1 + 0x260) & 1) != 0) {
    free(*(void **)(param_1 + 0x270));
  }
  plVar2 = *(long **)(param_1 + 8);
  if ((plVar2 == (long *)0x0) || (lVar1 = FUN_00133da0(0xffffffffffffffff,plVar2 + 1), lVar1 != 0))
  {
    return;
  }
  (**(code **)(*plVar2 + 0x10))(plVar2);
  FUN_0011b8a4(plVar2);
  return;
}


// ==== FUN_00117ce8 @ 00117ce8

void FUN_00117ce8(long param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00117cf0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(long *)(param_1 + 0x18) + 0x10))();
  return;
}


// ==== FUN_00117d10 @ 00117d10

void FUN_00117d10(undefined8 *param_1,byte *param_2,ulong param_3)

{
  undefined1 *puVar1;
  ulong uVar2;
  byte *pbVar3;
  int iVar4;
  byte bVar5;
  byte bVar6;
  long lVar7;
  bool bVar8;
  long *plVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  char *pcVar12;
  long lVar13;
  long lVar14;
  code *pcVar15;
  undefined1 uVar16;
  ulong uVar17;
  undefined1 uVar18;
  long lVar19;
  ulong uVar20;
  uint unaff_w26;
  long lVar21;
  undefined1 auStack_e8 [24];
  undefined8 local_d0;
  undefined8 uStack_c8;
  undefined8 local_c0;
  undefined8 local_b0;
  undefined8 uStack_a8;
  undefined8 local_a0;
  undefined1 auStack_98 [24];
  undefined1 local_80;
  undefined4 local_7f;
  long local_68;
  
  lVar7 = tpidr_el0;
  local_68 = *(long *)(lVar7 + 0x28);
  bVar8 = (*param_2 & 1) == 0;
  uVar20 = (ulong)(*param_2 >> 1);
  if (!bVar8) {
    uVar20 = *(ulong *)(param_2 + 8);
  }
  if (uVar20 != 0) {
    lVar21 = 0;
    uVar20 = 0;
    lVar14 = 0;
    lVar13 = 0;
    uVar17 = 0;
    pcVar12 = (char *)((long)param_1 + 0x5a);
    do {
      pbVar3 = param_2 + 1;
      if (!bVar8) {
        pbVar3 = *(byte **)(param_2 + 0x10);
      }
      bVar6 = pbVar3[uVar20];
      if ((int)uVar17 == 0) {
        unaff_w26 = 0xffU >> (ulong)((byte)(&DAT_0010b56e)[bVar6] & 0x1f) & (uint)bVar6;
      }
      else {
        unaff_w26 = bVar6 & 0x3f | unaff_w26 << 6;
      }
      bVar5 = (&DAT_0010b66e)[uVar17 * 0x10 + (ulong)(byte)(&DAT_0010b56e)[bVar6]];
      uVar17 = (ulong)bVar5;
      if (bVar5 == 1) {
        iVar4 = *(int *)(param_1 + 0x4f);
        if (1 < iVar4 - 1U) {
          if (iVar4 != 0) {
            uVar17 = 1;
            goto LAB_00117da0;
          }
          local_7f = 0;
          local_80 = 6;
                    /* try { // try from 001181bc to 001181cf has its CatchHandler @ 00118358 */
          FUN_001185c8((ulong)&local_80 | 1,0x17,3,&DAT_0010a8df);
          uVar10 = FUN_0011d504(0x20);
                    /* try { // try from 001181dc to 001181e7 has its CatchHandler @ 00118348 */
          FUN_0011c6f0(auStack_e8,uVar20);
                    /* try { // try from 001181e8 to 001181fb has its CatchHandler @ 00118330 */
          puVar11 = (undefined8 *)FUN_0011c108(auStack_e8,0,"invalid UTF-8 byte at index ");
          local_c0 = puVar11[2];
          uStack_c8 = puVar11[1];
          local_d0 = *puVar11;
          puVar11[1] = 0;
          puVar11[2] = 0;
          *puVar11 = 0;
                    /* try { // try from 00118214 to 00118223 has its CatchHandler @ 00118300 */
          puVar11 = (undefined8 *)FUN_0011c2e4(&local_d0,&DAT_0010ad13);
          local_a0 = puVar11[2];
          uStack_a8 = puVar11[1];
          local_b0 = *puVar11;
          puVar11[1] = 0;
          puVar11[2] = 0;
          *puVar11 = 0;
                    /* try { // try from 0011823c to 0011824b has its CatchHandler @ 001182dc */
          FUN_00115cb8(auStack_98,&local_b0,&local_80);
                    /* try { // try from 00118250 to 0011827b has its CatchHandler @ 0011829c */
          FUN_00115a40(uVar10,0x13c,auStack_98);
          FUN_0011d57c(uVar10,&PTR_PTR_0013c248,0x115c5c);
          goto LAB_0011827c;
        }
        uVar20 = uVar20 - (lVar14 != 0);
        if (iVar4 == 1) {
          lVar14 = lVar13 + 1;
          puVar1 = (undefined1 *)((long)param_1 + lVar13 + 0x5a);
          if ((param_3 & 1) == 0) {
            uVar16 = 0xbd;
            uVar18 = 0xbf;
            lVar21 = 2;
            lVar19 = 3;
            *puVar1 = 0xef;
          }
          else {
            uVar16 = 100;
            uVar18 = 0x66;
            *puVar1 = 0x5c;
            *(undefined1 *)((long)param_1 + lVar13 + 0x5b) = 0x75;
            lVar14 = lVar13 + 4;
            lVar21 = 5;
            lVar19 = 6;
            *(undefined2 *)((long)param_1 + lVar13 + 0x5c) = 0x6666;
          }
          lVar21 = lVar13 + lVar21;
          lVar13 = lVar13 + lVar19;
          *(undefined1 *)((long)param_1 + lVar14 + 0x5a) = uVar18;
          *(undefined1 *)((long)param_1 + lVar21 + 0x5a) = uVar16;
          if (lVar13 - 500U < 0xd) goto LAB_00118030;
        }
LAB_00117d94:
        uVar17 = 0;
        lVar14 = 0;
        lVar21 = lVar13;
      }
      else if (bVar5 == 0) {
        switch(unaff_w26) {
        case 8:
          lVar13 = lVar21 + 2;
          *(undefined2 *)((long)param_1 + lVar21 + 0x5a) = 0x625c;
          break;
        case 9:
          lVar13 = lVar21 + 2;
          *(undefined2 *)((long)param_1 + lVar21 + 0x5a) = 0x745c;
          break;
        case 10:
          lVar13 = lVar21 + 2;
          *(undefined2 *)((long)param_1 + lVar21 + 0x5a) = 0x6e5c;
          break;
        case 0xb:
        case 0xe:
        case 0xf:
        case 0x10:
        case 0x11:
        case 0x12:
        case 0x13:
        case 0x14:
        case 0x15:
        case 0x16:
        case 0x17:
        case 0x18:
        case 0x19:
        case 0x1a:
        case 0x1b:
        case 0x1c:
        case 0x1d:
        case 0x1e:
        case 0x1f:
        case 0x20:
        case 0x21:
switchD_00117e34_caseD_b:
          if (unaff_w26 < 0x20) {
LAB_00117f40:
            FUN_001185c8((long)param_1 + lVar21 + 0x5a,0xffffffffffffffff,7,"\\u%04x",unaff_w26);
            lVar13 = lVar21 + 6;
          }
          else if (((param_3 & 1) == 0) || (unaff_w26 < 0x7f)) {
            lVar13 = lVar21 + 1;
            *(byte *)((long)param_1 + lVar21 + 0x5a) = bVar6;
          }
          else {
            if (unaff_w26 >> 0x10 == 0) goto LAB_00117f40;
            FUN_001185c8((long)param_1 + lVar21 + 0x5a,0xffffffffffffffff,0xd,"\\u%04x\\u%04x",
                         (unaff_w26 >> 10) + 0xd7c0 & 0xffff,unaff_w26 & 0x3ff | 0xdc00);
            lVar13 = lVar21 + 0xc;
          }
          break;
        case 0xc:
          lVar13 = lVar21 + 2;
          *(undefined2 *)((long)param_1 + lVar21 + 0x5a) = 0x665c;
          break;
        case 0xd:
          lVar13 = lVar21 + 2;
          *(undefined2 *)((long)param_1 + lVar21 + 0x5a) = 0x725c;
          break;
        case 0x22:
          lVar13 = lVar21 + 2;
          *(undefined2 *)((long)param_1 + lVar21 + 0x5a) = 0x225c;
          break;
        default:
          if (unaff_w26 != 0x5c) goto switchD_00117e34_caseD_b;
          lVar13 = lVar21 + 2;
          *(undefined2 *)((long)param_1 + lVar21 + 0x5a) = 0x5c5c;
        }
        if (0xc < lVar13 - 500U) goto LAB_00117d94;
LAB_00118030:
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,pcVar12);
        uVar17 = 0;
        lVar13 = 0;
        lVar14 = 0;
        lVar21 = 0;
      }
      else {
        lVar19 = lVar21;
        if ((param_3 & 1) == 0) {
          lVar19 = lVar21 + 1;
          *(byte *)((long)param_1 + lVar21 + 0x5a) = bVar6;
        }
        lVar14 = lVar14 + 1;
        lVar21 = lVar19;
      }
LAB_00117da0:
      bVar6 = *param_2;
      uVar20 = uVar20 + 1;
      bVar8 = (bVar6 & 1) == 0;
      uVar2 = (ulong)(bVar6 >> 1);
      if (!bVar8) {
        uVar2 = *(ulong *)(param_2 + 8);
      }
    } while (uVar20 < uVar2);
    if ((int)uVar17 == 0) {
      if (lVar21 != 0) {
        plVar9 = (long *)*param_1;
        lVar13 = lVar21;
LAB_00118070:
        pcVar15 = *(code **)(*plVar9 + 8);
LAB_00118078:
        (*pcVar15)(plVar9,pcVar12,lVar13);
      }
    }
    else {
      iVar4 = *(int *)(param_1 + 0x4f);
      if (iVar4 == 1) {
        (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,pcVar12);
        plVar9 = (long *)*param_1;
        pcVar15 = *(code **)(*plVar9 + 8);
        if ((param_3 & 1) == 0) {
          lVar13 = 3;
          pcVar12 = &DAT_0010ae36;
        }
        else {
          lVar13 = 6;
          pcVar12 = "\\ufffd";
        }
        goto LAB_00118078;
      }
      if (iVar4 == 2) {
        plVar9 = (long *)*param_1;
        goto LAB_00118070;
      }
      if (iVar4 == 0) {
        local_7f = 0;
        pbVar3 = param_2 + 1;
        if ((bVar6 & 1) != 0) {
          pbVar3 = *(byte **)(param_2 + 0x10);
        }
        local_80 = 6;
                    /* try { // try from 001180f0 to 00118103 has its CatchHandler @ 00118298 */
        FUN_001185c8((ulong)&local_80 | 1,0x17,3,&DAT_0010a8df,pbVar3[uVar2 - 1]);
        uVar10 = FUN_0011d504(0x20);
                    /* try { // try from 00118110 to 00118123 has its CatchHandler @ 00118294 */
        FUN_0011c428(auStack_98,"incomplete UTF-8 string; last byte: 0x",&local_80);
                    /* try { // try from 00118128 to 00118153 has its CatchHandler @ 00118280 */
        FUN_00115a40(uVar10,0x13c,auStack_98);
        FUN_0011d57c(uVar10,&PTR_PTR_0013c248,0x115c5c);
        goto LAB_0011827c;
      }
    }
  }
  if (*(long *)(lVar7 + 0x28) == local_68) {
    return;
  }
LAB_0011827c:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00118374 @ 00118374

void FUN_00118374(undefined8 *param_1,ulong param_2)

{
  uint uVar1;
  bool bVar2;
  ulong uVar3;
  ulong uVar4;
  uint uVar5;
  undefined2 *puVar6;
  ulong uVar7;
  
  if (param_2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x001183a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)**(undefined8 **)*param_1)((undefined8 *)*param_1,0x30);
    return;
  }
  if (-1 < (long)param_2) {
    if (9 < param_2) {
      uVar3 = param_2;
      uVar1 = 4;
LAB_00118400:
      uVar5 = uVar1;
      if (uVar3 < 100) {
        uVar5 = uVar5 - 2;
joined_r0x001184d8:
        uVar3 = (ulong)uVar5;
        puVar6 = (undefined2 *)((long)param_1 + uVar3 + 0x10);
        uVar4 = param_2;
        goto joined_r0x001184f4;
      }
      if (999 < uVar3) {
        if (0x270 < uVar3 >> 4) goto code_r0x0011841c;
        goto joined_r0x00118448;
      }
      uVar3 = (ulong)(uVar5 - 1);
      puVar6 = (undefined2 *)((long)param_1 + uVar3 + 0x10);
      uVar4 = param_2;
      goto joined_r0x001184f4;
    }
    puVar6 = (undefined2 *)((long)param_1 + 0x11);
    uVar3 = 1;
    goto LAB_001185b0;
  }
  param_2 = -param_2;
  *(undefined1 *)(param_1 + 2) = 0x2d;
  uVar4 = param_2;
  if (param_2 < 10) {
    uVar3 = 2;
    puVar6 = (undefined2 *)((long)param_1 + 0x12);
  }
  else {
    uVar3 = param_2;
    uVar1 = 4;
    do {
      uVar5 = uVar1;
      if (uVar3 < 100) {
        uVar5 = uVar5 - 1;
        goto joined_r0x00118448;
      }
      if (uVar3 < 1000) goto joined_r0x001184d8;
      if (uVar3 >> 4 < 0x271) goto LAB_001184a8;
      bVar2 = 99999 < uVar3;
      uVar3 = uVar3 / 10000;
      uVar1 = uVar5 + 4;
    } while (bVar2);
    uVar5 = uVar5 + 1;
LAB_001184a8:
    uVar3 = (ulong)(uVar5 + 1);
    puVar6 = (undefined2 *)((long)param_1 + uVar3 + 0x10);
  }
  goto joined_r0x001184f4;
code_r0x0011841c:
  bVar2 = uVar3 < 100000;
  uVar3 = uVar3 / 10000;
  uVar1 = uVar5 + 4;
  if (bVar2) goto code_r0x00118434;
  goto LAB_00118400;
code_r0x00118434:
  uVar5 = uVar5 + 1;
joined_r0x00118448:
  uVar3 = (ulong)uVar5;
  puVar6 = (undefined2 *)((long)param_1 + uVar3 + 0x10);
  uVar4 = param_2;
joined_r0x001184f4:
  param_2 = uVar4;
  if (99 < uVar4) {
    do {
      uVar7 = uVar4 >> 4;
      param_2 = uVar4 / 100;
      puVar6 = puVar6 + -1;
      *puVar6 = *(undefined2 *)(&DAT_0010b7c6 + (uVar4 % 100) * 2);
      uVar4 = param_2;
    } while (0x270 < uVar7);
  }
  if (9 < param_2) {
    puVar6[-1] = *(undefined2 *)(&DAT_0010b7c6 + param_2 * 2);
                    /* WARNING: Could not recover jumptable at 0x00118580. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*(long *)*param_1 + 8))();
    return;
  }
LAB_001185b0:
  *(char *)((long)puVar6 + -1) = (char)param_2 + '0';
                    /* WARNING: Could not recover jumptable at 0x001185c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(long *)*param_1 + 8))((long *)*param_1,param_1 + 2,uVar3);
  return;
}


// ==== FUN_001185c8 @ 001185c8

void FUN_001185c8(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  long lVar2;
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 local_80;
  undefined8 uStack_78;
  undefined1 *local_70;
  undefined1 **ppuStack_68;
  undefined8 *puStack_60;
  undefined8 uStack_58;
  
  ppuStack_68 = &local_70;
  lVar1 = tpidr_el0;
  lVar2 = *(long *)(lVar1 + 0x28);
  puStack_60 = &local_90;
  uStack_58 = 0xffffff80ffffffe0;
  local_90 = param_6;
  uStack_88 = param_7;
  local_80 = param_8;
  uStack_78 = param_9;
  local_70 = (undefined1 *)register0x00000008;
  __vsnprintf_chk(param_2,param_4,0,param_3,param_5,&local_70,param_8,param_9,param_1);
  if (*(long *)(lVar1 + 0x28) != lVar2) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0011866c @ 0011866c

/* WARNING: Removing unreachable block (ram,0x001186d4) */

void FUN_0011866c(ulong param_1,undefined8 param_2,undefined8 param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  
  uVar5 = param_1 & 0xfffffffffffff;
  if (param_1 >> 0x34 == 0) {
    uVar4 = uVar5 << 1 | 1;
    iVar3 = -0x433;
    uVar6 = uVar5;
  }
  else {
    uVar6 = uVar5 | 0x10000000000000;
    iVar3 = (uint)(param_1 >> 0x34) - 0x434;
    uVar4 = uVar6 << 1 | 1;
    if ((param_1 >> 0x35 != 0) && (uVar5 == 0)) {
      uVar6 = 0x10000000000000;
    }
  }
  do {
    iVar3 = iVar3 + -1;
    uVar5 = uVar4 & 0x7fffffffffffffff;
    uVar4 = uVar4 << 1;
  } while (uVar5 >> 0x3e == 0);
  do {
    uVar5 = uVar6 & 0x7fffffffffffffff;
    uVar6 = uVar6 << 1;
  } while (uVar5 >> 0x3e == 0);
  iVar2 = (-0x3d - iVar3) * 0x13441;
  iVar1 = iVar2 + 0x3ffff;
  if (-1 < iVar2) {
    iVar1 = iVar2;
  }
  iVar1 = iVar1 >> 0x12;
  if (0 < -0x3d - iVar3) {
    iVar1 = iVar1 + 1;
  }
  *param_4 = -*(int *)(&DAT_0010b964 +
                      (long)((int)((iVar1 + 0x133U + (iVar1 + 0x133U >> 0x1c & 7)) * 0x10000) >>
                            0x13) * 0x10);
  FUN_00118a70();
  return;
}


// ==== FUN_00118848 @ 00118848

undefined1 * FUN_00118848(undefined2 *param_1,int param_2,int param_3,int param_4,int param_5)

{
  ulong uVar1;
  undefined1 *puVar2;
  uint uVar3;
  char cVar4;
  long lVar5;
  char cVar6;
  undefined1 uVar7;
  byte bVar8;
  int iVar9;
  
  lVar5 = (long)param_2;
  uVar1 = lVar5 + param_3;
  iVar9 = (int)uVar1;
  if ((-1 < param_3) && (iVar9 <= param_5)) {
    memset((void *)((long)param_1 + lVar5),0x30,uVar1 - lVar5);
    *(undefined1 *)((long)param_1 + uVar1) = 0x2e;
    *(undefined1 *)((long)param_1 + (long)iVar9 + 1) = 0x30;
    return (undefined1 *)((long)param_1 + uVar1) + 2;
  }
  if ((0 < iVar9) && (iVar9 <= param_5)) {
    puVar2 = (undefined1 *)((long)param_1 + (uVar1 & 0xffffffff));
    memmove(puVar2 + 1,puVar2,(long)param_2 - (uVar1 & 0xffffffff));
    *puVar2 = 0x2e;
    return (undefined1 *)((long)param_1 + (long)param_2 + 1);
  }
  if ((param_4 < iVar9) && (iVar9 < 1)) {
    lVar5 = (ulong)(uint)-iVar9 + 2;
    memmove((void *)((long)param_1 + lVar5),param_1,(long)param_2);
    *param_1 = 0x2e30;
    memset(param_1 + 1,0x30,(ulong)(uint)-iVar9);
    return (undefined1 *)((long)param_1 + lVar5 + param_2);
  }
  if (param_2 == 1) {
    lVar5 = 1;
  }
  else {
    memmove(param_1 + 1,(void *)((long)param_1 + 1),(long)param_2 - 1);
    lVar5 = (long)param_2 + 1;
    *(undefined1 *)((long)param_1 + 1) = 0x2e;
  }
  puVar2 = (undefined1 *)((long)param_1 + lVar5);
  uVar7 = 0x2d;
  uVar3 = 1 - iVar9;
  if (0 < iVar9) {
    uVar7 = 0x2b;
    uVar3 = iVar9 - 1;
  }
  *puVar2 = 0x65;
  puVar2[1] = uVar7;
  if (uVar3 < 10) {
    cVar6 = '0';
    bVar8 = (char)uVar3 + 0x30;
  }
  else {
    if (99 < uVar3) {
      puVar2[2] = (char)(uVar3 / 100) + '0';
      bVar8 = (byte)((uVar3 % 100) / 10);
      puVar2[3] = bVar8 | 0x30;
      puVar2[4] = (char)(uVar3 % 100) + bVar8 * -10 | 0x30;
      return puVar2 + 5;
    }
    cVar4 = (char)((uVar3 & 0xff) / 10);
    cVar6 = cVar4 + '0';
    bVar8 = (char)uVar3 + cVar4 * -10 | 0x30;
  }
  puVar2[2] = cVar6;
  puVar2[3] = bVar8;
  return puVar2 + 4;
}


// ==== FUN_00118a70 @ 00118a70

void FUN_00118a70(long param_1,int *param_2,int *param_3,long param_4,undefined8 param_5,
                 long param_6,undefined8 param_7,undefined8 param_8,ulong param_9,int param_10)

{
  ulong uVar1;
  int iVar2;
  int iVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  ulong uVar9;
  uint uVar10;
  ulong uVar11;
  uint uVar12;
  ulong uVar13;
  ulong uVar14;
  long lVar15;
  ulong uVar16;
  ulong uVar17;
  
  uVar7 = (ulong)(uint)-param_10;
  uVar8 = param_9 - param_4;
  uVar5 = param_9 - param_6;
  uVar4 = 1L << (uVar7 & 0x3f);
  uVar11 = param_9 >> (uVar7 & 0x3f);
  uVar10 = (uint)uVar11;
  uVar6 = uVar4 - 1 & param_9;
  if (uVar10 < 1000000000) {
    if (uVar10 < 100000000) {
      if (uVar10 < 10000000) {
        if (uVar10 < 1000000) {
          if (uVar10 >> 5 < 0xc35) {
            if (uVar10 >> 4 < 0x271) {
              if (uVar10 < 1000) {
                if (uVar10 < 100) {
                  uVar12 = 10;
                  if (uVar10 < 10) {
                    uVar12 = 1;
                  }
                  uVar13 = (ulong)uVar12;
                  iVar3 = 1;
                  if (9 < uVar10) {
                    iVar3 = 2;
                  }
                }
                else {
                  iVar3 = 3;
                  uVar13 = 100;
                }
              }
              else {
                iVar3 = 4;
                uVar13 = 1000;
              }
            }
            else {
              iVar3 = 5;
              uVar13 = 10000;
            }
          }
          else {
            uVar13 = 100000;
            iVar3 = 6;
          }
        }
        else {
          uVar13 = 1000000;
          iVar3 = 7;
        }
      }
      else {
        uVar13 = 10000000;
        iVar3 = 8;
      }
    }
    else {
      uVar13 = 100000000;
      iVar3 = 9;
    }
  }
  else {
    uVar13 = 1000000000;
    iVar3 = 10;
  }
  do {
    if (iVar3 < 1) {
      iVar3 = 0;
      do {
        uVar9 = uVar8;
        uVar11 = uVar5;
        iVar2 = *param_2;
        uVar13 = uVar6 * 10;
        iVar3 = iVar3 + -1;
        uVar6 = uVar13 & uVar4 - 1;
        uVar8 = uVar9 * 10;
        uVar5 = uVar11 * 10;
        *param_2 = iVar2 + 1;
        *(char *)(param_1 + iVar2) = (char)(uVar13 >> (uVar7 & 0x3f)) + '0';
      } while (uVar8 < uVar6);
      *param_3 = *param_3 + iVar3;
      if ((uVar6 < uVar5) && (uVar4 <= uVar8 - uVar6)) {
        iVar3 = *param_2;
        lVar15 = -uVar6;
        while ((uVar6 = uVar4 + uVar6, uVar6 < uVar5 ||
               (uVar11 * -10 + uVar6 < uVar11 * 10 + lVar15))) {
          *(char *)(param_1 + (long)iVar3 + -1) = *(char *)(param_1 + (long)iVar3 + -1) + -1;
          if (uVar5 <= uVar6) {
            return;
          }
          uVar8 = (uVar9 * 10 - uVar4) + lVar15;
          lVar15 = lVar15 - uVar4;
          if (uVar8 < uVar4) {
            return;
          }
        }
      }
      return;
    }
    uVar10 = 0;
    uVar12 = (uint)uVar13;
    if (uVar12 != 0) {
      uVar10 = (uint)uVar11 / uVar12;
    }
    iVar2 = *param_2;
    iVar3 = iVar3 + -1;
    *param_2 = iVar2 + 1;
    uVar11 = (ulong)((uint)uVar11 - uVar10 * uVar12);
    *(char *)(param_1 + iVar2) = (char)uVar10 + '0';
    lVar15 = uVar11 << (uVar7 & 0x3f);
    uVar9 = lVar15 + uVar6;
    if (uVar8 < uVar9) {
      uVar13 = uVar13 / 10;
    }
    else {
      uVar14 = uVar13 << (uVar7 & 0x3f);
      *param_3 = *param_3 + iVar3;
      if (uVar5 <= uVar9 || uVar8 - uVar9 < uVar14) {
        return;
      }
      iVar2 = *param_2;
      uVar16 = uVar6 + lVar15 + uVar14;
      lVar15 = -uVar16;
      uVar17 = param_9;
      do {
        if (((uVar5 <= uVar16) && ((-uVar9 - param_6) + uVar17 <= (param_6 - param_9) + uVar16)) ||
           (*(char *)(param_1 + (long)iVar2 + -1) = *(char *)(param_1 + (long)iVar2 + -1) + -1,
           uVar5 <= uVar16)) break;
        uVar1 = (lVar15 - param_4) + uVar17;
        uVar17 = uVar17 - uVar14;
        uVar16 = uVar16 + uVar14;
      } while (uVar14 <= uVar1);
    }
    if (uVar9 <= uVar8) {
      return;
    }
  } while( true );
}


// ==== FUN_00118d54 @ 00118d54

void FUN_00118d54(undefined8 *param_1,undefined8 *param_2)

{
  ulong uVar1;
  long lVar2;
  undefined8 *puVar3;
  ulong uVar4;
  void *__src;
  size_t __n;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  
  puVar3 = (undefined8 *)param_1[1];
  if (puVar3 < (undefined8 *)param_1[2]) {
    uVar5 = *param_2;
    puVar3[1] = param_2[1];
    *puVar3 = uVar5;
    uVar7 = param_2[6];
    uVar6 = param_2[9];
    uVar5 = param_2[8];
    uVar11 = param_2[3];
    uVar10 = param_2[2];
    uVar9 = param_2[5];
    uVar8 = param_2[4];
    puVar3[7] = param_2[7];
    puVar3[6] = uVar7;
    puVar3[9] = uVar6;
    puVar3[8] = uVar5;
    puVar3[3] = uVar11;
    puVar3[2] = uVar10;
    puVar3[5] = uVar9;
    puVar3[4] = uVar8;
    param_1[1] = puVar3 + 10;
  }
  else {
    __src = (void *)*param_1;
    __n = (long)puVar3 - (long)__src;
    uVar1 = ((long)__n >> 4) * -0x3333333333333333 + 1;
    if (0x333333333333333 < uVar1) {
      FUN_0011d4bc(param_1);
LAB_00118ea0:
                    /* WARNING: Subroutine does not return */
      FUN_001157bc("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
    }
    lVar2 = (long)param_1[2] - (long)__src >> 4;
    uVar4 = lVar2 * -0x6666666666666666;
    if (uVar1 <= uVar4) {
      uVar1 = uVar4;
    }
    if (0x199999999999998 < (ulong)(lVar2 * -0x3333333333333333)) {
      uVar1 = 0x333333333333333;
    }
    if (uVar1 == 0) {
      lVar2 = 0;
    }
    else {
      if (0x333333333333333 < uVar1) goto LAB_00118ea0;
      lVar2 = FUN_0011b974(uVar1 * 0x50);
    }
    uVar9 = param_2[8];
    uVar6 = param_2[5];
    uVar5 = param_2[4];
    uVar8 = param_2[7];
    uVar7 = param_2[6];
    puVar3 = (undefined8 *)(lVar2 + ((long)__n >> 4) * 0x10);
    puVar3[9] = param_2[9];
    puVar3[8] = uVar9;
    puVar3[5] = uVar6;
    puVar3[4] = uVar5;
    puVar3[7] = uVar8;
    puVar3[6] = uVar7;
    uVar7 = *param_2;
    uVar6 = param_2[3];
    uVar5 = param_2[2];
    puVar3[1] = param_2[1];
    *puVar3 = uVar7;
    puVar3[3] = uVar6;
    puVar3[2] = uVar5;
    if (0 < (long)__n) {
      memcpy((void *)((long)puVar3 - __n),__src,__n);
      __src = (void *)*param_1;
    }
    *param_1 = (void *)((long)puVar3 - __n);
    param_1[1] = puVar3 + 10;
    param_1[2] = lVar2 + uVar1 * 0x50;
    if (__src != (void *)0x0) {
      free(__src);
      return;
    }
  }
  return;
}


// ==== _INIT_0 @ 00118eac

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _INIT_0(void)

{
  DAT_00142e78 = 1000;
  uRam0000000000142e88 = 0;
  _DAT_00142e80 = 0;
  uRam0000000000142e98 = 0;
  _DAT_00142e90 = 0;
  uRam0000000000142ea8 = 0;
  _DAT_00142ea0 = 0;
  uRam0000000000142eb8 = 0;
  _DAT_00142eb0 = 0;
  uRam0000000000142ec8 = 0;
  _DAT_00142ec0 = 0;
  DAT_00142ed8 = 0;
  _DAT_00142ed0 = 0;
  DAT_00142ee8 = 0;
  DAT_00142ee0 = 0;
                    /* try { // try from 00118ee8 to 00118ef3 has its CatchHandler @ 00118f28 */
  DAT_00142ed8 = FUN_0011b974(80000);
  DAT_00142ee8 = DAT_00142ed8 + 80000;
  DAT_00142ee0 = DAT_00142ed8;
  __cxa_atexit(FUN_00113a80,&DAT_00142e78,&PTR_LOOP_0013c1e0);
  return;
}


// ==== thunk_FUN_00118f5c @ 00118f4c

void thunk_FUN_00118f5c(char *param_1,char *param_2,long param_3,undefined8 param_4)

{
  long lVar1;
  int iVar2;
  undefined8 uVar3;
  undefined8 *__ptr;
  char *pcVar4;
  uchar *puStack_68;
  ulong uStack_60;
  ulong uStack_58;
  reg_syntax_t rStack_50;
  char *pcStack_48;
  
  lVar1 = tpidr_el0;
  pcStack_48 = *(char **)(lVar1 + 0x28);
  uVar3 = 0x3ea;
  if (((param_1 != (char *)0x0) && (param_2 != (char *)0x0)) && (param_3 != 0)) {
    if (DAT_00142ef0 == 0) {
      iVar2 = regcomp((regex_t *)&puStack_68,param_1,4);
      if (iVar2 == 0) {
        __ptr = malloc(0x48);
        if (__ptr == (undefined8 *)0x0) {
          uVar3 = 0x3eb;
        }
        else {
          pcVar4 = strdup(param_2);
          __ptr[4] = pcVar4;
          if (pcVar4 == (char *)0x0) {
            free(__ptr);
            uVar3 = 0x3eb;
          }
          else {
            __ptr[5] = param_3;
            __ptr[6] = param_4;
            __ptr[1] = uStack_60;
            *__ptr = puStack_68;
            __ptr[3] = rStack_50;
            __ptr[2] = uStack_58;
            pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
            __ptr[7] = 0;
            __ptr[8] = PTR_DAT_00142df0;
            *(undefined8 **)PTR_DAT_00142df0 = __ptr;
            PTR_DAT_00142df0 = (undefined *)(__ptr + 7);
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
            uVar3 = 0;
          }
        }
        goto LAB_00118ff8;
      }
    }
    else if (DAT_00142e08 < 7) {
      __android_log_print(6,"xhook","do not register hook after refresh(): %s, %s",param_1,param_2);
    }
    uVar3 = 0x3ea;
  }
LAB_00118ff8:
  if (*(char **)(lVar1 + 0x28) != pcStack_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar3);
  }
  return;
}


// ==== thunk_FUN_001190a8 @ 00118f50

void thunk_FUN_001190a8(int param_1)

{
  long lVar1;
  int iVar2;
  undefined8 uVar3;
  pthread_mutex_t *__mutex;
  undefined1 auStack_68 [8];
  code *pcStack_60;
  undefined1 auStack_58 [16];
  ulong uStack_48;
  
  lVar1 = tpidr_el0;
  uStack_48 = *(ulong *)(lVar1 + 0x28);
  if (DAT_00142ef0 == 0) {
    iVar2 = pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
    if (DAT_00142ef0 == 0) {
      DAT_00142ef0 = 1;
      if (DAT_00142e08 < 5) {
        uVar3 = FUN_0011b850(iVar2);
        __android_log_print(4,"xhook",&DAT_0010b358,uVar3);
      }
      if (DAT_00142de0 == 0) {
LAB_00119180:
        DAT_00142ef4 = 1;
      }
      else {
        iVar2 = sigemptyset((sigset_t *)auStack_58);
        if (iVar2 == 0) {
          pcStack_60 = FUN_00119958;
          iVar2 = sigaction(0xb,(sigaction *)auStack_68,(sigaction *)&DAT_00142f20);
          if (iVar2 == 0) goto LAB_00119180;
        }
      }
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
  }
  if (DAT_00142ef4 == 0) {
LAB_00119240:
    uVar3 = 0x3e9;
    if (*(ulong *)(lVar1 + 0x28) != uStack_48) {
LAB_00119210:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(uVar3);
    }
  }
  else {
    if (param_1 == 0) {
      __mutex = (pthread_mutex_t *)&DAT_00142f68;
      iVar2 = pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f68);
      FUN_00119a5c(iVar2);
    }
    else {
      if (DAT_00142f04 == 0) {
        pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
        if (DAT_00142f04 == 0) {
          DAT_00142f04 = 1;
          DAT_00142f00 = 1;
          iVar2 = pthread_create(&DAT_00142f10,(pthread_attr_t *)0x0,FUN_00119994,(void *)0x0);
          if (iVar2 == 0) {
            DAT_00142ef8 = 1;
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
          }
          else {
            DAT_00142f00 = 0;
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
          }
        }
        else {
          pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
        }
      }
      if (DAT_00142ef8 == 0) goto LAB_00119240;
      __mutex = (pthread_mutex_t *)&DAT_00142f40;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
      DAT_00142efc = 1;
      pthread_cond_signal((pthread_cond_t *)&DAT_00142f90);
    }
    pthread_mutex_unlock(__mutex);
    uVar3 = 0;
    if (*(ulong *)(lVar1 + 0x28) != uStack_48) goto LAB_00119210;
  }
  return;
}


// ==== thunk_FUN_001192d8 @ 00118f54

int thunk_FUN_001192d8(void)

{
  regex_t *prVar1;
  regex_t *prVar2;
  int iVar3;
  undefined8 *__ptr;
  undefined8 *puVar4;
  long *plVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  
  if (DAT_00142ef8 != 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
    DAT_00142f00 = 0;
    pthread_cond_signal((pthread_cond_t *)&DAT_00142f90);
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
    pthread_join(DAT_00142f10,(void **)0x0);
    DAT_00142ef8 = 0;
  }
  DAT_00142f04 = 0;
  if (DAT_00142ef4 != 0) {
    if (DAT_00142de0 != 0) {
      sigaction(0xb,(sigaction *)&DAT_00142f20,(sigaction *)0x0);
    }
    DAT_00142ef4 = 0;
  }
  DAT_00142ef0 = 0;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f68);
  puVar6 = &DAT_00142f18;
  puVar4 = (undefined8 *)0x0;
  do {
    __ptr = puVar4;
    puVar4 = (undefined8 *)*puVar6;
    puVar6 = puVar4 + 0x18;
  } while (puVar4 != (undefined8 *)0x0);
  do {
    prVar2 = DAT_00142de8;
    if (__ptr == (undefined8 *)0x0) {
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = *(regex_t **)&prVar2->field_0x38;
        plVar5 = (long *)prVar2[1].buffer;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_00142df0 = (undefined *)plVar5;
        }
        else {
          prVar1[1].buffer = (uchar *)plVar5;
          plVar5 = (long *)prVar2[1].buffer;
        }
        *plVar5 = (long)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      prVar2 = DAT_00142df8;
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = (regex_t *)prVar2->translate;
        plVar5 = (long *)prVar2->re_nsub;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_00142e00 = (undefined *)plVar5;
        }
        else {
          prVar1->re_nsub = (size_t)plVar5;
          plVar5 = (long *)prVar2->re_nsub;
        }
        *plVar5 = (long)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f68);
      iVar3 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
      return iVar3;
    }
    puVar6 = (undefined8 *)__ptr[0x19];
    if ((undefined8 *)__ptr[0x19] == (undefined8 *)0x0) {
      puVar4 = (undefined8 *)__ptr[0x1a];
      if ((puVar4 != (undefined8 *)0x0) && ((undefined8 *)puVar4[0x18] != __ptr)) {
        puVar6 = __ptr;
        puVar7 = puVar4;
        do {
          puVar4 = puVar7;
          if (puVar6 != (undefined8 *)puVar7[0x19]) break;
          puVar4 = (undefined8 *)puVar7[0x1a];
          puVar6 = puVar7;
          puVar7 = puVar4;
        } while (puVar4 != (undefined8 *)0x0);
      }
    }
    else {
      do {
        puVar4 = puVar6;
        puVar6 = (undefined8 *)puVar4[0x18];
      } while (puVar6 != (undefined8 *)0x0);
    }
    FUN_001194d8(__ptr);
    if ((void *)*__ptr != (void *)0x0) {
      free((void *)*__ptr);
    }
    free(__ptr);
    __ptr = puVar4;
  } while( true );
}


// ==== thunk_FUN_00119944 @ 00118f58

void thunk_FUN_00119944(int param_1)

{
  DAT_00142de0 = (uint)(param_1 != 0);
  return;
}


// ==== FUN_00118f5c @ 00118f5c

void FUN_00118f5c(char *param_1,char *param_2,long param_3,undefined8 param_4)

{
  long lVar1;
  int iVar2;
  undefined8 uVar3;
  undefined8 *__ptr;
  char *pcVar4;
  uchar *local_68;
  ulong uStack_60;
  ulong local_58;
  reg_syntax_t rStack_50;
  char *local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(char **)(lVar1 + 0x28);
  uVar3 = 0x3ea;
  if (((param_1 != (char *)0x0) && (param_2 != (char *)0x0)) && (param_3 != 0)) {
    if (DAT_00142ef0 == 0) {
      iVar2 = regcomp((regex_t *)&local_68,param_1,4);
      if (iVar2 == 0) {
        __ptr = malloc(0x48);
        if (__ptr == (undefined8 *)0x0) {
          uVar3 = 0x3eb;
        }
        else {
          pcVar4 = strdup(param_2);
          __ptr[4] = pcVar4;
          if (pcVar4 == (char *)0x0) {
            free(__ptr);
            uVar3 = 0x3eb;
          }
          else {
            __ptr[5] = param_3;
            __ptr[6] = param_4;
            __ptr[1] = uStack_60;
            *__ptr = local_68;
            __ptr[3] = rStack_50;
            __ptr[2] = local_58;
            pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
            __ptr[7] = 0;
            __ptr[8] = PTR_DAT_00142df0;
            *(undefined8 **)PTR_DAT_00142df0 = __ptr;
            PTR_DAT_00142df0 = (undefined *)(__ptr + 7);
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
            uVar3 = 0;
          }
        }
        goto LAB_00118ff8;
      }
    }
    else if (DAT_00142e08 < 7) {
      __android_log_print(6,"xhook","do not register hook after refresh(): %s, %s",param_1,param_2);
    }
    uVar3 = 0x3ea;
  }
LAB_00118ff8:
  if (*(char **)(lVar1 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar3);
  }
  return;
}


// ==== FUN_001190a8 @ 001190a8

void FUN_001190a8(int param_1)

{
  long lVar1;
  int iVar2;
  undefined8 uVar3;
  pthread_mutex_t *__mutex;
  undefined1 auStack_68 [8];
  code *local_60;
  undefined1 auStack_58 [16];
  ulong local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(ulong *)(lVar1 + 0x28);
  if (DAT_00142ef0 == 0) {
    iVar2 = pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
    if (DAT_00142ef0 == 0) {
      DAT_00142ef0 = 1;
      if (DAT_00142e08 < 5) {
        uVar3 = FUN_0011b850(iVar2);
        __android_log_print(4,"xhook",&DAT_0010b358,uVar3);
      }
      if (DAT_00142de0 == 0) {
LAB_00119180:
        DAT_00142ef4 = 1;
      }
      else {
        iVar2 = sigemptyset((sigset_t *)auStack_58);
        if (iVar2 == 0) {
          local_60 = FUN_00119958;
          iVar2 = sigaction(0xb,(sigaction *)auStack_68,(sigaction *)&DAT_00142f20);
          if (iVar2 == 0) goto LAB_00119180;
        }
      }
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
  }
  if (DAT_00142ef4 == 0) {
LAB_00119240:
    uVar3 = 0x3e9;
    if (*(ulong *)(lVar1 + 0x28) != local_48) {
LAB_00119210:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(uVar3);
    }
  }
  else {
    if (param_1 == 0) {
      __mutex = (pthread_mutex_t *)&DAT_00142f68;
      iVar2 = pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f68);
      FUN_00119a5c(iVar2);
    }
    else {
      if (DAT_00142f04 == 0) {
        pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
        if (DAT_00142f04 == 0) {
          DAT_00142f04 = 1;
          DAT_00142f00 = 1;
          iVar2 = pthread_create(&DAT_00142f10,(pthread_attr_t *)0x0,FUN_00119994,(void *)0x0);
          if (iVar2 == 0) {
            DAT_00142ef8 = 1;
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
          }
          else {
            DAT_00142f00 = 0;
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
          }
        }
        else {
          pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
        }
      }
      if (DAT_00142ef8 == 0) goto LAB_00119240;
      __mutex = (pthread_mutex_t *)&DAT_00142f40;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
      DAT_00142efc = 1;
      pthread_cond_signal((pthread_cond_t *)&DAT_00142f90);
    }
    pthread_mutex_unlock(__mutex);
    uVar3 = 0;
    if (*(ulong *)(lVar1 + 0x28) != local_48) goto LAB_00119210;
  }
  return;
}


// ==== FUN_001192d8 @ 001192d8

int FUN_001192d8(void)

{
  regex_t *prVar1;
  regex_t *prVar2;
  int iVar3;
  undefined8 *__ptr;
  undefined8 *puVar4;
  long *plVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  
  if (DAT_00142ef8 != 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
    DAT_00142f00 = 0;
    pthread_cond_signal((pthread_cond_t *)&DAT_00142f90);
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
    pthread_join(DAT_00142f10,(void **)0x0);
    DAT_00142ef8 = 0;
  }
  DAT_00142f04 = 0;
  if (DAT_00142ef4 != 0) {
    if (DAT_00142de0 != 0) {
      sigaction(0xb,(sigaction *)&DAT_00142f20,(sigaction *)0x0);
    }
    DAT_00142ef4 = 0;
  }
  DAT_00142ef0 = 0;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f68);
  puVar6 = &DAT_00142f18;
  puVar4 = (undefined8 *)0x0;
  do {
    __ptr = puVar4;
    puVar4 = (undefined8 *)*puVar6;
    puVar6 = puVar4 + 0x18;
  } while (puVar4 != (undefined8 *)0x0);
  do {
    prVar2 = DAT_00142de8;
    if (__ptr == (undefined8 *)0x0) {
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = *(regex_t **)&prVar2->field_0x38;
        plVar5 = (long *)prVar2[1].buffer;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_00142df0 = (undefined *)plVar5;
        }
        else {
          prVar1[1].buffer = (uchar *)plVar5;
          plVar5 = (long *)prVar2[1].buffer;
        }
        *plVar5 = (long)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      prVar2 = DAT_00142df8;
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = (regex_t *)prVar2->translate;
        plVar5 = (long *)prVar2->re_nsub;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_00142e00 = (undefined *)plVar5;
        }
        else {
          prVar1->re_nsub = (size_t)plVar5;
          plVar5 = (long *)prVar2->re_nsub;
        }
        *plVar5 = (long)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f68);
      iVar3 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
      return iVar3;
    }
    puVar6 = (undefined8 *)__ptr[0x19];
    if ((undefined8 *)__ptr[0x19] == (undefined8 *)0x0) {
      puVar4 = (undefined8 *)__ptr[0x1a];
      if ((puVar4 != (undefined8 *)0x0) && ((undefined8 *)puVar4[0x18] != __ptr)) {
        puVar6 = __ptr;
        puVar7 = puVar4;
        do {
          puVar4 = puVar7;
          if (puVar6 != (undefined8 *)puVar7[0x19]) break;
          puVar4 = (undefined8 *)puVar7[0x1a];
          puVar6 = puVar7;
          puVar7 = puVar4;
        } while (puVar4 != (undefined8 *)0x0);
      }
    }
    else {
      do {
        puVar4 = puVar6;
        puVar6 = (undefined8 *)puVar4[0x18];
      } while (puVar6 != (undefined8 *)0x0);
    }
    FUN_001194d8(__ptr);
    if ((void *)*__ptr != (void *)0x0) {
      free((void *)*__ptr);
    }
    free(__ptr);
    __ptr = puVar4;
  } while( true );
}


// ==== FUN_001194d8 @ 001194d8

void FUN_001194d8(long param_1)

{
  undefined4 uVar1;
  long lVar2;
  int iVar3;
  long lVar4;
  long lVar5;
  long lVar6;
  long lVar7;
  long *plVar8;
  long lVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  
  lVar4 = *(long *)(param_1 + 0xc0);
  lVar2 = *(long *)(param_1 + 200);
  if (lVar4 == 0) {
    lVar9 = *(long *)(param_1 + 0xd0);
    iVar3 = *(int *)(param_1 + 0xd8);
    if (lVar2 != 0) goto LAB_00119558;
    if (lVar9 != 0) goto LAB_00119534;
LAB_00119560:
    plVar8 = &DAT_00142f18;
  }
  else {
    if (lVar2 != 0) {
      do {
        lVar4 = lVar2;
        lVar2 = *(long *)(lVar4 + 0xc0);
      } while (lVar2 != 0);
      lVar2 = *(long *)(lVar4 + 200);
      lVar5 = *(long *)(lVar4 + 0xd0);
      iVar3 = *(int *)(lVar4 + 0xd8);
      if (lVar2 != 0) {
        *(long *)(lVar2 + 0xd0) = lVar5;
      }
      if (lVar5 == 0) {
        plVar8 = &DAT_00142f18;
      }
      else {
        plVar8 = (long *)(lVar5 + 0xc0);
        if (*(long *)(lVar5 + 0xc0) != lVar4) {
          plVar8 = (long *)(lVar5 + 200);
        }
      }
      *plVar8 = lVar2;
      lVar9 = *(long *)(param_1 + 0xc0);
      uVar11 = *(undefined8 *)(param_1 + 0xd8);
      uVar10 = *(undefined8 *)(param_1 + 0xd0);
      lVar6 = *(long *)(lVar4 + 0xd0);
      *(undefined8 *)(lVar4 + 200) = *(undefined8 *)(param_1 + 200);
      *(long *)(lVar4 + 0xc0) = lVar9;
      *(undefined8 *)(lVar4 + 0xd8) = uVar11;
      *(undefined8 *)(lVar4 + 0xd0) = uVar10;
      lVar7 = *(long *)(param_1 + 0xd0);
      lVar9 = lVar4;
      if (lVar6 != param_1) {
        lVar9 = lVar5;
      }
      if (lVar7 == 0) {
        lVar5 = *(long *)(param_1 + 200);
        DAT_00142f18 = lVar4;
        *(long *)(*(long *)(param_1 + 0xc0) + 0xd0) = lVar4;
      }
      else {
        plVar8 = (long *)(lVar7 + 0xc0);
        if (*(long *)(lVar7 + 0xc0) != param_1) {
          plVar8 = (long *)(lVar7 + 200);
        }
        *plVar8 = lVar4;
        lVar5 = *(long *)(param_1 + 200);
        *(long *)(*(long *)(param_1 + 0xc0) + 0xd0) = lVar4;
      }
      if (lVar5 != 0) {
        *(long *)(lVar5 + 0xd0) = lVar4;
      }
      goto LAB_001195bc;
    }
    lVar9 = *(long *)(param_1 + 0xd0);
    iVar3 = *(int *)(param_1 + 0xd8);
    lVar2 = lVar4;
LAB_00119558:
    *(long *)(lVar2 + 0xd0) = lVar9;
    if (lVar9 == 0) goto LAB_00119560;
LAB_00119534:
    plVar8 = (long *)(lVar9 + 0xc0);
    if (*(long *)(lVar9 + 0xc0) != param_1) {
      plVar8 = (long *)(lVar9 + 200);
    }
  }
  *plVar8 = lVar2;
LAB_001195bc:
  if (iVar3 != 0) {
    return;
  }
  lVar4 = DAT_00142f18;
  do {
    if (lVar2 == 0) {
      if (lVar4 == 0) {
        return;
      }
    }
    else if ((*(int *)(lVar2 + 0xd8) != 0) || (lVar2 == lVar4)) goto LAB_0011993c;
    lVar5 = *(long *)(lVar9 + 0xc0);
    if (lVar5 == lVar2) {
      lVar5 = *(long *)(lVar9 + 200);
      lVar2 = lVar5;
      if (*(int *)(lVar5 + 0xd8) == 1) {
        lVar2 = *(long *)(lVar5 + 0xc0);
        *(undefined4 *)(lVar5 + 0xd8) = 0;
        *(undefined4 *)(lVar9 + 0xd8) = 1;
        *(long *)(lVar9 + 200) = lVar2;
        if (lVar2 != 0) {
          *(long *)(lVar2 + 0xd0) = lVar9;
        }
        lVar6 = *(long *)(lVar9 + 0xd0);
        *(long *)(lVar5 + 0xd0) = lVar6;
        if (lVar6 == 0) {
          lVar4 = lVar5;
          DAT_00142f18 = lVar5;
        }
        else {
          lVar6 = *(long *)(lVar9 + 0xd0);
          if (lVar9 == *(long *)(lVar6 + 0xc0)) {
            *(long *)(lVar6 + 0xc0) = lVar5;
          }
          else {
            *(long *)(lVar6 + 200) = lVar5;
            lVar2 = *(long *)(lVar9 + 200);
          }
        }
        *(long *)(lVar5 + 0xc0) = lVar9;
        *(long *)(lVar9 + 0xd0) = lVar5;
      }
      lVar5 = *(long *)(lVar2 + 0xc0);
      if ((lVar5 == 0) || (*(int *)(lVar5 + 0xd8) == 0)) {
        lVar6 = *(long *)(lVar2 + 200);
        if ((lVar6 == 0) || (*(int *)(lVar6 + 0xd8) == 0)) goto LAB_001195d4;
LAB_00119770:
        *(undefined4 *)(lVar2 + 0xd8) = *(undefined4 *)(lVar9 + 0xd8);
        *(undefined4 *)(lVar9 + 0xd8) = 0;
LAB_001198d0:
        *(undefined4 *)(lVar6 + 0xd8) = 0;
      }
      else {
        lVar6 = *(long *)(lVar2 + 200);
        if ((lVar6 != 0) && (*(int *)(lVar6 + 0xd8) != 0)) goto LAB_00119770;
        lVar6 = *(long *)(lVar5 + 200);
        *(undefined4 *)(lVar5 + 0xd8) = 0;
        *(undefined4 *)(lVar2 + 0xd8) = 1;
        *(long *)(lVar2 + 0xc0) = lVar6;
        if (lVar6 != 0) {
          *(long *)(lVar6 + 0xd0) = lVar2;
        }
        lVar6 = *(long *)(lVar2 + 0xd0);
        *(long *)(lVar5 + 0xd0) = lVar6;
        if (lVar6 == 0) {
          plVar8 = &DAT_00142f18;
          lVar4 = lVar5;
        }
        else {
          plVar8 = (long *)(*(long *)(lVar2 + 0xd0) + 0xc0);
          if (lVar2 != *plVar8) {
            plVar8 = (long *)(*(long *)(lVar2 + 0xd0) + 200);
          }
        }
        *plVar8 = lVar5;
        uVar1 = *(undefined4 *)(lVar9 + 0xd8);
        *(long *)(lVar5 + 200) = lVar2;
        *(long *)(lVar2 + 0xd0) = lVar5;
        lVar2 = *(long *)(lVar9 + 200);
        lVar6 = *(long *)(lVar2 + 200);
        *(undefined4 *)(lVar2 + 0xd8) = uVar1;
        *(undefined4 *)(lVar9 + 0xd8) = 0;
        if (lVar6 != 0) goto LAB_001198d0;
      }
      lVar5 = *(long *)(lVar2 + 0xc0);
      *(long *)(lVar9 + 200) = lVar5;
      if (lVar5 != 0) {
        *(long *)(lVar5 + 0xd0) = lVar9;
      }
      lVar5 = *(long *)(lVar9 + 0xd0);
      *(long *)(lVar2 + 0xd0) = lVar5;
      if (lVar5 == 0) {
        DAT_00142f18 = lVar2;
        *(long *)(lVar2 + 0xc0) = lVar9;
        *(long *)(lVar9 + 0xd0) = lVar2;
      }
      else {
        plVar8 = (long *)(*(long *)(lVar9 + 0xd0) + 0xc0);
        if (lVar9 != *plVar8) {
          plVar8 = (long *)(*(long *)(lVar9 + 0xd0) + 200);
        }
        *plVar8 = lVar2;
        *(long *)(lVar2 + 0xc0) = lVar9;
        *(long *)(lVar9 + 0xd0) = lVar2;
        lVar2 = lVar4;
      }
      goto joined_r0x00119914;
    }
    lVar2 = lVar5;
    if (*(int *)(lVar5 + 0xd8) == 1) {
      lVar2 = *(long *)(lVar5 + 200);
      *(undefined4 *)(lVar5 + 0xd8) = 0;
      *(undefined4 *)(lVar9 + 0xd8) = 1;
      *(long *)(lVar9 + 0xc0) = lVar2;
      if (lVar2 != 0) {
        *(long *)(lVar2 + 0xd0) = lVar9;
      }
      lVar6 = *(long *)(lVar9 + 0xd0);
      *(long *)(lVar5 + 0xd0) = lVar6;
      if (lVar6 == 0) {
        lVar4 = lVar5;
        DAT_00142f18 = lVar5;
      }
      else {
        lVar6 = *(long *)(lVar9 + 0xd0);
        if (lVar9 == *(long *)(lVar6 + 0xc0)) {
          *(long *)(lVar6 + 0xc0) = lVar5;
          lVar2 = *(long *)(lVar9 + 0xc0);
        }
        else {
          *(long *)(lVar6 + 200) = lVar5;
        }
      }
      *(long *)(lVar5 + 200) = lVar9;
      *(long *)(lVar9 + 0xd0) = lVar5;
    }
    lVar5 = *(long *)(lVar2 + 0xc0);
    if ((lVar5 != 0) && (*(int *)(lVar5 + 0xd8) != 0)) goto LAB_00119750;
    lVar6 = *(long *)(lVar2 + 200);
    if ((lVar6 != 0) && (*(int *)(lVar6 + 0xd8) != 0)) break;
LAB_001195d4:
    lVar5 = *(long *)(lVar9 + 0xd0);
    *(undefined4 *)(lVar2 + 0xd8) = 1;
    lVar2 = lVar9;
    lVar9 = lVar5;
  } while( true );
  if ((lVar5 == 0) || (*(int *)(lVar5 + 0xd8) == 0)) {
    lVar5 = *(long *)(lVar6 + 0xc0);
    *(undefined4 *)(lVar6 + 0xd8) = 0;
    *(undefined4 *)(lVar2 + 0xd8) = 1;
    *(long *)(lVar2 + 200) = lVar5;
    if (lVar5 != 0) {
      *(long *)(lVar5 + 0xd0) = lVar2;
    }
    lVar5 = *(long *)(lVar2 + 0xd0);
    *(long *)(lVar6 + 0xd0) = lVar5;
    if (lVar5 == 0) {
      plVar8 = &DAT_00142f18;
      lVar4 = lVar6;
    }
    else {
      plVar8 = (long *)(*(long *)(lVar2 + 0xd0) + 0xc0);
      if (lVar2 != *plVar8) {
        plVar8 = (long *)(*(long *)(lVar2 + 0xd0) + 200);
      }
    }
    *plVar8 = lVar6;
    uVar1 = *(undefined4 *)(lVar9 + 0xd8);
    *(long *)(lVar6 + 0xc0) = lVar2;
    *(long *)(lVar2 + 0xd0) = lVar6;
    lVar2 = *(long *)(lVar9 + 0xc0);
    lVar5 = *(long *)(lVar2 + 0xc0);
    *(undefined4 *)(lVar2 + 0xd8) = uVar1;
    *(undefined4 *)(lVar9 + 0xd8) = 0;
    if (lVar5 == 0) goto LAB_00119834;
  }
  else {
LAB_00119750:
    *(undefined4 *)(lVar2 + 0xd8) = *(undefined4 *)(lVar9 + 0xd8);
    *(undefined4 *)(lVar9 + 0xd8) = 0;
  }
  *(undefined4 *)(lVar5 + 0xd8) = 0;
LAB_00119834:
  lVar5 = *(long *)(lVar2 + 200);
  *(long *)(lVar9 + 0xc0) = lVar5;
  if (lVar5 != 0) {
    *(long *)(lVar5 + 0xd0) = lVar9;
  }
  lVar5 = *(long *)(lVar9 + 0xd0);
  *(long *)(lVar2 + 0xd0) = lVar5;
  if (lVar5 == 0) {
    DAT_00142f18 = lVar2;
    *(long *)(lVar2 + 200) = lVar9;
    *(long *)(lVar9 + 0xd0) = lVar2;
  }
  else {
    plVar8 = (long *)(*(long *)(lVar9 + 0xd0) + 0xc0);
    if (lVar9 != *plVar8) {
      plVar8 = (long *)(*(long *)(lVar9 + 0xd0) + 200);
    }
    *plVar8 = lVar2;
    *(long *)(lVar2 + 200) = lVar9;
    *(long *)(lVar9 + 0xd0) = lVar2;
    lVar2 = lVar4;
  }
joined_r0x00119914:
  if (lVar2 == 0) {
    return;
  }
LAB_0011993c:
  *(undefined4 *)(lVar2 + 0xd8) = 0;
  return;
}


// ==== FUN_00119944 @ 00119944

void FUN_00119944(int param_1)

{
  DAT_00142de0 = (uint)(param_1 != 0);
  return;
}


// ==== FUN_00119958 @ 00119958

int FUN_00119958(void)

{
  int iVar1;
  
  if (DAT_00142f08 != 0) {
                    /* WARNING: Subroutine does not return */
    siglongjmp((__jmp_buf_tag *)&DAT_00142fc0,1);
  }
  iVar1 = sigaction(0xb,(sigaction *)&DAT_00142f20,(sigaction *)0x0);
  return iVar1;
}


// ==== FUN_00119994 @ 00119994

undefined8 FUN_00119994(void)

{
  int iVar1;
  pthread_t __target_thread;
  
  __target_thread = pthread_self();
  pthread_setname_np(__target_thread,"xh_refresh_loop");
  while( true ) {
    if (DAT_00142f00 == 0) {
      return 0;
    }
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f40);
    while ((DAT_00142efc == 0 && (DAT_00142f00 != 0))) {
      pthread_cond_wait((pthread_cond_t *)&DAT_00142f90,(pthread_mutex_t *)&DAT_00142f40);
    }
    if (DAT_00142f00 == 0) break;
    DAT_00142efc = 0;
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
    iVar1 = pthread_mutex_lock((pthread_mutex_t *)&DAT_00142f68);
    FUN_00119a5c(iVar1);
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f68);
  }
  pthread_mutex_unlock((pthread_mutex_t *)&DAT_00142f40);
  return 0;
}


// ==== FUN_00119a5c @ 00119a5c

void FUN_00119a5c(void)

{
  bool bVar1;
  long lVar2;
  regex_t *__preg;
  regex_t *__preg_00;
  int iVar3;
  FILE *__stream;
  char *pcVar4;
  size_t sVar5;
  undefined8 uVar6;
  char *pcVar7;
  long lVar8;
  long lVar9;
  undefined8 *__ptr;
  undefined8 *puVar10;
  uint uVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined8 *local_298;
  int local_28c;
  ulong local_288;
  ulong local_280;
  char local_278 [3];
  char local_275;
  char acStack_271 [513];
  long local_70;
  
  lVar2 = tpidr_el0;
  local_70 = *(long *)(lVar2 + 0x28);
  local_298 = (undefined8 *)0x0;
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    if (6 < DAT_00142e08) goto LAB_00119db0;
    pcVar7 = "fopen /proc/self/maps failed";
    uVar6 = 6;
  }
  else {
    pcVar7 = acStack_271 + 1;
    pcVar4 = fgets(acStack_271 + 1,0x200,__stream);
    if (pcVar4 != (char *)0x0) {
LAB_00119b40:
      iVar3 = sscanf(acStack_271 + 1,"%lx-%*lx %4s %lx %*x:%*x %*d%n",&local_280,local_278,
                     &local_288,&local_28c);
      if ((((iVar3 == 3) && (local_278[0] == 'r')) && (local_275 == 'p')) && (local_288 == 0)) {
        lVar8 = (long)local_28c;
        if (((byte)pcVar7[lVar8] == 0x20 || (byte)pcVar7[lVar8] - 9 < 5) &&
           (lVar9 = lVar8, local_28c < 0x1ff)) {
          do {
            uVar11 = (uint)*(byte *)(((ulong)pcVar7 | 1) + lVar9);
            lVar8 = lVar9 + 1;
            if (uVar11 != 0x20 && 4 < uVar11 - 9) break;
            bVar1 = lVar9 < 0x1fe;
            lVar9 = lVar8;
          } while (bVar1);
          local_28c = (int)lVar8;
        }
        if (local_28c < 0x1ff) {
          pcVar4 = pcVar7 + lVar8;
          sVar5 = strlen(pcVar4);
          if (((sVar5 != 0) &&
              ((lVar8 = sVar5 - 1, pcVar4[lVar8] != '\n' || (pcVar4[lVar8] = '\0', lVar8 != 0)))) &&
             (__preg_00 = DAT_00142de8, *pcVar4 != '[')) {
            for (; __preg_00 != (regex_t *)0x0; __preg_00 = *(regex_t **)&__preg_00->field_0x38) {
              iVar3 = regexec(__preg_00,pcVar4,0,(regmatch_t *)0x0,0);
              __preg = DAT_00142df8;
              if (iVar3 == 0) goto joined_r0x00119c70;
            }
          }
        }
      }
      goto LAB_00119b2c;
    }
LAB_00119d54:
    fclose(__stream);
    puVar12 = &DAT_00142f18;
    puVar10 = (undefined8 *)0x0;
    do {
      __ptr = puVar10;
      puVar10 = (undefined8 *)*puVar12;
      puVar12 = puVar10 + 0x18;
    } while (puVar10 != (undefined8 *)0x0);
    while (__ptr != (undefined8 *)0x0) {
      puVar12 = (undefined8 *)__ptr[0x19];
      if ((undefined8 *)__ptr[0x19] == (undefined8 *)0x0) {
        puVar10 = (undefined8 *)__ptr[0x1a];
        if ((puVar10 != (undefined8 *)0x0) && ((undefined8 *)puVar10[0x18] != __ptr)) {
          puVar12 = __ptr;
          puVar13 = puVar10;
          do {
            puVar10 = puVar13;
            if (puVar12 != (undefined8 *)puVar13[0x19]) break;
            puVar10 = (undefined8 *)puVar13[0x1a];
            puVar12 = puVar13;
            puVar13 = puVar10;
          } while (puVar10 != (undefined8 *)0x0);
        }
      }
      else {
        do {
          puVar10 = puVar12;
          puVar12 = (undefined8 *)puVar10[0x18];
        } while (puVar12 != (undefined8 *)0x0);
      }
      FUN_001194d8(__ptr);
      if ((void *)*__ptr != (void *)0x0) {
        free((void *)*__ptr);
      }
      free(__ptr);
      __ptr = puVar10;
    }
    DAT_00142f18 = local_298;
    if (4 < DAT_00142e08) goto LAB_00119db0;
    pcVar7 = "map refreshed";
    uVar6 = 4;
  }
  __android_log_print(uVar6,"xhook",pcVar7);
LAB_00119db0:
  if (*(long *)(lVar2 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
joined_r0x00119c70:
  if (__preg == (regex_t *)0x0) goto LAB_00119c74;
  iVar3 = regexec(__preg,pcVar4,0,(regmatch_t *)0x0,0);
  if ((iVar3 == 0) &&
     ((__preg->fastmap == (char *)0x0 ||
      (iVar3 = strcmp(__preg->fastmap,__preg_00->fastmap), iVar3 == 0)))) goto LAB_00119b2c;
  __preg = (regex_t *)__preg->translate;
  goto joined_r0x00119c70;
LAB_00119c74:
  iVar3 = FUN_00119e58(local_280,pcVar4);
  puVar12 = DAT_00142f18;
  if (iVar3 == 0) {
    for (; puVar12 != (undefined8 *)0x0; puVar12 = (undefined8 *)puVar12[0x18]) {
      while (iVar3 = strcmp(pcVar4,(char *)*puVar12), -1 < iVar3) {
        if (iVar3 == 0) {
          FUN_001194d8(puVar12);
          lVar8 = FUN_00119efc(&local_298,puVar12);
          if (lVar8 != 0) goto LAB_00119b1c;
          if (puVar12[1] == local_280) goto LAB_00119b2c;
          puVar12[1] = local_280;
          goto LAB_00119d48;
        }
        puVar12 = (undefined8 *)puVar12[0x19];
        if (puVar12 == (undefined8 *)0x0) goto LAB_00119cf8;
      }
    }
LAB_00119cf8:
    puVar12 = malloc(0xe0);
    if (puVar12 != (undefined8 *)0x0) {
      pcVar4 = strdup(pcVar4);
      *puVar12 = pcVar4;
      if (pcVar4 != (char *)0x0) {
        puVar12[1] = local_280;
        lVar8 = FUN_00119efc(&local_298,puVar12);
        if (lVar8 == 0) {
LAB_00119d48:
          FUN_0011a1ac(puVar12);
          goto LAB_00119b2c;
        }
LAB_00119b1c:
        free((void *)*puVar12);
      }
      free(puVar12);
    }
  }
LAB_00119b2c:
  pcVar4 = fgets(acStack_271 + 1,0x200,__stream);
  if (pcVar4 == (char *)0x0) goto LAB_00119d54;
  goto LAB_00119b40;
}


// ==== FUN_00119e58 @ 00119e58

undefined8 FUN_00119e58(undefined8 param_1,undefined8 param_2)

{
  int iVar1;
  undefined8 uVar2;
  
  if (DAT_00142de0 == 0) {
    uVar2 = FUN_0011a318(param_1);
    return uVar2;
  }
  DAT_00142f08 = 1;
  iVar1 = sigsetjmp(&DAT_00142fc0);
  if (iVar1 == 0) {
    uVar2 = FUN_0011a318(param_1);
  }
  else {
    if (DAT_00142e08 < 6) {
      __android_log_print(5,"xhook","catch SIGSEGV when check_elfheader: %s",param_2);
    }
    uVar2 = 0x3f1;
  }
  DAT_00142f08 = 0;
  return uVar2;
}


// ==== FUN_00119efc @ 00119efc

undefined8 * FUN_00119efc(long *param_1,undefined8 *param_2)

{
  int iVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  long lVar4;
  undefined8 *puVar5;
  long *plVar6;
  long lVar7;
  undefined8 *puVar8;
  char *__s1;
  
  if ((undefined8 *)*param_1 == (undefined8 *)0x0) {
    param_2[0x18] = 0;
    param_2[0x19] = 0;
    param_2[0x1a] = 0;
    *param_1 = (long)param_2;
    *(undefined4 *)(param_2 + 0x1b) = 1;
  }
  else {
    __s1 = (char *)*param_2;
    puVar2 = (undefined8 *)*param_1;
    do {
      while( true ) {
        puVar8 = puVar2;
        iVar1 = strcmp(__s1,(char *)*puVar8);
        if (iVar1 < 0) break;
        if (iVar1 == 0) {
          return puVar8;
        }
        puVar2 = (undefined8 *)puVar8[0x19];
        if ((undefined8 *)puVar8[0x19] == (undefined8 *)0x0) goto LAB_00119f54;
      }
      puVar2 = (undefined8 *)puVar8[0x18];
    } while ((undefined8 *)puVar8[0x18] != (undefined8 *)0x0);
LAB_00119f54:
    lVar4 = 0xc0;
    if (-1 < iVar1) {
      lVar4 = 200;
    }
    param_2[0x19] = 0;
    param_2[0x1a] = puVar8;
    param_2[0x18] = 0;
    *(undefined4 *)(param_2 + 0x1b) = 1;
    *(undefined8 **)((long)puVar8 + lVar4) = param_2;
    do {
      if (*(int *)(puVar8 + 0x1b) != 1) break;
      puVar2 = (undefined8 *)puVar8[0x1a];
      puVar3 = (undefined8 *)puVar2[0x18];
      if (puVar8 == puVar3) {
        puVar3 = (undefined8 *)puVar2[0x19];
        if ((puVar3 != (undefined8 *)0x0) && (*(int *)(puVar3 + 0x1b) == 1)) goto LAB_00119f7c;
        puVar3 = (undefined8 *)puVar8[0x19];
        if (puVar3 == param_2) {
          lVar4 = param_2[0x18];
          puVar8[0x19] = lVar4;
          if (lVar4 == 0) {
            param_2[0x1a] = puVar2;
LAB_0011a134:
            plVar6 = (long *)(puVar8[0x1a] + 0xc0);
            if (puVar8 != (undefined8 *)*plVar6) {
              plVar6 = (long *)(puVar8[0x1a] + 200);
            }
          }
          else {
            *(undefined8 **)(lVar4 + 0xd0) = puVar8;
            lVar4 = puVar8[0x1a];
            param_2[0x1a] = lVar4;
            if (lVar4 != 0) goto LAB_0011a134;
            plVar6 = param_1;
          }
          *plVar6 = (long)param_2;
          param_2[0x18] = puVar8;
          puVar5 = (undefined8 *)puVar2[0x18];
          puVar8[0x1a] = param_2;
          puVar3 = (undefined8 *)puVar5[0x19];
          *(undefined4 *)(param_2 + 0x1b) = 0;
          *(undefined4 *)(puVar2 + 0x1b) = 1;
          puVar2[0x18] = puVar3;
          param_2 = puVar8;
        }
        else {
          *(undefined4 *)(puVar8 + 0x1b) = 0;
          *(undefined4 *)(puVar2 + 0x1b) = 1;
          puVar2[0x18] = puVar3;
          puVar5 = puVar8;
        }
        if (puVar3 != (undefined8 *)0x0) {
          puVar3[0x1a] = puVar2;
        }
        lVar4 = puVar2[0x1a];
        puVar5[0x1a] = lVar4;
        if (lVar4 == 0) {
          plVar6 = param_1;
        }
        else {
          plVar6 = (long *)(puVar2[0x1a] + 0xc0);
          if (puVar2 != (undefined8 *)*plVar6) {
            plVar6 = (long *)(puVar2[0x1a] + 200);
          }
        }
        *plVar6 = (long)puVar5;
        puVar5[0x19] = puVar2;
        puVar2[0x1a] = puVar5;
      }
      else if ((puVar3 == (undefined8 *)0x0) || (*(int *)(puVar3 + 0x1b) != 1)) {
        if ((undefined8 *)puVar8[0x18] == param_2) {
          lVar4 = param_2[0x19];
          puVar8[0x18] = lVar4;
          if (lVar4 == 0) {
            param_2[0x1a] = puVar2;
LAB_0011a0f0:
            plVar6 = (long *)(puVar8[0x1a] + 0xc0);
            if (puVar8 != (undefined8 *)*plVar6) {
              plVar6 = (long *)(puVar8[0x1a] + 200);
            }
          }
          else {
            *(undefined8 **)(lVar4 + 0xd0) = puVar8;
            lVar4 = puVar8[0x1a];
            param_2[0x1a] = lVar4;
            if (lVar4 != 0) goto LAB_0011a0f0;
            plVar6 = param_1;
          }
          *plVar6 = (long)param_2;
          param_2[0x19] = puVar8;
          puVar8[0x1a] = param_2;
          lVar4 = puVar2[0x19];
          *(undefined4 *)(param_2 + 0x1b) = 0;
          *(undefined4 *)(puVar2 + 0x1b) = 1;
          lVar7 = *(long *)(lVar4 + 0xc0);
          puVar2[0x19] = lVar7;
          param_2 = puVar8;
        }
        else {
          lVar4 = puVar2[0x19];
          *(undefined4 *)(puVar8 + 0x1b) = 0;
          *(undefined4 *)(puVar2 + 0x1b) = 1;
          lVar7 = *(long *)(lVar4 + 0xc0);
          puVar2[0x19] = lVar7;
        }
        if (lVar7 != 0) {
          *(undefined8 **)(lVar7 + 0xd0) = puVar2;
        }
        lVar7 = puVar2[0x1a];
        *(long *)(lVar4 + 0xd0) = lVar7;
        if (lVar7 == 0) {
          plVar6 = param_1;
        }
        else {
          plVar6 = (long *)(puVar2[0x1a] + 0xc0);
          if (puVar2 != (undefined8 *)*plVar6) {
            plVar6 = (long *)(puVar2[0x1a] + 200);
          }
        }
        *plVar6 = lVar4;
        *(undefined8 **)(lVar4 + 0xc0) = puVar2;
        puVar2[0x1a] = lVar4;
      }
      else {
LAB_00119f7c:
        *(undefined4 *)(puVar3 + 0x1b) = 0;
        *(undefined4 *)(puVar8 + 0x1b) = 0;
        *(undefined4 *)(puVar2 + 0x1b) = 1;
        param_2 = puVar2;
      }
      puVar8 = (undefined8 *)param_2[0x1a];
    } while (puVar8 != (undefined8 *)0x0);
    param_2 = (undefined8 *)*param_1;
  }
  *(undefined4 *)(param_2 + 0x1b) = 0;
  return (undefined8 *)0x0;
}


// ==== FUN_0011a1ac @ 0011a1ac

void FUN_0011a1ac(undefined8 *param_1)

{
  int iVar1;
  
  if (DAT_00142de0 == 0) {
    FUN_0011a248(param_1);
    return;
  }
  DAT_00142f08 = 1;
  iVar1 = sigsetjmp(&DAT_00142fc0);
  if (iVar1 == 0) {
    FUN_0011a248(param_1);
  }
  else if (DAT_00142e08 < 6) {
    __android_log_print(5,"xhook","catch SIGSEGV when init or hook: %s",*param_1);
  }
  DAT_00142f08 = 0;
  return;
}


// ==== FUN_0011a248 @ 0011a248

void FUN_0011a248(undefined8 *param_1)

{
  regex_t *__preg;
  regex_t *__preg_00;
  int iVar1;
  
  iVar1 = FUN_0011a38c(param_1 + 2,param_1[1],*param_1);
  __preg = DAT_00142de8;
  if (iVar1 == 0) {
    for (; __preg != (regex_t *)0x0; __preg = *(regex_t **)&__preg->field_0x38) {
      iVar1 = regexec(__preg,(char *)*param_1,0,(regmatch_t *)0x0,0);
      __preg_00 = DAT_00142df8;
      if (iVar1 == 0) {
        for (; __preg_00 != (regex_t *)0x0; __preg_00 = (regex_t *)__preg_00->translate) {
          iVar1 = regexec(__preg_00,(char *)*param_1,0,(regmatch_t *)0x0,0);
          if (iVar1 == 0) {
            if (__preg_00->fastmap == (char *)0x0) {
              return;
            }
            iVar1 = strcmp(__preg_00->fastmap,__preg->fastmap);
            if (iVar1 == 0) goto LAB_0011a298;
          }
        }
        FUN_0011a910(param_1 + 2,__preg->fastmap,__preg->translate,__preg->re_nsub);
      }
LAB_0011a298:
    }
  }
  return;
}


// ==== FUN_0011a318 @ 0011a318

undefined4 FUN_0011a318(int *param_1)

{
  undefined4 uVar1;
  
  if ((((*param_1 != 0x464c457f) || ((char)param_1[1] != '\x02')) ||
      (*(char *)((long)param_1 + 5) != '\x01')) ||
     ((*(char *)((long)param_1 + 6) != '\x01' || ((*(ushort *)(param_1 + 4) & 0xfffe) != 2)))) {
    return 0x3ef;
  }
  uVar1 = 0x3ef;
  if ((*(short *)((long)param_1 + 0x12) == 0xb7) && (uVar1 = 0, param_1[5] != 1)) {
    uVar1 = 0x3ef;
  }
  return uVar1;
}


// ==== FUN_0011a38c @ 0011a38c

undefined8 FUN_0011a38c(long *param_1,uint *param_2,long param_3)

{
  uint *puVar1;
  int *piVar2;
  long *plVar3;
  uint *puVar4;
  undefined *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  char *pcVar9;
  long lVar10;
  int *piVar11;
  long *plVar12;
  ulong uVar13;
  long lVar14;
  
  if ((param_2 == (uint *)0x0) || (param_3 == 0)) {
    return 0x3ea;
  }
  param_1[1] = 0;
  *param_1 = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[0x13] = 0;
  param_1[0x12] = 0;
  param_1[0x15] = 0;
  param_1[0x14] = 0;
  param_1[0xf] = 0;
  param_1[0xe] = 0;
  param_1[0x11] = 0;
  param_1[0x10] = 0;
  param_1[0xb] = 0;
  param_1[10] = 0;
  param_1[0xd] = 0;
  param_1[0xc] = 0;
  param_1[7] = 0;
  param_1[6] = 0;
  param_1[9] = 0;
  param_1[8] = 0;
  param_1[5] = 0;
  param_1[4] = 0;
  lVar10 = *(long *)(param_2 + 8);
  *param_1 = param_3;
  param_1[1] = (long)param_2;
  uVar8 = param_2[0xe];
  piVar2 = (int *)(lVar10 + (long)param_2);
  param_1[3] = (long)param_2;
  param_1[4] = (long)piVar2;
  if ((ulong)(ushort)uVar8 != 0) {
    piVar11 = piVar2;
    do {
      if ((*piVar11 == 1) && (*(long *)(piVar11 + 2) == 0)) {
        if (param_2 < *(uint **)(piVar11 + 4)) {
          return 0x3ef;
        }
        lVar10 = (long)param_2 - (long)*(uint **)(piVar11 + 4);
        param_1[2] = lVar10;
        piVar11 = piVar2;
        goto LAB_0011a488;
      }
      piVar11 = piVar11 + 0xe;
    } while (piVar11 < piVar2 + (ulong)(ushort)uVar8 * 0xe);
  }
  if (6 < DAT_00142e08) {
    return 0x3ef;
  }
  pcVar9 = "Can NOT found the first load segment. %s";
  goto LAB_0011a458;
  while (piVar11 = piVar11 + 0xe, piVar11 < piVar2 + (ulong)(ushort)uVar8 * 0xe) {
LAB_0011a488:
    if (*piVar11 == 2) {
      plVar12 = (long *)(*(long *)(piVar11 + 4) + lVar10);
      uVar13 = *(ulong *)(piVar11 + 10) >> 4 & 0xfffffff;
      *(int *)(param_1 + 6) = (int)*(ulong *)(piVar11 + 10);
      param_1[5] = (long)plVar12;
      if (uVar13 == 0) goto LAB_0011a6a0;
      plVar3 = plVar12 + uVar13 * 2;
      goto LAB_0011a524;
    }
  }
  if (6 < DAT_00142e08) {
    return 0x3ef;
  }
  pcVar9 = "Can NOT found dynamic segment. %s";
  goto LAB_0011a458;
LAB_0011a524:
  do {
    lVar14 = *plVar12;
    switch(lVar14) {
    case 0:
      plVar12 = plVar3;
      break;
    case 1:
    case 3:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x10:
    case 0x13:
    case 0x15:
    case 0x16:
      break;
    case 2:
      *(int *)(param_1 + 10) = (int)plVar12[1];
      break;
    case 4:
      if (*(int *)((long)param_1 + 0xac) != 1) {
        puVar4 = (uint *)(plVar12[1] + lVar10);
        if (puVar4 < param_2) {
          return 0x3ef;
        }
        uVar8 = *puVar4;
        *(uint *)(param_1 + 0x10) = uVar8;
        uVar6 = puVar4[1];
        param_1[0xf] = (long)(puVar4 + 2);
        param_1[0x11] = (long)(puVar4 + 2 + uVar8);
        *(uint *)(param_1 + 0x12) = uVar6;
      }
      break;
    case 5:
      puVar4 = (uint *)(plVar12[1] + lVar10);
      param_1[7] = (long)puVar4;
      goto joined_r0x0011a584;
    case 6:
      puVar4 = (uint *)(plVar12[1] + lVar10);
      param_1[8] = (long)puVar4;
      goto joined_r0x0011a584;
    case 7:
    case 0x11:
      puVar4 = (uint *)(plVar12[1] + lVar10);
      param_1[0xb] = (long)puVar4;
      goto joined_r0x0011a584;
    case 8:
    case 0x12:
      *(int *)(param_1 + 0xc) = (int)plVar12[1];
      break;
    case 0x14:
      *(uint *)(param_1 + 0x15) = (uint)(plVar12[1] == 7);
      break;
    case 0x17:
      puVar4 = (uint *)(plVar12[1] + lVar10);
      param_1[9] = (long)puVar4;
joined_r0x0011a584:
      if (puVar4 < param_2) {
        return 0x3ef;
      }
      break;
    default:
      switch(lVar14) {
      case 0x6000000f:
      case 0x60000011:
        puVar4 = (uint *)(plVar12[1] + lVar10);
        param_1[0xd] = (long)puVar4;
        goto joined_r0x0011a584;
      case 0x60000010:
      case 0x60000012:
        *(int *)(param_1 + 0xe) = (int)plVar12[1];
        break;
      default:
        if (lVar14 == 0x6ffffef5) {
          puVar4 = (uint *)(plVar12[1] + lVar10);
          if (puVar4 < param_2) {
            return 0x3ef;
          }
          uVar8 = *puVar4;
          puVar1 = puVar4 + 4;
          *(uint *)(param_1 + 0x10) = uVar8;
          uVar6 = puVar4[1];
          param_1[0x13] = (long)puVar1;
          *(uint *)((long)param_1 + 0x94) = uVar6;
          uVar6 = puVar4[2];
          *(uint *)(param_1 + 0x14) = uVar6;
          uVar7 = puVar4[3];
          *(undefined4 *)((long)param_1 + 0xac) = 1;
          param_1[0xf] = (long)(puVar1 + (ulong)uVar6 * 2);
          *(uint *)((long)param_1 + 0xa4) = uVar7;
          param_1[0x11] = (long)(puVar1 + (ulong)uVar6 * 2 + uVar8);
        }
      }
    }
    plVar12 = plVar12 + 2;
  } while (plVar12 < plVar3);
LAB_0011a6a0:
  pcVar9 = (char *)param_1[0xd];
  if (pcVar9 != (char *)0x0) {
    if ((((*(uint *)(param_1 + 0xe) < 4) || (*pcVar9 != 'A')) || (pcVar9[1] != 'P')) ||
       ((pcVar9[2] != 'S' || (pcVar9[3] != '2')))) {
      if (DAT_00142e08 < 7) {
        __android_log_print(6,"xhook","android rel/rela format error\n");
        return 0x3ef;
      }
      return 0x3ef;
    }
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) - 4;
    param_1[0xd] = (long)(pcVar9 + 4);
  }
  if (lVar10 == 0) {
    if (6 < DAT_00142e08) {
      return 0x3ef;
    }
    pcVar9 = "bias_addr == 0\n";
  }
  else if (piVar2 == (int *)0x0) {
    if (6 < DAT_00142e08) {
      return 0x3ef;
    }
    pcVar9 = "phdr == NULL\n";
  }
  else if (param_1[7] == 0) {
    if (6 < DAT_00142e08) {
      return 0x3ef;
    }
    pcVar9 = "strtab == NULL\n";
  }
  else if (param_1[8] == 0) {
    if (6 < DAT_00142e08) {
      return 0x3ef;
    }
    pcVar9 = "symtab == NULL\n";
  }
  else if (param_1[0xf] == 0) {
    if (6 < DAT_00142e08) {
      return 0x3ef;
    }
    pcVar9 = "bucket == NULL\n";
  }
  else if (param_1[0x11] == 0) {
    if (6 < DAT_00142e08) {
      return 0x3ef;
    }
    pcVar9 = "chain == NULL\n";
  }
  else {
    if ((*(int *)((long)param_1 + 0xac) != 1) || (param_1[0x13] != 0)) {
      if (DAT_00142e08 < 5) {
        puVar5 = &DAT_0010a51a;
        if ((int)param_1[0x15] != 0) {
          puVar5 = &DAT_0010a607;
        }
        pcVar9 = "ELF_HASH";
        if (*(int *)((long)param_1 + 0xac) != 0) {
          pcVar9 = "GNU_HASH";
        }
        __android_log_print(4,"xhook","init OK: %s (%s %s PLT:%u DYN:%u ANDROID:%u)\n",param_3,
                            puVar5,pcVar9,(int)param_1[10],(int)param_1[0xc],(int)param_1[0xe]);
      }
      return 0;
    }
    if (6 < DAT_00142e08) {
      return 0x3ef;
    }
    pcVar9 = "bloom == NULL\n";
  }
  __android_log_print(6,"xhook",pcVar9);
  if (6 < DAT_00142e08) {
    return 0x3ef;
  }
  pcVar9 = "elf init check failed. %s";
LAB_0011a458:
  __android_log_print(6,"xhook",pcVar9,param_3);
  return 0x3ef;
}


// ==== FUN_0011a910 @ 0011a910

void FUN_0011a910(long *param_1,byte *param_2,long param_3,undefined8 param_4)

{
  byte *pbVar1;
  long lVar2;
  byte bVar3;
  ulong uVar4;
  uint uVar5;
  long lVar6;
  int iVar7;
  undefined8 uVar8;
  char *pcVar9;
  ulong *puVar10;
  uint uVar11;
  ulong uVar12;
  byte *pbVar13;
  ulong uVar14;
  byte *pbVar15;
  ulong uVar16;
  ulong uVar17;
  ulong uVar18;
  uint uVar19;
  ulong uVar20;
  uint *puVar21;
  ulong uVar22;
  ulong uVar23;
  uint uVar24;
  long lVar25;
  ulong uVar26;
  ulong uVar27;
  ulong uStack_128;
  long lStack_118;
  int local_fc;
  byte *local_f8;
  byte *pbStack_f0;
  ulong local_e8;
  ulong uStack_e0;
  ulong local_d8;
  ulong uStack_d0;
  ulong local_c8;
  ulong uStack_c0;
  ulong local_b8;
  ulong uStack_b0;
  long local_a8;
  ulong uStack_a0;
  ulong local_98;
  ulong uStack_90;
  ulong local_88;
  long lStack_80;
  ulong local_78;
  long local_70;
  
  lVar6 = tpidr_el0;
  local_70 = *(long *)(lVar6 + 0x28);
  if (*param_1 == 0) {
    if (DAT_00142e08 < 7) {
      __android_log_print(6,"xhook","not inited\n");
    }
    uVar8 = 0x3f0;
    goto LAB_0011abb0;
  }
  uVar8 = 0x3ea;
  if ((param_2 == (byte *)0x0) || (param_3 == 0)) goto LAB_0011abb0;
  if (DAT_00142e08 < 5) {
    __android_log_print(4,"xhook","hooking %s in %s\n",param_2);
  }
  uVar11 = (uint)*param_2;
  if (*(int *)((long)param_1 + 0xac) == 0) {
    uVar24 = 0;
    if (uVar11 != 0) {
      pbVar15 = param_2;
      do {
        pbVar15 = pbVar15 + 1;
        uVar24 = uVar11 + uVar24 * 0x10;
        uVar11 = (uint)*pbVar15;
        uVar24 = uVar24 >> 0x18 & 0xf0 ^ uVar24 & 0xfffffff;
      } while (uVar11 != 0);
    }
    uVar11 = *(uint *)(param_1 + 0x10);
    uVar5 = 0;
    if (uVar11 != 0) {
      uVar5 = uVar24 / uVar11;
    }
    uVar11 = *(uint *)(param_1[0xf] + (ulong)(uVar24 - uVar5 * uVar11) * 4);
    if (uVar11 != 0) {
      lVar25 = param_1[7];
      lVar2 = param_1[8];
      do {
        uVar20 = (ulong)uVar11;
        iVar7 = strcmp((char *)param_2,(char *)(lVar25 + (ulong)*(uint *)(lVar2 + uVar20 * 0x18)));
        if (iVar7 == 0) {
          if (4 < DAT_00142e08) goto LAB_0011ac0c;
          pcVar9 = "found %s at symidx: %u (ELF_HASH)\n";
          goto LAB_0011abfc;
        }
        uVar11 = *(uint *)(param_1[0x11] + uVar20 * 4);
      } while (uVar11 != 0);
    }
  }
  else {
    if (uVar11 == 0) {
      uVar20 = 0x1505;
    }
    else {
      uVar20 = 0x1505;
      pbVar15 = param_2;
      do {
        pbVar15 = pbVar15 + 1;
        uVar20 = (ulong)((int)uVar20 * 0x21 + uVar11);
        uVar11 = (uint)*pbVar15;
      } while (uVar11 != 0);
    }
    uVar11 = *(uint *)(param_1 + 0x14);
    uVar5 = (uint)(uVar20 >> 6);
    uVar24 = 0;
    if (uVar11 != 0) {
      uVar24 = uVar5 / uVar11;
    }
    if (((1L << (uVar20 >> ((ulong)*(uint *)((long)param_1 + 0xa4) & 0x3f) & 0x3f) |
         1L << (uVar20 & 0x3f)) &
        (*(ulong *)(param_1[0x13] + (ulong)(uVar5 - uVar24 * uVar11) * 8) ^ 0xffffffffffffffff)) ==
        0) {
      uVar24 = *(uint *)(param_1 + 0x10);
      uVar11 = *(uint *)((long)param_1 + 0x94);
      uVar5 = 0;
      uVar19 = (uint)uVar20;
      if (uVar24 != 0) {
        uVar5 = uVar19 / uVar24;
      }
      uVar24 = *(uint *)(param_1[0xf] + (ulong)(uVar19 - uVar5 * uVar24) * 4);
      if (uVar11 <= uVar24) {
        lVar25 = param_1[0x11];
        do {
          uVar20 = (ulong)uVar24;
          uVar5 = *(uint *)(lVar25 + (ulong)(uVar24 - uVar11) * 4);
          if (((uVar5 ^ uVar19) < 2) &&
             (iVar7 = strcmp((char *)param_2,
                             (char *)(param_1[7] + (ulong)*(uint *)(param_1[8] + uVar20 * 0x18))),
             iVar7 == 0)) {
            if (4 < DAT_00142e08) goto LAB_0011ac0c;
            pcVar9 = "found %s at symidx: %u (GNU_HASH DEF)\n";
            goto LAB_0011abfc;
          }
          uVar24 = uVar24 + 1;
        } while ((uVar5 & 1) == 0);
        goto joined_r0x0011ab40;
      }
    }
    else {
      uVar11 = *(uint *)((long)param_1 + 0x94);
joined_r0x0011ab40:
      if (uVar11 == 0) goto LAB_0011abac;
    }
    lVar25 = param_1[7];
    puVar21 = (uint *)param_1[8];
    uVar20 = 0;
LAB_0011ab84:
    iVar7 = strcmp((char *)(lVar25 + (ulong)*puVar21),(char *)param_2);
    if (iVar7 != 0) goto code_r0x0011ab98;
    if (DAT_00142e08 < 5) {
      pcVar9 = "found %s at symidx: %u (GNU_HASH UNDEF)\n";
LAB_0011abfc:
      __android_log_print(4,"xhook",pcVar9,param_2,uVar20 & 0xffffffff);
    }
LAB_0011ac0c:
    uVar22 = param_1[9];
    if (uVar22 != 0) {
      uVar17 = uVar22 + *(uint *)(param_1 + 10);
      lVar25 = 0x10;
      if ((int)param_1[0x15] != 0) {
        lVar25 = 0x18;
      }
      do {
        if (uVar17 <= uVar22) break;
        pcVar9 = ".rel.plt";
        if ((int)param_1[0x15] != 0) {
          pcVar9 = ".rela.plt";
        }
        uVar8 = FUN_0011b260(param_1,pcVar9,1,param_2,param_3,param_4,uVar20 & 0xffffffff,uVar22,
                             &local_fc);
        if ((int)uVar8 != 0) goto LAB_0011abb0;
        uVar22 = uVar22 + lVar25;
      } while (local_fc == 0);
    }
    uVar22 = param_1[0xb];
    if (uVar22 != 0) {
      uVar17 = uVar22 + *(uint *)(param_1 + 0xc);
      lVar25 = 0x10;
      if ((int)param_1[0x15] != 0) {
        lVar25 = 0x18;
      }
      while (uVar22 < uVar17) {
        pcVar9 = ".rel.dyn";
        if ((int)param_1[0x15] != 0) {
          pcVar9 = ".rela.dyn";
        }
        uVar8 = FUN_0011b260(param_1,pcVar9,0,param_2,param_3,param_4,uVar20 & 0xffffffff,uVar22,0);
        uVar22 = uVar22 + lVar25;
        if ((int)uVar8 != 0) goto LAB_0011abb0;
      }
    }
    pbVar15 = (byte *)param_1[0xd];
    if (pbVar15 != (byte *)0x0) {
      uVar11 = *(uint *)(param_1 + 0x15);
      local_78 = (ulong)uVar11;
      uStack_e0 = 0;
      local_e8 = 0;
      pbVar1 = pbVar15 + *(uint *)(param_1 + 0xe);
      uStack_d0 = 0;
      local_d8 = 0;
      uStack_c0 = 0;
      local_c8 = 0;
      uStack_b0 = 0;
      local_b8 = 0;
      uStack_a0 = 0;
      local_a8 = 0;
      uStack_90 = 0;
      local_98 = 0;
      lStack_80 = 0;
      local_88 = 0;
      if (*(uint *)(param_1 + 0xe) == 0) {
LAB_0011ad80:
        local_f8 = pbVar15;
      }
      else {
        uVar22 = 0;
        uVar17 = 0;
        pbVar13 = pbVar15;
        while( true ) {
          pbVar15 = pbVar13 + 1;
          bVar3 = *pbVar13;
          uVar17 = ((ulong)bVar3 & 0x7f) << (uVar22 & 0x3f) | uVar17;
          if (-1 < (char)bVar3) break;
          uVar22 = uVar22 + 7;
          pbVar13 = pbVar15;
          if (pbVar1 <= pbVar15) goto LAB_0011ad80;
        }
        uVar18 = 0;
        uVar16 = 0;
        local_e8 = 0;
        if ((bVar3 & 0x40) != 0 && uVar22 + 7 < 0x40) {
          local_e8 = -1L << (uVar22 + 7 & 0x3f);
        }
        local_e8 = uVar17 | local_e8;
        local_f8 = pbVar13 + 1;
        do {
          if (pbVar1 <= local_f8) goto LAB_0011ad8c;
          pbVar15 = local_f8 + 1;
          bVar3 = *local_f8;
          uVar22 = uVar16 & 0x3f;
          uVar16 = uVar16 + 7;
          uVar18 = ((ulong)bVar3 & 0x7f) << uVar22 | uVar18;
          local_f8 = pbVar15;
        } while ((char)bVar3 < '\0');
        uStack_90 = 0;
        if ((bVar3 & 0x40) != 0 && uVar16 < 0x40) {
          uStack_90 = -1L << (uVar16 & 0x3f);
        }
        uStack_90 = uVar18 | uStack_90;
      }
LAB_0011ad8c:
      uVar16 = local_e8;
      uVar27 = 0;
      lStack_118 = 0;
      uVar18 = 0;
      uVar26 = 0;
      uVar23 = 0;
      uVar22 = 0;
      uStack_128 = 0;
      uVar17 = uStack_90;
      pbVar15 = local_f8;
      pbStack_f0 = pbVar1;
      while( true ) {
        if (uVar16 <= uStack_128) break;
        if (uVar22 == uVar23) {
          uVar23 = 0;
          uVar22 = 0;
          do {
            if (pbVar1 <= pbVar15) goto LAB_0011abac;
            local_f8 = pbVar15 + 1;
            bVar3 = *pbVar15;
            uVar26 = uVar22 & 0x3f;
            uVar22 = uVar22 + 7;
            uVar23 = ((ulong)bVar3 & 0x7f) << uVar26 | uVar23;
            pbVar15 = local_f8;
          } while ((char)bVar3 < '\0');
          uVar26 = 0;
          uVar12 = 0;
          if ((bVar3 & 0x40) != 0 && uVar22 < 0x40) {
            uVar12 = -1L << (uVar22 & 0x3f);
          }
          uVar23 = uVar23 | uVar12;
          uVar22 = 0;
          do {
            uStack_e0 = uVar23;
            if (pbVar1 <= local_f8) goto LAB_0011abac;
            pbVar15 = local_f8 + 1;
            bVar3 = *local_f8;
            uVar12 = uVar22 & 0x3f;
            uVar22 = uVar22 + 7;
            uVar26 = ((ulong)bVar3 & 0x7f) << uVar12 | uVar26;
            local_f8 = pbVar15;
          } while ((char)bVar3 < '\0');
          uVar12 = 0;
          if ((bVar3 & 0x40) != 0 && uVar22 < 0x40) {
            uVar12 = -1L << (uVar22 & 0x3f);
          }
          uVar26 = uVar26 | uVar12;
          uVar24 = (uint)uVar26;
          local_d8 = uVar26;
          if ((uVar24 >> 1 & 1) == 0) {
          }
          else {
            uVar18 = 0;
            uVar22 = 0;
            do {
              if (pbVar1 <= local_f8) goto LAB_0011abac;
              pbVar15 = local_f8 + 1;
              bVar3 = *local_f8;
              uVar12 = uVar22 & 0x3f;
              uVar22 = uVar22 + 7;
              uVar18 = ((ulong)bVar3 & 0x7f) << uVar12 | uVar18;
              local_f8 = pbVar15;
            } while ((char)bVar3 < '\0');
            uVar12 = 0;
            if ((bVar3 & 0x40) != 0 && uVar22 < 0x40) {
              uVar12 = -1L << (uVar22 & 0x3f);
            }
            uVar18 = uVar18 | uVar12;
            uStack_d0 = uVar18;
          }
          if ((uVar26 & 1) == 0) {
          }
          else {
            uVar27 = 0;
            uVar22 = 0;
            do {
              if (pbVar1 <= local_f8) goto LAB_0011abac;
              pbVar15 = local_f8 + 1;
              bVar3 = *local_f8;
              uVar12 = uVar22 & 0x3f;
              uVar22 = uVar22 + 7;
              uVar27 = ((ulong)bVar3 & 0x7f) << uVar12 | uVar27;
              local_f8 = pbVar15;
            } while ((char)bVar3 < '\0');
            uVar12 = 0;
            if ((bVar3 & 0x40) != 0 && uVar22 < 0x40) {
              uVar12 = -1L << (uVar22 & 0x3f);
            }
            uVar27 = uVar27 | uVar12;
            local_88 = uVar27;
          }
          if ((~uVar24 & 0xc) == 0) {
            if (uVar11 == 0) {
              if (DAT_00142e08 < 7) {
                __android_log_print(6,"xhook","unexpected r_addend in android.rel section");
              }
              break;
            }
            uVar12 = 0;
            uVar22 = 0;
            do {
              if (pbVar1 <= local_f8) goto LAB_0011abac;
              pbVar15 = local_f8 + 1;
              bVar3 = *local_f8;
              uVar14 = uVar22 & 0x3f;
              uVar22 = uVar22 + 7;
              uVar12 = ((ulong)bVar3 & 0x7f) << uVar14 | uVar12;
              local_f8 = pbVar15;
            } while ((char)bVar3 < '\0');
            uVar14 = 0;
            if ((bVar3 & 0x40) != 0 && uVar22 < 0x40) {
              uVar14 = -1L << (uVar22 & 0x3f);
            }
            lStack_118 = lStack_118 + (uVar12 | uVar14);
LAB_0011afe4:
            lStack_80 = lStack_118;
          }
          else if ((uVar24 >> 3 & 1) == 0) {
            lStack_118 = 0;
            goto LAB_0011afe4;
          }
          uVar22 = 1;
          uStack_c0 = 0;
          uVar12 = uVar18;
          pbVar15 = local_f8;
          if ((uVar24 >> 1 & 1) != 0) goto LAB_0011aff4;
LAB_0011ae88:
          uVar12 = 0;
          uVar14 = 0;
          pbVar13 = pbVar15;
          do {
            if (pbVar1 <= pbVar13) goto LAB_0011abac;
            pbVar15 = pbVar13 + 1;
            bVar3 = *pbVar13;
            uVar4 = uVar14 & 0x3f;
            uVar14 = uVar14 + 7;
            uVar12 = ((ulong)bVar3 & 0x7f) << uVar4 | uVar12;
            pbVar13 = pbVar15;
            local_f8 = pbVar15;
          } while ((char)bVar3 < '\0');
          uVar4 = 0;
          if ((bVar3 & 0x40) != 0 && uVar14 < 0x40) {
            uVar4 = -1L << (uVar14 & 0x3f);
          }
          uVar12 = uVar12 | uVar4;
        }
        else {
          uVar22 = uVar22 + 1;
          uVar12 = uVar18;
          if (((uint)uVar26 >> 1 & 1) == 0) goto LAB_0011ae88;
LAB_0011aff4:
          uVar18 = uVar12;
        }
        uVar17 = uVar17 + uVar12;
        uStack_90 = uVar17;
        if ((uVar26 & 1) == 0) {
          uVar27 = 0;
          uVar12 = 0;
          pbVar13 = pbVar15;
          do {
            if (pbVar1 <= pbVar13) goto LAB_0011abac;
            pbVar15 = pbVar13 + 1;
            bVar3 = *pbVar13;
            uVar14 = uVar12 & 0x3f;
            uVar12 = uVar12 + 7;
            uVar27 = ((ulong)bVar3 & 0x7f) << uVar14 | uVar27;
            pbVar13 = pbVar15;
            local_f8 = pbVar15;
          } while ((char)bVar3 < '\0');
          uVar14 = 0;
          if ((bVar3 & 0x40) != 0 && uVar12 < 0x40) {
            uVar14 = -1L << (uVar12 & 0x3f);
          }
          uVar27 = uVar27 | uVar14;
          local_88 = uVar27;
        }
        if (uVar11 == 0) {
          puVar10 = &uStack_a0;
          uStack_a0 = uVar17;
          local_98 = uVar27;
        }
        else {
          if ((uVar26 & 0xc) == 8) {
            uVar14 = 0;
            uVar12 = 0;
            pbVar13 = pbVar15;
            do {
              if (pbVar1 <= pbVar13) goto LAB_0011abac;
              pbVar15 = pbVar13 + 1;
              bVar3 = *pbVar13;
              uVar4 = uVar12 & 0x3f;
              uVar12 = uVar12 + 7;
              uVar14 = ((ulong)bVar3 & 0x7f) << uVar4 | uVar14;
              pbVar13 = pbVar15;
              local_f8 = pbVar15;
            } while ((char)bVar3 < '\0');
            uVar4 = 0;
            if ((bVar3 & 0x40) != 0 && uVar12 < 0x40) {
              uVar4 = -1L << (uVar12 & 0x3f);
            }
            lStack_118 = lStack_118 + (uVar14 | uVar4);
            lStack_80 = lStack_118;
          }
          puVar10 = &local_b8;
          local_b8 = uVar17;
          uStack_b0 = uVar27;
          local_a8 = lStack_118;
        }
        uStack_128 = uStack_128 + 1;
        pcVar9 = ".rel.android";
        if ((int)param_1[0x15] != 0) {
          pcVar9 = ".rela.android";
        }
        local_c8 = uStack_128;
        uStack_c0 = uVar22;
        uVar8 = FUN_0011b260(param_1,pcVar9,0,param_2,param_3,param_4,uVar20 & 0xffffffff,puVar10,0)
        ;
        if ((int)uVar8 != 0) goto LAB_0011abb0;
      }
    }
  }
LAB_0011abac:
  uVar8 = 0;
LAB_0011abb0:
  if (*(long *)(lVar6 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar8);
  }
  return;
code_r0x0011ab98:
  uVar20 = uVar20 + 1;
  puVar21 = puVar21 + 6;
  if (uVar11 == uVar20) goto LAB_0011abac;
  goto LAB_0011ab84;
}


// ==== FUN_0011b260 @ 0011b260

int FUN_0011b260(undefined8 *param_1,undefined8 param_2,int param_3,undefined8 param_4,long param_5,
                long *param_6,ulong param_7,long *param_8,undefined4 *param_9)

{
  long *plVar1;
  long lVar2;
  int iVar3;
  ulong uVar4;
  long lVar5;
  int local_6c;
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  if (param_9 != (undefined4 *)0x0) {
    *param_9 = 0;
  }
  uVar4 = param_8[1];
  if ((((param_7 & 0xffffffff) == uVar4 >> 0x20) &&
      ((lVar5 = *param_8, param_3 == 0 || ((uVar4 & 0xffffffff) == 0x402)))) &&
     ((param_3 != 0 || (((int)uVar4 == 0x401 || ((int)uVar4 == 0x101)))))) {
    if (DAT_00142e08 < 5) {
      __android_log_print(4,"xhook","found %s at %s offset: %p\n",param_4,param_2,lVar5);
    }
    if (param_9 != (undefined4 *)0x0) {
      *param_9 = 1;
    }
    plVar1 = (long *)(param_1[2] + lVar5);
    if (plVar1 < (long *)param_1[1]) {
      iVar3 = 0x3ef;
      goto LAB_0011b2d4;
    }
    local_6c = 0;
    if (*plVar1 != param_5) {
      iVar3 = FUN_0011b764(plVar1,*param_1,&local_6c);
      if (iVar3 == 0) {
        if ((local_6c == 3) || (iVar3 = FUN_0011b774(plVar1,3), iVar3 == 0)) {
          lVar5 = *plVar1;
          if (param_6 != (long *)0x0) {
            *param_6 = lVar5;
          }
          *plVar1 = param_5;
          if (((local_6c != 3) && (iVar3 = FUN_0011b774(plVar1), iVar3 != 0)) && (DAT_00142e08 < 6))
          {
            __android_log_print(5,"xhook","restore addr prot failed. ret: %d",iVar3);
          }
          FUN_0011b800(plVar1);
          if (DAT_00142e08 < 5) {
            __android_log_print(4,"xhook","XH_HK_OK %p: %p -> %p %s %s\n",plVar1,lVar5,param_5,
                                param_4,*param_1);
          }
          goto LAB_0011b2d0;
        }
        if (6 < DAT_00142e08) goto LAB_0011b2d4;
        __android_log_print(6,"xhook","set addr prot failed. ret: %d",iVar3);
      }
      else {
        if (6 < DAT_00142e08) goto LAB_0011b2d4;
        __android_log_print(6,"xhook","get addr prot failed. ret: %d",iVar3);
      }
      if (DAT_00142e08 < 7) {
        __android_log_print(6,"xhook","replace function failed: %s at %s\n",param_4,param_2);
      }
      goto LAB_0011b2d4;
    }
  }
LAB_0011b2d0:
  iVar3 = 0;
LAB_0011b2d4:
  if (*(long *)(lVar2 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar3;
}


// ==== FUN_0011b4ec @ 0011b4ec

undefined8 FUN_0011b4ec(ulong param_1,long param_2,char *param_3,uint *param_4)

{
  ulong uVar1;
  long lVar2;
  bool bVar3;
  int iVar4;
  FILE *__stream;
  char *pcVar5;
  uint uVar6;
  undefined8 uVar7;
  ulong local_280;
  ulong local_278;
  char local_270;
  char local_26f;
  char local_26e;
  char local_26d;
  char acStack_268 [512];
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  *param_4 = 0;
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    uVar7 = 0x3ee;
    iVar4 = 0;
    if (*(long *)(lVar2 + 0x28) != local_68) goto LAB_0011b760;
  }
  else {
    pcVar5 = fgets(acStack_268,0x200,__stream);
    if (pcVar5 != (char *)0x0) {
      uVar1 = param_2 + param_1;
      bVar3 = true;
      do {
        if (param_3 == (char *)0x0) {
          while ((iVar4 = sscanf(acStack_268,"%lx-%lx %4s ",&local_278,&local_280,&local_270),
                 iVar4 != 3 || (local_26d != 'p'))) {
            pcVar5 = fgets(acStack_268,0x200,__stream);
            if (pcVar5 == (char *)0x0) goto LAB_0011b70c;
          }
        }
        else {
          while (((pcVar5 = strstr(acStack_268,param_3), pcVar5 == (char *)0x0 ||
                  (iVar4 = sscanf(acStack_268,"%lx-%lx %4s ",&local_278,&local_280,&local_270),
                  iVar4 != 3)) || (local_26d != 'p'))) {
            pcVar5 = fgets(acStack_268,0x200,__stream);
            if (pcVar5 == (char *)0x0) goto LAB_0011b70c;
          }
        }
        if ((local_278 <= param_1) && (param_1 < local_280)) {
          if (bVar3) {
            if (local_270 == 'r') {
              *param_4 = *param_4 | 1;
            }
            if (local_26f == 'w') {
              *param_4 = *param_4 | 2;
            }
            if (local_26e == 'x') {
              uVar6 = *param_4 | 4;
LAB_0011b6e0:
              *param_4 = uVar6;
            }
          }
          else {
            if (local_270 != 'r') {
              *param_4 = *param_4 & 0xfffffffe;
            }
            if (local_26f != 'w') {
              *param_4 = *param_4 & 0xfffffffd;
            }
            if (local_26e != 'x') {
              uVar6 = *param_4 & 0xfffffffb;
              goto LAB_0011b6e0;
            }
          }
          bVar3 = false;
          uVar7 = 0;
          param_1 = local_280;
          if (uVar1 <= local_280) goto LAB_0011b710;
        }
        pcVar5 = fgets(acStack_268,0x200,__stream);
      } while (pcVar5 != (char *)0x0);
    }
LAB_0011b70c:
    uVar7 = 0x3f1;
LAB_0011b710:
    iVar4 = fclose(__stream);
    if (*(long *)(lVar2 + 0x28) != local_68) {
LAB_0011b760:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(iVar4);
    }
  }
  return uVar7;
}


// ==== FUN_0011b764 @ 0011b764

void FUN_0011b764(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  FUN_0011b4ec(param_1,8,param_2,param_3);
  return;
}


// ==== FUN_0011b774 @ 0011b774

int FUN_0011b774(ulong param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  iVar1 = getpagesize();
  iVar2 = getpagesize();
  iVar3 = getpagesize();
  iVar4 = getpagesize();
  iVar2 = mprotect((void *)((long)-iVar1 & param_1),
                   ((param_1 + 7 & (long)-iVar2) + (long)iVar3) - ((long)-iVar4 & param_1),param_2);
  iVar1 = 0;
  if (iVar2 != 0) {
    piVar5 = (int *)__errno();
    iVar1 = 0x3e9;
    if (*piVar5 != 0) {
      iVar1 = *piVar5;
    }
  }
  return iVar1;
}


// ==== FUN_0011b800 @ 0011b800

void FUN_0011b800(ulong param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = getpagesize();
  iVar2 = getpagesize();
  iVar3 = getpagesize();
  FUN_00133c0c((long)-iVar1 & param_1,(param_1 + 7 & (long)-iVar2) + (long)iVar3);
  return;
}


// ==== FUN_0011b850 @ 0011b850

char * FUN_0011b850(void)

{
  return "libxhook 1.2.0 (aarch64)";
}


// ==== FUN_0011b85c @ 0011b85c

int FUN_0011b85c(pthread_cond_t *param_1)

{
  int iVar1;
  
                    /* try { // try from 0011b868 to 0011b86b has its CatchHandler @ 0011b878 */
  iVar1 = pthread_cond_signal(param_1);
  return iVar1;
}


// ==== FUN_0011b87c @ 0011b87c

int FUN_0011b87c(pthread_cond_t *param_1)

{
  int iVar1;
  
                    /* try { // try from 0011b888 to 0011b88b has its CatchHandler @ 0011b898 */
  iVar1 = pthread_cond_destroy(param_1);
  return iVar1;
}


// ==== FUN_0011b89c @ 0011b89c

void FUN_0011b89c(void)

{
  return;
}


// ==== FUN_0011b8a4 @ 0011b8a4

void FUN_0011b8a4(long *param_1)

{
  long lVar1;
  
  if ((param_1[2] == 0) || (lVar1 = FUN_00133da0(0xffffffffffffffff), lVar1 == 0)) {
                    /* WARNING: Could not recover jumptable at 0x0011b8f8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 0x20))(param_1);
    return;
  }
  return;
}


// ==== FUN_0011b908 @ 0011b908

int FUN_0011b908(pthread_mutex_t *param_1)

{
  int iVar1;
  pthread_mutex_t *__mutex;
  
  iVar1 = pthread_mutex_lock(param_1);
  if (iVar1 == 0) {
    return 0;
  }
  __mutex = (pthread_mutex_t *)FUN_0011d350(iVar1,"mutex lock failed");
  iVar1 = pthread_mutex_unlock(__mutex);
  return iVar1;
}


// ==== FUN_0011b934 @ 0011b934

int FUN_0011b934(pthread_mutex_t *param_1)

{
  int iVar1;
  
                    /* try { // try from 0011b940 to 0011b943 has its CatchHandler @ 0011b950 */
  iVar1 = pthread_mutex_unlock(param_1);
  return iVar1;
}


// ==== FUN_0011b954 @ 0011b954

int FUN_0011b954(pthread_mutex_t *param_1)

{
  int iVar1;
  
                    /* try { // try from 0011b960 to 0011b963 has its CatchHandler @ 0011b970 */
  iVar1 = pthread_mutex_destroy(param_1);
  return iVar1;
}


// ==== FUN_0011b974 @ 0011b974

void FUN_0011b974(size_t param_1)

{
  void *pvVar1;
  code *pcVar2;
  undefined8 uVar3;
  
  if (param_1 == 0) {
    param_1 = 1;
  }
  while( true ) {
    pvVar1 = malloc(param_1);
    if (pvVar1 != (void *)0x0) {
      return;
    }
    pcVar2 = (code *)FUN_0011dd24();
    if (pcVar2 == (code *)0x0) break;
    (*pcVar2)();
  }
  uVar3 = FUN_0011d504(8);
  FUN_001336c4();
  pvVar1 = (void *)FUN_0011d57c(uVar3,&PTR_PTR_0013e680,FUN_001336a4);
  free(pvVar1);
  return;
}


// ==== free @ 0011b9e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== FUN_0011b9e8 @ 0011b9e8

void FUN_0011b9e8(undefined8 *param_1,void *param_2)

{
  long lVar1;
  long *plVar2;
  
  *param_1 = &PTR_FUN_0013e6a8;
                    /* try { // try from 0011ba14 to 0011ba2b has its CatchHandler @ 0011ba60 */
  lVar1 = __strlen_chk(param_2,0xffffffffffffffff);
  plVar2 = (long *)FUN_0011b974(lVar1 + 0x19);
  *plVar2 = lVar1;
  plVar2[1] = lVar1;
  *(undefined4 *)(plVar2 + 2) = 0;
  memcpy(plVar2 + 3,param_2,lVar1 + 1);
  param_1[1] = plVar2 + 3;
  return;
}


// ==== FUN_0011ba74 @ 0011ba74

void FUN_0011ba74(undefined8 *param_1,byte *param_2)

{
  byte bVar1;
  long lVar2;
  long *plVar3;
  byte *__src;
  
  bVar1 = *param_2;
  *param_1 = &PTR_FUN_0013e6d0;
  __src = *(byte **)(param_2 + 0x10);
  if ((bVar1 & 1) == 0) {
    __src = param_2 + 1;
  }
                    /* try { // try from 0011baac to 0011bac3 has its CatchHandler @ 0011baf8 */
  lVar2 = __strlen_chk(__src,0xffffffffffffffff);
  plVar3 = (long *)FUN_0011b974(lVar2 + 0x19);
  *plVar3 = lVar2;
  plVar3[1] = lVar2;
  *(undefined4 *)(plVar3 + 2) = 0;
  memcpy(plVar3 + 3,__src,lVar2 + 1);
  param_1[1] = plVar3 + 3;
  return;
}


// ==== FUN_0011bb0c @ 0011bb0c

void FUN_0011bb0c(undefined8 *param_1,void *param_2)

{
  long lVar1;
  long *plVar2;
  
  *param_1 = &PTR_FUN_0013e6d0;
                    /* try { // try from 0011bb38 to 0011bb4f has its CatchHandler @ 0011bb84 */
  lVar1 = __strlen_chk(param_2,0xffffffffffffffff);
  plVar2 = (long *)FUN_0011b974(lVar1 + 0x19);
  *plVar2 = lVar1;
  plVar2[1] = lVar1;
  *(undefined4 *)(plVar2 + 2) = 0;
  memcpy(plVar2 + 3,param_2,lVar1 + 1);
  param_1[1] = plVar2 + 3;
  return;
}


// ==== FUN_0011bb98 @ 0011bb98

void FUN_0011bb98(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_001157bc("basic_string");
}


// ==== FUN_0011bbb0 @ 0011bbb0

void FUN_0011bbb0(void)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = FUN_0011bbc8("basic_string");
  uVar2 = FUN_0011d504(0x10);
  FUN_0011c7c8(uVar2,uVar1);
  uVar1 = FUN_0011d57c(uVar2,&PTR_PTR_0013e768,FUN_001336f4);
  FUN_0011d558(uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_00134000(uVar1);
}


// ==== FUN_0011bbc8 @ 0011bbc8

void FUN_0011bbc8(undefined8 param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = FUN_0011d504(0x10);
                    /* try { // try from 0011bbe8 to 0011bbef has its CatchHandler @ 0011bc08 */
  FUN_0011c7c8(uVar1,param_1);
  uVar2 = FUN_0011d57c(uVar1,&PTR_PTR_0013e768,FUN_001336f4);
                    /* catch() { ... } // from try @ 0011bbe8 with catch @ 0011bc08 */
  FUN_0011d558(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_00134000(uVar2);
}


// ==== FUN_0011bc1c @ 0011bc1c

ulong * FUN_0011bc1c(ulong *param_1,ulong param_2,byte *param_3,ulong param_4,size_t param_5,
                    long param_6,size_t param_7,void *param_8)

{
  byte *pbVar1;
  long lVar2;
  void *__src;
  byte bVar3;
  size_t sVar4;
  ulong *puVar5;
  ulong *puVar6;
  ulong *extraout_x0;
  ulong *__dest;
  ulong *extraout_x0_00;
  ulong uVar7;
  byte *pbVar8;
  undefined1 *__dest_00;
  ulong uVar9;
  ulong uVar10;
  undefined1 auVar11 [16];
  undefined1 *puStack_130;
  undefined8 uStack_128;
  undefined1 *puStack_f0;
  code *pcStack_e8;
  undefined1 *puStack_90;
  code *pcStack_88;
  
  if (param_3 <= (byte *)(-0x12 - param_2)) {
    pbVar8 = (byte *)param_1[2];
    if ((*param_1 & 1) == 0) {
      pbVar8 = (byte *)((long)param_1 + 1);
    }
    if (param_2 < 0x7fffffffffffffe7) {
      pbVar1 = (byte *)(param_2 << 1);
      if ((byte *)(param_2 << 1) <= param_3 + param_2) {
        pbVar1 = param_3 + param_2;
      }
      uVar10 = 0x17;
      if ((byte *)0x16 < pbVar1) {
        uVar10 = (ulong)(pbVar1 + 0x10) & 0xfffffffffffffff0;
      }
    }
    else {
      uVar10 = 0xffffffffffffffef;
    }
    puVar5 = (ulong *)FUN_0011b974(uVar10);
    puVar6 = puVar5;
    if (param_5 != 0) {
      puVar6 = memcpy(puVar5,pbVar8,param_5);
    }
    if (param_7 != 0) {
      puVar6 = memcpy((void *)((long)puVar5 + param_5),param_8,param_7);
    }
    sVar4 = param_4 - (param_5 + param_6);
    if (sVar4 != 0) {
      puVar6 = memcpy((void *)((long)puVar5 + param_7 + param_5),pbVar8 + param_6 + param_5,sVar4);
    }
    if (param_2 != 0x16) {
      free(pbVar8);
      puVar6 = extraout_x0;
    }
    uVar9 = param_7 + param_5 + sVar4;
    *param_1 = uVar10 | 1;
    param_1[1] = uVar9;
    param_1[2] = (ulong)puVar5;
    *(undefined1 *)((long)puVar5 + uVar9) = 0;
    return puVar6;
  }
  auVar11 = FUN_0011bb98(param_1);
  puVar5 = auVar11._8_8_;
  puVar6 = auVar11._0_8_;
  puStack_f0 = (undefined1 *)&puStack_90;
  pcStack_88 = FUN_0011bd5c;
  if ((*puVar5 & 1) == 0) {
    uVar9 = puVar5[1];
    uVar10 = *puVar5;
    puVar6[2] = puVar5[2];
    puVar6[1] = uVar9;
    *puVar6 = uVar10;
    return puVar6;
  }
  uVar10 = puVar5[1];
  __src = (void *)puVar5[2];
  if (uVar10 < 0x17) {
    __dest_00 = (undefined1 *)((long)puVar6 + 1);
    *(char *)puVar6 = (char)((int)uVar10 << 1);
    puStack_90 = (undefined1 *)((long)register0x00000008 + -0x60);
  }
  else {
    if (0xffffffffffffffef < uVar10) {
      puStack_90 = (undefined1 *)((long)register0x00000008 + -0x60);
      auVar11 = FUN_0011bb98(puVar6);
      uVar9 = auVar11._8_8_;
      puVar6 = auVar11._0_8_;
      pcStack_e8 = FUN_0011be08;
      if (param_3 <= (byte *)(-0x11 - uVar9)) {
        pbVar8 = (byte *)puVar6[2];
        if ((*puVar6 & 1) == 0) {
          pbVar8 = (byte *)((long)puVar6 + 1);
        }
        if (uVar9 < 0x7fffffffffffffe7) {
          pbVar1 = (byte *)(uVar9 << 1);
          if ((byte *)(uVar9 << 1) <= param_3 + uVar9) {
            pbVar1 = param_3 + uVar9;
          }
          uVar10 = 0x17;
          if ((byte *)0x16 < pbVar1) {
            uVar10 = (ulong)(pbVar1 + 0x10) & 0xfffffffffffffff0;
          }
        }
        else {
          uVar10 = 0xffffffffffffffef;
        }
        puStack_f0 = (undefined1 *)&puStack_90;
        __dest = (ulong *)FUN_0011b974(uVar10);
        puVar5 = __dest;
        if (param_5 != 0) {
          puVar5 = memcpy(__dest,pbVar8,param_5);
        }
        sVar4 = param_4 - (param_5 + param_6);
        if (sVar4 != 0) {
          puVar5 = memcpy((void *)((long)__dest + param_7 + param_5),pbVar8 + param_6 + param_5,
                          sVar4);
        }
        if (uVar9 != 0x16) {
          free(pbVar8);
          puVar5 = extraout_x0_00;
        }
        puVar6[2] = (ulong)__dest;
        *puVar6 = uVar10 | 1;
        return puVar5;
      }
      auVar11 = FUN_0011bb98(puVar6);
      uVar7 = auVar11._8_8_;
      puVar6 = auVar11._0_8_;
      uStack_128 = 0x11bf20;
      bVar3 = (byte)*puVar6;
      uVar9 = (ulong)(bVar3 >> 1);
      if ((bVar3 & 1) != 0) {
        uVar9 = puVar6[1];
      }
      if (uVar9 < uVar7) {
        puStack_130 = (undefined1 *)&puStack_f0;
        auVar11 = FUN_0011bbb0(puVar6);
        puVar6 = auVar11._0_8_;
        bVar3 = (byte)*puVar6;
        uVar9 = (ulong)(bVar3 >> 1);
        lVar2 = 0x16;
        if ((bVar3 & 1) != 0) {
          uVar9 = puVar6[1];
          lVar2 = (*puVar6 & 0xfffffffffffffffe) - 1;
        }
        if ((byte *)(lVar2 - uVar9) < param_3) {
          FUN_0011bc1c(puVar6,lVar2,param_3 + (uVar9 - lVar2),uVar9,uVar9,0,param_3,auVar11._8_8_,
                       &puStack_130,FUN_0011c03c,uVar10);
        }
        else if (param_3 != (byte *)0x0) {
          uVar10 = puVar6[2];
          if ((bVar3 & 1) == 0) {
            uVar10 = (long)puVar6 + 1;
          }
          memcpy((void *)(uVar10 + uVar9),auVar11._8_8_,(size_t)param_3);
          param_3 = param_3 + uVar9;
          if ((*puVar6 & 1) == 0) {
            *(char *)puVar6 = (char)((int)param_3 << 1);
          }
          else {
            puVar6[1] = (ulong)param_3;
          }
          param_3[uVar10] = 0;
        }
        return puVar6;
      }
      lVar2 = 0x16;
      if ((bVar3 & 1) != 0) {
        lVar2 = (*puVar6 & 0xfffffffffffffffe) - 1;
      }
      if (lVar2 - uVar9 < param_4) {
        puStack_130 = (undefined1 *)&puStack_f0;
        FUN_0011bc1c(puVar6,lVar2,(uVar9 + param_4) - lVar2,uVar9,uVar7,0,param_4,param_3);
      }
      else if (param_4 != 0) {
        pbVar8 = (byte *)puVar6[2];
        if ((bVar3 & 1) == 0) {
          pbVar8 = (byte *)((long)puVar6 + 1);
        }
        puStack_130 = (undefined1 *)&puStack_f0;
        if (uVar9 - uVar7 != 0) {
          pbVar1 = pbVar8 + uVar7;
          uVar10 = param_4;
          if (pbVar8 + uVar9 <= param_3 || param_3 < pbVar1) {
            uVar10 = 0;
          }
          param_3 = param_3 + uVar10;
          puStack_130 = (undefined1 *)&puStack_f0;
          memmove(pbVar1 + param_4,pbVar1,uVar9 - uVar7);
        }
        memmove(pbVar8 + uVar7,param_3,param_4);
        uVar9 = uVar9 + param_4;
        if ((*puVar6 & 1) == 0) {
          *(byte *)puVar6 = (byte)((int)uVar9 << 1);
        }
        else {
          puVar6[1] = uVar9;
        }
        pbVar8[uVar9] = 0;
      }
      return puVar6;
    }
    uVar9 = uVar10 + 0x10 & 0xfffffffffffffff0;
    puStack_90 = (undefined1 *)((long)register0x00000008 + -0x60);
    __dest_00 = (undefined1 *)FUN_0011b974(uVar9);
    puVar6[1] = uVar10;
    puVar6[2] = (ulong)__dest_00;
    *puVar6 = uVar9 | 1;
  }
  puVar6 = memcpy(__dest_00,__src,uVar10 + 1);
  return puVar6;
}


// ==== FUN_0011bd5c @ 0011bd5c

ulong * FUN_0011bd5c(ulong *param_1,ulong *param_2,byte *param_3,ulong param_4,size_t param_5,
                    long param_6,long param_7)

{
  byte *pbVar1;
  long lVar2;
  void *__src;
  byte bVar3;
  size_t __n;
  ulong *puVar4;
  ulong *__dest;
  ulong *puVar5;
  ulong *extraout_x0;
  ulong uVar6;
  byte *pbVar7;
  undefined1 *__dest_00;
  ulong uVar8;
  ulong uVar9;
  undefined1 auVar10 [16];
  undefined1 *puStack_d0;
  undefined8 uStack_c8;
  undefined1 *puStack_90;
  code *pcStack_88;
  
  if ((*param_2 & 1) == 0) {
    uVar8 = param_2[1];
    uVar9 = *param_2;
    param_1[2] = param_2[2];
    param_1[1] = uVar8;
    *param_1 = uVar9;
    return param_1;
  }
  uVar9 = param_2[1];
  __src = (void *)param_2[2];
  if (uVar9 < 0x17) {
    __dest_00 = (undefined1 *)((long)param_1 + 1);
    *(char *)param_1 = (char)((int)uVar9 << 1);
  }
  else {
    if (0xffffffffffffffef < uVar9) {
      auVar10 = FUN_0011bb98(param_1);
      uVar8 = auVar10._8_8_;
      puVar4 = auVar10._0_8_;
      pcStack_88 = FUN_0011be08;
      if (param_3 <= (byte *)(-0x11 - uVar8)) {
        pbVar7 = (byte *)puVar4[2];
        if ((*puVar4 & 1) == 0) {
          pbVar7 = (byte *)((long)puVar4 + 1);
        }
        if (uVar8 < 0x7fffffffffffffe7) {
          pbVar1 = (byte *)(uVar8 << 1);
          if ((byte *)(uVar8 << 1) <= param_3 + uVar8) {
            pbVar1 = param_3 + uVar8;
          }
          uVar9 = 0x17;
          if ((byte *)0x16 < pbVar1) {
            uVar9 = (ulong)(pbVar1 + 0x10) & 0xfffffffffffffff0;
          }
        }
        else {
          uVar9 = 0xffffffffffffffef;
        }
        puStack_90 = (undefined1 *)((long)register0x00000008 + -0x30);
        __dest = (ulong *)FUN_0011b974(uVar9);
        puVar5 = __dest;
        if (param_5 != 0) {
          puVar5 = memcpy(__dest,pbVar7,param_5);
        }
        __n = param_4 - (param_5 + param_6);
        if (__n != 0) {
          puVar5 = memcpy((void *)((long)__dest + param_7 + param_5),pbVar7 + param_6 + param_5,__n)
          ;
        }
        if (uVar8 != 0x16) {
          free(pbVar7);
          puVar5 = extraout_x0;
        }
        puVar4[2] = (ulong)__dest;
        *puVar4 = uVar9 | 1;
        return puVar5;
      }
      puStack_90 = (undefined1 *)((long)register0x00000008 + -0x30);
      auVar10 = FUN_0011bb98(puVar4);
      uVar6 = auVar10._8_8_;
      puVar4 = auVar10._0_8_;
      uStack_c8 = 0x11bf20;
      bVar3 = (byte)*puVar4;
      uVar8 = (ulong)(bVar3 >> 1);
      if ((bVar3 & 1) != 0) {
        uVar8 = puVar4[1];
      }
      if (uVar8 < uVar6) {
        puStack_d0 = (undefined1 *)&puStack_90;
        auVar10 = FUN_0011bbb0(puVar4);
        puVar4 = auVar10._0_8_;
        bVar3 = (byte)*puVar4;
        uVar8 = (ulong)(bVar3 >> 1);
        lVar2 = 0x16;
        if ((bVar3 & 1) != 0) {
          uVar8 = puVar4[1];
          lVar2 = (*puVar4 & 0xfffffffffffffffe) - 1;
        }
        if ((byte *)(lVar2 - uVar8) < param_3) {
          FUN_0011bc1c(puVar4,lVar2,param_3 + (uVar8 - lVar2),uVar8,uVar8,0,param_3,auVar10._8_8_,
                       &puStack_d0,FUN_0011c03c,uVar9);
        }
        else if (param_3 != (byte *)0x0) {
          uVar9 = puVar4[2];
          if ((bVar3 & 1) == 0) {
            uVar9 = (long)puVar4 + 1;
          }
          memcpy((void *)(uVar9 + uVar8),auVar10._8_8_,(size_t)param_3);
          param_3 = param_3 + uVar8;
          if ((*puVar4 & 1) == 0) {
            *(char *)puVar4 = (char)((int)param_3 << 1);
          }
          else {
            puVar4[1] = (ulong)param_3;
          }
          param_3[uVar9] = 0;
        }
        return puVar4;
      }
      lVar2 = 0x16;
      if ((bVar3 & 1) != 0) {
        lVar2 = (*puVar4 & 0xfffffffffffffffe) - 1;
      }
      if (lVar2 - uVar8 < param_4) {
        puStack_d0 = (undefined1 *)&puStack_90;
        FUN_0011bc1c(puVar4,lVar2,(uVar8 + param_4) - lVar2,uVar8,uVar6,0,param_4,param_3);
      }
      else if (param_4 != 0) {
        pbVar7 = (byte *)puVar4[2];
        if ((bVar3 & 1) == 0) {
          pbVar7 = (byte *)((long)puVar4 + 1);
        }
        puStack_d0 = (undefined1 *)&puStack_90;
        if (uVar8 - uVar6 != 0) {
          pbVar1 = pbVar7 + uVar6;
          uVar9 = param_4;
          if (pbVar7 + uVar8 <= param_3 || param_3 < pbVar1) {
            uVar9 = 0;
          }
          param_3 = param_3 + uVar9;
          puStack_d0 = (undefined1 *)&puStack_90;
          memmove(pbVar1 + param_4,pbVar1,uVar8 - uVar6);
        }
        memmove(pbVar7 + uVar6,param_3,param_4);
        uVar8 = uVar8 + param_4;
        if ((*puVar4 & 1) == 0) {
          *(byte *)puVar4 = (byte)((int)uVar8 << 1);
        }
        else {
          puVar4[1] = uVar8;
        }
        pbVar7[uVar8] = 0;
      }
      return puVar4;
    }
    uVar8 = uVar9 + 0x10 & 0xfffffffffffffff0;
    __dest_00 = (undefined1 *)FUN_0011b974(uVar8);
    param_1[1] = uVar9;
    param_1[2] = (ulong)__dest_00;
    *param_1 = uVar8 | 1;
  }
  puVar4 = memcpy(__dest_00,__src,uVar9 + 1);
  return puVar4;
}


// ==== FUN_0011be08 @ 0011be08

ulong * FUN_0011be08(ulong *param_1,ulong param_2,byte *param_3,ulong param_4,size_t param_5,
                    long param_6,long param_7)

{
  byte *pbVar1;
  long lVar2;
  ulong uVar3;
  byte bVar4;
  size_t __n;
  ulong *__dest;
  ulong *puVar5;
  ulong *extraout_x0;
  byte *pbVar6;
  ulong uVar7;
  ulong uVar8;
  undefined1 auVar9 [16];
  undefined1 *local_a0;
  undefined8 uStack_98;
  
  if (param_3 <= (byte *)(-0x11 - param_2)) {
    pbVar6 = (byte *)param_1[2];
    if ((*param_1 & 1) == 0) {
      pbVar6 = (byte *)((long)param_1 + 1);
    }
    if (param_2 < 0x7fffffffffffffe7) {
      pbVar1 = (byte *)(param_2 << 1);
      if ((byte *)(param_2 << 1) <= param_3 + param_2) {
        pbVar1 = param_3 + param_2;
      }
      uVar8 = 0x17;
      if ((byte *)0x16 < pbVar1) {
        uVar8 = (ulong)(pbVar1 + 0x10) & 0xfffffffffffffff0;
      }
    }
    else {
      uVar8 = 0xffffffffffffffef;
    }
    __dest = (ulong *)FUN_0011b974(uVar8);
    puVar5 = __dest;
    if (param_5 != 0) {
      puVar5 = memcpy(__dest,pbVar6,param_5);
    }
    __n = param_4 - (param_5 + param_6);
    if (__n != 0) {
      puVar5 = memcpy((void *)((long)__dest + param_7 + param_5),pbVar6 + param_6 + param_5,__n);
    }
    if (param_2 != 0x16) {
      free(pbVar6);
      puVar5 = extraout_x0;
    }
    param_1[2] = (ulong)__dest;
    *param_1 = uVar8 | 1;
    return puVar5;
  }
  auVar9 = FUN_0011bb98(param_1);
  uVar7 = auVar9._8_8_;
  puVar5 = auVar9._0_8_;
  uStack_98 = 0x11bf20;
  bVar4 = (byte)*puVar5;
  uVar8 = (ulong)(bVar4 >> 1);
  if ((bVar4 & 1) != 0) {
    uVar8 = puVar5[1];
  }
  if (uVar8 < uVar7) {
    local_a0 = (undefined1 *)((long)register0x00000008 + -0x60);
    auVar9 = FUN_0011bbb0(puVar5);
    puVar5 = auVar9._0_8_;
    bVar4 = (byte)*puVar5;
    uVar8 = (ulong)(bVar4 >> 1);
    lVar2 = 0x16;
    if ((bVar4 & 1) != 0) {
      uVar8 = puVar5[1];
      lVar2 = (*puVar5 & 0xfffffffffffffffe) - 1;
    }
    if ((byte *)(lVar2 - uVar8) < param_3) {
      FUN_0011bc1c(puVar5,lVar2,param_3 + (uVar8 - lVar2),uVar8,uVar8,0,param_3,auVar9._8_8_,
                   &local_a0,FUN_0011c03c);
    }
    else if (param_3 != (byte *)0x0) {
      uVar7 = puVar5[2];
      if ((bVar4 & 1) == 0) {
        uVar7 = (long)puVar5 + 1;
      }
      memcpy((void *)(uVar7 + uVar8),auVar9._8_8_,(size_t)param_3);
      param_3 = param_3 + uVar8;
      if ((*puVar5 & 1) == 0) {
        *(char *)puVar5 = (char)((int)param_3 << 1);
      }
      else {
        puVar5[1] = (ulong)param_3;
      }
      param_3[uVar7] = 0;
    }
    return puVar5;
  }
  lVar2 = 0x16;
  if ((bVar4 & 1) != 0) {
    lVar2 = (*puVar5 & 0xfffffffffffffffe) - 1;
  }
  if (lVar2 - uVar8 < param_4) {
    local_a0 = (undefined1 *)((long)register0x00000008 + -0x60);
    FUN_0011bc1c(puVar5,lVar2,(uVar8 + param_4) - lVar2,uVar8,uVar7,0,param_4,param_3);
  }
  else if (param_4 != 0) {
    pbVar6 = (byte *)puVar5[2];
    if ((bVar4 & 1) == 0) {
      pbVar6 = (byte *)((long)puVar5 + 1);
    }
    local_a0 = (undefined1 *)((long)register0x00000008 + -0x60);
    if (uVar8 - uVar7 != 0) {
      pbVar1 = pbVar6 + uVar7;
      uVar3 = param_4;
      if (pbVar6 + uVar8 <= param_3 || param_3 < pbVar1) {
        uVar3 = 0;
      }
      param_3 = param_3 + uVar3;
      local_a0 = (undefined1 *)((long)register0x00000008 + -0x60);
      memmove(pbVar1 + param_4,pbVar1,uVar8 - uVar7);
    }
    memmove(pbVar6 + uVar7,param_3,param_4);
    uVar8 = uVar8 + param_4;
    if ((*puVar5 & 1) == 0) {
      *(byte *)puVar5 = (byte)((int)uVar8 << 1);
    }
    else {
      puVar5[1] = uVar8;
    }
    pbVar6[uVar8] = 0;
  }
  return puVar5;
}


// ==== FUN_0011c03c @ 0011c03c

ulong * FUN_0011c03c(ulong *param_1,void *param_2,ulong param_3)

{
  ulong uVar1;
  byte bVar2;
  long lVar3;
  ulong uVar4;
  
  bVar2 = (byte)*param_1;
  uVar1 = (ulong)(bVar2 >> 1);
  lVar3 = 0x16;
  if ((bVar2 & 1) != 0) {
    uVar1 = param_1[1];
    lVar3 = (*param_1 & 0xfffffffffffffffe) - 1;
  }
  if (lVar3 - uVar1 < param_3) {
    FUN_0011bc1c(param_1,lVar3,(uVar1 + param_3) - lVar3,uVar1,uVar1,0,param_3);
  }
  else if (param_3 != 0) {
    uVar4 = param_1[2];
    if ((bVar2 & 1) == 0) {
      uVar4 = (long)param_1 + 1;
    }
    memcpy((void *)(uVar4 + uVar1),param_2,param_3);
    uVar1 = uVar1 + param_3;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)((int)uVar1 << 1);
    }
    else {
      param_1[1] = uVar1;
    }
    *(undefined1 *)(uVar4 + uVar1) = 0;
  }
  return param_1;
}


// ==== FUN_0011c108 @ 0011c108

ulong * FUN_0011c108(ulong *param_1,ulong param_2,byte *param_3)

{
  byte *__src;
  ulong uVar1;
  long lVar2;
  size_t sVar3;
  byte bVar4;
  ulong *puVar5;
  size_t __n;
  byte *pbVar6;
  ulong uVar7;
  undefined1 auVar8 [16];
  undefined1 auStack_40 [16];
  
  __n = strlen((char *)param_3);
  bVar4 = (byte)*param_1;
  uVar1 = (ulong)(bVar4 >> 1);
  if ((bVar4 & 1) != 0) {
    uVar1 = param_1[1];
  }
  if (uVar1 < param_2) {
    auVar8 = FUN_0011bbb0(param_1);
    puVar5 = auVar8._0_8_;
    bVar4 = (byte)*puVar5;
    uVar1 = (ulong)(bVar4 >> 1);
    lVar2 = 0x16;
    if ((bVar4 & 1) != 0) {
      uVar1 = puVar5[1];
      lVar2 = (*puVar5 & 0xfffffffffffffffe) - 1;
    }
    if ((byte *)(lVar2 - uVar1) < param_3) {
      FUN_0011bc1c(puVar5,lVar2,param_3 + (uVar1 - lVar2),uVar1,uVar1,0,param_3,auVar8._8_8_,
                   auStack_40,FUN_0011c03c);
    }
    else if (param_3 != (byte *)0x0) {
      uVar7 = puVar5[2];
      if ((bVar4 & 1) == 0) {
        uVar7 = (long)puVar5 + 1;
      }
      memcpy((void *)(uVar7 + uVar1),auVar8._8_8_,(size_t)param_3);
      param_3 = param_3 + uVar1;
      if ((*puVar5 & 1) == 0) {
        *(char *)puVar5 = (char)((int)param_3 << 1);
      }
      else {
        puVar5[1] = (ulong)param_3;
      }
      param_3[uVar7] = 0;
    }
    return puVar5;
  }
  lVar2 = 0x16;
  if ((bVar4 & 1) != 0) {
    lVar2 = (*param_1 & 0xfffffffffffffffe) - 1;
  }
  if (lVar2 - uVar1 < __n) {
    FUN_0011bc1c(param_1,lVar2,(uVar1 + __n) - lVar2,uVar1,param_2,0,__n,param_3);
  }
  else if (__n != 0) {
    pbVar6 = (byte *)param_1[2];
    if ((bVar4 & 1) == 0) {
      pbVar6 = (byte *)((long)param_1 + 1);
    }
    if (uVar1 - param_2 != 0) {
      __src = pbVar6 + param_2;
      sVar3 = __n;
      if (pbVar6 + uVar1 <= param_3 || param_3 < __src) {
        sVar3 = 0;
      }
      param_3 = param_3 + sVar3;
      memmove(__src + __n,__src,uVar1 - param_2);
    }
    memmove(pbVar6 + param_2,param_3,__n);
    uVar1 = uVar1 + __n;
    if ((*param_1 & 1) == 0) {
      *(byte *)param_1 = (byte)((int)uVar1 << 1);
    }
    else {
      param_1[1] = uVar1;
    }
    pbVar6[uVar1] = 0;
  }
  return param_1;
}


// ==== FUN_0011c154 @ 0011c154

void FUN_0011c154(ulong *param_1,undefined1 param_2)

{
  byte bVar1;
  ulong uVar2;
  ulong uVar3;
  
  if (((byte)*param_1 & 1) == 0) {
    bVar1 = (byte)*param_1 >> 1;
    uVar3 = (ulong)bVar1;
    if (bVar1 == 0x16) {
      uVar3 = 0x16;
      uVar2 = 0x16;
LAB_0011c1a4:
      FUN_0011be08(param_1,uVar2,1,uVar2,uVar2,0,0);
      if ((*param_1 & 1) != 0) goto LAB_0011c1d8;
    }
    uVar2 = (long)param_1 + 1;
    *(char *)param_1 = (char)uVar3 * '\x02' + '\x02';
  }
  else {
    uVar3 = param_1[1];
    uVar2 = (*param_1 & 0xfffffffffffffffe) - 1;
    if (uVar3 == uVar2) goto LAB_0011c1a4;
LAB_0011c1d8:
    uVar2 = param_1[2];
    param_1[1] = uVar3 + 1;
  }
  *(undefined1 *)(uVar2 + uVar3) = param_2;
  ((undefined1 *)(uVar2 + uVar3))[1] = 0;
  return;
}


// ==== FUN_0011c208 @ 0011c208

ulong * FUN_0011c208(ulong *param_1,ulong param_2,int param_3)

{
  ulong uVar1;
  long lVar2;
  uint uVar3;
  ulong uVar4;
  ulong uVar5;
  
  if (param_2 != 0) {
    uVar1 = (ulong)(byte)((byte)*param_1 >> 1);
    lVar2 = 0x16;
    if (((byte)*param_1 & 1) != 0) {
      uVar1 = param_1[1];
      lVar2 = (*param_1 & 0xfffffffffffffffe) - 1;
    }
    if (lVar2 - uVar1 < param_2) {
      FUN_0011be08(param_1,lVar2,(uVar1 + param_2) - lVar2,uVar1,uVar1,0,0);
      uVar3 = (uint)(byte)*param_1;
    }
    else {
      uVar3 = (uint)*param_1 & 0xff;
    }
    uVar5 = uVar1 + param_2;
    uVar4 = param_1[2];
    if ((uVar3 & 1) == 0) {
      uVar4 = (long)param_1 + 1;
    }
    memset((void *)(uVar4 + uVar1),param_3,param_2);
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)((int)uVar5 << 1);
    }
    else {
      param_1[1] = uVar5;
    }
    *(undefined1 *)(uVar4 + uVar5) = 0;
  }
  return param_1;
}


// ==== FUN_0011c2e4 @ 0011c2e4

ulong * FUN_0011c2e4(ulong *param_1,char *param_2)

{
  ulong uVar1;
  byte bVar2;
  long lVar3;
  size_t __n;
  ulong uVar4;
  
  __n = strlen(param_2);
  bVar2 = (byte)*param_1;
  uVar1 = (ulong)(bVar2 >> 1);
  lVar3 = 0x16;
  if ((bVar2 & 1) != 0) {
    uVar1 = param_1[1];
    lVar3 = (*param_1 & 0xfffffffffffffffe) - 1;
  }
  if (lVar3 - uVar1 < __n) {
    FUN_0011bc1c(param_1,lVar3,(uVar1 + __n) - lVar3,uVar1,uVar1,0,__n,param_2);
  }
  else if (__n != 0) {
    uVar4 = param_1[2];
    if ((bVar2 & 1) == 0) {
      uVar4 = (long)param_1 + 1;
    }
    memcpy((void *)(uVar4 + uVar1),param_2,__n);
    uVar1 = uVar1 + __n;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)((int)uVar1 << 1);
    }
    else {
      param_1[1] = uVar1;
    }
    *(undefined1 *)(uVar4 + uVar1) = 0;
  }
  return param_1;
}


// ==== FUN_0011c3c4 @ 0011c3c4

void FUN_0011c3c4(byte *param_1,ulong param_2)

{
  ulong uVar1;
  byte bVar2;
  
  bVar2 = *param_1;
  uVar1 = (ulong)(bVar2 >> 1);
  if ((bVar2 & 1) != 0) {
    uVar1 = *(ulong *)(param_1 + 8);
  }
  if (uVar1 < param_2) {
    FUN_0011c208(param_1,param_2 - uVar1);
  }
  else if ((bVar2 & 1) == 0) {
    param_1[param_2 + 1] = 0;
    *param_1 = (byte)((int)param_2 << 1);
  }
  else {
    *(undefined1 *)(*(long *)(param_1 + 0x10) + param_2) = 0;
    *(ulong *)(param_1 + 8) = param_2;
  }
  return;
}


// ==== FUN_0011c428 @ 0011c428

void FUN_0011c428(ulong *param_1,char *param_2,byte *param_3)

{
  ulong __n;
  byte bVar1;
  byte bVar2;
  long lVar3;
  size_t __n_00;
  undefined8 uVar4;
  byte *__src;
  ulong uVar5;
  void *__dest;
  ulong uVar6;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  __n_00 = strlen(param_2);
  bVar1 = *param_3;
  __n = (ulong)(bVar1 >> 1);
  if ((bVar1 & 1) != 0) {
    __n = *(ulong *)(param_3 + 8);
  }
  uVar6 = __n + __n_00;
  if (0xffffffffffffffef < uVar6) {
                    /* try { // try from 0011c590 to 0011c597 has its CatchHandler @ 0011c598 */
    uVar4 = FUN_0011bb98(param_1);
                    /* catch() { ... } // from try @ 0011c4f0 with catch @ 0011c598
                       catch() { ... } // from try @ 0011c590 with catch @ 0011c598 */
    if ((*param_1 & 1) != 0) {
      free((void *)param_1[2]);
    }
                    /* WARNING: Subroutine does not return */
    FUN_00134000(uVar4);
  }
  if (uVar6 < 0x17) {
    __dest = (void *)((long)param_1 + 1);
    *(char *)param_1 = (char)((int)__n_00 << 1);
  }
  else {
    uVar6 = uVar6 + 0x10 & 0xfffffffffffffff0;
    __dest = (void *)FUN_0011b974(uVar6);
    param_1[1] = __n_00;
    param_1[2] = (ulong)__dest;
    *param_1 = uVar6 | 1;
  }
  if (__n_00 != 0) {
    memcpy(__dest,param_2,__n_00);
  }
  *(undefined1 *)((long)__dest + __n_00) = 0;
  __src = *(byte **)(param_3 + 0x10);
  bVar2 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    __src = param_3 + 1;
  }
  uVar6 = (ulong)(bVar2 >> 1);
  lVar3 = 0x16;
  if ((bVar2 & 1) != 0) {
    uVar6 = param_1[1];
    lVar3 = (*param_1 & 0xfffffffffffffffe) - 1;
  }
  if (lVar3 - uVar6 < __n) {
                    /* try { // try from 0011c4f0 to 0011c51b has its CatchHandler @ 0011c598 */
    FUN_0011bc1c(param_1,lVar3,(uVar6 + __n) - lVar3,uVar6,uVar6,0,__n);
  }
  else if (__n != 0) {
    uVar5 = param_1[2];
    if ((bVar2 & 1) == 0) {
      uVar5 = (long)param_1 + 1;
    }
    memcpy((void *)(uVar5 + uVar6),__src,__n);
    uVar6 = uVar6 + __n;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)((int)uVar6 << 1);
    }
    else {
      param_1[1] = uVar6;
    }
    *(undefined1 *)(uVar5 + uVar6) = 0;
  }
  return;
}


// ==== FUN_0011c5b4 @ 0011c5b4

void FUN_0011c5b4(ulong *param_1,uint param_2)

{
  uint uVar1;
  long lVar2;
  undefined1 *puVar3;
  undefined1 *puVar4;
  ulong __n;
  ulong uVar5;
  undefined1 local_54 [11];
  undefined1 uStack_49;
  long local_48;
  
  lVar2 = tpidr_el0;
  puVar4 = local_54;
  local_48 = *(long *)(lVar2 + 0x28);
  puVar3 = &uStack_49;
  if ((int)param_2 < 0) {
    puVar4 = (undefined1 *)((ulong)puVar4 | 1);
    param_2 = -param_2;
    local_54[0] = 0x2d;
  }
  if ((9 < (long)puVar3 - (long)puVar4) ||
     (uVar1 = (uint)((0x20 - (int)LZCOUNT(param_2 | 1)) * 0x4d1) >> 0xc,
     (long)(ulong)((uVar1 - (param_2 < *(uint *)(&DAT_0010be8c + (ulong)uVar1 * 4))) + 1) <=
     (long)puVar3 - (long)puVar4)) {
    puVar3 = (undefined1 *)FUN_0011c800();
  }
  __n = (long)puVar3 - (long)local_54;
  if (__n < 0xfffffffffffffff0) {
    if (__n < 0x17) {
      puVar4 = (undefined1 *)((long)param_1 + 1);
      *(char *)param_1 = (char)((int)__n << 1);
    }
    else {
      uVar5 = __n + 0x10 & 0xfffffffffffffff0;
      puVar4 = (undefined1 *)FUN_0011b974(uVar5);
      param_1[1] = __n;
      param_1[2] = (ulong)puVar4;
      *param_1 = uVar5 | 1;
    }
    if (local_54 != puVar3) {
      memcpy(puVar4,local_54,__n);
      puVar4 = puVar4 + __n;
    }
    *puVar4 = 0;
    if (*(long *)(lVar2 + 0x28) == local_48) {
      return;
    }
  }
  else {
    FUN_0011bb98(param_1);
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0011c6f0 @ 0011c6f0

void FUN_0011c6f0(ulong *param_1,undefined8 param_2)

{
  long lVar1;
  undefined1 *puVar2;
  undefined1 *__dest;
  ulong __n;
  ulong uVar3;
  undefined1 auStack_60 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  puVar2 = (undefined1 *)FUN_0011ca90(param_2,auStack_60);
  __n = (long)puVar2 - (long)auStack_60;
  if (__n < 0xfffffffffffffff0) {
    if (__n < 0x17) {
      __dest = (undefined1 *)((long)param_1 + 1);
      *(char *)param_1 = (char)((int)__n << 1);
    }
    else {
      uVar3 = __n + 0x10 & 0xfffffffffffffff0;
      __dest = (undefined1 *)FUN_0011b974(uVar3);
      param_1[1] = __n;
      param_1[2] = (ulong)__dest;
      *param_1 = uVar3 | 1;
    }
    if (auStack_60 != puVar2) {
      memcpy(__dest,auStack_60,__n);
      __dest = __dest + __n;
    }
    *__dest = 0;
    if (*(long *)(lVar1 + 0x28) == local_48) {
      return;
    }
  }
  else {
    FUN_0011bb98(param_1);
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0011c7c8 @ 0011c7c8

void FUN_0011c7c8(undefined8 *param_1)

{
  FUN_0011b9e8();
  *param_1 = &PTR_FUN_0013e750;
  return;
}


// ==== FUN_0011c800 @ 0011c800

char * FUN_0011c800(uint param_1,char *param_2)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  uint uVar4;
  char *pcVar5;
  long lVar6;
  
  if (param_1 < 100000000) {
    pcVar5 = (char *)FUN_0011c8d4(param_2,param_1);
    return pcVar5;
  }
  uVar4 = param_1 % 100000000;
  if (param_1 < 1000000000) {
    lVar6 = 1;
    *param_2 = (char)(param_1 / 100000000) + '0';
  }
  else {
    lVar6 = 2;
    *(undefined2 *)param_2 =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)(param_1 / 100000000) * 2);
  }
  param_2 = param_2 + lVar6;
  uVar1 = *(undefined2 *)
           (
           "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
           + (ulong)((uVar4 % 10000) / 100) * 2);
  uVar2 = *(undefined2 *)
           (
           "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
           + ((ulong)(uVar4 / 10000 + (uVar4 / 1000000) * -100) & 0xffff) * 2);
  *(undefined2 *)param_2 =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)(uVar4 / 1000000) * 2);
  uVar3 = *(undefined2 *)
           (
           "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
           + (ulong)((uVar4 % 10000) % 100) * 2);
  *(undefined2 *)(param_2 + 4) = uVar1;
  *(undefined2 *)(param_2 + 2) = uVar2;
  *(undefined2 *)(param_2 + 6) = uVar3;
  return param_2 + 8;
}


// ==== FUN_0011c8d4 @ 0011c8d4

char * FUN_0011c8d4(char *param_1,uint param_2)

{
  undefined2 uVar1;
  uint uVar2;
  uint uVar3;
  ulong uVar4;
  long lVar5;
  
  if (0x270 < param_2 >> 4) {
    uVar4 = (ulong)param_2 / 10000;
    uVar3 = (uint)uVar4;
    if (param_2 < 1000000) {
      if (param_2 >> 5 < 0xc35) {
        lVar5 = 1;
        *param_1 = (char)uVar4 + '0';
      }
      else {
        lVar5 = 2;
        *(undefined2 *)param_1 =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + uVar4 * 2);
      }
    }
    else if (param_2 < 10000000) {
      uVar2 = (uVar3 >> 2 & 0x3fff) / 0x19;
      lVar5 = 3;
      *param_1 = (char)uVar2 + '0';
      *(undefined2 *)(param_1 + 1) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + ((ulong)(uVar3 + uVar2 * -100) & 0xffff) * 2);
    }
    else {
      lVar5 = 4;
      uVar1 = *(undefined2 *)
               (
               "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
               + (ulong)(uVar3 + (int)(uVar4 / 100) * -100) * 2);
      *(undefined2 *)param_1 =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(param_2 / 1000000) * 2);
      *(undefined2 *)(param_1 + 2) = uVar1;
    }
    param_1 = param_1 + lVar5;
    param_2 = param_2 + uVar3 * -10000;
    uVar3 = (param_2 >> 2 & 0x3fff) / 0x19;
    uVar1 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + ((ulong)(param_2 + uVar3 * -100) & 0xffff) * 2);
    *(undefined2 *)param_1 =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)uVar3 * 2);
    *(undefined2 *)(param_1 + 2) = uVar1;
    return param_1 + 4;
  }
  if (param_2 < 100) {
    if (param_2 < 10) {
      *param_1 = (char)param_2 + '0';
      return param_1 + 1;
    }
    *(undefined2 *)param_1 =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)param_2 * 2);
    return param_1 + 2;
  }
  uVar3 = (param_2 >> 2 & 0x3fff) / 0x19;
  uVar4 = (ulong)(param_2 + uVar3 * -100) & 0xffff;
  if (param_2 < 1000) {
    uVar1 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + uVar4 * 2);
    *param_1 = (char)uVar3 + '0';
    *(undefined2 *)(param_1 + 1) = uVar1;
    return param_1 + 3;
  }
  uVar1 = *(undefined2 *)
           (
           "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
           + uVar4 * 2);
  *(undefined2 *)param_1 =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + (ulong)uVar3 * 2);
  *(undefined2 *)(param_1 + 2) = uVar1;
  return param_1 + 4;
}


// ==== FUN_0011ca90 @ 0011ca90

char * FUN_0011ca90(ulong param_1,char *param_2)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  char *pcVar10;
  undefined2 *puVar11;
  uint uVar12;
  long lVar13;
  ulong uVar14;
  
  if (param_1 < 100000000) {
    pcVar10 = (char *)FUN_0011c8d4(param_2,param_1 & 0xffffffff);
    return pcVar10;
  }
  if (param_1 < 10000000000000000) {
    uVar14 = param_1 % 100000000;
    puVar11 = (undefined2 *)FUN_0011c8d4(param_2,param_1 / 100000000 & 0xffffffff);
    uVar7 = (int)uVar14 + (int)(uVar14 / 10000) * -10000;
    uVar12 = (uint)(uVar14 / 40000) / 0x19;
    uVar6 = (uVar7 >> 2 & 0x3fff) / 0x19;
    uVar1 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + (ulong)uVar6 * 2);
    uVar2 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + ((ulong)((int)(uVar14 / 10000) + uVar12 * -100) & 0xffff) * 2);
    *puVar11 = *(undefined2 *)
                (
                "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
                + (ulong)uVar12 * 2);
    uVar3 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + ((ulong)(uVar7 + uVar6 * -100) & 0xffff) * 2);
    puVar11[2] = uVar1;
    puVar11[1] = uVar2;
    pcVar10 = (char *)(puVar11 + 4);
    puVar11[3] = uVar3;
  }
  else {
    uVar14 = param_1 / 10000000000000000;
    uVar12 = (uint)uVar14;
    if (uVar12 < 100) {
      if (uVar12 < 10) {
        lVar13 = 1;
        *param_2 = (char)uVar14 + '0';
      }
      else {
        lVar13 = 2;
        *(undefined2 *)param_2 =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + uVar14 * 2);
      }
    }
    else if (uVar12 < 1000) {
      *param_2 = (char)(uVar12 / 100) + '0';
      lVar13 = 3;
      *(undefined2 *)(param_2 + 1) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(uVar12 % 100) * 2);
    }
    else {
      *(undefined2 *)param_2 =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(uVar12 / 100) * 2);
      lVar13 = 4;
      *(undefined2 *)(param_2 + 2) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (ulong)(uVar12 % 100) * 2);
    }
    uVar14 = (param_1 % 10000000000000000) / 100000000;
    uVar8 = (int)(param_1 % 10000000000000000) + (int)uVar14 * -100000000;
    param_2 = param_2 + lVar13;
    uVar9 = (int)uVar14 + (int)(uVar14 / 10000) * -10000;
    uVar12 = (uint)(uVar14 / 40000) / 0x19;
    uVar6 = (uVar8 / 40000 & 0x3fff) / 0x19;
    uVar7 = (uVar9 >> 2 & 0x3fff) / 0x19;
    uVar1 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + (ulong)uVar6 * 2);
    uVar2 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + (ulong)uVar7 * 2);
    pcVar10 = param_2 + 0x10;
    uVar3 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + ((ulong)((int)(uVar14 / 10000) + uVar12 * -100) & 0xffff) * 2);
    uVar4 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + ((ulong)(uVar9 + uVar7 * -100) & 0xffff) * 2);
    *(undefined2 *)param_2 =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (ulong)uVar12 * 2);
    uVar5 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + ((ulong)(uVar8 / 10000 + uVar6 * -100) & 0xffff) * 2);
    *(undefined2 *)(param_2 + 8) = uVar1;
    uVar1 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + (ulong)((uVar8 % 10000) / 100) * 2);
    *(undefined2 *)(param_2 + 4) = uVar2;
    uVar2 = *(undefined2 *)
             (
             "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
             + (ulong)((uVar8 % 10000) % 100) * 2);
    *(undefined2 *)(param_2 + 2) = uVar3;
    *(undefined2 *)(param_2 + 6) = uVar4;
    *(undefined2 *)(param_2 + 10) = uVar5;
    *(undefined2 *)(param_2 + 0xc) = uVar1;
    *(undefined2 *)(param_2 + 0xe) = uVar2;
  }
  return pcVar10;
}


// ==== FUN_0011cce4 @ 0011cce4

undefined4 FUN_0011cce4(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}


// ==== FUN_0011ccf8 @ 0011ccf8

bool FUN_0011ccf8(long *param_1,undefined8 param_2,int *param_3)

{
  int iVar1;
  long extraout_x1;
  
  iVar1 = (**(code **)(*param_1 + 0x18))();
  return *(long *)(param_3 + 2) == extraout_x1 && *param_3 == iVar1;
}


// ==== FUN_0011cd44 @ 0011cd44

bool FUN_0011cd44(long param_1,int *param_2,int param_3)

{
  return *(long *)(param_2 + 2) == param_1 && *param_2 == param_3;
}


// ==== FUN_0011d098 @ 0011d098

void FUN_0011d098(undefined8 *param_1,int *param_2,byte *param_3)

{
  ulong uVar1;
  int iVar2;
  long lVar3;
  void *pvVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar3 = tpidr_el0;
  local_38 = *(long *)(lVar3 + 0x28);
  iVar2 = *param_2;
  if (iVar2 != 0) {
    uVar1 = (ulong)(*param_3 >> 1);
    if ((*param_3 & 1) != 0) {
      uVar1 = *(ulong *)(param_3 + 8);
    }
    if (uVar1 != 0) {
      FUN_0011c2e4(param_3,&DAT_0010aa52);
      iVar2 = *param_2;
    }
    (**(code **)(**(long **)(param_2 + 2) + 0x30))(local_50,*(long **)(param_2 + 2),iVar2);
    uVar1 = (ulong)(local_50[0] >> 1);
    pvVar4 = (void *)((ulong)local_50 | 1);
    if ((local_50[0] & 1) != 0) {
      uVar1 = local_48;
      pvVar4 = local_40;
    }
                    /* try { // try from 0011d130 to 0011d137 has its CatchHandler @ 0011d18c */
    FUN_0011c03c(param_3,pvVar4,uVar1);
    if ((local_50[0] & 1) != 0) {
      free(local_40);
    }
  }
  uVar7 = *(undefined8 *)(param_3 + 8);
  uVar6 = *(undefined8 *)param_3;
  param_3[0] = 0;
  param_3[1] = 0;
  param_3[2] = 0;
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  param_3[6] = 0;
  param_3[7] = 0;
  uVar5 = *(undefined8 *)(param_3 + 0x10);
  param_3[8] = 0;
  param_3[9] = 0;
  param_3[10] = 0;
  param_3[0xb] = 0;
  param_3[0xc] = 0;
  param_3[0xd] = 0;
  param_3[0xe] = 0;
  param_3[0xf] = 0;
  param_3[0x10] = 0;
  param_3[0x11] = 0;
  param_3[0x12] = 0;
  param_3[0x13] = 0;
  param_3[0x14] = 0;
  param_3[0x15] = 0;
  param_3[0x16] = 0;
  param_3[0x17] = 0;
  param_1[1] = uVar7;
  *param_1 = uVar6;
  param_1[2] = uVar5;
  if (*(long *)(lVar3 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0011d1a8 @ 0011d1a8

void FUN_0011d1a8(undefined8 *param_1,undefined8 param_2,undefined8 param_3,char *param_4)

{
  long lVar1;
  size_t __n;
  void *__dest;
  ulong uVar2;
  ulong local_88;
  size_t local_80;
  void *local_78;
  byte local_70 [16];
  void *local_60;
  undefined8 local_58;
  undefined8 uStack_50;
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  local_58 = param_2;
  uStack_50 = param_3;
  __n = strlen(param_4);
  if (0xffffffffffffffef < __n) {
    FUN_0011bb98(&local_88);
    goto LAB_0011d2cc;
  }
  if (__n < 0x17) {
    __dest = (void *)((ulong)&local_88 | 1);
    local_88 = CONCAT71(local_88._1_7_,(char)((int)__n << 1));
    if (__n != 0) goto LAB_0011d230;
  }
  else {
    uVar2 = __n + 0x10 & 0xfffffffffffffff0;
    __dest = (void *)FUN_0011b974(uVar2);
    local_88 = uVar2 | 1;
    local_80 = __n;
    local_78 = __dest;
LAB_0011d230:
    memcpy(__dest,param_4,__n);
  }
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 0011d244 to 0011d253 has its CatchHandler @ 0011d300 */
  FUN_0011d098(local_70,&local_58,&local_88);
                    /* try { // try from 0011d254 to 0011d25f has its CatchHandler @ 0011d2d0 */
  FUN_0011ba74(param_1,local_70);
  if ((local_70[0] & 1) != 0) {
    free(local_60);
  }
  if ((local_88 & 1) != 0) {
    free(local_78);
  }
  param_1[3] = uStack_50;
  param_1[2] = local_58;
  *param_1 = &PTR_LAB_0013c328;
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
LAB_0011d2cc:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0011d350 @ 0011d350

void FUN_0011d350(undefined4 param_1,undefined8 param_2)

{
  int iVar1;
  undefined8 uVar2;
  
  uVar2 = FUN_0011d504(0x20);
  if ((DAT_001430e0 & 1) == 0) goto LAB_0011d3b8;
  do {
                    /* try { // try from 0011d394 to 0011d39f has its CatchHandler @ 0011d3e8 */
    FUN_0011d1a8(uVar2,param_1,&DAT_001430d8,param_2);
    FUN_0011d57c(uVar2,&PTR_PTR_0013c340,&LAB_0011d31c);
LAB_0011d3b8:
    iVar1 = FUN_0011d95c(&DAT_001430e0);
    if (iVar1 != 0) {
      DAT_001430d8 = &PTR_LAB_0013c3f0;
      FUN_0011dab4(&DAT_001430e0);
    }
  } while( true );
}


// ==== FUN_0011d414 @ 0011d414

void FUN_0011d414(char *param_1)

{
  long lVar1;
  int iVar2;
  undefined8 in_x4;
  undefined8 in_x5;
  undefined8 in_x6;
  undefined8 in_x7;
  long lVar3;
  undefined8 local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined1 *local_70;
  undefined1 **ppuStack_68;
  undefined8 *puStack_60;
  undefined8 uStack_58;
  
  ppuStack_68 = &local_70;
  puStack_60 = &local_90;
  lVar1 = tpidr_el0;
  lVar3 = *(long *)(lVar1 + 0x28);
  uStack_58 = 0xffffff80ffffffe0;
  local_90 = in_x4;
  local_88 = in_x5;
  uStack_80 = in_x6;
  local_78 = in_x7;
  local_70 = (undefined1 *)register0x00000008;
  iVar2 = vsnprintf(param_1,0x400,"Unknown error %d",&local_70);
  if (*(long *)(lVar1 + 0x28) != lVar3) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar2);
  }
  return;
}


// ==== FUN_0011d4bc @ 0011d4bc

void FUN_0011d4bc(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_001157bc("vector");
}


// ==== FUN_0011d4d4 @ 0011d4d4

undefined8 FUN_0011d4d4(undefined8 *param_1)

{
  return *param_1;
}


// ==== FUN_0011d4e0 @ 0011d4e0

bool FUN_0011d4e0(ulong *param_1)

{
  return *param_1 >> 8 == 0x434c4e47432b2b;
}


// ==== FUN_0011d504 @ 0011d504

long FUN_0011d504(long param_1)

{
  void *__s;
  ulong __n;
  
  __n = param_1 + 0x8fU & 0xfffffffffffffff0;
                    /* try { // try from 0011d51c to 0011d523 has its CatchHandler @ 0011d554 */
  __s = (void *)FUN_00132b74(__n);
  if (__s == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_0011dc6c();
  }
  memset(__s,0,__n);
  return (long)__s + 0x80;
}


// ==== FUN_0011d558 @ 0011d558

void FUN_0011d558(long param_1)

{
                    /* try { // try from 0011d568 to 0011d56b has its CatchHandler @ 0011d578 */
  FUN_00132ce0(param_1 + -0x80);
  return;
}


// ==== FUN_0011d57c @ 0011d57c

void FUN_0011d57c(long param_1,undefined8 param_2,undefined8 param_3)

{
  int iVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  
  lVar2 = FUN_0011d914();
  uVar3 = FUN_0011dc58();
  *(undefined8 *)(param_1 + -0x60) = uVar3;
  uVar3 = FUN_0011dccc();
  *(undefined8 *)(param_1 + -0x58) = uVar3;
  *(undefined8 *)(param_1 + -0x70) = param_2;
  *(undefined8 *)(param_1 + -0x68) = param_3;
  FUN_0011d5fc(param_1 + -0x20);
  iVar1 = *(int *)(lVar2 + 8);
  *(undefined8 *)(param_1 + -0x78) = 1;
  *(code **)(param_1 + -0x18) = FUN_0011d618;
  *(int *)(lVar2 + 8) = iVar1 + 1;
  FUN_00133dd0(param_1 + -0x20);
  puVar4 = (undefined8 *)FUN_0011d680(param_1 + -0x80);
  *puVar4 = 0x434c4e47432b2b00;
  return;
}


// ==== FUN_0011d5fc @ 0011d5fc

void FUN_0011d5fc(undefined8 *param_1)

{
  *param_1 = 0x434c4e47432b2b00;
  return;
}


// ==== FUN_0011d618 @ 0011d618

void FUN_0011d618(int param_1,long param_2)

{
  long lVar1;
  
  if (param_1 != 1) {
    FUN_0011dce0(*(undefined8 *)(param_2 + -0x38));
                    /* WARNING: Subroutine does not return */
                    /* catch() { ... } // from try @ 0011d654 with catch @ 0011d678 */
    FUN_001326bc();
  }
  lVar1 = FUN_00133da0(0xffffffffffffffff,param_2 + -0x58);
  if (lVar1 == 1) {
    if (*(code **)(param_2 + -0x48) != (code *)0x0) {
                    /* try { // try from 0011d654 to 0011d657 has its CatchHandler @ 0011d678 */
      (**(code **)(param_2 + -0x48))(param_2 + 0x20);
    }
                    /* try { // try from 0011d65c to 0011d65f has its CatchHandler @ 0011d67c */
    FUN_00132ce0(param_2 + -0x60);
  }
  return;
}


// ==== FUN_0011d680 @ 0011d680

ulong * FUN_0011d680(long param_1)

{
  int iVar1;
  int iVar2;
  ulong *puVar3;
  long *plVar4;
  ulong *puVar5;
  ulong *puVar6;
  ulong uVar7;
  
  FUN_0011d6a4(param_1 + 0x60);
  puVar3 = (ulong *)FUN_0011dce0(*(undefined8 *)(param_1 + 0x28));
  uVar7 = *puVar3;
  plVar4 = (long *)FUN_0011d914();
  puVar6 = puVar3 + -0xc;
  if (uVar7 >> 8 == 0x434c4e47432b2b) {
    iVar2 = (int)puVar3[-5];
    iVar1 = -iVar2;
    if (-1 < iVar2) {
      iVar1 = iVar2;
    }
    puVar5 = (ulong *)*plVar4;
    *(int *)(puVar3 + -5) = iVar1 + 1;
    if (puVar5 != puVar6) {
      puVar3[-6] = (ulong)puVar5;
      *plVar4 = (long)puVar6;
    }
    puVar3 = (ulong *)puVar3[-1];
    *(int *)(plVar4 + 1) = (int)plVar4[1] + -1;
  }
  else {
    if (*plVar4 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    puVar3 = puVar3 + 4;
    *plVar4 = (long)puVar6;
  }
  return puVar3;
}


// ==== FUN_0011d6a4 @ 0011d6a4

ulong * FUN_0011d6a4(ulong *param_1)

{
  int iVar1;
  int iVar2;
  long *plVar3;
  ulong *puVar4;
  ulong *puVar5;
  ulong uVar6;
  
  uVar6 = *param_1;
                    /* try { // try from 0011d6bc to 0011d6bf has its CatchHandler @ 0011d740 */
  plVar3 = (long *)FUN_0011d914();
  puVar5 = param_1 + -0xc;
  if (uVar6 >> 8 == 0x434c4e47432b2b) {
    iVar2 = (int)param_1[-5];
    iVar1 = -iVar2;
    if (-1 < iVar2) {
      iVar1 = iVar2;
    }
    puVar4 = (ulong *)*plVar3;
    *(int *)(param_1 + -5) = iVar1 + 1;
    if (puVar4 != puVar5) {
      param_1[-6] = (ulong)puVar4;
      *plVar3 = (long)puVar5;
    }
    param_1 = (ulong *)param_1[-1];
    *(int *)(plVar3 + 1) = (int)plVar3[1] + -1;
  }
  else {
    if (*plVar3 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    param_1 = param_1 + 4;
    *plVar3 = (long)puVar5;
  }
  return param_1;
}


// ==== FUN_0011d744 @ 0011d744

void FUN_0011d744(void)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  long lVar4;
  
  plVar2 = (long *)FUN_0011d938();
  lVar3 = *plVar2;
  if (lVar3 == 0) {
    return;
  }
  if (*(ulong *)(lVar3 + 0x60) >> 8 == 0x434c4e47432b2b) {
    iVar1 = *(int *)(lVar3 + 0x38);
    if (-1 < iVar1) {
      *(int *)(lVar3 + 0x38) = iVar1 + -1;
      if (iVar1 + -1 != 0) {
        return;
      }
      *plVar2 = *(long *)(lVar3 + 0x30);
      lVar4 = lVar3;
      if (*(char *)(lVar3 + 0x60) == '\x01') {
        lVar4 = *(long *)(lVar3 + 8) + -0x80;
        FUN_00132ce0(lVar3);
      }
      lVar3 = FUN_00133da0(0xffffffffffffffff,lVar4 + 8);
      if (lVar3 != 1) {
        return;
      }
      if (*(code **)(lVar4 + 0x18) != (code *)0x0) {
                    /* try { // try from 0011d7e0 to 0011d7e3 has its CatchHandler @ 0011d820 */
        (**(code **)(lVar4 + 0x18))(lVar4 + 0x80);
      }
                    /* try { // try from 0011d7e4 to 0011d7eb has its CatchHandler @ 0011d824 */
      FUN_00132ce0(lVar4);
      return;
    }
    *(int *)(lVar3 + 0x38) = iVar1 + 1;
    if (iVar1 != -1) {
      return;
    }
    lVar3 = *(long *)(lVar3 + 0x30);
  }
  else {
    FUN_001341e4();
    lVar3 = 0;
  }
  *plVar2 = lVar3;
  return;
}


// ==== FUN_0011d828 @ 0011d828

void FUN_0011d828(void)

{
  int iVar1;
  int iVar2;
  long *plVar3;
  ulong uVar4;
  long lVar5;
  ulong *puVar6;
  long lVar7;
  ulong uVar8;
  
  plVar3 = (long *)FUN_0011d914();
  lVar7 = *plVar3;
  if (lVar7 != 0) {
    puVar6 = (ulong *)(lVar7 + 0x60);
    uVar4 = *puVar6;
    if ((uVar4 & 0xffffffffffffff00) == 0x434c4e47432b2b00) {
      lVar5 = plVar3[1];
      *(int *)(lVar7 + 0x38) = -*(int *)(lVar7 + 0x38);
      *(int *)(plVar3 + 1) = (int)lVar5 + 1;
    }
    else {
      *plVar3 = 0;
    }
    FUN_00133dd0(puVar6);
    uVar8 = *puVar6;
                    /* try { // try from 0011d8a0 to 0011d8a3 has its CatchHandler @ 0011d910 */
    plVar3 = (long *)FUN_0011d914();
    if ((uVar8 & 0xffffffffffffff00) == 0x434c4e47432b2b00) {
      iVar2 = *(int *)(lVar7 + 0x38);
      iVar1 = -iVar2;
      if (-1 < iVar2) {
        iVar1 = iVar2;
      }
      lVar5 = *plVar3;
      *(int *)(lVar7 + 0x38) = iVar1 + 1;
      if (lVar5 != lVar7) {
        *(long *)(lVar7 + 0x30) = lVar5;
        *plVar3 = lVar7;
      }
      *(int *)(plVar3 + 1) = (int)plVar3[1] + -1;
    }
    else {
      if (*plVar3 != 0) goto LAB_0011d84c;
      *plVar3 = lVar7;
    }
    if ((uVar4 & 0xffffffffffffff00) == 0x434c4e47432b2b00) {
      FUN_0011dce0(*(undefined8 *)(lVar7 + 0x28));
                    /* WARNING: Subroutine does not return */
                    /* catch() { ... } // from try @ 0011d8a0 with catch @ 0011d910 */
      FUN_001326bc();
    }
  }
LAB_0011d84c:
                    /* WARNING: Subroutine does not return */
  FUN_0011dc6c();
}


// ==== FUN_0011d914 @ 0011d914

void FUN_0011d914(void)

{
  FUN_00133944(&DAT_00142e10);
  return;
}


// ==== FUN_0011d938 @ 0011d938

void FUN_0011d938(void)

{
  FUN_00133944(&DAT_00142e10);
  return;
}


// ==== FUN_0011d95c @ 0011d95c

undefined8 FUN_0011d95c(char *param_1)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  long lVar4;
  int unaff_w20;
  undefined8 uVar5;
  
  if (*param_1 == '\0') {
    iVar3 = pthread_mutex_lock((pthread_mutex_t *)&DAT_001430e8);
    if (iVar3 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011db64("%s failed to acquire mutex","__cxa_guard_acquire");
    }
    bVar1 = param_1[1];
    if ((bVar1 >> 1 & 1) != 0) {
      iVar3 = *(int *)(param_1 + 4);
                    /* try { // try from 0011d9a4 to 0011d9ab has its CatchHandler @ 0011da78 */
      lVar4 = syscall(0xb2);
      unaff_w20 = (int)lVar4;
      if (iVar3 == unaff_w20) {
                    /* try { // try from 0011da6c to 0011da77 has its CatchHandler @ 0011da78 */
                    /* WARNING: Subroutine does not return */
        FUN_0011db64("__cxa_guard_acquire detected recursive initialization");
      }
    }
    while (bVar2 = param_1[1], (bVar2 >> 1 & 1) != 0) {
      param_1[1] = bVar2 | 4;
                    /* try { // try from 0011d9d8 to 0011d9e3 has its CatchHandler @ 0011da80 */
      pthread_cond_wait((pthread_cond_t *)&DAT_00143110,(pthread_mutex_t *)&DAT_001430e8);
    }
    if (bVar2 == 1) {
      uVar5 = 0;
    }
    else {
      if ((bVar1 >> 1 & 1) == 0) {
                    /* try { // try from 0011d9fc to 0011da03 has its CatchHandler @ 0011da78 */
        lVar4 = syscall(0xb2);
        unaff_w20 = (int)lVar4;
      }
      uVar5 = 1;
      *(int *)(param_1 + 4) = unaff_w20;
      param_1[1] = '\x02';
    }
                    /* try { // try from 0011da18 to 0011da23 has its CatchHandler @ 0011da7c */
    iVar3 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_001430e8);
    if (iVar3 != 0) {
                    /* try { // try from 0011da58 to 0011da6b has its CatchHandler @ 0011da7c */
                    /* WARNING: Subroutine does not return */
      FUN_0011db64("%s failed to release mutex","__cxa_guard_acquire");
    }
  }
  else {
    uVar5 = 0;
  }
  return uVar5;
}


// ==== FUN_0011dab4 @ 0011dab4

void FUN_0011dab4(undefined1 *param_1)

{
  byte bVar1;
  int iVar2;
  
  *param_1 = 1;
  iVar2 = pthread_mutex_lock((pthread_mutex_t *)&DAT_001430e8);
  if (iVar2 != 0) {
                    /* WARNING: Subroutine does not return */
    FUN_0011db64("%s failed to acquire mutex","__cxa_guard_release");
  }
  bVar1 = param_1[1];
  param_1[1] = 1;
                    /* try { // try from 0011daec to 0011daf7 has its CatchHandler @ 0011db60 */
  iVar2 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_001430e8);
  if (iVar2 != 0) {
                    /* try { // try from 0011db38 to 0011db4b has its CatchHandler @ 0011db60 */
                    /* WARNING: Subroutine does not return */
    FUN_0011db64("%s failed to release mutex","__cxa_guard_release");
  }
  if (((bVar1 >> 2 & 1) != 0) &&
     (iVar2 = pthread_cond_broadcast((pthread_cond_t *)&DAT_00143110), iVar2 != 0)) {
                    /* WARNING: Subroutine does not return */
    FUN_0011db64("%s failed to broadcast","__cxa_guard_release");
  }
  return;
}


// ==== FUN_0011db64 @ 0011db64

void FUN_0011db64(char *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  undefined1 auStack_120 [8];
  undefined8 local_118;
  undefined8 uStack_110;
  undefined8 local_108;
  undefined8 uStack_100;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 local_e8;
  undefined1 *local_e0;
  undefined1 **ppuStack_d8;
  undefined1 *puStack_d0;
  undefined8 uStack_c8;
  char *local_98;
  undefined1 *local_90;
  undefined1 **ppuStack_88;
  undefined1 *puStack_80;
  undefined8 uStack_78;
  
  uStack_78 = 0xffffff80ffffffc8;
  local_118 = param_2;
  uStack_110 = param_3;
  local_108 = param_4;
  uStack_100 = param_5;
  local_f8 = param_6;
  uStack_f0 = param_7;
  local_e8 = param_8;
  local_90 = (undefined1 *)register0x00000008;
  ppuStack_88 = &local_e0;
  puStack_80 = auStack_120;
  vfprintf((FILE *)0x144348,param_1,&local_90);
  fputc(10,(FILE *)0x144348);
  uStack_c8 = 0xffffff80ffffffc8;
  local_e0 = (undefined1 *)register0x00000008;
  ppuStack_d8 = &local_e0;
  puStack_d0 = auStack_120;
  vasprintf(&local_98,param_1,&local_e0);
  android_set_abort_message(local_98);
  openlog("libc++abi",0,0);
  syslog(2,"%s",local_98);
  closelog();
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_0011dc58 @ 0011dc58

undefined * FUN_0011dc58(void)

{
  return PTR_FUN_00142e38;
}


// ==== FUN_0011dc6c @ 0011dc6c

void FUN_0011dc6c(void)

{
  long *plVar1;
  ulong uVar2;
  long unaff_x19;
  
                    /* try { // try from 0011dc74 to 0011dc77 has its CatchHandler @ 0011dcac */
  plVar1 = (long *)FUN_0011d938();
  if ((plVar1 != (long *)0x0) && (unaff_x19 = *plVar1, unaff_x19 != 0)) goto LAB_0011dc94;
  do {
    FUN_0011dce0(PTR_FUN_00142e30);
LAB_0011dc94:
                    /* try { // try from 0011dc98 to 0011dc9b has its CatchHandler @ 0011dca8 */
    uVar2 = FUN_0011d4e0(unaff_x19 + 0x60);
  } while ((uVar2 & 1) == 0);
  FUN_0011dce0(*(undefined8 *)(unaff_x19 + 0x28));
                    /* WARNING: Subroutine does not return */
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0011dc98 with catch @ 0011dca8
                        */
  FUN_00114fb8();
}


// ==== FUN_0011dcb0 @ 0011dcb0

void FUN_0011dcb0(code *param_1)

{
  (*param_1)();
                    /* WARNING: Subroutine does not return */
  FUN_0011db64("unexpected_handler unexpectedly returned");
}


// ==== FUN_0011dccc @ 0011dccc

undefined * FUN_0011dccc(void)

{
  return PTR_FUN_00142e30;
}


// ==== FUN_0011dce0 @ 0011dce0

void FUN_0011dce0(code *param_1)

{
                    /* try { // try from 0011dcf0 to 0011dcff has its CatchHandler @ 0011dd00 */
  (*param_1)();
                    /* WARNING: Subroutine does not return */
  FUN_0011db64("terminate_handler unexpectedly returned");
}


// ==== FUN_0011dd24 @ 0011dd24

undefined8 FUN_0011dd24(void)

{
  return DAT_00143140;
}


// ==== FUN_0011dd38 @ 0011dd38

void FUN_0011dd38(void)

{
  undefined *puVar1;
  long *plVar2;
  ulong uVar3;
  long lVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  long lVar7;
  undefined8 local_440;
  undefined1 auStack_434 [1024];
  int local_34;
  long *local_18;
  
  plVar2 = (long *)FUN_0011d938();
  if ((plVar2 == (long *)0x0) || (lVar7 = *plVar2, lVar7 == 0)) {
                    /* WARNING: Subroutine does not return */
    FUN_0011db64("terminating");
  }
  uVar3 = FUN_0011d4e0(lVar7 + 0x60);
  if ((uVar3 & 1) == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_0011db64("terminating with %s foreign exception",PTR_s_uncaught_00142e40);
  }
  lVar4 = FUN_0011d4d4(lVar7 + 0x60);
  if (lVar4 == 0x434c4e47432b2b01) {
    local_18 = *(long **)(lVar7 + 8);
  }
  else {
    local_18 = (long *)(lVar7 + 0x80);
  }
  lVar7 = *(long *)(lVar7 + 0x10);
  local_440 = 0x400;
  uVar5 = FUN_0011de7c(*(undefined8 *)(lVar7 + 8),auStack_434,&local_440,&local_34);
  if (local_34 != 0) {
    uVar5 = *(undefined8 *)(lVar7 + 8);
  }
  uVar3 = FUN_00132e84(&PTR_PTR_0013e630,lVar7,&local_18);
  puVar1 = PTR_s_uncaught_00142e40;
  if ((uVar3 & 1) == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_0011db64("terminating with %s exception of type %s",PTR_s_uncaught_00142e40,uVar5);
  }
  uVar6 = (**(code **)(*local_18 + 0x10))();
                    /* WARNING: Subroutine does not return */
  FUN_0011db64("terminating with %s exception of type %s: %s",puVar1,uVar5,uVar6);
}


// ==== FUN_0011de5c @ 0011de5c

void FUN_0011de5c(void)

{
  PTR_s_uncaught_00142e40 = s_unexpected_0010a7f7;
                    /* WARNING: Subroutine does not return */
  FUN_0011dc6c();
}


// ==== FUN_0011de7c @ 0011de7c

void * FUN_0011de7c(byte *param_1,void *param_2,ulong *param_3,undefined4 *param_4)

{
  byte *pbVar1;
  long lVar2;
  long *plVar3;
  size_t sVar4;
  long *plVar5;
  long *plVar6;
  undefined4 uVar7;
  long lVar8;
  ulong uVar9;
  byte *pbVar10;
  byte *pbVar11;
  byte *pbVar12;
  byte *pbVar13;
  void *pvVar14;
  ulong uVar15;
  void *local_13e8;
  ulong local_13e0;
  size_t local_13d8;
  undefined8 local_13d0;
  long local_13c8;
  byte *local_13c0;
  byte *local_13b8;
  undefined8 *local_13b0;
  undefined8 *puStack_13a8;
  undefined8 **local_13a0;
  undefined8 local_1398;
  undefined8 uStack_1390;
  undefined8 local_1388;
  undefined8 uStack_1380;
  undefined8 local_1378;
  undefined8 uStack_1370;
  undefined8 local_1368;
  undefined8 uStack_1360;
  undefined8 local_1358;
  undefined8 uStack_1350;
  undefined8 local_1348;
  undefined8 uStack_1340;
  undefined8 local_1338;
  undefined8 uStack_1330;
  undefined8 local_1328;
  undefined8 uStack_1320;
  undefined8 local_1318;
  undefined8 uStack_1310;
  undefined8 local_1308;
  undefined8 uStack_1300;
  undefined8 local_12f8;
  undefined8 uStack_12f0;
  undefined8 local_12e8;
  undefined8 uStack_12e0;
  undefined8 local_12d8;
  undefined8 uStack_12d0;
  undefined8 local_12c8;
  undefined8 uStack_12c0;
  undefined8 local_12b8;
  undefined8 uStack_12b0;
  undefined8 local_12a8;
  undefined8 uStack_12a0;
  undefined8 *local_1298;
  undefined8 *puStack_1290;
  undefined8 **local_1288;
  undefined8 local_1280;
  undefined8 uStack_1278;
  undefined8 uStack_1270;
  undefined8 uStack_1268;
  undefined8 local_1260;
  undefined8 uStack_1258;
  undefined8 uStack_1250;
  undefined8 uStack_1248;
  undefined8 local_1240;
  undefined8 uStack_1238;
  undefined8 uStack_1230;
  undefined8 uStack_1228;
  undefined8 local_1220;
  undefined8 uStack_1218;
  undefined8 uStack_1210;
  undefined8 uStack_1208;
  undefined8 local_1200;
  undefined8 uStack_11f8;
  undefined8 uStack_11f0;
  undefined8 uStack_11e8;
  undefined8 local_11e0;
  undefined8 uStack_11d8;
  undefined8 uStack_11d0;
  undefined8 uStack_11c8;
  undefined8 local_11c0;
  undefined8 uStack_11b8;
  undefined8 uStack_11b0;
  undefined8 uStack_11a8;
  undefined8 local_11a0;
  undefined8 uStack_1198;
  undefined8 uStack_1190;
  undefined8 uStack_1188;
  undefined8 *local_1180;
  undefined8 *local_1178;
  undefined8 **local_1170;
  undefined8 local_1168;
  undefined8 uStack_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined8 local_1148;
  undefined8 uStack_1140;
  undefined8 local_1138;
  undefined8 uStack_1130;
  undefined8 *local_1128;
  undefined8 *local_1120;
  undefined8 **local_1118;
  undefined8 local_1110;
  undefined8 uStack_1108;
  undefined8 uStack_1100;
  undefined8 uStack_10f8;
  undefined8 *local_10f0;
  undefined8 *local_10e8;
  undefined2 *local_10e0;
  undefined8 local_10d8;
  undefined8 uStack_10d0;
  undefined8 local_10c8;
  undefined8 uStack_10c0;
  undefined2 local_10b8 [4];
  undefined8 local_10b0;
  undefined8 local_10a8;
  undefined4 local_10a0;
  long local_1090;
  undefined8 uStack_1088;
  long *local_90;
  long local_78;
  
  lVar2 = tpidr_el0;
  local_78 = *(long *)(lVar2 + 0x28);
  if ((param_1 == (byte *)0x0) || ((param_2 != (void *)0x0 && (param_3 == (ulong *)0x0)))) {
    if (param_4 == (undefined4 *)0x0) {
      pvVar14 = (void *)0x0;
    }
    else {
      pvVar14 = (void *)0x0;
      *param_4 = 0xfffffffd;
    }
    goto LAB_0011e1d0;
  }
  sVar4 = strlen((char *)param_1);
  local_13b8 = param_1 + sVar4;
  local_13a0 = &local_1298;
  local_1170 = &local_1128;
  uStack_12b0 = 0;
  local_12b8 = 0;
  uStack_12a0 = 0;
  local_12a8 = 0;
  local_1288 = &local_1180;
  uStack_1390 = 0;
  local_1398 = 0;
  uStack_1380 = 0;
  local_1388 = 0;
  uStack_1370 = 0;
  local_1378 = 0;
  uStack_1360 = 0;
  local_1368 = 0;
  uStack_1130 = 0;
  local_1138 = 0;
  local_1118 = &local_10f0;
  uStack_1350 = 0;
  local_1358 = 0;
  uStack_1340 = 0;
  local_1348 = 0;
  uStack_1330 = 0;
  local_1338 = 0;
  uStack_1320 = 0;
  local_1328 = 0;
  uStack_10c0 = 0;
  local_10c8 = 0;
  uStack_1310 = 0;
  local_1318 = 0;
  uStack_1300 = 0;
  local_1308 = 0;
  uStack_12f0 = 0;
  local_12f8 = 0;
  uStack_12e0 = 0;
  local_12e8 = 0;
  uStack_12d0 = 0;
  local_12d8 = 0;
  uStack_12c0 = 0;
  local_12c8 = 0;
  uStack_1278 = 0;
  local_1280 = 0;
  uStack_1268 = 0;
  uStack_1270 = 0;
  uStack_1258 = 0;
  local_1260 = 0;
  uStack_1248 = 0;
  uStack_1250 = 0;
  uStack_1238 = 0;
  local_1240 = 0;
  uStack_1228 = 0;
  uStack_1230 = 0;
  uStack_1218 = 0;
  local_1220 = 0;
  uStack_1208 = 0;
  uStack_1210 = 0;
  uStack_11f8 = 0;
  local_1200 = 0;
  uStack_11e8 = 0;
  uStack_11f0 = 0;
  uStack_11d8 = 0;
  local_11e0 = 0;
  uStack_11c8 = 0;
  uStack_11d0 = 0;
  uStack_11b8 = 0;
  local_11c0 = 0;
  uStack_11a8 = 0;
  uStack_11b0 = 0;
  uStack_1198 = 0;
  local_11a0 = 0;
  uStack_1188 = 0;
  uStack_1190 = 0;
  uStack_1140 = 0;
  local_1148 = 0;
  uStack_1150 = 0;
  local_1158 = 0;
  local_10e0 = local_10b8;
  uStack_1160 = 0;
  local_1168 = 0;
  uStack_1108 = 0;
  local_1110 = 0;
  uStack_10f8 = 0;
  uStack_1100 = 0;
  uStack_10d0 = 0;
  local_10d8 = 0;
  uStack_1088 = 0;
  local_1090 = 0;
  local_10b8[0] = 1;
  local_10b0 = 0xffffffffffffffff;
  local_10a0 = 0;
  local_10a8 = 0;
  local_13e8 = (void *)0x0;
  local_13e0 = 0;
  local_13d8 = 0;
  local_13d0 = 0xffffffffffffffff;
  local_13b0 = &local_1398;
  puStack_13a8 = &local_1398;
  local_1298 = &local_1280;
  puStack_1290 = &local_1280;
  local_1180 = &local_1168;
  local_1178 = &local_1168;
  local_1128 = &local_1110;
  local_1120 = &local_1110;
  local_10f0 = &local_10d8;
  local_10e8 = &local_10d8;
  local_90 = &local_1090;
  if ((sVar4 < 2) || (*param_1 != 0x5f)) {
LAB_0011e11c:
    local_13c0 = param_1;
    plVar6 = (long *)FUN_0011ef00(&local_13c0);
    if (local_13b8 == local_13c0) {
LAB_0011e3f4:
      if (plVar6 != (long *)0x0) goto LAB_0011e3fc;
    }
LAB_0011e130:
    uVar7 = 0xfffffffe;
    pvVar14 = (void *)0x0;
    uVar15 = local_13e0;
  }
  else {
    if (param_1[1] != 0x5a) {
      if ((sVar4 < 3) || (param_1[1] != 0x5f)) goto LAB_0011e11c;
      if (param_1[2] == 0x5a) {
        lVar8 = 3;
        goto LAB_0011e074;
      }
      if (sVar4 < 4) goto LAB_0011e11c;
      if ((param_1[2] == 0x5f) && (param_1[3] == 0x5a)) {
        lVar8 = 4;
      }
      else {
        if ((((sVar4 < 5) || (param_1[2] != 0x5f)) || (param_1[3] != 0x5f)) || (param_1[4] != 0x5a))
        goto LAB_0011e11c;
        lVar8 = 5;
      }
      local_13c0 = param_1 + lVar8;
      local_13c8 = FUN_0011e5c4(&local_13c0);
      if (((((local_13c8 == 0) || ((ulong)((long)local_13b8 - (long)local_13c0) < 0xd)) ||
           ((*local_13c0 != 0x5f || ((local_13c0[1] != 0x62 || (local_13c0[2] != 0x6c)))))) ||
          ((local_13c0[3] != 0x6f ||
           ((((local_13c0[4] != 99 || (local_13c0[5] != 0x6b)) || (local_13c0[6] != 0x5f)) ||
            ((local_13c0[7] != 0x69 || (local_13c0[8] != 0x6e)))))))) ||
         (((local_13c0[9] != 0x76 || ((local_13c0[10] != 0x6f || (local_13c0[0xb] != 0x6b)))) ||
          (local_13c0[0xc] != 0x65)))) goto LAB_0011e130;
      pbVar1 = local_13c0 + 0xd;
      if (pbVar1 != local_13b8) {
        pbVar12 = pbVar1;
        if (*pbVar1 == 0x5f) {
          pbVar12 = local_13c0 + 0xe;
        }
        local_13c0 = pbVar12;
        pbVar12 = local_13b8;
        if (local_13b8 == local_13c0) {
          pbVar10 = (byte *)0x0;
          pbVar13 = (byte *)0x0;
        }
        else {
          pbVar11 = local_13c0;
          if (*local_13c0 - 0x3a < 0xfffffff6) {
            pbVar10 = (byte *)0x0;
            pbVar12 = local_13c0;
            pbVar13 = (byte *)0x0;
          }
          else {
            do {
              pbVar11 = pbVar11 + 1;
              pbVar10 = local_13c0;
              if (pbVar11 == local_13b8) {
                pbVar13 = local_13b8;
                local_13c0 = pbVar11;
                goto LAB_0011e3b8;
              }
            } while (0xfffffff5 < *pbVar11 - 0x3a);
            pbVar12 = pbVar11;
            pbVar13 = pbVar11;
            local_13c0 = pbVar11;
          }
        }
LAB_0011e3b8:
        if ((*pbVar1 == 0x5f) && (pbVar10 == pbVar13)) goto LAB_0011e130;
        pbVar1 = local_13c0;
        if (local_13b8 != pbVar12) {
          if (*pbVar12 != 0x2e) goto LAB_0011e130;
          local_13c0 = local_13b8;
          pbVar1 = local_13c0;
        }
      }
      local_13c0 = pbVar1;
      plVar6 = (long *)FUN_0011ee58(&local_13c0,"invocation function for block in ",&local_13c8);
      goto LAB_0011e3f4;
    }
    lVar8 = 2;
LAB_0011e074:
    local_13c0 = param_1 + lVar8;
                    /* try { // try from 0011e07c to 0011e457 has its CatchHandler @ 0011e4e0 */
    plVar5 = (long *)FUN_0011e5c4(&local_13c0);
    plVar3 = local_90;
    pbVar12 = local_13b8;
    pbVar1 = local_13c0;
    if (plVar5 == (long *)0x0) goto LAB_0011e130;
    plVar6 = plVar5;
    if (local_13b8 != local_13c0) {
      if (*local_13c0 != 0x2e) goto LAB_0011e130;
      lVar8 = local_90[1];
      if (lVar8 - 0xfc0U < 0xfffffffffffff00f || lVar8 == -0x31) {
        plVar6 = malloc(0x1000);
        if (plVar6 == (long *)0x0) goto LAB_0011e4d8;
        lVar8 = 0;
        *plVar6 = (long)plVar3;
        plVar6[1] = 0;
        local_90 = plVar6;
      }
      local_90[1] = lVar8 + 0x30;
      plVar6 = (long *)((long)local_90 + lVar8 + 0x10);
      *plVar6 = (long)&PTR_LAB_0013dea0;
      *(undefined4 *)((long)local_90 + lVar8 + 0x18) = 0x1010101;
      *(long **)((long)local_90 + lVar8 + 0x20) = plVar5;
      *(byte **)((long)local_90 + lVar8 + 0x28) = pbVar1;
      *(byte **)((long)local_90 + lVar8 + 0x30) = pbVar12;
      local_13c0 = local_13b8;
    }
LAB_0011e3fc:
    if (param_2 == (void *)0x0) {
      uVar15 = 0x400;
      param_2 = malloc(0x400);
      if (param_2 == (void *)0x0) {
        uVar7 = 0xffffffff;
        pvVar14 = (void *)0x0;
        uVar15 = local_13e0;
        goto joined_r0x0011e4c4;
      }
    }
    else {
      uVar15 = *param_3;
    }
    local_13e0 = 0;
    local_13e8 = param_2;
    local_13d8 = uVar15;
    (**(code **)(*plVar6 + 0x20))(plVar6,&local_13e8);
    if (*(char *)((long)plVar6 + 9) != '\x01') {
      (**(code **)(*plVar6 + 0x28))(plVar6,&local_13e8);
    }
    uVar15 = local_13e0 + 1;
    if (local_13d8 <= uVar15) {
      uVar9 = local_13d8 << 1;
      local_13d8 = uVar15;
      if (uVar15 <= uVar9) {
        local_13d8 = uVar9;
      }
      local_13e8 = realloc(local_13e8,local_13d8);
      if (local_13e8 == (void *)0x0) {
LAB_0011e4d8:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      uVar15 = local_13e0 + 1;
    }
    *(undefined1 *)((long)local_13e8 + local_13e0) = 0;
    if (param_3 != (ulong *)0x0) {
      *param_3 = uVar15;
    }
    uVar7 = 0;
    pvVar14 = local_13e8;
  }
joined_r0x0011e4c4:
  local_13e0 = uVar15;
  plVar6 = local_90;
  if (param_4 != (undefined4 *)0x0) {
    *param_4 = uVar7;
  }
  while (local_90 = plVar6, local_90 != (long *)0x0) {
    while( true ) {
      plVar6 = (long *)*local_90;
      if (&local_1090 == local_90) break;
      plVar6 = local_90;
      local_90 = (long *)*local_90;
      free(plVar6);
      if (local_90 == (long *)0x0) goto LAB_0011e170;
    }
  }
LAB_0011e170:
  local_1090 = 0;
  uStack_1088 = 0;
  local_90 = &local_1090;
  if (local_10f0 != &local_10d8) {
    free(local_10f0);
  }
  if (local_1128 != &local_1110) {
    free(local_1128);
  }
  if (local_1180 != &local_1168) {
    free(local_1180);
  }
  if (local_1298 != &local_1280) {
    free(local_1298);
  }
  if (local_13b0 != &local_1398) {
    free(local_13b0);
  }
LAB_0011e1d0:
  if (*(long *)(lVar2 + 0x28) != local_78) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return pvVar14;
}


// ==== FUN_0011e4f4 @ 0011e4f4

void FUN_0011e4f4(long param_1)

{
  undefined8 *puVar1;
  undefined8 *__ptr;
  undefined8 *puVar2;
  
  puVar1 = (undefined8 *)(param_1 + 0x330);
  __ptr = *(undefined8 **)(param_1 + 0x1330);
  while (__ptr != (undefined8 *)0x0) {
    while( true ) {
      puVar2 = (undefined8 *)*__ptr;
      *(undefined8 **)(param_1 + 0x1330) = puVar2;
      if (puVar1 != __ptr) break;
      __ptr = puVar2;
      if (puVar2 == (undefined8 *)0x0) goto LAB_0011e53c;
    }
    free(__ptr);
    __ptr = *(undefined8 **)(param_1 + 0x1330);
  }
LAB_0011e53c:
  *puVar1 = 0;
  *(undefined8 *)(param_1 + 0x338) = 0;
  *(undefined8 **)(param_1 + 0x1330) = puVar1;
  if (*(void **)(param_1 + 0x2d0) != (void *)(param_1 + 0x2e8)) {
    free(*(void **)(param_1 + 0x2d0));
  }
  if (*(void **)(param_1 + 0x298) != (void *)(param_1 + 0x2b0)) {
    free(*(void **)(param_1 + 0x298));
  }
  if (*(void **)(param_1 + 0x240) != (void *)(param_1 + 600)) {
    free(*(void **)(param_1 + 0x240));
  }
  if (*(void **)(param_1 + 0x128) != (void *)(param_1 + 0x140)) {
    free(*(void **)(param_1 + 0x128));
  }
  if (*(void **)(param_1 + 0x10) == (void *)(param_1 + 0x28)) {
    return;
  }
  free(*(void **)(param_1 + 0x10));
  return;
}


// ==== FUN_0011e5c4 @ 0011e5c4

void FUN_0011e5c4(long *param_1)

{
  byte *pbVar1;
  char cVar2;
  byte bVar3;
  long lVar4;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  bool bVar18;
  long lVar19;
  ulong uVar20;
  undefined8 *puVar21;
  long lVar22;
  char *pcVar23;
  uint uVar24;
  char *pcVar25;
  byte *pbVar26;
  byte *pbVar27;
  undefined8 *puVar28;
  long lVar29;
  long *plVar30;
  ulong uVar31;
  ulong uVar32;
  void *pvVar33;
  undefined1 auVar34 [16];
  long local_98;
  undefined1 local_90 [16];
  undefined8 local_80;
  undefined8 *local_78;
  undefined8 local_70;
  undefined1 local_68 [8];
  ulong local_60;
  long local_58;
  
  lVar4 = tpidr_el0;
  local_58 = *(long *)(lVar4 + 0x28);
  pcVar23 = (char *)*param_1;
  pcVar25 = (char *)param_1[1];
  if ((pcVar25 == pcVar23) || ((cVar2 = *pcVar23, cVar2 != 'T' && (cVar2 != 'G')))) {
    local_70 = (local_70 >> 0x10 & 0xffff) << 0x10;
    local_68[0] = 0;
    local_60 = param_1[0x5b] - param_1[0x5a] >> 3;
    puVar21 = (undefined8 *)FUN_0011feb0(param_1,&local_70);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    auVar15._8_8_ = local_90._8_8_;
    auVar15._0_8_ = local_90._0_8_;
    auVar14._8_8_ = local_90._8_8_;
    auVar14._0_8_ = local_90._0_8_;
    auVar13._8_8_ = local_90._8_8_;
    auVar13._0_8_ = local_90._0_8_;
    auVar12._8_8_ = local_90._8_8_;
    auVar12._0_8_ = local_90._0_8_;
    auVar11._8_8_ = local_90._8_8_;
    auVar11._0_8_ = local_90._0_8_;
    auVar10._8_8_ = local_90._8_8_;
    auVar10._0_8_ = local_90._0_8_;
    auVar9._8_8_ = local_90._8_8_;
    auVar9._0_8_ = local_90._0_8_;
    auVar8._8_8_ = local_90._8_8_;
    auVar8._0_8_ = local_90._0_8_;
    auVar7._8_8_ = local_90._8_8_;
    auVar7._0_8_ = local_90._0_8_;
    auVar6._8_8_ = local_90._8_8_;
    auVar6._0_8_ = local_90._0_8_;
    auVar5._8_8_ = local_90._8_8_;
    auVar5._0_8_ = local_90._0_8_;
    auVar34._8_8_ = local_90._8_8_;
    auVar34._0_8_ = local_90._0_8_;
    local_78 = puVar21;
    if (puVar21 == (undefined8 *)0x0) goto LAB_0011e9ac;
    lVar19 = param_1[0x5a];
    uVar20 = param_1[0x5b] - lVar19 >> 3;
    if (uVar20 <= local_60) {
LAB_0011e79c:
      param_1[0x5b] = lVar19 + local_60 * 8;
LAB_0011e7a4:
      pbVar27 = (byte *)*param_1;
      pbVar1 = (byte *)param_1[1];
      if (pbVar1 != pbVar27) {
        uVar24 = *pbVar27 - 0x2e;
        if ((0x31 < uVar24) || ((1L << ((ulong)uVar24 & 0x3f) & 0x2000000800001U) == 0)) {
          local_80 = 0;
          if (((((0xc < (ulong)((long)pbVar1 - (long)pbVar27)) &&
                (((local_90 = auVar34, *pbVar27 == 0x55 && (local_90 = auVar5, pbVar27[1] == 0x61))
                 && (local_90 = auVar6, pbVar27[2] == 0x39)))) &&
               (((local_90 = auVar7, pbVar27[3] == 0x65 && (local_90 = auVar8, pbVar27[4] == 0x6e))
                && (local_90 = auVar9, pbVar27[5] == 0x61)))) &&
              ((local_90 = auVar10, pbVar27[6] == 0x62 && (local_90 = auVar11, pbVar27[7] == 0x6c)))
              ) && (((local_90 = auVar12, pbVar27[8] == 0x65 &&
                     (((local_90 = auVar13, pbVar27[9] == 0x5f &&
                       (local_90 = auVar14, pbVar27[10] == 0x69)) &&
                      (local_90 = auVar15, pbVar27[0xb] == 0x66)))) &&
                    (local_90 = auVar16, pbVar27[0xc] == 0x49)))) {
            lVar22 = param_1[3];
            pbVar27 = pbVar27 + 0xd;
            lVar19 = param_1[2];
            *param_1 = (long)pbVar27;
            if (pbVar27 == pbVar1) goto LAB_0011e8b0;
            while (*pbVar27 != 0x45) {
LAB_0011e8b0:
              do {
                local_90._0_8_ = FUN_00120934(param_1);
                auVar16._8_8_ = local_90._8_8_;
                auVar16._0_8_ = local_90._0_8_;
                puVar21 = (undefined8 *)0x0;
                if (local_90._0_8_ == 0) goto LAB_0011e9ac;
                FUN_00120b24(param_1 + 2,local_90);
                pbVar27 = (byte *)*param_1;
              } while (pbVar27 == (byte *)param_1[1]);
            }
            lVar19 = (lVar22 - lVar19 >> 3) * 8;
            *param_1 = (long)(pbVar27 + 1);
            local_90 = FUN_0012a7b8(param_1,param_1[2] + lVar19,param_1[3]);
            param_1[3] = param_1[2] + lVar19;
            local_80 = FUN_00120be8(param_1,local_90);
          }
          local_98 = 0;
          if (((char)local_70 == '\0') && (local_70._1_1_ != '\0')) {
            local_98 = FUN_0011ef00(param_1);
            puVar21 = (undefined8 *)0x0;
            auVar16 = local_90;
            if (local_98 == 0) goto LAB_0011e9ac;
          }
          pcVar23 = (char *)*param_1;
          if ((pcVar23 == (char *)param_1[1]) || (*pcVar23 != 'v')) {
            lVar19 = param_1[2];
            lVar22 = param_1[3];
            do {
              lVar29 = FUN_0011ef00(param_1);
              auVar16._8_8_ = local_90._8_8_;
              auVar16._0_8_ = lVar29;
              puVar21 = (undefined8 *)0x0;
              if (lVar29 == 0) goto LAB_0011e9ac;
              local_90._0_8_ = lVar29;
              FUN_00120b24(param_1 + 2,local_90);
              auVar17._8_8_ = local_90._8_8_;
              auVar17._0_8_ = local_90._0_8_;
            } while (((byte *)param_1[1] != (byte *)*param_1) &&
                    ((uVar24 = *(byte *)*param_1 - 0x2e, 0x31 < uVar24 ||
                     (local_90 = auVar17, (1L << ((ulong)uVar24 & 0x3f) & 0x2000000800001U) == 0))))
            ;
            lVar19 = (lVar22 - lVar19 >> 3) * 8;
            local_90 = FUN_0012a7b8(param_1,param_1[2] + lVar19,param_1[3]);
            param_1[3] = param_1[2] + lVar19;
          }
          else {
            local_90 = ZEXT816(0);
            *param_1 = (long)(pcVar23 + 1);
          }
          puVar21 = (undefined8 *)
                    FUN_00120c78(param_1,&local_98,&local_78,local_90,&local_80,(ulong)&local_70 | 4
                                 ,local_68);
          auVar16 = local_90;
        }
      }
      goto LAB_0011e9ac;
    }
    puVar28 = (undefined8 *)param_1[0x53];
    if ((puVar28 != (undefined8 *)param_1[0x54]) &&
       (plVar30 = (long *)*puVar28, plVar30 != (long *)0x0)) {
      lVar29 = *(long *)(lVar19 + local_60 * 8);
      lVar22 = *plVar30;
      uVar31 = *(ulong *)(lVar29 + 0x10);
      if (uVar31 < (ulong)(plVar30[1] - lVar22 >> 3)) {
        uVar32 = local_60;
        do {
          uVar32 = uVar32 + 1;
          *(undefined8 *)(lVar29 + 0x18) = *(undefined8 *)(lVar22 + uVar31 * 8);
          if (uVar20 == uVar32) goto LAB_0011e79c;
          plVar30 = (long *)*puVar28;
          if (plVar30 == (long *)0x0) break;
          lVar29 = *(long *)(lVar19 + uVar32 * 8);
          lVar22 = *plVar30;
          uVar31 = *(ulong *)(lVar29 + 0x10);
        } while (uVar31 < (ulong)(plVar30[1] - lVar22 >> 3));
        if (uVar20 <= uVar32) goto LAB_0011e7a4;
      }
    }
    goto LAB_0011e9a8;
  }
  if (pcVar25 == pcVar23) goto LAB_0011e9a8;
  if (cVar2 == 'G') {
    if (1 < (ulong)((long)pcVar25 - (long)pcVar23)) {
      if (pcVar23[1] == 'R') {
        *param_1 = (long)(pcVar23 + 2);
        lVar19 = FUN_0011feb0(param_1,0);
        auVar16._8_8_ = local_90._8_8_;
        auVar16._0_8_ = local_90._0_8_;
        puVar21 = (undefined8 *)0x0;
        if (lVar19 == 0) goto LAB_0011e9ac;
        pbVar27 = (byte *)*param_1;
        pbVar1 = (byte *)param_1[1];
        if (pbVar1 != pbVar27) {
          bVar3 = *pbVar27;
          uVar24 = (uint)bVar3;
          if ((bVar3 < 0x30) || ((0x39 < bVar3 && (0x19 < bVar3 - 0x41)))) {
            bVar18 = true;
          }
          else {
            pbVar26 = pbVar27 + 1;
            do {
              if ((0x39 < uVar24) && (pbVar27 = pbVar26, 0x19 < uVar24 - 0x41)) break;
              *param_1 = (long)pbVar26;
              if (pbVar26 == pbVar1) goto LAB_0011e9a8;
              pbVar27 = pbVar26 + 1;
              uVar24 = (uint)*pbVar26;
              pbVar26 = pbVar27;
            } while (0x2f < uVar24);
            bVar18 = false;
            pbVar27 = pbVar27 + -1;
          }
          if ((pbVar27 == pbVar1) || (uVar24 != 0x5f)) {
            if (!bVar18) goto LAB_0011e9a8;
          }
          else {
            *param_1 = (long)(pbVar27 + 1);
          }
        }
        pvVar33 = (void *)param_1[0x266];
        lVar22 = *(long *)((long)pvVar33 + 8);
        puVar21 = pvVar33;
        if (lVar22 - 0xfc0U < 0xfffffffffffff00f || lVar22 == -0x31) {
          puVar21 = malloc(0x1000);
          if (puVar21 == (void *)0x0) {
LAB_0011edb8:
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar22 = 0;
          *puVar21 = pvVar33;
          puVar21[1] = 0;
          param_1[0x266] = (long)puVar21;
        }
        *(long *)((long)puVar21 + 8) = lVar22 + 0x30;
        puVar21 = (undefined8 *)((long)puVar21 + lVar22 + 0x10);
        *puVar21 = &PTR_LAB_0013c450;
        pcVar23 = "reference temporary for ";
        pcVar25 = "";
      }
      else {
        if (pcVar23[1] != 'V') goto LAB_0011e9a8;
        *param_1 = (long)(pcVar23 + 2);
        lVar19 = FUN_0011feb0(param_1,0);
        auVar16._8_8_ = local_90._8_8_;
        auVar16._0_8_ = local_90._0_8_;
        puVar21 = (undefined8 *)0x0;
        if (lVar19 == 0) goto LAB_0011e9ac;
        pvVar33 = (void *)param_1[0x266];
        lVar22 = *(long *)((long)pvVar33 + 8);
        puVar21 = pvVar33;
        if (lVar22 - 0xfc0U < 0xfffffffffffff00f || lVar22 == -0x31) {
          puVar21 = malloc(0x1000);
          if (puVar21 == (void *)0x0) goto LAB_0011edb8;
          lVar22 = 0;
          *puVar21 = pvVar33;
          puVar21[1] = 0;
          param_1[0x266] = (long)puVar21;
        }
        *(long *)((long)puVar21 + 8) = lVar22 + 0x30;
        puVar21 = (undefined8 *)((long)puVar21 + lVar22 + 0x10);
        *puVar21 = &PTR_LAB_0013c450;
        pcVar23 = "guard variable for ";
        pcVar25 = "";
      }
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
      *(undefined4 *)(puVar21 + 1) = 0x1010114;
      puVar21[2] = pcVar23;
      puVar21[3] = pcVar25;
      puVar21[4] = lVar19;
      goto LAB_0011e9ac;
    }
    goto LAB_0011e9a8;
  }
  if (cVar2 != 'T') goto LAB_0011e9a8;
  if ((ulong)((long)pcVar25 - (long)pcVar23) < 2) {
code_r0x0011e978:
    pcVar23 = pcVar23 + 1;
    *param_1 = (long)pcVar23;
    if (pcVar25 == pcVar23) {
      bVar18 = false;
    }
    else {
      bVar18 = *pcVar23 == 'v';
    }
    uVar20 = FUN_00120fd0(param_1);
    if ((uVar20 & 1) == 0) {
      local_70 = FUN_0011e5c4(param_1);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
      puVar21 = (undefined8 *)0x0;
      if (local_70 != 0) {
        if (bVar18) {
          puVar21 = (undefined8 *)FUN_00121384();
          auVar16._8_8_ = local_90._8_8_;
          auVar16._0_8_ = local_90._0_8_;
        }
        else {
          puVar21 = (undefined8 *)FUN_00121424(param_1,&local_70);
          auVar16._8_8_ = local_90._8_8_;
          auVar16._0_8_ = local_90._0_8_;
        }
      }
      goto LAB_0011e9ac;
    }
    goto LAB_0011e9a8;
  }
  switch(pcVar23[1]) {
  case 'C':
    *param_1 = (long)(pcVar23 + 2);
    local_70 = FUN_0011ef00(param_1);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
    if (local_70 == 0) break;
    auVar34 = FUN_0011edc0(param_1,1);
    if (((auVar34._0_8_ != auVar34._8_8_) &&
        (pcVar23 = (char *)*param_1, pcVar23 != (char *)param_1[1])) && (*pcVar23 == '_')) {
      *param_1 = (long)(pcVar23 + 1);
      local_90._0_8_ = FUN_0011ef00(param_1);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
      puVar21 = (undefined8 *)0x0;
      if (local_90._0_8_ != 0) {
        puVar21 = (undefined8 *)FUN_0012124c(param_1,local_90,&local_70);
        auVar16._8_8_ = local_90._8_8_;
        auVar16._0_8_ = local_90._0_8_;
      }
      break;
    }
    goto LAB_0011e9a8;
  default:
    goto code_r0x0011e978;
  case 'H':
    *param_1 = (long)(pcVar23 + 2);
    local_70 = FUN_0011feb0(param_1,0);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
    if (local_70 != 0) {
      puVar21 = (undefined8 *)FUN_001212e4(param_1,&local_70);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
    }
    break;
  case 'I':
    *param_1 = (long)(pcVar23 + 2);
    local_70 = FUN_0011ef00(param_1);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
    if (local_70 != 0) {
      puVar21 = (undefined8 *)FUN_00120e90(param_1,&local_70);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
    }
    break;
  case 'S':
    *param_1 = (long)(pcVar23 + 2);
    local_70 = FUN_0011ef00(param_1);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
    if (local_70 != 0) {
      puVar21 = (undefined8 *)FUN_00120f30(param_1,&local_70);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
    }
    break;
  case 'T':
    *param_1 = (long)(pcVar23 + 2);
    local_70 = FUN_0011ef00(param_1);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
    if (local_70 != 0) {
      puVar21 = (undefined8 *)FUN_00120df0(param_1,&local_70);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
    }
    break;
  case 'V':
    *param_1 = (long)(pcVar23 + 2);
    local_70 = FUN_0011ef00(param_1);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
    if (local_70 != 0) {
      puVar21 = (undefined8 *)FUN_00120d50(param_1,&local_70);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
    }
    break;
  case 'W':
    *param_1 = (long)(pcVar23 + 2);
    local_70 = FUN_0011feb0(param_1,0);
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
    if (local_70 != 0) {
      puVar21 = (undefined8 *)FUN_0011ee58(param_1,"thread-local wrapper routine for ",&local_70);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
    }
    break;
  case 'c':
    *param_1 = (long)(pcVar23 + 2);
    uVar20 = FUN_00120fd0(param_1);
    if (((uVar20 & 1) == 0) && (uVar20 = FUN_00120fd0(param_1), (uVar20 & 1) == 0)) {
      local_70 = FUN_0011e5c4(param_1);
      auVar16._8_8_ = local_90._8_8_;
      auVar16._0_8_ = local_90._0_8_;
      puVar21 = (undefined8 *)0x0;
      if (local_70 != 0) {
        puVar21 = (undefined8 *)FUN_001211ac(param_1,&local_70);
        auVar16._8_8_ = local_90._8_8_;
        auVar16._0_8_ = local_90._0_8_;
      }
      break;
    }
LAB_0011e9a8:
    auVar16._8_8_ = local_90._8_8_;
    auVar16._0_8_ = local_90._0_8_;
    puVar21 = (undefined8 *)0x0;
  }
LAB_0011e9ac:
  if (*(long *)(lVar4 + 0x28) != local_58) {
    local_90 = auVar16;
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar21);
  }
  return;
}


// ==== FUN_0011edc0 @ 0011edc0

undefined1  [16] FUN_0011edc0(undefined1 (*param_1) [16],ulong param_2)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined1 auVar3 [16];
  
  auVar3._0_8_ = *(byte **)*param_1;
  pbVar2 = *(byte **)(*param_1 + 8);
  pbVar1 = auVar3._0_8_;
  if ((((param_2 & 1) != 0) && (auVar3._0_8_ != pbVar2)) && (*auVar3._0_8_ == 0x6e)) {
    pbVar1 = auVar3._0_8_ + 1;
    *(byte **)*param_1 = pbVar1;
  }
  if ((pbVar2 == pbVar1) || (*pbVar1 - 0x3a < 0xfffffff6)) {
    return ZEXT816(0);
  }
  do {
    pbVar1 = pbVar1 + 1;
    *(byte **)*param_1 = pbVar1;
    if (pbVar1 == pbVar2) {
      return *param_1;
    }
  } while (0xfffffff5 < *pbVar1 - 0x3a);
  auVar3._8_8_ = pbVar1;
  return auVar3;
}


// ==== FUN_0011ee58 @ 0011ee58

undefined8 * FUN_0011ee58(long param_1,char *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar6 + 8);
  puVar1 = pvVar6;
  if (lVar3 - 0xfc0U < 0xfffffffffffff00f || lVar3 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar6;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x30;
  sVar2 = strlen(param_2);
  uVar4 = *param_3;
  puVar5 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar5 = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010114;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  *(undefined8 *)((long)puVar1 + lVar3 + 0x30) = uVar4;
  return puVar5;
}


// ==== FUN_0011ef00 @ 0011ef00

void FUN_0011ef00(long *param_1)

{
  byte bVar1;
  long lVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined8 *puVar11;
  byte *pbVar12;
  byte *pbVar13;
  byte *pbVar14;
  byte **ppbVar15;
  byte **ppbVar16;
  long lVar17;
  char *pcVar18;
  uint uVar19;
  ulong uVar20;
  char *pcVar21;
  ulong uVar22;
  void *pvVar23;
  byte *local_58;
  undefined1 local_50 [16];
  byte *local_40;
  long local_38;
  
  auVar3._8_8_ = local_50._8_8_;
  auVar3._0_8_ = local_50._0_8_;
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  pbVar14 = (byte *)*param_1;
  pbVar12 = (byte *)param_1[1];
  local_58 = (byte *)0x0;
  uVar22 = (long)pbVar12 - (long)pbVar14;
  if (pbVar12 == pbVar14) {
code_r0x0011f5cc:
    pbVar12 = (byte *)FUN_0012fbe4(param_1);
    auVar4._8_8_ = local_50._8_8_;
    auVar4._0_8_ = local_50._0_8_;
    goto LAB_0011f5d4;
  }
  bVar1 = *pbVar14;
  switch(bVar1) {
  case 0x41:
    if (pbVar14 != pbVar12) {
      pbVar13 = pbVar14 + 1;
      local_40 = (byte *)0x0;
      *param_1 = (long)pbVar13;
      if (pbVar12 == pbVar13) {
LAB_0011fc00:
        pbVar13 = (byte *)FUN_00122d94(param_1);
        auVar4._8_8_ = local_50._8_8_;
        auVar4._0_8_ = local_50._0_8_;
        pbVar12 = (byte *)0x0;
        if (pbVar13 == (byte *)0x0) goto LAB_0011f5d4;
        pcVar21 = (char *)*param_1;
        if ((pcVar21 == (char *)param_1[1]) || (local_50 = auVar4, *pcVar21 != '_'))
        goto LAB_0011fc94;
        pbVar14 = (byte *)(pcVar21 + 1);
        local_40 = pbVar13;
      }
      else if (*pbVar13 - 0x3a < 0xfffffff6) {
        if (*pbVar13 != 0x5f) goto LAB_0011fc00;
        pbVar14 = pbVar14 + 2;
      }
      else {
        local_50 = FUN_0011edc0(param_1,0);
        local_40 = (byte *)FUN_00130a9c(param_1,local_50);
        pcVar21 = (char *)*param_1;
        if ((pcVar21 == (char *)param_1[1]) || (*pcVar21 != '_')) goto LAB_0011fc94;
        pbVar14 = (byte *)(pcVar21 + 1);
      }
      *param_1 = (long)pbVar14;
      pbVar14 = (byte *)FUN_0011ef00(param_1);
      auVar4._8_8_ = local_50._8_8_;
      auVar4._0_8_ = pbVar14;
      pbVar12 = (byte *)0x0;
      if (pbVar14 != (byte *)0x0) {
        local_50._0_8_ = pbVar14;
        pbVar12 = (byte *)FUN_00130ecc(param_1,local_50,&local_40);
        auVar4._8_8_ = local_50._8_8_;
        auVar4._0_8_ = local_50._0_8_;
      }
      goto LAB_0011f5d4;
    }
    goto LAB_0011fc94;
  default:
    goto code_r0x0011f5cc;
  case 0x43:
    *param_1 = (long)(pbVar14 + 1);
    local_50._0_8_ = FUN_0011ef00(param_1);
    pbVar12 = (byte *)0x0;
    if ((byte *)local_50._0_8_ == (byte *)0x0) goto code_r0x0011fb6c;
    local_58 = (byte *)FUN_0012fe70(param_1,local_50);
    goto LAB_0011f5dc;
  case 0x44:
    if (uVar22 < 2) {
LAB_0011fd34:
      pbVar12 = (byte *)0x0;
      goto code_r0x0011fb6c;
    }
    pbVar12 = (byte *)0x0;
    switch(pbVar14[1]) {
    case 0x4f:
    case 0x6f:
    case 0x77:
    case 0x78:
      goto code_r0x0011f500;
    case 0x54:
    case 0x74:
      pbVar12 = (byte *)FUN_0012237c(param_1);
      auVar4._8_8_ = local_50._8_8_;
      auVar4._0_8_ = local_50._0_8_;
      goto LAB_0011f5d4;
    case 0x61:
      *param_1 = (long)(pbVar14 + 2);
      pbVar12 = (byte *)FUN_00122a90(param_1,&DAT_0010a0c8);
      break;
    case 99:
      pcVar21 = "decltype(auto)";
      goto LAB_0011fe18;
    case 100:
      pcVar21 = "decimal64";
      goto LAB_0011fde4;
    case 0x65:
      *param_1 = (long)(pbVar14 + 2);
      pbVar12 = (byte *)FUN_0012bd0c(param_1,"decimal128");
      break;
    case 0x66:
      pcVar21 = "decimal32";
      goto LAB_0011fde4;
    case 0x68:
      pcVar21 = "decimal16";
LAB_0011fde4:
      *param_1 = (long)(pbVar14 + 2);
      pbVar12 = (byte *)FUN_0012bda8(param_1,pcVar21);
      break;
    case 0x69:
      pcVar21 = "char32_t";
      goto LAB_0011fe68;
    case 0x6e:
      pcVar21 = "std::nullptr_t";
LAB_0011fe18:
      *param_1 = (long)(pbVar14 + 2);
      pbVar12 = (byte *)FUN_0012c09c(param_1,pcVar21);
      break;
    case 0x70:
      *param_1 = (long)(pbVar14 + 2);
      local_50._0_8_ = FUN_0011ef00(param_1);
      pbVar12 = (byte *)0x0;
      if ((byte *)local_50._0_8_ == (byte *)0x0) break;
      local_58 = (byte *)FUN_001265e8(param_1,local_50);
      goto LAB_0011f5dc;
    case 0x73:
      pcVar21 = "char16_t";
LAB_0011fe68:
      *param_1 = (long)(pbVar14 + 2);
      pbVar12 = (byte *)FUN_0012f884(param_1,pcVar21);
      break;
    case 0x75:
      *param_1 = (long)(pbVar14 + 2);
      pbVar12 = (byte *)FUN_00126ddc(param_1,"char8_t");
      break;
    case 0x76:
      pbVar12 = (byte *)FUN_0012f920(param_1);
      auVar4._8_8_ = local_50._8_8_;
      auVar4._0_8_ = local_50._0_8_;
      goto LAB_0011f5d4;
    }
    goto code_r0x0011fb6c;
  case 0x46:
    goto code_r0x0011f500;
  case 0x47:
    *param_1 = (long)(pbVar14 + 1);
    local_50._0_8_ = FUN_0011ef00(param_1);
    pbVar12 = (byte *)0x0;
    if ((byte *)local_50._0_8_ == (byte *)0x0) goto code_r0x0011fb6c;
    local_58 = (byte *)FUN_0012ff10(param_1,local_50);
    goto LAB_0011f5dc;
  case 0x4b:
  case 0x56:
  case 0x72:
    uVar20 = (ulong)(bVar1 == 0x72);
    if (uVar20 < uVar22) {
      uVar19 = 1;
      if (bVar1 == 0x72) {
        uVar19 = 2;
      }
      if (pbVar14[uVar20] != 0x56) {
        uVar19 = (uint)(bVar1 == 0x72);
      }
      uVar20 = (ulong)uVar19;
    }
    if (uVar20 < uVar22) {
      uVar19 = (uint)uVar20;
      if (pbVar14[uVar20] == 0x4b) {
        uVar19 = uVar19 + 1;
      }
      uVar20 = (ulong)uVar19;
    }
    if ((uVar22 <= uVar20) ||
       ((pbVar14[uVar20] != 0x46 &&
        (((pbVar14[uVar20] != 0x44 || (uVar22 <= uVar20 + 1)) ||
         ((0x29 < pbVar14[uVar20 + 1] - 0x4f ||
          ((1L << ((ulong)(pbVar14[uVar20 + 1] - 0x4f) & 0x3f) & 0x30100000001U) == 0))))))))
    goto code_r0x0011f000;
    goto code_r0x0011f500;
  case 0x4d:
    local_50 = auVar3;
    if (pbVar14 != pbVar12) {
      *param_1 = (long)(pbVar14 + 1);
      local_50._0_8_ = FUN_0011ef00(param_1);
      auVar4._8_8_ = local_50._8_8_;
      auVar4._0_8_ = local_50._0_8_;
      pbVar12 = (byte *)0x0;
      if ((byte *)local_50._0_8_ != (byte *)0x0) {
        local_40 = (byte *)FUN_0011ef00(param_1);
        auVar4._8_8_ = local_50._8_8_;
        auVar4._0_8_ = local_50._0_8_;
        pbVar12 = (byte *)0x0;
        if (local_40 != (byte *)0x0) {
          pbVar12 = (byte *)FUN_00131124(param_1,local_50,&local_40);
          auVar4._8_8_ = local_50._8_8_;
          auVar4._0_8_ = local_50._0_8_;
        }
      }
      goto LAB_0011f5d4;
    }
LAB_0011fc94:
    pbVar12 = (byte *)0x0;
    auVar4 = local_50;
LAB_0011f5d4:
    local_58 = pbVar12;
    local_50 = auVar4;
    if (pbVar12 == (byte *)0x0) goto code_r0x0011fb6c;
    goto LAB_0011f5dc;
  case 0x4f:
    *param_1 = (long)(pbVar14 + 1);
    local_50._0_8_ = FUN_0011ef00(param_1);
    pbVar12 = (byte *)0x0;
    if ((byte *)local_50._0_8_ == (byte *)0x0) goto code_r0x0011fb6c;
    local_40 = (byte *)CONCAT44(local_40._4_4_,1);
    goto LAB_0011fa74;
  case 0x50:
    *param_1 = (long)(pbVar14 + 1);
    local_50._0_8_ = FUN_0011ef00(param_1);
    pbVar12 = (byte *)0x0;
    if ((byte *)local_50._0_8_ == (byte *)0x0) goto code_r0x0011fb6c;
    local_58 = (byte *)FUN_0012fd28(param_1,local_50);
    goto LAB_0011f5dc;
  case 0x52:
    *param_1 = (long)(pbVar14 + 1);
    local_50._0_8_ = FUN_0011ef00(param_1);
    pbVar12 = (byte *)0x0;
    if ((byte *)local_50._0_8_ == (byte *)0x0) goto code_r0x0011fb6c;
    local_40 = (byte *)((ulong)local_40 & 0xffffffff00000000);
LAB_0011fa74:
    local_58 = (byte *)FUN_0012fdc4(param_1,local_50,&local_40);
    goto LAB_0011f5dc;
  case 0x53:
    if (((uVar22 < 2) || (pbVar14[1] == 0)) || (pbVar14[1] == 0x74)) goto code_r0x0011f5cc;
    pbVar12 = (byte *)FUN_00121764(param_1);
    auVar10._8_8_ = local_50._8_8_;
    auVar10._0_8_ = pbVar12;
    auVar9._8_8_ = local_50._8_8_;
    auVar9._0_8_ = pbVar12;
    auVar8._8_8_ = local_50._8_8_;
    auVar8._0_8_ = pbVar12;
    local_50._0_8_ = pbVar12;
    if ((((pbVar12 == (byte *)0x0) || (local_50 = auVar8, (char)param_1[0x61] == '\0')) ||
        (local_50 = auVar9, (char *)param_1[1] == (char *)*param_1)) ||
       (local_50 = auVar10, *(char *)*param_1 != 'I')) goto code_r0x0011fb6c;
    local_40 = (byte *)FUN_00121af4(param_1,0);
    pbVar12 = (byte *)0x0;
    if (local_40 == (byte *)0x0) goto code_r0x0011fb6c;
    ppbVar15 = (byte **)local_50;
    ppbVar16 = &local_40;
LAB_0011fce8:
    local_58 = (byte *)FUN_00121f70(param_1,ppbVar15,ppbVar16);
    goto LAB_0011f5dc;
  case 0x54:
    if (((1 < uVar22) && (pbVar14[1] - 0x65 < 0x11)) &&
       ((1 << (ulong)(pbVar14[1] - 0x65 & 0x1f) & 0x14001U) != 0)) goto code_r0x0011f5cc;
    pbVar12 = (byte *)FUN_00122008(param_1);
    auVar7._8_8_ = local_50._8_8_;
    auVar7._0_8_ = local_50._0_8_;
    auVar6._8_8_ = local_50._8_8_;
    auVar6._0_8_ = local_50._0_8_;
    auVar5._8_8_ = local_50._8_8_;
    auVar5._0_8_ = local_50._0_8_;
    local_58 = pbVar12;
    local_50 = auVar7;
    if (pbVar12 == (byte *)0x0) goto code_r0x0011fb6c;
    local_50 = auVar5;
    if ((((char)param_1[0x61] != '\0') &&
        (local_50 = auVar6, (char *)param_1[1] != (char *)*param_1)) &&
       (local_50 = auVar7, *(char *)*param_1 == 'I')) {
      local_50._0_8_ = FUN_00121af4(param_1,0);
      pbVar12 = (byte *)0x0;
      if ((byte *)local_50._0_8_ == (byte *)0x0) goto code_r0x0011fb6c;
      ppbVar15 = &local_58;
      ppbVar16 = (byte **)local_50;
      goto LAB_0011fce8;
    }
    goto LAB_0011f5dc;
  case 0x55:
code_r0x0011f000:
    pbVar12 = (byte *)FUN_0012f4c4(param_1);
    auVar4._8_8_ = local_50._8_8_;
    auVar4._0_8_ = local_50._0_8_;
    goto LAB_0011f5d4;
  case 0x61:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) {
LAB_0011fea8:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "signed char";
    pcVar21 = "";
    break;
  case 0x62:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "bool";
    goto LAB_0011fb5c;
  case 99:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "char";
    goto LAB_0011fb5c;
  case 100:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "double";
    pcVar21 = "";
    break;
  case 0x65:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "long double";
    pcVar21 = "";
    break;
  case 0x66:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "float";
    pcVar21 = "";
    break;
  case 0x67:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "__float128";
    pcVar21 = "";
    break;
  case 0x68:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "unsigned char";
    pcVar21 = "";
    break;
  case 0x69:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "int";
    pcVar21 = "";
    break;
  case 0x6a:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "unsigned int";
    pcVar21 = "";
    break;
  case 0x6c:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "long";
    goto LAB_0011fb5c;
  case 0x6d:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "unsigned long";
    pcVar21 = "";
    break;
  case 0x6e:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "__int128";
    pcVar21 = "";
    break;
  case 0x6f:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "unsigned __int128";
    pcVar21 = "";
    break;
  case 0x73:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "short";
    pcVar21 = "";
    break;
  case 0x74:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "unsigned short";
    pcVar21 = "";
    break;
  case 0x75:
    pbVar13 = pbVar14 + 1;
    *param_1 = (long)pbVar13;
    if ((pbVar12 == pbVar13) || (*pbVar13 - 0x3a < 0xfffffff6)) {
LAB_0011fd0c:
      local_50._8_8_ = (byte *)0x0;
      local_50._0_8_ = (byte *)0x0;
    }
    else {
      uVar22 = 0;
      local_50._0_8_ = pbVar14 + 1;
      pbVar14 = pbVar14 + 2;
      do {
        pbVar13 = pbVar14;
        *param_1 = (long)pbVar13;
        uVar22 = ((ulong)pbVar13[-1] + uVar22 * 10) - 0x30;
        if (pbVar13 == pbVar12) {
          local_50._0_8_ = pbVar12;
          pbVar13 = pbVar12;
          goto LAB_0011fd00;
        }
        local_50._0_8_ = local_50._0_8_ + 1;
        pbVar14 = pbVar13 + 1;
      } while (*pbVar13 - 0x30 < 10);
LAB_0011fd00:
      if ((ulong)((long)pbVar12 - local_50._0_8_) < uVar22) goto LAB_0011fd0c;
      local_50._8_8_ = pbVar13 + uVar22;
      *param_1 = local_50._8_8_;
    }
    if (local_50._0_8_ == local_50._8_8_) goto LAB_0011fd34;
    local_58 = (byte *)FUN_0012b0dc(param_1,local_50);
LAB_0011f5dc:
    FUN_00120b24(param_1 + 0x25,&local_58);
    pbVar12 = local_58;
    goto code_r0x0011fb6c;
  case 0x76:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "void";
LAB_0011fb5c:
    pcVar21 = pcVar18 + 4;
    break;
  case 0x77:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "wchar_t";
    pcVar21 = "";
    break;
  case 0x78:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "long long";
    pcVar21 = "";
    break;
  case 0x79:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "unsigned long long";
    pcVar21 = "";
    break;
  case 0x7a:
    pvVar23 = (void *)param_1[0x266];
    *param_1 = (long)(pbVar14 + 1);
    lVar17 = *(long *)((long)pvVar23 + 8);
    puVar11 = pvVar23;
    if (lVar17 - 0xfd0U < 0xfffffffffffff00f || lVar17 == -0x21) {
      puVar11 = malloc(0x1000);
      if (puVar11 == (void *)0x0) goto LAB_0011fea8;
      lVar17 = 0;
      *puVar11 = pvVar23;
      puVar11[1] = 0;
      param_1[0x266] = (long)puVar11;
    }
    *(long *)((long)puVar11 + 8) = lVar17 + 0x20;
    pbVar12 = (byte *)((long)puVar11 + lVar17 + 0x10);
    *(undefined ***)pbVar12 = &PTR_LAB_0013c540;
    pcVar18 = "...";
    pcVar21 = "";
  }
  pbVar12[8] = 7;
  pbVar12[9] = 1;
  pbVar12[10] = 1;
  pbVar12[0xb] = 1;
  *(char **)(pbVar12 + 0x10) = pcVar18;
  *(char **)(pbVar12 + 0x18) = pcVar21;
code_r0x0011fb6c:
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(pbVar12);
  }
  return;
code_r0x0011f500:
  pbVar12 = (byte *)FUN_0012efe4(param_1);
  auVar4._8_8_ = local_50._8_8_;
  auVar4._0_8_ = local_50._0_8_;
  goto LAB_0011f5d4;
}


// ==== FUN_0011feb0 @ 0011feb0

undefined8 * FUN_0011feb0(long *param_1,undefined1 *param_2)

{
  byte *pbVar1;
  char *pcVar2;
  byte *pbVar3;
  int iVar4;
  char cVar5;
  byte bVar6;
  byte bVar7;
  ulong uVar8;
  long lVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined8 **ppuVar14;
  long lVar15;
  long lVar16;
  char *pcVar17;
  byte *pbVar18;
  undefined8 *puVar19;
  undefined1 uVar20;
  uint uVar21;
  char *pcVar22;
  void *pvVar23;
  undefined8 *local_78;
  undefined8 *local_70;
  long local_68;
  
  lVar9 = tpidr_el0;
  local_68 = *(long *)(lVar9 + 0x28);
  pcVar22 = (char *)*param_1;
  pcVar2 = (char *)param_1[1];
  if ((pcVar22 != pcVar2) && (*pcVar22 == 'L')) {
    pcVar22 = pcVar22 + 1;
    *param_1 = (long)pcVar22;
  }
  if (pcVar2 == pcVar22) {
LAB_0011ff68:
    local_70 = (undefined8 *)FUN_00122618(param_1,param_2);
    puVar10 = local_70;
    if (local_70 == (undefined8 *)0x0) goto LAB_00120870;
LAB_0011ff80:
    puVar19 = local_70;
    puVar10 = local_70;
    if (((char *)param_1[1] == (char *)*param_1) || (*(char *)*param_1 != 'I')) goto LAB_00120870;
    FUN_00120b24(param_1 + 0x25,&local_70);
    lVar16 = FUN_00121af4(param_1,param_2 != (undefined1 *)0x0);
    if (lVar16 != 0) {
      if (param_2 != (undefined1 *)0x0) {
        param_2[1] = 1;
      }
      pvVar23 = (void *)param_1[0x266];
      lVar15 = *(long *)((long)pvVar23 + 8);
      puVar11 = pvVar23;
      if (lVar15 - 0xfd0U < 0xfffffffffffff00f || lVar15 == -0x21) {
        puVar11 = malloc(0x1000);
        if (puVar11 == (void *)0x0) goto LAB_0012092c;
        lVar15 = 0;
        *puVar11 = pvVar23;
        puVar11[1] = 0;
        param_1[0x266] = (long)puVar11;
      }
      *(long *)((long)puVar11 + 8) = lVar15 + 0x20;
      puVar10 = (undefined8 *)((long)puVar11 + lVar15 + 0x10);
      *puVar10 = &PTR_LAB_0013dc70;
      *(undefined8 **)((long)puVar11 + lVar15 + 0x20) = puVar19;
      *(long *)((long)puVar11 + lVar15 + 0x28) = lVar16;
      *(undefined4 *)((long)puVar11 + lVar15 + 0x18) = 0x1010125;
      goto LAB_00120870;
    }
  }
  else {
    cVar5 = *pcVar22;
    if (cVar5 == 'Z') {
      if (pcVar22 != pcVar2) {
        *param_1 = (long)(pcVar22 + 1);
        local_70 = (undefined8 *)FUN_0011e5c4(param_1);
        if (local_70 != (undefined8 *)0x0) {
          pcVar22 = (char *)*param_1;
          if ((pcVar22 != (char *)param_1[1]) && (*pcVar22 == 'E')) {
            pcVar2 = pcVar22 + 1;
            *param_1 = (long)pcVar2;
            if (pcVar2 == (char *)param_1[1]) {
LAB_001208a8:
              local_78 = (undefined8 *)FUN_0011feb0(param_1,param_2);
              if (local_78 != (undefined8 *)0x0) {
                lVar16 = FUN_0012dec0(*param_1,param_1[1]);
                *param_1 = lVar16;
LAB_001208c8:
                puVar10 = (undefined8 *)FUN_0012df70(param_1,&local_70,&local_78);
                goto LAB_00120870;
              }
            }
            else {
              if (*pcVar2 != 'd') {
                if (*pcVar2 != 's') goto LAB_001208a8;
                *param_1 = (long)(pcVar22 + 2);
                lVar16 = FUN_0012dec0();
                *param_1 = lVar16;
                local_78 = (undefined8 *)FUN_0012c09c(param_1,"string literal");
                goto LAB_001208c8;
              }
              *param_1 = (long)(pcVar22 + 2);
              FUN_0011edc0(param_1,1);
              pcVar22 = (char *)*param_1;
              if ((pcVar22 != (char *)param_1[1]) && (*pcVar22 == '_')) {
                *param_1 = (long)(pcVar22 + 1);
                local_78 = (undefined8 *)FUN_0011feb0(param_1,param_2);
                if (local_78 != (undefined8 *)0x0) goto LAB_001208c8;
              }
            }
          }
        }
      }
    }
    else {
      if (cVar5 != 'S') {
        if (cVar5 != 'N') goto LAB_0011ff68;
        if (pcVar22 == pcVar2) goto LAB_0012086c;
        pcVar17 = pcVar22 + 1;
        *param_1 = (long)pcVar17;
        if (pcVar17 == pcVar2) {
          uVar21 = 0;
LAB_00120190:
          pcVar17 = pcVar2;
        }
        else {
          if (*pcVar17 != 'r') {
            uVar21 = 0;
            if (pcVar17 != pcVar2) goto LAB_00120154;
            goto LAB_00120190;
          }
          pcVar17 = pcVar22 + 2;
          uVar21 = 4;
          *param_1 = (long)pcVar17;
          if (pcVar17 == pcVar2) goto LAB_00120190;
LAB_00120154:
          if (*pcVar17 == 'V') {
            pcVar17 = pcVar17 + 1;
            uVar21 = uVar21 | 2;
            *param_1 = (long)pcVar17;
          }
          if (pcVar17 == pcVar2) goto LAB_00120190;
          if (*pcVar17 == 'K') {
            pcVar17 = pcVar17 + 1;
            uVar21 = uVar21 | 1;
            *param_1 = (long)pcVar17;
          }
        }
        if (param_2 != (undefined1 *)0x0) {
          *(uint *)(param_2 + 4) = uVar21;
        }
        if (pcVar17 == pcVar2) {
LAB_001201cc:
          if (param_2 != (undefined1 *)0x0) {
            uVar20 = 0;
LAB_00120268:
            param_2[8] = uVar20;
          }
        }
        else if (*pcVar17 == 'R') {
          pcVar17 = pcVar17 + 1;
          *param_1 = (long)pcVar17;
          if (param_2 != (undefined1 *)0x0) {
            uVar20 = 1;
            goto LAB_00120268;
          }
        }
        else {
          if (*pcVar17 != 'O') goto LAB_001201cc;
          pcVar17 = pcVar17 + 1;
          *param_1 = (long)pcVar17;
          if (param_2 != (undefined1 *)0x0) {
            uVar20 = 2;
            goto LAB_00120268;
          }
        }
        local_70 = (undefined8 *)0x0;
        if (((1 < (ulong)((long)pcVar2 - (long)pcVar17)) && (*pcVar17 == 'S')) &&
           (pcVar17[1] == 't')) {
          pvVar23 = (void *)param_1[0x266];
          *param_1 = (long)(pcVar17 + 2);
          lVar16 = *(long *)((long)pvVar23 + 8);
          puVar10 = pvVar23;
          if (lVar16 - 0xfd0U < 0xfffffffffffff00f || lVar16 == -0x21) {
            puVar10 = malloc(0x1000);
            if (puVar10 == (void *)0x0) {
LAB_0012092c:
                    /* WARNING: Subroutine does not return */
              FUN_0011dc6c();
            }
            lVar16 = 0;
            *puVar10 = pvVar23;
            puVar10[1] = 0;
            param_1[0x266] = (long)puVar10;
          }
          *(long *)((long)puVar10 + 8) = lVar16 + 0x20;
          local_70 = (undefined8 *)((long)puVar10 + lVar16 + 0x10);
          *local_70 = &PTR_LAB_0013c540;
          *(undefined4 *)((long)puVar10 + lVar16 + 0x18) = 0x1010107;
          *(undefined **)((long)puVar10 + lVar16 + 0x20) = &DAT_0010a066;
          *(undefined **)((long)puVar10 + lVar16 + 0x28) = &DAT_0010a069;
        }
LAB_00120338:
        pbVar1 = (byte *)*param_1;
        pbVar3 = (byte *)param_1[1];
        if (pbVar1 == pbVar3) {
joined_r0x00120370:
          if ((pbVar1 != pbVar3) && (*pbVar1 == 0x4d)) {
            *param_1 = (long)(pbVar1 + 1);
            if (local_70 == (undefined8 *)0x0) goto LAB_0012086c;
            goto LAB_00120338;
          }
          uVar8 = (long)pbVar3 - (long)pbVar1;
          if (pbVar3 == pbVar1) {
code_r0x001205dc:
            puVar10 = (undefined8 *)FUN_00122618(param_1,param_2);
            puVar19 = local_70;
joined_r0x001203dc:
            local_70 = puVar19;
            if (puVar10 != (undefined8 *)0x0) {
              local_70 = puVar10;
              if (puVar19 != (undefined8 *)0x0) {
                pvVar23 = (void *)param_1[0x266];
                lVar16 = *(long *)((long)pvVar23 + 8);
                puVar11 = pvVar23;
                if (lVar16 - 0xfd0U < 0xfffffffffffff00f || lVar16 == -0x21) {
                  local_70 = puVar19;
                  puVar11 = malloc(0x1000);
                  if (puVar11 == (void *)0x0) goto LAB_0012092c;
                  lVar16 = 0;
                  *puVar11 = pvVar23;
                  puVar11[1] = 0;
                  param_1[0x266] = (long)puVar11;
                }
                *(long *)((long)puVar11 + 8) = lVar16 + 0x20;
                local_70 = (undefined8 *)((long)puVar11 + lVar16 + 0x10);
                *local_70 = &PTR_LAB_0013c5b0;
                *(undefined4 *)((long)puVar11 + lVar16 + 0x18) = 0x1010117;
                *(undefined8 **)((long)puVar11 + lVar16 + 0x20) = puVar19;
                *(undefined8 **)((long)puVar11 + lVar16 + 0x28) = puVar10;
              }
              if (param_2 != (undefined1 *)0x0) {
                param_2[1] = 0;
              }
              goto LAB_0012081c;
            }
          }
          else {
            switch(*pbVar1) {
            case 0x44:
              if (1 < uVar8) {
                bVar6 = pbVar1[1];
                if (bVar6 == 0x43) goto code_r0x001205dc;
                if ((bVar6 == 0x74) || (bVar6 == 0x54)) {
                  puVar10 = (undefined8 *)FUN_0012237c(param_1);
                  puVar19 = local_70;
                  goto joined_r0x001203dc;
                }
              }
            case 0x43:
              if (local_70 == (undefined8 *)0x0) goto LAB_0012086c;
              if ((*(char *)(local_70 + 1) == ')') &&
                 (iVar4 = *(int *)((long)local_70 + 0xc), iVar4 - 2U < 4)) {
                pvVar23 = (void *)param_1[0x266];
                lVar16 = *(long *)((long)pvVar23 + 8);
                puVar10 = pvVar23;
                if (lVar16 - 0xfe0U < 0xfffffffffffff00f || lVar16 == -0x11) {
                  puVar10 = malloc(0x1000);
                  if (puVar10 == (void *)0x0) goto LAB_0012092c;
                  lVar16 = 0;
                  *puVar10 = pvVar23;
                  puVar10[1] = 0;
                  param_1[0x266] = (long)puVar10;
                }
                *(long *)((long)puVar10 + 8) = lVar16 + 0x10;
                local_70 = (undefined8 *)((long)puVar10 + lVar16 + 0x10);
                *local_70 = &PTR_LAB_0013d8f0;
                *(undefined4 *)((long)puVar10 + lVar16 + 0x18) = 0x1010128;
                *(int *)((long)puVar10 + lVar16 + 0x1c) = iVar4;
              }
              puVar19 = local_70;
              if (pbVar1 != pbVar3) {
                bVar6 = *pbVar1;
                if (bVar6 != 0x43) goto LAB_00120700;
                pbVar18 = pbVar1 + 1;
                *param_1 = (long)pbVar18;
                if (pbVar18 == pbVar3) goto LAB_0012086c;
                bVar6 = *pbVar18;
                if (bVar6 == 0x49) {
                  pbVar18 = pbVar1 + 2;
                  *param_1 = (long)pbVar18;
                }
                if ((pbVar3 == pbVar18) || (bVar7 = *pbVar18, 4 < bVar7 - 0x31)) goto LAB_0012086c;
                *param_1 = (long)(pbVar18 + 1);
                if (param_2 != (undefined1 *)0x0) {
                  *param_2 = 1;
                }
                if ((bVar6 == 0x49) && (lVar16 = FUN_0011feb0(param_1,param_2), lVar16 == 0))
                goto LAB_0012086c;
                puVar11 = (undefined8 *)param_1[0x266];
                lVar16 = puVar11[1];
                puVar10 = puVar11;
                if (lVar16 - 0xfd0U < 0xfffffffffffff00f || lVar16 == -0x21) {
                  puVar10 = malloc(0x1000);
                  if (puVar10 == (void *)0x0) goto LAB_0012092c;
                  lVar16 = 0;
                  *puVar10 = puVar11;
                  puVar10[1] = 0;
                  param_1[0x266] = (long)puVar10;
                }
                uVar20 = 0;
LAB_00120784:
                puVar11 = local_70;
                lVar15 = lVar16 + 0x20;
                puVar10[1] = lVar15;
                puVar12 = (undefined8 *)((long)puVar10 + lVar16 + 0x10);
                *puVar12 = &PTR_LAB_0013d960;
                *(undefined4 *)((long)puVar10 + lVar16 + 0x18) = 0x101012a;
                *(undefined8 **)((long)puVar10 + lVar16 + 0x20) = puVar19;
                *(undefined1 *)((long)puVar10 + lVar16 + 0x28) = uVar20;
                *(uint *)((long)puVar10 + lVar16 + 0x2c) = bVar7 - 0x30;
                puVar19 = puVar12;
                if (local_70 != (undefined8 *)0x0) {
                  puVar13 = puVar10;
                  if (lVar16 - 0xfb0U < 0xfffffffffffff00f || lVar15 == -0x21) {
                    puVar13 = malloc(0x1000);
                    if (puVar13 == (undefined8 *)0x0) goto LAB_0012092c;
                    lVar15 = 0;
                    *puVar13 = puVar10;
                    puVar13[1] = 0;
                    param_1[0x266] = (long)puVar13;
                  }
                  puVar13[1] = lVar15 + 0x20;
                  puVar19 = (undefined8 *)((long)puVar13 + lVar15 + 0x10);
                  *puVar19 = &PTR_LAB_0013c5b0;
                  *(undefined8 **)((long)puVar13 + lVar15 + 0x20) = puVar11;
                  *(undefined8 **)((long)puVar13 + lVar15 + 0x28) = puVar12;
                  *(undefined4 *)((long)puVar13 + lVar15 + 0x18) = 0x1010117;
                }
                if (param_2 != (undefined1 *)0x0) {
                  param_2[1] = 0;
                }
                local_70 = (undefined8 *)FUN_0012249c(param_1,puVar19);
                if (local_70 == (undefined8 *)0x0) goto LAB_0012086c;
LAB_0012081c:
                ppuVar14 = &local_70;
LAB_00120820:
                FUN_00120b24(param_1 + 0x25,ppuVar14);
                goto LAB_00120338;
              }
              bVar6 = *pbVar3;
LAB_00120700:
              puVar10 = (undefined8 *)0x0;
              if ((bVar6 == 0x44) && (uVar8 != 1)) {
                bVar7 = pbVar1[1];
                puVar10 = (undefined8 *)0x0;
                if ((bVar7 < 0x36) && ((1L << ((ulong)bVar7 & 0x3f) & 0x37000000000000U) != 0)) {
                  *param_1 = (long)(pbVar1 + 2);
                  if (param_2 != (undefined1 *)0x0) {
                    *param_2 = 1;
                  }
                  puVar11 = (undefined8 *)param_1[0x266];
                  lVar16 = puVar11[1];
                  puVar10 = puVar11;
                  if (lVar16 - 0xfd0U < 0xfffffffffffff00f || lVar16 == -0x21) {
                    puVar10 = malloc(0x1000);
                    if (puVar10 == (undefined8 *)0x0) goto LAB_0012092c;
                    lVar16 = 0;
                    *puVar10 = puVar11;
                    puVar10[1] = 0;
                    param_1[0x266] = (long)puVar10;
                  }
                  uVar20 = 1;
                  goto LAB_00120784;
                }
              }
              break;
            default:
              goto code_r0x001205dc;
            case 0x49:
              lVar16 = FUN_00121af4(param_1,param_2 != (undefined1 *)0x0);
              puVar19 = local_70;
              puVar10 = (undefined8 *)0x0;
              if ((lVar16 == 0) || (local_70 == (undefined8 *)0x0)) break;
              pvVar23 = (void *)param_1[0x266];
              lVar15 = *(long *)((long)pvVar23 + 8);
              puVar10 = pvVar23;
              if (lVar15 - 0xfd0U < 0xfffffffffffff00f || lVar15 == -0x21) {
                puVar10 = malloc(0x1000);
                if (puVar10 == (void *)0x0) goto LAB_0012092c;
                lVar15 = 0;
                *puVar10 = pvVar23;
                puVar10[1] = 0;
                param_1[0x266] = (long)puVar10;
              }
              *(long *)((long)puVar10 + 8) = lVar15 + 0x20;
              local_70 = (undefined8 *)((long)puVar10 + lVar15 + 0x10);
              *local_70 = &PTR_LAB_0013dc70;
              *(undefined8 **)((long)puVar10 + lVar15 + 0x20) = puVar19;
              *(long *)((long)puVar10 + lVar15 + 0x28) = lVar16;
              *(undefined4 *)((long)puVar10 + lVar15 + 0x18) = 0x1010125;
              if (param_2 != (undefined1 *)0x0) {
                param_2[1] = 1;
              }
              goto LAB_0012081c;
            case 0x53:
              if ((1 < uVar8) && (pbVar1[1] == 0x74)) goto code_r0x001205dc;
              puVar10 = (undefined8 *)FUN_00121764(param_1);
              puVar19 = local_70;
              local_78 = puVar10;
              if (puVar10 == (undefined8 *)0x0) break;
              puVar11 = puVar10;
              if (local_70 != (undefined8 *)0x0) {
                pvVar23 = (void *)param_1[0x266];
                lVar16 = *(long *)((long)pvVar23 + 8);
                puVar12 = pvVar23;
                if (lVar16 - 0xfd0U < 0xfffffffffffff00f || lVar16 == -0x21) {
                  puVar12 = malloc(0x1000);
                  if (puVar12 == (void *)0x0) goto LAB_0012092c;
                  lVar16 = 0;
                  *puVar12 = pvVar23;
                  puVar12[1] = 0;
                  param_1[0x266] = (long)puVar12;
                }
                *(long *)((long)puVar12 + 8) = lVar16 + 0x20;
                puVar11 = (undefined8 *)((long)puVar12 + lVar16 + 0x10);
                *puVar11 = &PTR_LAB_0013c5b0;
                *(undefined4 *)((long)puVar12 + lVar16 + 0x18) = 0x1010117;
                *(undefined8 **)((long)puVar12 + lVar16 + 0x20) = puVar19;
                *(undefined8 **)((long)puVar12 + lVar16 + 0x28) = puVar10;
              }
              local_70 = puVar11;
              if (param_2 != (undefined1 *)0x0) {
                param_2[1] = 0;
              }
              if (local_70 != puVar10) {
                ppuVar14 = &local_78;
                goto LAB_00120820;
              }
              goto LAB_00120338;
            case 0x54:
              puVar10 = (undefined8 *)FUN_00122008(param_1);
              puVar19 = local_70;
              goto joined_r0x001203dc;
            }
          }
        }
        else {
          if (*pbVar1 == 0x4c) {
            pbVar1 = pbVar1 + 1;
            *param_1 = (long)pbVar1;
            goto joined_r0x00120370;
          }
          if (*pbVar1 != 0x45) goto joined_r0x00120370;
          *param_1 = (long)(pbVar1 + 1);
          puVar10 = local_70;
          if (local_70 == (undefined8 *)0x0) goto LAB_00120860;
          if (param_1[0x25] == param_1[0x26]) goto LAB_0012086c;
          param_1[0x26] = param_1[0x26] + -8;
        }
LAB_00120860:
        goto LAB_00120870;
      }
      if (((ulong)((long)pcVar2 - (long)pcVar22) < 2) || (pcVar22[1] != 't')) {
        local_70 = (undefined8 *)FUN_00121764(param_1);
        if ((local_70 != (undefined8 *)0x0) &&
           ((((char *)param_1[1] != (char *)*param_1 && (*(char *)*param_1 == 'I')) &&
            (local_78 = (undefined8 *)FUN_00121af4(param_1,param_2 != (undefined1 *)0x0),
            local_78 != (undefined8 *)0x0)))) {
          if (param_2 != (undefined1 *)0x0) {
            param_2[1] = 1;
          }
          puVar10 = (undefined8 *)FUN_00121f70(param_1,&local_70,&local_78);
          goto LAB_00120870;
        }
      }
      else {
        if (((ulong)((long)pcVar2 - (long)pcVar22) < 3) || (pcVar22[2] != 'L')) {
          lVar16 = 2;
        }
        else {
          lVar16 = 3;
        }
        *param_1 = (long)(pcVar22 + lVar16);
        lVar16 = FUN_00122618(param_1,param_2);
        if (lVar16 != 0) {
          pvVar23 = (void *)param_1[0x266];
          lVar15 = *(long *)((long)pvVar23 + 8);
          puVar10 = pvVar23;
          if (lVar15 - 0xfd0U < 0xfffffffffffff00f || lVar15 == -0x21) {
            puVar10 = malloc(0x1000);
            if (puVar10 == (void *)0x0) goto LAB_0012092c;
            lVar15 = 0;
            *puVar10 = pvVar23;
            puVar10[1] = 0;
            param_1[0x266] = (long)puVar10;
          }
          *(long *)((long)puVar10 + 8) = lVar15 + 0x20;
          local_70 = (undefined8 *)((long)puVar10 + lVar15 + 0x10);
          *local_70 = &PTR_LAB_0013dce0;
          *(undefined4 *)((long)puVar10 + lVar15 + 0x18) = 0x1010127;
          *(long *)((long)puVar10 + lVar15 + 0x20) = lVar16;
          goto LAB_0011ff80;
        }
      }
    }
  }
LAB_0012086c:
  puVar10 = (undefined8 *)0x0;
LAB_00120870:
  if (*(long *)(lVar9 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar10;
}


// ==== FUN_00120934 @ 00120934

void FUN_00120934(long *param_1)

{
  char *pcVar1;
  char cVar2;
  long lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  char *pcVar6;
  long lVar7;
  long lVar8;
  void *pvVar9;
  undefined1 auVar10 [16];
  long local_50;
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  pcVar6 = (char *)*param_1;
  pcVar1 = (char *)param_1[1];
  if (pcVar1 == pcVar6) {
LAB_001209c0:
    puVar4 = (undefined8 *)FUN_0011ef00(param_1);
  }
  else {
    cVar2 = *pcVar6;
    if (cVar2 == 'J') {
      lVar8 = param_1[3];
      pcVar6 = pcVar6 + 1;
      lVar7 = param_1[2];
      *param_1 = (long)pcVar6;
      if (pcVar6 == pcVar1) goto LAB_00120a50;
      while (*pcVar6 != 'E') {
LAB_00120a50:
        do {
          local_50 = FUN_00120934(param_1);
          puVar4 = (undefined8 *)0x0;
          if (local_50 == 0) goto LAB_001209c8;
          FUN_00120b24(param_1 + 2,&local_50);
          pcVar6 = (char *)*param_1;
        } while (pcVar6 == (char *)param_1[1]);
      }
      lVar7 = (lVar8 - lVar7 >> 3) * 8;
      *param_1 = (long)(pcVar6 + 1);
      auVar10 = FUN_0012a7b8(param_1,param_1[2] + lVar7,param_1[3]);
      pvVar9 = (void *)param_1[0x266];
      param_1[3] = param_1[2] + lVar7;
      lVar7 = *(long *)((long)pvVar9 + 8);
      puVar5 = pvVar9;
      if (lVar7 - 0xfd0U < 0xfffffffffffff00f || lVar7 == -0x21) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0011dc6c();
        }
        lVar7 = 0;
        *puVar5 = pvVar9;
        puVar5[1] = 0;
        param_1[0x266] = (long)puVar5;
      }
      *(long *)((long)puVar5 + 8) = lVar7 + 0x20;
      puVar4 = (undefined8 *)((long)puVar5 + lVar7 + 0x10);
      *puVar4 = &PTR_LAB_0013dd50;
      *(undefined4 *)((long)puVar5 + lVar7 + 0x18) = 0x1010121;
      *(undefined1 (*) [16])((long)puVar5 + lVar7 + 0x20) = auVar10;
      goto LAB_001209c8;
    }
    if (cVar2 == 'L') {
      if (((ulong)((long)pcVar1 - (long)pcVar6) < 2) || (pcVar6[1] != 'Z')) {
        puVar4 = (undefined8 *)FUN_00123e10(param_1);
        goto LAB_001209c8;
      }
      *param_1 = (long)(pcVar6 + 2);
      puVar4 = (undefined8 *)FUN_0011e5c4(param_1);
    }
    else {
      if (cVar2 != 'X') goto LAB_001209c0;
      *param_1 = (long)(pcVar6 + 1);
      puVar4 = (undefined8 *)FUN_00122d94(param_1);
    }
    if (puVar4 != (undefined8 *)0x0) {
      pcVar6 = (char *)*param_1;
      if ((pcVar6 == (char *)param_1[1]) || (*pcVar6 != 'E')) {
        puVar4 = (undefined8 *)0x0;
      }
      else {
        *param_1 = (long)(pcVar6 + 1);
      }
    }
  }
LAB_001209c8:
  if (*(long *)(lVar3 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar4);
  }
  return;
}


// ==== FUN_00120b24 @ 00120b24

void FUN_00120b24(undefined8 *param_1,undefined8 *param_2)

{
  void *__dest;
  undefined8 *puVar1;
  undefined8 uVar2;
  size_t __n;
  undefined8 *__src;
  
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 == (undefined8 *)param_1[2]) {
    __src = (undefined8 *)*param_1;
    __n = (long)puVar1 - (long)__src;
    if (__src == param_1 + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_00120be4;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *param_1 = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *param_1 = __dest;
      if (__dest == (void *)0x0) {
LAB_00120be4:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
    }
    puVar1 = (undefined8 *)((long)__dest + ((long)__n >> 3) * 8);
    param_1[1] = puVar1;
    param_1[2] = (void *)((long)__dest + ((long)__n >> 2) * 8);
  }
  uVar2 = *param_2;
  param_1[1] = puVar1 + 1;
  *puVar1 = uVar2;
  return;
}


// ==== FUN_00120be8 @ 00120be8

void FUN_00120be8(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  void *pvVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  
  pvVar3 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar3 + 8);
  puVar1 = pvVar3;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar3;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar5 = param_2[1];
  uVar4 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013ddc0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010109;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar4;
  return;
}


// ==== FUN_00120c78 @ 00120c78

void FUN_00120c78(long param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4,
                 undefined8 *param_5,undefined4 *param_6,undefined1 *param_7)

{
  undefined4 uVar1;
  undefined1 uVar2;
  undefined8 *puVar3;
  long lVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  void *pvVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  
  pvVar8 = *(void **)(param_1 + 0x1330);
  lVar4 = *(long *)((long)pvVar8 + 8);
  puVar3 = pvVar8;
  if (lVar4 - 0xfb0U < 0xfffffffffffff00f || lVar4 == -0x41) {
    puVar3 = malloc(0x1000);
    if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar4 = 0;
    *puVar3 = pvVar8;
    puVar3[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar3;
  }
  uVar5 = *param_2;
  *(long *)((long)puVar3 + 8) = lVar4 + 0x40;
  uVar6 = *param_3;
  uVar7 = *param_5;
  uVar10 = param_4[1];
  uVar9 = *param_4;
  uVar1 = *param_6;
  *(undefined ***)((long)puVar3 + lVar4 + 0x10) = &PTR_LAB_0013de30;
  uVar2 = *param_7;
  *(undefined4 *)((long)puVar3 + lVar4 + 0x18) = 0x10012;
  *(undefined8 *)((long)puVar3 + lVar4 + 0x20) = uVar5;
  *(undefined8 *)((long)puVar3 + lVar4 + 0x28) = uVar6;
  *(undefined8 *)((long)puVar3 + lVar4 + 0x38) = uVar10;
  *(undefined8 *)((long)puVar3 + lVar4 + 0x30) = uVar9;
  *(undefined8 *)((long)puVar3 + lVar4 + 0x40) = uVar7;
  *(undefined4 *)((long)puVar3 + lVar4 + 0x48) = uVar1;
  *(undefined1 *)((long)puVar3 + lVar4 + 0x4c) = uVar2;
  return;
}


// ==== FUN_00120d50 @ 00120d50

void FUN_00120d50(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "vtable for ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00120df0 @ 00120df0

void FUN_00120df0(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "VTT for ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00120e90 @ 00120e90

void FUN_00120e90(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "typeinfo for ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00120f30 @ 00120f30

void FUN_00120f30(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "typeinfo name for ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00120fd0 @ 00120fd0

undefined8 FUN_00120fd0(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  undefined8 uVar4;
  byte *pbVar5;
  byte *pbVar6;
  
  pbVar2 = (byte *)*param_1;
  pbVar1 = (byte *)param_1[1];
  if (pbVar2 == pbVar1) {
    return 1;
  }
  if (*pbVar2 == 0x68) {
    pbVar5 = pbVar2 + 1;
    *param_1 = (long)pbVar5;
    if (pbVar5 == pbVar1) {
      return 1;
    }
    pbVar3 = pbVar5;
    if (*pbVar5 == 0x6e) {
      pbVar3 = pbVar2 + 2;
      *param_1 = (long)pbVar3;
    }
    if (pbVar1 == pbVar3) {
      return 1;
    }
    if (*pbVar3 - 0x3a < 0xfffffff6) {
      return 1;
    }
    pbVar2 = pbVar3 + 1;
    do {
      pbVar3 = pbVar2;
      *param_1 = (long)pbVar3;
      if (pbVar3 == pbVar1) goto LAB_00121168;
      pbVar2 = pbVar3 + 1;
    } while (0xfffffff5 < *pbVar3 - 0x3a);
  }
  else {
    if (*pbVar2 != 0x76) {
      return 1;
    }
    pbVar5 = pbVar2 + 1;
    *param_1 = (long)pbVar5;
    if (pbVar5 == pbVar1) {
      return 1;
    }
    pbVar3 = pbVar5;
    if (*pbVar5 == 0x6e) {
      pbVar3 = pbVar2 + 2;
      *param_1 = (long)pbVar3;
    }
    if (pbVar1 == pbVar3) {
      return 1;
    }
    if (*pbVar3 - 0x3a < 0xfffffff6) {
      return 1;
    }
    do {
      pbVar2 = pbVar3;
      pbVar3 = pbVar2 + 1;
      *param_1 = (long)pbVar3;
      if (pbVar3 == pbVar1) {
        pbVar6 = pbVar1;
        goto LAB_001210dc;
      }
    } while (0xfffffff5 < *pbVar3 - 0x3a);
    pbVar6 = pbVar3;
LAB_001210dc:
    if (pbVar5 == pbVar6) {
      return 1;
    }
    if (pbVar3 == pbVar1) {
      return 1;
    }
    if (*pbVar3 != 0x5f) {
      return 1;
    }
    pbVar5 = pbVar2 + 2;
    *param_1 = (long)pbVar5;
    if (pbVar5 == pbVar1) {
      return 1;
    }
    pbVar3 = pbVar5;
    if (*pbVar5 == 0x6e) {
      pbVar3 = pbVar2 + 3;
      *param_1 = (long)pbVar3;
    }
    if (pbVar1 == pbVar3) {
      return 1;
    }
    if (*pbVar3 - 0x3a < 0xfffffff6) {
      return 1;
    }
    pbVar2 = pbVar3 + 1;
    do {
      pbVar3 = pbVar2;
      *param_1 = (long)pbVar3;
      if (pbVar3 == pbVar1) goto LAB_00121168;
      pbVar2 = pbVar3 + 1;
    } while (0xfffffff5 < *pbVar3 - 0x3a);
  }
  pbVar2 = pbVar2 + -1;
LAB_0012116c:
  uVar4 = 1;
  if ((pbVar5 != pbVar2) && (pbVar3 != pbVar1)) {
    if (*pbVar3 != 0x5f) {
      return 1;
    }
    uVar4 = 0;
    *param_1 = (long)(pbVar3 + 1);
  }
  return uVar4;
LAB_00121168:
  pbVar2 = pbVar1;
  goto LAB_0012116c;
}


// ==== FUN_001211ac @ 001211ac

void FUN_001211ac(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "covariant return thunk to ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_0012124c @ 0012124c

void FUN_0012124c(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar4 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c4d0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010115;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar4;
  return;
}


// ==== FUN_001212e4 @ 001212e4

void FUN_001212e4(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "thread-local initialization routine for ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00121384 @ 00121384

void FUN_00121384(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "virtual thunk to ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00121424 @ 00121424

void FUN_00121424(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c450;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010114;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "non-virtual thunk to ";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_001215d0 @ 001215d0

void FUN_001215d0(void)

{
  return;
}


// ==== FUN_001215d8 @ 001215d8

undefined1  [16] FUN_001215d8(void)

{
  return ZEXT816(0);
}


// ==== free @ 001215e8

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== FUN_00121764 @ 00121764

undefined8 * FUN_00121764(long *param_1)

{
  byte *pbVar1;
  byte bVar2;
  long lVar3;
  undefined8 *puVar4;
  undefined4 uVar5;
  long lVar6;
  byte *pbVar7;
  byte *pbVar8;
  uint uVar9;
  long lVar10;
  undefined8 *puVar11;
  undefined8 *local_40;
  long local_38;
  
  lVar3 = tpidr_el0;
  local_38 = *(long *)(lVar3 + 0x28);
  pbVar7 = (byte *)*param_1;
  pbVar1 = (byte *)param_1[1];
  if ((pbVar7 != pbVar1) && (*pbVar7 == 0x53)) {
    pbVar8 = pbVar7 + 1;
    *param_1 = (long)pbVar8;
    if (pbVar1 != pbVar8) {
      if (0xffffffe5 < *pbVar8 - 0x7b) {
        puVar4 = (undefined8 *)0x0;
        switch((uint)*pbVar8) {
        case 0x61:
          puVar11 = (undefined8 *)param_1[0x266];
          *param_1 = (long)(pbVar7 + 2);
          lVar6 = puVar11[1];
          if (lVar6 - 0xfe0U < 0xfffffffffffff00f || lVar6 == -0x11) {
            puVar4 = malloc(0x1000);
            if (puVar4 == (void *)0x0) {
LAB_00121aec:
                    /* WARNING: Subroutine does not return */
              FUN_0011dc6c();
            }
            uVar5 = 0;
LAB_001219cc:
            lVar6 = 0;
            *puVar4 = puVar11;
            puVar4[1] = 0;
            param_1[0x266] = (long)puVar4;
            puVar11 = puVar4;
          }
          else {
            uVar5 = 0;
          }
          break;
        case 0x62:
          puVar11 = (undefined8 *)param_1[0x266];
          *param_1 = (long)(pbVar7 + 2);
          lVar6 = puVar11[1];
          if (lVar6 - 0xfe0U < 0xfffffffffffff00f || lVar6 == -0x11) {
            puVar4 = malloc(0x1000);
            if (puVar4 == (undefined8 *)0x0) goto LAB_00121aec;
            uVar5 = 1;
            goto LAB_001219cc;
          }
          uVar5 = 1;
          break;
        default:
          goto code_r0x00121878;
        case 100:
          puVar11 = (undefined8 *)param_1[0x266];
          *param_1 = (long)(pbVar7 + 2);
          lVar6 = puVar11[1];
          if (lVar6 - 0xfe0U < 0xfffffffffffff00f || lVar6 == -0x11) {
            puVar4 = malloc(0x1000);
            if (puVar4 == (undefined8 *)0x0) goto LAB_00121aec;
            uVar5 = 5;
            goto LAB_001219cc;
          }
          uVar5 = 5;
          break;
        case 0x69:
          puVar11 = (undefined8 *)param_1[0x266];
          *param_1 = (long)(pbVar7 + 2);
          lVar6 = puVar11[1];
          if (lVar6 - 0xfe0U < 0xfffffffffffff00f || lVar6 == -0x11) {
            puVar4 = malloc(0x1000);
            if (puVar4 == (undefined8 *)0x0) goto LAB_00121aec;
            uVar5 = 3;
            goto LAB_001219cc;
          }
          uVar5 = 3;
          break;
        case 0x6f:
          puVar11 = (undefined8 *)param_1[0x266];
          *param_1 = (long)(pbVar7 + 2);
          lVar6 = puVar11[1];
          if (lVar6 - 0xfe0U < 0xfffffffffffff00f || lVar6 == -0x11) {
            puVar4 = malloc(0x1000);
            if (puVar4 == (undefined8 *)0x0) goto LAB_00121aec;
            uVar5 = 4;
            goto LAB_001219cc;
          }
          uVar5 = 4;
          break;
        case 0x73:
          puVar11 = (undefined8 *)param_1[0x266];
          *param_1 = (long)(pbVar7 + 2);
          lVar6 = puVar11[1];
          if (lVar6 - 0xfe0U < 0xfffffffffffff00f || lVar6 == -0x11) {
            puVar4 = malloc(0x1000);
            if (puVar4 == (undefined8 *)0x0) goto LAB_00121aec;
            uVar5 = 2;
            goto LAB_001219cc;
          }
          uVar5 = 2;
        }
        puVar11[1] = lVar6 + 0x10;
        puVar4 = (undefined8 *)((long)puVar11 + lVar6 + 0x10);
        *puVar4 = &PTR_LAB_0013db20;
        *(undefined4 *)((long)puVar11 + lVar6 + 0x18) = 0x1010129;
        *(undefined4 *)((long)puVar11 + lVar6 + 0x1c) = uVar5;
        puVar11 = (undefined8 *)FUN_0012249c(param_1,puVar4);
        local_40 = puVar11;
        if (puVar11 != puVar4) {
          FUN_00120b24(param_1 + 0x25,&local_40);
          puVar4 = puVar11;
        }
        goto code_r0x00121878;
      }
      if (*pbVar8 == 0x5f) {
        *param_1 = (long)(pbVar7 + 2);
        if ((undefined8 *)param_1[0x25] != (undefined8 *)param_1[0x26]) {
          puVar4 = *(undefined8 **)param_1[0x25];
          goto code_r0x00121878;
        }
      }
      else {
        bVar2 = *pbVar8;
        uVar9 = (uint)bVar2;
        if ((0x2f < bVar2) && ((bVar2 < 0x3a || (bVar2 - 0x41 < 0x1a)))) {
          lVar6 = 0;
          pbVar7 = pbVar7 + 2;
          do {
            if (uVar9 < 0x3a) {
              lVar10 = -0x30;
            }
            else {
              if (0x19 < uVar9 - 0x41) break;
              lVar10 = -0x37;
            }
            *param_1 = (long)pbVar7;
            if (pbVar7 == pbVar1) goto LAB_00121870;
            bVar2 = (byte)uVar9;
            pbVar8 = pbVar7 + 1;
            uVar9 = (uint)*pbVar7;
            lVar6 = lVar6 * 0x24 + (ulong)bVar2 + lVar10;
            pbVar7 = pbVar8;
          } while (0x2f < uVar9);
          if ((pbVar7 + -1 != pbVar1) && (pbVar7[-1] == 0x5f)) {
            *param_1 = (long)pbVar7;
            if (lVar6 + 1U < (ulong)(param_1[0x26] - param_1[0x25] >> 3)) {
              puVar4 = *(undefined8 **)(param_1[0x25] + (lVar6 + 1U) * 8);
              goto code_r0x00121878;
            }
          }
        }
      }
    }
  }
LAB_00121870:
  puVar4 = (undefined8 *)0x0;
code_r0x00121878:
  if (*(long *)(lVar3 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar4;
}


// ==== FUN_00121af4 @ 00121af4

void FUN_00121af4(long *param_1,ulong param_2)

{
  long *plVar1;
  long *plVar2;
  char *pcVar3;
  long lVar4;
  long lVar5;
  undefined8 *puVar6;
  long *plVar7;
  undefined8 *puVar8;
  long lVar9;
  long lVar10;
  long lVar11;
  long *plVar12;
  long lVar13;
  long *plVar14;
  long lVar15;
  void *pvVar16;
  undefined1 auVar17 [16];
  undefined8 *local_b0;
  undefined8 *local_a8;
  long *local_a0;
  long *local_98;
  long *local_90;
  long local_88 [5];
  
  lVar5 = tpidr_el0;
  local_88[4] = *(long *)(lVar5 + 0x28);
  pcVar3 = (char *)*param_1;
  if ((pcVar3 != (char *)param_1[1]) && (*pcVar3 == 'I')) {
    *param_1 = (long)(pcVar3 + 1);
    if ((param_2 & 1) != 0) {
      local_a0 = param_1 + 0x48;
      param_1[0x54] = param_1[0x53];
      FUN_001229cc(param_1 + 0x53,&local_a0);
      param_1[0x49] = param_1[0x48];
    }
    plVar1 = local_88 + 4;
    plVar14 = param_1 + 2;
    lVar15 = *plVar14;
    lVar4 = param_1[3];
    plVar2 = param_1 + 0x56;
LAB_00121bac:
    while ((pcVar3 = (char *)*param_1, pcVar3 == (char *)param_1[1] || (*pcVar3 != 'E'))) {
      if ((param_2 & 1) != 0) {
        local_a0 = (long *)param_1[0x53];
        local_88[1] = 0;
        local_88[0] = 0;
        local_88[3] = 0;
        local_88[2] = 0;
        local_90 = plVar1;
        if (local_a0 == plVar2) {
          if (param_1[0x54] - (long)plVar2 == 0) {
            lVar10 = 0;
            plVar7 = plVar2;
            local_a0 = local_88;
          }
          else {
            local_a0 = local_88;
            local_98 = local_88;
            __memmove_chk(local_88,plVar2,param_1[0x54] - (long)plVar2,0x20);
            lVar10 = param_1[0x54] - param_1[0x53] >> 3;
            plVar7 = (long *)param_1[0x53];
          }
          local_98 = local_a0 + lVar10;
          param_1[0x54] = (long)plVar7;
        }
        else {
          local_98 = (long *)param_1[0x54];
          param_1[0x53] = (long)plVar2;
          local_90 = (long *)param_1[0x55];
          param_1[0x54] = (long)plVar2;
          param_1[0x55] = (long)(param_1 + 0x5a);
        }
                    /* try { // try from 00121c70 to 00121c77 has its CatchHandler @ 00121f50 */
        puVar6 = (undefined8 *)FUN_00120934(param_1);
        plVar7 = (long *)param_1[0x53];
        plVar12 = local_88;
        local_a8 = puVar6;
        if (local_a0 != local_88) {
          param_1[0x53] = (long)local_a0;
          if (plVar7 == plVar2) {
            param_1[0x54] = (long)local_98;
            param_1[0x55] = (long)local_90;
            local_a0 = local_88;
            local_98 = local_88;
            local_90 = plVar1;
            if (puVar6 != (undefined8 *)0x0) goto LAB_00121d48;
            goto LAB_00121e60;
          }
          plVar12 = (long *)param_1[0x55];
          param_1[0x54] = (long)local_98;
          param_1[0x55] = (long)local_90;
          local_a0 = plVar7;
          local_98 = plVar7;
          local_90 = plVar12;
          if (puVar6 == (undefined8 *)0x0) {
            plVar12 = plVar7;
            goto LAB_00121e60;
          }
LAB_00121d48:
          FUN_00120b24(plVar14,&local_a8);
          local_b0 = puVar6;
          if (*(char *)(puVar6 + 1) == '!') {
            pvVar16 = (void *)param_1[0x266];
            plVar7 = (long *)puVar6[2];
            lVar10 = puVar6[3];
            lVar9 = *(long *)((long)pvVar16 + 8);
            puVar8 = pvVar16;
            if (lVar9 - 0xfd0U < 0xfffffffffffff00f || lVar9 == -0x21) {
              puVar8 = malloc(0x1000);
              if (puVar8 == (void *)0x0) {
LAB_00121f48:
                    /* WARNING: Subroutine does not return */
                FUN_0011dc6c();
              }
              lVar9 = 0;
              *puVar8 = pvVar16;
              puVar8[1] = 0;
              param_1[0x266] = (long)puVar8;
            }
            *(long *)((long)puVar8 + 8) = lVar9 + 0x20;
            local_b0 = (undefined8 *)((long)puVar8 + lVar9 + 0x10);
            *local_b0 = &PTR_LAB_0013db90;
            *(undefined2 *)((long)puVar8 + lVar9 + 0x19) = 0x202;
            *(long **)((long)puVar8 + lVar9 + 0x20) = plVar7;
            *(long *)((long)puVar8 + lVar9 + 0x28) = lVar10;
            *(undefined1 *)((long)puVar8 + lVar9 + 0x18) = 0x20;
            lVar11 = lVar10 << 3;
            *(undefined1 *)((long)puVar8 + lVar9 + 0x1b) = 2;
            if (lVar10 != 0) {
              lVar13 = lVar11;
              plVar12 = plVar7;
              do {
                if (*(char *)(*plVar12 + 10) != '\x01') goto LAB_00121dfc;
                lVar13 = lVar13 + -8;
                plVar12 = plVar12 + 1;
              } while (lVar13 != 0);
            }
            *(undefined1 *)((long)puVar8 + lVar9 + 0x1a) = 1;
LAB_00121dfc:
            if (lVar10 != 0) {
              lVar13 = lVar11;
              plVar12 = plVar7;
              do {
                if (*(char *)(*plVar12 + 0xb) != '\x01') goto joined_r0x00121e24;
                lVar13 = lVar13 + -8;
                plVar12 = plVar12 + 1;
              } while (lVar13 != 0);
            }
            *(undefined1 *)((long)puVar8 + lVar9 + 0x1b) = 1;
joined_r0x00121e24:
            do {
              if (lVar10 == 0) goto LAB_00121e40;
              if (*(char *)(*plVar7 + 9) != '\x01') break;
              lVar11 = lVar11 + -8;
              plVar7 = plVar7 + 1;
              lVar10 = lVar11;
            } while( true );
          }
          goto LAB_00121e4c;
        }
        if (plVar7 != plVar2) {
          free(plVar7);
          param_1[0x53] = (long)plVar2;
          param_1[0x54] = (long)plVar2;
          param_1[0x55] = (long)(param_1 + 0x5a);
          plVar7 = plVar2;
          plVar12 = local_a0;
        }
        if ((long)local_98 - (long)plVar12 == 0) {
          lVar10 = 0;
          plVar7 = plVar2;
        }
        else {
          memmove(plVar7,plVar12,(long)local_98 - (long)plVar12);
          lVar10 = (long)local_98 - (long)local_a0 >> 3;
          plVar12 = local_a0;
          plVar7 = (long *)param_1[0x53];
        }
        param_1[0x54] = (long)(plVar7 + lVar10);
        local_98 = plVar12;
        if (puVar6 != (undefined8 *)0x0) goto LAB_00121d48;
        goto LAB_00121e60;
      }
      local_a0 = (long *)FUN_00120934(param_1);
      puVar6 = (undefined8 *)0x0;
      if (local_a0 == (long *)0x0) goto LAB_00121f14;
      FUN_00120b24(plVar14,&local_a0);
    }
    *param_1 = (long)(pcVar3 + 1);
    lVar15 = (lVar4 - lVar15 >> 3) * 8;
    auVar17 = FUN_0012a7b8(param_1,param_1[2] + lVar15,param_1[3]);
    pvVar16 = (void *)param_1[0x266];
    param_1[3] = param_1[2] + lVar15;
    lVar15 = *(long *)((long)pvVar16 + 8);
    puVar8 = pvVar16;
    if (lVar15 - 0xfd0U < 0xfffffffffffff00f || lVar15 == -0x21) {
      puVar8 = malloc(0x1000);
      if (puVar8 == (void *)0x0) goto LAB_00121f48;
      lVar15 = 0;
      *puVar8 = pvVar16;
      puVar8[1] = 0;
      param_1[0x266] = (long)puVar8;
    }
    *(long *)((long)puVar8 + 8) = lVar15 + 0x20;
    puVar6 = (undefined8 *)((long)puVar8 + lVar15 + 0x10);
    *puVar6 = &PTR_LAB_0013dc00;
    *(undefined4 *)((long)puVar8 + lVar15 + 0x18) = 0x1010123;
    *(undefined1 (*) [16])((long)puVar8 + lVar15 + 0x20) = auVar17;
    goto LAB_00121f14;
  }
  puVar6 = (undefined8 *)0x0;
LAB_00121f14:
  if (*(long *)(lVar5 + 0x28) != local_88[4]) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar6);
  }
  return;
LAB_00121e40:
  *(undefined1 *)((long)puVar8 + lVar9 + 0x19) = 1;
LAB_00121e4c:
  FUN_00128824(*(undefined8 *)(param_1[0x54] + -8),&local_b0);
  plVar12 = local_a0;
LAB_00121e60:
  if (plVar12 != local_88) {
    free(plVar12);
  }
  if (puVar6 == (undefined8 *)0x0) goto LAB_00121f0c;
  goto LAB_00121bac;
LAB_00121f0c:
  puVar6 = (undefined8 *)0x0;
  goto LAB_00121f14;
}


// ==== FUN_00121f70 @ 00121f70

void FUN_00121f70(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar4 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013dc70;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010125;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar4;
  return;
}


// ==== FUN_00122008 @ 00122008

undefined8 * FUN_00122008(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 *puVar4;
  ulong uVar5;
  long lVar6;
  long lVar7;
  ulong uVar8;
  byte *pbVar9;
  byte *pbVar10;
  undefined8 *puVar11;
  ulong uVar12;
  size_t __n;
  void *pvVar13;
  long *plVar14;
  undefined8 local_50;
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  pbVar1 = (byte *)*param_1;
  pbVar2 = (byte *)param_1[1];
  if ((pbVar1 != pbVar2) && (*pbVar1 == 0x54)) {
    pbVar10 = pbVar1 + 1;
    *param_1 = (long)pbVar10;
    if (pbVar10 != pbVar2) {
      if (*pbVar10 == 0x4c) {
        pbVar10 = pbVar1 + 2;
        *param_1 = (long)pbVar10;
        if ((pbVar2 != pbVar10) && (0xfffffff5 < *pbVar10 - 0x3a)) {
          lVar6 = 0;
          pbVar1 = pbVar1 + 4;
          do {
            pbVar10 = pbVar1;
            pbVar9 = pbVar10 + -1;
            *param_1 = (long)pbVar9;
            lVar7 = (ulong)pbVar10[-2] + lVar6 * 10;
            lVar6 = lVar7 + -0x30;
            if (pbVar9 == pbVar2) break;
            pbVar1 = pbVar10 + 1;
          } while (pbVar10[-1] - 0x30 < 10);
          if ((pbVar9 != pbVar2) && (pbVar10[-1] == 0x5f)) {
            uVar8 = lVar7 - 0x2f;
            *param_1 = (long)pbVar10;
            goto joined_r0x001220fc;
          }
        }
      }
      else {
        uVar8 = 0;
joined_r0x001220fc:
        if (pbVar10 != pbVar2) {
          if (*pbVar10 == 0x5f) {
            uVar12 = 0;
LAB_00122110:
            *param_1 = (long)(pbVar10 + 1);
            if ((*(char *)((long)param_1 + 0x309) == '\0') || (uVar8 != 0)) {
              uVar5 = param_1[0x54] - param_1[0x53] >> 3;
              if ((uVar8 < uVar5) &&
                 ((plVar14 = *(long **)(param_1[0x53] + uVar8 * 8), plVar14 != (long *)0x0 &&
                  (uVar12 < (ulong)(plVar14[1] - *plVar14 >> 3))))) {
                puVar11 = *(undefined8 **)(*plVar14 + uVar12 * 8);
              }
              else {
                puVar11 = (undefined8 *)0x0;
                if ((param_1[0x62] == uVar8) && (uVar8 <= uVar5)) {
                  if (uVar8 == uVar5) {
                    local_50 = 0;
                    FUN_001229cc(param_1 + 0x53,&local_50);
                  }
                  pvVar13 = (void *)param_1[0x266];
                  lVar6 = *(long *)((long)pvVar13 + 8);
                  puVar4 = pvVar13;
                  if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
                    puVar4 = malloc(0x1000);
                    if (puVar4 == (void *)0x0) goto LAB_00122374;
                    lVar6 = 0;
                    *puVar4 = pvVar13;
                    puVar4[1] = 0;
                    param_1[0x266] = (long)puVar4;
                  }
                  *(long *)((long)puVar4 + 8) = lVar6 + 0x20;
                  puVar11 = (undefined8 *)((long)puVar4 + lVar6 + 0x10);
                  *puVar11 = &PTR_LAB_0013c540;
                  *(undefined4 *)((long)puVar4 + lVar6 + 0x18) = 0x1010107;
                  *(undefined **)((long)puVar4 + lVar6 + 0x20) = &DAT_0010a0c8;
                  *(undefined **)((long)puVar4 + lVar6 + 0x28) = &DAT_0010a0cc;
                }
              }
            }
            else {
              pvVar13 = (void *)param_1[0x266];
              lVar6 = *(long *)((long)pvVar13 + 8);
              puVar4 = pvVar13;
              if (lVar6 - 0xfc0U < 0xfffffffffffff00f || lVar6 == -0x31) {
                puVar4 = malloc(0x1000);
                if (puVar4 == (void *)0x0) goto LAB_00122374;
                lVar6 = 0;
                *puVar4 = pvVar13;
                puVar4[1] = 0;
                param_1[0x266] = (long)puVar4;
              }
              *(long *)((long)puVar4 + 8) = lVar6 + 0x30;
              puVar11 = (undefined8 *)((long)puVar4 + lVar6 + 0x10);
              *puVar11 = &PTR_FUN_0013c620;
              *(undefined4 *)((long)puVar4 + lVar6 + 0x18) = 0x2020224;
              *(ulong *)((long)puVar4 + lVar6 + 0x20) = uVar12;
              *(undefined8 *)((long)puVar4 + lVar6 + 0x28) = 0;
              *(undefined1 *)((long)puVar4 + lVar6 + 0x30) = 0;
              puVar4 = (undefined8 *)param_1[0x5b];
              if (puVar4 == (undefined8 *)param_1[0x5c]) {
                plVar14 = (long *)param_1[0x5a];
                __n = (long)puVar4 - (long)plVar14;
                if (plVar14 == param_1 + 0x5d) {
                  pvVar13 = malloc(__n * 2);
                  if (pvVar13 == (void *)0x0) goto LAB_00122374;
                  if (__n != 0) {
                    memmove(pvVar13,plVar14,__n);
                  }
                  param_1[0x5a] = (long)pvVar13;
                }
                else {
                  pvVar13 = realloc(plVar14,__n * 2);
                  param_1[0x5a] = (long)pvVar13;
                  if (pvVar13 == (void *)0x0) {
LAB_00122374:
                    /* WARNING: Subroutine does not return */
                    FUN_0011dc6c();
                  }
                }
                puVar4 = (undefined8 *)((long)pvVar13 + ((long)__n >> 3) * 8);
                param_1[0x5c] = (long)((long)pvVar13 + ((long)__n >> 2) * 8);
              }
              param_1[0x5b] = (long)(puVar4 + 1);
              *puVar4 = puVar11;
            }
            goto LAB_0012222c;
          }
          if (0xfffffff5 < *pbVar10 - 0x3a) {
            lVar6 = 0;
            pbVar1 = pbVar10;
            do {
              pbVar10 = pbVar1 + 1;
              *param_1 = (long)pbVar10;
              lVar7 = (ulong)*pbVar1 + lVar6 * 10;
              lVar6 = lVar7 + -0x30;
              if (pbVar10 == pbVar2) break;
              pbVar1 = pbVar10;
            } while (*pbVar10 - 0x30 < 10);
            if ((pbVar10 != pbVar2) && (*pbVar10 == 0x5f)) {
              uVar12 = lVar7 - 0x2f;
              goto LAB_00122110;
            }
          }
        }
      }
    }
  }
  puVar11 = (undefined8 *)0x0;
LAB_0012222c:
  if (*(long *)(lVar3 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar11;
}


// ==== FUN_0012237c @ 0012237c

undefined8 * FUN_0012237c(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  char *pcVar3;
  long lVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  long lVar7;
  void *pvVar8;
  
  pbVar2 = (byte *)*param_1;
  if ((pbVar2 != (byte *)param_1[1]) && (*pbVar2 == 0x44)) {
    pbVar1 = pbVar2 + 1;
    *param_1 = (long)pbVar1;
    if ((pbVar1 != (byte *)param_1[1]) && ((*pbVar1 | 0x20) == 0x74)) {
      *param_1 = (long)(pbVar2 + 2);
      lVar4 = FUN_00122d94(param_1);
      if (lVar4 == 0) {
        return (undefined8 *)0x0;
      }
      pcVar3 = (char *)*param_1;
      if ((pcVar3 != (char *)param_1[1]) && (*pcVar3 == 'E')) {
        pvVar8 = (void *)param_1[0x266];
        lVar7 = *(long *)((long)pvVar8 + 8);
        *param_1 = (long)(pcVar3 + 1);
        puVar5 = pvVar8;
        if (lVar7 - 0xfb0U < 0xfffffffffffff00f || lVar7 == -0x41) {
          puVar5 = malloc(0x1000);
          if (puVar5 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar7 = 0;
          *puVar5 = pvVar8;
          puVar5[1] = 0;
          param_1[0x266] = (long)puVar5;
        }
        *(long *)((long)puVar5 + 8) = lVar7 + 0x40;
        puVar6 = (undefined8 *)((long)puVar5 + lVar7 + 0x10);
        *puVar6 = &PTR_LAB_0013d650;
        *(long *)((long)puVar5 + lVar7 + 0x30) = lVar4;
        *(undefined **)((long)puVar5 + lVar7 + 0x38) = &DAT_0010b201;
        *(undefined4 *)((long)puVar5 + lVar7 + 0x18) = 0x1010134;
        *(char **)((long)puVar5 + lVar7 + 0x20) = "decltype(";
        *(char **)((long)puVar5 + lVar7 + 0x28) = "";
        *(undefined **)((long)puVar5 + lVar7 + 0x40) = &DAT_0010b202;
        return puVar6;
      }
    }
  }
  return (undefined8 *)0x0;
}


// ==== FUN_0012249c @ 0012249c

undefined8 * FUN_0012249c(long *param_1,undefined8 *param_2)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined8 *puVar3;
  byte *pbVar4;
  long lVar5;
  byte *pbVar6;
  ulong uVar7;
  undefined8 *puVar8;
  byte *pbVar9;
  void *pvVar10;
  
  pbVar6 = (byte *)*param_1;
  pbVar4 = (byte *)param_1[1];
  puVar8 = param_2;
  if (pbVar6 != pbVar4) {
    do {
      if (*pbVar6 != 0x42) {
        return puVar8;
      }
      pbVar9 = pbVar6 + 1;
      *param_1 = (long)pbVar9;
      if ((pbVar4 == pbVar9) || (*pbVar9 - 0x3a < 0xfffffff6)) {
        return (undefined8 *)0x0;
      }
      uVar7 = 0;
      pbVar6 = pbVar6 + 2;
      do {
        pbVar9 = pbVar6;
        *param_1 = (long)pbVar9;
        uVar7 = ((ulong)pbVar9[-1] + uVar7 * 10) - 0x30;
        if (pbVar9 == pbVar4) {
          pbVar9 = pbVar4;
          goto LAB_00122588;
        }
        pbVar6 = pbVar9 + 1;
      } while (*pbVar9 - 0x30 < 10);
LAB_00122588:
      if ((ulong)((long)pbVar4 - (long)pbVar9) < uVar7) {
        return (undefined8 *)0x0;
      }
      pbVar6 = pbVar9 + uVar7;
      *param_1 = (long)pbVar6;
      if (pbVar9 == pbVar6) {
        return (undefined8 *)0x0;
      }
      pvVar10 = (void *)param_1[0x266];
      lVar5 = *(long *)((long)pvVar10 + 8);
      puVar3 = pvVar10;
      if (lVar5 - 0xfc0U < 0xfffffffffffff00f || lVar5 == -0x31) {
        puVar3 = malloc(0x1000);
        if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0011dc6c();
        }
        lVar5 = 0;
        *puVar3 = pvVar10;
        puVar3[1] = 0;
        param_1[0x266] = (long)puVar3;
      }
      uVar1 = *(undefined1 *)((long)puVar8 + 0xb);
      *(long *)((long)puVar3 + 8) = lVar5 + 0x30;
      param_2 = (undefined8 *)((long)puVar3 + lVar5 + 0x10);
      *param_2 = &PTR_LAB_0013d9d0;
      uVar2 = *(undefined2 *)((long)puVar8 + 9);
      *(byte **)((long)puVar3 + lVar5 + 0x28) = pbVar9;
      *(byte **)((long)puVar3 + lVar5 + 0x30) = pbVar6;
      *(undefined8 **)((long)puVar3 + lVar5 + 0x20) = puVar8;
      *(undefined1 *)((long)puVar3 + lVar5 + 0x18) = 8;
      *(undefined2 *)((long)puVar3 + lVar5 + 0x19) = uVar2;
      pbVar6 = (byte *)*param_1;
      pbVar4 = (byte *)param_1[1];
      *(undefined1 *)((long)puVar3 + lVar5 + 0x1b) = uVar1;
      puVar8 = param_2;
    } while (pbVar6 != pbVar4);
  }
  return param_2;
}


// ==== FUN_00122618 @ 00122618

undefined8 FUN_00122618(long *param_1)

{
  byte *pbVar1;
  char *pcVar2;
  long lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  long lVar7;
  long lVar8;
  void *pvVar9;
  undefined1 auVar10 [16];
  long local_50;
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  pbVar1 = (byte *)*param_1;
  if ((byte *)param_1[1] == pbVar1) {
LAB_00122690:
    if ((((ulong)(param_1[1] - (long)pbVar1) < 2) || (*pbVar1 != 0x44)) || (pbVar1[1] != 0x43)) {
      puVar4 = (undefined8 *)FUN_0012b288(param_1);
joined_r0x001227ac:
      if (puVar4 != (undefined8 *)0x0) goto LAB_001227b0;
    }
    else {
      lVar8 = param_1[3];
      lVar7 = param_1[2];
      *param_1 = (long)(pbVar1 + 2);
      local_50 = FUN_0012af08(param_1);
      if (local_50 != 0) {
        do {
          FUN_00120b24(param_1 + 2,&local_50);
          pcVar2 = (char *)*param_1;
          if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'E')) {
            lVar7 = (lVar8 - lVar7 >> 3) * 8;
            *param_1 = (long)(pcVar2 + 1);
            auVar10 = FUN_0012a7b8(param_1,param_1[2] + lVar7,param_1[3]);
            pvVar9 = (void *)param_1[0x266];
            param_1[3] = param_1[2] + lVar7;
            lVar7 = *(long *)((long)pvVar9 + 8);
            puVar5 = pvVar9;
            if (lVar7 - 0xfd0U < 0xfffffffffffff00f || lVar7 == -0x21) {
              puVar5 = malloc(0x1000);
              if (puVar5 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
                FUN_0011dc6c();
              }
              lVar7 = 0;
              *puVar5 = pvVar9;
              puVar5[1] = 0;
              param_1[0x266] = (long)puVar5;
            }
            *(long *)((long)puVar5 + 8) = lVar7 + 0x20;
            puVar4 = (undefined8 *)((long)puVar5 + lVar7 + 0x10);
            *puVar4 = &PTR_LAB_0013da40;
            *(undefined4 *)((long)puVar5 + lVar7 + 0x18) = 0x101012e;
            *(undefined1 (*) [16])((long)puVar5 + lVar7 + 0x20) = auVar10;
            goto LAB_001227b0;
          }
          local_50 = FUN_0012af08(param_1);
        } while (local_50 != 0);
      }
    }
LAB_001227cc:
    if (*(long *)(lVar3 + 0x28) != local_48) {
LAB_00122800:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
    uVar6 = 0;
  }
  else {
    if (*pbVar1 == 0x55) {
      puVar4 = (undefined8 *)FUN_00126e78(param_1);
      goto joined_r0x001227ac;
    }
    if (8 < *pbVar1 - 0x31) goto LAB_00122690;
    puVar4 = (undefined8 *)FUN_0012af08(param_1);
    if (puVar4 == (undefined8 *)0x0) goto LAB_001227cc;
LAB_001227b0:
    uVar6 = FUN_0012249c(param_1,puVar4);
    if (*(long *)(lVar3 + 0x28) != local_48) goto LAB_00122800;
  }
  return uVar6;
}


// ==== FUN_00122804 @ 00122804

void FUN_00122804(long param_1,undefined8 *param_2)

{
  ulong __size;
  void *__src;
  size_t __n;
  void *pvVar1;
  ulong uVar2;
  long lVar3;
  
  __src = *(void **)(param_1 + 0x10);
  __n = *(long *)(param_1 + 0x18) - (long)__src;
  if (__n != 0) {
    lVar3 = param_2[1];
    __size = lVar3 + __n;
    if (__size < (ulong)param_2[2]) {
      pvVar1 = (void *)*param_2;
    }
    else {
      uVar2 = param_2[2] << 1;
      if (__size <= uVar2) {
        __size = uVar2;
      }
      param_2[2] = __size;
      pvVar1 = realloc((void *)*param_2,__size);
      *param_2 = pvVar1;
      if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar3 = param_2[1];
    }
    memmove((void *)((long)pvVar1 + lVar3),__src,__n);
    param_2[1] = param_2[1] + __n;
  }
  return;
}


// ==== FUN_001229cc @ 001229cc

void FUN_001229cc(undefined8 *param_1,undefined8 *param_2)

{
  void *__dest;
  undefined8 *puVar1;
  undefined8 uVar2;
  size_t __n;
  undefined8 *__src;
  
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 == (undefined8 *)param_1[2]) {
    __src = (undefined8 *)*param_1;
    __n = (long)puVar1 - (long)__src;
    if (__src == param_1 + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_00122a8c;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *param_1 = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *param_1 = __dest;
      if (__dest == (void *)0x0) {
LAB_00122a8c:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
    }
    puVar1 = (undefined8 *)((long)__dest + ((long)__n >> 3) * 8);
    param_1[1] = puVar1;
    param_1[2] = (void *)((long)__dest + ((long)__n >> 2) * 8);
  }
  uVar2 = *param_2;
  param_1[1] = puVar1 + 1;
  *puVar1 = uVar2;
  return;
}


// ==== FUN_00122a90 @ 00122a90

undefined8 * FUN_00122a90(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_00122b2c @ 00122b2c

byte FUN_00122b2c(long param_1)

{
  char cVar1;
  byte bVar2;
  
  if (*(char *)(param_1 + 0x20) == '\0') {
    cVar1 = *(char *)((long)*(undefined8 **)(param_1 + 0x18) + 9);
    *(undefined1 *)(param_1 + 0x20) = 1;
    if (cVar1 == '\x02') {
                    /* try { // try from 00122b70 to 00122b73 has its CatchHandler @ 00122b9c */
      bVar2 = (**(code **)**(undefined8 **)(param_1 + 0x18))();
    }
    else {
      bVar2 = cVar1 == '\0';
    }
    *(undefined1 *)(param_1 + 0x20) = 0;
  }
  else {
    bVar2 = 0;
  }
  return bVar2 & 1;
}


// ==== FUN_00122d94 @ 00122d94

void FUN_00122d94(long *param_1)

{
  char *pcVar1;
  char *pcVar2;
  char cVar3;
  long lVar4;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined8 uVar19;
  undefined *puVar20;
  char *pcVar21;
  undefined *puVar22;
  ulong uVar23;
  long lVar24;
  long lVar25;
  long local_60;
  undefined1 local_58 [16];
  ulong local_48;
  undefined1 local_3c [4];
  long local_38;
  
  auVar18._8_8_ = local_58._8_8_;
  auVar18._0_8_ = local_58._0_8_;
  auVar17._8_8_ = local_58._8_8_;
  auVar17._0_8_ = local_58._0_8_;
  auVar16._8_8_ = local_58._8_8_;
  auVar16._0_8_ = local_58._0_8_;
  auVar15._8_8_ = local_58._8_8_;
  auVar15._0_8_ = local_58._0_8_;
  auVar14._8_8_ = local_58._8_8_;
  auVar14._0_8_ = local_58._0_8_;
  auVar13._8_8_ = local_58._8_8_;
  auVar13._0_8_ = local_58._0_8_;
  auVar12._8_8_ = local_58._8_8_;
  auVar12._0_8_ = local_58._0_8_;
  auVar11._8_8_ = local_58._8_8_;
  auVar11._0_8_ = local_58._0_8_;
  auVar10._8_8_ = local_58._8_8_;
  auVar10._0_8_ = local_58._0_8_;
  auVar9._8_8_ = local_58._8_8_;
  auVar9._0_8_ = local_58._0_8_;
  auVar8._8_8_ = local_58._8_8_;
  auVar8._0_8_ = local_58._0_8_;
  auVar7._8_8_ = local_58._8_8_;
  auVar7._0_8_ = local_58._0_8_;
  auVar6._8_8_ = local_58._8_8_;
  auVar6._0_8_ = local_58._0_8_;
  auVar5._8_8_ = local_58._8_8_;
  auVar5._0_8_ = local_58._0_8_;
  lVar4 = tpidr_el0;
  local_38 = *(long *)(lVar4 + 0x28);
  pcVar21 = (char *)*param_1;
  pcVar2 = (char *)param_1[1];
  uVar23 = (long)pcVar2 - (long)pcVar21;
  if (uVar23 < 2) goto LAB_00122dc8;
  cVar3 = *pcVar21;
  if ((cVar3 == 'g') && (pcVar21[1] == 's')) {
    pcVar21 = pcVar21 + 2;
    uVar23 = (long)pcVar2 - (long)pcVar21;
    *param_1 = (long)pcVar21;
    local_3c[0] = 1;
    if (uVar23 < 2) goto LAB_00122dc8;
    cVar3 = *pcVar21;
  }
  else {
    local_3c[0] = 0;
  }
  switch(cVar3) {
  case '1':
  case '2':
  case '3':
  case '4':
  case '5':
  case '6':
  case '7':
  case '8':
  case '9':
code_r0x00122e64:
    uVar19 = FUN_00125578(param_1);
    auVar8._8_8_ = local_58._8_8_;
    auVar8._0_8_ = local_58._0_8_;
    break;
  default:
    uVar19 = 0;
    auVar8 = auVar6;
    if ((uVar23 < 0xb) || (auVar8 = auVar7, cVar3 != 'u')) break;
    if ((pcVar21[1] == '8') && (pcVar21[2] == '_')) {
      if (((((pcVar21[3] == '_') && (pcVar21[4] == 'u')) && (pcVar21[5] == 'u')) &&
          ((pcVar21[6] == 'i' && (pcVar21[7] == 'd')))) &&
         ((pcVar21[8] == 'o' && ((pcVar21[9] == 'f' && (pcVar21[10] == 't')))))) {
        *param_1 = (long)(pcVar21 + 0xb);
        local_58._0_8_ = FUN_0011ef00(param_1);
      }
      else {
        if ((((pcVar21[3] != '_') ||
             (((pcVar21[4] != 'u' || (pcVar21[5] != 'u')) || (pcVar21[6] != 'i')))) ||
            (((pcVar21[7] != 'd' || (pcVar21[8] != 'o')) || (pcVar21[9] != 'f')))) ||
           (pcVar21[10] != 'z')) goto LAB_00122dc8;
        *param_1 = (long)(pcVar21 + 0xb);
        local_58._0_8_ = FUN_00122d94(param_1);
      }
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        uVar19 = FUN_00126ac8(param_1,local_58);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
      }
      break;
    }
    goto LAB_00122dc8;
  case 'L':
    uVar19 = FUN_00123e10(param_1);
    auVar8._8_8_ = local_58._8_8_;
    auVar8._0_8_ = local_58._0_8_;
    break;
  case 'T':
    uVar19 = FUN_00122008(param_1);
    auVar8._8_8_ = local_58._8_8_;
    auVar8._0_8_ = local_58._0_8_;
    break;
  case 'a':
    uVar19 = 0;
    auVar8 = auVar18;
    switch(pcVar21[1]) {
    case 'N':
      puVar20 = &UNK_0010a537;
      break;
    default:
      goto code_r0x00122dd0;
    case 'S':
      puVar20 = &DAT_0010a95a;
      goto LAB_00123c38;
    case 'a':
      puVar20 = &DAT_0010afb5;
      break;
    case 'd':
      puVar20 = &DAT_0010b078;
      goto LAB_00123b54;
    case 'n':
      puVar20 = &DAT_0010b078;
LAB_00123c38:
      puVar22 = puVar20 + 1;
      *param_1 = (long)(pcVar21 + 2);
      goto LAB_00123c40;
    case 't':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_0011ef00(param_1);
      goto LAB_00123918;
    case 'z':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
LAB_00123918:
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        uVar19 = FUN_00123d58(param_1,"alignof (",local_58);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
      }
      goto code_r0x00122dd0;
    }
    goto LAB_001238b8;
  case 'c':
    uVar19 = 0;
    auVar8 = auVar17;
    switch(pcVar21[1]) {
    case 'c':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_0011ef00(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        local_48 = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_48 != 0) {
          uVar19 = FUN_0012506c(param_1,local_58,&local_48);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
        }
      }
      break;
    case 'l':
      *param_1 = (long)(pcVar21 + 2);
      local_48 = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_48 != 0) {
        lVar24 = param_1[2];
        lVar25 = param_1[3];
        while ((pcVar21 = (char *)*param_1, pcVar21 == (char *)param_1[1] || (*pcVar21 != 'E'))) {
          local_58._0_8_ = FUN_00122d94(param_1);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
          uVar19 = 0;
          if (local_58._0_8_ == 0) goto code_r0x00122dd0;
          FUN_00120b24(param_1 + 2,local_58);
        }
        lVar24 = (lVar25 - lVar24 >> 3) * 8;
        *param_1 = (long)(pcVar21 + 1);
        local_58 = FUN_0012a7b8(param_1,param_1[2] + lVar24,param_1[3]);
        param_1[3] = param_1[2] + lVar24;
        uVar19 = FUN_00125114(param_1,&local_48,local_58);
        auVar8 = local_58;
      }
      break;
    case 'm':
      puVar20 = &DAT_0010a3ed;
      goto LAB_00123c38;
    case 'o':
      puVar20 = &DAT_0010b07a;
      goto LAB_00123b54;
    case 'v':
      uVar19 = FUN_001251b0(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
    }
    break;
  case 'd':
    uVar19 = 0;
    auVar8 = auVar16;
    switch(pcVar21[1]) {
    case 'V':
      puVar20 = &UNK_0010a06a;
      goto LAB_001238b8;
    case 'a':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ == 0) break;
      local_48 = CONCAT71(local_48._1_7_,1);
      goto LAB_00123b88;
    case 'c':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_0011ef00(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        local_48 = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_48 != 0) {
          uVar19 = FUN_001254d0(param_1,local_58,&local_48);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
        }
      }
      break;
    case 'e':
      puVar20 = &DAT_0010a2e6;
      goto LAB_00123b54;
    case 'l':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ == 0) break;
      local_48 = local_48 & 0xffffffffffffff00;
LAB_00123b88:
      uVar19 = FUN_00125420(param_1,local_58,local_3c,&local_48);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      break;
    case 'n':
      goto code_r0x00122e64;
    case 's':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ == 0) break;
      local_48 = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_48 == 0) break;
      puVar20 = &DAT_0010a816;
LAB_00123bd4:
      uVar19 = FUN_00125abc(param_1,local_58,puVar20,&local_48);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      break;
    case 't':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        local_48 = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_48 != 0) {
          uVar19 = FUN_00125b74(param_1,local_58,&local_48);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
        }
      }
      break;
    case 'v':
      puVar20 = &DAT_00109ce9;
      goto LAB_00123c38;
    }
    break;
  case 'e':
    cVar3 = pcVar21[1];
    if (cVar3 == 'O') {
      puVar20 = &UNK_0010a7b0;
    }
    else {
      if (cVar3 != 'q') {
        if (cVar3 == 'o') {
          puVar20 = &DAT_0010aa55;
          goto LAB_00123c38;
        }
        goto LAB_00122dc8;
      }
      puVar20 = &UNK_0010a7b3;
    }
    goto LAB_001238b8;
  case 'f':
    if ((pcVar21[1] == 'p') ||
       (((pcVar21[1] == 'L' && (2 < uVar23)) && (0xfffffff5 < (byte)pcVar21[2] - 0x3a)))) {
      uVar19 = FUN_0012475c(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
    }
    else {
      uVar19 = FUN_00124a40(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
    }
    break;
  case 'g':
    if (pcVar21[1] == 't') {
      puVar20 = &DAT_0010a7b6;
      goto LAB_00123c38;
    }
    if (pcVar21[1] == 'e') {
      puVar20 = &UNK_00109bef;
      goto LAB_001238b8;
    }
    goto LAB_00122dc8;
  case 'i':
    if (pcVar21[1] == 'l') {
      lVar25 = param_1[3];
      pcVar21 = pcVar21 + 2;
      lVar24 = param_1[2];
      *param_1 = (long)pcVar21;
      if (pcVar21 == pcVar2) goto LAB_0012342c;
      while (*pcVar21 != 'E') {
LAB_0012342c:
        do {
          local_58._0_8_ = FUN_00125cb4(param_1);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
          uVar19 = 0;
          if (local_58._0_8_ == 0) goto code_r0x00122dd0;
          FUN_00120b24(param_1 + 2,local_58);
          pcVar21 = (char *)*param_1;
        } while (pcVar21 == (char *)param_1[1]);
      }
      lVar24 = (lVar25 - lVar24 >> 3) * 8;
      *param_1 = (long)(pcVar21 + 1);
      local_58 = FUN_0012a7b8(param_1,param_1[2] + lVar24,param_1[3]);
      param_1[3] = param_1[2] + lVar24;
      uVar19 = FUN_00125ee8(param_1,&local_48,local_58);
      auVar8 = local_58;
      break;
    }
    if (pcVar21[1] == 'x') {
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        local_48 = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_48 != 0) {
          uVar19 = FUN_00125c1c(param_1,local_58,&local_48);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
        }
      }
      break;
    }
    goto LAB_00122dc8;
  case 'l':
    uVar19 = 0;
    auVar8 = auVar15;
    switch(pcVar21[1]) {
    case 'S':
      puVar20 = &UNK_0010aada;
LAB_001237c4:
      puVar22 = puVar20 + 3;
      *param_1 = (long)(pcVar21 + 2);
      goto LAB_00123c40;
    default:
      goto code_r0x00122dd0;
    case 'e':
      puVar20 = &UNK_0010ae3a;
      break;
    case 's':
      puVar20 = &UNK_0010acb1;
      break;
    case 't':
      puVar20 = &DAT_00109b61;
      goto LAB_00123c38;
    }
    goto LAB_001238b8;
  case 'm':
    uVar19 = 0;
    auVar8 = auVar14;
    switch(pcVar21[1]) {
    case 'I':
      puVar20 = &UNK_0010a06d;
      break;
    default:
      goto code_r0x00122dd0;
    case 'L':
      puVar20 = &UNK_0010a3ef;
      break;
    case 'i':
      puVar20 = &DAT_0010a0cd;
      goto LAB_00123c38;
    case 'l':
      puVar20 = &DAT_0010a2e6;
      goto LAB_00123c38;
    case 'm':
      pcVar1 = pcVar21 + 2;
      *param_1 = (long)pcVar1;
      if ((pcVar1 == pcVar2) || (*pcVar1 != '_')) {
        local_58._0_8_ = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_58._0_8_ == 0) goto code_r0x00122dd0;
        puVar20 = &DAT_0010b203;
LAB_00123c64:
        uVar19 = FUN_00125f7c(param_1,local_58,puVar20);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        goto code_r0x00122dd0;
      }
      puVar20 = &DAT_0010b203;
LAB_001237fc:
      puVar22 = puVar20 + 2;
      *param_1 = (long)(pcVar21 + 3);
      goto LAB_00123b5c;
    }
    goto LAB_001238b8;
  case 'n':
    uVar19 = 0;
    auVar8 = auVar13;
    switch(pcVar21[1]) {
    case 'a':
    case 'w':
      uVar19 = FUN_00126024(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      break;
    case 'e':
      puVar20 = &UNK_0010ad8d;
      goto LAB_001238b8;
    case 'g':
      puVar20 = &DAT_0010a0cd;
      goto LAB_00123b54;
    case 't':
      puVar20 = &DAT_0010a6d9;
LAB_00123b54:
      *param_1 = (long)(pcVar21 + 2);
      puVar22 = puVar20 + 1;
LAB_00123b5c:
      uVar19 = FUN_00124fc4(param_1,puVar20,puVar22);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      break;
    case 'x':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        uVar19 = FUN_0012633c(param_1,local_58);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
      }
    }
    break;
  case 'o':
    uVar19 = 0;
    auVar8 = auVar12;
    switch(pcVar21[1]) {
    case 'R':
      puVar20 = &UNK_0010aa57;
      break;
    default:
      goto code_r0x00122dd0;
    case 'n':
      goto code_r0x00122e64;
    case 'o':
      puVar20 = &UNK_0010a95c;
      break;
    case 'r':
      puVar20 = &DAT_0010afb8;
      goto LAB_00123c38;
    }
    goto LAB_001238b8;
  case 'p':
    uVar19 = 0;
    auVar8 = auVar11;
    switch(pcVar21[1]) {
    case 'L':
      puVar20 = &UNK_0010a859;
      break;
    default:
      goto code_r0x00122dd0;
    case 'l':
      puVar20 = &DAT_0010aa5a;
      goto LAB_00123c38;
    case 'm':
      puVar20 = &UNK_0010a53a;
      goto LAB_001237c4;
    case 'p':
      pcVar1 = pcVar21 + 2;
      *param_1 = (long)pcVar1;
      if ((pcVar1 == pcVar2) || (*pcVar1 != '_')) {
        local_58._0_8_ = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_58._0_8_ == 0) goto code_r0x00122dd0;
        puVar20 = &DAT_00109b63;
        goto LAB_00123c64;
      }
      puVar20 = &DAT_00109b63;
      goto LAB_001237fc;
    case 's':
      puVar20 = &DAT_0010aa5a;
      goto LAB_00123b54;
    case 't':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ == 0) goto code_r0x00122dd0;
      local_48 = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_48 == 0) goto code_r0x00122dd0;
      puVar20 = &DAT_0010abb3;
      goto LAB_00123bd4;
    }
    goto LAB_001238b8;
  case 'q':
    if (pcVar21[1] == 'u') {
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        local_48 = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_48 != 0) {
          local_60 = FUN_00122d94(param_1);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
          uVar19 = 0;
          if (local_60 != 0) {
            uVar19 = FUN_001263ec(param_1,local_58,&local_48,&local_60);
            auVar8._8_8_ = local_58._8_8_;
            auVar8._0_8_ = local_58._0_8_;
          }
        }
      }
      break;
    }
LAB_00122dc8:
    uVar19 = 0;
    auVar8 = auVar5;
    break;
  case 'r':
    uVar19 = 0;
    auVar8 = auVar10;
    switch(pcVar21[1]) {
    case 'M':
      puVar20 = &UNK_0010ae3d;
      break;
    default:
      goto code_r0x00122dd0;
    case 'S':
      puVar20 = &DAT_0010a85c;
      goto LAB_001237c4;
    case 'c':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_0011ef00(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        local_48 = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_48 != 0) {
          uVar19 = FUN_00126498(param_1,local_58,&local_48);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
        }
      }
      goto code_r0x00122dd0;
    case 'm':
      puVar20 = &DAT_0010b49e;
      goto LAB_00123c38;
    case 's':
      puVar20 = &DAT_00109e06;
    }
LAB_001238b8:
    *param_1 = (long)(pcVar21 + 2);
    puVar22 = puVar20 + 2;
LAB_00123c40:
    uVar19 = FUN_00124f0c(param_1,puVar20,puVar22);
    auVar8._8_8_ = local_58._8_8_;
    auVar8._0_8_ = local_58._0_8_;
    break;
  case 's':
    uVar19 = 0;
    auVar8 = auVar9;
    switch(pcVar21[1]) {
    case 'P':
      lVar25 = param_1[3];
      pcVar21 = pcVar21 + 2;
      lVar24 = param_1[2];
      *param_1 = (long)pcVar21;
      if (pcVar21 == pcVar2) goto LAB_001231e4;
      while (*pcVar21 != 'E') {
LAB_001231e4:
        do {
          local_58._0_8_ = FUN_00120934(param_1);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
          uVar19 = 0;
          if (local_58._0_8_ == 0) goto code_r0x00122dd0;
          FUN_00120b24(param_1 + 2,local_58);
          pcVar21 = (char *)*param_1;
        } while (pcVar21 == (char *)param_1[1]);
      }
      lVar24 = (lVar25 - lVar24 >> 3) * 8;
      *param_1 = (long)(pcVar21 + 1);
      local_58 = FUN_0012a7b8(param_1,param_1[2] + lVar24,param_1[3]);
      param_1[3] = param_1[2] + lVar24;
      lVar24 = FUN_00126870(param_1,local_58);
      local_58._0_8_ = lVar24;
LAB_00123d44:
      uVar19 = FUN_001267c0(param_1,local_58);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      break;
    case 'Z':
      pcVar21 = pcVar21 + 2;
      *param_1 = (long)pcVar21;
      if (pcVar2 != pcVar21) {
        if (*pcVar21 == 'f') {
          local_58._0_8_ = FUN_0012475c(param_1);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
          uVar19 = 0;
          if (local_58._0_8_ == 0) break;
          goto LAB_00123d44;
        }
        if (*pcVar21 == 'T') {
          local_58._0_8_ = FUN_00122008(param_1);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
          uVar19 = 0;
          if (local_58._0_8_ != 0) {
            uVar19 = FUN_00126730(param_1,local_58);
            auVar8._8_8_ = local_58._8_8_;
            auVar8._0_8_ = local_58._0_8_;
          }
          break;
        }
      }
      goto LAB_00122dc8;
    case 'c':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_0011ef00(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        local_48 = FUN_00122d94(param_1);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
        uVar19 = 0;
        if (local_48 != 0) {
          uVar19 = FUN_00126540(param_1,local_58,&local_48);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
        }
      }
      break;
    case 'p':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        uVar19 = FUN_001265e8(param_1,local_58);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
      }
      break;
    case 'r':
      goto code_r0x00122e64;
    case 't':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_0011ef00(param_1);
      goto LAB_00123a18;
    case 'z':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
LAB_00123a18:
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        pcVar21 = "sizeof (";
LAB_00123a28:
        uVar19 = FUN_00126678(param_1,pcVar21,local_58);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
      }
    }
    break;
  case 't':
    uVar19 = 0;
    switch(pcVar21[1]) {
    case 'e':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      goto LAB_001234f0;
    case 'i':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_0011ef00(param_1);
LAB_001234f0:
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ == 0) break;
      pcVar21 = "typeid (";
      goto LAB_00123a28;
    case 'l':
      *param_1 = (long)(pcVar21 + 2);
      local_48 = FUN_0011ef00(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_48 != 0) {
        lVar24 = param_1[2];
        lVar25 = param_1[3];
        while ((pcVar21 = (char *)*param_1, pcVar21 == (char *)param_1[1] || (*pcVar21 != 'E'))) {
          local_58._0_8_ = FUN_00125cb4(param_1);
          auVar8._8_8_ = local_58._8_8_;
          auVar8._0_8_ = local_58._0_8_;
          uVar19 = 0;
          if (local_58._0_8_ == 0) goto code_r0x00122dd0;
          FUN_00120b24(param_1 + 2,local_58);
        }
        lVar24 = (lVar25 - lVar24 >> 3) * 8;
        *param_1 = (long)(pcVar21 + 1);
        local_58 = FUN_0012a7b8(param_1,param_1[2] + lVar24,param_1[3]);
        param_1[3] = param_1[2] + lVar24;
        uVar19 = FUN_00126900(param_1,&local_48,local_58);
        auVar8 = local_58;
      }
      break;
    case 'r':
      *param_1 = (long)(pcVar21 + 2);
      uVar19 = FUN_0012699c(param_1,"throw");
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      break;
    case 'w':
      *param_1 = (long)(pcVar21 + 2);
      local_58._0_8_ = FUN_00122d94(param_1);
      auVar8._8_8_ = local_58._8_8_;
      auVar8._0_8_ = local_58._0_8_;
      uVar19 = 0;
      if (local_58._0_8_ != 0) {
        uVar19 = FUN_00126a38(param_1,local_58);
        auVar8._8_8_ = local_58._8_8_;
        auVar8._0_8_ = local_58._0_8_;
      }
    }
  }
code_r0x00122dd0:
  if (*(long *)(lVar4 + 0x28) != local_38) {
    local_58 = auVar8;
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar19);
  }
  return;
}


// ==== FUN_00123d58 @ 00123d58

undefined8 * FUN_00123d58(long param_1,char *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar6 + 8);
  puVar1 = pvVar6;
  if (lVar3 - 0xfb0U < 0xfffffffffffff00f || lVar3 == -0x41) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar6;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x40;
  sVar2 = strlen(param_2);
  uVar4 = *param_3;
  puVar5 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar5 = &PTR_LAB_0013d650;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010134;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  *(undefined8 *)((long)puVar1 + lVar3 + 0x30) = uVar4;
  *(undefined **)((long)puVar1 + lVar3 + 0x38) = &DAT_0010b201;
  *(undefined **)((long)puVar1 + lVar3 + 0x40) = &DAT_0010b202;
  return puVar5;
}


// ==== FUN_00123e10 @ 00123e10

void FUN_00123e10(long *param_1)

{
  char *pcVar1;
  char *pcVar2;
  byte *pbVar3;
  byte *pbVar4;
  ulong uVar5;
  long lVar6;
  undefined8 *puVar7;
  long lVar8;
  char *pcVar9;
  char *pcVar10;
  long lVar11;
  undefined **ppuVar12;
  uint uVar13;
  byte *pbVar14;
  void *pvVar15;
  undefined8 *puVar16;
  undefined8 local_60;
  byte *pbStack_58;
  long local_50;
  long local_48;
  
  lVar6 = tpidr_el0;
  local_48 = *(long *)(lVar6 + 0x28);
  pcVar2 = (char *)*param_1;
  pcVar10 = (char *)param_1[1];
  if ((pcVar2 == pcVar10) || (*pcVar2 != 'L')) goto LAB_001245f4;
  pcVar9 = pcVar2 + 1;
  uVar5 = (long)pcVar10 - (long)pcVar9;
  *param_1 = (long)pcVar9;
  if (pcVar10 == pcVar9) {
code_r0x00123ed8:
    local_50 = FUN_0011ef00(param_1);
    puVar7 = (undefined8 *)0x0;
    if (local_50 == 0) goto code_r0x001245fc;
    pbVar3 = (byte *)*param_1;
    pbVar4 = (byte *)param_1[1];
    pbVar14 = pbVar3;
    if ((pbVar4 == pbVar3) || (*pbVar3 - 0x3a < 0xfffffff6)) {
      local_60 = (byte *)0x0;
      pbStack_58 = (byte *)0x0;
    }
    else {
      do {
        pbVar14 = pbVar14 + 1;
        *param_1 = (long)pbVar14;
        local_60 = pbVar3;
        if (pbVar14 == pbVar4) {
          pbStack_58 = pbVar4;
          goto LAB_00123f10;
        }
      } while (0xfffffff5 < *pbVar14 - 0x3a);
      pbStack_58 = pbVar14;
    }
LAB_00123f10:
    puVar7 = (undefined8 *)0x0;
    if ((pbStack_58 == local_60) || (pbVar14 == pbVar4)) goto code_r0x001245fc;
    if (*pbVar14 == 0x45) {
      *param_1 = (long)(pbVar14 + 1);
      puVar7 = (undefined8 *)FUN_001274c0(param_1,&local_50,&local_60);
      goto code_r0x001245fc;
    }
    goto LAB_001245f4;
  }
  puVar7 = (undefined8 *)0x0;
  switch(*pcVar9) {
  case 'A':
    local_60 = (byte *)FUN_0011ef00(param_1);
    puVar7 = (undefined8 *)0x0;
    if (local_60 == (byte *)0x0) goto code_r0x001245fc;
    pcVar2 = (char *)*param_1;
    if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'E')) {
      *param_1 = (long)(pcVar2 + 1);
      puVar7 = (undefined8 *)FUN_00126d4c(param_1,&local_60);
      goto code_r0x001245fc;
    }
    goto LAB_001245f4;
  default:
    goto code_r0x00123ed8;
  case 'D':
    if (((2 < uVar5) && (pcVar2[2] == 'n')) && (pcVar2[3] == 'E')) {
      *param_1 = (long)(pcVar2 + 4);
      puVar7 = (undefined8 *)FUN_00126ddc(param_1,"nullptr");
      goto code_r0x001245fc;
    }
    goto LAB_001245f4;
  case 'T':
    goto code_r0x001245fc;
  case 'U':
    if ((1 < uVar5) && (pcVar2[2] == 'l')) {
      local_60 = (byte *)FUN_00126e78(param_1,0);
      puVar7 = (undefined8 *)0x0;
      if (local_60 == (byte *)0x0) goto code_r0x001245fc;
      pcVar2 = (char *)*param_1;
      if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'E')) {
        *param_1 = (long)(pcVar2 + 1);
        puVar7 = (undefined8 *)FUN_00127430(param_1,&local_60);
        goto code_r0x001245fc;
      }
    }
    goto LAB_001245f4;
  case '_':
    if ((1 < uVar5) && (pcVar2[2] == 'Z')) {
      *param_1 = (long)(pcVar2 + 3);
      puVar7 = (undefined8 *)FUN_0011e5c4(param_1);
      if (puVar7 == (undefined8 *)0x0) goto code_r0x001245fc;
      pcVar2 = (char *)*param_1;
      if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'E')) {
        *param_1 = (long)(pcVar2 + 1);
        goto code_r0x001245fc;
      }
    }
    goto LAB_001245f4;
  case 'a':
    pcVar9 = "signed char";
    pcVar10 = "";
    break;
  case 'b':
    if (2 < uVar5) {
      if (pcVar2[2] == '1') {
        if (pcVar2[3] == 'E') {
          *param_1 = (long)(pcVar2 + 4);
          local_60 = (byte *)CONCAT44(local_60._4_4_,1);
          goto LAB_00124744;
        }
      }
      else if ((pcVar2[2] == '0') && (pcVar2[3] == 'E')) {
        local_60 = (byte *)((ulong)local_60._4_4_ << 0x20);
        *param_1 = (long)(pcVar2 + 4);
LAB_00124744:
        puVar7 = (undefined8 *)FUN_00126cb4(param_1,&local_60);
        goto code_r0x001245fc;
      }
    }
    goto LAB_001245f4;
  case 'c':
    pcVar9 = "char";
    pcVar10 = "";
    break;
  case 'd':
    pcVar9 = pcVar2 + 2;
    *param_1 = (long)pcVar9;
    if ((((((0x10 < (ulong)((long)pcVar10 - (long)pcVar9)) &&
           ((0xfffffff5 < (byte)pcVar2[2] - 0x3a ||
            (0xfffffff9 < ((byte)pcVar2[2] & 0xffffffdf) - 0x47)))) &&
          ((0xfffffff5 < (byte)pcVar2[3] - 0x3a ||
           (0xfffffff9 < ((byte)pcVar2[3] & 0xffffffdf) - 0x47)))) &&
         (((((0xfffffff5 < (byte)pcVar2[4] - 0x3a ||
             (0xfffffff9 < ((byte)pcVar2[4] & 0xffffffdf) - 0x47)) &&
            ((0xfffffff5 < (byte)pcVar2[5] - 0x3a ||
             (0xfffffff9 < ((byte)pcVar2[5] & 0xffffffdf) - 0x47)))) &&
           ((0xfffffff5 < (byte)pcVar2[6] - 0x3a ||
            (0xfffffff9 < ((byte)pcVar2[6] & 0xffffffdf) - 0x47)))) &&
          ((0xfffffff5 < (byte)pcVar2[7] - 0x3a ||
           (0xfffffff9 < ((byte)pcVar2[7] & 0xffffffdf) - 0x47)))))) &&
        ((((((0xfffffff5 < (byte)pcVar2[8] - 0x3a ||
             (0xfffffff9 < ((byte)pcVar2[8] & 0xffffffdf) - 0x47)) &&
            ((0xfffffff5 < (byte)pcVar2[9] - 0x3a ||
             (0xfffffff9 < ((byte)pcVar2[9] & 0xffffffdf) - 0x47)))) &&
           ((0xfffffff5 < (byte)pcVar2[10] - 0x3a ||
            (0xfffffff9 < ((byte)pcVar2[10] & 0xffffffdf) - 0x47)))) &&
          ((0xfffffff5 < (byte)pcVar2[0xb] - 0x3a ||
           (0xfffffff9 < ((byte)pcVar2[0xb] & 0xffffffdf) - 0x47)))) &&
         ((((0xfffffff5 < (byte)pcVar2[0xc] - 0x3a ||
            (0xfffffff9 < ((byte)pcVar2[0xc] & 0xffffffdf) - 0x47)) &&
           ((0xfffffff5 < (byte)pcVar2[0xd] - 0x3a ||
            (0xfffffff9 < ((byte)pcVar2[0xd] & 0xffffffdf) - 0x47)))) &&
          ((0xfffffff5 < (byte)pcVar2[0xe] - 0x3a ||
           (0xfffffff9 < ((byte)pcVar2[0xe] & 0xffffffdf) - 0x47)))))))) &&
       (((0xfffffff5 < (byte)pcVar2[0xf] - 0x3a ||
         (0xfffffff9 < ((byte)pcVar2[0xf] & 0xffffffdf) - 0x47)) &&
        (((0xfffffff5 < (byte)pcVar2[0x10] - 0x3a ||
          (0xfffffff9 < ((byte)pcVar2[0x10] & 0xffffffdf) - 0x47)) &&
         ((0xfffffff5 < (byte)pcVar2[0x11] - 0x3a ||
          (0xfffffff9 < ((byte)pcVar2[0x11] & 0xffffffdf) - 0x47)))))))) {
      pcVar1 = pcVar2 + 0x12;
      *param_1 = (long)pcVar1;
      if ((pcVar1 != pcVar10) && (*pcVar1 == 'E')) {
        pvVar15 = (void *)param_1[0x266];
        *param_1 = (long)(pcVar2 + 0x13);
        lVar11 = *(long *)((long)pvVar15 + 8);
        puVar16 = pvVar15;
        if (lVar11 - 0xfd0U < 0xfffffffffffff00f || lVar11 == -0x21) {
          puVar16 = malloc(0x1000);
          if (puVar16 == (void *)0x0) {
LAB_00124758:
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar11 = 0;
          *puVar16 = pvVar15;
          puVar16[1] = 0;
          param_1[0x266] = (long)puVar16;
        }
        *(long *)((long)puVar16 + 8) = lVar11 + 0x20;
        puVar7 = (undefined8 *)((long)puVar16 + lVar11 + 0x10);
        *puVar7 = &PTR_LAB_0013c7e0;
        *(undefined4 *)((long)puVar16 + lVar11 + 0x18) = 0x1010147;
        *(char **)((long)puVar16 + lVar11 + 0x20) = pcVar9;
        *(char **)((long)puVar16 + lVar11 + 0x28) = pcVar1;
        goto code_r0x001245fc;
      }
    }
    goto LAB_001245f4;
  case 'e':
    pcVar1 = pcVar2 + 2;
    *param_1 = (long)pcVar1;
    if (0x20 < (ulong)((long)pcVar10 - (long)pcVar1)) {
      lVar11 = 0;
      pcVar9 = pcVar2 + 0x22;
      do {
        if ((byte)pcVar1[lVar11] - 0x3a < 0xfffffff6 &&
            ((byte)pcVar1[lVar11] & 0xffffffdf) - 0x47 < 0xfffffffa) goto LAB_001245f4;
        lVar11 = lVar11 + 1;
      } while (lVar11 != 0x20);
      *param_1 = (long)pcVar9;
      if ((pcVar9 != pcVar10) && (*pcVar9 == 'E')) {
        puVar16 = (undefined8 *)param_1[0x266];
        *param_1 = (long)(pcVar2 + 0x23);
        lVar11 = puVar16[1];
        puVar7 = puVar16;
        if (lVar11 - 0xfd0U < 0xfffffffffffff00f || lVar11 == -0x21) {
          puVar7 = malloc(0x1000);
          if (puVar7 == (undefined8 *)0x0) goto LAB_00124758;
          lVar11 = 0;
          *puVar7 = puVar16;
          puVar7[1] = 0;
          param_1[0x266] = (long)puVar7;
        }
        lVar8 = (long)puVar7 + lVar11;
        uVar13 = 0x148;
        ppuVar12 = &PTR_LAB_0013c850;
LAB_00124710:
        puVar7[1] = lVar11 + 0x20;
        puVar7 = (undefined8 *)(lVar8 + 0x10);
        *puVar7 = ppuVar12;
        *(uint *)(lVar8 + 0x18) = uVar13 | 0x1010000;
        *(char **)(lVar8 + 0x20) = pcVar2 + 2;
        *(char **)(lVar8 + 0x28) = pcVar9;
        goto code_r0x001245fc;
      }
    }
    goto LAB_001245f4;
  case 'f':
    *param_1 = (long)(pcVar2 + 2);
    if (((((8 < (ulong)((long)pcVar10 - (long)(pcVar2 + 2))) &&
          ((0xfffffff5 < (byte)pcVar2[2] - 0x3a ||
           (0xfffffff9 < ((byte)pcVar2[2] & 0xffffffdf) - 0x47)))) &&
         ((0xfffffff5 < (byte)pcVar2[3] - 0x3a ||
          (0xfffffff9 < ((byte)pcVar2[3] & 0xffffffdf) - 0x47)))) &&
        ((((0xfffffff5 < (byte)pcVar2[4] - 0x3a ||
           (0xfffffff9 < ((byte)pcVar2[4] & 0xffffffdf) - 0x47)) &&
          ((0xfffffff5 < (byte)pcVar2[5] - 0x3a ||
           (0xfffffff9 < ((byte)pcVar2[5] & 0xffffffdf) - 0x47)))) &&
         ((0xfffffff5 < (byte)pcVar2[6] - 0x3a ||
          (0xfffffff9 < ((byte)pcVar2[6] & 0xffffffdf) - 0x47)))))) &&
       (((0xfffffff5 < (byte)pcVar2[7] - 0x3a ||
         (0xfffffff9 < ((byte)pcVar2[7] & 0xffffffdf) - 0x47)) &&
        (((0xfffffff5 < (byte)pcVar2[8] - 0x3a ||
          (0xfffffff9 < ((byte)pcVar2[8] & 0xffffffdf) - 0x47)) &&
         ((0xfffffff5 < (byte)pcVar2[9] - 0x3a ||
          (0xfffffff9 < ((byte)pcVar2[9] & 0xffffffdf) - 0x47)))))))) {
      pcVar9 = pcVar2 + 10;
      *param_1 = (long)pcVar9;
      if ((pcVar9 != pcVar10) && (*pcVar9 == 'E')) {
        puVar16 = (undefined8 *)param_1[0x266];
        *param_1 = (long)(pcVar2 + 0xb);
        lVar11 = puVar16[1];
        puVar7 = puVar16;
        if (lVar11 - 0xfd0U < 0xfffffffffffff00f || lVar11 == -0x21) {
          puVar7 = malloc(0x1000);
          if (puVar7 == (void *)0x0) goto LAB_00124758;
          lVar11 = 0;
          *puVar7 = puVar16;
          puVar7[1] = 0;
          param_1[0x266] = (long)puVar7;
        }
        lVar8 = (long)puVar7 + lVar11;
        uVar13 = 0x146;
        ppuVar12 = &PTR_LAB_0013c770;
        goto LAB_00124710;
      }
    }
LAB_001245f4:
    puVar7 = (undefined8 *)0x0;
    goto code_r0x001245fc;
  case 'h':
    pcVar9 = "unsigned char";
    pcVar10 = "";
    break;
  case 'i':
    pcVar9 = "";
    pcVar10 = "";
    *param_1 = (long)(pcVar2 + 2);
    goto LAB_00124674;
  case 'j':
    pcVar9 = "u";
    goto LAB_001242d8;
  case 'l':
    pcVar9 = "l";
LAB_001242d8:
    pcVar10 = pcVar9 + 1;
    break;
  case 'm':
    pcVar9 = "ul";
    goto LAB_0012431c;
  case 'n':
    pcVar9 = "__int128";
    pcVar10 = "";
    break;
  case 'o':
    pcVar9 = "unsigned __int128";
    pcVar10 = "";
    break;
  case 's':
    pcVar9 = "short";
    pcVar10 = "";
    break;
  case 't':
    pcVar9 = "unsigned short";
    pcVar10 = "";
    break;
  case 'w':
    pcVar9 = "wchar_t";
    pcVar10 = "";
    break;
  case 'x':
    pcVar9 = "ll";
LAB_0012431c:
    pcVar10 = pcVar9 + 2;
    break;
  case 'y':
    pcVar9 = "ull";
    pcVar10 = "";
  }
  *param_1 = (long)(pcVar2 + 2);
LAB_00124674:
  puVar7 = (undefined8 *)FUN_00126b58(param_1,pcVar9,pcVar10);
code_r0x001245fc:
  if (*(long *)(lVar6 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar7);
  }
  return;
}


// ==== FUN_0012475c @ 0012475c

undefined8 * FUN_0012475c(long *param_1)

{
  char *pcVar1;
  byte *pbVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  long lVar5;
  byte *pbVar6;
  byte *pbVar7;
  byte *pbVar8;
  byte *pbVar9;
  void *pvVar10;
  
  pcVar1 = (char *)*param_1;
  pbVar2 = (byte *)param_1[1];
  if ((ulong)((long)pbVar2 - (long)pcVar1) < 2) {
    return (undefined8 *)0x0;
  }
  if (*pcVar1 != 'f') {
    return (undefined8 *)0x0;
  }
  if (pcVar1[1] == 'p') {
    pbVar9 = (byte *)(pcVar1 + 2);
    *param_1 = (long)pbVar9;
    if (pbVar9 == pbVar2) {
      return (undefined8 *)0x0;
    }
    if (*pbVar9 == 0x72) {
      pbVar9 = (byte *)(pcVar1 + 3);
      *param_1 = (long)pbVar9;
    }
    if (pbVar9 == pbVar2) {
      return (undefined8 *)0x0;
    }
    if (*pbVar9 == 0x56) {
      pbVar9 = pbVar9 + 1;
      *param_1 = (long)pbVar9;
    }
    if (pbVar9 == pbVar2) {
      return (undefined8 *)0x0;
    }
    if (*pbVar9 == 0x4b) {
      pbVar9 = pbVar9 + 1;
      *param_1 = (long)pbVar9;
    }
    if (pbVar2 == pbVar9) {
      return (undefined8 *)0x0;
    }
    pbVar6 = pbVar9;
    if (*pbVar9 - 0x3a < 0xfffffff6) {
      pbVar9 = (byte *)0x0;
      pbVar7 = (byte *)0x0;
    }
    else {
      do {
        pbVar6 = pbVar6 + 1;
        *param_1 = (long)pbVar6;
        pbVar7 = pbVar2;
        if (pbVar6 == pbVar2) break;
        pbVar7 = pbVar6;
      } while (0xfffffff5 < *pbVar6 - 0x3a);
    }
  }
  else {
    if (*pcVar1 != 'f') {
      return (undefined8 *)0x0;
    }
    if (pcVar1[1] != 'L') {
      return (undefined8 *)0x0;
    }
    pbVar9 = (byte *)(pcVar1 + 2);
    *param_1 = (long)pbVar9;
    if (pbVar2 == pbVar9) {
      return (undefined8 *)0x0;
    }
    if (*pbVar9 - 0x3a < 0xfffffff6) {
      return (undefined8 *)0x0;
    }
    pbVar6 = (byte *)(pcVar1 + 5);
    do {
      pbVar8 = pbVar6;
      pbVar7 = pbVar8 + -2;
      *param_1 = (long)pbVar7;
      if (pbVar7 == pbVar2) {
        pbVar6 = pbVar2;
        goto LAB_001248c0;
      }
      pbVar6 = pbVar8 + 1;
    } while (0xfffffff5 < pbVar8[-2] - 0x3a);
    pbVar6 = pbVar8 + -2;
LAB_001248c0:
    if (pbVar9 == pbVar6) {
      return (undefined8 *)0x0;
    }
    if (pbVar7 == pbVar2) {
      return (undefined8 *)0x0;
    }
    if (pbVar8[-2] != 0x70) {
      return (undefined8 *)0x0;
    }
    pbVar9 = pbVar8 + -1;
    *param_1 = (long)pbVar9;
    if (pbVar9 == pbVar2) {
      return (undefined8 *)0x0;
    }
    if (*pbVar9 == 0x72) {
      *param_1 = (long)pbVar8;
      pbVar9 = pbVar8;
    }
    if (pbVar9 == pbVar2) {
      return (undefined8 *)0x0;
    }
    if (*pbVar9 == 0x56) {
      pbVar9 = pbVar9 + 1;
      *param_1 = (long)pbVar9;
    }
    if (pbVar9 == pbVar2) {
      return (undefined8 *)0x0;
    }
    if (*pbVar9 == 0x4b) {
      pbVar9 = pbVar9 + 1;
      *param_1 = (long)pbVar9;
    }
    if (pbVar2 == pbVar9) {
      return (undefined8 *)0x0;
    }
    pbVar6 = pbVar9;
    if (*pbVar9 - 0x3a < 0xfffffff6) {
      pbVar9 = (byte *)0x0;
      pbVar7 = (byte *)0x0;
    }
    else {
      do {
        pbVar6 = pbVar6 + 1;
        *param_1 = (long)pbVar6;
        pbVar7 = pbVar2;
        if (pbVar6 == pbVar2) break;
        pbVar7 = pbVar6;
      } while (0xfffffff5 < *pbVar6 - 0x3a);
    }
  }
  if ((pbVar6 == pbVar2) || (*pbVar6 != 0x5f)) {
    return (undefined8 *)0x0;
  }
  pvVar10 = (void *)param_1[0x266];
  lVar5 = *(long *)((long)pvVar10 + 8);
  *param_1 = (long)(pbVar6 + 1);
  puVar3 = pvVar10;
  if (lVar5 - 0xfd0U < 0xfffffffffffff00f || lVar5 == -0x21) {
    puVar3 = malloc(0x1000);
    if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    *puVar3 = pvVar10;
    puVar3[1] = 0;
    lVar5 = 0;
    param_1[0x266] = (long)puVar3;
  }
  *(long *)((long)puVar3 + 8) = lVar5 + 0x20;
  puVar4 = (undefined8 *)((long)puVar3 + lVar5 + 0x10);
  *puVar4 = &PTR_LAB_0013cd20;
  *(undefined4 *)((long)puVar3 + lVar5 + 0x18) = 0x101013b;
  *(byte **)((long)puVar3 + lVar5 + 0x20) = pbVar9;
  *(byte **)((long)puVar3 + lVar5 + 0x28) = pbVar7;
  return puVar4;
}


// ==== FUN_00124a40 @ 00124a40

undefined8 * FUN_00124a40(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  byte bVar5;
  bool bVar6;
  undefined8 *puVar7;
  long lVar8;
  long lVar9;
  undefined8 *puVar10;
  long lVar11;
  undefined *puVar12;
  undefined *puVar13;
  void *pvVar14;
  
  pbVar2 = (byte *)*param_1;
  pbVar3 = (byte *)param_1[1];
  if ((pbVar2 == pbVar3) || (*pbVar2 != 0x66)) {
    return (undefined8 *)0x0;
  }
  pbVar1 = pbVar2 + 1;
  *param_1 = (long)pbVar1;
  if (pbVar3 == pbVar1) {
    return (undefined8 *)0x0;
  }
  bVar4 = *pbVar1;
  if ((bVar4 & 0xdf) == 0x4c) {
    bVar6 = true;
  }
  else {
    if ((bVar4 & 0xdf) != 0x52) {
      return (undefined8 *)0x0;
    }
    bVar6 = false;
  }
  pbVar1 = pbVar2 + 2;
  puVar7 = (undefined8 *)0x0;
  *param_1 = (long)pbVar1;
  if ((ulong)((long)pbVar3 - (long)pbVar1) < 2) {
    return (undefined8 *)0x0;
  }
  switch(*pbVar1) {
  case 0x61:
    puVar7 = (undefined8 *)0x0;
    puVar12 = &DAT_0010afb5;
    puVar13 = &UNK_0010afb7;
    switch(pbVar2[3]) {
    case 0x4e:
      puVar12 = &UNK_0010a537;
      goto LAB_00124e50;
    default:
      goto code_r0x00124cf4;
    case 0x53:
      puVar12 = &DAT_0010a95a;
      puVar13 = &DAT_0010a95b;
      break;
    case 0x61:
      break;
    case 0x6e:
      puVar12 = &DAT_0010b078;
      puVar13 = &DAT_0010b079;
    }
    break;
  default:
    goto code_r0x00124cf4;
  case 99:
    if (pbVar2[3] != 0x6d) {
      return (undefined8 *)0x0;
    }
    puVar12 = &DAT_0010a3ed;
    puVar13 = &DAT_0010a3ee;
    break;
  case 100:
    bVar5 = pbVar2[3];
    if (bVar5 == 0x56) {
      puVar12 = &UNK_0010a06a;
    }
    else {
      if (bVar5 != 0x73) {
        if (bVar5 != 0x76) {
          return (undefined8 *)0x0;
        }
        puVar12 = &DAT_00109ce9;
        puVar13 = &DAT_00109cea;
        break;
      }
      puVar12 = &DAT_0010a816;
    }
    goto LAB_00124e50;
  case 0x65:
    bVar5 = pbVar2[3];
    if (bVar5 == 0x4f) {
      puVar12 = &UNK_0010a7b0;
    }
    else {
      if (bVar5 == 0x6f) {
        puVar12 = &DAT_0010aa55;
        puVar13 = &DAT_0010aa56;
        break;
      }
      if (bVar5 != 0x71) {
        return (undefined8 *)0x0;
      }
      puVar12 = &UNK_0010a7b3;
    }
    goto LAB_00124e50;
  case 0x67:
    if (pbVar2[3] == 0x65) {
      puVar12 = &UNK_00109bef;
      goto LAB_00124e50;
    }
    if (pbVar2[3] != 0x74) {
      return (undefined8 *)0x0;
    }
    puVar12 = &DAT_0010a7b6;
    puVar13 = &DAT_0010a7b7;
    break;
  case 0x6c:
    puVar7 = (undefined8 *)0x0;
    puVar12 = &UNK_0010ae3a;
    puVar13 = &UNK_0010ae3c;
    switch(pbVar2[3]) {
    case 0x53:
      puVar12 = &UNK_0010aada;
      puVar13 = &UNK_0010aadd;
      break;
    default:
      goto code_r0x00124cf4;
    case 0x65:
      break;
    case 0x73:
      puVar12 = &UNK_0010acb1;
      goto LAB_00124e50;
    case 0x74:
      puVar12 = &DAT_00109b61;
      puVar13 = &DAT_00109b62;
    }
    break;
  case 0x6d:
    puVar7 = (undefined8 *)0x0;
    puVar12 = &DAT_0010a0cd;
    puVar13 = &DAT_0010a0ce;
    switch(pbVar2[3]) {
    case 0x49:
      puVar12 = &UNK_0010a06d;
      goto LAB_00124e50;
    default:
      goto code_r0x00124cf4;
    case 0x4c:
      puVar12 = &UNK_0010a3ef;
      goto LAB_00124e50;
    case 0x69:
      break;
    case 0x6c:
      puVar12 = &DAT_0010a2e6;
      puVar13 = &DAT_0010a2e7;
    }
    break;
  case 0x6e:
    if (pbVar2[3] != 0x65) {
      return (undefined8 *)0x0;
    }
    puVar12 = &UNK_0010ad8d;
    goto LAB_00124e50;
  case 0x6f:
    bVar5 = pbVar2[3];
    if (bVar5 == 0x52) {
      puVar12 = &UNK_0010aa57;
    }
    else {
      if (bVar5 != 0x6f) {
        if (bVar5 != 0x72) {
          return (undefined8 *)0x0;
        }
        puVar12 = &DAT_0010afb8;
        puVar13 = &DAT_0010afb9;
        break;
      }
      puVar12 = &UNK_0010a95c;
    }
LAB_00124e50:
    puVar13 = puVar12 + 2;
    break;
  case 0x70:
    if (pbVar2[3] == 0x4c) {
      puVar12 = &UNK_0010a859;
      goto LAB_00124e50;
    }
    if (pbVar2[3] != 0x6c) {
      return (undefined8 *)0x0;
    }
    puVar12 = &DAT_0010aa5a;
    puVar13 = &DAT_0010aa5b;
    break;
  case 0x72:
    puVar7 = (undefined8 *)0x0;
    puVar12 = &DAT_0010b49e;
    puVar13 = &DAT_0010b49f;
    switch(pbVar2[3]) {
    case 0x4d:
      puVar12 = &UNK_0010ae3d;
      goto LAB_00124e50;
    default:
      goto code_r0x00124cf4;
    case 0x53:
      puVar12 = &DAT_0010a85c;
      puVar13 = &DAT_0010a85f;
      break;
    case 0x6d:
      break;
    case 0x73:
      puVar12 = &DAT_00109e06;
      goto LAB_00124e50;
    }
  }
  *param_1 = (long)(pbVar2 + 4);
  lVar8 = FUN_00122d94(param_1);
  puVar7 = (undefined8 *)0x0;
  if (lVar8 != 0) {
    if ((bVar4 == 0x52) || (bVar4 == 0x4c)) {
      lVar9 = FUN_00122d94(param_1);
      if (lVar9 == 0) {
        return (undefined8 *)0x0;
      }
      lVar11 = lVar8;
      if (!bVar6) {
        lVar11 = lVar9;
        lVar9 = lVar8;
      }
      lVar8 = lVar9;
    }
    else {
      lVar11 = 0;
    }
    pvVar14 = (void *)param_1[0x266];
    lVar9 = *(long *)((long)pvVar14 + 8);
    puVar10 = pvVar14;
    if (lVar9 - 0xfb0U < 0xfffffffffffff00f || lVar9 == -0x41) {
      puVar10 = malloc(0x1000);
      if (puVar10 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar9 = 0;
      *puVar10 = pvVar14;
      puVar10[1] = 0;
      param_1[0x266] = (long)puVar10;
    }
    *(long *)((long)puVar10 + 8) = lVar9 + 0x40;
    puVar7 = (undefined8 *)((long)puVar10 + lVar9 + 0x10);
    *puVar7 = &PTR_LAB_0013cd90;
    *(undefined4 *)((long)puVar10 + lVar9 + 0x18) = 0x101013e;
    *(long *)((long)puVar10 + lVar9 + 0x20) = lVar8;
    *(long *)((long)puVar10 + lVar9 + 0x28) = lVar11;
    *(undefined **)((long)puVar10 + lVar9 + 0x30) = puVar12;
    *(undefined **)((long)puVar10 + lVar9 + 0x38) = puVar13;
    *(bool *)((long)puVar10 + lVar9 + 0x40) = bVar6;
  }
code_r0x00124cf4:
  return puVar7;
}


// ==== FUN_00124f0c @ 00124f0c

void FUN_00124f0c(long param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  long lVar2;
  undefined8 *puVar3;
  long lVar4;
  void *pvVar5;
  
  lVar1 = FUN_00122d94();
  if ((lVar1 != 0) && (lVar2 = FUN_00122d94(param_1), lVar2 != 0)) {
    pvVar5 = *(void **)(param_1 + 0x1330);
    lVar4 = *(long *)((long)pvVar5 + 8);
    puVar3 = pvVar5;
    if (lVar4 - 0xfc0U < 0xfffffffffffff00f || lVar4 == -0x31) {
      puVar3 = malloc(0x1000);
      if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar4 = 0;
      *puVar3 = pvVar5;
      puVar3[1] = 0;
      *(undefined8 **)(param_1 + 0x1330) = puVar3;
    }
    *(long *)((long)puVar3 + 8) = lVar4 + 0x30;
    *(undefined ***)((long)puVar3 + lVar4 + 0x10) = &PTR_LAB_0013ce70;
    *(undefined4 *)((long)puVar3 + lVar4 + 0x18) = 0x101012f;
    *(long *)((long)puVar3 + lVar4 + 0x20) = lVar1;
    *(undefined8 *)((long)puVar3 + lVar4 + 0x28) = param_2;
    *(undefined8 *)((long)puVar3 + lVar4 + 0x30) = param_3;
    *(long *)((long)puVar3 + lVar4 + 0x38) = lVar2;
  }
  return;
}


// ==== FUN_00124fc4 @ 00124fc4

void FUN_00124fc4(long param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  void *pvVar4;
  
  lVar1 = FUN_00122d94();
  if (lVar1 != 0) {
    pvVar4 = *(void **)(param_1 + 0x1330);
    lVar3 = *(long *)((long)pvVar4 + 8);
    puVar2 = pvVar4;
    if (lVar3 - 0xfc0U < 0xfffffffffffff00f || lVar3 == -0x31) {
      puVar2 = malloc(0x1000);
      if (puVar2 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar3 = 0;
      *puVar2 = pvVar4;
      puVar2[1] = 0;
      *(undefined8 **)(param_1 + 0x1330) = puVar2;
    }
    *(long *)((long)puVar2 + 8) = lVar3 + 0x30;
    *(undefined ***)((long)puVar2 + lVar3 + 0x10) = &PTR_LAB_0013cee0;
    *(undefined4 *)((long)puVar2 + lVar3 + 0x18) = 0x101013a;
    *(undefined8 *)((long)puVar2 + lVar3 + 0x20) = param_2;
    *(undefined8 *)((long)puVar2 + lVar3 + 0x28) = param_3;
    *(long *)((long)puVar2 + lVar3 + 0x30) = lVar1;
  }
  return;
}


// ==== FUN_0012506c @ 0012506c

void FUN_0012506c(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  uVar4 = *param_3;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013cf50;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x38) = uVar4;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010135;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "const_cast";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00125114 @ 00125114

void FUN_00125114(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar6 = param_3[1];
  uVar5 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013cfc0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010137;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar6;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  return;
}


// ==== FUN_001251b0 @ 001251b0

void FUN_001251b0(long *param_1)

{
  long lVar1;
  long lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  char *pcVar5;
  long lVar6;
  long lVar7;
  long *plVar8;
  void *pvVar9;
  undefined1 auVar10 [16];
  long local_50;
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  pcVar5 = (char *)*param_1;
  if (((1 < (ulong)(param_1[1] - (long)pcVar5)) && (*pcVar5 == 'c')) && (pcVar5[1] == 'v')) {
    lVar6 = param_1[0x61];
    *(undefined1 *)(param_1 + 0x61) = 0;
    *param_1 = (long)(pcVar5 + 2);
                    /* try { // try from 00125214 to 00125217 has its CatchHandler @ 00125418 */
    lVar2 = FUN_0011ef00();
    *(char *)(param_1 + 0x61) = (char)lVar6;
    if (lVar2 != 0) {
      pcVar5 = (char *)*param_1;
      if ((pcVar5 == (char *)param_1[1]) || (*pcVar5 != '_')) {
        local_50 = FUN_00122d94(param_1);
        puVar4 = (undefined8 *)0x0;
        if (local_50 != 0) {
          pvVar9 = (void *)param_1[0x266];
          lVar6 = *(long *)((long)pvVar9 + 8);
          puVar4 = pvVar9;
          if (lVar6 - 0xfe0U < 0xfffffffffffff00f || lVar6 == -0x11) {
            puVar4 = malloc(0x1000);
            if (puVar4 == (void *)0x0) goto LAB_00125410;
            lVar6 = 0;
            *puVar4 = pvVar9;
            puVar4[1] = 0;
            param_1[0x266] = (long)puVar4;
          }
          *(long *)((long)puVar4 + 8) = lVar6 + 0x10;
          plVar8 = (long *)((long)puVar4 + lVar6 + 0x10);
          *plVar8 = local_50;
          pvVar9 = (void *)param_1[0x266];
          lVar6 = *(long *)((long)pvVar9 + 8);
          puVar3 = pvVar9;
          if (lVar6 - 0xfc0U < 0xfffffffffffff00f || lVar6 == -0x31) {
            puVar3 = malloc(0x1000);
            if (puVar3 == (void *)0x0) goto LAB_00125410;
            lVar6 = 0;
            *puVar3 = pvVar9;
            puVar3[1] = 0;
            param_1[0x266] = (long)puVar3;
          }
          *(long *)((long)puVar3 + 8) = lVar6 + 0x30;
          puVar4 = (undefined8 *)((long)puVar3 + lVar6 + 0x10);
          *puVar4 = &PTR_LAB_0013d030;
          *(undefined4 *)((long)puVar3 + lVar6 + 0x18) = 0x101013c;
          *(long *)((long)puVar3 + lVar6 + 0x20) = lVar2;
          *(long **)((long)puVar3 + lVar6 + 0x28) = plVar8;
          *(undefined8 *)((long)puVar3 + lVar6 + 0x30) = 1;
        }
      }
      else {
        lVar7 = param_1[3];
        pcVar5 = pcVar5 + 1;
        lVar6 = param_1[2];
        *param_1 = (long)pcVar5;
        if (pcVar5 == (char *)param_1[1]) goto LAB_0012526c;
        while (*pcVar5 != 'E') {
LAB_0012526c:
          do {
            local_50 = FUN_00122d94(param_1);
            puVar4 = (undefined8 *)0x0;
            if (local_50 == 0) goto LAB_0012529c;
            FUN_00120b24(param_1 + 2,&local_50);
            pcVar5 = (char *)*param_1;
          } while (pcVar5 == (char *)param_1[1]);
        }
        lVar6 = (lVar7 - lVar6 >> 3) * 8;
        *param_1 = (long)(pcVar5 + 1);
        auVar10 = FUN_0012a7b8(param_1,param_1[2] + lVar6,param_1[3]);
        pvVar9 = (void *)param_1[0x266];
        param_1[3] = param_1[2] + lVar6;
        lVar6 = *(long *)((long)pvVar9 + 8);
        puVar3 = pvVar9;
        if (lVar6 - 0xfc0U < 0xfffffffffffff00f || lVar6 == -0x31) {
          puVar3 = malloc(0x1000);
          if (puVar3 == (void *)0x0) {
LAB_00125410:
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar6 = 0;
          *puVar3 = pvVar9;
          puVar3[1] = 0;
          param_1[0x266] = (long)puVar3;
        }
        *(long *)((long)puVar3 + 8) = lVar6 + 0x30;
        puVar4 = (undefined8 *)((long)puVar3 + lVar6 + 0x10);
        *puVar4 = &PTR_LAB_0013d030;
        *(undefined4 *)((long)puVar3 + lVar6 + 0x18) = 0x101013c;
        *(long *)((long)puVar3 + lVar6 + 0x20) = lVar2;
        *(undefined1 (*) [16])((long)puVar3 + lVar6 + 0x28) = auVar10;
      }
      goto LAB_0012529c;
    }
  }
  puVar4 = (undefined8 *)0x0;
LAB_0012529c:
  if (*(long *)(lVar1 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar4);
  }
  return;
}


// ==== FUN_00125420 @ 00125420

void FUN_00125420(long param_1,undefined8 *param_2,undefined1 *param_3,undefined1 *param_4)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined8 *puVar3;
  long lVar4;
  undefined8 uVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar4 = *(long *)((long)pvVar6 + 8);
  puVar3 = pvVar6;
  if (lVar4 - 0xfd0U < 0xfffffffffffff00f || lVar4 == -0x21) {
    puVar3 = malloc(0x1000);
    if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar4 = 0;
    *puVar3 = pvVar6;
    puVar3[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar3;
  }
  uVar5 = *param_2;
  uVar1 = *param_3;
  uVar2 = *param_4;
  *(long *)((long)puVar3 + 8) = lVar4 + 0x20;
  *(undefined ***)((long)puVar3 + lVar4 + 0x10) = &PTR_LAB_0013d0a0;
  *(undefined4 *)((long)puVar3 + lVar4 + 0x18) = 0x1010139;
  *(undefined8 *)((long)puVar3 + lVar4 + 0x20) = uVar5;
  *(undefined1 *)((long)puVar3 + lVar4 + 0x28) = uVar1;
  *(undefined1 *)((long)puVar3 + lVar4 + 0x29) = uVar2;
  return;
}


// ==== FUN_001254d0 @ 001254d0

void FUN_001254d0(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  uVar4 = *param_3;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013cf50;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x38) = uVar4;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010135;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "dynamic_cast";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00125578 @ 00125578

undefined8 * FUN_00125578(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  long lVar3;
  bool bVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  char *pcVar7;
  long lVar8;
  undefined8 *puVar9;
  long lVar10;
  char cVar11;
  void *pvVar12;
  undefined8 *unaff_x25;
  long local_78;
  undefined8 *local_70;
  long local_68;
  
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  pcVar7 = (char *)*param_1;
  pbVar2 = (byte *)param_1[1];
  if ((ulong)((long)pbVar2 - (long)pcVar7) < 3) {
    if ((long)pbVar2 - (long)pcVar7 != 2) {
LAB_001256d8:
      puVar5 = (undefined8 *)FUN_0012ad20(param_1);
      if (*(long *)(lVar3 + 0x28) == local_68) {
        return puVar5;
      }
      goto LAB_00125ab8;
    }
    cVar11 = *pcVar7;
LAB_001256a4:
    bVar4 = cVar11 == 'g';
    if (bVar4) {
      if (pcVar7[1] != 's') goto LAB_001256d8;
      pcVar7 = pcVar7 + 2;
      *param_1 = (long)pcVar7;
      if (1 < (ulong)((long)pbVar2 - (long)pcVar7)) {
        cVar11 = *pcVar7;
        goto LAB_00125778;
      }
      bVar4 = true;
    }
    else {
LAB_00125778:
      if (cVar11 == 's') goto LAB_00125780;
    }
LAB_00125808:
    puVar5 = (undefined8 *)FUN_0012ad20(param_1);
    puVar9 = puVar5;
    if ((bVar4) && (puVar5 != (undefined8 *)0x0)) {
      pvVar12 = (void *)param_1[0x266];
      lVar8 = *(long *)((long)pvVar12 + 8);
      puVar6 = pvVar12;
      if (lVar8 - 0xfd0U < 0xfffffffffffff00f || lVar8 == -0x21) {
        puVar6 = malloc(0x1000);
        if (puVar6 == (void *)0x0) {
LAB_00125ab4:
                    /* WARNING: Subroutine does not return */
          FUN_0011dc6c();
        }
        lVar8 = 0;
        *puVar6 = pvVar12;
        puVar6[1] = 0;
        param_1[0x266] = (long)puVar6;
      }
      *(long *)((long)puVar6 + 8) = lVar8 + 0x20;
      puVar9 = (undefined8 *)((long)puVar6 + lVar8 + 0x10);
      *puVar9 = &PTR_LAB_0013d2d0;
      *(undefined8 **)((long)puVar6 + lVar8 + 0x20) = puVar5;
      *(undefined4 *)((long)puVar6 + lVar8 + 0x18) = 0x1010126;
    }
  }
  else {
    cVar11 = *pcVar7;
    if (cVar11 != 's') goto LAB_001256a4;
    if ((pcVar7[1] == 'r') && (pcVar7[2] == 'N')) {
      *param_1 = (long)(pcVar7 + 3);
      puVar5 = (undefined8 *)FUN_0012ab90(param_1);
      if (puVar5 == (undefined8 *)0x0) goto LAB_00125a78;
      puVar6 = puVar5;
      if (((char *)param_1[1] != (char *)*param_1) && (*(char *)*param_1 == 'I')) {
        lVar8 = FUN_00121af4(param_1,0);
        puVar9 = (undefined8 *)0x0;
        if (lVar8 == 0) goto LAB_00125a7c;
        pvVar12 = (void *)param_1[0x266];
        lVar10 = *(long *)((long)pvVar12 + 8);
        puVar9 = pvVar12;
        if (lVar10 - 0xfd0U < 0xfffffffffffff00f || lVar10 == -0x21) {
          puVar9 = malloc(0x1000);
          if (puVar9 == (void *)0x0) goto LAB_00125ab4;
          lVar10 = 0;
          *puVar9 = pvVar12;
          puVar9[1] = 0;
          param_1[0x266] = (long)puVar9;
        }
        *(long *)((long)puVar9 + 8) = lVar10 + 0x20;
        puVar6 = (undefined8 *)((long)puVar9 + lVar10 + 0x10);
        *puVar6 = &PTR_LAB_0013dc70;
        *(undefined8 **)((long)puVar9 + lVar10 + 0x20) = puVar5;
        *(long *)((long)puVar9 + lVar10 + 0x28) = lVar8;
        *(undefined4 *)((long)puVar9 + lVar10 + 0x18) = 0x1010125;
      }
      while( true ) {
        pcVar7 = (char *)*param_1;
        if ((pcVar7 != (char *)param_1[1]) && (*pcVar7 == 'E')) {
          *param_1 = (long)(pcVar7 + 1);
          local_70 = unaff_x25;
          lVar8 = FUN_0012ad20(param_1);
          if (lVar8 == 0) goto LAB_00125a78;
          pvVar12 = (void *)param_1[0x266];
          lVar10 = *(long *)((long)pvVar12 + 8);
          puVar5 = pvVar12;
          if (lVar10 - 0xfd0U < 0xfffffffffffff00f || lVar10 == -0x21) {
            puVar5 = malloc(0x1000);
            if (puVar5 == (void *)0x0) goto LAB_00125ab4;
            lVar10 = 0;
            *puVar5 = pvVar12;
            puVar5[1] = 0;
            param_1[0x266] = (long)puVar5;
          }
          *(long *)((long)puVar5 + 8) = lVar10 + 0x20;
          puVar9 = (undefined8 *)((long)puVar5 + lVar10 + 0x10);
          *puVar9 = &PTR_LAB_0013d110;
          *(undefined4 *)((long)puVar5 + lVar10 + 0x18) = 0x1010116;
          goto LAB_001259fc;
        }
        lVar8 = FUN_0012ac50(param_1);
        if (lVar8 == 0) break;
        pvVar12 = (void *)param_1[0x266];
        lVar10 = *(long *)((long)pvVar12 + 8);
        puVar5 = pvVar12;
        if (lVar10 - 0xfd0U < 0xfffffffffffff00f || lVar10 == -0x21) {
          puVar5 = malloc(0x1000);
          if (puVar5 == (void *)0x0) goto LAB_00125ab4;
          lVar10 = 0;
          *puVar5 = pvVar12;
          puVar5[1] = 0;
          param_1[0x266] = (long)puVar5;
        }
        *(long *)((long)puVar5 + 8) = lVar10 + 0x20;
        unaff_x25 = (undefined8 *)((long)puVar5 + lVar10 + 0x10);
        *unaff_x25 = &PTR_LAB_0013d110;
        *(undefined8 **)((long)puVar5 + lVar10 + 0x20) = puVar6;
        *(long *)((long)puVar5 + lVar10 + 0x28) = lVar8;
        *(undefined4 *)((long)puVar5 + lVar10 + 0x18) = 0x1010116;
        puVar6 = unaff_x25;
      }
      puVar9 = (undefined8 *)0x0;
      local_70 = unaff_x25;
    }
    else {
      bVar4 = false;
LAB_00125780:
      if (pcVar7[1] != 'r') goto LAB_00125808;
      pbVar1 = (byte *)(pcVar7 + 2);
      *param_1 = (long)pbVar1;
      if ((pbVar2 == pbVar1) || (*pbVar1 - 0x3a < 0xfffffff6)) {
        local_70 = (undefined8 *)FUN_0012ab90(param_1);
        if (local_70 != (undefined8 *)0x0) {
          if (((char *)param_1[1] != (char *)*param_1) && (*(char *)*param_1 == 'I')) {
            local_78 = FUN_00121af4(param_1,0);
            if (local_78 == 0) goto LAB_00125a78;
            local_70 = (undefined8 *)FUN_00121f70(param_1,&local_70,&local_78);
          }
LAB_00125998:
          puVar6 = local_70;
          lVar8 = FUN_0012ad20(param_1);
          if (lVar8 != 0) {
            pvVar12 = (void *)param_1[0x266];
            lVar10 = *(long *)((long)pvVar12 + 8);
            puVar5 = pvVar12;
            if (lVar10 - 0xfd0U < 0xfffffffffffff00f || lVar10 == -0x21) {
              puVar5 = malloc(0x1000);
              if (puVar5 == (void *)0x0) goto LAB_00125ab4;
              lVar10 = 0;
              *puVar5 = pvVar12;
              puVar5[1] = 0;
              param_1[0x266] = (long)puVar5;
            }
            *(long *)((long)puVar5 + 8) = lVar10 + 0x20;
            puVar9 = (undefined8 *)((long)puVar5 + lVar10 + 0x10);
            *puVar9 = &PTR_LAB_0013d110;
            *(undefined4 *)((long)puVar5 + lVar10 + 0x18) = 0x1010116;
LAB_001259fc:
            puVar9[2] = puVar6;
            puVar9[3] = lVar8;
            goto LAB_00125a7c;
          }
        }
LAB_00125a78:
        puVar9 = (undefined8 *)0x0;
      }
      else {
        puVar5 = (undefined8 *)FUN_0012ac50(param_1);
        puVar9 = (undefined8 *)0x0;
        if (puVar5 != (undefined8 *)0x0) {
          puVar6 = (undefined8 *)0x0;
          do {
            if (puVar6 == (undefined8 *)0x0) {
              if (bVar4) {
                pvVar12 = (void *)param_1[0x266];
                lVar8 = *(long *)((long)pvVar12 + 8);
                puVar6 = pvVar12;
                if (lVar8 - 0xfd0U < 0xfffffffffffff00f || lVar8 == -0x21) {
                  puVar6 = malloc(0x1000);
                  if (puVar6 == (void *)0x0) goto LAB_00125ab4;
                  lVar8 = 0;
                  *puVar6 = pvVar12;
                  puVar6[1] = 0;
                  param_1[0x266] = (long)puVar6;
                }
                *(long *)((long)puVar6 + 8) = lVar8 + 0x20;
                local_70 = (undefined8 *)((long)puVar6 + lVar8 + 0x10);
                *local_70 = &PTR_LAB_0013d2d0;
                *(undefined4 *)((long)puVar6 + lVar8 + 0x18) = 0x1010126;
                *(undefined8 **)((long)puVar6 + lVar8 + 0x20) = puVar5;
              }
              else {
                local_70 = puVar5;
              }
            }
            else {
              pvVar12 = (void *)param_1[0x266];
              lVar8 = *(long *)((long)pvVar12 + 8);
              puVar9 = pvVar12;
              if (lVar8 - 0xfd0U < 0xfffffffffffff00f || lVar8 == -0x21) {
                puVar9 = malloc(0x1000);
                if (puVar9 == (void *)0x0) goto LAB_00125ab4;
                lVar8 = 0;
                *puVar9 = pvVar12;
                puVar9[1] = 0;
                param_1[0x266] = (long)puVar9;
              }
              *(long *)((long)puVar9 + 8) = lVar8 + 0x20;
              local_70 = (undefined8 *)((long)puVar9 + lVar8 + 0x10);
              *local_70 = &PTR_LAB_0013d110;
              *(undefined4 *)((long)puVar9 + lVar8 + 0x18) = 0x1010116;
              *(undefined8 **)((long)puVar9 + lVar8 + 0x20) = puVar6;
              *(undefined8 **)((long)puVar9 + lVar8 + 0x28) = puVar5;
            }
            puVar6 = local_70;
            pcVar7 = (char *)*param_1;
            if ((pcVar7 != (char *)param_1[1]) && (*pcVar7 == 'E')) {
              *param_1 = (long)(pcVar7 + 1);
              goto LAB_00125998;
            }
            puVar5 = (undefined8 *)FUN_0012ac50(param_1);
            puVar9 = (undefined8 *)0x0;
          } while (puVar5 != (undefined8 *)0x0);
        }
      }
    }
  }
LAB_00125a7c:
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return puVar9;
  }
LAB_00125ab8:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00125abc @ 00125abc

undefined8 * FUN_00125abc(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  void *pvVar7;
  
  pvVar7 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar7 + 8);
  puVar1 = pvVar7;
  if (lVar3 - 0xfc0U < 0xfffffffffffff00f || lVar3 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar7;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar5 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar3 + 0x30;
  sVar2 = strlen(param_3);
  uVar4 = *param_4;
  puVar6 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar6 = &PTR_LAB_0013d340;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010133;
  *(undefined8 *)((long)puVar1 + lVar3 + 0x20) = uVar5;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_3;
  *(char **)((long)puVar1 + lVar3 + 0x30) = param_3 + sVar2;
  *(undefined8 *)((long)puVar1 + lVar3 + 0x38) = uVar4;
  return puVar6;
}


// ==== FUN_00125b74 @ 00125b74

void FUN_00125b74(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  uVar4 = *param_3;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d340;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010133;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined **)((long)puVar1 + lVar2 + 0x28) = &DAT_00109caa;
  *(undefined **)((long)puVar1 + lVar2 + 0x30) = &DAT_00109cab;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x38) = uVar4;
  return;
}


// ==== FUN_00125c1c @ 00125c1c

void FUN_00125c1c(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar4 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d3b0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010130;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar4;
  return;
}


// ==== FUN_00125cb4 @ 00125cb4

void FUN_00125cb4(long *param_1)

{
  char *pcVar1;
  char cVar2;
  long lVar3;
  long lVar4;
  undefined8 *puVar5;
  long lVar6;
  long lVar7;
  void *pvVar8;
  
  pcVar1 = (char *)*param_1;
  if (((char *)param_1[1] == pcVar1) || (*pcVar1 != 'd' || param_1[1] - (long)pcVar1 == 1)) {
LAB_00125cec:
    FUN_00122d94(param_1);
    return;
  }
  cVar2 = pcVar1[1];
  if (cVar2 == 'X') {
    *param_1 = (long)(pcVar1 + 2);
    lVar3 = FUN_00122d94(param_1);
    if (((lVar3 != 0) && (lVar4 = FUN_00122d94(param_1), lVar4 != 0)) &&
       (lVar6 = FUN_00125cb4(param_1), lVar6 != 0)) {
      pvVar8 = (void *)param_1[0x266];
      lVar7 = *(long *)((long)pvVar8 + 8);
      puVar5 = pvVar8;
      if (lVar7 - 0xfc0U < 0xfffffffffffff00f || lVar7 == -0x31) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (void *)0x0) {
LAB_00125ee4:
                    /* WARNING: Subroutine does not return */
          FUN_0011dc6c();
        }
        lVar7 = 0;
        *puVar5 = pvVar8;
        puVar5[1] = 0;
        param_1[0x266] = (long)puVar5;
      }
      *(long *)((long)puVar5 + 8) = lVar7 + 0x30;
      *(undefined ***)((long)puVar5 + lVar7 + 0x10) = &PTR_LAB_0013d490;
      *(undefined4 *)((long)puVar5 + lVar7 + 0x18) = 0x101014a;
      *(long *)((long)puVar5 + lVar7 + 0x20) = lVar3;
      *(long *)((long)puVar5 + lVar7 + 0x28) = lVar4;
      *(long *)((long)puVar5 + lVar7 + 0x30) = lVar6;
    }
  }
  else if (cVar2 == 'x') {
    *param_1 = (long)(pcVar1 + 2);
    lVar3 = FUN_00122d94(param_1);
    if ((lVar3 != 0) && (lVar4 = FUN_00125cb4(param_1), lVar4 != 0)) {
      pvVar8 = (void *)param_1[0x266];
      lVar6 = *(long *)((long)pvVar8 + 8);
      puVar5 = pvVar8;
      if (lVar6 - 0xfc0U < 0xfffffffffffff00f || lVar6 == -0x31) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (void *)0x0) goto LAB_00125ee4;
        lVar6 = 0;
        *puVar5 = pvVar8;
        puVar5[1] = 0;
        param_1[0x266] = (long)puVar5;
      }
      *(long *)((long)puVar5 + 8) = lVar6 + 0x30;
      *(undefined ***)((long)puVar5 + lVar6 + 0x10) = &PTR_LAB_0013d420;
      *(undefined4 *)((long)puVar5 + lVar6 + 0x18) = 0x1010149;
      *(long *)((long)puVar5 + lVar6 + 0x20) = lVar3;
      *(long *)((long)puVar5 + lVar6 + 0x28) = lVar4;
      *(undefined1 *)((long)puVar5 + lVar6 + 0x30) = 1;
    }
  }
  else {
    if (cVar2 != 'i') goto LAB_00125cec;
    *param_1 = (long)(pcVar1 + 2);
    lVar3 = FUN_0012af08(param_1);
    if ((lVar3 != 0) && (lVar4 = FUN_00125cb4(param_1), lVar4 != 0)) {
      pvVar8 = (void *)param_1[0x266];
      lVar6 = *(long *)((long)pvVar8 + 8);
      puVar5 = pvVar8;
      if (lVar6 - 0xfc0U < 0xfffffffffffff00f || lVar6 == -0x31) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (void *)0x0) goto LAB_00125ee4;
        lVar6 = 0;
        *puVar5 = pvVar8;
        puVar5[1] = 0;
        param_1[0x266] = (long)puVar5;
      }
      *(long *)((long)puVar5 + 8) = lVar6 + 0x30;
      *(undefined ***)((long)puVar5 + lVar6 + 0x10) = &PTR_LAB_0013d420;
      *(undefined4 *)((long)puVar5 + lVar6 + 0x18) = 0x1010149;
      *(long *)((long)puVar5 + lVar6 + 0x20) = lVar3;
      *(long *)((long)puVar5 + lVar6 + 0x28) = lVar4;
      *(undefined1 *)((long)puVar5 + lVar6 + 0x30) = 0;
    }
  }
  return;
}


// ==== FUN_00125ee8 @ 00125ee8

void FUN_00125ee8(long param_1,undefined8 param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  void *pvVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  
  pvVar3 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar3 + 8);
  puVar1 = pvVar3;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar3;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar5 = param_3[1];
  uVar4 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d500;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x101013d;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = 0;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar5;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar4;
  return;
}


// ==== FUN_00125f7c @ 00125f7c

undefined8 * FUN_00125f7c(long param_1,undefined8 *param_2,char *param_3)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar6 + 8);
  puVar1 = pvVar6;
  if (lVar3 - 0xfc0U < 0xfffffffffffff00f || lVar3 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar6;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar4 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar3 + 0x30;
  sVar2 = strlen(param_3);
  puVar5 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar5 = &PTR_LAB_0013d570;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010131;
  *(undefined8 *)((long)puVar1 + lVar3 + 0x20) = uVar4;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_3;
  *(char **)((long)puVar1 + lVar3 + 0x30) = param_3 + sVar2;
  return puVar5;
}


// ==== FUN_00126024 @ 00126024

void FUN_00126024(long *param_1)

{
  char *pcVar1;
  long lVar2;
  char cVar3;
  char cVar4;
  long lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  char *pcVar8;
  long lVar9;
  long lVar10;
  long *plVar11;
  undefined1 uVar12;
  void *pvVar13;
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  long local_70;
  long local_68;
  
  lVar5 = tpidr_el0;
  local_68 = *(long *)(lVar5 + 0x28);
  pcVar8 = (char *)*param_1;
  pcVar1 = (char *)param_1[1];
  if (1 < (ulong)((long)pcVar1 - (long)pcVar8)) {
    cVar3 = *pcVar8;
    if (cVar3 == 'g') {
      if (pcVar8[1] == 's') {
        pcVar8 = pcVar8 + 2;
        *param_1 = (long)pcVar8;
        if (1 < (ulong)((long)pcVar1 - (long)pcVar8)) {
          cVar3 = *pcVar8;
          uVar12 = 1;
          goto LAB_001260a4;
        }
      }
    }
    else {
      uVar12 = 0;
LAB_001260a4:
      cVar4 = pcVar8[1];
      if ((cVar3 == 'n') && ((cVar4 == 'w' || (cVar4 == 'a')))) {
        lVar10 = param_1[3];
        pcVar8 = pcVar8 + 2;
        plVar11 = param_1 + 2;
        lVar9 = *plVar11;
        *param_1 = (long)pcVar8;
        if (pcVar8 == pcVar1) goto LAB_001260f8;
        while (*pcVar8 != '_') {
LAB_001260f8:
          do {
            local_70 = FUN_00122d94(param_1);
            puVar7 = (undefined8 *)0x0;
            if (local_70 == 0) goto LAB_0012626c;
            FUN_00120b24(plVar11,&local_70);
            pcVar8 = (char *)*param_1;
          } while (pcVar8 == (char *)param_1[1]);
        }
        lVar9 = (lVar10 - lVar9 >> 3) * 8;
        *param_1 = (long)(pcVar8 + 1);
        auVar14 = FUN_0012a7b8(param_1,param_1[2] + lVar9,param_1[3]);
        param_1[3] = param_1[2] + lVar9;
        lVar9 = FUN_0011ef00(param_1);
        puVar7 = (undefined8 *)0x0;
        if (lVar9 == 0) goto LAB_0012626c;
        pcVar8 = (char *)*param_1;
        pcVar1 = (char *)param_1[1];
        if ((((ulong)((long)pcVar1 - (long)pcVar8) < 2) || (*pcVar8 != 'p')) || (pcVar8[1] != 'i'))
        {
          if ((pcVar8 == pcVar1) || (*pcVar8 != 'E')) goto LAB_00126268;
          pvVar13 = (void *)param_1[0x266];
          *param_1 = (long)(pcVar8 + 1);
          lVar10 = *(long *)((long)pvVar13 + 8);
          puVar6 = pvVar13;
          if (lVar10 - 0xfb0U < 0xfffffffffffff00f || lVar10 == -0x41) {
            puVar6 = malloc(0x1000);
            if (puVar6 == (void *)0x0) goto LAB_00126334;
            lVar10 = 0;
            *puVar6 = pvVar13;
            puVar6[1] = 0;
            param_1[0x266] = (long)puVar6;
          }
          *(long *)((long)puVar6 + 8) = lVar10 + 0x40;
          puVar7 = (undefined8 *)((long)puVar6 + lVar10 + 0x10);
          *puVar7 = &PTR_LAB_0013d5e0;
          *(undefined4 *)((long)puVar6 + lVar10 + 0x18) = 0x1010138;
          *(undefined1 (*) [16])((long)puVar6 + lVar10 + 0x20) = auVar14;
          *(undefined8 *)((long)puVar6 + lVar10 + 0x38) = 0;
          *(undefined8 *)((long)puVar6 + lVar10 + 0x40) = 0;
          *(long *)((long)puVar6 + lVar10 + 0x30) = lVar9;
        }
        else {
          lVar10 = param_1[2];
          lVar2 = param_1[3];
          pcVar8 = pcVar8 + 2;
          *param_1 = (long)pcVar8;
          if (pcVar8 == pcVar1) goto LAB_001261b4;
          while (*pcVar8 != 'E') {
LAB_001261b4:
            do {
              local_70 = FUN_00122d94(param_1);
              puVar7 = (undefined8 *)0x0;
              if (local_70 == 0) goto LAB_0012626c;
              FUN_00120b24(plVar11,&local_70);
              pcVar8 = (char *)*param_1;
            } while (pcVar8 == (char *)param_1[1]);
          }
          lVar10 = (lVar2 - lVar10 >> 3) * 8;
          *param_1 = (long)(pcVar8 + 1);
          auVar15 = FUN_0012a7b8(param_1,param_1[2] + lVar10,param_1[3]);
          pvVar13 = (void *)param_1[0x266];
          param_1[3] = param_1[2] + lVar10;
          lVar10 = *(long *)((long)pvVar13 + 8);
          puVar6 = pvVar13;
          if (lVar10 - 0xfb0U < 0xfffffffffffff00f || lVar10 == -0x41) {
            puVar6 = malloc(0x1000);
            if (puVar6 == (void *)0x0) {
LAB_00126334:
                    /* WARNING: Subroutine does not return */
              FUN_0011dc6c();
            }
            lVar10 = 0;
            *puVar6 = pvVar13;
            puVar6[1] = 0;
            param_1[0x266] = (long)puVar6;
          }
          *(long *)((long)puVar6 + 8) = lVar10 + 0x40;
          puVar7 = (undefined8 *)((long)puVar6 + lVar10 + 0x10);
          *puVar7 = &PTR_LAB_0013d5e0;
          *(undefined4 *)((long)puVar6 + lVar10 + 0x18) = 0x1010138;
          *(undefined1 (*) [16])((long)puVar6 + lVar10 + 0x20) = auVar14;
          *(long *)((long)puVar6 + lVar10 + 0x30) = lVar9;
          *(undefined1 (*) [16])((long)puVar6 + lVar10 + 0x38) = auVar15;
        }
        *(undefined1 *)(puVar7 + 7) = uVar12;
        *(bool *)((long)puVar7 + 0x39) = cVar4 == 'a';
        goto LAB_0012626c;
      }
    }
  }
LAB_00126268:
  puVar7 = (undefined8 *)0x0;
LAB_0012626c:
  if (*(long *)(lVar5 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar7);
  }
  return;
}


// ==== FUN_0012633c @ 0012633c

void FUN_0012633c(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfb0U < 0xfffffffffffff00f || lVar2 == -0x41) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d650;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x40;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010134;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "noexcept (";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(undefined **)((long)puVar1 + lVar2 + 0x38) = &DAT_0010b201;
  *(undefined **)((long)puVar1 + lVar2 + 0x40) = &DAT_0010b202;
  return;
}


// ==== FUN_001263ec @ 001263ec

void FUN_001263ec(long param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar6 + 8);
  puVar1 = pvVar6;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar6;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar4 = *param_2;
  uVar5 = *param_3;
  uVar3 = *param_4;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d6c0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010132;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar4;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  return;
}


// ==== FUN_00126498 @ 00126498

void FUN_00126498(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  uVar4 = *param_3;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013cf50;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x38) = uVar4;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010135;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "reinterpret_cast";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_00126540 @ 00126540

void FUN_00126540(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  uVar4 = *param_3;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013cf50;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x38) = uVar4;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010135;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "static_cast";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  return;
}


// ==== FUN_001265e8 @ 001265e8

void FUN_001265e8(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013ce00;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010122;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_00126678 @ 00126678

undefined8 * FUN_00126678(long param_1,char *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar6 + 8);
  puVar1 = pvVar6;
  if (lVar3 - 0xfb0U < 0xfffffffffffff00f || lVar3 == -0x41) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar6;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x40;
  sVar2 = strlen(param_2);
  uVar4 = *param_3;
  puVar5 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar5 = &PTR_LAB_0013d650;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010134;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  *(undefined8 *)((long)puVar1 + lVar3 + 0x30) = uVar4;
  *(undefined **)((long)puVar1 + lVar3 + 0x38) = &DAT_0010b201;
  *(undefined **)((long)puVar1 + lVar3 + 0x40) = &DAT_0010b202;
  return puVar5;
}


// ==== FUN_00126730 @ 00126730

void FUN_00126730(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d730;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010136;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_001267c0 @ 001267c0

void FUN_001267c0(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfb0U < 0xfffffffffffff00f || lVar2 == -0x41) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d650;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x40;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010134;
  *(char **)((long)puVar1 + lVar2 + 0x20) = "sizeof... (";
  *(char **)((long)puVar1 + lVar2 + 0x28) = "";
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar3;
  *(undefined **)((long)puVar1 + lVar2 + 0x38) = &DAT_0010b201;
  *(undefined **)((long)puVar1 + lVar2 + 0x40) = &DAT_0010b202;
  return;
}


// ==== FUN_00126870 @ 00126870

void FUN_00126870(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  void *pvVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  
  pvVar3 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar3 + 8);
  puVar1 = pvVar3;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar3;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar5 = param_2[1];
  uVar4 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d7a0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010100;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar4;
  return;
}


// ==== FUN_00126900 @ 00126900

void FUN_00126900(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar6 = param_3[1];
  uVar5 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d500;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x101013d;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar6;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  return;
}


// ==== FUN_0012699c @ 0012699c

undefined8 * FUN_0012699c(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_00126a38 @ 00126a38

void FUN_00126a38(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d810;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x101013f;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_00126ac8 @ 00126ac8

void FUN_00126ac8(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d880;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010140;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_00126b58 @ 00126b58

undefined8 * FUN_00126b58(long *param_1,undefined8 param_2,undefined8 param_3)

{
  byte *pbVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  long lVar4;
  byte *pbVar5;
  byte *pbVar6;
  byte *pbVar7;
  void *pvVar8;
  
  pbVar6 = (byte *)*param_1;
  pbVar1 = (byte *)param_1[1];
  pbVar5 = pbVar6;
  if ((pbVar6 != pbVar1) && (*pbVar6 == 0x6e)) {
    pbVar5 = pbVar6 + 1;
    *param_1 = (long)pbVar5;
  }
  if (pbVar1 == pbVar5) {
    pbVar6 = (byte *)0x0;
    pbVar7 = (byte *)0x0;
    pbVar5 = pbVar1;
  }
  else if (*pbVar5 - 0x3a < 0xfffffff6) {
    pbVar6 = (byte *)0x0;
    pbVar7 = (byte *)0x0;
  }
  else {
    do {
      pbVar5 = pbVar5 + 1;
      *param_1 = (long)pbVar5;
      if (pbVar5 == pbVar1) {
        pbVar7 = pbVar1;
        goto LAB_00126c0c;
      }
    } while (0xfffffff5 < *pbVar5 - 0x3a);
    pbVar7 = pbVar5;
  }
LAB_00126c0c:
  puVar2 = (undefined8 *)0x0;
  if ((pbVar7 != pbVar6) && (pbVar5 != pbVar1)) {
    if (*pbVar5 == 0x45) {
      pvVar8 = (void *)param_1[0x266];
      lVar4 = *(long *)((long)pvVar8 + 8);
      *param_1 = (long)(pbVar5 + 1);
      puVar3 = pvVar8;
      if (lVar4 - 0xfc0U < 0xfffffffffffff00f || lVar4 == -0x31) {
        puVar3 = malloc(0x1000);
        if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0011dc6c();
        }
        lVar4 = 0;
        *puVar3 = pvVar8;
        puVar3[1] = 0;
        param_1[0x266] = (long)puVar3;
      }
      *(long *)((long)puVar3 + 8) = lVar4 + 0x30;
      puVar2 = (undefined8 *)((long)puVar3 + lVar4 + 0x10);
      *puVar2 = &PTR_LAB_0013c690;
      *(undefined4 *)((long)puVar3 + lVar4 + 0x18) = 0x1010145;
      *(undefined8 *)((long)puVar3 + lVar4 + 0x20) = param_2;
      *(undefined8 *)((long)puVar3 + lVar4 + 0x28) = param_3;
      *(byte **)((long)puVar3 + lVar4 + 0x30) = pbVar6;
      *(byte **)((long)puVar3 + lVar4 + 0x38) = pbVar7;
    }
    else {
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}


// ==== FUN_00126cb4 @ 00126cb4

void FUN_00126cb4(long param_1,int *param_2)

{
  int iVar1;
  undefined8 *puVar2;
  long lVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar4 + 8);
  puVar2 = pvVar4;
  if (lVar3 - 0xfe0U < 0xfffffffffffff00f || lVar3 == -0x11) {
    puVar2 = malloc(0x1000);
    if (puVar2 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar2 = pvVar4;
    puVar2[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar2;
  }
  iVar1 = *param_2;
  *(undefined ***)((long)puVar2 + lVar3 + 0x10) = &PTR_LAB_0013c700;
  *(long *)((long)puVar2 + 8) = lVar3 + 0x10;
  *(undefined4 *)((long)puVar2 + lVar3 + 0x18) = 0x1010141;
  *(bool *)((long)puVar2 + lVar3 + 0x1c) = iVar1 != 0;
  return;
}


// ==== FUN_00126d4c @ 00126d4c

void FUN_00126d4c(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c8c0;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010142;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_00126ddc @ 00126ddc

undefined8 * FUN_00126ddc(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_00126e78 @ 00126e78

undefined8 * FUN_00126e78(long *param_1,long param_2)

{
  byte *pbVar1;
  char cVar2;
  long lVar3;
  size_t __n;
  undefined *puVar4;
  ulong uVar5;
  undefined8 *puVar6;
  uint __c;
  long lVar7;
  char *pcVar8;
  long lVar9;
  byte *pbVar10;
  long lVar11;
  ulong uVar12;
  byte *pbVar13;
  char *pcVar14;
  byte *pbVar15;
  char *pcVar16;
  long *plVar17;
  void *pvVar18;
  long lVar19;
  undefined8 *puVar20;
  long lVar21;
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  undefined8 **local_d8;
  long *local_d0;
  long lStack_c8;
  undefined8 *local_c0;
  undefined8 *puStack_b8;
  long *local_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  long local_68;
  
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  if (param_2 != 0) {
    param_1[0x54] = param_1[0x53];
  }
  pcVar8 = (char *)*param_1;
  pbVar1 = (byte *)param_1[1];
  if ((1 < (ulong)((long)pbVar1 - (long)pcVar8)) && (*pcVar8 == 'U')) {
    cVar2 = pcVar8[1];
    if (cVar2 == 'b') {
      pbVar15 = (byte *)(pcVar8 + 2);
      *param_1 = (long)pbVar15;
      if (pbVar1 != pbVar15) {
        if (0xfffffff5 < *pbVar15 - 0x3a) {
          pbVar10 = (byte *)(pcVar8 + 3);
          do {
            pbVar15 = pbVar10;
            *param_1 = (long)pbVar15;
            if (pbVar15 == pbVar1) goto LAB_001272e4;
            pbVar10 = pbVar15 + 1;
          } while (0xfffffff5 < *pbVar15 - 0x3a);
        }
        if ((pbVar15 != pbVar1) && (*pbVar15 == 0x5f)) {
          pvVar18 = (void *)param_1[0x266];
          *param_1 = (long)(pbVar15 + 1);
          lVar11 = *(long *)((long)pvVar18 + 8);
          puVar6 = pvVar18;
          if (lVar11 - 0xfd0U < 0xfffffffffffff00f || lVar11 == -0x21) {
            puVar6 = malloc(0x1000);
            if (puVar6 == (void *)0x0) goto LAB_001273ec;
            lVar11 = 0;
            *puVar6 = pvVar18;
            puVar6[1] = 0;
            param_1[0x266] = (long)puVar6;
          }
          *(long *)((long)puVar6 + 8) = lVar11 + 0x20;
          puVar20 = (undefined8 *)((long)puVar6 + lVar11 + 0x10);
          *puVar20 = &PTR_LAB_0013c540;
          *(undefined4 *)((long)puVar6 + lVar11 + 0x18) = 0x1010107;
          *(char **)((long)puVar6 + lVar11 + 0x20) = "\'block-literal\'";
          *(char **)((long)puVar6 + lVar11 + 0x28) = "";
          goto LAB_001272e8;
        }
      }
    }
    else {
      if (cVar2 == 'l') {
        lVar21 = param_1[0x62];
        local_b0 = &local_68;
        lStack_c8 = param_1[0x54] - param_1[0x53] >> 3;
        *param_1 = (long)(pcVar8 + 2);
        param_1[0x62] = lStack_c8;
        local_d8 = &local_c0;
        uStack_a0 = 0;
        local_a8 = 0;
        uStack_90 = 0;
        local_98 = 0;
        uStack_80 = 0;
        local_88 = 0;
        uStack_70 = 0;
        local_78 = 0;
        local_d0 = param_1;
        local_c0 = &local_a8;
        puStack_b8 = &local_a8;
        FUN_001229cc(param_1 + 0x53,&local_d8);
        lVar19 = param_1[3];
        pcVar8 = (char *)*param_1;
        plVar17 = param_1 + 2;
        lVar11 = *plVar17;
        if ((char *)param_1[1] == pcVar8) {
          lVar7 = lVar19;
          lVar9 = lVar11;
        }
        else {
          while (*pcVar8 == 'T') {
                    /* try { // try from 00126fa8 to 00126fb3 has its CatchHandler @ 001273fc */
            __n = __strlen_chk(&DAT_0010acb4,5);
            if ((ulong)(param_1[1] - *param_1) < 2) {
              __c = 0;
            }
            else {
              __c = (uint)*(byte *)(*param_1 + 1);
            }
            if (((__n == 0) || (puVar4 = memchr(&DAT_0010acb4,__c,__n), puVar4 == (undefined *)0x0))
               || (puVar4 == &UNK_0010acb3)) break;
                    /* try { // try from 00126ff0 to 00126ff7 has its CatchHandler @ 001273f8 */
            local_d8 = (undefined8 **)FUN_00128108(param_1);
            if (local_d8 == (undefined8 **)0x0) goto LAB_00127384;
            FUN_00120b24(plVar17,&local_d8);
            pcVar8 = (char *)*param_1;
            if ((char *)param_1[1] == pcVar8) break;
          }
          lVar7 = param_1[3];
          lVar9 = param_1[2];
        }
        lVar11 = (lVar19 - lVar11 >> 3) * 8;
        auVar22 = FUN_0012a7b8(param_1,lVar9 + lVar11,lVar7);
        param_1[3] = param_1[2] + lVar11;
        if (auVar22._8_8_ == 0) {
          param_1[0x54] = param_1[0x54] + -8;
        }
                    /* try { // try from 0012712c to 0012713b has its CatchHandler @ 001273f4 */
        uVar5 = __strlen_chk(&DAT_0010aa5c,3);
        pcVar8 = (char *)*param_1;
        if ((ulong)(param_1[1] - (long)pcVar8) < uVar5) {
LAB_0012714c:
          do {
                    /* try { // try from 0012714c to 00127153 has its CatchHandler @ 00127400 */
            local_d8 = (undefined8 **)FUN_0011ef00(param_1);
            if (local_d8 == (undefined8 **)0x0) goto LAB_00127384;
            FUN_00120b24(plVar17,&local_d8);
            pcVar8 = (char *)*param_1;
          } while ((pcVar8 == (char *)param_1[1]) || (*pcVar8 != 'E'));
          pcVar8 = pcVar8 + 1;
        }
        else {
          if (uVar5 != 0) {
            pcVar16 = "vE";
            uVar12 = uVar5;
            pcVar14 = pcVar8;
            do {
              if (*pcVar16 != *pcVar14) goto LAB_0012714c;
              pcVar16 = pcVar16 + 1;
              pcVar14 = pcVar14 + 1;
              uVar12 = uVar12 - 1;
            } while (uVar12 != 0);
          }
          pcVar8 = pcVar8 + uVar5;
        }
        *param_1 = (long)pcVar8;
        auVar23 = FUN_0012a7b8(param_1,param_1[2] + lVar11,param_1[3]);
        pbVar1 = (byte *)param_1[1];
        pbVar10 = (byte *)*param_1;
        param_1[3] = param_1[2] + lVar11;
        pbVar15 = pbVar10;
        if ((pbVar1 == pbVar10) || (*pbVar10 - 0x3a < 0xfffffff6)) {
          pbVar10 = (byte *)0x0;
          pbVar13 = (byte *)0x0;
        }
        else {
          do {
            pbVar15 = pbVar15 + 1;
            *param_1 = (long)pbVar15;
            if (pbVar15 == pbVar1) {
              pbVar15 = pbVar1;
              goto LAB_00127324;
            }
          } while (0xfffffff5 < *pbVar15 - 0x3a);
LAB_00127324:
          pbVar13 = pbVar15;
        }
        if ((pbVar15 == pbVar1) || (*pbVar15 != 0x5f)) {
LAB_00127384:
          puVar20 = (undefined8 *)0x0;
        }
        else {
          puVar6 = (undefined8 *)param_1[0x266];
          *param_1 = (long)(pbVar15 + 1);
          lVar11 = *(long *)((long)puVar6 + 8);
          if (lVar11 - 0xfb0U < 0xfffffffffffff00f || lVar11 == -0x41) {
            puVar20 = malloc(0x1000);
            if (puVar20 == (void *)0x0) {
LAB_001273ec:
                    /* WARNING: Subroutine does not return */
              FUN_0011dc6c();
            }
            lVar11 = 0;
            *puVar20 = puVar6;
            puVar20[1] = 0;
            param_1[0x266] = (long)puVar20;
            puVar6 = puVar20;
          }
          *(long *)((long)puVar6 + 8) = lVar11 + 0x40;
          puVar20 = (undefined8 *)((long)puVar6 + lVar11 + 0x10);
          *puVar20 = &PTR_LAB_0013cbd0;
          *(undefined4 *)((long)puVar6 + lVar11 + 0x18) = 0x101012d;
          *(undefined1 (*) [16])((long)puVar6 + lVar11 + 0x20) = auVar22;
          *(undefined1 (*) [16])((long)puVar6 + lVar11 + 0x30) = auVar23;
          *(byte **)((long)puVar6 + lVar11 + 0x40) = pbVar10;
          *(byte **)((long)puVar6 + lVar11 + 0x48) = pbVar13;
        }
        local_d0[0x54] = local_d0[0x53] + lStack_c8 * 8;
        if (local_c0 != &local_a8) {
          free(local_c0);
        }
        param_1[0x62] = lVar21;
        goto LAB_001272e8;
      }
      if (cVar2 == 't') {
        pbVar15 = (byte *)(pcVar8 + 2);
        *param_1 = (long)pbVar15;
        if (pbVar1 != pbVar15) {
          if (*pbVar15 - 0x3a < 0xfffffff6) {
            pbVar13 = pbVar15;
            pbVar10 = (byte *)0x0;
            pbVar15 = (byte *)0x0;
          }
          else {
            pbVar10 = (byte *)(pcVar8 + 3);
            do {
              pbVar13 = pbVar10;
              *param_1 = (long)pbVar13;
              if (pbVar13 == pbVar1) {
                pbVar13 = pbVar1;
                goto LAB_00127264;
              }
              pbVar10 = pbVar13 + 1;
            } while (0xfffffff5 < *pbVar13 - 0x3a);
LAB_00127264:
            pbVar10 = pbVar13;
          }
          if ((pbVar13 != pbVar1) && (*pbVar13 == 0x5f)) {
            pvVar18 = (void *)param_1[0x266];
            *param_1 = (long)(pbVar13 + 1);
            lVar11 = *(long *)((long)pvVar18 + 8);
            puVar6 = pvVar18;
            if (lVar11 - 0xfd0U < 0xfffffffffffff00f || lVar11 == -0x21) {
              puVar6 = malloc(0x1000);
              if (puVar6 == (void *)0x0) goto LAB_001273ec;
              lVar11 = 0;
              *puVar6 = pvVar18;
              puVar6[1] = 0;
              param_1[0x266] = (long)puVar6;
            }
            *(long *)((long)puVar6 + 8) = lVar11 + 0x20;
            puVar20 = (undefined8 *)((long)puVar6 + lVar11 + 0x10);
            *puVar20 = &PTR_LAB_0013c930;
            *(undefined4 *)((long)puVar6 + lVar11 + 0x18) = 0x101012c;
            *(byte **)((long)puVar6 + lVar11 + 0x20) = pbVar15;
            *(byte **)((long)puVar6 + lVar11 + 0x28) = pbVar10;
            goto LAB_001272e8;
          }
        }
      }
    }
  }
LAB_001272e4:
  puVar20 = (undefined8 *)0x0;
LAB_001272e8:
  if (*(long *)(lVar3 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar20;
}


// ==== FUN_00127430 @ 00127430

void FUN_00127430(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013cc40;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010143;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_001274c0 @ 001274c0

void FUN_001274c0(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  uVar6 = param_3[1];
  uVar5 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013ccb0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010144;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x30) = uVar6;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  return;
}


// ==== FUN_0012755c @ 0012755c

void FUN_0012755c(long param_1,undefined8 *param_2)

{
  void *pvVar1;
  void *pvVar2;
  ulong uVar3;
  long lVar4;
  ulong uVar5;
  size_t sVar6;
  char *__src;
  long *plVar7;
  
  if (3 < (ulong)(*(long *)(param_1 + 0x18) - *(long *)(param_1 + 0x10))) {
    lVar4 = param_2[1];
    uVar5 = lVar4 + 1;
    if (uVar5 < (ulong)param_2[2]) {
      pvVar1 = (void *)*param_2;
    }
    else {
      uVar3 = param_2[2] << 1;
      if (uVar5 <= uVar3) {
        uVar5 = uVar3;
      }
      param_2[2] = uVar5;
      pvVar1 = realloc((void *)*param_2,uVar5);
      *param_2 = pvVar1;
      if (pvVar1 == (void *)0x0) goto LAB_001277fc;
      lVar4 = param_2[1];
    }
    *(undefined1 *)((long)pvVar1 + lVar4) = 0x28;
    lVar4 = param_2[1] + 1;
    param_2[1] = lVar4;
    pvVar1 = *(void **)(param_1 + 0x10);
    sVar6 = *(long *)(param_1 + 0x18) - (long)pvVar1;
    if (sVar6 != 0) {
      uVar5 = lVar4 + sVar6;
      if (uVar5 < (ulong)param_2[2]) {
        pvVar2 = (void *)*param_2;
      }
      else {
        uVar3 = param_2[2] << 1;
        if (uVar5 <= uVar3) {
          uVar5 = uVar3;
        }
        param_2[2] = uVar5;
        pvVar2 = realloc((void *)*param_2,uVar5);
        *param_2 = pvVar2;
        if (pvVar2 == (void *)0x0) goto LAB_001277fc;
        lVar4 = param_2[1];
      }
      memmove((void *)((long)pvVar2 + lVar4),pvVar1,sVar6);
      lVar4 = param_2[1] + sVar6;
      param_2[1] = lVar4;
    }
    uVar5 = lVar4 + 1;
    if (uVar5 < (ulong)param_2[2]) {
      pvVar1 = (void *)*param_2;
    }
    else {
      uVar3 = param_2[2] << 1;
      if (uVar5 <= uVar3) {
        uVar5 = uVar3;
      }
      param_2[2] = uVar5;
      pvVar1 = realloc((void *)*param_2,uVar5);
      *param_2 = pvVar1;
      if (pvVar1 == (void *)0x0) goto LAB_001277fc;
      lVar4 = param_2[1];
    }
    *(undefined1 *)((long)pvVar1 + lVar4) = 0x29;
    param_2[1] = param_2[1] + 1;
  }
  __src = *(char **)(param_1 + 0x20);
  if (*__src == 'n') {
    plVar7 = param_2 + 1;
    lVar4 = *plVar7;
    uVar5 = lVar4 + 1;
    if (uVar5 < (ulong)param_2[2]) {
      pvVar1 = (void *)*param_2;
    }
    else {
      uVar3 = param_2[2] << 1;
      if (uVar5 <= uVar3) {
        uVar5 = uVar3;
      }
      param_2[2] = uVar5;
      pvVar1 = realloc((void *)*param_2,uVar5);
      *param_2 = pvVar1;
      if (pvVar1 == (void *)0x0) goto LAB_001277fc;
      lVar4 = *plVar7;
    }
    *(undefined1 *)((long)pvVar1 + lVar4) = 0x2d;
    __src = *(char **)(param_1 + 0x20);
    lVar4 = *plVar7 + 1;
    if (*(char **)(param_1 + 0x28) != __src) {
      __src = __src + 1;
    }
    sVar6 = (long)*(char **)(param_1 + 0x28) - (long)__src;
    *plVar7 = lVar4;
    if (sVar6 != 0) {
      uVar5 = param_2[2];
LAB_00127724:
      plVar7 = param_2 + 1;
      uVar3 = lVar4 + sVar6;
      if (uVar3 < uVar5) {
        pvVar1 = (void *)*param_2;
      }
      else {
        if (uVar3 <= uVar5 << 1) {
          uVar3 = uVar5 << 1;
        }
        param_2[2] = uVar3;
        pvVar1 = realloc((void *)*param_2,uVar3);
        *param_2 = pvVar1;
        if (pvVar1 == (void *)0x0) goto LAB_001277fc;
        lVar4 = *plVar7;
      }
      memmove((void *)((long)pvVar1 + lVar4),__src,sVar6);
      *plVar7 = *plVar7 + sVar6;
    }
  }
  else {
    sVar6 = *(long *)(param_1 + 0x28) - (long)__src;
    if (sVar6 != 0) {
      lVar4 = param_2[1];
      uVar5 = param_2[2];
      goto LAB_00127724;
    }
  }
  pvVar1 = *(void **)(param_1 + 0x10);
  sVar6 = *(long *)(param_1 + 0x18) - (long)pvVar1;
  if (0xfffffffffffffffc < sVar6 - 4) {
    lVar4 = param_2[1];
    uVar5 = lVar4 + sVar6;
    if (uVar5 < (ulong)param_2[2]) {
      pvVar2 = (void *)*param_2;
    }
    else {
      uVar3 = param_2[2] << 1;
      if (uVar5 <= uVar3) {
        uVar5 = uVar3;
      }
      param_2[2] = uVar5;
      pvVar2 = realloc((void *)*param_2,uVar5);
      *param_2 = pvVar2;
      if (pvVar2 == (void *)0x0) {
LAB_001277fc:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar4 = param_2[1];
    }
    memmove((void *)((long)pvVar2 + lVar4),pvVar1,sVar6);
    param_2[1] = param_2[1] + sVar6;
  }
  return;
}


// ==== FUN_00127abc @ 00127abc

void FUN_00127abc(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  long lVar2;
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 local_80;
  undefined8 uStack_78;
  undefined1 *local_70;
  undefined1 **ppuStack_68;
  undefined8 *puStack_60;
  undefined8 uStack_58;
  
  ppuStack_68 = &local_70;
  lVar1 = tpidr_el0;
  lVar2 = *(long *)(lVar1 + 0x28);
  puStack_60 = &local_90;
  uStack_58 = 0xffffff80ffffffe0;
  local_90 = param_6;
  uStack_88 = param_7;
  local_80 = param_8;
  uStack_78 = param_9;
  local_70 = (undefined1 *)register0x00000008;
  __vsnprintf_chk(param_2,param_4,0,param_3,param_5,&local_70,param_8,param_9,param_1);
  if (*(long *)(lVar1 + 0x28) != lVar2) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00128108 @ 00128108

undefined8 * FUN_00128108(long *param_1)

{
  char *pcVar1;
  int iVar2;
  long lVar3;
  ulong uVar4;
  long lVar5;
  long lVar6;
  undefined **ppuVar7;
  ulong uVar8;
  uint uVar9;
  char *pcVar10;
  char *pcVar11;
  undefined8 *puVar12;
  long *plVar13;
  void *pvVar14;
  undefined8 *puVar15;
  undefined1 auVar16 [16];
  undefined8 **local_c8;
  long *local_c0;
  long lStack_b8;
  undefined8 *local_b0;
  undefined8 *local_a8;
  long *plStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  long local_58;
  
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  pcVar1 = (char *)*param_1;
  if ((1 < (ulong)(param_1[1] - (long)pcVar1)) && (*pcVar1 == 'T')) {
    puVar12 = (undefined8 *)0x0;
    switch(pcVar1[1]) {
    case 'n':
      iVar2 = *(int *)((long)param_1 + 0x31c);
      pvVar14 = (void *)param_1[0x266];
      *param_1 = (long)(pcVar1 + 2);
      *(int *)((long)param_1 + 0x31c) = iVar2 + 1;
      lVar6 = *(long *)((long)pvVar14 + 8);
      puVar12 = pvVar14;
      if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
        puVar12 = malloc(0x1000);
        if (puVar12 == (void *)0x0) goto LAB_00128604;
        lVar6 = 0;
        *puVar12 = pvVar14;
        puVar12[1] = 0;
        param_1[0x266] = (long)puVar12;
      }
      *(long *)((long)puVar12 + 8) = lVar6 + 0x20;
      plVar13 = (long *)((long)puVar12 + lVar6 + 0x10);
      *plVar13 = (long)&PTR_LAB_0013c9a0;
      *(undefined8 *)((long)puVar12 + lVar6 + 0x18) = 0x10101011b;
      *(int *)((long)puVar12 + lVar6 + 0x20) = iVar2;
      local_c0 = plVar13;
      FUN_00128824(*(undefined8 *)(param_1[0x54] + -8),&local_c0);
      lVar6 = FUN_0011ef00(param_1);
      if (lVar6 != 0) {
        pvVar14 = (void *)param_1[0x266];
        lVar5 = *(long *)((long)pvVar14 + 8);
        puVar15 = pvVar14;
        if (lVar5 - 0xfd0U < 0xfffffffffffff00f || lVar5 == -0x21) {
          puVar15 = malloc(0x1000);
          if (puVar15 == (void *)0x0) {
LAB_00128604:
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar5 = 0;
          *puVar15 = pvVar14;
          puVar15[1] = 0;
          param_1[0x266] = (long)puVar15;
        }
        *(long *)((long)puVar15 + 8) = lVar5 + 0x20;
        puVar12 = (undefined8 *)((long)puVar15 + lVar5 + 0x10);
        *puVar12 = &PTR_LAB_0013ca80;
        *(undefined4 *)((long)puVar15 + lVar5 + 0x18) = 0x101001d;
        *(long **)((long)puVar15 + lVar5 + 0x20) = plVar13;
        *(long *)((long)puVar15 + lVar5 + 0x28) = lVar6;
        goto code_r0x001284ec;
      }
      break;
    default:
      goto code_r0x001284ec;
    case 'p':
      *param_1 = (long)(pcVar1 + 2);
      plVar13 = (long *)FUN_00128108(param_1);
      if (plVar13 != (long *)0x0) {
        puVar15 = (undefined8 *)param_1[0x266];
        lVar6 = puVar15[1];
        puVar12 = puVar15;
        if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
          puVar12 = malloc(0x1000);
          if (puVar12 == (void *)0x0) goto LAB_00128604;
          lVar6 = 0;
          *puVar12 = puVar15;
          puVar12[1] = 0;
          param_1[0x266] = (long)puVar12;
        }
        lVar5 = (long)puVar12 + lVar6;
        uVar9 = 0x1f;
        ppuVar7 = &PTR_LAB_0013cb60;
        goto LAB_001285e4;
      }
      break;
    case 't':
      lVar6 = param_1[100];
      pvVar14 = (void *)param_1[0x266];
      *param_1 = (long)(pcVar1 + 2);
      *(int *)(param_1 + 100) = (int)lVar6 + 1;
      lVar5 = *(long *)((long)pvVar14 + 8);
      puVar12 = pvVar14;
      if (lVar5 - 0xfd0U < 0xfffffffffffff00f || lVar5 == -0x21) {
        puVar12 = malloc(0x1000);
        if (puVar12 == (void *)0x0) goto LAB_00128604;
        lVar5 = 0;
        *puVar12 = pvVar14;
        puVar12[1] = 0;
        param_1[0x266] = (long)puVar12;
      }
      *(long *)((long)puVar12 + 8) = lVar5 + 0x20;
      plVar13 = (long *)((long)puVar12 + lVar5 + 0x10);
      *plVar13 = (long)&PTR_LAB_0013c9a0;
      *(undefined8 *)((long)puVar12 + lVar5 + 0x18) = 0x20101011b;
      *(int *)((long)puVar12 + lVar5 + 0x20) = (int)lVar6;
      local_c0 = plVar13;
      FUN_00128824(*(undefined8 *)(param_1[0x54] + -8),&local_c0);
      plStack_a0 = &local_58;
      lVar5 = param_1[3];
      lStack_b8 = param_1[0x54] - param_1[0x53] >> 3;
      uStack_90 = 0;
      local_98 = 0;
      lVar6 = param_1[2];
      uStack_80 = 0;
      local_88 = 0;
      uStack_70 = 0;
      local_78 = 0;
      local_c8 = &local_b0;
      uStack_60 = 0;
      local_68 = 0;
      local_c0 = param_1;
      local_b0 = &local_98;
      local_a8 = &local_98;
      FUN_001229cc(param_1 + 0x53,&local_c8);
      do {
                    /* try { // try from 00128364 to 0012836f has its CatchHandler @ 00128610 */
        uVar4 = __strlen_chk(&DAT_0010b206,2);
        pcVar1 = (char *)*param_1;
        if (uVar4 <= (ulong)(param_1[1] - (long)pcVar1)) {
          if (uVar4 == 0) {
LAB_001283d0:
            lVar6 = (lVar5 - lVar6 >> 3) * 8;
            *param_1 = (long)(pcVar1 + uVar4);
            auVar16 = FUN_0012a7b8(param_1,param_1[2] + lVar6,param_1[3]);
            pvVar14 = (void *)param_1[0x266];
            param_1[3] = param_1[2] + lVar6;
            lVar6 = *(long *)((long)pvVar14 + 8);
            puVar15 = pvVar14;
            if (lVar6 - 0xfc0U < 0xfffffffffffff00f || lVar6 == -0x31) {
              puVar15 = malloc(0x1000);
              if (puVar15 == (void *)0x0) goto LAB_00128604;
              lVar6 = 0;
              *puVar15 = pvVar14;
              puVar15[1] = 0;
              param_1[0x266] = (long)puVar15;
            }
            *(long *)((long)puVar15 + 8) = lVar6 + 0x30;
            puVar12 = (undefined8 *)((long)puVar15 + lVar6 + 0x10);
            *puVar12 = &PTR_LAB_0013caf0;
            *(undefined4 *)((long)puVar15 + lVar6 + 0x18) = 0x101001e;
            *(long **)((long)puVar15 + lVar6 + 0x20) = plVar13;
            *(undefined1 (*) [16])((long)puVar15 + lVar6 + 0x28) = auVar16;
            goto LAB_0012845c;
          }
          pcVar11 = "E";
          uVar8 = uVar4;
          pcVar10 = pcVar1;
          while (*pcVar11 == *pcVar10) {
            pcVar11 = pcVar11 + 1;
            pcVar10 = pcVar10 + 1;
            uVar8 = uVar8 - 1;
            if (uVar8 == 0) goto LAB_001283d0;
          }
        }
                    /* try { // try from 00128380 to 00128387 has its CatchHandler @ 0012860c */
        local_c8 = (undefined8 **)FUN_00128108(param_1);
        if (local_c8 == (undefined8 **)0x0) goto LAB_001285fc;
        FUN_00120b24(param_1 + 2,&local_c8);
      } while( true );
    case 'y':
      lVar6 = param_1[99];
      pvVar14 = (void *)param_1[0x266];
      *param_1 = (long)(pcVar1 + 2);
      *(int *)(param_1 + 99) = (int)lVar6 + 1;
      lVar5 = *(long *)((long)pvVar14 + 8);
      puVar12 = pvVar14;
      if (lVar5 - 0xfd0U < 0xfffffffffffff00f || lVar5 == -0x21) {
        puVar12 = malloc(0x1000);
        if (puVar12 == (void *)0x0) goto LAB_00128604;
        lVar5 = 0;
        *puVar12 = pvVar14;
        puVar12[1] = 0;
        param_1[0x266] = (long)puVar12;
      }
      *(long *)((long)puVar12 + 8) = lVar5 + 0x20;
      plVar13 = (long *)((long)puVar12 + lVar5 + 0x10);
      *plVar13 = (long)&PTR_LAB_0013c9a0;
      *(undefined8 *)((long)puVar12 + lVar5 + 0x18) = 0x101011b;
      *(int *)((long)puVar12 + lVar5 + 0x20) = (int)lVar6;
      local_c0 = plVar13;
      FUN_00128824(*(undefined8 *)(param_1[0x54] + -8),&local_c0);
      puVar15 = (undefined8 *)param_1[0x266];
      lVar6 = puVar15[1];
      puVar12 = puVar15;
      if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
        puVar12 = malloc(0x1000);
        if (puVar12 == (undefined8 *)0x0) goto LAB_00128604;
        lVar6 = 0;
        *puVar12 = puVar15;
        puVar12[1] = 0;
        param_1[0x266] = (long)puVar12;
      }
      lVar5 = (long)puVar12 + lVar6;
      uVar9 = 0x1c;
      ppuVar7 = &PTR_LAB_0013ca10;
LAB_001285e4:
      puVar12[1] = lVar6 + 0x20;
      puVar12 = (undefined8 *)(lVar5 + 0x10);
      *puVar12 = ppuVar7;
      *(uint *)(lVar5 + 0x18) = uVar9 | 0x1010000;
      *(long **)(lVar5 + 0x20) = plVar13;
      goto code_r0x001284ec;
    }
  }
  puVar12 = (undefined8 *)0x0;
code_r0x001284ec:
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar12;
LAB_001285fc:
  puVar12 = (undefined8 *)0x0;
LAB_0012845c:
  local_c0[0x54] = local_c0[0x53] + lStack_b8 * 8;
  if (local_b0 != &local_98) {
    free(local_b0);
  }
  goto code_r0x001284ec;
}


// ==== FUN_0012863c @ 0012863c

undefined8 * FUN_0012863c(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_001286d8 @ 001286d8

void FUN_001286d8(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  size_t __n;
  void *pvVar2;
  void *pvVar3;
  ulong uVar4;
  long lVar5;
  
  lVar5 = param_2[1];
  uVar1 = lVar5 + 8;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] << 1;
    if (uVar1 <= uVar4) {
      uVar1 = uVar4;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_00128818;
    lVar5 = param_2[1];
  }
  *(undefined8 *)((long)pvVar2 + lVar5) = 0x64656d616e6e7527;
  lVar5 = param_2[1] + 8;
  param_2[1] = lVar5;
  pvVar2 = *(void **)(param_1 + 0x10);
  __n = *(long *)(param_1 + 0x18) - (long)pvVar2;
  if (__n != 0) {
    uVar1 = lVar5 + __n;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar3 = (void *)*param_2;
    }
    else {
      uVar4 = param_2[2] << 1;
      if (uVar1 <= uVar4) {
        uVar1 = uVar4;
      }
      param_2[2] = uVar1;
      pvVar3 = realloc((void *)*param_2,uVar1);
      *param_2 = pvVar3;
      if (pvVar3 == (void *)0x0) goto LAB_00128818;
      lVar5 = param_2[1];
    }
    memmove((void *)((long)pvVar3 + lVar5),pvVar2,__n);
    lVar5 = param_2[1] + __n;
    param_2[1] = lVar5;
  }
  uVar1 = lVar5 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] << 1;
    if (uVar1 <= uVar4) {
      uVar1 = uVar4;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_00128818:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar5 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar5) = 0x27;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_00128824 @ 00128824

void FUN_00128824(undefined8 *param_1,undefined8 *param_2)

{
  void *__dest;
  undefined8 *puVar1;
  undefined8 uVar2;
  size_t __n;
  undefined8 *__src;
  
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 == (undefined8 *)param_1[2]) {
    __src = (undefined8 *)*param_1;
    __n = (long)puVar1 - (long)__src;
    if (__src == param_1 + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_001288e4;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *param_1 = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *param_1 = __dest;
      if (__dest == (void *)0x0) {
LAB_001288e4:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
    }
    puVar1 = (undefined8 *)((long)__dest + ((long)__n >> 3) * 8);
    param_1[1] = puVar1;
    param_1[2] = (void *)((long)__dest + ((long)__n >> 2) * 8);
  }
  uVar2 = *param_2;
  param_1[1] = puVar1 + 1;
  *puVar1 = uVar2;
  return;
}


// ==== FUN_00128efc @ 00128efc

void FUN_00128efc(long *param_1,undefined8 *param_2)

{
  ulong __size;
  void *pvVar1;
  long lVar2;
  ulong uVar3;
  long *plVar4;
  long lVar5;
  bool bVar6;
  long lVar7;
  
  if (param_1[1] != 0) {
    lVar5 = 0;
    lVar7 = param_2[1];
    bVar6 = true;
    do {
      lVar2 = lVar7;
      if (!bVar6) {
        __size = lVar7 + 2;
        if (__size < (ulong)param_2[2]) {
          pvVar1 = (void *)*param_2;
        }
        else {
          uVar3 = param_2[2] << 1;
          if (__size <= uVar3) {
            __size = uVar3;
          }
          param_2[2] = __size;
          pvVar1 = realloc((void *)*param_2,__size);
          *param_2 = pvVar1;
          if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar2 = param_2[1];
        }
        *(undefined2 *)((long)pvVar1 + lVar2) = 0x202c;
        lVar2 = param_2[1] + 2;
        param_2[1] = lVar2;
      }
      plVar4 = *(long **)(*param_1 + lVar5 * 8);
      (**(code **)(*plVar4 + 0x20))(plVar4,param_2);
      if (*(char *)((long)plVar4 + 9) != '\x01') {
        (**(code **)(*plVar4 + 0x28))(plVar4,param_2);
      }
      if (lVar2 == param_2[1]) {
        param_2[1] = lVar7;
      }
      else {
        bVar6 = false;
        lVar7 = param_2[1];
      }
      lVar5 = lVar5 + 1;
    } while (lVar5 != param_1[1]);
  }
  return;
}


// ==== FUN_0012901c @ 0012901c

void FUN_0012901c(long param_1,undefined8 *param_2)

{
  ulong __size;
  void *pvVar1;
  ulong uVar2;
  long lVar3;
  
  (**(code **)(**(long **)(param_1 + 0x10) + 0x20))();
  lVar3 = param_2[1];
  __size = lVar3 + 3;
  if (__size < (ulong)param_2[2]) {
    pvVar1 = (void *)*param_2;
  }
  else {
    uVar2 = param_2[2] << 1;
    if (__size <= uVar2) {
      __size = uVar2;
    }
    param_2[2] = __size;
    pvVar1 = realloc((void *)*param_2,__size);
    *param_2 = pvVar1;
    if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = param_2[1];
  }
  *(undefined1 *)((undefined2 *)((long)pvVar1 + lVar3) + 1) = 0x2e;
  *(undefined2 *)((long)pvVar1 + lVar3) = 0x2e2e;
  param_2[1] = param_2[1] + 3;
  return;
}


// ==== FUN_00129228 @ 00129228

void FUN_00129228(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  void *pvVar2;
  long lVar3;
  ulong uVar4;
  
  lVar3 = param_2[1];
  if (*(long *)(param_1 + 0x18) != 0) {
    uVar1 = lVar3 + 1;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar2 = (void *)*param_2;
    }
    else {
      uVar4 = param_2[2] << 1;
      if (uVar1 <= uVar4) {
        uVar1 = uVar4;
      }
      param_2[2] = uVar1;
      pvVar2 = realloc((void *)*param_2,uVar1);
      *param_2 = pvVar2;
      if (pvVar2 == (void *)0x0) goto LAB_001293b4;
      lVar3 = param_2[1];
    }
    *(undefined1 *)((long)pvVar2 + lVar3) = 0x3c;
    param_2[1] = param_2[1] + 1;
    FUN_00128efc(param_1 + 0x10,param_2);
    lVar3 = param_2[1];
    uVar1 = lVar3 + 1;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar2 = (void *)*param_2;
    }
    else {
      uVar4 = param_2[2] << 1;
      if (uVar1 <= uVar4) {
        uVar1 = uVar4;
      }
      param_2[2] = uVar1;
      pvVar2 = realloc((void *)*param_2,uVar1);
      *param_2 = pvVar2;
      if (pvVar2 == (void *)0x0) goto LAB_001293b4;
      lVar3 = param_2[1];
    }
    *(undefined1 *)((long)pvVar2 + lVar3) = 0x3e;
    lVar3 = param_2[1] + 1;
    param_2[1] = lVar3;
  }
  uVar1 = lVar3 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] << 1;
    if (uVar1 <= uVar4) {
      uVar1 = uVar4;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_001293b4;
    lVar3 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar3) = 0x28;
  param_2[1] = param_2[1] + 1;
  FUN_00128efc(param_1 + 0x20,param_2);
  lVar3 = param_2[1];
  uVar1 = lVar3 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] << 1;
    if (uVar1 <= uVar4) {
      uVar1 = uVar4;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_001293b4:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar3) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_001293b8 @ 001293b8

void FUN_001293b8(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  char cVar2;
  void *pvVar3;
  long lVar4;
  long lVar5;
  ulong uVar6;
  
  lVar5 = param_2[1];
  uVar1 = lVar5 + 2;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar3 = (void *)*param_2;
  }
  else {
    uVar6 = param_2[2] << 1;
    if (uVar1 <= uVar6) {
      uVar1 = uVar6;
    }
    param_2[2] = uVar1;
    pvVar3 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar3;
    if (pvVar3 == (void *)0x0) goto LAB_001294ac;
    lVar5 = param_2[1];
  }
  *(undefined2 *)((long)pvVar3 + lVar5) = 0x5d5b;
  lVar4 = *(long *)(param_1 + 0x10);
  cVar2 = *(char *)(lVar4 + 8);
  lVar5 = param_2[1] + 2;
  param_2[1] = lVar5;
  if (cVar2 == '-') {
    FUN_00129228(lVar4,param_2);
    lVar5 = param_2[1];
  }
  uVar1 = lVar5 + 5;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar3 = (void *)*param_2;
  }
  else {
    uVar6 = param_2[2] << 1;
    if (uVar1 <= uVar6) {
      uVar1 = uVar6;
    }
    param_2[2] = uVar1;
    pvVar3 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar3;
    if (pvVar3 == (void *)0x0) {
LAB_001294ac:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar5 = param_2[1];
  }
  *(undefined1 *)((undefined4 *)((long)pvVar3 + lVar5) + 1) = 0x7d;
  *(undefined4 *)((long)pvVar3 + lVar5) = 0x2e2e2e7b;
  param_2[1] = param_2[1] + 5;
  return;
}


// ==== FUN_00129cdc @ 00129cdc

void FUN_00129cdc(long *param_1)

{
  long lVar1;
  long lVar2;
  void *pvVar3;
  ulong uVar4;
  long lVar5;
  ulong uVar6;
  undefined8 *puVar7;
  undefined **local_50;
  undefined4 local_48;
  undefined8 local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  puVar7 = (undefined8 *)*param_1;
  lVar1 = param_1[1];
  lVar5 = puVar7[1];
  uVar6 = lVar5 + 1;
  if (uVar6 < (ulong)puVar7[2]) {
    pvVar3 = (void *)*puVar7;
  }
  else {
    uVar4 = puVar7[2] << 1;
    if (uVar6 <= uVar4) {
      uVar6 = uVar4;
    }
    puVar7[2] = uVar6;
    pvVar3 = realloc((void *)*puVar7,uVar6);
    *puVar7 = pvVar3;
    if (pvVar3 == (void *)0x0) goto LAB_00129df8;
    lVar5 = puVar7[1];
    uVar6 = lVar5 + 1;
  }
  puVar7[1] = uVar6;
  *(undefined1 *)((long)pvVar3 + lVar5) = 0x28;
  local_40 = *(undefined8 *)(lVar1 + 0x10);
  local_48 = 0x1010122;
  local_50 = &PTR_LAB_0013ce00;
  FUN_00129e00(&local_50,*param_1);
  puVar7 = (undefined8 *)*param_1;
  lVar5 = puVar7[1];
  uVar6 = lVar5 + 1;
  if (uVar6 < (ulong)puVar7[2]) {
    pvVar3 = (void *)*puVar7;
  }
  else {
    uVar4 = puVar7[2] << 1;
    if (uVar6 <= uVar4) {
      uVar6 = uVar4;
    }
    puVar7[2] = uVar6;
    pvVar3 = realloc((void *)*puVar7,uVar6);
    *puVar7 = pvVar3;
    if (pvVar3 == (void *)0x0) {
LAB_00129df8:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar5 = puVar7[1];
    uVar6 = lVar5 + 1;
  }
  puVar7[1] = uVar6;
  *(undefined1 *)((long)pvVar3 + lVar5) = 0x29;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00129e00 @ 00129e00

void FUN_00129e00(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  size_t sVar5;
  void *pvVar6;
  long lVar7;
  ulong uVar8;
  long *plVar9;
  long lVar10;
  uint uVar11;
  
  plVar9 = *(long **)(param_1 + 0x10);
  uVar2 = *(undefined4 *)(param_2 + 3);
  uVar3 = *(undefined4 *)((long)param_2 + 0x1c);
  lVar7 = *plVar9;
  lVar10 = param_2[1];
  param_2[3] = 0xffffffffffffffff;
                    /* try { // try from 00129e40 to 00129e67 has its CatchHandler @ 00129fe0 */
  (**(code **)(lVar7 + 0x20))(plVar9);
  if (*(char *)((long)plVar9 + 9) != '\x01') {
    (**(code **)(*plVar9 + 0x28))(plVar9,param_2);
  }
  uVar4 = *(uint *)((long)param_2 + 0x1c);
  if (uVar4 == 0xffffffff) {
                    /* try { // try from 00129f48 to 00129f57 has its CatchHandler @ 00129fe0 */
    sVar5 = __strlen_chk(&DAT_0010abb6,4);
    if (sVar5 == 0) goto LAB_00129fbc;
    lVar10 = param_2[1];
    uVar1 = lVar10 + sVar5;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar6 = (void *)*param_2;
    }
    else {
      uVar8 = param_2[2] << 1;
      if (uVar1 <= uVar8) {
        uVar1 = uVar8;
      }
      param_2[2] = uVar1;
      pvVar6 = realloc((void *)*param_2,uVar1);
      *param_2 = pvVar6;
      if (pvVar6 == (void *)0x0) {
LAB_00129fdc:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar10 = param_2[1];
    }
    memcpy((void *)((long)pvVar6 + lVar10),&DAT_0010abb6,sVar5);
    lVar10 = param_2[1] + sVar5;
  }
  else if (uVar4 != 0) {
    if (1 < uVar4) {
      uVar11 = 1;
      do {
                    /* try { // try from 00129e9c to 00129ea7 has its CatchHandler @ 00129fe4 */
        sVar5 = __strlen_chk(&DAT_0010b032,3);
        if (sVar5 != 0) {
          lVar10 = param_2[1];
          uVar1 = lVar10 + sVar5;
          if (uVar1 < (ulong)param_2[2]) {
            pvVar6 = (void *)*param_2;
          }
          else {
            uVar8 = param_2[2] << 1;
            if (uVar1 <= uVar8) {
              uVar1 = uVar8;
            }
            param_2[2] = uVar1;
            pvVar6 = realloc((void *)*param_2,uVar1);
            *param_2 = pvVar6;
            if (pvVar6 == (void *)0x0) goto LAB_00129fdc;
            lVar10 = param_2[1];
          }
          memcpy((void *)((long)pvVar6 + lVar10),&DAT_0010b032,sVar5);
          param_2[1] = param_2[1] + sVar5;
        }
        plVar9 = *(long **)(param_1 + 0x10);
        *(uint *)(param_2 + 3) = uVar11;
                    /* try { // try from 00129f18 to 00129f43 has its CatchHandler @ 00129fe4 */
        (**(code **)(*plVar9 + 0x20))(plVar9,param_2);
        if (*(char *)((long)plVar9 + 9) != '\x01') {
          (**(code **)(*plVar9 + 0x28))(plVar9,param_2);
        }
        uVar11 = uVar11 + 1;
      } while (uVar4 != uVar11);
    }
    goto LAB_00129fbc;
  }
  param_2[1] = lVar10;
LAB_00129fbc:
  *(undefined4 *)(param_2 + 3) = uVar2;
  *(undefined4 *)((long)param_2 + 0x1c) = uVar3;
  return;
}


// ==== FUN_0012a7b8 @ 0012a7b8

undefined1  [16] FUN_0012a7b8(long param_1,void *param_2,long param_3)

{
  undefined8 *__dest;
  undefined8 *puVar1;
  long lVar2;
  size_t __n;
  undefined8 *puVar3;
  ulong uVar4;
  undefined1 auVar5 [16];
  
  puVar3 = *(undefined8 **)(param_1 + 0x1330);
  __n = param_3 - (long)param_2;
  uVar4 = (ulong)((int)__n + 0xf) & 0xfffffff0;
  lVar2 = puVar3[1];
  puVar1 = puVar3;
  if (0xfef < lVar2 + uVar4) {
    if (0xff0 < uVar4) {
      puVar1 = malloc(uVar4 + 0x10);
      if (puVar1 == (undefined8 *)0x0) {
LAB_0012a884:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      __dest = puVar1 + 2;
      *puVar1 = *puVar3;
      puVar1[1] = 0;
      *puVar3 = puVar1;
      goto joined_r0x0012a850;
    }
    puVar1 = malloc(0x1000);
    if (puVar1 == (undefined8 *)0x0) goto LAB_0012a884;
    lVar2 = 0;
    *puVar1 = puVar3;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  __dest = (undefined8 *)((long)puVar1 + lVar2 + 0x10);
  puVar1[1] = lVar2 + uVar4;
joined_r0x0012a850:
  if (__n != 0) {
    memmove(__dest,param_2,__n);
  }
  auVar5._8_8_ = (long)__n >> 3;
  auVar5._0_8_ = __dest;
  return auVar5;
}


// ==== FUN_0012a888 @ 0012a888

void FUN_0012a888(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  void *pvVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  
  lVar4 = param_2[1];
  uVar1 = lVar4 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar3 = param_2[2] << 1;
    if (uVar1 <= uVar3) {
      uVar1 = uVar3;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_0012a9ec;
    lVar4 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar4) = 0x28;
  plVar5 = *(long **)(param_1 + 0x10);
  lVar4 = *plVar5;
  param_2[1] = param_2[1] + 1;
  (**(code **)(lVar4 + 0x20))(plVar5,param_2);
  if (*(char *)((long)plVar5 + 9) != '\x01') {
    (**(code **)(*plVar5 + 0x28))(plVar5,param_2);
  }
  lVar4 = param_2[1];
  uVar1 = lVar4 + 2;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar3 = param_2[2] << 1;
    if (uVar1 <= uVar3) {
      uVar1 = uVar3;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_0012a9ec;
    lVar4 = param_2[1];
  }
  *(undefined2 *)((long)pvVar2 + lVar4) = 0x2829;
  param_2[1] = param_2[1] + 2;
  FUN_00128efc(param_1 + 0x18,param_2);
  lVar4 = param_2[1];
  uVar1 = lVar4 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar3 = param_2[2] << 1;
    if (uVar1 <= uVar3) {
      uVar1 = uVar3;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_0012a9ec:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar4 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar4) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_0012ab90 @ 0012ab90

long FUN_0012ab90(long *param_1)

{
  char cVar1;
  long lVar2;
  long lVar3;
  long local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  if ((char *)param_1[1] == (char *)*param_1) {
LAB_0012abe4:
    lVar3 = FUN_00121764(param_1);
    if (*(long *)(lVar2 + 0x28) != local_38) goto LAB_0012ac4c;
  }
  else {
    cVar1 = *(char *)*param_1;
    if (cVar1 == 'D') {
      lVar3 = FUN_0012237c(param_1);
    }
    else {
      if (cVar1 != 'T') goto LAB_0012abe4;
      lVar3 = FUN_00122008(param_1);
    }
    local_40 = lVar3;
    if (lVar3 != 0) {
      FUN_00120b24(param_1 + 0x25,&local_40);
    }
    if (*(long *)(lVar2 + 0x28) != local_38) {
LAB_0012ac4c:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  return lVar3;
}


// ==== FUN_0012ac50 @ 0012ac50

undefined8 * FUN_0012ac50(long *param_1)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 *puVar3;
  long lVar4;
  undefined8 *puVar5;
  void *pvVar6;
  
  puVar1 = (undefined8 *)FUN_0012af08();
  puVar5 = puVar1;
  if (((puVar1 != (undefined8 *)0x0) && ((char *)param_1[1] != (char *)*param_1)) &&
     (*(char *)*param_1 == 'I')) {
    lVar2 = FUN_00121af4(param_1,0);
    if (lVar2 == 0) {
      puVar5 = (undefined8 *)0x0;
    }
    else {
      pvVar6 = (void *)param_1[0x266];
      lVar4 = *(long *)((long)pvVar6 + 8);
      puVar3 = pvVar6;
      if (lVar4 - 0xfd0U < 0xfffffffffffff00f || lVar4 == -0x21) {
        puVar3 = malloc(0x1000);
        if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0011dc6c();
        }
        lVar4 = 0;
        *puVar3 = pvVar6;
        puVar3[1] = 0;
        param_1[0x266] = (long)puVar3;
      }
      *(long *)((long)puVar3 + 8) = lVar4 + 0x20;
      puVar5 = (undefined8 *)((long)puVar3 + lVar4 + 0x10);
      *puVar5 = &PTR_LAB_0013dc70;
      *(undefined8 **)((long)puVar3 + lVar4 + 0x20) = puVar1;
      *(long *)((long)puVar3 + lVar4 + 0x28) = lVar2;
      *(undefined4 *)((long)puVar3 + lVar4 + 0x18) = 0x1010125;
    }
  }
  return puVar5;
}


// ==== FUN_0012ad20 @ 0012ad20

undefined8 * FUN_0012ad20(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 *puVar7;
  void *pvVar8;
  
  pbVar1 = (byte *)*param_1;
  pbVar2 = (byte *)param_1[1];
  if ((pbVar2 != pbVar1) && (0xfffffff5 < *pbVar1 - 0x3a)) {
    puVar4 = (undefined8 *)FUN_0012ac50(param_1);
    return puVar4;
  }
  if (1 < (ulong)((long)pbVar2 - (long)pbVar1)) {
    if (*pbVar1 == 0x6f) {
      if (pbVar1[1] == 0x6e) {
        *param_1 = (long)(pbVar1 + 2);
      }
    }
    else if ((*pbVar1 == 100) && (pbVar1[1] == 0x6e)) {
      pbVar1 = pbVar1 + 2;
      *param_1 = (long)pbVar1;
      if ((pbVar2 == pbVar1) || (*pbVar1 - 0x3a < 0xfffffff6)) {
        lVar3 = FUN_0012ab90(param_1);
      }
      else {
        lVar3 = FUN_0012ac50(param_1);
      }
      if (lVar3 == 0) {
        return (undefined8 *)0x0;
      }
      pvVar8 = (void *)param_1[0x266];
      lVar6 = *(long *)((long)pvVar8 + 8);
      puVar4 = pvVar8;
      if (0xfffffffffffff00e < lVar6 - 0xfd0U && lVar6 != -0x21) {
LAB_0012aebc:
        *(long *)((long)puVar4 + 8) = lVar6 + 0x20;
        puVar7 = (undefined8 *)((long)puVar4 + lVar6 + 0x10);
        *puVar7 = &PTR_LAB_0013d180;
        *(undefined4 *)((long)puVar4 + lVar6 + 0x18) = 0x101012b;
        *(long *)((long)puVar4 + lVar6 + 0x20) = lVar3;
        return puVar7;
      }
      puVar4 = malloc(0x1000);
      if (puVar4 != (void *)0x0) {
        lVar6 = 0;
        *puVar4 = pvVar8;
        puVar4[1] = 0;
        param_1[0x266] = (long)puVar4;
        goto LAB_0012aebc;
      }
      goto LAB_0012af04;
    }
  }
  puVar4 = (undefined8 *)FUN_0012b288(param_1,0);
  if (puVar4 == (undefined8 *)0x0) {
    return (undefined8 *)0x0;
  }
  if ((char *)param_1[1] == (char *)*param_1) {
    return puVar4;
  }
  if (*(char *)*param_1 != 'I') {
    return puVar4;
  }
  lVar3 = FUN_00121af4(param_1,0);
  if (lVar3 == 0) {
    return (undefined8 *)0x0;
  }
  pvVar8 = (void *)param_1[0x266];
  lVar6 = *(long *)((long)pvVar8 + 8);
  puVar7 = pvVar8;
  if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
    puVar7 = malloc(0x1000);
    if (puVar7 == (void *)0x0) {
LAB_0012af04:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar6 = 0;
    *puVar7 = pvVar8;
    puVar7[1] = 0;
    param_1[0x266] = (long)puVar7;
  }
  *(long *)((long)puVar7 + 8) = lVar6 + 0x20;
  puVar5 = (undefined8 *)((long)puVar7 + lVar6 + 0x10);
  *puVar5 = &PTR_LAB_0013dc70;
  *(undefined8 **)((long)puVar7 + lVar6 + 0x20) = puVar4;
  *(long *)((long)puVar7 + lVar6 + 0x28) = lVar3;
  *(undefined4 *)((long)puVar7 + lVar6 + 0x18) = 0x1010125;
  return puVar5;
}


// ==== FUN_0012af08 @ 0012af08

undefined8 * FUN_0012af08(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  ulong uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  long lVar6;
  ulong uVar7;
  long lVar8;
  ulong uVar9;
  ulong uVar10;
  char *pcVar11;
  byte *pbVar12;
  void *pvVar13;
  
  pbVar2 = (byte *)*param_1;
  lVar6 = param_1[1] - (long)pbVar2;
  if ((lVar6 != 0) && (0xfffffff5 < *pbVar2 - 0x3a)) {
    uVar9 = 0;
    uVar3 = 0;
    do {
      uVar10 = uVar3;
      uVar7 = uVar9;
      pbVar1 = pbVar2 + uVar10;
      pcVar11 = (char *)(pbVar1 + 1);
      *param_1 = (long)pcVar11;
      lVar8 = (ulong)*pbVar1 + uVar7 * 10;
      uVar9 = lVar8 - 0x30;
      if ((byte *)pcVar11 == (byte *)param_1[1]) break;
      uVar3 = uVar10 + 1;
    } while ((byte)*pcVar11 - 0x30 < 10);
    if (lVar8 - 0x31U < ~uVar10 + lVar6) {
      pbVar12 = pbVar2 + uVar10 + (ulong)*pbVar1 + uVar7 * 10 + -0x2f;
      *param_1 = (long)pbVar12;
      if ((((((uVar9 < 10) || (pbVar1[1] != 0x5f)) || (pbVar2[uVar10 + 2] != 0x47)) ||
           ((pbVar2[uVar10 + 3] != 0x4c || (pbVar2[uVar10 + 4] != 0x4f)))) ||
          ((pbVar2[uVar10 + 5] != 0x42 ||
           ((pbVar2[uVar10 + 6] != 0x41 || (pbVar2[uVar10 + 7] != 0x4c)))))) ||
         ((pbVar2[uVar10 + 8] != 0x5f ||
          ((pbVar2[uVar10 + 9] != 0x5f || (pbVar2[uVar10 + 10] != 0x4e)))))) {
        pvVar13 = (void *)param_1[0x266];
      }
      else {
        pvVar13 = (void *)param_1[0x266];
        pcVar11 = "(anonymous namespace)";
        pbVar12 = (byte *)0x10a62d;
      }
      lVar6 = *(long *)((long)pvVar13 + 8);
      puVar4 = pvVar13;
      if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
        puVar4 = malloc(0x1000);
        if (puVar4 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0011dc6c();
        }
        *puVar4 = pvVar13;
        puVar4[1] = 0;
        lVar6 = 0;
        param_1[0x266] = (long)puVar4;
      }
      *(long *)((long)puVar4 + 8) = lVar6 + 0x20;
      puVar5 = (undefined8 *)((long)puVar4 + lVar6 + 0x10);
      *puVar5 = &PTR_LAB_0013c540;
      *(undefined4 *)((long)puVar4 + lVar6 + 0x18) = 0x1010107;
      *(char **)((long)puVar4 + lVar6 + 0x20) = pcVar11;
      *(byte **)((long)puVar4 + lVar6 + 0x28) = pbVar12;
      return puVar5;
    }
  }
  return (undefined8 *)0x0;
}


// ==== FUN_0012b0dc @ 0012b0dc

void FUN_0012b0dc(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  void *pvVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  
  pvVar3 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar3 + 8);
  puVar1 = pvVar3;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar3;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar5 = param_2[1];
  uVar4 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010107;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar4;
  return;
}


// ==== FUN_0012b16c @ 0012b16c

void FUN_0012b16c(long param_1,undefined8 *param_2)

{
  ulong __size;
  void *pvVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  
  plVar4 = *(long **)(param_1 + 0x10);
  (**(code **)(*plVar4 + 0x20))(plVar4);
  if (*(char *)((long)plVar4 + 9) != '\x01') {
    (**(code **)(*plVar4 + 0x28))(plVar4,param_2);
  }
  lVar3 = param_2[1];
  __size = lVar3 + 2;
  if (__size < (ulong)param_2[2]) {
    pvVar1 = (void *)*param_2;
  }
  else {
    uVar2 = param_2[2] << 1;
    if (__size <= uVar2) {
      __size = uVar2;
    }
    param_2[2] = __size;
    pvVar1 = realloc((void *)*param_2,__size);
    *param_2 = pvVar1;
    if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = param_2[1];
  }
  *(undefined2 *)((long)pvVar1 + lVar3) = 0x3a3a;
  plVar4 = *(long **)(param_1 + 0x18);
  lVar3 = *plVar4;
  param_2[1] = param_2[1] + 2;
  (**(code **)(lVar3 + 0x20))(plVar4,param_2);
  if (*(char *)((long)plVar4 + 9) == '\x01') {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0012b264. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar4 + 0x28))(plVar4,param_2);
  return;
}


// ==== FUN_0012b288 @ 0012b288

void FUN_0012b288(long *param_1,undefined1 *param_2)

{
  undefined1 *puVar1;
  char cVar2;
  ulong uVar3;
  long lVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 *puVar7;
  char *pcVar8;
  long lVar9;
  char *pcVar10;
  void *pvVar11;
  long local_50;
  long local_48;
  
  lVar4 = tpidr_el0;
  local_48 = *(long *)(lVar4 + 0x28);
  puVar1 = (undefined1 *)*param_1;
  uVar3 = param_1[1] - (long)puVar1;
  if ((undefined1 *)param_1[1] == puVar1) goto LAB_0012b8b0;
  puVar5 = (undefined8 *)0x0;
  switch(*puVar1) {
  case 0x61:
    if (1 < uVar3) {
      puVar5 = (undefined8 *)0x0;
      switch(puVar1[1]) {
      case 0x4e:
        pcVar10 = "operator&=";
        break;
      default:
        goto code_r0x0012b8b8;
      case 0x53:
        pcVar10 = "operator=";
        goto LAB_0012bbcc;
      case 0x61:
        pcVar10 = "operator&&";
        break;
      case 100:
      case 0x6e:
        pvVar11 = (void *)param_1[0x266];
        *param_1 = (long)(puVar1 + 2);
        lVar6 = *(long *)((long)pvVar11 + 8);
        puVar5 = pvVar11;
        if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
          puVar5 = malloc(0x1000);
          if (puVar5 == (void *)0x0) goto LAB_0012bc64;
          lVar6 = 0;
          *puVar5 = pvVar11;
          puVar5[1] = 0;
          param_1[0x266] = (long)puVar5;
        }
        *(long *)((long)puVar5 + 8) = lVar6 + 0x20;
        puVar5 = (undefined8 *)((long)puVar5 + lVar6 + 0x10);
        *puVar5 = &PTR_LAB_0013c540;
        pcVar8 = "operator&";
        goto LAB_0012b958;
      }
      goto LAB_0012bc54;
    }
    break;
  default:
    goto code_r0x0012b8b8;
  case 99:
    if (uVar3 < 2) break;
    puVar5 = (undefined8 *)0x0;
    switch(puVar1[1]) {
    case 0x6c:
      pcVar10 = "operator()";
      goto LAB_0012bc54;
    case 0x6d:
      pcVar10 = "operator,";
      break;
    default:
      goto code_r0x0012b8b8;
    case 0x6f:
      pcVar10 = "operator~";
      break;
    case 0x76:
      cVar2 = *(char *)((long)param_1 + 0x309);
      lVar6 = param_1[0x61];
      *(undefined1 *)(param_1 + 0x61) = 0;
      *param_1 = (long)(puVar1 + 2);
      *(bool *)((long)param_1 + 0x309) = param_2 != (undefined1 *)0x0 || cVar2 != '\0';
                    /* try { // try from 0012ba54 to 0012ba5b has its CatchHandler @ 0012bc6c */
      local_50 = FUN_0011ef00(param_1);
      puVar5 = (undefined8 *)0x0;
      if (local_50 != 0) {
        if (param_2 != (undefined1 *)0x0) {
          *param_2 = 1;
        }
        puVar5 = (undefined8 *)FUN_0012be44(param_1,&local_50);
      }
      *(char *)((long)param_1 + 0x309) = cVar2;
      *(char *)(param_1 + 0x61) = (char)lVar6;
      goto code_r0x0012b8b8;
    }
    goto LAB_0012bbcc;
  case 100:
    if (uVar3 < 2) break;
    puVar5 = (undefined8 *)0x0;
    switch(puVar1[1]) {
    case 0x56:
      pcVar10 = "operator/=";
      goto LAB_0012bc54;
    case 0x61:
      *param_1 = (long)(puVar1 + 2);
      puVar5 = (undefined8 *)FUN_0012bed4(param_1,"operator delete[]");
      break;
    case 0x65:
code_r0x0012b8e8:
      pcVar10 = "operator*";
      goto LAB_0012bbcc;
    case 0x6c:
      *param_1 = (long)(puVar1 + 2);
      puVar5 = (undefined8 *)FUN_0012863c(param_1,"operator delete");
      break;
    case 0x76:
      pcVar10 = "operator/";
LAB_0012bbcc:
      *param_1 = (long)(puVar1 + 2);
      puVar5 = (undefined8 *)FUN_0012bda8(param_1,pcVar10);
    }
    goto code_r0x0012b8b8;
  case 0x65:
    if (1 < uVar3) {
      cVar2 = puVar1[1];
      if (cVar2 == 'O') {
        pcVar10 = "operator^=";
      }
      else {
        if (cVar2 != 'q') {
          if (cVar2 == 'o') {
            pcVar10 = "operator^";
            goto LAB_0012bbcc;
          }
          break;
        }
        pcVar10 = "operator==";
      }
      goto LAB_0012bc54;
    }
    break;
  case 0x67:
    if (1 < uVar3) {
      if (puVar1[1] == 't') {
        pvVar11 = (void *)param_1[0x266];
        *param_1 = (long)(puVar1 + 2);
        lVar6 = *(long *)((long)pvVar11 + 8);
        puVar5 = pvVar11;
        if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
          puVar5 = malloc(0x1000);
          if (puVar5 == (void *)0x0) {
LAB_0012bc64:
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar6 = 0;
          *puVar5 = pvVar11;
          puVar5[1] = 0;
          param_1[0x266] = (long)puVar5;
        }
        *(long *)((long)puVar5 + 8) = lVar6 + 0x20;
        puVar5 = (undefined8 *)((long)puVar5 + lVar6 + 0x10);
        *puVar5 = &PTR_LAB_0013c540;
        pcVar8 = "operator>";
        goto LAB_0012b958;
      }
      if (puVar1[1] == 'e') {
        pvVar11 = (void *)param_1[0x266];
        *param_1 = (long)(puVar1 + 2);
        lVar6 = *(long *)((long)pvVar11 + 8);
        puVar5 = pvVar11;
        if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
          puVar5 = malloc(0x1000);
          if (puVar5 == (void *)0x0) goto LAB_0012bc64;
          lVar6 = 0;
          *puVar5 = pvVar11;
          puVar5[1] = 0;
          param_1[0x266] = (long)puVar5;
        }
        *(long *)((long)puVar5 + 8) = lVar6 + 0x20;
        puVar5 = (undefined8 *)((long)puVar5 + lVar6 + 0x10);
        *puVar5 = &PTR_LAB_0013c540;
        pcVar8 = "operator>=";
        pcVar10 = "";
        goto LAB_0012b95c;
      }
    }
    break;
  case 0x69:
    if ((1 < uVar3) && (puVar1[1] == 'x')) {
      pvVar11 = (void *)param_1[0x266];
      *param_1 = (long)(puVar1 + 2);
      lVar6 = *(long *)((long)pvVar11 + 8);
      puVar5 = pvVar11;
      if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (void *)0x0) goto LAB_0012bc64;
        lVar6 = 0;
        *puVar5 = pvVar11;
        puVar5[1] = 0;
        param_1[0x266] = (long)puVar5;
      }
      *(long *)((long)puVar5 + 8) = lVar6 + 0x20;
      puVar5 = (undefined8 *)((long)puVar5 + lVar6 + 0x10);
      *puVar5 = &PTR_LAB_0013c540;
      pcVar8 = "operator[]";
      pcVar10 = "";
LAB_0012b95c:
      *(undefined4 *)(puVar5 + 1) = 0x1010107;
      puVar5[2] = pcVar8;
      puVar5[3] = pcVar10;
      goto code_r0x0012b8b8;
    }
    break;
  case 0x6c:
    if (uVar3 < 2) break;
    puVar5 = (undefined8 *)0x0;
    switch(puVar1[1]) {
    case 0x53:
      pcVar10 = "operator<<=";
LAB_0012bc20:
      *param_1 = (long)(puVar1 + 2);
      puVar5 = (undefined8 *)FUN_0012c000(param_1,pcVar10);
      break;
    case 0x65:
      pcVar10 = "operator<=";
      goto LAB_0012bc54;
    case 0x69:
      *param_1 = (long)(puVar1 + 2);
      local_50 = FUN_0012af08(param_1);
      puVar5 = (undefined8 *)0x0;
      if (local_50 != 0) {
        puVar5 = (undefined8 *)FUN_0012bf70(param_1,&local_50);
      }
      break;
    case 0x73:
      pcVar10 = "operator<<";
LAB_0012bc54:
      *param_1 = (long)(puVar1 + 2);
      puVar5 = (undefined8 *)FUN_0012bd0c(param_1,pcVar10);
      break;
    case 0x74:
      pcVar10 = "operator<";
      goto LAB_0012bbcc;
    }
    goto code_r0x0012b8b8;
  case 0x6d:
    if (1 < uVar3) {
      puVar5 = (undefined8 *)0x0;
      switch(puVar1[1]) {
      case 0x49:
        pcVar10 = "operator-=";
        break;
      default:
        goto code_r0x0012b8b8;
      case 0x4c:
        pcVar10 = "operator*=";
        break;
      case 0x69:
code_r0x0012b96c:
        pcVar10 = "operator-";
        goto LAB_0012bbcc;
      case 0x6c:
        goto code_r0x0012b8e8;
      case 0x6d:
        pcVar10 = "operator--";
      }
      goto LAB_0012bc54;
    }
    break;
  case 0x6e:
    if (1 < uVar3) {
      puVar5 = (undefined8 *)0x0;
      switch(puVar1[1]) {
      case 0x61:
        *param_1 = (long)(puVar1 + 2);
        puVar5 = (undefined8 *)FUN_0012c09c(param_1,"operator new[]");
        break;
      case 0x65:
        pcVar10 = "operator!=";
        goto LAB_0012bc54;
      case 0x67:
        goto code_r0x0012b96c;
      case 0x74:
        pcVar10 = "operator!";
        goto LAB_0012bbcc;
      case 0x77:
        *param_1 = (long)(puVar1 + 2);
        puVar5 = (undefined8 *)FUN_0012c138(param_1,"operator new");
      }
      goto code_r0x0012b8b8;
    }
    break;
  case 0x6f:
    if (1 < uVar3) {
      cVar2 = puVar1[1];
      if (cVar2 == 'R') {
        pcVar10 = "operator|=";
      }
      else {
        if (cVar2 == 'r') {
          pcVar10 = "operator|";
          goto LAB_0012bbcc;
        }
        if (cVar2 != 'o') break;
        pcVar10 = "operator||";
      }
      goto LAB_0012bc54;
    }
    break;
  case 0x70:
    if (1 < uVar3) {
      puVar5 = (undefined8 *)0x0;
      switch(puVar1[1]) {
      case 0x4c:
        pcVar10 = "operator+=";
        break;
      default:
        goto code_r0x0012b8b8;
      case 0x6c:
      case 0x73:
        pcVar10 = "operator+";
        goto LAB_0012bbcc;
      case 0x6d:
        pcVar10 = "operator->*";
        goto LAB_0012bc20;
      case 0x70:
        pcVar10 = "operator++";
        break;
      case 0x74:
        pcVar10 = "operator->";
      }
      goto LAB_0012bc54;
    }
    break;
  case 0x71:
    if ((1 < uVar3) && (puVar1[1] == 'u')) {
      pvVar11 = (void *)param_1[0x266];
      *param_1 = (long)(puVar1 + 2);
      lVar6 = *(long *)((long)pvVar11 + 8);
      puVar5 = pvVar11;
      if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (void *)0x0) goto LAB_0012bc64;
        lVar6 = 0;
        *puVar5 = pvVar11;
        puVar5[1] = 0;
        param_1[0x266] = (long)puVar5;
      }
      *(long *)((long)puVar5 + 8) = lVar6 + 0x20;
      puVar5 = (undefined8 *)((long)puVar5 + lVar6 + 0x10);
      *puVar5 = &PTR_LAB_0013c540;
      pcVar8 = "operator?";
LAB_0012b958:
      pcVar10 = pcVar8 + 9;
      goto LAB_0012b95c;
    }
    break;
  case 0x72:
    if (1 < uVar3) {
      puVar5 = (undefined8 *)0x0;
      switch(puVar1[1]) {
      case 0x4d:
        pcVar10 = "operator%=";
        break;
      default:
        goto code_r0x0012b8b8;
      case 0x53:
        pcVar10 = "operator>>=";
        goto LAB_0012bc20;
      case 0x6d:
        pcVar10 = "operator%";
        goto LAB_0012bbcc;
      case 0x73:
        pcVar10 = "operator>>";
      }
      goto LAB_0012bc54;
    }
    break;
  case 0x73:
    if ((1 < uVar3) && (puVar1[1] == 's')) {
      pvVar11 = (void *)param_1[0x266];
      *param_1 = (long)(puVar1 + 2);
      lVar6 = *(long *)((long)pvVar11 + 8);
      puVar5 = pvVar11;
      if (lVar6 - 0xfd0U < 0xfffffffffffff00f || lVar6 == -0x21) {
        puVar5 = malloc(0x1000);
        if (puVar5 == (void *)0x0) goto LAB_0012bc64;
        lVar6 = 0;
        *puVar5 = pvVar11;
        puVar5[1] = 0;
        param_1[0x266] = (long)puVar5;
      }
      *(long *)((long)puVar5 + 8) = lVar6 + 0x20;
      puVar5 = (undefined8 *)((long)puVar5 + lVar6 + 0x10);
      *puVar5 = &PTR_LAB_0013c540;
      pcVar8 = "operator<=>";
      pcVar10 = "";
      goto LAB_0012b95c;
    }
    break;
  case 0x76:
    if ((1 < uVar3) && (0xfffffff5 < (byte)puVar1[1] - 0x3a)) {
      *param_1 = (long)(puVar1 + 2);
      lVar6 = FUN_0012af08(param_1);
      puVar5 = (undefined8 *)0x0;
      if (lVar6 != 0) {
        pvVar11 = (void *)param_1[0x266];
        lVar9 = *(long *)((long)pvVar11 + 8);
        puVar7 = pvVar11;
        if (lVar9 - 0xfd0U < 0xfffffffffffff00f || lVar9 == -0x21) {
          puVar7 = malloc(0x1000);
          if (puVar7 == (void *)0x0) goto LAB_0012bc64;
          lVar9 = 0;
          *puVar7 = pvVar11;
          puVar7[1] = 0;
          param_1[0x266] = (long)puVar7;
        }
        *(long *)((long)puVar7 + 8) = lVar9 + 0x20;
        puVar5 = (undefined8 *)((long)puVar7 + lVar9 + 0x10);
        *puVar5 = &PTR_LAB_0013d1f0;
        *(undefined4 *)((long)puVar7 + lVar9 + 0x18) = 0x1010104;
        *(long *)((long)puVar7 + lVar9 + 0x20) = lVar6;
      }
      goto code_r0x0012b8b8;
    }
  }
LAB_0012b8b0:
  puVar5 = (undefined8 *)0x0;
code_r0x0012b8b8:
  if (*(long *)(lVar4 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar5);
  }
  return;
}


// ==== FUN_0012bd0c @ 0012bd0c

undefined8 * FUN_0012bd0c(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_0012bda8 @ 0012bda8

undefined8 * FUN_0012bda8(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_0012be44 @ 0012be44

void FUN_0012be44(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d1f0;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010104;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_0012bed4 @ 0012bed4

undefined8 * FUN_0012bed4(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_0012bf70 @ 0012bf70

void FUN_0012bf70(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013d260;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010113;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_0012c000 @ 0012c000

undefined8 * FUN_0012c000(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_0012c09c @ 0012c09c

undefined8 * FUN_0012c09c(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_0012c138 @ 0012c138

undefined8 * FUN_0012c138(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_0012c1d4 @ 0012c1d4

void FUN_0012c1d4(long param_1,undefined8 *param_2)

{
  ulong __size;
  void *pvVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  
  lVar3 = param_2[1];
  __size = lVar3 + 9;
  if (__size < (ulong)param_2[2]) {
    pvVar1 = (void *)*param_2;
  }
  else {
    uVar2 = param_2[2] << 1;
    if (__size <= uVar2) {
      __size = uVar2;
    }
    param_2[2] = __size;
    pvVar1 = realloc((void *)*param_2,__size);
    *param_2 = pvVar1;
    if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = param_2[1];
  }
  builtin_strncpy((char *)((long)pvVar1 + lVar3),"operator ",9);
  plVar4 = *(long **)(param_1 + 0x10);
  lVar3 = *plVar4;
  param_2[1] = param_2[1] + 9;
  (**(code **)(lVar3 + 0x20))(plVar4,param_2);
  if (*(char *)((long)plVar4 + 9) == '\x01') {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0012c2a0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar4 + 0x28))(plVar4,param_2);
  return;
}


// ==== FUN_0012dec0 @ 0012dec0

byte * FUN_0012dec0(byte *param_1,byte *param_2)

{
  uint uVar1;
  byte *pbVar2;
  
  if (param_1 != param_2) {
    uVar1 = (uint)*param_1;
    pbVar2 = param_1;
    if (uVar1 == 0x5f) {
      if (param_1 + 1 != param_2) {
        uVar1 = (uint)param_1[1];
        if (0xfffffff5 < uVar1 - 0x3a) {
          return param_1 + 2;
        }
        if (uVar1 == 0x5f) {
          for (pbVar2 = param_1 + 2; pbVar2 != param_2; pbVar2 = pbVar2 + 1) {
            if (*pbVar2 - 0x3a < 0xfffffff6) {
              if (*pbVar2 == 0x5f) {
                param_1 = pbVar2 + 1;
              }
              return param_1;
            }
          }
        }
      }
    }
    else {
      while (0xfffffff5 < uVar1 - 0x3a) {
        pbVar2 = pbVar2 + 1;
        if (pbVar2 == param_2) {
          return param_2;
        }
        uVar1 = (uint)*pbVar2;
      }
    }
  }
  return param_1;
}


// ==== FUN_0012df70 @ 0012df70

void FUN_0012df70(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar4 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013dab0;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010118;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar4;
  return;
}


// ==== FUN_0012e008 @ 0012e008

void FUN_0012e008(long param_1,undefined8 *param_2)

{
  ulong __size;
  void *pvVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  
  plVar4 = *(long **)(param_1 + 0x10);
  (**(code **)(*plVar4 + 0x20))(plVar4);
  if (*(char *)((long)plVar4 + 9) != '\x01') {
    (**(code **)(*plVar4 + 0x28))(plVar4,param_2);
  }
  lVar3 = param_2[1];
  __size = lVar3 + 2;
  if (__size < (ulong)param_2[2]) {
    pvVar1 = (void *)*param_2;
  }
  else {
    uVar2 = param_2[2] << 1;
    if (__size <= uVar2) {
      __size = uVar2;
    }
    param_2[2] = __size;
    pvVar1 = realloc((void *)*param_2,__size);
    *param_2 = pvVar1;
    if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = param_2[1];
  }
  *(undefined2 *)((long)pvVar1 + lVar3) = 0x3a3a;
  plVar4 = *(long **)(param_1 + 0x18);
  lVar3 = *plVar4;
  param_2[1] = param_2[1] + 2;
  (**(code **)(lVar3 + 0x20))(plVar4,param_2);
  if (*(char *)((long)plVar4 + 9) == '\x01') {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0012e100. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar4 + 0x28))(plVar4,param_2);
  return;
}


// ==== FUN_0012ee70 @ 0012ee70

void FUN_0012ee70(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  size_t __n;
  void *pvVar2;
  void *pvVar3;
  ulong uVar4;
  long lVar5;
  long *plVar6;
  
  plVar6 = *(long **)(param_1 + 0x10);
  (**(code **)(*plVar6 + 0x20))(plVar6);
  if (*(char *)((long)plVar6 + 9) != '\x01') {
    (**(code **)(*plVar6 + 0x28))(plVar6,param_2);
  }
  lVar5 = param_2[1];
  uVar1 = lVar5 + 2;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] << 1;
    if (uVar1 <= uVar4) {
      uVar1 = uVar4;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_0012efd8;
    lVar5 = param_2[1];
  }
  *(undefined2 *)((long)pvVar2 + lVar5) = 0x2820;
  lVar5 = param_2[1] + 2;
  param_2[1] = lVar5;
  pvVar2 = *(void **)(param_1 + 0x18);
  __n = *(long *)(param_1 + 0x20) - (long)pvVar2;
  if (__n != 0) {
    uVar1 = lVar5 + __n;
    if (uVar1 < (ulong)param_2[2]) {
      pvVar3 = (void *)*param_2;
    }
    else {
      uVar4 = param_2[2] << 1;
      if (uVar1 <= uVar4) {
        uVar1 = uVar4;
      }
      param_2[2] = uVar1;
      pvVar3 = realloc((void *)*param_2,uVar1);
      *param_2 = pvVar3;
      if (pvVar3 == (void *)0x0) goto LAB_0012efd8;
      lVar5 = param_2[1];
    }
    memmove((void *)((long)pvVar3 + lVar5),pvVar2,__n);
    lVar5 = param_2[1] + __n;
    param_2[1] = lVar5;
  }
  uVar1 = lVar5 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] << 1;
    if (uVar1 <= uVar4) {
      uVar1 = uVar4;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_0012efd8:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar5 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar5) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_0012efe4 @ 0012efe4

void FUN_0012efe4(long *param_1)

{
  char *pcVar1;
  char *pcVar2;
  long lVar3;
  char cVar4;
  long lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  long lVar8;
  char *pcVar9;
  void *pvVar10;
  uint uVar11;
  undefined8 *puVar12;
  long lVar13;
  long lVar14;
  undefined1 uVar15;
  undefined1 auVar16 [16];
  long local_70;
  long local_68;
  
  lVar5 = tpidr_el0;
  local_68 = *(long *)(lVar5 + 0x28);
  pcVar9 = (char *)*param_1;
  pcVar2 = (char *)param_1[1];
  if ((pcVar9 == pcVar2) || (*pcVar9 != 'r')) {
    uVar11 = 0;
    if (pcVar9 != pcVar2) goto LAB_0012f054;
LAB_0012f090:
    pcVar9 = pcVar2;
  }
  else {
    pcVar9 = pcVar9 + 1;
    uVar11 = 4;
    *param_1 = (long)pcVar9;
    if (pcVar9 == pcVar2) goto LAB_0012f090;
LAB_0012f054:
    if (*pcVar9 == 'V') {
      pcVar9 = pcVar9 + 1;
      uVar11 = uVar11 | 2;
      *param_1 = (long)pcVar9;
    }
    if (pcVar9 == pcVar2) goto LAB_0012f090;
    if (*pcVar9 == 'K') {
      pcVar9 = pcVar9 + 1;
      uVar11 = uVar11 | 1;
      *param_1 = (long)pcVar9;
    }
  }
  if (((ulong)((long)pcVar2 - (long)pcVar9) < 2) || (*pcVar9 != 'D')) {
LAB_0012f138:
    puVar12 = (undefined8 *)0x0;
LAB_0012f13c:
    pcVar9 = (char *)*param_1;
    pcVar2 = (char *)param_1[1];
    if (((1 < (ulong)((long)pcVar2 - (long)pcVar9)) && (*pcVar9 == 'D')) && (pcVar9[1] == 'x')) {
      pcVar9 = pcVar9 + 2;
      *param_1 = (long)pcVar9;
    }
    if ((pcVar9 != pcVar2) && (*pcVar9 == 'F')) {
      pcVar1 = pcVar9 + 1;
      *param_1 = (long)pcVar1;
      if ((pcVar1 != pcVar2) && (*pcVar1 == 'Y')) {
        *param_1 = (long)(pcVar9 + 2);
      }
      lVar8 = FUN_0011ef00(param_1);
      puVar6 = (undefined8 *)0x0;
      if (lVar8 != 0) {
        lVar13 = 1;
        lVar14 = param_1[2];
        lVar3 = param_1[3];
        do {
          while( true ) {
            pcVar9 = (char *)*param_1;
            if (pcVar9 == (char *)param_1[1]) break;
            if (*pcVar9 != 'v') {
              if (*pcVar9 != 'E') break;
              uVar15 = 0;
              goto LAB_0012f420;
            }
            *param_1 = (long)(pcVar9 + 1);
          }
          if (1 < (ulong)(param_1[1] - (long)pcVar9)) {
            if (*pcVar9 == 'O') {
              if (pcVar9[1] != 'E') goto LAB_0012f230;
              lVar13 = 2;
              uVar15 = 2;
            }
            else {
              if ((*pcVar9 != 'R') || (pcVar9[1] != 'E')) goto LAB_0012f230;
              uVar15 = 1;
              lVar13 = 2;
            }
LAB_0012f420:
            lVar14 = (lVar3 - lVar14 >> 3) * 8;
            *param_1 = (long)(pcVar9 + lVar13);
            auVar16 = FUN_0012a7b8(param_1,param_1[2] + lVar14,param_1[3]);
            pvVar10 = (void *)param_1[0x266];
            param_1[3] = param_1[2] + lVar14;
            lVar14 = *(long *)((long)pvVar10 + 8);
            puVar7 = pvVar10;
            if (lVar14 - 0xfb0U < 0xfffffffffffff00f || lVar14 == -0x41) {
              puVar7 = malloc(0x1000);
              if (puVar7 == (void *)0x0) goto LAB_0012f4bc;
              lVar14 = 0;
              *puVar7 = pvVar10;
              puVar7[1] = 0;
              param_1[0x266] = (long)puVar7;
            }
            *(long *)((long)puVar7 + 8) = lVar14 + 0x40;
            puVar6 = (undefined8 *)((long)puVar7 + lVar14 + 0x10);
            *puVar6 = &PTR_LAB_0013dff0;
            *(undefined4 *)((long)puVar7 + lVar14 + 0x18) = 0x1000f;
            *(long *)((long)puVar7 + lVar14 + 0x20) = lVar8;
            *(undefined1 (*) [16])((long)puVar7 + lVar14 + 0x28) = auVar16;
            *(uint *)((long)puVar7 + lVar14 + 0x38) = uVar11;
            *(undefined1 *)((long)puVar7 + lVar14 + 0x3c) = uVar15;
            *(undefined8 **)((long)puVar7 + lVar14 + 0x40) = puVar12;
            break;
          }
LAB_0012f230:
          local_70 = FUN_0011ef00(param_1);
          puVar6 = (undefined8 *)0x0;
          if (local_70 == 0) break;
          FUN_00120b24(param_1 + 2,&local_70);
        } while( true );
      }
      goto LAB_0012f2e8;
    }
  }
  else {
    cVar4 = pcVar9[1];
    if (cVar4 != 'O') {
      if (cVar4 == 'w') {
        lVar14 = param_1[3];
        pcVar9 = pcVar9 + 2;
        lVar8 = param_1[2];
        *param_1 = (long)pcVar9;
        if (pcVar9 == pcVar2) goto LAB_0012f34c;
        while (*pcVar9 != 'E') {
LAB_0012f34c:
          do {
            local_70 = FUN_0011ef00(param_1);
            puVar6 = (undefined8 *)0x0;
            if (local_70 == 0) goto LAB_0012f2e8;
            FUN_00120b24(param_1 + 2,&local_70);
            pcVar9 = (char *)*param_1;
          } while (pcVar9 == (char *)param_1[1]);
        }
        lVar8 = (lVar14 - lVar8 >> 3) * 8;
        *param_1 = (long)(pcVar9 + 1);
        auVar16 = FUN_0012a7b8(param_1,param_1[2] + lVar8,param_1[3]);
        pvVar10 = (void *)param_1[0x266];
        param_1[3] = param_1[2] + lVar8;
        lVar8 = *(long *)((long)pvVar10 + 8);
        puVar6 = pvVar10;
        if (lVar8 - 0xfd0U < 0xfffffffffffff00f || lVar8 == -0x21) {
          puVar6 = malloc(0x1000);
          if (puVar6 == (void *)0x0) {
LAB_0012f4bc:
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar8 = 0;
          *puVar6 = pvVar10;
          puVar6[1] = 0;
          param_1[0x266] = (long)puVar6;
        }
        *(long *)((long)puVar6 + 8) = lVar8 + 0x20;
        puVar12 = (undefined8 *)((long)puVar6 + lVar8 + 0x10);
        *puVar12 = &PTR_LAB_0013df80;
        *(undefined4 *)((long)puVar6 + lVar8 + 0x18) = 0x1010111;
        *(undefined1 (*) [16])((long)puVar6 + lVar8 + 0x20) = auVar16;
      }
      else {
        if (cVar4 != 'o') goto LAB_0012f138;
        pvVar10 = (void *)param_1[0x266];
        *param_1 = (long)(pcVar9 + 2);
        lVar8 = *(long *)((long)pvVar10 + 8);
        puVar6 = pvVar10;
        if (lVar8 - 0xfd0U < 0xfffffffffffff00f || lVar8 == -0x21) {
          puVar6 = malloc(0x1000);
          if (puVar6 == (void *)0x0) goto LAB_0012f4bc;
          lVar8 = 0;
          *puVar6 = pvVar10;
          puVar6[1] = 0;
          param_1[0x266] = (long)puVar6;
        }
        *(long *)((long)puVar6 + 8) = lVar8 + 0x20;
        puVar12 = (undefined8 *)((long)puVar6 + lVar8 + 0x10);
        *puVar12 = &PTR_LAB_0013c540;
        *(undefined4 *)((long)puVar6 + lVar8 + 0x18) = 0x1010107;
        *(char **)((long)puVar6 + lVar8 + 0x20) = "noexcept";
        *(char **)((long)puVar6 + lVar8 + 0x28) = "";
      }
      goto LAB_0012f13c;
    }
    *param_1 = (long)(pcVar9 + 2);
    lVar8 = FUN_00122d94(param_1);
    puVar6 = (undefined8 *)0x0;
    if (lVar8 == 0) goto LAB_0012f2e8;
    pcVar9 = (char *)*param_1;
    if ((pcVar9 != (char *)param_1[1]) && (*pcVar9 == 'E')) {
      pvVar10 = (void *)param_1[0x266];
      *param_1 = (long)(pcVar9 + 1);
      lVar14 = *(long *)((long)pvVar10 + 8);
      puVar6 = pvVar10;
      if (lVar14 - 0xfd0U < 0xfffffffffffff00f || lVar14 == -0x21) {
        puVar6 = malloc(0x1000);
        if (puVar6 == (void *)0x0) goto LAB_0012f4bc;
        lVar14 = 0;
        *puVar6 = pvVar10;
        puVar6[1] = 0;
        param_1[0x266] = (long)puVar6;
      }
      *(long *)((long)puVar6 + 8) = lVar14 + 0x20;
      puVar12 = (undefined8 *)((long)puVar6 + lVar14 + 0x10);
      *puVar12 = &PTR_LAB_0013df10;
      *(undefined4 *)((long)puVar6 + lVar14 + 0x18) = 0x1010110;
      *(long *)((long)puVar6 + lVar14 + 0x20) = lVar8;
      goto LAB_0012f13c;
    }
  }
  puVar6 = (undefined8 *)0x0;
LAB_0012f2e8:
  if (*(long *)(lVar5 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar6);
  }
  return;
}


// ==== FUN_0012f4c4 @ 0012f4c4

undefined8 * FUN_0012f4c4(long *param_1)

{
  byte *pbVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  undefined8 *puVar4;
  long lVar5;
  undefined8 *puVar6;
  long lVar7;
  undefined **ppuVar8;
  byte *pbVar9;
  ulong uVar10;
  long lVar11;
  uint uVar12;
  void *pvVar13;
  byte *pbVar14;
  byte *pbVar15;
  undefined8 *puVar16;
  
  pbVar9 = (byte *)*param_1;
  pbVar1 = (byte *)param_1[1];
  if (pbVar9 == pbVar1) {
LAB_0012f560:
    uVar12 = 0;
  }
  else {
    if (*pbVar9 != 0x72) {
      if (*pbVar9 != 0x55) goto LAB_0012f560;
      pbVar15 = pbVar9 + 1;
      *param_1 = (long)pbVar15;
      if (pbVar1 == pbVar15) {
        return (undefined8 *)0x0;
      }
      if (*pbVar15 - 0x3a < 0xfffffff6) {
        return (undefined8 *)0x0;
      }
      uVar10 = 0;
      pbVar9 = pbVar9 + 2;
      do {
        pbVar15 = pbVar9;
        *param_1 = (long)pbVar15;
        uVar10 = ((ulong)pbVar15[-1] + uVar10 * 10) - 0x30;
        if (pbVar15 == pbVar1) {
          pbVar15 = pbVar1;
          goto LAB_0012f65c;
        }
        pbVar9 = pbVar15 + 1;
      } while (*pbVar15 - 0x30 < 10);
LAB_0012f65c:
      if ((ulong)((long)pbVar1 - (long)pbVar15) < uVar10) {
        return (undefined8 *)0x0;
      }
      pbVar9 = pbVar15 + uVar10;
      *param_1 = (long)pbVar9;
      if (pbVar15 == pbVar9) {
        return (undefined8 *)0x0;
      }
      if (((((((ulong)((long)pbVar9 - (long)pbVar15) < 9) || (*pbVar15 != 0x6f)) ||
            (pbVar15[1] != 0x62)) || ((pbVar15[2] != 0x6a || (pbVar15[3] != 99)))) ||
          ((pbVar15[4] != 0x70 || ((pbVar15[5] != 0x72 || (pbVar15[6] != 0x6f)))))) ||
         ((pbVar15[7] != 0x74 || (pbVar15[8] != 0x6f)))) {
        lVar5 = FUN_0012f4c4(param_1);
        if (lVar5 == 0) {
          return (undefined8 *)0x0;
        }
        puVar16 = (undefined8 *)param_1[0x266];
        lVar7 = puVar16[1];
        puVar6 = puVar16;
        if (lVar7 - 0xfc0U < 0xfffffffffffff00f || lVar7 == -0x31) {
          puVar6 = malloc(0x1000);
          if (puVar6 == (void *)0x0) goto LAB_0012f880;
          lVar7 = 0;
          *puVar6 = puVar16;
          puVar6[1] = 0;
          param_1[0x266] = (long)puVar6;
        }
        lVar11 = (long)puVar6 + lVar7;
        uVar12 = 0x102;
        ppuVar8 = &PTR_LAB_0013e0d0;
        goto LAB_0012f7c0;
      }
      pbVar14 = pbVar15 + 9;
      *param_1 = (long)pbVar14;
      param_1[1] = (long)pbVar9;
      if ((pbVar14 == pbVar9) || (*pbVar14 - 0x3a < 0xfffffff6)) {
LAB_0012f7ec:
        pbVar14 = (byte *)0x0;
        pbVar15 = (byte *)0x0;
      }
      else {
        uVar10 = 0;
        pbVar14 = pbVar15 + 10;
        do {
          pbVar15 = pbVar14;
          *param_1 = (long)pbVar15;
          uVar10 = ((ulong)pbVar15[-1] + uVar10 * 10) - 0x30;
          if (pbVar15 == pbVar9) {
            pbVar15 = pbVar9;
            goto LAB_0012f7e0;
          }
          pbVar14 = pbVar15 + 1;
        } while (*pbVar15 - 0x30 < 10);
LAB_0012f7e0:
        if ((ulong)((long)pbVar9 - (long)pbVar15) < uVar10) goto LAB_0012f7ec;
        pbVar14 = pbVar15 + uVar10;
      }
      *param_1 = (long)pbVar9;
      param_1[1] = (long)pbVar1;
      if ((pbVar15 == pbVar14) || (lVar5 = FUN_0012f4c4(param_1), lVar5 == 0)) {
        return (undefined8 *)0x0;
      }
      puVar16 = (undefined8 *)param_1[0x266];
      lVar7 = puVar16[1];
      puVar6 = puVar16;
      if (lVar7 - 0xfc0U < 0xfffffffffffff00f || lVar7 == -0x31) {
        puVar6 = malloc(0x1000);
        if (puVar6 == (undefined8 *)0x0) goto LAB_0012f880;
        lVar7 = 0;
        *puVar6 = puVar16;
        puVar6[1] = 0;
        param_1[0x266] = (long)puVar6;
      }
      lVar11 = (long)puVar6 + lVar7;
      uVar12 = 0x10a;
      ppuVar8 = &PTR_LAB_0013e060;
      pbVar9 = pbVar14;
LAB_0012f7c0:
      puVar6[1] = lVar7 + 0x30;
      *(undefined8 *)(lVar11 + 0x10) = ppuVar8;
      *(uint *)(lVar11 + 0x18) = uVar12 | 0x1010000;
      *(long *)(lVar11 + 0x20) = lVar5;
      *(byte **)(lVar11 + 0x28) = pbVar15;
      *(byte **)(lVar11 + 0x30) = pbVar9;
      return (undefined8 *)(lVar11 + 0x10);
    }
    pbVar9 = pbVar9 + 1;
    uVar12 = 4;
    *param_1 = (long)pbVar9;
  }
  if (pbVar9 != pbVar1) {
    if (*pbVar9 == 0x56) {
      pbVar9 = pbVar9 + 1;
      uVar12 = uVar12 | 2;
      *param_1 = (long)pbVar9;
    }
    if ((pbVar9 != pbVar1) && (*pbVar9 == 0x4b)) {
      uVar12 = uVar12 | 1;
      *param_1 = (long)(pbVar9 + 1);
    }
  }
  puVar16 = (undefined8 *)FUN_0011ef00(param_1);
  puVar6 = puVar16;
  if ((puVar16 != (undefined8 *)0x0) && (uVar12 != 0)) {
    pvVar13 = (void *)param_1[0x266];
    lVar5 = *(long *)((long)pvVar13 + 8);
    puVar4 = pvVar13;
    if (lVar5 - 0xfd0U < 0xfffffffffffff00f || lVar5 == -0x21) {
      puVar4 = malloc(0x1000);
      if (puVar4 == (void *)0x0) {
LAB_0012f880:
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar5 = 0;
      *puVar4 = pvVar13;
      puVar4[1] = 0;
      param_1[0x266] = (long)puVar4;
    }
    uVar2 = *(undefined1 *)((long)puVar16 + 0xb);
    *(long *)((long)puVar4 + 8) = lVar5 + 0x20;
    uVar3 = *(undefined2 *)((long)puVar16 + 9);
    puVar6 = (undefined8 *)((long)puVar4 + lVar5 + 0x10);
    *puVar6 = &PTR_LAB_0013e140;
    *(undefined8 **)((long)puVar4 + lVar5 + 0x20) = puVar16;
    *(undefined1 *)((long)puVar4 + lVar5 + 0x18) = 3;
    *(undefined1 *)((long)puVar4 + lVar5 + 0x1b) = uVar2;
    *(undefined2 *)((long)puVar4 + lVar5 + 0x19) = uVar3;
    *(uint *)((long)puVar4 + lVar5 + 0x1c) = uVar12;
  }
  return puVar6;
}


// ==== FUN_0012f884 @ 0012f884

undefined8 * FUN_0012f884(long param_1,char *param_2)

{
  undefined8 *puVar1;
  size_t sVar2;
  long lVar3;
  undefined8 *puVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar3 + 0x20;
  sVar2 = strlen(param_2);
  puVar4 = (undefined8 *)((long)puVar1 + lVar3 + 0x10);
  *puVar4 = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar3 + 0x18) = 0x1010107;
  *(char **)((long)puVar1 + lVar3 + 0x20) = param_2;
  *(char **)((long)puVar1 + lVar3 + 0x28) = param_2 + sVar2;
  return puVar4;
}


// ==== FUN_0012f920 @ 0012f920

void FUN_0012f920(long *param_1)

{
  byte *pbVar1;
  char *pcVar2;
  char *pcVar3;
  byte *pbVar4;
  byte bVar5;
  long lVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  long lVar9;
  long lVar10;
  long lVar11;
  byte *pbVar12;
  byte *pbVar13;
  void *pvVar14;
  long local_58;
  undefined8 *local_50;
  long local_48;
  
  lVar6 = tpidr_el0;
  local_48 = *(long *)(lVar6 + 0x28);
  pcVar3 = (char *)*param_1;
  pbVar4 = (byte *)param_1[1];
  if (((1 < (ulong)((long)pbVar4 - (long)pcVar3)) && (*pcVar3 == 'D')) && (pcVar3[1] == 'v')) {
    pbVar1 = (byte *)(pcVar3 + 2);
    *param_1 = (long)pbVar1;
    if ((pbVar4 != pbVar1) && (bVar5 = *pbVar1, 0x30 < bVar5)) {
      if (bVar5 < 0x3a) {
        pbVar13 = (byte *)(pcVar3 + 2);
        pbVar12 = (byte *)(pcVar3 + 3);
        do {
          *param_1 = (long)pbVar12;
          if (pbVar12 == pbVar4) {
            pbVar13 = pbVar4;
            break;
          }
          bVar5 = *pbVar12;
          pbVar13 = pbVar13 + 1;
          pbVar12 = pbVar12 + 1;
        } while (0xfffffff5 < bVar5 - 0x3a);
        pvVar14 = (void *)param_1[0x266];
        lVar11 = *(long *)((long)pvVar14 + 8);
        puVar8 = pvVar14;
        if (lVar11 - 0xfd0U < 0xfffffffffffff00f || lVar11 == -0x21) {
          puVar8 = malloc(0x1000);
          if (puVar8 == (void *)0x0) goto LAB_0012fbdc;
          lVar11 = 0;
          *puVar8 = pvVar14;
          puVar8[1] = 0;
          param_1[0x266] = (long)puVar8;
        }
        *(long *)((long)puVar8 + 8) = lVar11 + 0x20;
        local_50 = (undefined8 *)((long)puVar8 + lVar11 + 0x10);
        *local_50 = &PTR_LAB_0013c540;
        *(undefined4 *)((long)puVar8 + lVar11 + 0x18) = 0x1010107;
        *(byte **)((long)puVar8 + lVar11 + 0x20) = pbVar1;
        *(byte **)((long)puVar8 + lVar11 + 0x28) = pbVar13;
        pcVar3 = (char *)*param_1;
        if ((pcVar3 != (char *)param_1[1]) && (*pcVar3 == '_')) {
          pcVar2 = pcVar3 + 1;
          *param_1 = (long)pcVar2;
          if ((pcVar2 == (char *)param_1[1]) || (*pcVar2 != 'p')) {
            local_58 = FUN_0011ef00(param_1);
            puVar8 = (undefined8 *)0x0;
            if (local_58 != 0) {
              puVar8 = (undefined8 *)FUN_00130bbc(param_1,&local_58,&local_50);
            }
          }
          else {
            *param_1 = (long)(pcVar3 + 2);
            puVar8 = (undefined8 *)FUN_00130b2c(param_1,&local_50);
          }
          goto LAB_0012fb8c;
        }
        goto LAB_0012fb88;
      }
      if (bVar5 == 0x5f) {
        *param_1 = (long)(pcVar3 + 3);
        lVar11 = FUN_0011ef00(param_1);
        puVar8 = (undefined8 *)0x0;
        if (lVar11 != 0) {
          pvVar14 = (void *)param_1[0x266];
          lVar9 = *(long *)((long)pvVar14 + 8);
          puVar7 = pvVar14;
          if (lVar9 - 0xfd0U < 0xfffffffffffff00f || lVar9 == -0x21) {
            puVar7 = malloc(0x1000);
            if (puVar7 == (void *)0x0) goto LAB_0012fbdc;
            lVar9 = 0;
            *puVar7 = pvVar14;
            puVar7[1] = 0;
            param_1[0x266] = (long)puVar7;
          }
          *(long *)((long)puVar7 + 8) = lVar9 + 0x20;
          puVar8 = (undefined8 *)((long)puVar7 + lVar9 + 0x10);
          *puVar8 = &PTR_LAB_0013e220;
          *(undefined4 *)((long)puVar7 + lVar9 + 0x18) = 0x1010119;
          *(long *)((long)puVar7 + lVar9 + 0x20) = lVar11;
          *(undefined8 *)((long)puVar7 + lVar9 + 0x28) = 0;
        }
        goto LAB_0012fb8c;
      }
    }
    lVar11 = FUN_00122d94(param_1);
    puVar8 = (undefined8 *)0x0;
    if (lVar11 == 0) goto LAB_0012fb8c;
    pcVar3 = (char *)*param_1;
    if ((pcVar3 != (char *)param_1[1]) && (*pcVar3 == '_')) {
      *param_1 = (long)(pcVar3 + 1);
      lVar9 = FUN_0011ef00(param_1);
      puVar8 = (undefined8 *)0x0;
      if (lVar9 != 0) {
        pvVar14 = (void *)param_1[0x266];
        lVar10 = *(long *)((long)pvVar14 + 8);
        puVar7 = pvVar14;
        if (lVar10 - 0xfd0U < 0xfffffffffffff00f || lVar10 == -0x21) {
          puVar7 = malloc(0x1000);
          if (puVar7 == (void *)0x0) {
LAB_0012fbdc:
                    /* WARNING: Subroutine does not return */
            FUN_0011dc6c();
          }
          lVar10 = 0;
          *puVar7 = pvVar14;
          puVar7[1] = 0;
          param_1[0x266] = (long)puVar7;
        }
        *(long *)((long)puVar7 + 8) = lVar10 + 0x20;
        puVar8 = (undefined8 *)((long)puVar7 + lVar10 + 0x10);
        *puVar8 = &PTR_LAB_0013e220;
        *(undefined4 *)((long)puVar7 + lVar10 + 0x18) = 0x1010119;
        *(long *)((long)puVar7 + lVar10 + 0x20) = lVar9;
        *(long *)((long)puVar7 + lVar10 + 0x28) = lVar11;
      }
      goto LAB_0012fb8c;
    }
  }
LAB_0012fb88:
  puVar8 = (undefined8 *)0x0;
LAB_0012fb8c:
  if (*(long *)(lVar6 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar8);
  }
  return;
}


// ==== FUN_0012fbe4 @ 0012fbe4

undefined8 * FUN_0012fbe4(long *param_1)

{
  char *pcVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  long lVar5;
  undefined8 *puVar6;
  char *pcVar7;
  char *pcVar8;
  void *pvVar9;
  
  pcVar1 = (char *)*param_1;
  if (((ulong)(param_1[1] - (long)pcVar1) < 2) || (*pcVar1 != 'T')) {
LAB_0012fc48:
    puVar6 = (undefined8 *)FUN_0011feb0(param_1,0);
    return puVar6;
  }
  cVar2 = pcVar1[1];
  if (cVar2 == 'e') {
    pcVar7 = "enum";
    pcVar8 = "";
  }
  else if (cVar2 == 's') {
    pcVar7 = "struct";
    pcVar8 = "";
  }
  else {
    if (cVar2 != 'u') goto LAB_0012fc48;
    pcVar7 = "union";
    pcVar8 = "";
  }
  *param_1 = (long)(pcVar1 + 2);
  puVar3 = (undefined8 *)FUN_0011feb0(param_1,0);
  puVar6 = puVar3;
  if ((puVar3 != (undefined8 *)0x0) && (pcVar7 != pcVar8)) {
    pvVar9 = (void *)param_1[0x266];
    lVar5 = *(long *)((long)pvVar9 + 8);
    puVar4 = pvVar9;
    if (lVar5 - 0xfc0U < 0xfffffffffffff00f || lVar5 == -0x31) {
      puVar4 = malloc(0x1000);
      if (puVar4 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      lVar5 = 0;
      *puVar4 = pvVar9;
      puVar4[1] = 0;
      param_1[0x266] = (long)puVar4;
    }
    *(long *)((long)puVar4 + 8) = lVar5 + 0x30;
    puVar6 = (undefined8 *)((long)puVar4 + lVar5 + 0x10);
    *puVar6 = &PTR_LAB_0013e370;
    *(char **)((long)puVar4 + lVar5 + 0x28) = pcVar8;
    *(undefined8 **)((long)puVar4 + lVar5 + 0x30) = puVar3;
    *(undefined4 *)((long)puVar4 + lVar5 + 0x18) = 0x1010106;
    *(char **)((long)puVar4 + lVar5 + 0x20) = pcVar7;
  }
  return puVar6;
}


// ==== FUN_0012fd28 @ 0012fd28

void FUN_0012fd28(long param_1,long *param_2)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  long lVar3;
  long lVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar5 + 8);
  puVar2 = pvVar5;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar2 = malloc(0x1000);
    if (puVar2 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar2 = pvVar5;
    puVar2[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar2;
  }
  lVar4 = *param_2;
  *(long *)((long)puVar2 + 8) = lVar3 + 0x20;
  uVar1 = *(undefined1 *)(lVar4 + 9);
  *(undefined ***)((long)puVar2 + lVar3 + 0x10) = &PTR_LAB_0013e3e0;
  *(undefined1 *)((long)puVar2 + lVar3 + 0x18) = 0xb;
  *(undefined1 *)((long)puVar2 + lVar3 + 0x19) = uVar1;
  *(undefined2 *)((long)puVar2 + lVar3 + 0x1a) = 0x101;
  *(long *)((long)puVar2 + lVar3 + 0x20) = lVar4;
  return;
}


// ==== FUN_0012fdc4 @ 0012fdc4

void FUN_0012fdc4(long param_1,long *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined1 uVar2;
  undefined8 *puVar3;
  long lVar4;
  long lVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar4 = *(long *)((long)pvVar6 + 8);
  puVar3 = pvVar6;
  if (lVar4 - 0xfd0U < 0xfffffffffffff00f || lVar4 == -0x21) {
    puVar3 = malloc(0x1000);
    if (puVar3 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar4 = 0;
    *puVar3 = pvVar6;
    puVar3[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar3;
  }
  lVar5 = *param_2;
  *(long *)((long)puVar3 + 8) = lVar4 + 0x20;
  uVar1 = *param_3;
  *(undefined ***)((long)puVar3 + lVar4 + 0x10) = &PTR_LAB_0013e450;
  *(undefined1 *)((long)puVar3 + lVar4 + 0x18) = 0xc;
  uVar2 = *(undefined1 *)(lVar5 + 9);
  *(undefined2 *)((long)puVar3 + lVar4 + 0x1a) = 0x101;
  *(long *)((long)puVar3 + lVar4 + 0x20) = lVar5;
  *(undefined4 *)((long)puVar3 + lVar4 + 0x28) = uVar1;
  *(undefined1 *)((long)puVar3 + lVar4 + 0x19) = uVar2;
  *(undefined1 *)((long)puVar3 + lVar4 + 0x2c) = 0;
  return;
}


// ==== FUN_0012fe70 @ 0012fe70

void FUN_0012fe70(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013e4c0;
  uVar3 = *param_2;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010105;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x28) = " complex";
  *(char **)((long)puVar1 + lVar2 + 0x30) = "";
  return;
}


// ==== FUN_0012ff10 @ 0012ff10

void FUN_0012ff10(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfc0U < 0xfffffffffffff00f || lVar2 == -0x31) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x30;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013e4c0;
  uVar3 = *param_2;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010105;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(char **)((long)puVar1 + lVar2 + 0x28) = " imaginary";
  *(char **)((long)puVar1 + lVar2 + 0x30) = "";
  return;
}


// ==== FUN_0012ffb0 @ 0012ffb0

void FUN_0012ffb0(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  void *pvVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  
  lVar4 = param_2[1];
  uVar1 = lVar4 + 9;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar3 = param_2[2] << 1;
    if (uVar1 <= uVar3) {
      uVar1 = uVar3;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_001300c4;
    lVar4 = param_2[1];
  }
  builtin_strncpy((char *)((long)pvVar2 + lVar4),"noexcept(",9);
  plVar5 = *(long **)(param_1 + 0x10);
  lVar4 = *plVar5;
  param_2[1] = param_2[1] + 9;
  (**(code **)(lVar4 + 0x20))(plVar5,param_2);
  if (*(char *)((long)plVar5 + 9) != '\x01') {
    (**(code **)(*plVar5 + 0x28))(plVar5,param_2);
  }
  lVar4 = param_2[1];
  uVar1 = lVar4 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar3 = param_2[2] << 1;
    if (uVar1 <= uVar3) {
      uVar1 = uVar3;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_001300c4:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar4 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar4) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_00130a9c @ 00130a9c

void FUN_00130a9c(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  void *pvVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  
  pvVar3 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar3 + 8);
  puVar1 = pvVar3;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar3;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar5 = param_2[1];
  uVar4 = *param_2;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013c540;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010107;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar5;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar4;
  return;
}


// ==== FUN_00130b2c @ 00130b2c

void FUN_00130b2c(long param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  void *pvVar4;
  
  pvVar4 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar4 + 8);
  puVar1 = pvVar4;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar4;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013e1b0;
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x101011a;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  return;
}


// ==== FUN_00130bbc @ 00130bbc

void FUN_00130bbc(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar4 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013e220;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x1010119;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar4;
  return;
}


// ==== FUN_00130c54 @ 00130c54

void FUN_00130c54(long param_1,undefined8 *param_2)

{
  ulong uVar1;
  void *pvVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  
  lVar4 = param_2[1];
  uVar1 = lVar4 + 0xd;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar3 = param_2[2] << 1;
    if (uVar1 <= uVar3) {
      uVar1 = uVar3;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) goto LAB_00130d68;
    lVar4 = param_2[1];
  }
  builtin_strncpy((char *)((long)pvVar2 + lVar4),"pixel vector[",0xd);
  plVar5 = *(long **)(param_1 + 0x10);
  lVar4 = *plVar5;
  param_2[1] = param_2[1] + 0xd;
  (**(code **)(lVar4 + 0x20))(plVar5,param_2);
  if (*(char *)((long)plVar5 + 9) != '\x01') {
    (**(code **)(*plVar5 + 0x28))(plVar5,param_2);
  }
  lVar4 = param_2[1];
  uVar1 = lVar4 + 1;
  if (uVar1 < (ulong)param_2[2]) {
    pvVar2 = (void *)*param_2;
  }
  else {
    uVar3 = param_2[2] << 1;
    if (uVar1 <= uVar3) {
      uVar1 = uVar3;
    }
    param_2[2] = uVar1;
    pvVar2 = realloc((void *)*param_2,uVar1);
    *param_2 = pvVar2;
    if (pvVar2 == (void *)0x0) {
LAB_00130d68:
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar4 = param_2[1];
  }
  *(undefined1 *)((long)pvVar2 + lVar4) = 0x5d;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_00130ecc @ 00130ecc

void FUN_00130ecc(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  void *pvVar5;
  
  pvVar5 = *(void **)(param_1 + 0x1330);
  lVar2 = *(long *)((long)pvVar5 + 8);
  puVar1 = pvVar5;
  if (lVar2 - 0xfd0U < 0xfffffffffffff00f || lVar2 == -0x21) {
    puVar1 = malloc(0x1000);
    if (puVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar2 = 0;
    *puVar1 = pvVar5;
    puVar1[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar1;
  }
  uVar3 = *param_2;
  *(long *)((long)puVar1 + 8) = lVar2 + 0x20;
  uVar4 = *param_3;
  *(undefined ***)((long)puVar1 + lVar2 + 0x10) = &PTR_LAB_0013e290;
  *(undefined4 *)((long)puVar1 + lVar2 + 0x18) = 0x100000e;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x20) = uVar3;
  *(undefined8 *)((long)puVar1 + lVar2 + 0x28) = uVar4;
  return;
}


// ==== FUN_00131124 @ 00131124

void FUN_00131124(long param_1,undefined8 *param_2,long *param_3)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  long lVar3;
  long lVar4;
  undefined8 uVar5;
  void *pvVar6;
  
  pvVar6 = *(void **)(param_1 + 0x1330);
  lVar3 = *(long *)((long)pvVar6 + 8);
  puVar2 = pvVar6;
  if (lVar3 - 0xfd0U < 0xfffffffffffff00f || lVar3 == -0x21) {
    puVar2 = malloc(0x1000);
    if (puVar2 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0011dc6c();
    }
    lVar3 = 0;
    *puVar2 = pvVar6;
    puVar2[1] = 0;
    *(undefined8 **)(param_1 + 0x1330) = puVar2;
  }
  lVar4 = *param_3;
  *(undefined ***)((long)puVar2 + lVar3 + 0x10) = &PTR_LAB_0013e300;
  *(long *)((long)puVar2 + 8) = lVar3 + 0x20;
  uVar1 = *(undefined1 *)(lVar4 + 9);
  *(undefined1 *)((long)puVar2 + lVar3 + 0x18) = 0xd;
  uVar5 = *param_2;
  *(undefined1 *)((long)puVar2 + lVar3 + 0x19) = uVar1;
  *(undefined8 *)((long)puVar2 + lVar3 + 0x20) = uVar5;
  *(long *)((long)puVar2 + lVar3 + 0x28) = lVar4;
  *(undefined2 *)((long)puVar2 + lVar3 + 0x1a) = 0x101;
  return;
}


// ==== FUN_0013212c @ 0013212c

void FUN_0013212c(ulong *param_1,uint param_2,ulong param_3,long param_4,undefined8 param_5)

{
  ulong uVar1;
  byte bVar2;
  byte bVar3;
  ulong uVar4;
  long lVar5;
  undefined1 *puVar6;
  long lVar7;
  ulong uVar8;
  ulong uVar9;
  ulong uVar10;
  long lVar11;
  long *plVar12;
  undefined4 uVar13;
  ulong uVar14;
  ulong uVar15;
  ulong uVar16;
  byte *pbVar17;
  byte *pbVar18;
  byte *pbVar19;
  byte *local_a8;
  byte *local_98;
  uint local_88;
  byte *local_80;
  byte *local_78;
  byte *local_70;
  long local_68;
  
  lVar5 = tpidr_el0;
  local_68 = *(long *)(lVar5 + 0x28);
  param_1[4] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  *(undefined4 *)(param_1 + 5) = 3;
  if ((param_2 & 1) == 0) {
    if ((param_2 >> 1 & 1) == 0) goto LAB_00132568;
    if ((~param_2 & 0xc) == 0) {
      uVar13 = 2;
      goto LAB_00132564;
    }
  }
  else if ((param_2 & 0xe) != 0) goto LAB_00132568;
  puVar6 = (undefined1 *)FUN_0013417c(param_5);
  if (puVar6 != (undefined1 *)0x0) {
    param_1[2] = (ulong)puVar6;
    lVar7 = FUN_00134208(param_5);
    uVar8 = FUN_001341b0(param_5);
    local_78 = puVar6 + 1;
    uVar9 = FUN_001328c8(&local_78,*puVar6);
    uVar1 = uVar8;
    if (uVar9 != 0) {
      uVar1 = uVar9;
    }
    pbVar17 = local_78 + 1;
    uVar9 = (ulong)*local_78;
    if (uVar9 == 0xff) {
      local_98 = (byte *)0x0;
    }
    else {
      uVar16 = 0;
      uVar14 = 0;
      pbVar18 = pbVar17;
      do {
        pbVar17 = pbVar18 + 1;
        bVar2 = *pbVar18;
        uVar10 = uVar16 & 0x3f;
        uVar16 = uVar16 + 7;
        uVar14 = ((ulong)bVar2 & 0x7f) << uVar10 | uVar14;
        pbVar18 = pbVar17;
      } while ((char)bVar2 < '\0');
      local_98 = pbVar17 + uVar14;
    }
    uVar16 = 0;
    uVar14 = 0;
    uVar8 = lVar7 + ~uVar8;
    bVar2 = *pbVar17;
    pbVar17 = pbVar17 + 1;
    do {
      pbVar18 = pbVar17 + 1;
      bVar3 = *pbVar17;
      uVar10 = uVar16 & 0x3f;
      uVar16 = uVar16 + 7;
      uVar14 = ((ulong)bVar3 & 0x7f) << uVar10 | uVar14;
      pbVar17 = pbVar18;
    } while ((char)bVar3 < '\0');
    local_80 = pbVar18;
    local_78 = pbVar18;
    do {
      if (pbVar18 + (uVar14 & 0xffffffff) <= local_80) break;
      uVar10 = FUN_001328c8(&local_80,bVar2);
      lVar7 = FUN_001328c8(&local_80,bVar2);
      lVar11 = FUN_001328c8(&local_80,bVar2);
      uVar16 = 0;
      uVar15 = 0;
      pbVar17 = local_80;
      do {
        local_80 = pbVar17 + 1;
        bVar3 = *pbVar17;
        uVar4 = uVar16 & 0x3f;
        uVar16 = uVar16 + 7;
        uVar15 = ((ulong)bVar3 & 0x7f) << uVar4 | uVar15;
        pbVar17 = local_80;
      } while ((char)bVar3 < '\0');
      if ((uVar10 <= uVar8) && (uVar8 < lVar7 + uVar10)) {
        if (lVar11 == 0) goto LAB_0013255c;
        uVar1 = lVar11 + uVar1;
        if (uVar15 != 0) {
          uVar8 = uVar9 & 0xf;
          pbVar18 = pbVar18 + uVar15 + (uVar14 & 0xffffffff) + -1;
          local_a8 = (byte *)(param_4 + 0x20);
          local_88 = 0x1c1dU >> uVar8 & 1;
          goto LAB_0013235c;
        }
        if ((param_2 & 6) != 2) goto LAB_0013255c;
        uVar13 = 6;
        *param_1 = 0;
        param_1[3] = uVar1;
        goto LAB_00132564;
      }
    } while (uVar10 <= uVar8);
LAB_00132660:
    FUN_0011d6a4(param_4);
    if ((param_3 & 1) != 0) {
      FUN_0011dce0(*(undefined8 *)(param_4 + -0x38));
    }
                    /* WARNING: Subroutine does not return */
    FUN_0011dc6c();
  }
  uVar13 = 8;
  goto LAB_00132564;
LAB_0013235c:
  uVar16 = 0;
  uVar14 = 0;
  pbVar17 = pbVar18;
  do {
    pbVar19 = pbVar17 + 1;
    bVar2 = *pbVar17;
    uVar10 = uVar16 & 0x3f;
    uVar16 = uVar16 + 7;
    uVar14 = ((ulong)bVar2 & 0x7f) << uVar10 | uVar14;
    pbVar17 = pbVar19;
  } while ((char)bVar2 < '\0');
  uVar10 = -1L << (uVar16 & 0x3f);
  if ((uVar16 < 0x40 & bVar2 >> 6) == 0) {
    uVar10 = 0;
  }
  uVar14 = uVar14 | uVar10;
  if ((long)uVar14 < 1) {
    if ((long)uVar14 < 0) {
      if ((param_3 & 1) == 0) {
        if ((param_2 & 5) != 0) goto LAB_0013259c;
        if ((param_2 >> 3 & 1) == 0) goto LAB_001326ac;
      }
      else {
        lVar7 = FUN_0011d4d4(param_4);
        pbVar17 = local_a8;
        if (lVar7 == 0x434c4e47432b2b01) {
          pbVar17 = *(byte **)(param_4 + -0x58);
        }
        if ((pbVar17 == (byte *)0x0) || (*(long *)(param_4 + -0x50) == 0)) goto LAB_001326a0;
        uVar16 = FUN_00132a3c(uVar14,local_98,uVar9,*(long *)(param_4 + -0x50),pbVar17);
        if ((uVar16 & 1) != 0) {
          if ((param_2 & 1) == 0) goto LAB_001324e4;
          *param_1 = uVar14;
          param_1[1] = (ulong)pbVar18;
          uVar13 = 6;
          param_1[3] = uVar1;
          param_1[4] = (ulong)pbVar17;
          goto LAB_00132564;
        }
      }
    }
    else if ((param_2 & 6) == 2) {
      *param_1 = 0;
      param_1[1] = (ulong)pbVar18;
      param_1[3] = uVar1;
      lVar7 = FUN_0011d4d4(param_4);
      if (lVar7 == 0x434c4e47432b2b01) {
        local_a8 = *(byte **)(param_4 + -0x58);
      }
      uVar13 = 6;
      param_1[4] = (ulong)local_a8;
      goto LAB_00132564;
    }
  }
  else {
    if (((local_98 == (byte *)0x0) || (0xc < (uint)uVar8)) || (local_88 == 0)) goto LAB_00132660;
    local_70 = local_98 + *(long *)(&DAT_0010d788 + uVar8 * 8) * uVar14;
    plVar12 = (long *)FUN_001328c8(&local_70,uVar9);
    if (plVar12 == (long *)0x0) {
      if ((param_2 & 5) != 0) {
LAB_0013259c:
        *param_1 = uVar14;
        param_1[1] = (ulong)pbVar18;
        param_1[3] = uVar1;
        lVar7 = FUN_0011d4d4(param_4);
        if (lVar7 == 0x434c4e47432b2b01) {
          local_a8 = *(byte **)(param_4 + -0x58);
        }
        uVar13 = 6;
        param_1[4] = (ulong)local_a8;
        goto LAB_00132564;
      }
      if ((param_2 >> 3 & 1) == 0) goto LAB_00132660;
    }
    else if ((param_3 & 1) != 0) {
      lVar7 = FUN_0011d4d4(param_4);
      local_70 = local_a8;
      if (lVar7 == 0x434c4e47432b2b01) {
        local_70 = *(byte **)(param_4 + -0x58);
      }
      if ((local_70 == (byte *)0x0) || (*(long *)(param_4 + -0x50) == 0)) {
        FUN_0011d6a4(param_4);
        FUN_0011dce0(*(undefined8 *)(param_4 + -0x38));
LAB_001326a0:
        FUN_0011d6a4(param_4);
        FUN_0011dce0(*(undefined8 *)(param_4 + -0x38));
LAB_001326ac:
        FUN_0011d6a4(param_4);
                    /* WARNING: Subroutine does not return */
        FUN_0011dc6c();
      }
      uVar16 = (**(code **)(*plVar12 + 0x20))(plVar12,*(long *)(param_4 + -0x50),&local_70);
      if ((uVar16 & 1) != 0) {
        if ((param_2 & 1) != 0) {
          *param_1 = uVar14;
          param_1[1] = (ulong)pbVar18;
          *(undefined4 *)(param_1 + 5) = 6;
          param_1[3] = uVar1;
          param_1[4] = (ulong)local_70;
          goto LAB_00132568;
        }
LAB_001324e4:
        if ((param_2 >> 3 & 1) == 0) goto LAB_001326a0;
      }
    }
  }
  uVar16 = 0;
  uVar14 = 0;
  pbVar17 = pbVar19;
  do {
    bVar2 = *pbVar17;
    uVar10 = uVar16 & 0x3f;
    uVar16 = uVar16 + 7;
    uVar14 = ((ulong)bVar2 & 0x7f) << uVar10 | uVar14;
    pbVar17 = pbVar17 + 1;
  } while ((char)bVar2 < '\0');
  uVar10 = -1L << (uVar16 & 0x3f);
  if ((uVar16 < 0x40 & bVar2 >> 6) == 0) {
    uVar10 = 0;
  }
  if ((uVar14 | uVar10) == 0) goto LAB_0013255c;
  pbVar18 = pbVar19 + (uVar14 | uVar10);
  goto LAB_0013235c;
LAB_0013255c:
  uVar13 = 8;
LAB_00132564:
  *(undefined4 *)(param_1 + 5) = uVar13;
LAB_00132568:
  if (*(long *)(lVar5 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_001326bc @ 001326bc

void FUN_001326bc(long param_1)

{
  long lVar1;
  byte bVar2;
  char cVar3;
  ulong uVar4;
  ulong uVar5;
  undefined8 uVar6;
  long *plVar7;
  undefined8 *puVar8;
  char *extraout_x9;
  char *pcVar9;
  long unaff_x21;
  undefined *unaff_x23;
  ulong uVar10;
  long lVar11;
  undefined8 uVar12;
  long lVar13;
  byte *pbVar15;
  byte *pbVar14;
  undefined **local_70;
  char *local_68;
  
  if (param_1 == 0) {
    FUN_0011d6a4();
                    /* WARNING: Subroutine does not return */
    FUN_0011dc6c();
  }
  FUN_0011d6a4();
  uVar5 = FUN_0011d4e0(param_1);
  if ((uVar5 & 1) == 0) {
    uVar6 = FUN_0011dccc();
    uVar12 = FUN_0011dc58();
    lVar11 = 0;
  }
  else {
    uVar12 = *(undefined8 *)(param_1 + -0x40);
    uVar6 = *(undefined8 *)(param_1 + -0x38);
    lVar11 = param_1 + -0x60;
    unaff_x21 = (long)*(int *)(param_1 + -0x24);
    unaff_x23 = *(undefined **)(param_1 + -0x18);
  }
                    /* try { // try from 00132728 to 0013272b has its CatchHandler @ 0013272c */
  FUN_0011dcb0(uVar12);
                    /* catch(type#1 @ 00000000) { ... } // from try @ 00132728 with catch @ 0013272c
                        */
  FUN_0011d6a4();
  if ((uVar5 & 1) == 0) {
LAB_00132834:
    FUN_0011d744();
    FUN_0011dce0(uVar6);
  }
  else {
    local_68 = unaff_x23 + 1;
                    /* try { // try from 0013273c to 00132743 has its CatchHandler @ 001328b4 */
    FUN_001328c8(&local_68,*unaff_x23);
    cVar3 = *local_68;
    pcVar9 = local_68;
    if (cVar3 != -1) goto LAB_0013275c;
    do {
      FUN_0011dce0(uVar6);
      pcVar9 = extraout_x9;
LAB_0013275c:
      uVar5 = 0;
      uVar10 = 0;
      pbVar15 = (byte *)(pcVar9 + 1);
      do {
        pbVar14 = pbVar15 + 1;
        bVar2 = *pbVar15;
        uVar4 = uVar5 & 0x3f;
        uVar5 = uVar5 + 7;
        uVar10 = ((ulong)bVar2 & 0x7f) << uVar4 | uVar10;
        pbVar15 = pbVar14;
      } while ((char)bVar2 < '\0');
                    /* try { // try from 00132780 to 00132783 has its CatchHandler @ 001328b0 */
      plVar7 = (long *)FUN_0011d938();
      lVar13 = *plVar7;
    } while (lVar13 == 0);
    lVar1 = lVar13 + 0x60;
                    /* try { // try from 00132794 to 0013279b has its CatchHandler @ 001328ac */
    uVar5 = FUN_0011d4e0(lVar1);
    if (((uVar5 & 1) != 0) && (lVar13 != lVar11)) {
      uVar12 = *(undefined8 *)(lVar13 + 0x10);
                    /* try { // try from 001327b0 to 001327f3 has its CatchHandler @ 001328a8 */
      lVar11 = FUN_0011d4d4(lVar1);
      if (lVar11 == 0x434c4e47432b2b01) {
        lVar11 = *(long *)(lVar13 + 8);
      }
      else {
        lVar11 = lVar13 + 0x80;
      }
      uVar5 = FUN_00132a3c(unaff_x21,pbVar14 + uVar10,cVar3,uVar12,lVar11,param_1);
      if ((uVar5 & 1) == 0) {
        *(int *)(lVar13 + 0x38) = -*(int *)(lVar13 + 0x38);
        *(int *)(plVar7 + 1) = (int)plVar7[1] + 1;
                    /* try { // try from 00132884 to 00132897 has its CatchHandler @ 001328a8 */
        FUN_0011d744();
        FUN_0011d744();
        FUN_0011d6a4(lVar1);
        uVar12 = FUN_0011d828();
        goto LAB_00132898;
      }
    }
    unaff_x23 = &DAT_0013e640;
    local_70 = &PTR_FUN_0013e650;
                    /* try { // try from 00132808 to 00132827 has its CatchHandler @ 00132898 */
    uVar5 = FUN_00132a3c(unaff_x21,pbVar14 + uVar10,cVar3,&PTR_PTR_0013e668,&local_70,param_1);
    if ((uVar5 & 1) != 0) {
      FUN_001336a4(&local_70);
      goto LAB_00132834;
    }
  }
                    /* try { // try from 00132840 to 00132843 has its CatchHandler @ 00132898 */
  FUN_0011d744();
  puVar8 = (undefined8 *)FUN_0011d504(8);
  *puVar8 = unaff_x23 + 0x10;
                    /* try { // try from 00132854 to 00132867 has its CatchHandler @ 00132898 */
  uVar12 = FUN_0011d57c(puVar8,&PTR_PTR_0013e668,FUN_001336a4);
LAB_00132898:
                    /* catch(type#1 @ 00000000) { ... } // from try @ 00132808 with catch @ 00132898
                       catch(type#1 @ 00000000) { ... } // from try @ 00132840 with catch @ 00132898
                       catch(type#1 @ 00000000) { ... } // from try @ 00132854 with catch @ 00132898
                        */
  FUN_001336a4(&local_70);
                    /* try { // try from 001328b8 to 001328bb has its CatchHandler @ 001328c4 */
  FUN_0011d744();
                    /* WARNING: Subroutine does not return */
  FUN_00134000(uVar12);
}


// ==== FUN_001328c8 @ 001328c8

/* WARNING: Type propagation algorithm not settling */

long * FUN_001328c8(undefined8 *param_1,uint param_2)

{
  uint uVar1;
  byte bVar2;
  uint uVar3;
  long *plVar4;
  ulong uVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  ulong uVar9;
  ulong uVar10;
  
  uVar1 = param_2 & 0xff;
  if (uVar1 == 0xff) {
    return (long *)0x0;
  }
  if (0xc < (param_2 & 0xf)) {
code_r0x00132a38:
                    /* WARNING: Subroutine does not return */
    abort();
  }
  puVar8 = (uint *)*param_1;
  switch(param_2 & 0xf) {
  case 0:
  case 4:
  case 0xc:
    puVar6 = puVar8 + 2;
    plVar4 = *(long **)puVar8;
    break;
  case 1:
    uVar9 = 0;
    plVar4 = (long *)0x0;
    puVar7 = puVar8;
    do {
      puVar6 = (uint *)((long)puVar7 + 1);
      uVar3 = *puVar7;
      uVar5 = uVar9 & 0x3f;
      uVar9 = uVar9 + 7;
      plVar4 = (long *)(((ulong)(byte)uVar3 & 0x7f) << uVar5 | (ulong)plVar4);
      puVar7 = puVar6;
    } while ((char)(byte)uVar3 < '\0');
    break;
  case 2:
    puVar6 = (uint *)((long)puVar8 + 2);
    plVar4 = (long *)(ulong)(ushort)*puVar8;
    break;
  case 3:
    puVar6 = puVar8 + 1;
    plVar4 = (long *)(ulong)*puVar8;
    break;
  default:
    goto code_r0x00132a38;
  case 9:
    uVar9 = 0;
    uVar5 = 0;
    puVar7 = puVar8;
    do {
      puVar6 = (uint *)((long)puVar7 + 1);
      bVar2 = (byte)*puVar7;
      uVar10 = uVar9 & 0x3f;
      uVar9 = uVar9 + 7;
      uVar5 = ((ulong)bVar2 & 0x7f) << uVar10 | uVar5;
      puVar7 = puVar6;
    } while ((char)bVar2 < '\0');
    uVar10 = -1L << (uVar9 & 0x3f);
    if ((uVar9 < 0x40 & bVar2 >> 6) == 0) {
      uVar10 = 0;
    }
    plVar4 = (long *)(uVar5 | uVar10);
    break;
  case 10:
    puVar6 = (uint *)((long)puVar8 + 2);
    plVar4 = (long *)(long)(short)*puVar8;
    break;
  case 0xb:
    puVar6 = puVar8 + 1;
    plVar4 = (long *)(long)(int)*puVar8;
  }
  uVar3 = uVar1 >> 4 & 7;
  if (uVar3 != 0) {
    if (uVar3 != 1) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    if (plVar4 == (long *)0x0) goto LAB_001329cc;
    plVar4 = (long *)((long)plVar4 + (long)puVar8);
  }
  if ((plVar4 != (long *)0x0) && (uVar1 >> 7 != 0)) {
    plVar4 = (long *)*plVar4;
  }
LAB_001329cc:
  *param_1 = puVar6;
  return plVar4;
}


// ==== FUN_00132a3c @ 00132a3c

void FUN_00132a3c(ulong param_1,long param_2,ulong param_3,undefined8 param_4,long param_5,
                 long param_6)

{
  byte bVar1;
  long lVar2;
  long *plVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  byte *pbVar10;
  byte *pbVar9;
  long local_70;
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  if (param_2 == 0) {
LAB_00132b64:
    FUN_0011d6a4(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_0011dc6c();
  }
  uVar8 = param_3 & 0xf;
  uVar5 = 0;
  uVar6 = 0;
  pbVar10 = (byte *)(param_2 + ~param_1);
  do {
    do {
      pbVar9 = pbVar10 + 1;
      bVar1 = *pbVar10;
      uVar7 = uVar5 & 0x3f;
      uVar5 = uVar5 + 7;
      uVar7 = ((ulong)bVar1 & 0x7f) << uVar7 | uVar6;
      uVar6 = uVar7;
      pbVar10 = pbVar9;
    } while ((char)bVar1 < '\0');
    if (uVar7 == 0) break;
    if ((0xc < (uint)uVar8) || ((0x1c1dU >> uVar8 & 1) == 0)) {
      FUN_0011d6a4(param_6);
      FUN_0011dce0(*(undefined8 *)(param_6 + -0x38));
      goto LAB_00132b64;
    }
    local_70 = param_2 + *(long *)(&DAT_0010d788 + uVar8 * 8) * uVar7;
    plVar3 = (long *)FUN_001328c8(&local_70,param_3 & 0xffffffff);
    local_70 = param_5;
    uVar4 = (**(code **)(*plVar3 + 0x20))(plVar3,param_4,&local_70);
    uVar5 = 0;
    uVar6 = 0;
  } while ((uVar4 & 1) == 0);
  if (*(long *)(lVar2 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar7 == 0);
  }
  return;
}


// ==== FUN_00132b74 @ 00132b74

void FUN_00132b74(size_t param_1)

{
  long lVar1;
  int iVar2;
  void *local_30;
  long local_28;
  
  lVar1 = tpidr_el0;
  local_28 = *(long *)(lVar1 + 0x28);
  if (param_1 == 0) {
    param_1 = 1;
  }
  iVar2 = posix_memalign(&local_30,0x10,param_1);
  if (iVar2 != 0) {
    local_30 = (void *)FUN_00132be8(param_1);
  }
  if (*(long *)(lVar1 + 0x28) != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_30);
  }
  return;
}


// ==== FUN_00132be8 @ 00132be8

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ushort * FUN_00132be8(long param_1)

{
  ulong uVar1;
  ushort uVar2;
  ushort *puVar3;
  ushort *puVar4;
  ushort *puVar5;
  
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00143148);
  if (DAT_00143170 == (ushort *)0x0) {
    DAT_00143170 = &DAT_00143180;
    _DAT_00143180 = 0x800080;
  }
  if (DAT_00143170 != &DAT_00143380) {
    uVar1 = (param_1 + 3U >> 2) + 1;
    puVar3 = DAT_00143170;
    puVar5 = (ushort *)0x0;
    do {
      puVar4 = puVar3;
      uVar2 = puVar4[1];
      if (uVar1 < uVar2) {
        uVar2 = uVar2 - (ushort)uVar1;
        puVar3 = puVar4 + (ulong)uVar2 * 2;
        puVar4[1] = uVar2;
        puVar5 = puVar3 + 2;
        *puVar3 = 0;
        puVar3[1] = (ushort)uVar1;
        goto LAB_00132cbc;
      }
      if (uVar1 == uVar2) {
        if (puVar5 == (ushort *)0x0) {
          DAT_00143170 = &DAT_00143180 + (ulong)*puVar4 * 2;
          puVar5 = puVar4 + 2;
          *puVar4 = 0;
        }
        else {
          *puVar5 = *puVar4;
          puVar5 = puVar4 + 2;
          *puVar4 = 0;
        }
        goto LAB_00132cbc;
      }
      puVar3 = &DAT_00143180 + (ulong)*puVar4 * 2;
      puVar5 = puVar4;
    } while ((ulong)*puVar4 != 0x80);
  }
  puVar5 = (ushort *)0x0;
LAB_00132cbc:
                    /* try { // try from 00132cbc to 00132cc7 has its CatchHandler @ 00132cdc */
  pthread_mutex_unlock((pthread_mutex_t *)&DAT_00143148);
  return puVar5;
}


// ==== FUN_00132ce0 @ 00132ce0

ulong FUN_00132ce0(undefined2 *param_1)

{
  ushort uVar1;
  ushort *puVar2;
  uint uVar3;
  ulong extraout_x0;
  int iVar4;
  ushort *puVar5;
  ushort *puVar6;
  ushort *puVar7;
  
  if ((param_1 < &DAT_00143180) || ((undefined2 *)0x14337f < param_1)) {
    free(param_1);
    return extraout_x0;
  }
  puVar7 = param_1 + -2;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00143148);
  if (DAT_00143170 != (ushort *)0x0 && DAT_00143170 != &DAT_00143380) {
    puVar2 = DAT_00143170;
    puVar6 = (ushort *)0x0;
    do {
      puVar5 = puVar2;
      uVar1 = puVar5[1];
      if (puVar5 + (ulong)uVar1 * 2 == puVar7) {
        puVar5[1] = param_1[-1] + uVar1;
        goto LAB_00132df4;
      }
      if (puVar7 + (ulong)(ushort)param_1[-1] * 2 == puVar5) {
        param_1[-1] = param_1[-1] + uVar1;
        if (puVar6 == (ushort *)0x0) {
          DAT_00143170 = puVar7;
          *puVar7 = *puVar5;
        }
        else {
          *puVar6 = (ushort)((int)puVar7 - 0x143180U >> 2);
        }
        goto LAB_00132df4;
      }
      puVar2 = &DAT_00143180 + (ulong)*puVar5 * 2;
      puVar6 = puVar5;
    } while ((ulong)*puVar5 != 0x80);
  }
  iVar4 = (int)DAT_00143170;
  DAT_00143170 = puVar7;
  *puVar7 = (ushort)(iVar4 - 0x143180U >> 2);
LAB_00132df4:
                    /* try { // try from 00132df4 to 00132dff has its CatchHandler @ 00132e10 */
  uVar3 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_00143148);
  return (ulong)uVar3;
}


// ==== FUN_00132e84 @ 00132e84

void FUN_00132e84(long param_1,long param_2,undefined8 *param_3)

{
  long lVar1;
  bool bVar2;
  long *plVar3;
  long *local_88;
  undefined8 uStack_80;
  long local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined7 uStack_50;
  undefined1 local_49;
  undefined7 uStack_48;
  undefined8 uStack_41;
  long local_38;
  
  lVar1 = tpidr_el0;
  local_38 = *(long *)(lVar1 + 0x28);
  if (*(long *)(param_1 + 8) == *(long *)(param_2 + 8)) {
    bVar2 = true;
  }
  else {
    plVar3 = (long *)FUN_00133060(param_2,&PTR_PTR_0013e520,&PTR_PTR_0013e538,0);
    bVar2 = false;
    if (plVar3 != (long *)0x0) {
      uStack_80 = 0;
      uStack_70 = 0xffffffffffffffff;
      uStack_48 = 0;
      uStack_60 = 0;
      local_68 = 0;
      uStack_50 = 0;
      local_49 = 0;
      local_58 = 0;
      uStack_41 = 0x100;
      local_88 = plVar3;
      local_78 = param_1;
      (**(code **)(*plVar3 + 0x38))(plVar3,&local_88,*param_3,1);
      bVar2 = (int)local_58 == 1;
      if (bVar2) {
        *param_3 = local_68;
      }
    }
  }
  if (*(long *)(lVar1 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(bVar2);
  }
  return;
}


// ==== FUN_00133060 @ 00133060

void FUN_00133060(long *param_1,undefined8 param_2,long param_3,undefined8 param_4)

{
  long *plVar1;
  long lVar2;
  long lVar3;
  long local_78;
  long *local_70;
  undefined8 uStack_68;
  undefined8 local_60;
  long local_58;
  long lStack_50;
  undefined8 local_48;
  int iStack_40;
  int iStack_3c;
  int local_38;
  undefined3 uStack_34;
  undefined8 uStack_31;
  long local_28;
  
  lVar2 = tpidr_el0;
  local_28 = *(long *)(lVar2 + 0x28);
  plVar1 = *(long **)(*param_1 + -8);
  lStack_50 = 0;
  local_58 = 0;
  iStack_40 = 0;
  local_48 = 0;
  lVar3 = (long)param_1 + *(long *)(*param_1 + -0x10);
  uStack_31 = 0;
  iStack_3c = 0;
  local_38 = 0;
  uStack_34 = 0;
  local_78 = param_3;
  local_70 = param_1;
  uStack_68 = param_2;
  local_60 = param_4;
  if (plVar1[1] == *(long *)(param_3 + 8)) {
    uStack_31 = 0x100;
    (**(code **)(*plVar1 + 0x28))(plVar1,&local_78,lVar3,lVar3,1,0);
    if ((int)local_48 != 1) {
      lVar3 = 0;
    }
  }
  else {
    (**(code **)(*plVar1 + 0x30))(plVar1,&local_78,lVar3,1,0);
    if (iStack_3c == 1) {
      if ((int)local_48 != 1) {
        lVar3 = 0;
        if (((local_38 != 0) || (local_48._4_4_ != 1)) || (iStack_40 != 1)) goto LAB_0013317c;
      }
      lVar3 = local_58;
    }
    else if (iStack_3c == 0) {
      lVar3 = lStack_50;
      if ((iStack_40 != 1 || local_48._4_4_ != 1) || local_38 != 1) {
        lVar3 = 0;
      }
    }
    else {
      lVar3 = 0;
    }
  }
LAB_0013317c:
  if (*(long *)(lVar2 + 0x28) != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(lVar3);
  }
  return;
}


// ==== FUN_001331a4 @ 001331a4

void FUN_001331a4(long param_1,long *param_2,long param_3,int param_4,uint param_5)

{
  int iVar1;
  long lVar2;
  char *__s1;
  
  lVar2 = param_2[2];
  if ((param_5 & 1) == 0) {
    if (*(long *)(param_1 + 8) != *(long *)(lVar2 + 8)) {
      if (*(long *)(param_1 + 8) != *(long *)(*param_2 + 8)) {
LAB_0013329c:
                    /* WARNING: Could not recover jumptable at 0x001332cc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(**(long **)(param_1 + 0x10) + 0x30))
                  (*(long **)(param_1 + 0x10),param_2,param_3,param_4,param_5 & 1);
        return;
      }
LAB_00133210:
      if ((param_2[4] == param_3) || (param_2[5] == param_3)) {
        if (param_4 == 1) {
          *(undefined4 *)(param_2 + 7) = 1;
          return;
        }
        return;
      }
      *(int *)(param_2 + 7) = param_4;
      if (*(int *)((long)param_2 + 0x44) != 4) {
        *(undefined2 *)((long)param_2 + 0x4c) = 0;
        (**(code **)(**(long **)(param_1 + 0x10) + 0x28))
                  (*(long **)(param_1 + 0x10),param_2,param_3,param_3,1,param_5 & 1);
        if (*(char *)((long)param_2 + 0x4d) == '\0') {
          *(undefined4 *)((long)param_2 + 0x44) = 4;
        }
        else {
          *(undefined4 *)((long)param_2 + 0x44) = 3;
          if (*(char *)((long)param_2 + 0x4c) != '\0') {
            return;
          }
        }
      }
      param_2[5] = param_3;
      *(int *)(param_2 + 8) = (int)param_2[8] + 1;
      if (*(int *)((long)param_2 + 0x3c) != 1) {
        return;
      }
      if ((int)param_2[6] == 2) {
        *(undefined1 *)((long)param_2 + 0x4e) = 1;
        return;
      }
      return;
    }
  }
  else if (param_1 != lVar2) {
    __s1 = *(char **)(param_1 + 8);
    iVar1 = strcmp(__s1,*(char **)(lVar2 + 8));
    if (iVar1 != 0) {
      if ((param_1 != *param_2) && (iVar1 = strcmp(__s1,*(char **)(*param_2 + 8)), iVar1 != 0))
      goto LAB_0013329c;
      goto LAB_00133210;
    }
  }
  if ((param_2[1] == param_3) && (*(int *)((long)param_2 + 0x34) != 1)) {
    *(int *)((long)param_2 + 0x34) = param_4;
  }
  return;
}


// ==== FUN_00133350 @ 00133350

void FUN_00133350(long param_1,long *param_2,long param_3,int param_4,uint param_5)

{
  int iVar1;
  long lVar2;
  char *__s1;
  
  lVar2 = param_2[2];
  if ((param_5 & 1) == 0) {
    if (*(long *)(param_1 + 8) != *(long *)(lVar2 + 8)) {
      if (*(long *)(param_1 + 8) != *(long *)(*param_2 + 8)) {
        return;
      }
LAB_001333dc:
      if ((param_2[4] == param_3) || (param_2[5] == param_3)) {
        if (param_4 == 1) {
          *(undefined4 *)(param_2 + 7) = 1;
          return;
        }
        return;
      }
      *(int *)(param_2 + 7) = param_4;
      param_2[5] = param_3;
      *(int *)(param_2 + 8) = (int)param_2[8] + 1;
      if ((*(int *)((long)param_2 + 0x3c) == 1) && ((int)param_2[6] == 2)) {
        *(undefined1 *)((long)param_2 + 0x4e) = 1;
      }
      *(undefined4 *)((long)param_2 + 0x44) = 4;
      return;
    }
  }
  else if (param_1 != lVar2) {
    __s1 = *(char **)(param_1 + 8);
    iVar1 = strcmp(__s1,*(char **)(lVar2 + 8));
    if (iVar1 != 0) {
      if ((param_1 != *param_2) && (iVar1 = strcmp(__s1,*(char **)(*param_2 + 8)), iVar1 != 0)) {
        return;
      }
      goto LAB_001333dc;
    }
  }
  if ((param_2[1] == param_3) && (*(int *)((long)param_2 + 0x34) != 1)) {
    *(int *)((long)param_2 + 0x34) = param_4;
  }
  return;
}


// ==== FUN_00133478 @ 00133478

void FUN_00133478(long param_1,long param_2,long param_3,long param_4,int param_5,uint param_6)

{
  int iVar1;
  long lVar2;
  
  lVar2 = *(long *)(param_2 + 0x10);
  if ((param_6 & 1) == 0) {
    if (*(long *)(param_1 + 8) != *(long *)(lVar2 + 8)) goto LAB_00133510;
  }
  else if ((param_1 != lVar2) &&
          (iVar1 = strcmp(*(char **)(param_1 + 8),*(char **)(lVar2 + 8)), iVar1 != 0)) {
LAB_00133510:
                    /* WARNING: Could not recover jumptable at 0x00133544. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(long **)(param_1 + 0x10) + 0x28))
              (*(long **)(param_1 + 0x10),param_2,param_3,param_4,param_5,param_6 & 1);
    return;
  }
  *(undefined1 *)(param_2 + 0x4d) = 1;
  if (*(long *)(param_2 + 8) != param_4) {
    return;
  }
  *(undefined1 *)(param_2 + 0x4c) = 1;
  if (*(long *)(param_2 + 0x20) == 0) {
    *(long *)(param_2 + 0x20) = param_3;
    *(int *)(param_2 + 0x30) = param_5;
    *(undefined4 *)(param_2 + 0x3c) = 1;
    if (param_5 != 1) {
      return;
    }
    iVar1 = *(int *)(param_2 + 0x48);
  }
  else {
    if (*(long *)(param_2 + 0x20) != param_3) {
      *(int *)(param_2 + 0x3c) = *(int *)(param_2 + 0x3c) + 1;
      goto LAB_00133590;
    }
    iVar1 = *(int *)(param_2 + 0x30);
    if (*(int *)(param_2 + 0x30) == 2) {
      *(int *)(param_2 + 0x30) = param_5;
      iVar1 = param_5;
    }
    if (*(int *)(param_2 + 0x48) != 1) {
      return;
    }
  }
  if (iVar1 != 1) {
    return;
  }
LAB_00133590:
  *(undefined1 *)(param_2 + 0x4e) = 1;
  return;
}


// ==== FUN_001336a4 @ 001336a4

void FUN_001336a4(void)

{
  return;
}


// ==== free @ 001336ac

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== FUN_001336b4 @ 001336b4

char * FUN_001336b4(void)

{
  return "std::bad_exception";
}


// ==== FUN_001336c4 @ 001336c4

void FUN_001336c4(undefined8 *param_1)

{
  *param_1 = &PTR_FUN_0013e618;
  return;
}


// ==== free @ 001336dc

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== FUN_001336e4 @ 001336e4

char * FUN_001336e4(void)

{
  return "std::bad_alloc";
}


// ==== FUN_001336f4 @ 001336f4

void FUN_001336f4(undefined8 *param_1)

{
  int iVar1;
  long lVar2;
  
  lVar2 = param_1[1];
  *param_1 = &PTR_FUN_0013e6a8;
  iVar1 = FUN_00133d40(0xffffffff,lVar2 + -8);
  if (iVar1 + -1 < 0) {
    free((void *)(lVar2 + -0x18));
  }
  FUN_001336a4(param_1);
  return;
}


// ==== FUN_001337b8 @ 001337b8

void FUN_001337b8(undefined8 *param_1)

{
  int iVar1;
  long lVar2;
  
  lVar2 = param_1[1];
  *param_1 = &PTR_FUN_0013e6d0;
  iVar1 = FUN_00133d40(0xffffffff,lVar2 + -8);
  if (iVar1 + -1 < 0) {
    free((void *)(lVar2 + -0x18));
  }
  FUN_001336a4(param_1);
  return;
}


// ==== FUN_00133810 @ 00133810

void FUN_00133810(undefined8 *param_1)

{
  int iVar1;
  long lVar2;
  
  lVar2 = param_1[1];
  *param_1 = &PTR_FUN_0013e6d0;
  iVar1 = FUN_00133d40(0xffffffff,lVar2 + -8);
  if (iVar1 + -1 < 0) {
    free((void *)(lVar2 + -0x18));
  }
  FUN_001336a4(param_1);
  free(param_1);
  return;
}


// ==== FUN_00133870 @ 00133870

undefined8 FUN_00133870(long param_1)

{
  return *(undefined8 *)(param_1 + 8);
}


// ==== FUN_0013387c @ 0013387c

void FUN_0013387c(undefined8 *param_1)

{
  int iVar1;
  long lVar2;
  
  lVar2 = param_1[1];
  *param_1 = &PTR_FUN_0013e6a8;
  iVar1 = FUN_00133d40(0xffffffff,lVar2 + -8);
  if (iVar1 + -1 < 0) {
    free((void *)(lVar2 + -0x18));
  }
  FUN_001336a4(param_1);
  free(param_1);
  return;
}


// ==== FUN_001338dc @ 001338dc

void FUN_001338dc(undefined8 *param_1)

{
  int iVar1;
  long lVar2;
  
  lVar2 = param_1[1];
  *param_1 = &PTR_FUN_0013e6a8;
  iVar1 = FUN_00133d40(0xffffffff,lVar2 + -8);
  if (iVar1 + -1 < 0) {
    free((void *)(lVar2 + -0x18));
  }
  FUN_001336a4(param_1);
  free(param_1);
  return;
}


// ==== FUN_0013393c @ 0013393c

void FUN_0013393c(void)

{
  return;
}


// ==== FUN_00133944 @ 00133944

void * FUN_00133944(size_t *param_1)

{
  pthread_key_t __key;
  undefined8 *__ptr;
  void *pvVar1;
  void *__s;
  ulong uVar2;
  size_t __n;
  size_t sVar3;
  long lVar4;
  
  sVar3 = param_1[2];
  if (sVar3 == 0) {
    pthread_once((pthread_once_t *)&DAT_00143388,FUN_00133b48);
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00143398);
    sVar3 = param_1[2];
    if (sVar3 == 0) {
      sVar3 = DAT_00143390 + 1;
      DAT_00143390 = sVar3;
      param_1[2] = sVar3;
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00143398);
    __ptr = pthread_getspecific(DAT_00143384);
    if (__ptr == (undefined8 *)0x0) goto LAB_00133a24;
LAB_00133978:
    uVar2 = __ptr[1];
    if (sVar3 <= uVar2) goto LAB_00133a6c;
    lVar4 = (sVar3 + 0x11 & 0xfffffffffffffff0) - 2;
    __ptr = realloc(__ptr,lVar4 * 8 + 0x10);
    if (__ptr == (undefined8 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    memset(__ptr + uVar2 + 2,0,(lVar4 - uVar2) * 8);
  }
  else {
    __ptr = pthread_getspecific(DAT_00143384);
    if (__ptr != (undefined8 *)0x0) goto LAB_00133978;
LAB_00133a24:
    lVar4 = (sVar3 + 0x11 & 0xfffffffffffffff0) - 2;
    __ptr = malloc(lVar4 * 8 + 0x10);
    if (__ptr == (undefined8 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    memset(__ptr + 2,0,lVar4 * 8);
    *__ptr = 1;
  }
  __key = DAT_00143384;
  __ptr[1] = lVar4;
  pthread_setspecific(__key,__ptr);
LAB_00133a6c:
  __s = (void *)__ptr[sVar3 + 1];
  if (__s == (void *)0x0) {
    uVar2 = param_1[1];
    if (uVar2 < 9) {
      uVar2 = 8;
    }
    if ((uVar2 & uVar2 - 1) != 0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    __n = *param_1;
    pvVar1 = malloc(uVar2 + 7 + __n);
    if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    __s = (void *)((long)pvVar1 + uVar2 + 7 & -uVar2);
    *(void **)((long)__s + -8) = pvVar1;
    if ((void *)param_1[3] == (void *)0x0) {
      memset(__s,0,__n);
    }
    else {
      memcpy(__s,(void *)param_1[3],__n);
    }
    __ptr[sVar3 + 1] = __s;
  }
  return __s;
}


// ==== FUN_00133b10 @ 00133b10

ulong FUN_00133b10(ulong param_1)

{
  uint uVar1;
  
  if ((char)DAT_00143380 == '\x01') {
    uVar1 = pthread_key_delete(DAT_00143384);
    param_1 = (ulong)uVar1;
    DAT_00143380._0_1_ = '\0';
  }
  return param_1;
}


// ==== FUN_00133b48 @ 00133b48

void FUN_00133b48(void)

{
  int iVar1;
  
  iVar1 = pthread_key_create(&DAT_00143384,FUN_00133b84);
  if (iVar1 != 0) {
                    /* WARNING: Subroutine does not return */
    abort();
  }
  DAT_00143380._0_1_ = 1;
  return;
}


// ==== FUN_00133b84 @ 00133b84

ulong FUN_00133b84(long *param_1)

{
  uint uVar1;
  ulong extraout_x0;
  ulong uVar2;
  ulong uVar3;
  
  if (*param_1 != 0) {
    *param_1 = *param_1 + -1;
    uVar1 = pthread_setspecific(DAT_00143384,param_1);
    return (ulong)uVar1;
  }
  uVar2 = param_1[1];
  if (uVar2 != 0) {
    uVar3 = 0;
    do {
      if (param_1[uVar3 + 2] != 0) {
        free(*(void **)(param_1[uVar3 + 2] + -8));
        uVar2 = param_1[1];
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar2);
  }
  free(param_1);
  return extraout_x0;
}


// ==== FUN_00133c0c @ 00133c0c

void FUN_00133c0c(ulong param_1,ulong param_2)

{
  ulong uVar1;
  uint uVar2;
  uint uVar3;
  ulong uVar4;
  
  if (DAT_001433c0 == 0) {
    DAT_001433c0 = ctr_el0;
    uVar2 = (uint)DAT_001433c0;
  }
  else {
    uVar2 = (uint)DAT_001433c0;
  }
  uVar3 = (uint)DAT_001433c0;
  if ((uVar2 >> 0x1c & 1) == 0) {
    uVar4 = (ulong)(uint)(4 << (ulong)(uVar3 >> 0x10 & 0xf));
    for (uVar1 = -uVar4 & param_1; uVar1 < param_2; uVar1 = uVar1 + uVar4) {
      DC_CVAU(uVar1);
    }
  }
  DataSynchronizationBarrier(2,3,0);
  if ((uVar3 >> 0x1d & 1) == 0) {
    uVar1 = (ulong)(uint)(4 << (ulong)(uVar3 & 0xf));
    for (param_1 = -uVar1 & param_1; param_1 < param_2; param_1 = param_1 + uVar1) {
      IC_IVAU(param_1);
    }
    DataSynchronizationBarrier(2,3,0);
  }
  InstructionSynchronizationBarrier();
  return;
}


// ==== _INIT_1 @ 00133ca0

void _INIT_1(void)

{
  uint uVar1;
  int iVar2;
  undefined8 uVar3;
  uint uVar4;
  char acStack_6c [92];
  
  uVar3 = getauxval(0x10);
  if (((uint)uVar3 >> 8 & 1) == 0) {
    DAT_001433c8 = 0;
    return;
  }
  iVar2 = __system_property_get("ro.arch",acStack_6c);
  uVar1 = (uint)((ulong)uVar3 >> 8);
  if (iVar2 < 1) {
    uVar4 = uVar1 & 1;
  }
  else {
    iVar2 = strncmp(acStack_6c,"exynos9810",10);
    uVar4 = 0;
    if (iVar2 != 0) {
      uVar4 = uVar1 & 1;
    }
  }
  DAT_001433c8 = uVar4 != 0;
  return;
}


// ==== FUN_00133d40 @ 00133d40

int FUN_00133d40(int param_1,int *param_2)

{
  char cVar1;
  bool bVar2;
  int iVar3;
  
  if (DAT_001433c8 != '\0') {
    LOAcquire();
    iVar3 = *param_2;
    *param_2 = iVar3 + param_1;
    LORelease();
    return iVar3;
  }
  do {
    iVar3 = *param_2;
    cVar1 = '\x01';
    bVar2 = (bool)ExclusiveMonitorPass(param_2,0x10);
    if (bVar2) {
      *param_2 = iVar3 + param_1;
      cVar1 = ExclusiveMonitorsStatus();
    }
  } while (cVar1 != '\0');
  return iVar3;
}


// ==== FUN_00133d70 @ 00133d70

long FUN_00133d70(long param_1,long *param_2)

{
  char cVar1;
  bool bVar2;
  long lVar3;
  
  if (DAT_001433c8 != '\0') {
    lVar3 = *param_2;
    *param_2 = lVar3 + param_1;
    return lVar3;
  }
  do {
    lVar3 = *param_2;
    cVar1 = '\x01';
    bVar2 = (bool)ExclusiveMonitorPass(param_2,0x10);
    if (bVar2) {
      *param_2 = lVar3 + param_1;
      cVar1 = ExclusiveMonitorsStatus();
    }
  } while (cVar1 != '\0');
  return lVar3;
}


// ==== FUN_00133da0 @ 00133da0

long FUN_00133da0(long param_1,long *param_2)

{
  char cVar1;
  bool bVar2;
  long lVar3;
  
  if (DAT_001433c8 != '\0') {
    LOAcquire();
    lVar3 = *param_2;
    *param_2 = lVar3 + param_1;
    LORelease();
    return lVar3;
  }
  do {
    lVar3 = *param_2;
    cVar1 = '\x01';
    bVar2 = (bool)ExclusiveMonitorPass(param_2,0x10);
    if (bVar2) {
      *param_2 = lVar3 + param_1;
      cVar1 = ExclusiveMonitorsStatus();
    }
  } while (cVar1 != '\0');
  return lVar3;
}


// ==== FUN_00133dd0 @ 00133dd0

undefined8 FUN_00133dd0(undefined8 *param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_4f0 [624];
  undefined1 auStack_280 [528];
  undefined8 local_70;
  undefined1 auStack_68 [24];
  code *local_50;
  
  FUN_00137b98(auStack_280);
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00134248(auStack_4f0,auStack_280);
  iVar1 = FUN_0013445c(auStack_4f0);
  while( true ) {
    if (iVar1 == 0) {
      return 5;
    }
    if ((iVar1 < 0) || (iVar1 = FUN_00134480(auStack_4f0,auStack_68), iVar1 != 0)) break;
    if ((local_50 != (code *)0x0) &&
       (iVar1 = (*local_50)(1,1,*param_1,param_1,auStack_4f0), iVar1 != 8)) {
      if (iVar1 == 6) {
        FUN_001342f4(auStack_4f0,0xfffffffe,&local_70);
        param_1[3] = local_70;
        uVar2 = FUN_00133ec8(auStack_280,auStack_4f0,param_1);
        return uVar2;
      }
      return 3;
    }
    iVar1 = FUN_0013445c(auStack_4f0);
  }
  return 3;
}


// ==== FUN_00133ec8 @ 00133ec8

undefined8 FUN_00133ec8(undefined8 param_1,undefined8 param_2,undefined8 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 auStack_80 [24];
  code *local_68;
  long local_38;
  
  FUN_00134248(param_2,param_1);
  iVar1 = FUN_0013445c(param_2);
  while( true ) {
    if (iVar1 == 0) {
      return 5;
    }
    if (iVar1 < 0) break;
    FUN_001342f4(param_2,0xfffffffe,&local_38);
    iVar1 = FUN_00134480(param_2,auStack_80);
    if (iVar1 != 0) {
      return 2;
    }
    if (local_68 != (code *)0x0) {
      uVar2 = 6;
      if (local_38 != param_3[3]) {
        uVar2 = 2;
      }
      iVar1 = (*local_68)(1,uVar2,*param_3,param_3,param_2);
      if (iVar1 != 8) {
        if (iVar1 == 7) {
          FUN_001344c0(param_2);
          return 2;
        }
        return 2;
      }
      if (local_38 == param_3[3]) {
        fprintf((FILE *)0x144348,"libunwind: %s - %s\n","unwind_phase2",
                "during phase1 personality function said it would stop here, but now in phase2 it did not stop here"
               );
        fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
        abort();
      }
    }
    iVar1 = FUN_0013445c(param_2);
  }
  return 2;
}


// ==== FUN_00134000 @ 00134000

void FUN_00134000(long param_1)

{
  undefined1 auStack_4a0 [624];
  undefined1 auStack_230 [528];
  
  FUN_00137b98(auStack_230);
  if (*(long *)(param_1 + 0x10) == 0) {
    FUN_00133ec8(auStack_230,auStack_4a0,param_1);
  }
  else {
    FUN_00134088(auStack_230,auStack_4a0,param_1,*(long *)(param_1 + 0x10),
                 *(undefined8 *)(param_1 + 0x18));
  }
  fprintf((FILE *)0x144348,"libunwind: %s - %s\n","_Unwind_Resume","_Unwind_Resume() can\'t return")
  ;
  fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_00134088 @ 00134088

void FUN_00134088(undefined8 param_1,undefined8 param_2,undefined8 *param_3,code *param_4,
                 undefined8 param_5)

{
  int iVar1;
  undefined1 auStack_78 [24];
  code *local_60;
  
  FUN_00134248(param_2,param_1);
  iVar1 = FUN_0013445c(param_2);
  while( true ) {
    if (iVar1 < 1) {
      (*param_4)(1,0x1a,*param_3,param_3,param_2,param_5);
      return;
    }
    iVar1 = FUN_00134480(param_2,auStack_78);
    if (iVar1 != 0) break;
    iVar1 = (*param_4)(1,10,*param_3,param_3,param_2,param_5);
    if (iVar1 != 0) {
      return;
    }
    if ((local_60 != (code *)0x0) &&
       (iVar1 = (*local_60)(1,10,*param_3,param_3,param_2), iVar1 != 8)) {
      if (iVar1 != 7) {
        return;
      }
      FUN_001344c0(param_2);
    }
    iVar1 = FUN_0013445c(param_2);
  }
  return;
}


// ==== FUN_0013417c @ 0013417c

undefined8 FUN_0013417c(undefined8 param_1)

{
  int iVar1;
  undefined1 auStack_58 [16];
  undefined8 local_48;
  
  iVar1 = FUN_00134480(param_1,auStack_58);
  if (iVar1 != 0) {
    local_48 = 0;
  }
  return local_48;
}


// ==== FUN_001341b0 @ 001341b0

undefined8 FUN_001341b0(undefined8 param_1)

{
  int iVar1;
  undefined8 local_58 [9];
  
  iVar1 = FUN_00134480(param_1,local_58);
  if (iVar1 != 0) {
    local_58[0] = 0;
  }
  return local_58[0];
}


// ==== FUN_001341e4 @ 001341e4

void FUN_001341e4(long param_1)

{
  if (*(code **)(param_1 + 8) == (code *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x001341f8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 8))(1,param_1);
  return;
}


// ==== thunk_FUN_00134370 @ 00134200

void thunk_FUN_00134370(void)

{
  FUN_00134370();
  return;
}


// ==== FUN_00134208 @ 00134208

undefined8 FUN_00134208(undefined8 param_1)

{
  undefined8 local_18;
  
  FUN_001342f4(param_1,0xffffffff,&local_18);
  return local_18;
}


// ==== FUN_00134238 @ 00134238

void FUN_00134238(undefined8 param_1,undefined8 param_2)

{
  FUN_00134370(param_1,0xffffffff,param_2);
  return;
}


// ==== FUN_00134248 @ 00134248

undefined8 FUN_00134248(undefined8 *param_1,void *param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  
  *param_1 = &PTR_LAB_0013e7b8;
  param_1[1] = &DAT_001433c9;
  memcpy(param_1 + 2,param_2,0x110);
  uVar3 = *(undefined8 *)((long)param_2 + 0x130);
  uVar2 = *(undefined8 *)((long)param_2 + 0x148);
  uVar1 = *(undefined8 *)((long)param_2 + 0x140);
  uVar5 = *(undefined8 *)((long)param_2 + 0x118);
  uVar4 = *(undefined8 *)((long)param_2 + 0x110);
  uVar7 = *(undefined8 *)((long)param_2 + 0x128);
  uVar6 = *(undefined8 *)((long)param_2 + 0x120);
  param_1[0x29] = *(undefined8 *)((long)param_2 + 0x138);
  param_1[0x28] = uVar3;
  param_1[0x2b] = uVar2;
  param_1[0x2a] = uVar1;
  param_1[0x25] = uVar5;
  param_1[0x24] = uVar4;
  param_1[0x27] = uVar7;
  param_1[0x26] = uVar6;
  uVar3 = *(undefined8 *)((long)param_2 + 0x170);
  uVar2 = *(undefined8 *)((long)param_2 + 0x188);
  uVar1 = *(undefined8 *)((long)param_2 + 0x180);
  uVar5 = *(undefined8 *)((long)param_2 + 0x158);
  uVar4 = *(undefined8 *)((long)param_2 + 0x150);
  uVar7 = *(undefined8 *)((long)param_2 + 0x168);
  uVar6 = *(undefined8 *)((long)param_2 + 0x160);
  param_1[0x31] = *(undefined8 *)((long)param_2 + 0x178);
  param_1[0x30] = uVar3;
  param_1[0x33] = uVar2;
  param_1[0x32] = uVar1;
  param_1[0x2d] = uVar5;
  param_1[0x2c] = uVar4;
  param_1[0x2f] = uVar7;
  param_1[0x2e] = uVar6;
  uVar3 = *(undefined8 *)((long)param_2 + 0x1b0);
  uVar2 = *(undefined8 *)((long)param_2 + 0x1c8);
  uVar1 = *(undefined8 *)((long)param_2 + 0x1c0);
  uVar5 = *(undefined8 *)((long)param_2 + 0x198);
  uVar4 = *(undefined8 *)((long)param_2 + 400);
  uVar7 = *(undefined8 *)((long)param_2 + 0x1a8);
  uVar6 = *(undefined8 *)((long)param_2 + 0x1a0);
  param_1[0x39] = *(undefined8 *)((long)param_2 + 0x1b8);
  param_1[0x38] = uVar3;
  param_1[0x3b] = uVar2;
  param_1[0x3a] = uVar1;
  param_1[0x35] = uVar5;
  param_1[0x34] = uVar4;
  param_1[0x37] = uVar7;
  param_1[0x36] = uVar6;
  uVar1 = *(undefined8 *)((long)param_2 + 0x1f0);
  uVar3 = *(undefined8 *)((long)param_2 + 0x208);
  uVar2 = *(undefined8 *)((long)param_2 + 0x200);
  uVar7 = *(undefined8 *)((long)param_2 + 0x1d8);
  uVar6 = *(undefined8 *)((long)param_2 + 0x1d0);
  uVar5 = *(undefined8 *)((long)param_2 + 0x1e8);
  uVar4 = *(undefined8 *)((long)param_2 + 0x1e0);
  param_1[0x41] = *(undefined8 *)((long)param_2 + 0x1f8);
  param_1[0x40] = uVar1;
  param_1[0x43] = uVar3;
  param_1[0x42] = uVar2;
  *(undefined8 *)((long)param_1 + 0x263) = 0;
  *(undefined8 *)((long)param_1 + 0x25b) = 0;
  param_1[0x49] = 0;
  param_1[0x48] = 0;
  param_1[0x4b] = 0;
  param_1[0x4a] = 0;
  param_1[0x45] = 0;
  param_1[0x44] = 0;
  param_1[0x47] = 0;
  param_1[0x46] = 0;
  param_1[0x3d] = uVar7;
  param_1[0x3c] = uVar6;
  param_1[0x3f] = uVar5;
  param_1[0x3e] = uVar4;
  FUN_00134d54(param_1,0);
  return 0;
}


// ==== FUN_001342f4 @ 001342f4

undefined8 FUN_001342f4(long *param_1,undefined4 param_2,undefined8 *param_3)

{
  ulong uVar1;
  undefined8 uVar2;
  
  uVar1 = (**(code **)(*param_1 + 0x10))();
  if ((uVar1 & 1) == 0) {
    return 0xffffe672;
  }
  uVar2 = (**(code **)(*param_1 + 0x18))(param_1,param_2);
  *param_3 = uVar2;
  return 0;
}


// ==== FUN_00134370 @ 00134370

undefined8 FUN_00134370(long *param_1,int param_2,undefined8 param_3)

{
  ulong uVar1;
  long lVar2;
  undefined1 auStack_78 [32];
  long local_58;
  
  uVar1 = (**(code **)(*param_1 + 0x10))();
  if ((uVar1 & 1) == 0) {
    return 0xffffe672;
  }
  (**(code **)(*param_1 + 0x20))(param_1,param_2,param_3);
  if (param_2 == -1) {
    (**(code **)(*param_1 + 0x48))(param_1,auStack_78);
    (**(code **)(*param_1 + 0x68))(param_1,0);
    if (local_58 != 0) {
      lVar2 = (**(code **)(*param_1 + 0x18))(param_1,0xfffffffe);
      (**(code **)(*param_1 + 0x20))(param_1,0xfffffffe,local_58 + lVar2);
    }
  }
  return 0;
}


// ==== FUN_0013445c @ 0013445c

void FUN_0013445c(long *param_1)

{
  (**(code **)(*param_1 + 0x40))();
  return;
}


// ==== FUN_00134480 @ 00134480

undefined4 FUN_00134480(long *param_1,long param_2)

{
  undefined4 uVar1;
  
  (**(code **)(*param_1 + 0x48))();
  uVar1 = 0xffffe66b;
  if (*(long *)(param_2 + 8) != 0) {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_001344c0 @ 001344c0

undefined8 FUN_001344c0(long *param_1)

{
  (**(code **)(*param_1 + 0x50))();
  return 0xffffe674;
}


// ==== FUN_001344e8 @ 001344e8

char * FUN_001344e8(undefined8 param_1,uint *param_2,undefined8 *param_3,long *param_4,ulong param_5
                   )

{
  char cVar1;
  uint *puVar2;
  long lVar3;
  long lVar4;
  long lVar5;
  undefined8 uVar6;
  char *pcVar7;
  long lVar8;
  ulong uVar9;
  uint *puVar10;
  uint *local_48;
  
  puVar10 = param_2 + 1;
  uVar9 = (ulong)*param_2;
  if (*param_2 == 0xffffffff) {
    uVar9 = *(ulong *)(param_2 + 1);
    puVar10 = param_2 + 3;
  }
  if (uVar9 == 0) {
    pcVar7 = "FDE has zero length";
  }
  else if (*puVar10 == 0) {
    pcVar7 = "FDE is really a CIE";
  }
  else {
    lVar8 = (long)puVar10 - (ulong)*puVar10;
    if ((param_5 & 1) == 0) {
      pcVar7 = (char *)FUN_00134678(param_1,lVar8,param_4);
      if (pcVar7 != (char *)0x0) {
        return pcVar7;
      }
    }
    else if (*param_4 != lVar8) {
      return "CIE start does not match";
    }
    lVar8 = (long)puVar10 + uVar9;
    local_48 = puVar10 + 1;
    lVar3 = FUN_001362fc(param_1,&local_48,lVar8,(char)param_4[3],0);
    lVar4 = FUN_001362fc(param_1,&local_48,lVar8,*(byte *)(param_4 + 3) & 0xf,0);
    cVar1 = *(char *)((long)param_4 + 0x31);
    param_3[5] = 0;
    if (cVar1 == '\0') {
      puVar10 = local_48;
    }
    else {
      lVar5 = FUN_00136610(&local_48,lVar8);
      puVar2 = local_48;
      puVar10 = (uint *)((long)local_48 + lVar5);
      if ((*(byte *)((long)param_4 + 0x19) != 0xff) &&
         (lVar5 = FUN_001362fc(param_1,&local_48,lVar8,*(byte *)((long)param_4 + 0x19) & 0xf,0),
         lVar5 != 0)) {
        local_48 = puVar2;
        uVar6 = FUN_001362fc(param_1,&local_48,lVar8,*(undefined1 *)((long)param_4 + 0x19),0);
        param_3[5] = uVar6;
      }
    }
    pcVar7 = (char *)0x0;
    param_3[2] = puVar10;
    param_3[3] = lVar3;
    *param_3 = param_2;
    param_3[1] = lVar8 - (long)param_2;
    param_3[4] = lVar4 + lVar3;
  }
  return pcVar7;
}


// ==== FUN_00134678 @ 00134678

char * FUN_00134678(undefined8 param_1,uint *param_2,long *param_3)

{
  byte *pbVar1;
  byte bVar2;
  ulong uVar3;
  uint uVar4;
  undefined1 uVar5;
  undefined4 uVar6;
  char *pcVar7;
  long lVar8;
  uint *puVar9;
  byte *pbVar10;
  byte *pbVar11;
  ulong uVar12;
  ulong uVar13;
  byte *pbVar14;
  byte *pbVar15;
  uint uVar16;
  byte *pbVar17;
  byte *local_38;
  
  *(undefined1 *)((long)param_3 + 0x33) = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  *(undefined2 *)(param_3 + 6) = 0;
  *(undefined4 *)(param_3 + 3) = 0xff00;
  *param_3 = (long)param_2;
  puVar9 = param_2 + 1;
  uVar12 = (ulong)*param_2;
  if (*param_2 == 0xffffffff) {
    uVar12 = *(ulong *)(param_2 + 1);
    puVar9 = param_2 + 3;
    pbVar1 = (byte *)(uVar12 + (long)puVar9);
  }
  else {
    pbVar1 = (byte *)((long)puVar9 + uVar12);
  }
  if (uVar12 == 0) {
    pcVar7 = (char *)0x0;
  }
  else if (*puVar9 == 0) {
    uVar4 = puVar9[1];
    if (((byte)uVar4 & 0xfd) == 1) {
      pbVar17 = (byte *)((long)puVar9 + 5);
      pbVar10 = pbVar17;
      do {
        local_38 = pbVar10 + 1;
        bVar2 = *pbVar10;
        pbVar10 = local_38;
      } while (bVar2 != 0);
      uVar6 = FUN_00136610(&local_38,pbVar1);
      uVar12 = 0;
      uVar13 = 0;
      *(undefined4 *)(param_3 + 5) = uVar6;
      pbVar10 = local_38;
      pbVar14 = local_38;
      do {
        pbVar11 = pbVar10;
        if (pbVar14 == pbVar1) {
          fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                  "truncated sleb128 expression");
          fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
          abort();
        }
        pbVar15 = pbVar14 + 1;
        bVar2 = *pbVar14;
        pbVar10 = pbVar11 + 1;
        uVar3 = uVar12 & 0x3f;
        uVar12 = uVar12 + 7;
        uVar13 = ((ulong)bVar2 & 0x7f) << uVar3 | uVar13;
        pbVar14 = pbVar15;
      } while ((char)bVar2 < '\0');
      uVar16 = (uint)(-1L << (uVar12 & 0x3f));
      if (((int)uVar12 - 7U < 0x39 & bVar2 >> 6) == 0) {
        uVar16 = 0;
      }
      *(uint *)((long)param_3 + 0x2c) = (uint)uVar13 | uVar16;
      if ((byte)uVar4 == 1) {
        local_38 = pbVar11 + 2;
        *(byte *)((long)param_3 + 0x32) = *pbVar15;
        bVar2 = *pbVar17;
      }
      else {
        local_38 = pbVar10;
        uVar5 = FUN_00136610(&local_38,pbVar1);
        *(undefined1 *)((long)param_3 + 0x32) = uVar5;
        bVar2 = *pbVar17;
      }
      if (bVar2 == 0x7a) {
        FUN_00136610(&local_38,pbVar1);
LAB_00134820:
        switch(*pbVar17) {
        case 0x42:
          *(undefined1 *)((long)param_3 + 0x33) = 1;
          break;
        case 0x43:
        case 0x44:
        case 0x45:
        case 0x46:
        case 0x47:
        case 0x48:
        case 0x49:
        case 0x4a:
        case 0x4b:
        case 0x4d:
        case 0x4e:
        case 0x4f:
        case 0x51:
        case 0x54:
        case 0x55:
        case 0x56:
        case 0x57:
        case 0x58:
        case 0x59:
        case 0x5a:
        case 0x5b:
        case 0x5c:
        case 0x5d:
        case 0x5e:
        case 0x5f:
        case 0x60:
        case 0x61:
        case 0x62:
        case 99:
        case 100:
        case 0x65:
        case 0x66:
        case 0x67:
        case 0x68:
        case 0x69:
        case 0x6a:
        case 0x6b:
        case 0x6c:
        case 0x6d:
        case 0x6e:
        case 0x6f:
        case 0x70:
        case 0x71:
        case 0x72:
        case 0x73:
        case 0x74:
        case 0x75:
        case 0x76:
        case 0x77:
        case 0x78:
        case 0x79:
          break;
        case 0x4c:
          pbVar17 = pbVar17 + 1;
          *(byte *)((long)param_3 + 0x19) = *local_38;
          local_38 = local_38 + 1;
          goto LAB_00134820;
        case 0x50:
          bVar2 = *local_38;
          *(byte *)((long)param_3 + 0x1a) = bVar2;
          *(char *)((long)param_3 + 0x1b) = (char)(local_38 + 1) - (char)param_2;
          local_38 = local_38 + 1;
          lVar8 = FUN_001362fc(param_1,&local_38,pbVar1,bVar2,0);
          param_3[4] = lVar8;
          pbVar17 = pbVar17 + 1;
          goto LAB_00134820;
        case 0x52:
          pbVar17 = pbVar17 + 1;
          *(byte *)(param_3 + 3) = *local_38;
          local_38 = local_38 + 1;
          goto LAB_00134820;
        case 0x53:
          *(undefined1 *)(param_3 + 6) = 1;
          pbVar17 = pbVar17 + 1;
          goto LAB_00134820;
        case 0x7a:
          goto code_r0x001348c8;
        default:
          if (*pbVar17 == 0) goto LAB_001348d8;
        }
        pbVar17 = pbVar17 + 1;
        goto LAB_00134820;
      }
LAB_001348d8:
      pcVar7 = (char *)0x0;
      param_3[1] = (long)pbVar1 - *param_3;
      param_3[2] = (long)local_38;
    }
    else {
      pcVar7 = "CIE version is not 1 or 3";
    }
  }
  else {
    pcVar7 = "CIE ID is not zero";
  }
  return pcVar7;
code_r0x001348c8:
  *(undefined1 *)((long)param_3 + 0x31) = 1;
  pbVar17 = pbVar17 + 1;
  goto LAB_00134820;
}


// ==== FUN_00134d54 @ 00134d54

void FUN_00134d54(long *param_1,ulong param_2)

{
  int iVar1;
  long lVar2;
  ulong uVar3;
  int *piVar4;
  undefined *puVar5;
  ulong uVar6;
  undefined1 auStack_6e0 [32];
  long local_6c0;
  long local_6a8;
  undefined4 uStack_6a0;
  long local_690;
  long lStack_688;
  long local_680;
  undefined1 auStack_678 [16];
  long local_668;
  long local_648;
  undefined1 *puStack_640;
  ulong local_638;
  
  *(undefined1 *)((long)param_1 + 0x26a) = 0;
  lVar2 = (**(code **)(*param_1 + 0x18))(param_1,0xffffffff);
  if (lVar2 == 0) {
LAB_00134f4c:
    *(undefined1 *)(param_1 + 0x4d) = 1;
    return;
  }
  local_648 = param_1[1];
  uVar6 = lVar2 - (param_2 & 1);
  puStack_640 = auStack_678;
  local_638 = uVar6;
  iVar1 = dl_iterate_phdr(&LAB_00137498,&local_648);
  if (((iVar1 == 0) || (local_668 == 0)) ||
     (uVar3 = FUN_001371a4(param_1,uVar6,auStack_678,0), (uVar3 & 1) == 0)) {
    pthread_rwlock_rdlock((pthread_rwlock_t *)&DAT_001433cc);
    for (puVar5 = PTR_DAT_00142e48; puVar5 < PTR_DAT_00142e50; puVar5 = puVar5 + 0x20) {
      if ((*(ulong *)(puVar5 + 8) <= uVar6) && (uVar6 < *(ulong *)(puVar5 + 0x10))) {
        lVar2 = *(long *)(puVar5 + 0x18);
        pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_001433cc);
        if ((lVar2 != 0) &&
           (lVar2 = FUN_001344e8(param_1[1],lVar2,&local_6a8,auStack_6e0,0), lVar2 == 0)) {
          memset(&local_648,0,0x618);
          uVar6 = FUN_001354e4(param_1[1],&local_6a8,auStack_6e0,uVar6,4,&local_648);
          if ((uVar6 & 1) != 0) {
            param_1[0x4c] = 0;
            param_1[0x46] = local_680;
            param_1[0x47] = local_6c0;
            param_1[0x48] = local_638 & 0xffffffff;
            *(undefined4 *)(param_1 + 0x4a) = 0x3000000;
            param_1[0x45] = lStack_688;
            param_1[0x44] = local_690;
            param_1[0x49] = 0;
            param_1[0x4b] = local_6a8;
            *(undefined4 *)((long)param_1 + 0x254) = uStack_6a0;
            return;
          }
        }
        goto LAB_00134ee0;
      }
    }
    pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_001433cc);
LAB_00134ee0:
    piVar4 = (int *)(**(code **)(*param_1 + 0x18))(param_1,0xffffffff);
    if ((*piVar4 != -0x2d7fee98) || (piVar4[1] != -0x2bffffff)) goto LAB_00134f4c;
    param_1[0x4c] = 0;
    *(undefined1 *)((long)param_1 + 0x26a) = 1;
    param_1[0x49] = 0;
    param_1[0x48] = 0;
    param_1[0x4b] = 0;
    param_1[0x4a] = 0;
    param_1[0x45] = 0;
    param_1[0x44] = 0;
    param_1[0x47] = 0;
    param_1[0x46] = 0;
  }
  return;
}


// ==== FUN_00134f6c @ 00134f6c

void FUN_00134f6c(undefined8 param_1,undefined4 param_2)

{
  FUN_00137ad8(param_2);
  return;
}


// ==== FUN_00134f78 @ 00134f78

undefined8 FUN_00134f78(long param_1)

{
  long lVar1;
  undefined8 uVar2;
  
  lVar1 = *(long *)(param_1 + 0x108);
  *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(lVar1 + 0x138);
  *(undefined8 *)(param_1 + 0x18) = *(undefined8 *)(lVar1 + 0x140);
  *(undefined8 *)(param_1 + 0x20) = *(undefined8 *)(lVar1 + 0x148);
  *(undefined8 *)(param_1 + 0x28) = *(undefined8 *)(lVar1 + 0x150);
  *(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(lVar1 + 0x158);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(lVar1 + 0x160);
  *(undefined8 *)(param_1 + 0x40) = *(undefined8 *)(lVar1 + 0x168);
  *(undefined8 *)(param_1 + 0x48) = *(undefined8 *)(lVar1 + 0x170);
  *(undefined8 *)(param_1 + 0x50) = *(undefined8 *)(lVar1 + 0x178);
  *(undefined8 *)(param_1 + 0x58) = *(undefined8 *)(lVar1 + 0x180);
  *(undefined8 *)(param_1 + 0x60) = *(undefined8 *)(lVar1 + 0x188);
  *(undefined8 *)(param_1 + 0x68) = *(undefined8 *)(lVar1 + 400);
  *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(lVar1 + 0x198);
  *(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(lVar1 + 0x1a0);
  *(undefined8 *)(param_1 + 0x80) = *(undefined8 *)(lVar1 + 0x1a8);
  *(undefined8 *)(param_1 + 0x88) = *(undefined8 *)(lVar1 + 0x1b0);
  *(undefined8 *)(param_1 + 0x90) = *(undefined8 *)(lVar1 + 0x1b8);
  *(undefined8 *)(param_1 + 0x98) = *(undefined8 *)(lVar1 + 0x1c0);
  *(undefined8 *)(param_1 + 0xa0) = *(undefined8 *)(lVar1 + 0x1c8);
  *(undefined8 *)(param_1 + 0xa8) = *(undefined8 *)(lVar1 + 0x1d0);
  *(undefined8 *)(param_1 + 0xb0) = *(undefined8 *)(lVar1 + 0x1d8);
  *(undefined8 *)(param_1 + 0xb8) = *(undefined8 *)(lVar1 + 0x1e0);
  *(undefined8 *)(param_1 + 0xc0) = *(undefined8 *)(lVar1 + 0x1e8);
  *(undefined8 *)(param_1 + 200) = *(undefined8 *)(lVar1 + 0x1f0);
  *(undefined8 *)(param_1 + 0xd0) = *(undefined8 *)(lVar1 + 0x1f8);
  *(undefined8 *)(param_1 + 0xd8) = *(undefined8 *)(lVar1 + 0x200);
  *(undefined8 *)(param_1 + 0xe0) = *(undefined8 *)(lVar1 + 0x208);
  *(undefined8 *)(param_1 + 0xe8) = *(undefined8 *)(lVar1 + 0x210);
  *(undefined8 *)(param_1 + 0xf0) = *(undefined8 *)(lVar1 + 0x218);
  *(undefined8 *)(param_1 + 0xf8) = *(undefined8 *)(lVar1 + 0x220);
  *(undefined8 *)(param_1 + 0x100) = *(undefined8 *)(lVar1 + 0x228);
  *(undefined8 *)(param_1 + 0x108) = *(undefined8 *)(lVar1 + 0x230);
  uVar2 = *(undefined8 *)(lVar1 + 0x238);
  *(undefined1 *)(param_1 + 0x269) = 1;
  *(undefined8 *)(param_1 + 0x110) = uVar2;
  return 1;
}


// ==== FUN_0013509c @ 0013509c

undefined8
FUN_0013509c(undefined8 param_1,undefined8 param_2,undefined8 param_3,void *param_4,
            undefined1 *param_5)

{
  long lVar1;
  ulong uVar2;
  long lVar3;
  undefined8 *puVar4;
  long *plVar5;
  long lVar6;
  int *piVar7;
  uint uVar8;
  long *plVar9;
  undefined8 uVar10;
  undefined8 auStack_7ffffff8 [268435168];
  long alStack_8f8 [29];
  long local_810;
  long local_808;
  long local_800;
  long local_7f8;
  undefined8 local_7f0;
  undefined8 auStack_7e8 [32];
  undefined1 auStack_6e8 [24];
  int local_6d0 [2];
  long local_6c8 [191];
  undefined1 auStack_d0 [48];
  undefined1 local_a0;
  byte local_9e;
  undefined1 auStack_98 [56];
  
  lVar1 = FUN_001344e8(param_1,param_3,auStack_98,auStack_d0,0);
  if (lVar1 == 0) {
    memset(auStack_6e8,0,0x618);
    uVar2 = FUN_001354e4(param_1,auStack_98,auStack_d0,param_2,4,auStack_6e8);
    if ((uVar2 & 1) != 0) {
      lVar1 = FUN_00136004(param_1,auStack_6e8,param_4);
      memcpy(alStack_8f8,param_4,0x210);
      piVar7 = local_6d0;
      uVar2 = 0;
      lVar6 = 0;
      plVar9 = alStack_8f8;
      local_800 = lVar1;
      do {
        if (*piVar7 == 0) {
          if (uVar2 == local_9e) {
            plVar5 = (long *)((long)param_4 + 0x100);
            switch(local_9e) {
            case 0x1d:
              plVar5 = (long *)((long)param_4 + 0xe8);
              break;
            case 0x1e:
              plVar5 = (long *)((long)param_4 + 0xf0);
              break;
            case 0x1f:
              plVar5 = (long *)((long)param_4 + 0xf8);
              break;
            case 0x20:
              break;
            default:
              if (0x1c < local_9e) {
                fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getRegister",
                        "unsupported arm64 register");
                fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
                abort();
              }
              plVar5 = (long *)((long)param_4 + (ulong)local_9e * 8);
              break;
            case 0x22:
              plVar5 = (long *)((long)param_4 + 0x108);
            }
            lVar6 = *plVar5;
          }
          goto LAB_001351ec;
        }
        uVar8 = (uint)uVar2;
        if ((uVar8 & 0x7fffffe0) == 0x40) {
          uVar10 = 0;
          switch(*piVar7) {
          case 1:
            break;
          case 2:
            uVar10 = *(undefined8 *)(*(long *)(piVar7 + 2) + lVar1);
            break;
          default:
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSavedFloatRegister",
                    "unsupported restore location for float register");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          case 4:
            uVar10 = *(undefined8 *)
                      ((long)param_4 +
                      ((*(long *)(piVar7 + 2) << 0x20) + -0x4000000000 >> 0x1d) + 0x110);
            break;
          case 5:
            puVar4 = (undefined8 *)FUN_001367e0(*(undefined8 *)(piVar7 + 2),param_1,param_4,lVar1);
            uVar10 = *puVar4;
          }
          auStack_7e8[uVar8 - 0x40] = uVar10;
          goto LAB_001351ec;
        }
        if (uVar2 == local_9e) {
          lVar6 = FUN_00136100(param_1,param_4,lVar1,piVar7);
          goto LAB_001351ec;
        }
        if (uVar2 == 0x22) {
          local_7f0 = FUN_00136100(param_1,param_4,lVar1,piVar7);
          goto LAB_001351ec;
        }
        if (0xffffffe0 < uVar8 - 0x40) {
          return 0xffffe672;
        }
        lVar3 = FUN_00136100(param_1,param_4,lVar1,piVar7);
        plVar5 = &local_800;
        switch(uVar8) {
        case 0x1d:
          local_810 = lVar3;
          goto LAB_001351ec;
        case 0x1e:
          local_808 = lVar3;
          goto LAB_001351ec;
        case 0x1f:
          break;
        case 0x20:
          plVar5 = &local_7f8;
          break;
        default:
          plVar5 = plVar9;
          if (0x1c < uVar2) {
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","setRegister",
                    "unsupported arm64 register");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
        }
        *plVar5 = lVar3;
LAB_001351ec:
        uVar2 = uVar2 + 1;
        piVar7 = piVar7 + 4;
        plVar9 = plVar9 + 1;
        if (uVar2 == 0x60) {
          *param_5 = local_a0;
          local_7f8 = lVar6;
          memcpy(param_4,alStack_8f8,0x210);
          return 1;
        }
      } while( true );
    }
  }
  return 0xffffe66e;
}


// ==== FUN_001354e4 @ 001354e4

undefined8
FUN_001354e4(undefined8 param_1,long *param_2,long *param_3,long param_4,int param_5,
            undefined4 *param_6)

{
  byte *pbVar1;
  byte bVar2;
  char cVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined4 uVar6;
  long lVar7;
  char *__ptr;
  size_t __size;
  uint uVar8;
  byte *pbVar9;
  ulong uVar10;
  undefined4 *puVar11;
  ulong uVar12;
  ulong uVar13;
  ulong uVar14;
  ulong uVar15;
  undefined8 *puVar16;
  ulong uVar17;
  ulong *puVar18;
  byte *pbVar19;
  undefined1 auStack_6f0 [12];
  int local_6e4;
  byte **local_6e0;
  undefined8 *puStack_6d8;
  undefined8 local_6d0;
  ulong *local_6c8;
  undefined8 *local_6c0;
  byte *apbStack_6a0 [193];
  ulong local_98;
  long lStack_90;
  undefined8 local_88;
  long lStack_80;
  long local_78;
  long lStack_70;
  ulong uStack_68;
  
  puVar5 = (undefined8 *)auStack_6f0;
  puVar18 = &local_98;
  local_6c0 = (undefined8 *)0x0;
  local_98 = param_3[2];
  lStack_90 = param_3[1] + *param_3;
  local_88 = 0xffffffffffffffff;
  lStack_80 = param_2[2];
  local_6d0 = param_1;
  local_6c8 = &uStack_68;
  local_78 = param_2[1] + *param_2;
  lStack_70 = param_4 - param_2[3];
  local_6e0 = apbStack_6a0 + 0x44;
  puStack_6d8 = (undefined8 *)(param_6 + 0x8e);
  do {
    apbStack_6a0[0xc0] = (byte *)*puVar18;
    pbVar1 = (byte *)puVar18[1];
    uVar14 = puVar18[2];
    if (apbStack_6a0[0xc0] < pbVar1 && uVar14 != 0) {
      uVar15 = 0;
      pbVar19 = apbStack_6a0[0xc0];
      do {
        puVar16 = local_6c0;
        pbVar9 = pbVar19 + 1;
        bVar2 = *pbVar19;
        apbStack_6a0[0xc0] = pbVar9;
        switch((ulong)bVar2) {
        case 0:
          break;
        case 1:
          uVar15 = FUN_001362fc(local_6d0,apbStack_6a0 + 0xc0,pbVar1,(char)param_3[3],0);
          break;
        case 2:
          uVar8 = (uint)pbVar19[1];
          apbStack_6a0[0xc0] = pbVar19 + 2;
          goto LAB_00135610;
        case 3:
          uVar8 = (uint)*(ushort *)(pbVar19 + 1);
          apbStack_6a0[0xc0] = pbVar19 + 3;
          goto LAB_00135610;
        case 4:
          uVar8 = *(uint *)(pbVar19 + 1);
          apbStack_6a0[0xc0] = pbVar19 + 5;
LAB_00135610:
          uVar15 = uVar15 + (int)param_3[5] * uVar8;
          break;
        case 5:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          lVar7 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_offset_extended DWARF unwind, reg too big\n";
            __size = 0x46;
            goto LAB_00135ef8;
          }
          puVar11 = param_6 + uVar17 * 4;
          iVar4 = *(int *)((long)param_3 + 0x2c);
          if (*(char *)(puVar11 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(puVar11 + 7) = '\x01';
          }
          lVar7 = lVar7 * iVar4;
          goto LAB_00135d44;
        case 6:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_restore_extended DWARF unwind, reg too big\n";
LAB_00135e28:
            __size = 0x47;
LAB_00135ef8:
            fwrite(__ptr,__size,1,(FILE *)0x144348);
            return 0;
          }
          cVar3 = *(char *)(param_6 + uVar17 * 4 + 7);
joined_r0x00135d6c:
          if (cVar3 != '\0') {
            pbVar19 = apbStack_6a0[uVar17 * 2];
            *(byte **)(param_6 + uVar17 * 4 + 8) = apbStack_6a0[uVar17 * 2 + 1];
            *(byte **)(param_6 + uVar17 * 4 + 6) = pbVar19;
          }
          break;
        case 7:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_undefined DWARF unwind, reg too big\n";
LAB_00135ee8:
            __size = 0x40;
            goto LAB_00135ef8;
          }
          if (*(char *)(param_6 + uVar17 * 4 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(param_6 + uVar17 * 4 + 7) = '\x01';
          }
          param_6[uVar17 * 4 + 6] = 1;
          break;
        case 8:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_same_value DWARF unwind, reg too big\n";
            __size = 0x41;
            goto LAB_00135ef8;
          }
          if (*(char *)(param_6 + uVar17 * 4 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(param_6 + uVar17 * 4 + 7) = '\x01';
          }
          param_6[uVar17 * 4 + 6] = 0;
          break;
        case 9:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          uVar12 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_register DWARF unwind, reg too big\n";
            __size = 0x3f;
            goto LAB_00135ef8;
          }
          if (0x5f < uVar12) {
            __ptr = "libunwind: malformed DW_CFA_register DWARF unwind, reg2 too big\n";
            goto LAB_00135ee8;
          }
          if (*(char *)(param_6 + uVar17 * 4 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(param_6 + uVar17 * 4 + 7) = '\x01';
          }
          *(ulong *)(param_6 + uVar17 * 4 + 8) = uVar12;
          param_6[uVar17 * 4 + 6] = 4;
          break;
        case 10:
          puVar16 = (undefined8 *)((long)puVar5 + -0x620);
          *puVar16 = local_6c0;
          memcpy((undefined1 *)((long)puVar5 + -0x618),param_6,0x618);
          local_6c0 = puVar16;
          puVar5 = puVar16;
          break;
        case 0xb:
          if (local_6c0 == (undefined8 *)0x0) {
            return 0;
          }
          memcpy(param_6,local_6c0 + 1,0x618);
          local_6c0 = (undefined8 *)*puVar16;
          break;
        case 0xc:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          uVar6 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_def_cfa DWARF unwind, reg too big\n";
            __size = 0x3e;
            goto LAB_00135ef8;
          }
          *param_6 = (int)uVar17;
          param_6[1] = uVar6;
          break;
        case 0xd:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_def_cfa_register DWARF unwind, reg too big\n";
            goto LAB_00135e28;
          }
          *param_6 = (int)uVar17;
          break;
        case 0xe:
          uVar6 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          param_6[1] = uVar6;
          break;
        case 0xf:
          *param_6 = 0;
          *(byte **)(param_6 + 2) = pbVar9;
          goto LAB_00135bf4;
        case 0x10:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_expression DWARF unwind, reg too big\n";
            __size = 0x41;
            goto LAB_00135ef8;
          }
          puVar11 = param_6 + uVar17 * 4;
          if (*(char *)(puVar11 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(puVar11 + 7) = '\x01';
          }
          uVar6 = 5;
          goto LAB_00135be8;
        case 0x11:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_offset_extended_sf DWARF unwind, reg too big\n";
            __size = 0x49;
            goto LAB_00135ef8;
          }
          uVar12 = 0;
          uVar10 = 0;
          pbVar19 = apbStack_6a0[0xc0];
          pbVar9 = apbStack_6a0[0xc0];
          do {
            if (pbVar9 == pbVar1) {
              fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
              abort();
            }
            bVar2 = *pbVar9;
            pbVar19 = pbVar19 + 1;
            uVar13 = uVar12 & 0x3f;
            uVar12 = uVar12 + 7;
            uVar10 = ((ulong)bVar2 & 0x7f) << uVar13 | uVar10;
            pbVar9 = pbVar9 + 1;
          } while ((char)bVar2 < '\0');
          puVar11 = param_6 + uVar17 * 4;
          uVar13 = -1L << (uVar12 & 0x3f);
          if (((int)uVar12 - 7U < 0x39 & bVar2 >> 6) == 0) {
            uVar13 = 0;
          }
          iVar4 = *(int *)((long)param_3 + 0x2c);
          apbStack_6a0[0xc0] = pbVar19;
          if (*(char *)(puVar11 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(puVar11 + 7) = '\x01';
          }
          uVar10 = uVar10 | uVar13;
          uVar6 = 2;
          goto LAB_00135b8c;
        case 0x12:
          uVar12 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          uVar17 = 0;
          uVar10 = 0;
          pbVar19 = apbStack_6a0[0xc0];
          pbVar9 = apbStack_6a0[0xc0];
          do {
            if (pbVar9 == pbVar1) {
              fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
              abort();
            }
            bVar2 = *pbVar9;
            pbVar19 = pbVar19 + 1;
            uVar13 = uVar17 & 0x3f;
            uVar17 = uVar17 + 7;
            uVar10 = ((ulong)bVar2 & 0x7f) << uVar13 | uVar10;
            pbVar9 = pbVar9 + 1;
          } while ((char)bVar2 < '\0');
          apbStack_6a0[0xc0] = pbVar19;
          if (0x5f < uVar12) {
            __ptr = "libunwind: malformed DW_CFA_def_cfa_sf DWARF unwind, reg too big\n";
            __size = 0x41;
            goto LAB_00135ef8;
          }
          iVar4 = *(int *)((long)param_3 + 0x2c);
          uVar8 = (uint)(-1L << (uVar17 & 0x3f));
          if (((int)uVar17 - 7U < 0x39 & bVar2 >> 6) == 0) {
            uVar8 = 0;
          }
          *param_6 = (int)uVar12;
          param_6[1] = iVar4 * ((uint)uVar10 | uVar8);
          break;
        case 0x13:
          uVar17 = 0;
          uVar12 = 0;
          pbVar19 = pbVar9;
          do {
            if (pbVar19 == pbVar1) {
              fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
              abort();
            }
            bVar2 = *pbVar19;
            pbVar9 = pbVar9 + 1;
            uVar10 = uVar17 & 0x3f;
            uVar17 = uVar17 + 7;
            uVar12 = ((ulong)bVar2 & 0x7f) << uVar10 | uVar12;
            pbVar19 = pbVar19 + 1;
          } while ((char)bVar2 < '\0');
          apbStack_6a0[0xc0] = pbVar9;
          uVar8 = (uint)(-1L << (uVar17 & 0x3f));
          if (((int)uVar17 - 7U < 0x39 & bVar2 >> 6) == 0) {
            uVar8 = 0;
          }
          param_6[1] = *(int *)((long)param_3 + 0x2c) * ((uint)uVar12 | uVar8);
          break;
        case 0x14:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            fprintf((FILE *)0x144348,
                    "libunwind: malformed DW_CFA_val_offset DWARF unwind, reg (%lu) out of range\n\n"
                    ,uVar17);
            return 0;
          }
          lVar7 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          puVar11 = param_6 + uVar17 * 4;
          iVar4 = *(int *)((long)param_3 + 0x2c);
          if (*(char *)(puVar11 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(puVar11 + 7) = '\x01';
          }
          lVar7 = lVar7 * iVar4;
          uVar6 = 3;
          goto LAB_00135d48;
        case 0x15:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_val_offset_sf DWARF unwind, reg too big\n";
            __size = 0x44;
            goto LAB_00135ef8;
          }
          uVar12 = 0;
          uVar10 = 0;
          pbVar19 = apbStack_6a0[0xc0];
          pbVar9 = apbStack_6a0[0xc0];
          do {
            if (pbVar9 == pbVar1) {
              fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                      "truncated sleb128 expression");
              fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
              abort();
            }
            bVar2 = *pbVar9;
            pbVar19 = pbVar19 + 1;
            uVar13 = uVar12 & 0x3f;
            uVar12 = uVar12 + 7;
            uVar10 = ((ulong)bVar2 & 0x7f) << uVar13 | uVar10;
            pbVar9 = pbVar9 + 1;
          } while ((char)bVar2 < '\0');
          puVar11 = param_6 + uVar17 * 4;
          uVar13 = -1L << (uVar12 & 0x3f);
          if (((int)uVar12 - 7U < 0x39 & bVar2 >> 6) == 0) {
            uVar13 = 0;
          }
          iVar4 = *(int *)((long)param_3 + 0x2c);
          apbStack_6a0[0xc0] = pbVar19;
          if (*(char *)(puVar11 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(puVar11 + 7) = '\x01';
          }
          uVar10 = uVar10 | uVar13;
          uVar6 = 3;
LAB_00135b8c:
          puVar11[6] = uVar6;
          *(ulong *)(puVar11 + 8) = uVar10 * (long)iVar4;
          break;
        case 0x16:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = "libunwind: malformed DW_CFA_val_expression DWARF unwind, reg too big\n";
            __size = 0x45;
            goto LAB_00135ef8;
          }
          puVar11 = param_6 + uVar17 * 4;
          if (*(char *)(puVar11 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(puVar11 + 7) = '\x01';
          }
          uVar6 = 6;
LAB_00135be8:
          puVar11[6] = uVar6;
          *(byte **)(puVar11 + 8) = apbStack_6a0[0xc0];
LAB_00135bf4:
          lVar7 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          apbStack_6a0[0xc0] = apbStack_6a0[0xc0] + lVar7;
          break;
        default:
          uVar17 = (ulong)bVar2 & 0x3f;
          bVar2 = bVar2 & 0xc0;
          if (bVar2 == 0x40) {
            uVar15 = uVar15 + (uint)((int)param_3[5] * (int)uVar17);
          }
          else {
            if (bVar2 == 0xc0) {
              cVar3 = *(char *)(param_6 + uVar17 * 4 + 7);
              goto joined_r0x00135d6c;
            }
            if (bVar2 != 0x80) {
              return 0;
            }
            local_6e4 = param_5;
            lVar7 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
            iVar4 = *(int *)((long)param_3 + 0x2c);
            if (*(char *)(param_6 + uVar17 * 4 + 7) == '\0') {
              pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
              apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
              apbStack_6a0[uVar17 * 2] = pbVar19;
              *(char *)(param_6 + uVar17 * 4 + 7) = '\x01';
            }
            param_6[uVar17 * 4 + 6] = 2;
            *(long *)(param_6 + uVar17 * 4 + 8) = lVar7 * iVar4;
            param_5 = local_6e4;
          }
          break;
        case 0x2d:
          if (param_5 == 4) {
            if (*(char *)(param_6 + 0x8f) == '\0') {
              pbVar19 = (byte *)*puStack_6d8;
              local_6e0[1] = (byte *)puStack_6d8[1];
              *local_6e0 = pbVar19;
              *(undefined1 *)(param_6 + 0x8f) = 1;
            }
            *(ulong *)(param_6 + 0x90) = *(ulong *)(param_6 + 0x90) ^ 1;
          }
          break;
        case 0x2e:
          uVar6 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          param_6[4] = uVar6;
          break;
        case 0x2f:
          uVar17 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          if (0x5f < uVar17) {
            __ptr = 
            "libunwind: malformed DW_CFA_GNU_negative_offset_extended DWARF unwind, reg too big\n";
            __size = 0x53;
            goto LAB_00135ef8;
          }
          lVar7 = FUN_00136610(apbStack_6a0 + 0xc0,pbVar1);
          puVar11 = param_6 + uVar17 * 4;
          iVar4 = *(int *)((long)param_3 + 0x2c);
          if (*(char *)(puVar11 + 7) == '\0') {
            pbVar19 = *(byte **)(param_6 + uVar17 * 4 + 6);
            apbStack_6a0[uVar17 * 2 + 1] = *(byte **)(param_6 + uVar17 * 4 + 8);
            apbStack_6a0[uVar17 * 2] = pbVar19;
            *(char *)(puVar11 + 7) = '\x01';
          }
          lVar7 = -(lVar7 * iVar4);
LAB_00135d44:
          uVar6 = 2;
LAB_00135d48:
          puVar11[6] = uVar6;
          *(long *)(puVar11 + 8) = lVar7;
        }
      } while ((apbStack_6a0[0xc0] < pbVar1) && (pbVar19 = apbStack_6a0[0xc0], uVar15 < uVar14));
    }
    puVar18 = puVar18 + 3;
    if (puVar18 == local_6c8) {
      return 1;
    }
  } while( true );
}


// ==== FUN_00136004 @ 00136004

long FUN_00136004(undefined8 param_1,uint *param_2,long param_3)

{
  uint uVar1;
  long lVar2;
  long *plVar3;
  
  uVar1 = *param_2;
  switch(uVar1) {
  case 0:
    lVar2 = FUN_001367e0(*(undefined8 *)(param_2 + 2),param_1,param_3,0);
    return lVar2;
  default:
    if (0x1c < uVar1) {
      fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getRegister","unsupported arm64 register");
      fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    plVar3 = (long *)(param_3 + (ulong)uVar1 * 8);
    break;
  case 0x1d:
    plVar3 = (long *)(param_3 + 0xe8);
    break;
  case 0x1e:
    plVar3 = (long *)(param_3 + 0xf0);
    break;
  case 0x22:
    plVar3 = (long *)(param_3 + 0x108);
    break;
  case 0xfffffffe:
  case 0x1f:
    plVar3 = (long *)(param_3 + 0xf8);
    break;
  case 0xffffffff:
  case 0x20:
    plVar3 = (long *)(param_3 + 0x100);
  }
  return *plVar3 + (long)(int)param_2[1];
}


// ==== FUN_00136100 @ 00136100

undefined8 FUN_00136100(undefined8 param_1,long param_2,long param_3,undefined4 *param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  uint uVar3;
  
  switch(*param_4) {
  case 1:
    return 0;
  case 2:
    return *(undefined8 *)(*(long *)(param_4 + 2) + param_3);
  default:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSavedRegister",
            "unsupported restore location for register");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 4:
    break;
  case 5:
    puVar1 = (undefined8 *)FUN_001367e0(*(undefined8 *)(param_4 + 2),param_1,param_2,param_3);
    return *puVar1;
  case 6:
    uVar2 = FUN_001367e0(*(undefined8 *)(param_4 + 2),param_1,param_2,param_3);
    return uVar2;
  }
  uVar3 = (uint)*(ulong *)(param_4 + 2);
  switch(uVar3) {
  case 0x1d:
    return *(undefined8 *)(param_2 + 0xe8);
  case 0x1e:
    return *(undefined8 *)(param_2 + 0xf0);
  case 0x22:
    return *(undefined8 *)(param_2 + 0x108);
  case 0xfffffffe:
  case 0x1f:
    return *(undefined8 *)(param_2 + 0xf8);
  case 0xffffffff:
  case 0x20:
    return *(undefined8 *)(param_2 + 0x100);
  }
  if (0x1c < uVar3) {
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getRegister","unsupported arm64 register");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  return *(undefined8 *)(param_2 + (*(ulong *)(param_4 + 2) & 0xffffffff) * 8);
}


// ==== FUN_001362fc @ 001362fc

long * FUN_001362fc(undefined8 param_1,long *param_2,uint *param_3,uint param_4,long param_5)

{
  byte bVar1;
  long *plVar2;
  ulong uVar3;
  uint *puVar4;
  ulong uVar5;
  ulong uVar6;
  uint *puVar7;
  uint *puVar8;
  
  if (0xc < (param_4 & 0xf)) {
code_r0x001365d8:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getEncodedP","unknown pointer encoding");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  puVar8 = (uint *)*param_2;
  switch(param_4 & 0xf) {
  case 0:
  case 4:
  case 0xc:
    plVar2 = *(long **)puVar8;
    *param_2 = (long)(puVar8 + 2);
    break;
  case 1:
    plVar2 = (long *)FUN_00136610(param_2,param_3);
    break;
  case 2:
    plVar2 = (long *)(ulong)(ushort)*puVar8;
    *param_2 = (long)puVar8 + 2;
    break;
  case 3:
    plVar2 = (long *)(ulong)*puVar8;
    *param_2 = (long)(puVar8 + 1);
    break;
  default:
    goto code_r0x001365d8;
  case 9:
    uVar5 = 0;
    uVar3 = 0;
    puVar4 = puVar8;
    puVar7 = puVar8;
    do {
      if (puVar7 == param_3) {
        fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128","truncated sleb128 expression")
        ;
        fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
        abort();
      }
      bVar1 = (byte)*puVar7;
      puVar4 = (uint *)((long)puVar4 + 1);
      uVar6 = uVar5 & 0x3f;
      uVar5 = uVar5 + 7;
      uVar3 = ((ulong)bVar1 & 0x7f) << uVar6 | uVar3;
      puVar7 = (uint *)((long)puVar7 + 1);
    } while ((char)bVar1 < '\0');
    uVar6 = -1L << (uVar5 & 0x3f);
    *param_2 = (long)puVar4;
    if (((int)uVar5 - 7U < 0x39 & bVar1 >> 6) == 0) {
      uVar6 = 0;
    }
    plVar2 = (long *)(uVar3 | uVar6);
    break;
  case 10:
    plVar2 = (long *)(long)(short)*puVar8;
    *param_2 = (long)puVar8 + 2;
    break;
  case 0xb:
    plVar2 = (long *)(long)(int)*puVar8;
    *param_2 = (long)(puVar8 + 1);
  }
  param_4 = param_4 & 0xff;
  switch(param_4 >> 4 & 7) {
  case 0:
    goto code_r0x00136448;
  case 1:
    plVar2 = (long *)((long)plVar2 + (long)puVar8);
code_r0x00136448:
    if (param_4 >> 7 != 0) {
LAB_0013644c:
      plVar2 = (long *)*plVar2;
    }
    return plVar2;
  case 2:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_textrel pointer encoding not supported");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 3:
    if (param_5 == 0) {
      fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getEncodedP",
              "DW_EH_PE_datarel is invalid with a datarelBase of 0");
      fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    plVar2 = (long *)((long)plVar2 + param_5);
    if (param_4 >> 7 == 0) {
      return plVar2;
    }
    goto LAB_0013644c;
  case 4:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_funcrel pointer encoding not supported");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 5:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_aligned pointer encoding not supported");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  default:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getEncodedP","unknown pointer encoding");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
}


// ==== FUN_00136610 @ 00136610

ulong FUN_00136610(long *param_1,byte *param_2)

{
  byte bVar1;
  ulong uVar2;
  byte *pbVar3;
  byte *pbVar4;
  
  pbVar3 = (byte *)*param_1;
  if (pbVar3 != param_2) {
    pbVar4 = pbVar3 + 1;
    uVar2 = (ulong)*pbVar3 & 0x7f;
    if (-1 < (char)*pbVar3) {
LAB_00136640:
      *param_1 = (long)pbVar4;
      return uVar2;
    }
    if (pbVar4 != param_2) {
      uVar2 = uVar2 | (ulong)((int)(char)pbVar3[1] & 0x7f) << 7;
      pbVar4 = pbVar3 + 2;
      if (-1 < (char)pbVar3[1]) goto LAB_00136640;
      if (pbVar4 != param_2) {
        uVar2 = uVar2 | (ulong)((int)(char)pbVar3[2] & 0x7f) << 0xe;
        pbVar4 = pbVar3 + 3;
        if (-1 < (char)pbVar3[2]) goto LAB_00136640;
        if (pbVar4 != param_2) {
          uVar2 = uVar2 | (ulong)((int)(char)pbVar3[3] & 0x7f) << 0x15;
          pbVar4 = pbVar3 + 4;
          if (-1 < (char)pbVar3[3]) goto LAB_00136640;
          if (pbVar4 != param_2) {
            uVar2 = uVar2 | (ulong)((int)(char)pbVar3[4] & 0x7f) << 0x1c;
            pbVar4 = pbVar3 + 5;
            if (-1 < (char)pbVar3[4]) goto LAB_00136640;
            if (pbVar4 != param_2) {
              uVar2 = uVar2 | (ulong)((int)(char)pbVar3[5] & 0x7f) << 0x23;
              pbVar4 = pbVar3 + 6;
              if (-1 < (char)pbVar3[5]) goto LAB_00136640;
              if (pbVar4 != param_2) {
                uVar2 = uVar2 | (ulong)((int)(char)pbVar3[6] & 0x7f) << 0x2a;
                pbVar4 = pbVar3 + 7;
                if (-1 < (char)pbVar3[6]) goto LAB_00136640;
                if (pbVar4 != param_2) {
                  uVar2 = uVar2 | (ulong)((int)(char)pbVar3[7] & 0x7f) << 0x31;
                  pbVar4 = pbVar3 + 8;
                  if (-1 < (char)pbVar3[7]) goto LAB_00136640;
                  if (pbVar4 != param_2) {
                    uVar2 = uVar2 | (ulong)((int)(char)pbVar3[8] & 0x7f) << 0x38;
                    pbVar4 = pbVar3 + 9;
                    if (-1 < (char)pbVar3[8]) goto LAB_00136640;
                    if (pbVar4 != param_2) {
                      bVar1 = *pbVar4;
                      if ((bVar1 & 0x7e) == 0) {
                        if (-1 < (char)bVar1) {
                          *param_1 = (long)(pbVar3 + 10);
                          return uVar2 | (ulong)bVar1 << 0x3f;
                        }
                        if (pbVar3 + 10 == param_2) goto LAB_00136770;
                      }
                      fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getULEB128",
                              "malformed uleb128 expression");
                      fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
                      abort();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
LAB_00136770:
  fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getULEB128","truncated uleb128 expression");
  fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_001367e0 @ 001367e0

ulong FUN_001367e0(byte *param_1,undefined8 param_2,long param_3,ulong param_4)

{
  ulong *puVar1;
  ulong *puVar2;
  ulong *puVar3;
  ulong *puVar4;
  ulong *puVar5;
  byte *pbVar6;
  byte bVar7;
  uint uVar8;
  long lVar9;
  ulong uVar10;
  byte *pbVar11;
  ulong *puVar12;
  byte *pbVar13;
  uint uVar14;
  ulong uVar15;
  ulong uVar16;
  ulong *puVar17;
  undefined1 auVar18 [16];
  ulong local_380 [99];
  byte *local_68;
  
  local_68 = param_1;
  lVar9 = FUN_00136610(&local_68,param_1 + 0x14);
  local_380[0] = param_4;
  pbVar6 = local_68 + lVar9;
  if (local_68 < pbVar6) {
    puVar1 = (ulong *)(param_3 + 0xf0);
    puVar2 = (ulong *)(param_3 + 0xe8);
    puVar17 = local_380;
    puVar3 = (ulong *)(param_3 + 0x108);
    puVar4 = (ulong *)(param_3 + 0xf8);
    puVar5 = (ulong *)(param_3 + 0x100);
    pbVar13 = local_68;
    do {
      pbVar11 = pbVar13 + 1;
      local_68 = pbVar11;
      uVar8 = (uint)*pbVar13;
      if (0x91 < uVar8 - 3) {
code_r0x00137048:
        fprintf((FILE *)0x144348,"libunwind: %s - %s\n","evaluateExpression",
                "DWARF opcode not implemented");
        fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
        abort();
      }
      uVar14 = (uint)*pbVar13;
      switch(uVar8) {
      case 3:
      case 0xe:
      case 0xf:
        pbVar11 = pbVar13 + 9;
        uVar10 = *(ulong *)(pbVar13 + 1);
        goto LAB_00136b68;
      case 4:
      case 5:
      case 7:
        goto code_r0x00137048;
      case 6:
        puVar12 = (ulong *)*puVar17;
code_r0x00136a90:
        *puVar17 = *puVar12;
        goto LAB_00136878;
      case 8:
        pbVar11 = pbVar13 + 2;
        uVar10 = (ulong)pbVar13[1];
        goto LAB_00136b68;
      case 9:
        pbVar11 = pbVar13 + 2;
        uVar10 = (ulong)(char)pbVar13[1];
        goto LAB_00136b68;
      case 10:
        pbVar11 = pbVar13 + 3;
        uVar10 = (ulong)*(ushort *)(pbVar13 + 1);
        goto LAB_00136b68;
      case 0xb:
        pbVar11 = pbVar13 + 3;
        uVar10 = (ulong)*(short *)(pbVar13 + 1);
        goto LAB_00136b68;
      case 0xc:
        pbVar11 = pbVar13 + 5;
        uVar10 = (ulong)*(uint *)(pbVar13 + 1);
        goto LAB_00136b68;
      case 0xd:
        pbVar11 = pbVar13 + 5;
        uVar10 = (ulong)*(int *)(pbVar13 + 1);
        goto LAB_00136b68;
      case 0x10:
        uVar15 = FUN_00136610(&local_68,pbVar6);
        puVar17 = puVar17 + 1;
        *puVar17 = uVar15;
        goto LAB_00136878;
      case 0x11:
        uVar15 = 0;
        uVar10 = 0;
        pbVar13 = pbVar11;
        do {
          if (pbVar13 == pbVar6) {
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                    "truncated sleb128 expression");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          bVar7 = *pbVar13;
          pbVar11 = pbVar11 + 1;
          uVar16 = uVar15 & 0x3f;
          uVar15 = uVar15 + 7;
          uVar10 = ((ulong)bVar7 & 0x7f) << uVar16 | uVar10;
          pbVar13 = pbVar13 + 1;
        } while ((char)bVar7 < '\0');
        uVar16 = -1L << (uVar15 & 0x3f);
        if (((int)uVar15 - 7U < 0x39 & bVar7 >> 6) == 0) {
          uVar16 = 0;
        }
        uVar10 = uVar10 | uVar16;
LAB_00136b68:
        local_68 = pbVar11;
        puVar17 = puVar17 + 1;
        *puVar17 = uVar10;
        goto LAB_00136878;
      case 0x12:
        uVar15 = *puVar17;
        goto LAB_00136874;
      case 0x13:
        puVar17 = puVar17 + -1;
        goto LAB_00136878;
      case 0x14:
        uVar15 = puVar17[-1];
        goto LAB_00136874;
      case 0x15:
        local_68 = pbVar13 + 2;
        puVar12 = puVar17 + -(ulong)pbVar13[1];
        goto code_r0x00136870;
      case 0x16:
        auVar18 = NEON_ext(*(undefined1 (*) [16])(puVar17 + -1),*(undefined1 (*) [16])(puVar17 + -1)
                           ,8,1);
        *puVar17 = auVar18._8_8_;
        puVar17[-1] = auVar18._0_8_;
        goto LAB_00136878;
      case 0x17:
        uVar15 = *puVar17;
        *puVar17 = SUB168(*(undefined1 (*) [16])(puVar17 + -2),8);
        puVar17[-1] = SUB168(*(undefined1 (*) [16])(puVar17 + -2),0);
        puVar17[-2] = uVar15;
        goto LAB_00136878;
      case 0x18:
        puVar12 = (ulong *)*puVar17;
        puVar17 = puVar17 + -1;
        *puVar17 = *puVar12;
        goto LAB_00136878;
      case 0x19:
        uVar15 = *puVar17;
        if ((long)uVar15 < 0) goto LAB_00136c6c;
        goto LAB_00136878;
      case 0x1a:
        uVar15 = puVar17[-1] & *puVar17;
        break;
      case 0x1b:
        uVar15 = 0;
        if (*puVar17 != 0) {
          uVar15 = (long)puVar17[-1] / (long)*puVar17;
        }
        break;
      case 0x1c:
        uVar15 = puVar17[-1] - *puVar17;
        break;
      case 0x1d:
        uVar15 = *puVar17;
        lVar9 = 0;
        if (uVar15 != 0) {
          lVar9 = (long)puVar17[-1] / (long)uVar15;
        }
        uVar15 = puVar17[-1] - lVar9 * uVar15;
        break;
      case 0x1e:
        uVar15 = puVar17[-1] * *puVar17;
        break;
      case 0x1f:
        uVar15 = *puVar17;
LAB_00136c6c:
        *puVar17 = -uVar15;
        goto LAB_00136878;
      case 0x20:
        *puVar17 = ~*puVar17;
        goto LAB_00136878;
      case 0x21:
        uVar15 = puVar17[-1] | *puVar17;
        break;
      case 0x22:
        uVar15 = puVar17[-1] + *puVar17;
        break;
      case 0x23:
        lVar9 = FUN_00136610(&local_68,pbVar6);
        *puVar17 = *puVar17 + lVar9;
        goto LAB_00136878;
      case 0x24:
        uVar15 = puVar17[-1] << (*puVar17 & 0x3f);
        break;
      case 0x25:
        uVar15 = puVar17[-1] >> (*puVar17 & 0x3f);
        break;
      case 0x26:
        uVar15 = (long)puVar17[-1] >> (*puVar17 & 0x3f);
        break;
      case 0x27:
        uVar15 = puVar17[-1] ^ *puVar17;
        break;
      case 0x28:
        puVar12 = puVar17 + -1;
        uVar15 = *puVar17;
        local_68 = pbVar13 + 3;
        puVar17 = puVar12;
        if (uVar15 != 0) {
          local_68 = pbVar13 + 3 + *(short *)(pbVar13 + 1);
        }
        goto LAB_00136878;
      case 0x29:
        uVar15 = (ulong)(puVar17[-1] == *puVar17);
        break;
      case 0x2a:
        uVar15 = (ulong)(*puVar17 <= puVar17[-1]);
        break;
      case 0x2b:
        uVar15 = (ulong)(*puVar17 < puVar17[-1]);
        break;
      case 0x2c:
        uVar15 = (ulong)(puVar17[-1] <= *puVar17);
        break;
      case 0x2d:
        uVar15 = (ulong)(puVar17[-1] < *puVar17);
        break;
      case 0x2e:
        uVar15 = (ulong)(puVar17[-1] != *puVar17);
        break;
      case 0x2f:
        local_68 = pbVar13 + (long)*(short *)(pbVar13 + 1) + 3;
        goto LAB_00136878;
      default:
        uVar15 = (ulong)(uVar14 - 0x30);
        goto LAB_00136874;
      case 0x50:
      case 0x51:
      case 0x52:
      case 0x53:
      case 0x54:
      case 0x55:
      case 0x56:
      case 0x57:
      case 0x58:
      case 0x59:
      case 0x5a:
      case 0x5b:
      case 0x5c:
      case 0x5d:
      case 0x5e:
      case 0x5f:
      case 0x60:
      case 0x61:
      case 0x62:
      case 99:
      case 100:
      case 0x65:
      case 0x66:
      case 0x67:
      case 0x68:
      case 0x69:
      case 0x6a:
      case 0x6b:
      case 0x6c:
      case 0x6d:
      case 0x6e:
      case 0x6f:
        puVar12 = puVar4;
        if (((uVar14 != 0x6f) && (puVar12 = puVar1, uVar14 != 0x6e)) &&
           (puVar12 = puVar2, uVar14 != 0x6d)) {
          puVar12 = (ulong *)(param_3 + (ulong)(uVar14 - 0x50) * 8);
        }
        goto code_r0x00136870;
      case 0x70:
      case 0x71:
      case 0x72:
      case 0x73:
      case 0x74:
      case 0x75:
      case 0x76:
      case 0x77:
      case 0x78:
      case 0x79:
      case 0x7a:
      case 0x7b:
      case 0x7c:
      case 0x7d:
      case 0x7e:
      case 0x7f:
      case 0x80:
      case 0x81:
      case 0x82:
      case 0x83:
      case 0x84:
      case 0x85:
      case 0x86:
      case 0x87:
      case 0x88:
      case 0x89:
      case 0x8a:
      case 0x8b:
      case 0x8c:
      case 0x8d:
      case 0x8e:
      case 0x8f:
        uVar15 = 0;
        uVar10 = 0;
        pbVar13 = pbVar11;
        do {
          if (pbVar13 == pbVar6) {
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                    "truncated sleb128 expression");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          bVar7 = *pbVar13;
          pbVar11 = pbVar11 + 1;
          uVar16 = uVar15 & 0x3f;
          uVar15 = uVar15 + 7;
          uVar10 = ((ulong)bVar7 & 0x7f) << uVar16 | uVar10;
          pbVar13 = pbVar13 + 1;
        } while ((char)bVar7 < '\0');
        uVar16 = -1L << (uVar15 & 0x3f);
        local_68 = pbVar11;
        if (((int)uVar15 - 7U < 0x39 & bVar7 >> 6) == 0) {
          uVar16 = 0;
        }
        puVar12 = puVar5;
        switch(uVar14) {
        case 0x6e:
        case 0x8f:
          puVar12 = puVar4;
          break;
        case 0x6f:
        case 0x90:
          break;
        default:
          if (0x1c < uVar8 - 0x70) {
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getRegister",
                    "unsupported arm64 register");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          puVar12 = (ulong *)(param_3 + (ulong)(uVar8 - 0x70) * 8);
          break;
        case 0x8d:
          puVar12 = puVar2;
          break;
        case 0x8e:
          puVar12 = puVar1;
          break;
        case 0x92:
          puVar12 = puVar3;
        }
        uVar15 = *puVar12 + (uVar10 | uVar16);
        goto LAB_00136874;
      case 0x90:
        uVar8 = FUN_00136610(&local_68,pbVar6);
        puVar12 = puVar5;
        switch(uVar8) {
        default:
          if (0x1c < uVar8) {
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getRegister",
                    "unsupported arm64 register");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          puVar12 = (ulong *)(param_3 + (ulong)uVar8 * 8);
          break;
        case 0x1d:
          puVar12 = puVar2;
          break;
        case 0x1e:
          puVar12 = puVar1;
          break;
        case 0x22:
          puVar12 = puVar3;
          break;
        case 0xfffffffe:
        case 0x1f:
          puVar12 = puVar4;
          break;
        case 0xffffffff:
        case 0x20:
          break;
        }
code_r0x00136870:
        uVar15 = *puVar12;
        goto LAB_00136874;
      case 0x91:
        fprintf((FILE *)0x144348,"libunwind: %s - %s\n","evaluateExpression",
                "DW_OP_fbreg not implemented");
        fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
        abort();
      case 0x92:
        uVar8 = FUN_00136610(&local_68,pbVar6);
        uVar15 = 0;
        uVar10 = 0;
        pbVar13 = local_68;
        pbVar11 = local_68;
        do {
          if (pbVar11 == pbVar6) {
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getSLEB128",
                    "truncated sleb128 expression");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          bVar7 = *pbVar11;
          pbVar13 = pbVar13 + 1;
          uVar16 = uVar15 & 0x3f;
          uVar15 = uVar15 + 7;
          uVar10 = ((ulong)bVar7 & 0x7f) << uVar16 | uVar10;
          pbVar11 = pbVar11 + 1;
        } while ((char)bVar7 < '\0');
        uVar16 = -1L << (uVar15 & 0x3f);
        local_68 = pbVar13;
        if (((int)uVar15 - 7U < 0x39 & bVar7 >> 6) == 0) {
          uVar16 = 0;
        }
        puVar12 = puVar5;
        switch(uVar8) {
        default:
          if (0x1c < uVar8) {
            fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getRegister",
                    "unsupported arm64 register");
            fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          puVar12 = (ulong *)(param_3 + (ulong)uVar8 * 8);
          break;
        case 0x1d:
          puVar12 = puVar2;
          break;
        case 0x1e:
          puVar12 = puVar1;
          break;
        case 0x22:
          puVar12 = puVar3;
          break;
        case 0xfffffffe:
        case 0x1f:
          puVar12 = puVar4;
          break;
        case 0xffffffff:
        case 0x20:
          break;
        }
        uVar15 = *puVar12 + (uVar10 | uVar16);
LAB_00136874:
        puVar17[1] = uVar15;
        puVar17 = puVar17 + 1;
        goto LAB_00136878;
      case 0x93:
        fprintf((FILE *)0x144348,"libunwind: %s - %s\n","evaluateExpression",
                "DW_OP_piece not implemented");
        fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
        abort();
      case 0x94:
        local_68 = pbVar13 + 2;
        puVar12 = (ulong *)*puVar17;
        switch(pbVar13[1]) {
        case 1:
          *puVar17 = (ulong)(byte)*puVar12;
          break;
        case 2:
          *puVar17 = (ulong)(ushort)*puVar12;
          break;
        default:
          fprintf((FILE *)0x144348,"libunwind: %s - %s\n","evaluateExpression",
                  "DW_OP_deref_size with bad size");
          fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
          abort();
        case 4:
          *puVar17 = (ulong)(uint)*puVar12;
          break;
        case 8:
          goto code_r0x00136a90;
        }
        goto LAB_00136878;
      }
      puVar17[-1] = uVar15;
      puVar17 = puVar17 + -1;
LAB_00136878:
      pbVar13 = local_68;
    } while (local_68 < pbVar6);
    param_4 = *puVar17;
  }
  return param_4;
}


// ==== FUN_001371a4 @ 001371a4

undefined8 FUN_001371a4(long param_1,ulong param_2,long *param_3,uint param_4)

{
  byte bVar1;
  undefined *__src;
  ulong uVar2;
  undefined8 uVar3;
  undefined *__dest;
  long *plVar4;
  size_t __n;
  long lVar5;
  undefined1 auStack_6e8 [32];
  undefined8 local_6c8;
  long local_6b0;
  undefined4 uStack_6a8;
  long local_698;
  long local_690;
  undefined8 uStack_688;
  undefined1 auStack_680 [16];
  uint local_670;
  
  if (((param_4 != 0) &&
      (uVar2 = FUN_00137658(*(undefined8 *)(param_1 + 8),param_2,param_3[2],param_3[3],
                            param_3[2] + (ulong)param_4,&local_6b0,auStack_6e8), (uVar2 & 1) != 0))
     || ((param_3[4] != 0 &&
         (uVar2 = FUN_00137820(*(undefined8 *)(param_1 + 8),param_2,param_3[4],(int)param_3[5],
                               &local_6b0,auStack_6e8), (uVar2 & 1) != 0)))) {
    bVar1 = 0;
    goto LAB_00137328;
  }
  lVar5 = *param_3;
  pthread_rwlock_rdlock((pthread_rwlock_t *)&DAT_001433cc);
  if (PTR_DAT_00142e48 < PTR_DAT_00142e50) {
    plVar4 = (long *)PTR_DAT_00142e48;
    if (lVar5 == -1) {
      do {
        if (((ulong)plVar4[1] <= param_2) && (param_2 < (ulong)plVar4[2])) goto LAB_001372b4;
        plVar4 = plVar4 + 4;
      } while (plVar4 < PTR_DAT_00142e50);
    }
    else {
      do {
        if (((*plVar4 == lVar5) && ((ulong)plVar4[1] <= param_2)) && (param_2 < (ulong)plVar4[2]))
        goto LAB_001372b4;
        plVar4 = plVar4 + 4;
      } while (plVar4 < PTR_DAT_00142e50);
    }
  }
  pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_001433cc);
LAB_001372fc:
  uVar2 = FUN_00137658(*(undefined8 *)(param_1 + 8),param_2,param_3[2],param_3[3],0,&local_6b0,
                       auStack_6e8);
  bVar1 = 0;
  if ((uVar2 & 1) == 0) {
    return 0;
  }
LAB_00137328:
  lVar5 = *param_3;
  memset(auStack_680,0,0x618);
  uVar2 = FUN_001354e4(*(undefined8 *)(param_1 + 8),&local_6b0,auStack_6e8,param_2,4,auStack_680);
  if ((uVar2 & 1) == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = 1;
    *(undefined8 *)(param_1 + 0x230) = uStack_688;
    *(long *)(param_1 + 0x228) = local_690;
    *(undefined8 *)(param_1 + 0x238) = local_6c8;
    *(ulong *)(param_1 + 0x240) = (ulong)local_670;
    *(undefined4 *)(param_1 + 0x250) = 0x3000000;
    *(long *)(param_1 + 0x220) = local_698;
    *(undefined8 *)(param_1 + 0x248) = 0;
    *(long *)(param_1 + 0x260) = lVar5;
    *(long *)(param_1 + 600) = local_6b0;
    *(undefined4 *)(param_1 + 0x254) = uStack_6a8;
    if ((!(bool)(param_4 != 0 | bVar1)) && (param_3[4] == 0)) {
      lVar5 = *param_3;
      pthread_rwlock_wrlock((pthread_rwlock_t *)&DAT_001433cc);
      __src = PTR_DAT_00142e48;
      if (DAT_00142e58 <= PTR_DAT_00142e50) {
        __n = (long)DAT_00142e58 - (long)PTR_DAT_00142e48;
        __dest = malloc(__n * 4);
        memcpy(__dest,__src,__n);
        if ((undefined8 *)__src != &DAT_00143408) {
          free(__src);
        }
        DAT_00142e58 = __dest + ((long)__n >> 3) * 0x20;
        PTR_DAT_00142e50 = __dest + ((long)__n >> 5) * 0x20;
        PTR_DAT_00142e48 = __dest;
      }
      *(long *)PTR_DAT_00142e50 = lVar5;
      *(long *)((long)PTR_DAT_00142e50 + 8) = local_698;
      *(long *)((long)PTR_DAT_00142e50 + 0x18) = local_6b0;
      *(long *)((long)PTR_DAT_00142e50 + 0x10) = local_690;
      PTR_DAT_00142e50 = (undefined *)((long)PTR_DAT_00142e50 + 0x20);
      pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_001433cc);
      uVar3 = 1;
    }
  }
  return uVar3;
LAB_001372b4:
  lVar5 = plVar4[3];
  pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_001433cc);
  if ((lVar5 != 0) &&
     (uVar2 = FUN_00137658(*(undefined8 *)(param_1 + 8),param_2,param_3[2],param_3[3],lVar5,
                           &local_6b0,auStack_6e8), (uVar2 & 1) != 0)) {
    bVar1 = 1;
    goto LAB_00137328;
  }
  goto LAB_001372fc;
}


// ==== FUN_00137658 @ 00137658

undefined8
FUN_00137658(undefined8 param_1,ulong param_2,uint *param_3,long param_4,uint *param_5,
            undefined8 *param_6,long param_7)

{
  uint *puVar1;
  char cVar2;
  uint *puVar3;
  long lVar4;
  long lVar5;
  undefined8 uVar6;
  uint *puVar7;
  ulong uVar8;
  uint *puVar9;
  uint *local_68;
  
  puVar9 = (uint *)(param_4 + (long)param_3);
  puVar1 = param_3;
  if (param_5 != (uint *)0x0) {
    puVar1 = param_5;
  }
  if (param_4 == -1) {
    puVar9 = (uint *)0xffffffffffffffff;
  }
  while( true ) {
    puVar3 = puVar1;
    if (puVar9 <= puVar3) {
      return 0;
    }
    local_68 = puVar3 + 1;
    uVar8 = (ulong)*puVar3;
    if (*puVar3 == 0xffffffff) {
      local_68 = puVar3 + 3;
      uVar8 = *(ulong *)(puVar3 + 1);
    }
    if (uVar8 == 0) break;
    puVar1 = (uint *)((long)local_68 + uVar8);
    if ((((*local_68 != 0) &&
         (puVar7 = (uint *)((long)local_68 - (ulong)*local_68), param_3 <= puVar7)) &&
        (puVar7 < puVar9)) && (lVar4 = FUN_00134678(param_1,puVar7,param_7), lVar4 == 0)) {
      local_68 = local_68 + 1;
      uVar8 = FUN_001362fc(param_1,&local_68,puVar1,*(undefined1 *)(param_7 + 0x18),0);
      lVar4 = FUN_001362fc(param_1,&local_68,puVar1,*(byte *)(param_7 + 0x18) & 0xf,0);
      if ((uVar8 < param_2) && (param_2 <= lVar4 + uVar8)) {
        cVar2 = *(char *)(param_7 + 0x31);
        param_6[5] = 0;
        if (cVar2 == '\0') {
          puVar9 = local_68;
        }
        else {
          lVar5 = FUN_00136610(&local_68,puVar1);
          puVar7 = local_68;
          puVar9 = (uint *)((long)local_68 + lVar5);
          if ((*(byte *)(param_7 + 0x19) != 0xff) &&
             (lVar5 = FUN_001362fc(param_1,&local_68,puVar1,*(byte *)(param_7 + 0x19) & 0xf,0),
             lVar5 != 0)) {
            local_68 = puVar7;
            uVar6 = FUN_001362fc(param_1,&local_68,puVar1,*(undefined1 *)(param_7 + 0x19),0);
            param_6[5] = uVar6;
          }
        }
        param_6[2] = puVar9;
        param_6[3] = uVar8;
        param_6[4] = lVar4 + uVar8;
        *param_6 = puVar3;
        param_6[1] = (long)puVar1 - (long)puVar3;
        return 1;
      }
    }
  }
  return 0;
}


// ==== FUN_00137820 @ 00137820

undefined8
FUN_00137820(undefined8 param_1,ulong param_2,char *param_3,ulong param_4,long param_5,
            undefined8 param_6)

{
  char *pcVar1;
  char cVar2;
  char cVar3;
  char *pcVar4;
  long lVar5;
  ulong uVar6;
  long lVar7;
  ulong uVar8;
  undefined8 uVar9;
  char *pcVar10;
  ulong uVar11;
  long lVar12;
  char *local_68;
  
  if (*param_3 == '\x01') {
    local_68 = param_3 + 4;
    cVar2 = param_3[2];
    pcVar1 = param_3 + (param_4 & 0xffffffff);
    cVar3 = param_3[3];
    FUN_001362fc(param_1,&local_68,pcVar1,param_3[1],param_3);
    if (cVar2 != -1) {
      uVar6 = FUN_001362fc(param_1,&local_68,pcVar1,cVar2,param_3);
      pcVar4 = local_68;
      if (uVar6 == 0) {
        return 0;
      }
      lVar7 = FUN_001379f0(cVar3);
      lVar12 = 0;
      do {
        if (uVar6 < 2) {
          pcVar10 = pcVar4 + lVar12 * lVar7;
          break;
        }
        uVar11 = uVar6 >> 1;
        pcVar10 = pcVar4 + (uVar11 + lVar12) * lVar7;
        local_68 = pcVar10;
        uVar8 = FUN_001362fc(param_1,&local_68,pcVar1,cVar3,param_3);
        uVar6 = uVar6 - uVar11;
        lVar5 = uVar11 + lVar12;
        if (param_2 <= uVar8) {
          uVar6 = uVar11;
          lVar5 = lVar12;
        }
        lVar12 = lVar5;
      } while (uVar8 != param_2);
      local_68 = pcVar10;
      FUN_001362fc(param_1,&local_68,pcVar1,cVar3,param_3);
      uVar9 = FUN_001362fc(param_1,&local_68,pcVar1,cVar3,param_3);
      lVar12 = FUN_001344e8(param_1,uVar9,param_5,param_6,0);
      if (((lVar12 == 0) && (*(ulong *)(param_5 + 0x18) <= param_2)) &&
         (param_2 < *(ulong *)(param_5 + 0x20))) {
        return 1;
      }
    }
  }
  else {
    fwrite("libunwind: Unsupported .eh_frame_hdr version\n",0x2d,1,(FILE *)0x144348);
  }
  return 0;
}


// ==== FUN_001379f0 @ 001379f0

undefined8 FUN_001379f0(uint param_1)

{
  undefined8 uVar1;
  
  uVar1 = 4;
  switch(param_1 & 0xf) {
  case 1:
  case 9:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getTableEntrySize",
            "Can\'t binary search on variable length encoded data.");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  case 2:
  case 10:
    goto code_r0x00137a38;
  case 3:
  case 0xb:
    uVar1 = 8;
code_r0x00137a38:
    return uVar1;
  case 4:
  case 0xc:
    return 0x10;
  default:
    fprintf((FILE *)0x144348,"libunwind: %s - %s\n","getTableEntrySize",
            "Unknown DWARF encoding for search table.");
    fflush((FILE *)0x144348);
                    /* WARNING: Subroutine does not return */
    abort();
  }
}


// ==== FUN_00137ad8 @ 00137ad8

char * FUN_00137ad8(int param_1)

{
  if (param_1 + 2U < 0x62) {
    return &DAT_0010dc5c + *(int *)(&DAT_0010dc5c + (long)(int)(param_1 + 2U) * 4);
  }
  return "unknown register";
}


// ==== FUN_00137b08 @ 00137b08

undefined8 FUN_00137b08(undefined8 *param_1)

{
  return *param_1;
}


// ==== FUN_00137b98 @ 00137b98

undefined8
FUN_00137b98(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
            undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
            undefined8 param_9,long param_10,undefined8 param_11,undefined8 param_12,
            undefined8 param_13,undefined8 param_14,undefined8 param_15,undefined8 param_16,
            undefined8 param_17)

{
  undefined8 in_x9;
  undefined8 in_x10;
  undefined8 in_x11;
  undefined8 in_x12;
  undefined8 in_x13;
  undefined8 in_x14;
  undefined8 in_x15;
  undefined8 in_x16;
  undefined8 in_x17;
  undefined8 in_x18;
  undefined8 unaff_x19;
  undefined8 unaff_x20;
  undefined8 unaff_x21;
  undefined8 unaff_x22;
  undefined8 unaff_x23;
  undefined8 unaff_x24;
  undefined8 unaff_x25;
  undefined8 unaff_x26;
  undefined8 unaff_x27;
  undefined8 unaff_x28;
  undefined8 unaff_x29;
  undefined8 unaff_x30;
  undefined8 unaff_d8;
  undefined8 unaff_d9;
  undefined8 unaff_d10;
  undefined8 unaff_d11;
  undefined8 unaff_d12;
  undefined8 unaff_d13;
  undefined8 unaff_d14;
  undefined8 unaff_d15;
  undefined8 in_d16;
  undefined8 in_d17;
  undefined8 in_d18;
  undefined8 in_d19;
  undefined8 in_d20;
  undefined8 in_d21;
  undefined8 in_d22;
  undefined8 in_d23;
  undefined8 in_d24;
  undefined8 in_d25;
  undefined8 in_d26;
  undefined8 in_d27;
  undefined8 in_d28;
  undefined8 in_d29;
  undefined8 in_d30;
  undefined8 in_d31;
  
  *(long *)param_10 = param_10;
  *(undefined8 *)(param_10 + 8) = param_11;
  *(undefined8 *)(param_10 + 0x10) = param_12;
  *(undefined8 *)(param_10 + 0x18) = param_13;
  *(undefined8 *)(param_10 + 0x20) = param_14;
  *(undefined8 *)(param_10 + 0x28) = param_15;
  *(undefined8 *)(param_10 + 0x30) = param_16;
  *(undefined8 *)(param_10 + 0x38) = param_17;
  *(undefined8 *)(param_10 + 0x40) = param_1;
  *(undefined8 *)(param_10 + 0x48) = in_x9;
  *(undefined8 *)(param_10 + 0x50) = in_x10;
  *(undefined8 *)(param_10 + 0x58) = in_x11;
  *(undefined8 *)(param_10 + 0x60) = in_x12;
  *(undefined8 *)(param_10 + 0x68) = in_x13;
  *(undefined8 *)(param_10 + 0x70) = in_x14;
  *(undefined8 *)(param_10 + 0x78) = in_x15;
  *(undefined8 *)(param_10 + 0x80) = in_x16;
  *(undefined8 *)(param_10 + 0x88) = in_x17;
  *(undefined8 *)(param_10 + 0x90) = in_x18;
  *(undefined8 *)(param_10 + 0x98) = unaff_x19;
  *(undefined8 *)(param_10 + 0xa0) = unaff_x20;
  *(undefined8 *)(param_10 + 0xa8) = unaff_x21;
  *(undefined8 *)(param_10 + 0xb0) = unaff_x22;
  *(undefined8 *)(param_10 + 0xb8) = unaff_x23;
  *(undefined8 *)(param_10 + 0xc0) = unaff_x24;
  *(undefined8 *)(param_10 + 200) = unaff_x25;
  *(undefined8 *)(param_10 + 0xd0) = unaff_x26;
  *(undefined8 *)(param_10 + 0xd8) = unaff_x27;
  *(undefined8 *)(param_10 + 0xe0) = unaff_x28;
  *(undefined8 *)(param_10 + 0xe8) = unaff_x29;
  *(undefined8 *)(param_10 + 0xf0) = unaff_x30;
  *(BADSPACEBASE **)(param_10 + 0xf8) = register0x00000008;
  *(undefined8 *)(param_10 + 0x100) = unaff_x30;
  *(undefined8 *)(param_10 + 0x110) = param_2;
  *(undefined8 *)(param_10 + 0x118) = param_3;
  *(undefined8 *)(param_10 + 0x120) = param_4;
  *(undefined8 *)(param_10 + 0x128) = param_5;
  *(undefined8 *)(param_10 + 0x130) = param_6;
  *(undefined8 *)(param_10 + 0x138) = param_7;
  *(undefined8 *)(param_10 + 0x140) = param_8;
  *(undefined8 *)(param_10 + 0x148) = param_9;
  *(undefined8 *)(param_10 + 0x150) = unaff_d8;
  *(undefined8 *)(param_10 + 0x158) = unaff_d9;
  *(undefined8 *)(param_10 + 0x160) = unaff_d10;
  *(undefined8 *)(param_10 + 0x168) = unaff_d11;
  *(undefined8 *)(param_10 + 0x170) = unaff_d12;
  *(undefined8 *)(param_10 + 0x178) = unaff_d13;
  *(undefined8 *)(param_10 + 0x180) = unaff_d14;
  *(undefined8 *)(param_10 + 0x188) = unaff_d15;
  *(undefined8 *)(param_10 + 400) = in_d16;
  *(undefined8 *)(param_10 + 0x198) = in_d17;
  *(undefined8 *)(param_10 + 0x1a0) = in_d18;
  *(undefined8 *)(param_10 + 0x1a8) = in_d19;
  *(undefined8 *)(param_10 + 0x1b0) = in_d20;
  *(undefined8 *)(param_10 + 0x1b8) = in_d21;
  *(undefined8 *)(param_10 + 0x1c0) = in_d22;
  *(undefined8 *)(param_10 + 0x1c8) = in_d23;
  *(undefined8 *)(param_10 + 0x1d0) = in_d24;
  *(undefined8 *)(param_10 + 0x1d8) = in_d25;
  *(undefined8 *)(param_10 + 0x1e0) = in_d26;
  *(undefined8 *)(param_10 + 0x1e8) = in_d27;
  *(undefined8 *)(param_10 + 0x1f0) = in_d28;
  *(undefined8 *)(param_10 + 0x1f8) = in_d29;
  *(undefined8 *)(param_10 + 0x200) = in_d30;
  *(undefined8 *)(param_10 + 0x208) = in_d31;
  return 0;
}


// ==== FUN_00137c40 @ 00137c40

void FUN_00137c40(void)

{
  (*(code *)(undefined *)0x0)();
  return;
}


// ==== __cxa_finalize @ 00137c60

void __cxa_finalize(void)

{
  __cxa_finalize();
  return;
}


// ==== __cxa_atexit @ 00137c70

void __cxa_atexit(void)

{
  __cxa_atexit();
  return;
}


// ==== __stack_chk_fail @ 00137c80

void __stack_chk_fail(void)

{
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== strlen @ 00137c90

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
  size_t sVar1;
  
  sVar1 = strlen(__s);
  return sVar1;
}


// ==== memcpy @ 00137ca0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memcpy(__dest,__src,__n);
  return pvVar1;
}


// ==== localeconv @ 00137cb0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

lconv * localeconv(void)

{
  lconv *plVar1;
  
  plVar1 = localeconv();
  return plVar1;
}


// ==== AMotionEvent_getAction @ 00137cc0

void AMotionEvent_getAction(void)

{
  AMotionEvent_getAction();
  return;
}


// ==== AInputEvent_getDeviceId @ 00137cd0

void AInputEvent_getDeviceId(void)

{
  AInputEvent_getDeviceId();
  return;
}


// ==== AInputEvent_getSource @ 00137ce0

void AInputEvent_getSource(void)

{
  AInputEvent_getSource();
  return;
}


// ==== gettimeofday @ 00137cf0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
  int iVar1;
  
  iVar1 = gettimeofday(__tv,__tz);
  return iVar1;
}


// ==== AMotionEvent_getX @ 00137d00

void AMotionEvent_getX(void)

{
  AMotionEvent_getX();
  return;
}


// ==== AMotionEvent_getY @ 00137d10

void AMotionEvent_getY(void)

{
  AMotionEvent_getY();
  return;
}


// ==== AMotionEvent_getToolType @ 00137d20

void AMotionEvent_getToolType(void)

{
  AMotionEvent_getToolType();
  return;
}


// ==== AMotionEvent_getPointerId @ 00137d30

void AMotionEvent_getPointerId(void)

{
  AMotionEvent_getPointerId();
  return;
}


// ==== AMotionEvent_getPressure @ 00137d40

void AMotionEvent_getPressure(void)

{
  AMotionEvent_getPressure();
  return;
}


// ==== AMotionEvent_getSize @ 00137d50

void AMotionEvent_getSize(void)

{
  AMotionEvent_getSize();
  return;
}


// ==== AMotionEvent_getFlags @ 00137d60

void AMotionEvent_getFlags(void)

{
  AMotionEvent_getFlags();
  return;
}


// ==== AMotionEvent_getPointerCount @ 00137d70

void AMotionEvent_getPointerCount(void)

{
  AMotionEvent_getPointerCount();
  return;
}


// ==== AMotionEvent_getXPrecision @ 00137d80

void AMotionEvent_getXPrecision(void)

{
  AMotionEvent_getXPrecision();
  return;
}


// ==== AMotionEvent_getYPrecision @ 00137d90

void AMotionEvent_getYPrecision(void)

{
  AMotionEvent_getYPrecision();
  return;
}


// ==== AMotionEvent_getDownTime @ 00137da0

void AMotionEvent_getDownTime(void)

{
  AMotionEvent_getDownTime();
  return;
}


// ==== AMotionEvent_getEventTime @ 00137db0

void AMotionEvent_getEventTime(void)

{
  AMotionEvent_getEventTime();
  return;
}


// ==== memcmp @ 00137dc0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = memcmp(__s1,__s2,__n);
  return iVar1;
}


// ==== __vsnprintf_chk @ 00137dd0

void __vsnprintf_chk(void)

{
  __vsnprintf_chk();
  return;
}


// ==== memset @ 00137de0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memset(__s,__c,__n);
  return pvVar1;
}


// ==== memmove @ 00137df0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memmove(__dest,__src,__n);
  return pvVar1;
}


// ==== __android_log_print @ 00137e00

void __android_log_print(void)

{
  __android_log_print();
  return;
}


// ==== regcomp @ 00137e10

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
  int iVar1;
  
  iVar1 = regcomp(__preg,__pattern,__cflags);
  return iVar1;
}


// ==== malloc @ 00137e20

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = malloc(__size);
  return pvVar1;
}


// ==== strdup @ 00137e30

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
  char *pcVar1;
  
  pcVar1 = strdup(__s);
  return pcVar1;
}


// ==== pthread_mutex_lock @ 00137e40

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_lock(__mutex);
  return iVar1;
}


// ==== pthread_mutex_unlock @ 00137e50

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_unlock(__mutex);
  return iVar1;
}


// ==== free @ 00137e60

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== sigemptyset @ 00137e70

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigemptyset(sigset_t *__set)

{
  int iVar1;
  
  iVar1 = sigemptyset(__set);
  return iVar1;
}


// ==== sigaction @ 00137e80

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
  int iVar1;
  
  iVar1 = sigaction(__sig,__act,__oact);
  return iVar1;
}


// ==== pthread_cond_signal @ 00137e90

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_signal(__cond);
  return iVar1;
}


// ==== pthread_create @ 00137ea0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
  int iVar1;
  
  iVar1 = pthread_create(__newthread,__attr,__start_routine,__arg);
  return iVar1;
}


// ==== pthread_join @ 00137eb0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
  int iVar1;
  
  iVar1 = pthread_join(__th,__thread_return);
  return iVar1;
}


// ==== regfree @ 00137ec0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
  regfree(__preg);
  return;
}


// ==== siglongjmp @ 00137ed0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Subroutine does not return */
  siglongjmp(__env,__val);
}


// ==== pthread_self @ 00137ee0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
  pthread_t pVar1;
  
  pVar1 = pthread_self();
  return pVar1;
}


// ==== pthread_setname_np @ 00137ef0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
  int iVar1;
  
  iVar1 = pthread_setname_np(__target_thread,__name);
  return iVar1;
}


// ==== pthread_cond_wait @ 00137f00

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_cond_wait(__cond,__mutex);
  return iVar1;
}


// ==== fopen @ 00137f10

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
  FILE *pFVar1;
  
  pFVar1 = fopen(__filename,__modes);
  return pFVar1;
}


// ==== fgets @ 00137f20

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
  char *pcVar1;
  
  pcVar1 = fgets(__s,__n,__stream);
  return pcVar1;
}


// ==== sscanf @ 00137f30

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
  int iVar1;
  
  iVar1 = sscanf(__s,__format);
  return iVar1;
}


// ==== regexec @ 00137f40

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
  int iVar1;
  
  iVar1 = regexec(__preg,__string,__nmatch,__pmatch,__eflags);
  return iVar1;
}


// ==== strcmp @ 00137f50

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = strcmp(__s1,__s2);
  return iVar1;
}


// ==== fclose @ 00137f60

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fclose(__stream);
  return iVar1;
}


// ==== sigsetjmp @ 00137f70

void sigsetjmp(void)

{
  sigsetjmp();
  return;
}


// ==== getpagesize @ 00137f80

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int getpagesize(void)

{
  int iVar1;
  
  iVar1 = getpagesize();
  return iVar1;
}


// ==== strstr @ 00137f90

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
  char *pcVar1;
  
  pcVar1 = strstr(__haystack,__needle);
  return pcVar1;
}


// ==== mprotect @ 00137fa0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
  int iVar1;
  
  iVar1 = mprotect(__addr,__len,__prot);
  return iVar1;
}


// ==== __errno @ 00137fb0

void __errno(void)

{
  __errno();
  return;
}


// ==== pthread_cond_broadcast @ 00137fc0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_broadcast(__cond);
  return iVar1;
}


// ==== pthread_getspecific @ 00137fd0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
  void *pvVar1;
  
  pvVar1 = pthread_getspecific(__key);
  return pvVar1;
}


// ==== pthread_setspecific @ 00137fe0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
  int iVar1;
  
  iVar1 = pthread_setspecific(__key,__pointer);
  return iVar1;
}


// ==== pthread_cond_destroy @ 00137ff0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_destroy(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_destroy(__cond);
  return iVar1;
}


// ==== pthread_mutex_destroy @ 00138000

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_destroy(__mutex);
  return iVar1;
}


// ==== posix_memalign @ 00138010

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
  int iVar1;
  
  iVar1 = posix_memalign(__memptr,__alignment,__size);
  return iVar1;
}


// ==== __strlen_chk @ 00138020

void __strlen_chk(void)

{
  __strlen_chk();
  return;
}


// ==== memchr @ 00138030

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memchr(__s,__c,__n);
  return pvVar1;
}


// ==== strerror_r @ 00138040

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
  char *pcVar1;
  
  pcVar1 = strerror_r(__errnum,__buf,__buflen);
  return pcVar1;
}


// ==== abort @ 00138050

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== vsnprintf @ 00138060

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vsnprintf(__s,__maxlen,__format,__arg);
  return iVar1;
}


// ==== pthread_key_create @ 00138070

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
  int iVar1;
  
  iVar1 = pthread_key_create(__key,__destr_function);
  return iVar1;
}


// ==== syscall @ 00138080

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
  long lVar1;
  
  lVar1 = syscall(__sysno);
  return lVar1;
}


// ==== vfprintf @ 00138090

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vfprintf(__s,__format,__arg);
  return iVar1;
}


// ==== fputc @ 001380a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
  int iVar1;
  
  iVar1 = fputc(__c,__stream);
  return iVar1;
}


// ==== vasprintf @ 001380b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vasprintf(__ptr,__f,__arg);
  return iVar1;
}


// ==== android_set_abort_message @ 001380c0

void android_set_abort_message(void)

{
  android_set_abort_message();
  return;
}


// ==== openlog @ 001380d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void openlog(char *__ident,int __option,int __facility)

{
  openlog(__ident,__option,__facility);
  return;
}


// ==== syslog @ 001380e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void syslog(int __pri,char *__fmt,...)

{
  syslog(__pri,__fmt);
  return;
}


// ==== closelog @ 001380f0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void closelog(void)

{
  closelog();
  return;
}


// ==== realloc @ 00138100

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
  void *pvVar1;
  
  pvVar1 = realloc(__ptr,__size);
  return pvVar1;
}


// ==== __memmove_chk @ 00138110

void __memmove_chk(void)

{
  __memmove_chk();
  return;
}


// ==== pthread_once @ 00138120

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
  int iVar1;
  
  iVar1 = pthread_once(__once_control,__init_routine);
  return iVar1;
}


// ==== pthread_key_delete @ 00138130

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
  int iVar1;
  
  iVar1 = pthread_key_delete(__key);
  return iVar1;
}


// ==== getauxval @ 00138140

void getauxval(void)

{
  getauxval();
  return;
}


// ==== __system_property_get @ 00138150

void __system_property_get(void)

{
  __system_property_get();
  return;
}


// ==== strncmp @ 00138160

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strncmp(char *__s1,char *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = strncmp(__s1,__s2,__n);
  return iVar1;
}


// ==== fprintf @ 00138170

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
  int iVar1;
  
  iVar1 = fprintf(__stream,__format);
  return iVar1;
}


// ==== fflush @ 00138180

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fflush(__stream);
  return iVar1;
}


// ==== pthread_rwlock_wrlock @ 00138190

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_wrlock(__rwlock);
  return iVar1;
}


// ==== pthread_rwlock_unlock @ 001381a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_unlock(__rwlock);
  return iVar1;
}


// ==== dl_iterate_phdr @ 001381b0

void dl_iterate_phdr(void)

{
  dl_iterate_phdr();
  return;
}


// ==== pthread_rwlock_rdlock @ 001381c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_rdlock(__rwlock);
  return iVar1;
}


// ==== fwrite @ 001381d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
  size_t sVar1;
  
  sVar1 = fwrite(__ptr,__size,__n,__s);
  return sVar1;
}


// ==== __cxa_finalize @ 00144000

/* WARNING: Control flow encountered bad instruction data */

void __cxa_finalize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __cxa_atexit @ 00144008

/* WARNING: Control flow encountered bad instruction data */

void __cxa_atexit(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __stack_chk_fail @ 00144010

/* WARNING: Control flow encountered bad instruction data */

void __stack_chk_fail(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strlen @ 00144018

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcpy @ 00144020

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== localeconv @ 00144028

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

lconv * localeconv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getAction @ 00144030

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getAction(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getDeviceId @ 00144038

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getDeviceId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getSource @ 00144040

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getSource(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== gettimeofday @ 00144048

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getX @ 00144050

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getX(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getY @ 00144058

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getY(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getToolType @ 00144060

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getToolType(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerId @ 00144068

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPressure @ 00144070

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPressure(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getSize @ 00144078

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getSize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getFlags @ 00144080

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getFlags(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerCount @ 00144088

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerCount(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getXPrecision @ 00144090

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getXPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getYPrecision @ 00144098

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getYPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getDownTime @ 001440a0

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getDownTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getEventTime @ 001440a8

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getEventTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcmp @ 001440b0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __vsnprintf_chk @ 001440b8

/* WARNING: Control flow encountered bad instruction data */

void __vsnprintf_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memset @ 001440c0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memmove @ 001440c8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __android_log_print @ 001440d0

/* WARNING: Control flow encountered bad instruction data */

void __android_log_print(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regcomp @ 001440d8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== malloc @ 001440e0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strdup @ 001440e8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_lock @ 001440f0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_unlock @ 001440f8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== free @ 00144100

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigemptyset @ 00144108

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigemptyset(sigset_t *__set)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigaction @ 00144110

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_signal @ 00144118

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_create @ 00144120

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_join @ 00144128

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regfree @ 00144130

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== siglongjmp @ 00144138

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_self @ 00144140

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setname_np @ 00144148

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_wait @ 00144150

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fopen @ 00144158

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fgets @ 00144160

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sscanf @ 00144168

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regexec @ 00144170

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strcmp @ 00144178

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fclose @ 00144180

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigsetjmp @ 00144188

/* WARNING: Control flow encountered bad instruction data */

void sigsetjmp(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== getpagesize @ 00144190

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int getpagesize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strstr @ 00144198

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== mprotect @ 001441a0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __errno @ 001441a8

/* WARNING: Control flow encountered bad instruction data */

void __errno(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_broadcast @ 001441b0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_getspecific @ 001441b8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setspecific @ 001441c0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_destroy @ 001441c8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_destroy(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_destroy @ 001441d0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== posix_memalign @ 001441d8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __strlen_chk @ 001441e0

/* WARNING: Control flow encountered bad instruction data */

void __strlen_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memchr @ 001441e8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strerror_r @ 001441f0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== abort @ 001441f8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vsnprintf @ 00144200

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_create @ 00144208

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== syscall @ 00144210

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vfprintf @ 00144220

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fputc @ 00144228

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vasprintf @ 00144230

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== android_set_abort_message @ 00144238

/* WARNING: Control flow encountered bad instruction data */

void android_set_abort_message(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== openlog @ 00144240

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void openlog(char *__ident,int __option,int __facility)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== syslog @ 00144248

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void syslog(int __pri,char *__fmt,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== closelog @ 00144250

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void closelog(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== realloc @ 00144258

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __memmove_chk @ 00144260

/* WARNING: Control flow encountered bad instruction data */

void __memmove_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_once @ 00144268

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_delete @ 00144270

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== getauxval @ 00144278

/* WARNING: Control flow encountered bad instruction data */

void getauxval(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __system_property_get @ 00144280

/* WARNING: Control flow encountered bad instruction data */

void __system_property_get(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strncmp @ 00144288

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strncmp(char *__s1,char *__s2,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fprintf @ 00144290

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fflush @ 00144298

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_wrlock @ 001442a0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_unlock @ 001442a8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== dl_iterate_phdr @ 001442b0

/* WARNING: Control flow encountered bad instruction data */

void dl_iterate_phdr(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_rdlock @ 001442b8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fwrite @ 001442c0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


