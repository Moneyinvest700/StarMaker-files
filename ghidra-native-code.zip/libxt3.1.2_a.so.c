// ==== _FINI_1 @ 00018ee8

void _FINI_1(void)

{
  __cxa_finalize(&DAT_000313d0);
  return;
}


// ==== _FINI_0 @ 00018efc

void _FINI_0(void)

{
  if (DAT_00036e14 == '\x01') {
    pthread_key_delete(DAT_00036e18);
    DAT_00036e14 = 0;
    return;
  }
  return;
}


// ==== FUN_00018fd0 @ 00018fd0

void FUN_00018fd0(int *param_1)

{
  undefined1 uVar1;
  undefined8 uVar2;
  float *pfVar3;
  float *pfVar4;
  undefined4 uVar5;
  undefined1 *puVar6;
  float fVar7;
  float *pfVar8;
  undefined8 local_140;
  undefined1 local_138;
  undefined8 local_130;
  undefined1 local_128;
  float local_120;
  int local_11c;
  undefined1 local_118;
  float local_110;
  int local_10c;
  undefined1 local_108;
  float local_100;
  float fStack_fc;
  undefined1 local_f8;
  float local_f0;
  float fStack_ec;
  undefined1 local_e8;
  undefined8 local_e0;
  undefined1 local_d8;
  undefined8 local_d0;
  undefined1 local_c8;
  float local_c0;
  float fStack_bc;
  undefined1 local_b8;
  float local_b0;
  int local_ac;
  undefined1 local_a8;
  float local_a0;
  int local_9c;
  undefined1 local_98;
  float local_90;
  int local_8c;
  undefined1 local_88;
  float local_80;
  int local_7c;
  undefined1 local_78;
  float local_70;
  int local_6c;
  undefined1 local_68;
  undefined8 local_60;
  undefined1 local_58;
  undefined8 local_50;
  byte local_48;
  undefined1 auStack_47 [7];
  undefined1 *local_40 [2];
  undefined1 local_38 [8];
  undefined4 local_30;
  undefined4 uStack_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  DataMemoryBarrier(0x1b);
  if (((DAT_00036a40 & 1) != 0) && (DataMemoryBarrier(0x1b), (DAT_000369fc & 1) != 0)) {
    FUN_0001ee48(0x36a58);
    pfVar4 = DAT_00036a5c._4_4_;
    pfVar3 = (float *)DAT_00036a5c;
    FUN_0001ee60(0x36a58);
    if (pfVar3 != pfVar4) {
      local_30 = 0;
      uStack_2c = 0;
      local_38[0] = 2;
      uVar5 = FUN_0001ee80(0xc);
      FUN_0001b0ec(uVar5,0,0);
      local_30 = uVar5;
      FUN_0001ee48(0x36a58);
      pfVar4 = DAT_00036a5c._4_4_;
      pfVar3 = (float *)DAT_00036a5c;
      DAT_00036a5c._0_4_ = (float *)0x0;
      DAT_00036a5c._4_4_ = (float *)0x0;
      DAT_00036a64 = 0;
      FUN_0001ee60(0x36a58);
      if (pfVar3 != pfVar4) {
        pfVar8 = pfVar3;
        do {
          local_40[0] = (undefined1 *)0x0;
          local_50 = (double)*pfVar8;
          local_48 = 0;
          local_58 = 7;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016eb5);
          uVar1 = *puVar6;
          *puVar6 = local_58;
          uVar2 = *(undefined8 *)(puVar6 + 8);
          *(undefined4 *)(puVar6 + 8) = (undefined4)local_50;
          *(undefined4 *)(puVar6 + 0xc) = local_50._4_4_;
          local_58 = uVar1;
          local_50 = (double)uVar2;
          FUN_00019e9c(&local_50);
          local_60 = (double)pfVar8[1];
          local_68 = 7;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016140);
          uVar1 = *puVar6;
          *puVar6 = local_68;
          uVar2 = *(undefined8 *)(puVar6 + 8);
          *(undefined4 *)(puVar6 + 8) = (undefined4)local_60;
          *(undefined4 *)(puVar6 + 0xc) = local_60._4_4_;
          local_68 = uVar1;
          local_60 = (double)uVar2;
          FUN_00019e9c(&local_60);
          local_70 = pfVar8[8];
          local_6c = (int)local_70 >> 0x1f;
          local_78 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00017045);
          uVar1 = *puVar6;
          *puVar6 = local_78;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_70;
          *(int *)(puVar6 + 0xc) = local_6c;
          local_78 = uVar1;
          local_70 = fVar7;
          local_6c = uVar5;
          FUN_00019e9c(&local_70);
          local_80 = pfVar8[9];
          local_7c = (int)local_80 >> 0x1f;
          local_88 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016093);
          uVar1 = *puVar6;
          *puVar6 = local_88;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_80;
          *(int *)(puVar6 + 0xc) = local_7c;
          local_88 = uVar1;
          local_80 = fVar7;
          local_7c = uVar5;
          FUN_00019e9c(&local_80);
          local_90 = pfVar8[10];
          local_8c = (int)local_90 >> 0x1f;
          local_98 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016b9d);
          uVar1 = *puVar6;
          *puVar6 = local_98;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_90;
          *(int *)(puVar6 + 0xc) = local_8c;
          local_98 = uVar1;
          local_90 = fVar7;
          local_8c = uVar5;
          FUN_00019e9c(&local_90);
          local_a0 = pfVar8[0xc];
          local_9c = (int)local_a0 >> 0x1f;
          local_a8 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016468);
          uVar1 = *puVar6;
          *puVar6 = local_a8;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_a0;
          *(int *)(puVar6 + 0xc) = local_9c;
          local_a8 = uVar1;
          local_a0 = fVar7;
          local_9c = uVar5;
          FUN_00019e9c(&local_a0);
          local_b0 = pfVar8[0xb];
          local_ac = (int)local_b0 >> 0x1f;
          local_b8 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016324);
          uVar1 = *puVar6;
          *puVar6 = local_b8;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_b0;
          *(int *)(puVar6 + 0xc) = local_ac;
          local_b8 = uVar1;
          local_b0 = fVar7;
          local_ac = uVar5;
          FUN_00019e9c(&local_b0);
          local_c0 = pfVar8[0xe];
          fStack_bc = pfVar8[0xf];
          local_c8 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00015f5f);
          uVar1 = *puVar6;
          *puVar6 = local_c8;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_c0;
          *(float *)(puVar6 + 0xc) = fStack_bc;
          local_c8 = uVar1;
          local_c0 = fVar7;
          fStack_bc = (float)uVar5;
          FUN_00019e9c(&local_c0);
          local_d0 = (double)pfVar8[2];
          local_d8 = 7;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_0001652e);
          uVar1 = *puVar6;
          *puVar6 = local_d8;
          uVar2 = *(undefined8 *)(puVar6 + 8);
          *(undefined4 *)(puVar6 + 8) = (undefined4)local_d0;
          *(undefined4 *)(puVar6 + 0xc) = local_d0._4_4_;
          local_d8 = uVar1;
          local_d0 = (double)uVar2;
          FUN_00019e9c(&local_d0);
          local_e0 = (double)pfVar8[3];
          local_e8 = 7;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_000170b8);
          uVar1 = *puVar6;
          *puVar6 = local_e8;
          uVar2 = *(undefined8 *)(puVar6 + 8);
          *(undefined4 *)(puVar6 + 8) = (undefined4)local_e0;
          *(undefined4 *)(puVar6 + 0xc) = local_e0._4_4_;
          local_e8 = uVar1;
          local_e0 = (double)uVar2;
          FUN_00019e9c(&local_e0);
          local_f0 = pfVar8[4];
          fStack_ec = pfVar8[5];
          local_f8 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016284);
          uVar1 = *puVar6;
          *puVar6 = local_f8;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_f0;
          *(float *)(puVar6 + 0xc) = fStack_ec;
          local_f8 = uVar1;
          local_f0 = fVar7;
          fStack_ec = (float)uVar5;
          FUN_00019e9c(&local_f0);
          local_100 = pfVar8[6];
          fStack_fc = pfVar8[7];
          local_108 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016682);
          uVar1 = *puVar6;
          *puVar6 = local_108;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_100;
          *(float *)(puVar6 + 0xc) = fStack_fc;
          local_108 = uVar1;
          local_100 = fVar7;
          fStack_fc = (float)uVar5;
          FUN_00019e9c(&local_100);
          local_110 = pfVar8[0x12];
          local_10c = (int)local_110 >> 0x1f;
          local_118 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016096);
          uVar1 = *puVar6;
          *puVar6 = local_118;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_110;
          *(int *)(puVar6 + 0xc) = local_10c;
          local_118 = uVar1;
          local_110 = fVar7;
          local_10c = uVar5;
          FUN_00019e9c(&local_110);
          local_120 = pfVar8[0x13];
          local_11c = (int)local_120 >> 0x1f;
          local_128 = 5;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_0001693c);
          uVar1 = *puVar6;
          *puVar6 = local_128;
          fVar7 = *(float *)(puVar6 + 8);
          uVar5 = *(undefined4 *)(puVar6 + 0xc);
          *(float *)(puVar6 + 8) = local_120;
          *(int *)(puVar6 + 0xc) = local_11c;
          local_128 = uVar1;
          local_120 = fVar7;
          local_11c = uVar5;
          FUN_00019e9c(&local_120);
          local_130 = (double)pfVar8[0x10];
          local_138 = 7;
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00015eab);
          uVar1 = *puVar6;
          *puVar6 = local_138;
          uVar2 = *(undefined8 *)(puVar6 + 8);
          *(undefined4 *)(puVar6 + 8) = (undefined4)local_130;
          *(undefined4 *)(puVar6 + 0xc) = local_130._4_4_;
          local_138 = uVar1;
          local_130 = (double)uVar2;
          FUN_00019e9c(&local_130);
          local_140 = (double)pfVar8[0x11];
          puVar6 = (undefined1 *)FUN_00019644(&local_48,&DAT_00016287);
          *puVar6 = 7;
          uVar2 = *(undefined8 *)(puVar6 + 8);
          *(undefined4 *)(puVar6 + 8) = (undefined4)local_140;
          *(undefined4 *)(puVar6 + 0xc) = local_140._4_4_;
          local_140 = (double)uVar2;
          FUN_00019e9c(&local_140);
          FUN_00019814(local_38,&local_48);
          FUN_00019e9c(local_40,local_48);
          pfVar8 = pfVar8 + 0x14;
        } while (pfVar8 != pfVar4);
        FUN_0001993c(&local_48,local_38,0xffffffff,0x20,0,0);
        puVar6 = local_40[0];
        if ((local_48 & 1) == 0) {
          puVar6 = auStack_47;
        }
        (**(code **)(*param_1 + 0x29c))(param_1,puVar6);
        if ((local_48 & 1) != 0) {
          free(local_40[0]);
        }
      }
      if (pfVar3 != (float *)0x0) {
        free(pfVar3);
      }
      FUN_00019e9c(&local_30,local_38[0]);
    }
  }
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_28);
  }
  return;
}


// ==== FUN_00019644 @ 00019644

void FUN_00019644(char *param_1,char *param_2)

{
  undefined4 *puVar1;
  size_t __n;
  void *__dest;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  uint uVar7;
  int *piVar8;
  undefined4 local_3c [3];
  undefined8 local_30;
  void *local_28;
  int local_24;
  
  local_24 = __stack_chk_guard;
  if (*param_1 == '\0') {
    *param_1 = '\x01';
    puVar1 = (undefined4 *)FUN_0001ee80(0xc);
    puVar1[1] = 0;
    puVar1[2] = 0;
    *puVar1 = puVar1 + 1;
    *(undefined4 **)(param_1 + 8) = puVar1;
  }
  else if (*param_1 != '\x01') {
    uVar4 = FUN_0001fcbc(0x10);
    uVar5 = FUN_0001a7e0(param_1);
    FUN_0001a758(local_3c,uVar5);
    puVar6 = (undefined8 *)
             FUN_0001f3aa(local_3c,0,"cannot use operator[] with a string argument with ");
    local_30 = *puVar6;
    local_28 = *(void **)(puVar6 + 1);
    *(undefined4 *)puVar6 = 0;
    *(undefined4 *)((int)puVar6 + 4) = 0;
    *(undefined4 *)(puVar6 + 1) = 0;
    FUN_0001a634(uVar4,0x131,&local_30);
    FUN_0001fcf8(uVar4,&PTR_PTR_00031404,0x1a7b9);
    goto LAB_000197ac;
  }
  piVar8 = *(int **)(param_1 + 8);
  __n = strlen(param_2);
  if (0xffffffef < __n) {
LAB_000197ac:
                    /* WARNING: Subroutine does not return */
    FUN_0001ef94(&local_30);
  }
  if (__n < 0xb) {
    local_30 = CONCAT71(local_30._1_7_,(char)(__n << 1));
    __dest = (void *)((int)&local_30 + 1);
    if (__n == 0) goto LAB_000196c8;
  }
  else {
    uVar7 = __n + 0x10 & 0xfffffff0;
    __dest = (void *)FUN_0001ee80(uVar7);
    local_30 = CONCAT44(__n,uVar7 + 1);
    local_28 = __dest;
  }
  memcpy(__dest,param_2,__n);
LAB_000196c8:
  *(undefined1 *)((int)__dest + __n) = 0;
  piVar2 = (int *)FUN_0001ae6c(piVar8,local_3c,&local_30);
  if (*piVar2 == 0) {
    puVar1 = (undefined4 *)FUN_0001ee80(0x30);
    puVar1[6] = local_28;
    puVar1[10] = 0;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = local_3c[0];
    *(ulonglong *)(puVar1 + 4) = local_30;
    local_30 = 0;
    local_28 = (void *)0x0;
    *piVar2 = (int)puVar1;
    iVar3 = *(int *)*piVar8;
    *(undefined1 *)(puVar1 + 8) = 0;
    if (iVar3 != 0) {
      *piVar8 = iVar3;
      puVar1 = (undefined4 *)*piVar2;
    }
    FUN_0001af34(piVar8[1],puVar1);
    piVar8[2] = piVar8[2] + 1;
  }
  if ((local_30 & 1) != 0) {
    free(local_28);
  }
  if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_24);
  }
  return;
}


// ==== FUN_00019814 @ 00019814

void FUN_00019814(char *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  uint uVar6;
  undefined1 auStack_34 [12];
  undefined8 local_28;
  undefined4 local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  if (*param_1 == '\0') {
    *param_1 = '\x02';
    puVar1 = (undefined4 *)FUN_0001ee80(0xc);
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    *(undefined4 **)(param_1 + 8) = puVar1;
    uVar6 = puVar1[1];
    if ((uint)puVar1[2] <= uVar6) {
LAB_0001986c:
      FUN_0001b1d8(puVar1,param_2);
      iVar2 = puVar1[1];
      goto LAB_00019876;
    }
  }
  else {
    if (*param_1 != '\x02') {
      uVar3 = FUN_0001fcbc(0x10);
      uVar4 = FUN_0001a7e0(param_1);
      FUN_0001a758(auStack_34,uVar4);
      puVar5 = (undefined8 *)FUN_0001f3aa(auStack_34,0,"cannot use emplace_back() with ");
      local_28 = *puVar5;
      local_20 = *(undefined4 *)(puVar5 + 1);
      *(undefined4 *)puVar5 = 0;
      *(undefined4 *)((int)puVar5 + 4) = 0;
      *(undefined4 *)(puVar5 + 1) = 0;
      FUN_0001a634(uVar3,0x137,&local_28);
      FUN_0001fcf8(uVar3,&PTR_PTR_00031404,0x1a7b9);
      pcRam00000004 = param_1;
                    /* WARNING: Subroutine does not return */
      FUN_0001fc74();
    }
    puVar1 = *(undefined4 **)(param_1 + 8);
    uVar6 = puVar1[1];
    if ((uint)puVar1[2] <= uVar6) goto LAB_0001986c;
  }
  FUN_0001a9d8(uVar6,param_2);
  iVar2 = uVar6 + 0x10;
  puVar1[1] = iVar2;
LAB_00019876:
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar2);
  }
  return;
}


// ==== FUN_0001993c @ 0001993c

void FUN_0001993c(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  bool bVar1;
  int *piVar2;
  void *pvVar3;
  int *piVar4;
  int iVar5;
  int *local_288;
  int *local_284;
  undefined4 local_280;
  undefined4 uStack_27c;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined4 local_270;
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined4 local_260;
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 local_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 *local_240;
  undefined1 local_23c;
  undefined1 local_23b;
  undefined1 auStack_23a [512];
  undefined1 local_3a;
  uint local_38;
  undefined4 local_34;
  void *local_30;
  undefined4 local_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  piVar2 = (int *)FUN_0001ee80(0x14);
  piVar2[2] = 0;
  piVar2[4] = (int)param_1;
  *piVar2 = (int)&PTR_LAB_0001c08e_1_00031440;
  local_288 = piVar2 + 3;
  *local_288 = (int)&PTR_LAB_0001c0ae_1_0003145c;
  piVar4 = piVar2 + 1;
  *piVar4 = 0;
  do {
    ExclusiveAccess(piVar4);
    bVar1 = (bool)hasExclusiveAccess(piVar4);
  } while (!bVar1);
  *piVar4 = *piVar4 + 1;
  uStack_27c = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
  uStack_278 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
  uStack_274 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
  local_280 = 0;
  local_270 = 0;
  local_260 = 0;
  local_250 = 0;
  local_284 = piVar2;
  uStack_26c = uStack_27c;
  uStack_268 = uStack_278;
  uStack_264 = uStack_274;
  uStack_25c = uStack_27c;
  uStack_258 = uStack_278;
  uStack_254 = uStack_274;
  uStack_24c = uStack_27c;
  uStack_248 = uStack_278;
  uStack_244 = uStack_274;
  local_240 = (undefined4 *)FUN_00029b08();
  if ((undefined1 *)local_240[1] == (undefined1 *)0x0) {
    local_23c = 0;
  }
  else {
    local_23c = *(undefined1 *)local_240[1];
  }
  if ((undefined1 *)*local_240 == (undefined1 *)0x0) {
    local_23b = 0;
  }
  else {
    local_23b = *(undefined1 *)*local_240;
  }
  FUN_0002a2f8(auStack_23a,0x200);
  local_3a = (undefined1)param_4;
  pvVar3 = (void *)FUN_0001ee80(0x210);
  local_38 = 0x211;
  local_34 = 0x200;
  local_30 = pvVar3;
  FUN_0002a2e8(pvVar3,0x200,param_4);
  *(undefined1 *)((int)pvVar3 + 0x200) = 0;
  local_2c = param_6;
  piVar4 = piVar2 + 1;
  DataMemoryBarrier(0x1b);
  do {
    ExclusiveAccess(piVar4);
    iVar5 = *piVar4;
    bVar1 = (bool)hasExclusiveAccess(piVar4);
  } while (!bVar1);
  *piVar4 = iVar5 + -1;
  DataMemoryBarrier(0x1b);
  if (iVar5 == 0) {
    (**(code **)(*piVar2 + 8))(piVar2);
    FUN_0001ee0e(piVar2);
  }
  if (param_3 < 0) {
    FUN_0001b390(&local_288,param_2,0,param_5,0,0);
  }
  else {
    FUN_0001b390(&local_288,param_2,1,param_5,param_3,0);
  }
  if ((local_38 & 1) != 0) {
    free(local_30);
  }
  piVar4 = local_284;
  if (local_284 != (int *)0x0) {
    piVar2 = local_284 + 1;
    DataMemoryBarrier(0x1b);
    do {
      ExclusiveAccess(piVar2);
      iVar5 = *piVar2;
      bVar1 = (bool)hasExclusiveAccess(piVar2);
    } while (!bVar1);
    *piVar2 = iVar5 + -1;
    DataMemoryBarrier(0x1b);
    if (iVar5 == 0) {
      (**(code **)(*local_284 + 8))(local_284);
      FUN_0001ee0e(piVar4);
    }
  }
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== JNI_OnLoad @ 00019ce4

void JNI_OnLoad(int *param_1)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *local_6c;
  char local_68 [48];
  char local_38 [28];
  int local_1c;
  
  local_1c = __stack_chk_guard;
  iVar2 = (**(code **)(*param_1 + 0x18))(param_1,&local_6c,0x10004);
  if (iVar2 == 0) {
    iVar2 = (**(code **)(*local_6c + 0x18))(local_6c,"com/netease/mobsec/xt/a");
    iVar3 = (**(code **)(*local_6c + 0x3c))(local_6c);
    if (iVar3 == 0) {
      if ((iVar2 != 0) &&
         (iVar2 = (**(code **)(*local_6c + 0x35c))(local_6c,iVar2,&PTR_DAT_000313d4,3), -1 < iVar2))
      {
        uVar5 = 0xda;
        local_38[0] = -0x26;
        local_38[1] = -0x59;
        local_38[2] = -0x14;
        local_38[3] = -0x2c;
        local_38[4] = -0x15;
        local_38[5] = -0x2e;
        local_38[6] = -0x2f;
        local_38[7] = '\x18';
        local_38[8] = '\x1b';
        local_38[9] = '.';
        local_38[10] = 'E';
        local_38[0xb] = 'P';
        local_38[0xc] = -0x31;
        local_38[0xd] = -0x1a;
        local_38[0xe] = '\x0e';
        local_38[0xf] = -0x6c;
        local_38[0x10] = -0x76;
        local_38[0x11] = '=';
        local_38[0x12] = 'u';
        local_38[0x13] = ';';
        local_38[0x14] = -0x76;
        local_38[0x15] = '\x12';
        local_38[0x16] = -7;
        local_38[0x17] = 'G';
        local_38[0x18] = 'J';
        local_38[0x19] = -0x3c;
        uVar4 = 0;
        while( true ) {
          uVar5 = uVar5 ^ uVar4 ^ 0xffffff9d;
          uVar5 = 2 - (uVar5 << 5 | (uVar5 & 0xff) >> 3);
          bVar1 = (byte)uVar4;
          local_38[uVar4] =
               (-((((char)uVar5 * '\x02' | (byte)((uVar5 & 0xff) >> 7)) ^ bVar1) + bVar1) ^ 0xe2) -
               bVar1;
          if (uVar4 == 0x19) break;
          uVar5 = (uint)(byte)local_38[uVar4 + 1];
          uVar4 = uVar4 + 1;
        }
        uVar5 = 0xf3;
        local_68[0] = -0xd;
        local_68[1] = -0x31;
        local_68[2] = -0x79;
        local_68[3] = 'T';
        local_68[4] = '{';
        local_68[5] = '\x0f';
        local_68[6] = '\x7f';
        local_68[7] = -0x48;
        local_68[8] = '\x13';
        local_68[9] = '\v';
        local_68[10] = 'o';
        local_68[0xb] = -0x55;
        local_68[0xc] = -0x65;
        local_68[0xd] = -0x75;
        local_68[0xe] = '\x13';
        local_68[0xf] = -0x60;
        local_68[0x10] = 'K';
        local_68[0x11] = '3';
        local_68[0x12] = 'G';
        local_68[0x13] = -0x25;
        local_68[0x14] = -0x50;
        local_68[0x15] = 'k';
        local_68[0x16] = 'G';
        local_68[0x17] = -0x40;
        local_68[0x18] = 0xb7;
        local_68[0x19] = 'c';
        local_68[0x1a] = 'S';
        local_68[0x1b] = '_';
        local_68[0x1c] = -0x44;
        local_68[0x1d] = -0x11;
        local_68[0x1e] = -0x28;
        local_68[0x1f] = 'S';
        local_68[0x20] = 0x3b;
        local_68[0x21] = -0x65;
        local_68[0x22] = -0x41;
        local_68[0x23] = -0x7d;
        local_68[0x24] = '#';
        local_68[0x25] = '8';
        local_68[0x26] = 's';
        local_68[0x27] = -8;
        local_68[0x28] = -0x2e;
        for (uVar4 = 0; uVar5 = uVar5 - 1 ^ 0x5d,
            uVar5 = -(((uVar5 << 7 | (uVar5 & 0xff) >> 1) ^ uVar4) + uVar4) - 10,
            uVar5 = (uVar5 * 2 | (uVar5 & 0xff) >> 7) + 4,
            local_68[uVar4] = (((char)uVar5 * '@' | (byte)((uVar5 & 0xff) >> 2)) ^ 0xce) + 1,
            uVar4 != 0x28; uVar4 = uVar4 + 1) {
          uVar5 = (uint)(byte)local_68[uVar4 + 1];
        }
        iVar2 = thunk_FUN_0001d0e0(local_38,local_68,&LAB_00019b24_1,&DAT_00036a44);
        if (iVar2 == 0) {
          thunk_FUN_0001d740(1);
          iVar2 = thunk_FUN_0001d1e4(0);
          if (iVar2 == 0) {
            thunk_FUN_0001d31c();
            DataMemoryBarrier(0x1b);
            DAT_00036a40 = 1;
            DataMemoryBarrier(0x1b);
          }
        }
      }
    }
    else {
      (**(code **)(*local_6c + 0x44))(local_6c);
    }
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_1c);
  }
  return;
}


// ==== FUN_00019e94 @ 00019e94

void FUN_00019e94(void)

{
  FUN_0001fe34();
                    /* WARNING: Subroutine does not return */
  FUN_00020238();
}


// ==== FUN_00019e9c @ 00019e9c

void FUN_00019e9c(int *param_1,int param_2)

{
  uint uVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined1 *puVar8;
  undefined1 *puVar9;
  void *__ptr;
  undefined4 uVar10;
  undefined1 *puVar11;
  undefined1 *puVar12;
  undefined1 *puVar13;
  int *piVar14;
  undefined1 *puVar15;
  undefined4 *puVar16;
  uint uVar17;
  int iVar18;
  byte *__ptr_00;
  undefined1 *puVar19;
  int *piVar20;
  int *piVar21;
  bool bVar22;
  undefined4 *local_40;
  undefined4 local_3c;
  undefined1 *local_34;
  undefined1 *local_30;
  undefined1 *local_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  local_2c = (undefined1 *)0x0;
  local_34 = (undefined1 *)0x0;
  local_30 = (undefined1 *)0x0;
  if (param_2 == 1) {
    puVar16 = (undefined4 *)*param_1;
    uVar17 = puVar16[2];
    if (uVar17 == 0) {
      piVar20 = (int *)*puVar16;
      if (piVar20 != puVar16 + 1) goto LAB_00019f76;
    }
    else {
      if (0xfffffff < uVar17) {
                    /* WARNING: Subroutine does not return */
        FUN_0001a480("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
      local_34 = (undefined1 *)FUN_0001ee80(uVar17 << 4);
      local_2c = local_34 + uVar17 * 0x10;
      piVar20 = (int *)*puVar16;
      local_30 = local_34;
      if (piVar20 != puVar16 + 1) {
LAB_00019f76:
        local_34 = local_30;
        if (local_2c <= local_30) goto LAB_00019f9c;
        do {
          *local_30 = (char)piVar20[8];
          iVar18 = piVar20[0xb];
          *(int *)(local_30 + 8) = piVar20[10];
          *(int *)(local_30 + 0xc) = iVar18;
          local_30 = local_30 + 0x10;
          piVar20[10] = 0;
          piVar20[0xb] = 0;
          *(undefined1 *)(piVar20 + 8) = 0;
          piVar14 = piVar20;
          while( true ) {
            piVar6 = (int *)piVar14[1];
            if ((int *)piVar14[1] == (int *)0x0) {
              piVar6 = piVar14 + 2;
              piVar20 = (int *)*piVar6;
              if ((int *)*piVar20 != piVar14) {
                do {
                  iVar18 = *piVar6;
                  piVar6 = (int *)(iVar18 + 8);
                  piVar20 = (int *)*piVar6;
                } while (*piVar20 != iVar18);
              }
            }
            else {
              do {
                piVar20 = piVar6;
                piVar6 = (int *)*piVar20;
              } while ((int *)*piVar20 != (int *)0x0);
            }
            if (piVar20 == puVar16 + 1) goto LAB_00019fde;
            if (local_30 < local_2c) break;
LAB_00019f9c:
            FUN_0001a4d0(&local_34,piVar20 + 8);
            piVar14 = piVar20;
          }
        } while( true );
      }
    }
  }
  else if (param_2 == 2) {
    puVar16 = (undefined4 *)*param_1;
    puVar13 = (undefined1 *)*puVar16;
    puVar15 = (undefined1 *)puVar16[1];
    iVar18 = (int)puVar15 - (int)puVar13;
    if (iVar18 == 0) {
      if (puVar13 != puVar15) goto LAB_00019f30;
    }
    else {
      if (iVar18 < 0) {
                    /* WARNING: Subroutine does not return */
        FUN_0001a480("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
      local_34 = (undefined1 *)FUN_0001ee80(iVar18);
      local_2c = local_34 + (iVar18 >> 4) * 0x10;
      puVar15 = (undefined1 *)puVar16[1];
      puVar13 = (undefined1 *)*puVar16;
      local_30 = local_34;
      if (puVar13 != puVar15) {
LAB_00019f30:
        local_34 = local_30;
        if (local_2c <= local_30) goto LAB_00019f52;
        do {
          *local_30 = *puVar13;
          uVar10 = *(undefined4 *)(puVar13 + 0xc);
          *(undefined4 *)(local_30 + 8) = *(undefined4 *)(puVar13 + 8);
          *(undefined4 *)(local_30 + 0xc) = uVar10;
          local_30 = local_30 + 0x10;
          *(undefined4 *)(puVar13 + 8) = 0;
          *(undefined4 *)(puVar13 + 0xc) = 0;
          *puVar13 = 0;
          while( true ) {
            puVar13 = puVar13 + 0x10;
            if (puVar13 == puVar15) goto LAB_00019fde;
            if (local_30 < local_2c) break;
LAB_00019f52:
            FUN_0001a4d0(&local_34,puVar13);
          }
        } while( true );
      }
    }
  }
LAB_00019fde:
  if (local_34 != local_30) {
    do {
      cVar4 = local_30[-0x10];
      local_40 = *(undefined4 **)(local_30 + -8);
      local_3c = *(undefined4 *)(local_30 + -4);
      *(undefined4 *)(local_30 + -8) = 0;
      *(undefined4 *)(local_30 + -4) = 0;
      local_30[-0x10] = 0;
      puVar13 = local_30 + -0x10;
      FUN_00019e9c(local_30 + -8,*puVar13);
      local_30 = puVar13;
      if (cVar4 == '\x01') {
        piVar14 = local_40 + 1;
        piVar20 = (int *)*local_40;
        if (piVar20 != piVar14) {
          if (local_2c <= puVar13) goto LAB_0001a192;
LAB_0001a16c:
          *local_30 = (char)piVar20[8];
          iVar18 = piVar20[0xb];
          *(int *)(local_30 + 8) = piVar20[10];
          *(int *)(local_30 + 0xc) = iVar18;
          local_30 = local_30 + 0x10;
          piVar20[10] = 0;
          piVar20[0xb] = 0;
          *(undefined1 *)(piVar20 + 8) = 0;
          piVar6 = (int *)piVar20[1];
          piVar21 = piVar20;
          if ((int *)piVar20[1] != (int *)0x0) goto LAB_0001a254;
          do {
            piVar6 = piVar21 + 2;
            piVar20 = (int *)*piVar6;
            if ((int *)*piVar20 != piVar21) {
              do {
                iVar18 = *piVar6;
                piVar6 = (int *)(iVar18 + 8);
                piVar20 = (int *)*piVar6;
              } while (*piVar20 != iVar18);
            }
            while( true ) {
              if (piVar20 == piVar14) goto LAB_0001a2b6;
              if (local_30 < local_2c) goto LAB_0001a16c;
LAB_0001a192:
              puVar15 = local_30;
              puVar13 = local_34;
              iVar18 = (int)local_30 - (int)local_34 >> 4;
              uVar17 = iVar18 + 1;
              if (0xfffffff < uVar17) {
                FUN_0001fc64(&local_34);
                goto LAB_0001a3aa;
              }
              uVar1 = (int)local_2c - (int)local_34 >> 3;
              if (uVar17 <= uVar1) {
                uVar17 = uVar1;
              }
              if (0x7fffffef < (uint)((int)local_2c - (int)local_34)) {
                uVar17 = 0xfffffff;
              }
              if (0xfffffff < uVar17) goto LAB_0001a3b0;
              iVar7 = FUN_0001ee80(uVar17 << 4);
              puVar19 = local_34;
              puVar12 = (undefined1 *)(iVar7 + iVar18 * 0x10);
              *(char *)(iVar7 + iVar18 * 0x10) = (char)piVar20[8];
              iVar18 = piVar20[0xb];
              *(int *)(puVar12 + 8) = piVar20[10];
              *(int *)(puVar12 + 0xc) = iVar18;
              local_2c = (undefined1 *)(iVar7 + uVar17 * 0x10);
              puVar9 = puVar12 + 0x10;
              piVar20[10] = 0;
              piVar20[0xb] = 0;
              *(undefined1 *)(piVar20 + 8) = 0;
              if (puVar15 == puVar13) {
                puVar19 = puVar15;
                local_34 = puVar12;
              }
              else {
                do {
                  puVar11 = puVar15 + -0x10;
                  puVar8 = puVar12 + -0x10;
                  *puVar8 = *puVar11;
                  uVar10 = *(undefined4 *)(puVar15 + -4);
                  *(undefined4 *)(puVar12 + -8) = *(undefined4 *)(puVar15 + -8);
                  *(undefined4 *)(puVar12 + -4) = uVar10;
                  *(undefined4 *)(puVar15 + -8) = 0;
                  *(undefined4 *)(puVar15 + -4) = 0;
                  *puVar11 = 0;
                  puVar12 = puVar8;
                  puVar15 = puVar11;
                } while (puVar11 != puVar13);
                bVar22 = local_30 != local_34;
                local_34 = puVar8;
                if (bVar22) {
                  puVar13 = local_30 + -8;
                  local_30 = puVar9;
                  do {
                    puVar15 = puVar13 + -8;
                    FUN_00019e9c(puVar13,*puVar15);
                    puVar13 = puVar13 + -0x10;
                    puVar9 = local_30;
                  } while (puVar15 != puVar19);
                }
              }
              local_30 = puVar9;
              if (puVar19 != (undefined1 *)0x0) {
                free(puVar19);
              }
              piVar6 = (int *)piVar20[1];
              piVar21 = piVar20;
              if ((int *)piVar20[1] == (int *)0x0) break;
LAB_0001a254:
              do {
                piVar20 = piVar6;
                piVar6 = (int *)*piVar20;
              } while ((int *)*piVar20 != (int *)0x0);
            }
          } while( true );
        }
LAB_0001a2b6:
        puVar5 = local_40;
        puVar16 = local_40 + 1;
        FUN_0001a5b4(local_40,*puVar16);
        *puVar16 = 0;
        *puVar5 = puVar16;
        puVar5[2] = 0;
      }
      else if (cVar4 == '\x02') {
        puVar15 = (undefined1 *)*local_40;
        puVar16 = local_40 + 1;
        puVar19 = (undefined1 *)*puVar16;
        if (puVar15 != puVar19) {
          if (local_2c <= puVar13) goto LAB_0001a086;
          do {
            *puVar13 = *puVar15;
            uVar10 = *(undefined4 *)(puVar15 + 0xc);
            *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar15 + 8);
            *(undefined4 *)(puVar13 + 0xc) = uVar10;
            *puVar15 = 0;
            *(undefined4 *)(puVar15 + 8) = 0;
            *(undefined4 *)(puVar15 + 0xc) = 0;
            puVar13 = puVar13 + 0x10;
            while( true ) {
              puVar15 = puVar15 + 0x10;
              local_30 = puVar13;
              if (puVar15 == puVar19) {
                puVar15 = (undefined1 *)*local_40;
                puVar16 = local_40 + 1;
                if ((undefined1 *)*puVar16 != puVar15) {
                  puVar13 = (undefined1 *)*puVar16 + -8;
                  do {
                    puVar19 = puVar13 + -8;
                    FUN_00019e9c(puVar13,*puVar19);
                    puVar13 = puVar13 + -0x10;
                  } while (puVar19 != puVar15);
                }
                goto LAB_00019ff8;
              }
              if (puVar13 < local_2c) break;
LAB_0001a086:
              puVar12 = local_30;
              puVar13 = local_34;
              iVar18 = (int)local_30 - (int)local_34 >> 4;
              uVar17 = iVar18 + 1;
              if (0xfffffff < uVar17) {
LAB_0001a3aa:
                FUN_0001fc64(&local_34);
LAB_0001a3b0:
                    /* WARNING: Subroutine does not return */
                FUN_0001a480("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size"
                            );
              }
              uVar1 = (int)local_2c - (int)local_34 >> 3;
              if (uVar17 <= uVar1) {
                uVar17 = uVar1;
              }
              if (0x7fffffef < (uint)((int)local_2c - (int)local_34)) {
                uVar17 = 0xfffffff;
              }
              if (0xfffffff < uVar17) {
                    /* WARNING: Subroutine does not return */
                FUN_0001a480("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size"
                            );
              }
              iVar7 = FUN_0001ee80(uVar17 << 4);
              puVar9 = local_34;
              puVar11 = (undefined1 *)(iVar7 + iVar18 * 0x10);
              *(undefined1 *)(iVar7 + iVar18 * 0x10) = *puVar15;
              uVar10 = *(undefined4 *)(puVar15 + 0xc);
              *(undefined4 *)(puVar11 + 8) = *(undefined4 *)(puVar15 + 8);
              *(undefined4 *)(puVar11 + 0xc) = uVar10;
              local_2c = (undefined1 *)(iVar7 + uVar17 * 0x10);
              puVar8 = puVar11 + 0x10;
              *(undefined4 *)(puVar15 + 8) = 0;
              *(undefined4 *)(puVar15 + 0xc) = 0;
              *puVar15 = 0;
              if (puVar12 == puVar13) {
                puVar9 = puVar12;
                local_34 = puVar11;
              }
              else {
                do {
                  puVar2 = puVar12 + -0x10;
                  puVar3 = puVar11 + -0x10;
                  *puVar3 = *puVar2;
                  uVar10 = *(undefined4 *)(puVar12 + -4);
                  *(undefined4 *)(puVar11 + -8) = *(undefined4 *)(puVar12 + -8);
                  *(undefined4 *)(puVar11 + -4) = uVar10;
                  *(undefined4 *)(puVar12 + -8) = 0;
                  *(undefined4 *)(puVar12 + -4) = 0;
                  *puVar2 = 0;
                  puVar11 = puVar3;
                  puVar12 = puVar2;
                } while (puVar2 != puVar13);
                bVar22 = local_30 != local_34;
                local_34 = puVar3;
                if (bVar22) {
                  puVar13 = local_30 + -8;
                  local_30 = puVar8;
                  do {
                    puVar12 = puVar13 + -8;
                    FUN_00019e9c(puVar13,*puVar12);
                    puVar13 = puVar13 + -0x10;
                    puVar8 = local_30;
                  } while (puVar12 != puVar9);
                }
              }
              local_30 = puVar8;
              puVar13 = local_30;
              if (puVar9 != (undefined1 *)0x0) {
                free(puVar9);
                puVar13 = local_30;
              }
            }
          } while( true );
        }
LAB_00019ff8:
        *puVar16 = puVar15;
      }
      FUN_00019e9c(&local_40,cVar4);
    } while (local_34 != local_30);
  }
  switch(param_2) {
  case 1:
    FUN_0001a5b4(*param_1,*(undefined4 *)(*param_1 + 4));
LAB_0001a356:
    __ptr_00 = (byte *)*param_1;
    break;
  case 2:
    __ptr_00 = (byte *)*param_1;
    puVar13 = *(undefined1 **)__ptr_00;
    if (puVar13 != (undefined1 *)0x0) {
      puVar15 = puVar13;
      if (*(undefined1 **)(__ptr_00 + 4) != puVar13) {
        puVar15 = *(undefined1 **)(__ptr_00 + 4) + -8;
        do {
          puVar19 = puVar15 + -8;
          FUN_00019e9c(puVar15,*puVar19);
          puVar15 = puVar15 + -0x10;
        } while (puVar19 != puVar13);
        puVar15 = *(undefined1 **)__ptr_00;
      }
      *(undefined1 **)(__ptr_00 + 4) = puVar13;
      free(puVar15);
      __ptr_00 = (byte *)*param_1;
    }
    break;
  case 3:
    __ptr_00 = (byte *)*param_1;
    if ((*__ptr_00 & 1) != 0) {
      __ptr = *(void **)(__ptr_00 + 8);
LAB_0001a352:
      free(__ptr);
      goto LAB_0001a356;
    }
    break;
  default:
    goto switchD_0001a2d6_caseD_4;
  case 8:
    __ptr_00 = (byte *)*param_1;
    __ptr = *(void **)__ptr_00;
    if (__ptr != (void *)0x0) {
      *(void **)(__ptr_00 + 4) = __ptr;
      goto LAB_0001a352;
    }
  }
  free(__ptr_00);
switchD_0001a2d6_caseD_4:
  puVar13 = local_34;
  if (local_34 != (undefined1 *)0x0) {
    if (local_30 != local_34) {
      puVar15 = local_30 + -8;
      do {
        puVar19 = puVar15 + -8;
        FUN_00019e9c(puVar15,*puVar19);
        puVar15 = puVar15 + -0x10;
      } while (puVar19 != puVar13);
    }
    local_30 = puVar13;
    free(local_34);
  }
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001a410 @ 0001a410

undefined4 * FUN_0001a410(undefined4 *param_1)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  puVar3 = (undefined1 *)*param_1;
  if (puVar3 != (undefined1 *)0x0) {
    puVar2 = puVar3;
    if ((undefined1 *)param_1[1] != puVar3) {
      puVar2 = (undefined1 *)param_1[1] + -8;
      do {
        puVar1 = puVar2 + -8;
        FUN_00019e9c(puVar2,*puVar1);
        puVar2 = puVar2 + -0x10;
      } while (puVar1 != puVar3);
      puVar2 = (undefined1 *)*param_1;
    }
    param_1[1] = puVar3;
    free(puVar2);
  }
  return param_1;
}


// ==== FUN_0001a452 @ 0001a452

undefined4 * FUN_0001a452(undefined4 *param_1)

{
  undefined1 uVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = param_1[1];
  iVar2 = param_1[2];
  while (iVar2 != iVar3) {
    uVar1 = *(undefined1 *)(iVar2 + -0x10);
    param_1[2] = (undefined1 *)(iVar2 + -0x10);
    FUN_00019e9c(iVar2 + -8,uVar1);
    iVar2 = param_1[2];
  }
  if ((void *)*param_1 != (void *)0x0) {
    free((void *)*param_1);
  }
  return param_1;
}


// ==== FUN_0001a480 @ 0001a480

void FUN_0001a480(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0001fcbc(8);
  FUN_0001a4b8(uVar1,param_1);
  FUN_0001fcf8(uVar1,&PTR_PTR_000326cc,FUN_00029a3c + 1);
  FUN_0001fce6(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0001fc74();
}


// ==== FUN_0001a4b8 @ 0001a4b8

void FUN_0001a4b8(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_0001ef04();
  *puVar1 = &PTR_FUN_00029a3c_1_000326c0;
  return;
}


// ==== FUN_0001a4d0 @ 0001a4d0

void FUN_0001a4d0(int *param_1,undefined1 *param_2)

{
  int iVar1;
  uint uVar2;
  undefined1 *puVar3;
  undefined1 *puVar4;
  int iVar5;
  uint uVar6;
  undefined1 *puVar7;
  undefined1 *puVar8;
  undefined4 uVar9;
  undefined1 *__ptr;
  uint uVar10;
  undefined1 *puVar11;
  undefined4 uVar12;
  
  iVar1 = param_1[1] - *param_1 >> 4;
  uVar10 = iVar1 + 1;
  if (uVar10 < 0x10000000) {
    uVar6 = param_1[2] - *param_1;
    uVar2 = (int)uVar6 >> 3;
    if (uVar10 <= uVar2) {
      uVar10 = uVar2;
    }
    if (0x7fffffef < uVar6) {
      uVar10 = 0xfffffff;
    }
    if (uVar10 < 0x10000000) {
      iVar5 = FUN_0001ee80(uVar10 << 4);
      *(undefined1 *)(iVar5 + iVar1 * 0x10) = *param_2;
      puVar7 = (undefined1 *)(iVar5 + iVar1 * 0x10);
      uVar12 = *(undefined4 *)(param_2 + 8);
      uVar9 = *(undefined4 *)(param_2 + 0xc);
      iVar5 = iVar5 + uVar10 * 0x10;
      *(undefined4 *)(param_2 + 8) = 0;
      *(undefined4 *)(param_2 + 0xc) = 0;
      *param_2 = 0;
      __ptr = (undefined1 *)*param_1;
      puVar11 = (undefined1 *)param_1[1];
      *(undefined4 *)(puVar7 + 8) = uVar12;
      *(undefined4 *)(puVar7 + 0xc) = uVar9;
      puVar8 = puVar7;
      if (puVar11 == __ptr) {
        *param_1 = (int)puVar7;
        param_1[1] = (int)(puVar7 + 0x10);
        param_1[2] = iVar5;
      }
      else {
        do {
          puVar3 = puVar11 + -0x10;
          puVar4 = puVar8 + -0x10;
          *puVar4 = *puVar3;
          uVar9 = *(undefined4 *)(puVar11 + -4);
          *(undefined4 *)(puVar8 + -8) = *(undefined4 *)(puVar11 + -8);
          *(undefined4 *)(puVar8 + -4) = uVar9;
          *(undefined4 *)(puVar11 + -8) = 0;
          *(undefined4 *)(puVar11 + -4) = 0;
          *puVar3 = 0;
          puVar8 = puVar4;
          puVar11 = puVar3;
        } while (puVar3 != __ptr);
        __ptr = (undefined1 *)*param_1;
        puVar8 = (undefined1 *)param_1[1];
        *param_1 = (int)puVar4;
        param_1[1] = (int)(puVar7 + 0x10);
        param_1[2] = iVar5;
        if (puVar8 != __ptr) {
          puVar8 = puVar8 + -8;
          do {
            puVar11 = puVar8 + -8;
            FUN_00019e9c(puVar8,*puVar11);
            puVar8 = puVar8 + -0x10;
          } while (puVar11 != __ptr);
        }
      }
      if (__ptr == (undefined1 *)0x0) {
        return;
      }
      free(__ptr);
      return;
    }
  }
  else {
    FUN_0001fc64(param_1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0001a480("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
}


// ==== FUN_0001a5b4 @ 0001a5b4

void FUN_0001a5b4(undefined4 param_1,undefined4 *param_2)

{
  if (param_2 == (undefined4 *)0x0) {
    return;
  }
  FUN_0001a5b4(param_1,*param_2);
  FUN_0001a5b4(param_1,param_2[1]);
  FUN_00019e9c(param_2 + 10,*(undefined1 *)(param_2 + 8));
  if ((*(byte *)(param_2 + 4) & 1) != 0) {
    free((void *)param_2[6]);
  }
  free(param_2);
  return;
}


// ==== FUN_0001a5f2 @ 0001a5f2

undefined4 * FUN_0001a5f2(undefined4 *param_1)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  puVar3 = (undefined1 *)*param_1;
  if (puVar3 != (undefined1 *)0x0) {
    puVar2 = puVar3;
    if ((undefined1 *)param_1[1] != puVar3) {
      puVar2 = (undefined1 *)param_1[1] + -8;
      do {
        puVar1 = puVar2 + -8;
        FUN_00019e9c(puVar2,*puVar1);
        puVar2 = puVar2 + -0x10;
      } while (puVar1 != puVar3);
      puVar2 = (undefined1 *)*param_1;
    }
    param_1[1] = puVar3;
    free(puVar2);
  }
  return param_1;
}


// ==== FUN_0001a634 @ 0001a634

void FUN_0001a634(undefined4 *param_1,undefined4 param_2,byte *param_3)

{
  ulonglong *puVar1;
  byte *pbVar2;
  void *pvVar3;
  uint uVar4;
  byte local_40 [9];
  undefined2 uStack_37;
  undefined1 uStack_35;
  byte local_34 [8];
  void *local_2c;
  undefined8 local_28;
  void *local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  local_40[1] = 0x74;
  local_40[2] = 0x79;
  local_40[3] = 0x70;
  local_40[4] = 0x65;
  local_40[5] = 0x5f;
  local_40[6] = 0x65;
  local_40[7] = 0x72;
  local_40[8] = 0x72;
  local_40[0] = 0x14;
  uStack_37 = 0x726f;
  uStack_35 = 0;
  FUN_0001a838(local_34,local_40,param_2);
  uVar4 = *(uint *)(param_3 + 4);
  pbVar2 = *(byte **)(param_3 + 8);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar4 = (uint)(*param_3 >> 1);
  }
  puVar1 = (ulonglong *)FUN_0001f32c(local_34,pbVar2,uVar4);
  local_28 = *puVar1;
  local_20 = *(void **)(puVar1 + 1);
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)((int)puVar1 + 4) = 0;
  *(undefined4 *)(puVar1 + 1) = 0;
  if ((local_34[0] & 1) != 0) {
    free(local_2c);
  }
  if ((local_40[0] & 1) != 0) {
    free((void *)CONCAT13(uStack_35,CONCAT21(uStack_37,local_40[8])));
  }
  *param_1 = &PTR_FUN_0001a7b8_1_0003142c;
  param_1[1] = param_2;
  pvVar3 = local_20;
  if ((local_28 & 1) == 0) {
    pvVar3 = (void *)((int)&local_28 + 1);
  }
  FUN_0001ef68(param_1 + 2,pvVar3);
  *param_1 = &PTR_FUN_0001a7b8_1_00031418;
  if ((local_28 & 1) != 0) {
    free(local_20);
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001a758 @ 0001a758

int * FUN_0001a758(int *param_1,char *param_2)

{
  size_t __n;
  undefined1 *__dest;
  uint uVar1;
  
  __n = strlen(param_2);
  if (0xffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0001ef94(param_1);
  }
  if (__n < 0xb) {
    __dest = (undefined1 *)((int)param_1 + 1);
    *(char *)param_1 = (char)(__n << 1);
    if (__n == 0) goto LAB_0001a7a6;
  }
  else {
    uVar1 = __n + 0x10 & 0xfffffff0;
    __dest = (undefined1 *)FUN_0001ee80(uVar1);
    *param_1 = uVar1 + 1;
    param_1[1] = __n;
    param_1[2] = (int)__dest;
  }
  memcpy(__dest,param_2,__n);
LAB_0001a7a6:
  __dest[__n] = 0;
  return param_1;
}


// ==== FUN_0001a7b8 @ 0001a7b8

void FUN_0001a7b8(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_0001a7b8_1_0003142c;
  FUN_00029aa8(param_1 + 2);
  FUN_00029a0a(param_1);
  return;
}


// ==== FUN_0001a7e0 @ 0001a7e0

char * FUN_0001a7e0(char *param_1)

{
  if ((uint)(int)*param_1 < 10) {
    return (&PTR_DAT_0003146c)[*param_1];
  }
  return "number";
}


// ==== FUN_0001a800 @ 0001a800

void FUN_0001a800(undefined8 *param_1,undefined4 param_2,byte *param_3)

{
  undefined8 *puVar1;
  byte *pbVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined8 uVar5;
  
  uVar4 = *(uint *)(param_3 + 4);
  pbVar2 = *(byte **)(param_3 + 8);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar4 = (uint)(*param_3 >> 1);
  }
  puVar1 = (undefined8 *)FUN_0001f32c(param_2,pbVar2,uVar4);
  uVar5 = *puVar1;
  uVar3 = *(undefined4 *)(puVar1 + 1);
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)((int)puVar1 + 4) = 0;
  *(undefined4 *)(puVar1 + 1) = 0;
  *(undefined4 *)(param_1 + 1) = uVar3;
  *param_1 = uVar5;
  return;
}


// ==== FUN_0001a838 @ 0001a838

void FUN_0001a838(undefined8 *param_1,undefined4 param_2,undefined4 param_3)

{
  ulonglong *puVar1;
  undefined8 *puVar2;
  undefined1 *puVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  byte local_50;
  undefined1 auStack_4f [3];
  uint local_4c;
  undefined1 *local_48;
  byte local_44 [8];
  void *local_3c;
  ulonglong local_38;
  void *local_30;
  ulonglong local_28;
  void *local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  FUN_0001f51a(local_44,"[json.exception.",param_2);
  puVar1 = (ulonglong *)FUN_0001f4da(local_44,&DAT_00015eae);
  local_38 = *puVar1;
  local_30 = *(void **)(puVar1 + 1);
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)((int)puVar1 + 4) = 0;
  *(undefined4 *)(puVar1 + 1) = 0;
  FUN_0001f56c(&local_50,param_3);
  puVar3 = local_48;
  if ((local_50 & 1) == 0) {
    puVar3 = auStack_4f;
    local_4c = (uint)(local_50 >> 1);
  }
  puVar1 = (ulonglong *)FUN_0001f32c(&local_38,puVar3,local_4c);
  local_28 = *puVar1;
  local_20 = *(void **)(puVar1 + 1);
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)((int)puVar1 + 4) = 0;
  *(undefined4 *)(puVar1 + 1) = 0;
  puVar2 = (undefined8 *)FUN_0001f4da(&local_28,&DAT_00016142);
  uVar5 = *puVar2;
  uVar4 = *(undefined4 *)(puVar2 + 1);
  *(undefined4 *)puVar2 = 0;
  *(undefined4 *)((int)puVar2 + 4) = 0;
  *(undefined4 *)(puVar2 + 1) = 0;
  *(undefined4 *)(param_1 + 1) = uVar4;
  *param_1 = uVar5;
  if ((local_28 & 1) != 0) {
    free(local_20);
  }
  if ((local_50 & 1) != 0) {
    free(local_48);
  }
  if ((local_38 & 1) != 0) {
    free(local_30);
  }
  if ((local_44[0] & 1) != 0) {
    free(local_3c);
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001a978 @ 0001a978

void FUN_0001a978(undefined4 *param_1)

{
  void *__ptr;
  
  *param_1 = &PTR_FUN_0001a7b8_1_0003142c;
  FUN_00029aa8(param_1 + 2);
  __ptr = (void *)FUN_00029a0a(param_1);
  free(__ptr);
  return;
}


// ==== FUN_0001a9d8 @ 0001a9d8

undefined1 * FUN_0001a9d8(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  int *__ptr;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  bool bVar10;
  
  uVar1 = *param_2;
  *param_1 = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  switch(uVar1) {
  case 1:
    puVar8 = *(undefined4 **)(param_2 + 8);
    __ptr = (int *)FUN_0001ee80(0xc);
    __ptr[2] = 0;
    piVar9 = __ptr + 1;
    *piVar9 = 0;
    *__ptr = (int)piVar9;
    piVar7 = (int *)*puVar8;
    while (piVar7 != puVar8 + 1) {
      FUN_0001ab38(__ptr,piVar9,piVar7 + 4,piVar7 + 4);
      piVar3 = (int *)piVar7[1];
      if ((int *)piVar7[1] == (int *)0x0) {
        piVar3 = piVar7 + 2;
        bVar10 = *(int **)*piVar3 != piVar7;
        piVar7 = (int *)*piVar3;
        if (bVar10) {
          do {
            iVar5 = *piVar3;
            piVar3 = (int *)(iVar5 + 8);
            piVar7 = (int *)*piVar3;
          } while (*piVar7 != iVar5);
        }
      }
      else {
        do {
          piVar7 = piVar3;
          piVar3 = (int *)*piVar7;
        } while ((int *)*piVar7 != (int *)0x0);
      }
    }
    break;
  case 2:
    piVar9 = *(int **)(param_2 + 8);
    __ptr = (int *)FUN_0001ee80(0xc);
    *__ptr = 0;
    __ptr[1] = 0;
    iVar5 = *piVar9;
    iVar6 = piVar9[1];
    __ptr[2] = 0;
    iVar6 = iVar6 - iVar5;
    if (iVar6 != 0) {
      if (iVar6 < 0) {
        FUN_0001fc64(__ptr);
        free(__ptr);
                    /* WARNING: Subroutine does not return */
        FUN_0001fc74();
      }
      iVar4 = FUN_0001ee80(iVar6);
      *__ptr = iVar4;
      __ptr[1] = iVar4;
      __ptr[2] = iVar4 + (iVar6 >> 4) * 0x10;
      iVar6 = piVar9[1];
      for (iVar5 = *piVar9; iVar5 != iVar6; iVar5 = iVar5 + 0x10) {
        FUN_0001a9d8(iVar4,iVar5);
        iVar4 = iVar4 + 0x10;
      }
      __ptr[1] = iVar4;
      *(int **)(param_1 + 8) = __ptr;
      return param_1;
    }
    break;
  case 3:
    uVar2 = *(undefined4 *)(param_2 + 8);
    __ptr = (int *)FUN_0001ee80(0xc);
    FUN_0001f130(__ptr,uVar2);
    break;
  case 4:
    *(uint *)(param_1 + 8) = (uint)(byte)param_2[8];
    *(undefined4 *)(param_1 + 0xc) = 0;
    return param_1;
  case 5:
  case 6:
  case 7:
    uVar2 = *(undefined4 *)(param_2 + 0xc);
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    return param_1;
  case 8:
    uVar2 = FUN_0001b07c(*(undefined4 *)(param_2 + 8));
    *(undefined4 *)(param_1 + 8) = uVar2;
    return param_1;
  default:
    return param_1;
  }
  *(int **)(param_1 + 8) = __ptr;
  return param_1;
}


// ==== FUN_0001ab38 @ 0001ab38

void FUN_0001ab38(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined1 auStack_38 [4];
  undefined4 local_34;
  undefined4 *local_30;
  int *piStack_2c;
  undefined1 local_28;
  int local_24;
  
  local_24 = __stack_chk_guard;
  puVar1 = (undefined4 *)FUN_0001abf4(param_1,param_2,&local_34,auStack_38,param_3);
  puVar2 = (undefined4 *)*puVar1;
  if ((undefined4 *)*puVar1 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)FUN_0001ee80(0x30);
    local_28 = 0;
    piStack_2c = param_1 + 1;
    local_30 = puVar2;
    FUN_0001f130(puVar2 + 4,param_4);
    FUN_0001a9d8(puVar2 + 8,param_4 + 0x10);
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = local_34;
    *puVar1 = puVar2;
    if (*(int *)*param_1 != 0) {
      *param_1 = *(int *)*param_1;
      puVar2 = (undefined4 *)*puVar1;
    }
    FUN_0001af34(param_1[1],puVar2);
    param_1[2] = param_1[2] + 1;
    puVar2 = local_30;
  }
  if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar2);
  }
  return;
}


// ==== FUN_0001abf4 @ 0001abf4

int * FUN_0001abf4(int *param_1,int *param_2,undefined4 *param_3,int *param_4,byte *param_5)

{
  byte bVar1;
  byte bVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  byte *pbVar7;
  int *piVar8;
  void *pvVar9;
  uint uVar10;
  uint uVar11;
  
  if (param_1 + 1 == param_2) {
LAB_0001ac86:
    piVar5 = (int *)*param_2;
    if ((int *)*param_1 == param_2) {
      piVar8 = param_2;
    }
    else {
      if (piVar5 == (int *)0x0) {
        piVar8 = param_2 + 2;
        if (*(int **)*piVar8 == param_2) {
          do {
            iVar4 = *piVar8;
            piVar8 = (int *)(iVar4 + 8);
          } while (*(int *)*piVar8 == iVar4);
        }
        piVar8 = (int *)*piVar8;
      }
      else {
        piVar3 = piVar5;
        do {
          piVar8 = piVar3;
          piVar3 = (int *)piVar8[1];
        } while ((int *)piVar8[1] != (int *)0x0);
      }
      bVar1 = *param_5;
      bVar2 = *(byte *)(piVar8 + 4);
      uVar11 = *(uint *)(param_5 + 4);
      uVar10 = piVar8[5];
      if ((bVar1 & 1) == 0) {
        uVar11 = (uint)(bVar1 >> 1);
      }
      if ((bVar2 & 1) == 0) {
        uVar10 = (uint)(bVar2 >> 1);
      }
      uVar6 = uVar10;
      if (uVar11 < uVar10) {
        uVar6 = uVar11;
      }
      if (uVar6 != 0) {
        pvVar9 = (void *)piVar8[6];
        pbVar7 = *(byte **)(param_5 + 8);
        if ((bVar2 & 1) == 0) {
          pvVar9 = (void *)((int)piVar8 + 0x11);
        }
        if ((bVar1 & 1) == 0) {
          pbVar7 = param_5 + 1;
        }
        iVar4 = memcmp(pvVar9,pbVar7,uVar6);
        if (iVar4 != 0) {
          if (iVar4 < 0) goto LAB_0001ad76;
          goto LAB_0001ad5e;
        }
      }
      if (uVar11 <= uVar10) {
LAB_0001ad5e:
        piVar5 = (int *)FUN_0001ae6c(param_1,param_3,param_5);
        return piVar5;
      }
    }
LAB_0001ad76:
    if (piVar5 == (int *)0x0) {
      *param_3 = param_2;
      return param_2;
    }
    *param_3 = piVar8;
    return piVar8 + 1;
  }
  bVar1 = *param_5;
  bVar2 = *(byte *)(param_2 + 4);
  uVar10 = *(uint *)(param_5 + 4);
  uVar11 = param_2[5];
  if ((bVar1 & 1) == 0) {
    uVar10 = (uint)(bVar1 >> 1);
  }
  if ((bVar2 & 1) == 0) {
    uVar11 = (uint)(bVar2 >> 1);
  }
  uVar6 = uVar10;
  if (uVar11 < uVar10) {
    uVar6 = uVar11;
  }
  if (uVar6 == 0) {
    if (uVar10 < uVar11) goto LAB_0001ac86;
LAB_0001acd6:
    if (uVar10 <= uVar11) {
LAB_0001acc2:
      *param_3 = param_2;
      *param_4 = (int)param_2;
      return param_4;
    }
  }
  else {
    pbVar7 = *(byte **)(param_5 + 8);
    pvVar9 = (void *)param_2[6];
    if ((bVar1 & 1) == 0) {
      pbVar7 = param_5 + 1;
    }
    if ((bVar2 & 1) == 0) {
      pvVar9 = (void *)((int)param_2 + 0x11);
    }
    iVar4 = memcmp(pbVar7,pvVar9,uVar6);
    if (iVar4 == 0) {
      if (uVar10 < uVar11) goto LAB_0001ac86;
    }
    else if (iVar4 < 0) goto LAB_0001ac86;
    iVar4 = memcmp(pvVar9,pbVar7,uVar6);
    if (iVar4 == 0) goto LAB_0001acd6;
    if (-1 < iVar4) goto LAB_0001acc2;
  }
  piVar5 = (int *)param_2[1];
  if ((int *)param_2[1] == (int *)0x0) {
    piVar5 = param_2 + 2;
    piVar8 = (int *)*piVar5;
    if ((int *)*piVar8 != param_2) {
      do {
        iVar4 = *piVar5;
        piVar5 = (int *)(iVar4 + 8);
        piVar8 = (int *)*piVar5;
      } while (*piVar8 != iVar4);
    }
  }
  else {
    do {
      piVar8 = piVar5;
      piVar5 = (int *)*piVar8;
    } while ((int *)*piVar8 != (int *)0x0);
  }
  if (piVar8 != param_1 + 1) {
    bVar2 = *(byte *)(piVar8 + 4);
    uVar11 = piVar8[5];
    if ((bVar2 & 1) == 0) {
      uVar11 = (uint)(bVar2 >> 1);
    }
    uVar6 = uVar10;
    if (uVar11 < uVar10) {
      uVar6 = uVar11;
    }
    if (uVar6 != 0) {
      pbVar7 = *(byte **)(param_5 + 8);
      pvVar9 = (void *)piVar8[6];
      if ((bVar1 & 1) == 0) {
        pbVar7 = param_5 + 1;
      }
      if ((bVar2 & 1) == 0) {
        pvVar9 = (void *)((int)piVar8 + 0x11);
      }
      iVar4 = memcmp(pbVar7,pvVar9,uVar6);
      if (iVar4 != 0) {
        if (iVar4 < 0) goto LAB_0001ae1a;
        goto LAB_0001ae02;
      }
    }
    if (uVar11 <= uVar10) {
LAB_0001ae02:
      piVar5 = (int *)FUN_0001ae6c(param_1,param_3,param_5);
      return piVar5;
    }
  }
LAB_0001ae1a:
  if (param_2[1] == 0) {
    *param_3 = param_2;
    piVar8 = param_2 + 1;
  }
  else {
    *param_3 = piVar8;
  }
  return piVar8;
}


// ==== FUN_0001ae6c @ 0001ae6c

int * FUN_0001ae6c(int param_1,int *param_2,byte *param_3)

{
  byte bVar1;
  int iVar2;
  int *piVar3;
  uint __n;
  int *piVar4;
  void *__s2;
  uint uVar5;
  byte *__s1;
  int *piVar6;
  uint uVar7;
  
  piVar4 = (int *)(param_1 + 4);
  piVar6 = (int *)*piVar4;
  if (piVar6 == (int *)0x0) {
    *param_2 = (int)piVar4;
    return piVar4;
  }
  piVar4 = (int *)(param_1 + 4);
  uVar7 = *(uint *)(param_3 + 4);
  __s1 = *(byte **)(param_3 + 8);
  if ((*param_3 & 1) == 0) {
    __s1 = param_3 + 1;
    uVar7 = (uint)(*param_3 >> 1);
  }
  while( true ) {
    bVar1 = *(byte *)(piVar6 + 4);
    uVar5 = piVar6[5];
    if ((bVar1 & 1) == 0) {
      uVar5 = (uint)(bVar1 >> 1);
    }
    __n = uVar7;
    if (uVar5 < uVar7) {
      __n = uVar5;
    }
    if (__n == 0) break;
    __s2 = (void *)piVar6[6];
    if ((bVar1 & 1) == 0) {
      __s2 = (void *)((int)piVar6 + 0x11);
    }
    iVar2 = memcmp(__s1,__s2,__n);
    if (iVar2 == 0) {
      if (uVar5 <= uVar7) goto LAB_0001aeee;
    }
    else if (-1 < iVar2) {
LAB_0001aeee:
      iVar2 = memcmp(__s2,__s1,__n);
      if (iVar2 == 0) goto LAB_0001af02;
      if (iVar2 < 0) goto LAB_0001af06;
      goto LAB_0001af12;
    }
LAB_0001ae9c:
    piVar3 = (int *)*piVar6;
    piVar4 = piVar6;
    if (piVar3 == (int *)0x0) goto LAB_0001af26;
LAB_0001aea4:
    piVar6 = piVar3;
  }
  if (uVar7 < uVar5) goto LAB_0001ae9c;
LAB_0001af02:
  if (uVar5 < uVar7) {
LAB_0001af06:
    piVar4 = piVar6 + 1;
    piVar3 = (int *)*piVar4;
    if (piVar3 != (int *)0x0) {
      goto LAB_0001aea4;
    }
  }
LAB_0001af12:
LAB_0001af26:
  *param_2 = (int)piVar6;
  return piVar4;
}


// ==== FUN_0001af34 @ 0001af34

void FUN_0001af34(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  
  *(bool *)(param_2 + 3) = param_2 == param_1;
  do {
    if (param_2 == param_1) {
      return;
    }
    piVar5 = (int *)param_2[2];
    if ((char)piVar5[3] != '\0') {
      return;
    }
    piVar6 = (int *)piVar5[2];
    piVar2 = (int *)*piVar6;
    if (piVar2 == piVar5) {
      if ((piVar6[1] == 0) || (piVar2 = (int *)(piVar6[1] + 0xc), *(char *)piVar2 != '\0')) {
        if ((int *)*piVar5 != param_2) {
          piVar2 = (int *)piVar5[1];
          iVar1 = *piVar2;
          piVar5[1] = iVar1;
          if (iVar1 != 0) {
            *(int **)(iVar1 + 8) = piVar5;
            piVar6 = (int *)piVar5[2];
          }
          piVar2[2] = (int)piVar6;
          puVar4 = (undefined4 *)piVar5[2];
          puVar3 = puVar4 + 1;
          if ((int *)*puVar4 == piVar5) {
            puVar3 = puVar4;
          }
          *puVar3 = piVar2;
          piVar5[2] = (int)piVar2;
          piVar6 = (int *)piVar2[2];
          *piVar2 = (int)piVar5;
          piVar5 = piVar2;
        }
        piVar2 = (int *)*piVar6;
        *(undefined1 *)(piVar5 + 3) = 1;
        *(undefined1 *)(piVar6 + 3) = 0;
        iVar1 = piVar2[1];
        *piVar6 = iVar1;
        if (iVar1 != 0) {
          *(int **)(iVar1 + 8) = piVar6;
        }
        piVar5 = piVar6 + 2;
        piVar2[2] = *piVar5;
        puVar4 = (undefined4 *)*piVar5;
        puVar3 = puVar4 + 1;
        if ((int *)*puVar4 == piVar6) {
          puVar3 = puVar4;
        }
        *puVar3 = piVar2;
        piVar2[1] = (int)piVar6;
        goto LAB_0001b078;
      }
    }
    else if ((piVar2 == (int *)0x0) || (piVar2 = piVar2 + 3, (char)*piVar2 != '\0')) {
      if ((int *)*piVar5 == param_2) {
        iVar1 = param_2[1];
        *piVar5 = iVar1;
        if (iVar1 != 0) {
          *(int **)(iVar1 + 8) = piVar5;
          piVar6 = (int *)piVar5[2];
        }
        param_2[2] = (int)piVar6;
        piVar6 = (int *)piVar5[2];
        piVar2 = piVar6 + 1;
        if ((int *)*piVar6 == piVar5) {
          piVar2 = piVar6;
        }
        *piVar2 = (int)param_2;
        piVar5[2] = (int)param_2;
        piVar6 = (int *)param_2[2];
        param_2[1] = (int)piVar5;
      }
      else {
        param_2 = piVar5;
      }
      piVar2 = (int *)piVar6[1];
      *(undefined1 *)(param_2 + 3) = 1;
      *(undefined1 *)(piVar6 + 3) = 0;
      iVar1 = *piVar2;
      piVar6[1] = iVar1;
      if (iVar1 != 0) {
        *(int **)(iVar1 + 8) = piVar6;
      }
      piVar5 = piVar6 + 2;
      piVar2[2] = *piVar5;
      puVar4 = (undefined4 *)*piVar5;
      puVar3 = puVar4 + 1;
      if ((int *)*puVar4 == piVar6) {
        puVar3 = puVar4;
      }
      *puVar3 = piVar2;
      *piVar2 = (int)piVar6;
LAB_0001b078:
      *piVar5 = (int)piVar2;
      return;
    }
    *(undefined1 *)(piVar5 + 3) = 1;
    *(bool *)(piVar6 + 3) = piVar6 == param_1;
    *(char *)piVar2 = '\x01';
    param_2 = piVar6;
  } while( true );
}


// ==== FUN_0001b07c @ 0001b07c

undefined4 * FUN_0001b07c(undefined4 *param_1)

{
  undefined4 *__ptr;
  void *__dest;
  size_t __n;
  void *pvVar1;
  
  __ptr = (undefined4 *)FUN_0001ee80(0x10);
  pvVar1 = (void *)*param_1;
  __n = param_1[1] - (int)pvVar1;
  *__ptr = 0;
  __ptr[1] = 0;
  __ptr[2] = 0;
  if (__n != 0) {
    if ((int)__n < 0) {
      FUN_0001fc64(__ptr);
      pvVar1 = (void *)*__ptr;
      if (pvVar1 != (void *)0x0) {
        __ptr[1] = pvVar1;
        free(pvVar1);
      }
      free(__ptr);
                    /* WARNING: Subroutine does not return */
      FUN_0001fc74();
    }
    __dest = (void *)FUN_0001ee80(__n);
    __ptr[2] = (int)__dest + __n;
    *__ptr = __dest;
    memcpy(__dest,pvVar1,__n);
    __ptr[1] = (int)__dest + __n;
  }
  *(undefined2 *)(__ptr + 3) = *(undefined2 *)(param_1 + 3);
  return __ptr;
}


// ==== FUN_0001b0ec @ 0001b0ec

void FUN_0001b0ec(int *param_1,int param_2,int param_3)

{
  int iVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  undefined1 local_38 [8];
  undefined4 local_30;
  undefined4 local_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_3 - param_2 != 0) {
    iVar1 = param_3 - param_2 >> 3;
    if (0xfffffff < (uint)(iVar1 * -0x55555555)) {
      FUN_0001fc64(param_1);
      FUN_0001a5f2(param_1);
                    /* WARNING: Subroutine does not return */
      FUN_0001fc74();
    }
    puVar2 = (undefined1 *)FUN_0001ee80(iVar1 * -0x55555550);
    *param_1 = (int)puVar2;
    param_1[1] = (int)puVar2;
    param_1[2] = (int)(puVar2 + iVar1 * -0x55555550);
    if (param_2 != param_3) {
      do {
        puVar3 = *(undefined1 **)(param_2 + 0x10);
        if (*(char *)(param_2 + 0x14) == '\0') {
          FUN_0001a9d8(local_38);
        }
        else {
          local_38[0] = *puVar3;
          local_30 = *(undefined4 *)(puVar3 + 8);
          local_2c = *(undefined4 *)(puVar3 + 0xc);
          *puVar3 = 0;
          *(undefined4 *)(puVar3 + 8) = 0;
          *(undefined4 *)(puVar3 + 0xc) = 0;
        }
        *(undefined4 *)(puVar2 + 8) = local_30;
        *(undefined4 *)(puVar2 + 0xc) = local_2c;
        *puVar2 = local_38[0];
        local_30 = 0;
        local_2c = 0;
        local_38[0] = 0;
        FUN_00019e9c(&local_30,0);
        param_2 = param_2 + 0x18;
        puVar2 = puVar2 + 0x10;
      } while (param_2 != param_3);
    }
    param_1[1] = (int)puVar2;
  }
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_28);
  }
  return;
}


// ==== FUN_0001b1d8 @ 0001b1d8

void FUN_0001b1d8(int *param_1,undefined4 param_2)

{
  uint uVar1;
  undefined1 *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined1 *__ptr;
  undefined1 *puVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  int iVar10;
  int local_2c;
  
  iVar3 = __stack_chk_guard;
  iVar5 = param_1[1] - *param_1 >> 4;
  uVar9 = iVar5 + 1;
  if (0xfffffff < uVar9) {
    FUN_0001fc64(param_1);
LAB_0001b2f4:
                    /* WARNING: Subroutine does not return */
    FUN_0001a480("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
  }
  uVar4 = param_1[2] - *param_1;
  uVar1 = (int)uVar4 >> 3;
  if (uVar9 <= uVar1) {
    uVar9 = uVar1;
  }
  if (0x7fffffef < uVar4) {
    uVar9 = 0xfffffff;
  }
  if (uVar9 == 0) {
    local_2c = 0;
  }
  else {
    if (0xfffffff < uVar9) goto LAB_0001b2f4;
    local_2c = FUN_0001ee80(uVar9 << 4);
  }
  iVar10 = local_2c + uVar9 * 0x10;
  local_2c = local_2c + iVar5 * 0x10;
  iVar5 = FUN_0001a9d8(local_2c,param_2);
  __ptr = (undefined1 *)*param_1;
  puVar6 = (undefined1 *)param_1[1];
  iVar7 = iVar5 + 0x10;
  if (puVar6 == __ptr) {
    *param_1 = iVar5;
    param_1[1] = iVar7;
    param_1[2] = iVar10;
  }
  else {
    do {
      puVar2 = puVar6 + -0x10;
      *(undefined1 *)(iVar5 + -0x10) = *puVar2;
      uVar8 = *(undefined4 *)(puVar6 + -4);
      *(undefined4 *)(iVar5 + -8) = *(undefined4 *)(puVar6 + -8);
      *(undefined4 *)(iVar5 + -4) = uVar8;
      *(undefined4 *)(puVar6 + -8) = 0;
      *(undefined4 *)(puVar6 + -4) = 0;
      *puVar2 = 0;
      iVar5 = local_2c + -0x10;
      puVar6 = puVar2;
      local_2c = iVar5;
    } while (puVar2 != __ptr);
    __ptr = (undefined1 *)*param_1;
    puVar6 = (undefined1 *)param_1[1];
    *param_1 = iVar5;
    param_1[1] = iVar7;
    param_1[2] = iVar10;
    if (puVar6 != __ptr) {
      puVar6 = puVar6 + -8;
      do {
        puVar2 = puVar6 + -8;
        FUN_00019e9c(puVar6,*puVar2);
        puVar6 = puVar6 + -0x10;
      } while (puVar2 != __ptr);
    }
  }
  if (__ptr == (undefined1 *)0x0) {
    if (__stack_chk_guard == iVar3) {
      return;
    }
  }
  else if (__stack_chk_guard == iVar3) {
    free(__ptr);
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(iVar3);
}


// ==== FUN_0001b318 @ 0001b318

int FUN_0001b318(int param_1)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    piVar2 = piVar4 + 1;
    DataMemoryBarrier(0x1b);
    do {
      ExclusiveAccess(piVar2);
      iVar3 = *piVar2;
      bVar1 = (bool)hasExclusiveAccess(piVar2);
    } while (!bVar1);
    *piVar2 = iVar3 + -1;
    DataMemoryBarrier(0x1b);
    if (iVar3 == 0) {
      (**(code **)(*piVar4 + 8))(piVar4);
      FUN_0001ee0e(piVar4);
      return param_1;
    }
  }
  return param_1;
}


// ==== FUN_0001b352 @ 0001b352

int FUN_0001b352(int param_1)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    piVar2 = piVar4 + 1;
    DataMemoryBarrier(0x1b);
    do {
      ExclusiveAccess(piVar2);
      iVar3 = *piVar2;
      bVar1 = (bool)hasExclusiveAccess(piVar2);
    } while (!bVar1);
    *piVar2 = iVar3 + -1;
    DataMemoryBarrier(0x1b);
    if (iVar3 == 0) {
      (**(code **)(*piVar4 + 8))(piVar4);
      FUN_0001ee0e(piVar4);
      return param_1;
    }
  }
  return param_1;
}


// ==== FUN_0001b390 @ 0001b390

/* WARNING: Removing unreachable block (ram,0x0001b63c) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_0001b390(undefined4 *param_1,undefined1 *param_2,int param_3,undefined4 param_4,int param_5
                 ,int param_6)

{
  ulonglong *puVar1;
  ulonglong uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  byte *pbVar6;
  int *piVar7;
  byte bVar8;
  char cVar9;
  int iVar10;
  undefined *puVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined2 *puVar14;
  undefined4 uVar15;
  undefined2 *puVar16;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar17;
  int *piVar18;
  byte *pbVar19;
  char *pcVar20;
  int iVar21;
  undefined4 *puVar22;
  bool bVar23;
  double dVar24;
  ulonglong uVar25;
  ulonglong uVar26;
  undefined8 uVar27;
  int local_30;
  undefined4 *local_2c;
  undefined4 *local_28;
  
  local_28 = __stack_chk_guard;
  switch(*param_2) {
  case 0:
switchD_0001b3ba_caseD_0:
                    /* WARNING: Could not recover jumptable at 0x0001b6d2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00015f61,4);
    return;
  case 1:
    piVar4 = (int *)*param_1;
    if (*(int *)(*(int *)(param_2 + 8) + 8) == 0) {
      UNRECOVERED_JUMPTABLE = *(code **)(*piVar4 + 4);
      puVar11 = &UNK_00015f66;
LAB_0001b920:
                    /* WARNING: Could not recover jumptable at 0x0001b92c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(piVar4,puVar11,2);
      return;
    }
    if (param_3 != 0) {
      (**(code **)(*piVar4 + 4))(piVar4,&DAT_00016f15,2);
      uVar17 = param_6 + param_5;
      uVar5 = param_1[0x95];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        uVar5 = (uint)(*(byte *)(param_1 + 0x94) >> 1);
      }
      if (uVar5 < uVar17) {
        FUN_0001f4f6(param_1 + 0x94,uVar5 << 1,0x20);
      }
      puVar22 = (undefined4 *)((int)param_1 + 0x251);
      piVar4 = (int *)**(undefined4 **)(param_2 + 8);
      if ((*(undefined4 **)(param_2 + 8))[2] != 1) {
        uVar5 = 0;
        piVar18 = piVar4;
        do {
          puVar13 = (undefined4 *)param_1[0x96];
          if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
            puVar13 = puVar22;
          }
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,puVar13,uVar17);
          (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x22);
          FUN_0001c0c0(param_1,piVar18 + 4,param_4);
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016943,3);
          FUN_0001b390(param_1,piVar18 + 8,1,param_4);
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016a2f,2);
          piVar7 = (int *)piVar18[1];
          if ((int *)piVar18[1] == (int *)0x0) {
            piVar7 = piVar18 + 2;
            piVar4 = (int *)*piVar7;
            if ((int *)*piVar4 != piVar18) {
              do {
                iVar3 = *piVar7;
                piVar7 = (int *)(iVar3 + 8);
                piVar4 = (int *)*piVar7;
              } while (*piVar4 != iVar3);
            }
          }
          else {
            do {
              piVar4 = piVar7;
              piVar7 = (int *)*piVar4;
            } while ((int *)*piVar4 != (int *)0x0);
          }
          uVar5 = uVar5 + 1;
          piVar18 = piVar4;
        } while (uVar5 < *(int *)(*(int *)(param_2 + 8) + 8) - 1U);
      }
      puVar13 = (undefined4 *)param_1[0x96];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        puVar13 = puVar22;
      }
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,puVar13,uVar17);
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x22);
      FUN_0001c0c0(param_1,piVar4 + 4,param_4);
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016943,3);
      FUN_0001b390(param_1,piVar4 + 8,1,param_4);
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,10);
      piVar4 = (int *)*param_1;
      UNRECOVERED_JUMPTABLE = *(code **)(*piVar4 + 4);
      puVar13 = (undefined4 *)param_1[0x96];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        puVar13 = puVar22;
      }
      goto LAB_0001bf78;
    }
    (**(code **)*piVar4)(piVar4,0x7b);
    piVar4 = (int *)**(undefined4 **)(param_2 + 8);
    if ((*(undefined4 **)(param_2 + 8))[2] != 1) {
      uVar5 = 0;
      piVar18 = piVar4;
      do {
        (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x22);
        FUN_0001c0c0(param_1,piVar18 + 4,param_4);
        (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016f8a,2);
        FUN_0001b390(param_1,piVar18 + 8,0,param_4);
        (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x2c);
        piVar7 = (int *)piVar18[1];
        if ((int *)piVar18[1] == (int *)0x0) {
          piVar7 = piVar18 + 2;
          piVar4 = (int *)*piVar7;
          if ((int *)*piVar4 != piVar18) {
            do {
              iVar3 = *piVar7;
              piVar7 = (int *)(iVar3 + 8);
              piVar4 = (int *)*piVar7;
            } while (*piVar4 != iVar3);
          }
        }
        else {
          do {
            piVar4 = piVar7;
            piVar7 = (int *)*piVar4;
          } while ((int *)*piVar4 != (int *)0x0);
        }
        uVar5 = uVar5 + 1;
        piVar18 = piVar4;
      } while (uVar5 < *(int *)(*(int *)(param_2 + 8) + 8) - 1U);
    }
    (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x22);
    FUN_0001c0c0(param_1,piVar4 + 4,param_4);
    (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016f8a,2);
    FUN_0001b390(param_1,piVar4 + 8,0,param_4);
    goto LAB_0001bf7a;
  case 2:
    piVar4 = (int *)*param_1;
    if (**(int **)(param_2 + 8) == (*(int **)(param_2 + 8))[1]) {
      UNRECOVERED_JUMPTABLE = *(code **)(*piVar4 + 4);
      puVar11 = &DAT_0001722f;
      goto LAB_0001b920;
    }
    if (param_3 == 0) {
      (**(code **)*piVar4)(piVar4,0x5b);
      iVar3 = **(int **)(param_2 + 8);
      if (iVar3 != (*(int **)(param_2 + 8))[1] + -0x10) {
        do {
          FUN_0001b390(param_1,iVar3,0,param_4);
          (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x2c);
          iVar3 = iVar3 + 0x10;
        } while (iVar3 != *(int *)(*(int *)(param_2 + 8) + 4) + -0x10);
      }
      FUN_0001b390(param_1,iVar3,0,param_4);
    }
    else {
      (**(code **)(*piVar4 + 4))(piVar4,&DAT_000166f7,2);
      uVar5 = param_1[0x95];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        uVar5 = (uint)(*(byte *)(param_1 + 0x94) >> 1);
      }
      uVar17 = param_6 + param_5;
      if (uVar5 < uVar17) {
        FUN_0001f4f6(param_1 + 0x94,uVar5 << 1,0x20);
      }
      iVar3 = (int)param_1 + 0x251;
      iVar21 = **(int **)(param_2 + 8);
      if (iVar21 != (*(int **)(param_2 + 8))[1] + -0x10) {
        do {
          iVar10 = param_1[0x96];
          if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
            iVar10 = iVar3;
          }
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,iVar10,uVar17);
          FUN_0001b390(param_1,iVar21,1,param_4);
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016a2f,2);
          iVar21 = iVar21 + 0x10;
        } while (iVar21 != *(int *)(*(int *)(param_2 + 8) + 4) + -0x10);
      }
      iVar21 = param_1[0x96];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        iVar21 = iVar3;
      }
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,iVar21,uVar17);
      FUN_0001b390(param_1,*(int *)(*(int *)(param_2 + 8) + 4) + -0x10,1,param_4);
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,10);
      iVar21 = param_1[0x96];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        iVar21 = iVar3;
      }
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,iVar21,param_6);
    }
    if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001ba42. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x5d);
      return;
    }
    break;
  case 3:
    (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x22);
    FUN_0001c0c0(param_1,*(undefined4 *)(param_2 + 8),param_4);
    if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001b5de. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x22);
      return;
    }
    break;
  case 4:
    piVar4 = (int *)*param_1;
    if (param_2[8] == '\0') {
                    /* WARNING: Could not recover jumptable at 0x0001b950. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar4 + 4))(piVar4,"false",5);
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x0001b614. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar4 + 4))(piVar4,&DAT_00016947,4);
    return;
  case 5:
    uVar5 = (uint)*(ulonglong *)(param_2 + 8);
    uVar17 = *(uint *)(param_2 + 0xc);
    uVar26 = *(ulonglong *)(param_2 + 8);
    if (uVar5 == 0 && uVar17 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0001c620. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
      return;
    }
    puVar13 = param_1 + 2;
    local_2c = param_1;
    if ((int)uVar17 < 0) {
      bVar23 = uVar5 != 0;
      uVar5 = -uVar5;
      *(undefined1 *)puVar13 = 0x2d;
      uVar17 = -(uint)bVar23 - uVar17;
      uVar26 = CONCAT44(uVar17,uVar5);
      if (uVar17 == 0 && (9 < uVar5) <= uVar17) {
        iVar21 = 1;
      }
      else {
        iVar3 = 4;
        local_28 = puVar13;
        do {
          iVar21 = iVar3;
          uVar12 = (uint)(uVar26 >> 0x20);
          pcVar20 = (char *)uVar26;
          if (-uVar12 < (uint)(pcVar20 < (char *)0x64)) {
            iVar21 = iVar21 + -2;
            goto LAB_0001c73e;
          }
          if ((uint)-(int)((uVar26 >> 3) >> 0x20) < (uint)((uint)(uVar26 >> 3) < 0x7d)) {
            iVar21 = iVar21 + -1;
            goto LAB_0001c73e;
          }
          if (uVar12 == 0 && ((char *)0x270f < pcVar20) <= uVar12) goto LAB_0001c73e;
          uVar26 = FUN_0002a500(pcVar20,uVar12,10000,0);
          iVar3 = iVar21 + 4;
        } while (uVar12 != 0 ||
                 uVar12 < ("12_GLOBAL__N_116itanium_demangle12InitListExprE" < pcVar20));
        iVar21 = iVar21 + 1;
LAB_0001c73e:
        puVar13 = local_28;
      }
      iVar21 = iVar21 + 1;
      iVar3 = (int)local_2c + iVar21;
      param_1 = local_2c;
      if (uVar17 == 0 && (99 < uVar5) <= uVar17) goto LAB_0001c71c;
LAB_0001c756:
      uVar27 = CONCAT44(uVar17,uVar5);
      puVar14 = (undefined2 *)(iVar3 + 6);
      local_30 = iVar21;
      local_2c = param_1;
      local_28 = puVar13;
      do {
        puVar16 = puVar14;
        iVar3 = (int)((ulonglong)uVar27 >> 0x20);
        uVar12 = (uint)uVar27;
        uVar27 = FUN_0002a500(uVar12,iVar3,100,0);
        uVar17 = (uint)((ulonglong)uVar27 >> 0x20);
        uVar5 = (uint)uVar27;
        *puVar16 = *(undefined2 *)(&DAT_000176b3 + (uVar12 + uVar5 * -100) * 2);
        puVar14 = puVar16 + -1;
      } while ((uint)(uVar12 < 10000) <= (uint)-iVar3);
      puVar13 = local_28;
      param_1 = local_2c;
      if (uVar17 == 0 && (9 < uVar5) <= uVar17) goto LAB_0001c72a;
LAB_0001c7aa:
      puVar16[-1] = *(undefined2 *)(&DAT_000176b3 + uVar5 * 2);
      param_1 = local_2c;
    }
    else {
      if (uVar17 == 0 && (9 < uVar5) <= uVar17) {
        puVar16 = (undefined2 *)((int)param_1 + 9);
        local_30 = 1;
      }
      else {
        iVar3 = 4;
        local_28 = puVar13;
        do {
          iVar21 = iVar3;
          uVar12 = (uint)(uVar26 >> 0x20);
          pcVar20 = (char *)uVar26;
          if (-uVar12 < (uint)(pcVar20 < (char *)0x64)) {
            iVar21 = iVar21 + -2;
            goto LAB_0001c70c;
          }
          if ((uint)-(int)((uVar26 >> 3) >> 0x20) < (uint)((uint)(uVar26 >> 3) < 0x7d)) {
            iVar21 = iVar21 + -1;
            goto LAB_0001c70c;
          }
          if (uVar12 == 0 && ((char *)0x270f < pcVar20) <= uVar12) goto LAB_0001c70c;
          uVar26 = FUN_0002a500(pcVar20,uVar12,10000,0);
          iVar3 = iVar21 + 4;
        } while (uVar12 != 0 ||
                 uVar12 < ("12_GLOBAL__N_116itanium_demangle12InitListExprE" < pcVar20));
        iVar21 = iVar21 + 1;
LAB_0001c70c:
        iVar3 = (int)param_1 + iVar21;
        puVar13 = local_28;
        if (uVar17 != 0 || uVar17 < (99 < uVar5)) goto LAB_0001c756;
LAB_0001c71c:
        puVar16 = (undefined2 *)(iVar3 + 8);
        local_30 = iVar21;
        param_1 = local_2c;
        if (uVar17 != 0 || uVar17 < (9 < uVar5)) goto LAB_0001c7aa;
      }
LAB_0001c72a:
      *(char *)((int)puVar16 + -1) = (char)uVar5 + '0';
    }
                    /* WARNING: Could not recover jumptable at 0x0001c7ca. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,puVar13,local_30);
    return;
  case 6:
    puVar1 = (ulonglong *)(param_2 + 8);
    uVar5 = (uint)*puVar1;
    uVar17 = *(uint *)(param_2 + 0xc);
    uVar2 = *puVar1;
    uVar26 = *puVar1;
    if (uVar5 == 0 && uVar17 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0001b978. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
      return;
    }
    if (uVar17 == 0 && (9 < uVar5) <= uVar17) {
      puVar14 = (undefined2 *)((int)param_1 + 9);
      iVar21 = 1;
LAB_0001bd54:
      *(char *)((int)puVar14 + -1) = (char)uVar5 + '0';
    }
    else {
      iVar3 = 4;
      uVar25 = uVar26;
      do {
        iVar21 = iVar3;
        uVar12 = (uint)(uVar25 >> 0x20);
        pcVar20 = (char *)uVar25;
        if (-uVar12 < (uint)(pcVar20 < (char *)0x64)) {
          iVar21 = iVar21 + -2;
          goto LAB_0001bcf0;
        }
        if ((uint)-(int)((uVar25 >> 3) >> 0x20) < (uint)((uint)(uVar25 >> 3) < 0x7d)) {
          iVar21 = iVar21 + -1;
          goto LAB_0001bcf0;
        }
        if (uVar12 == 0 && ((char *)0x270f < pcVar20) <= uVar12) goto LAB_0001bcf0;
        uVar25 = FUN_0002a500(pcVar20,uVar12,10000,0);
        iVar3 = iVar21 + 4;
      } while ((uint)(pcVar20 < "2_GLOBAL__N_116itanium_demangle12InitListExprE") <= -uVar12);
      iVar21 = iVar21 + 1;
LAB_0001bcf0:
      if (uVar17 == 0 && (99 < uVar5) <= uVar17) {
        puVar14 = (undefined2 *)((int)param_1 + iVar21 + 8);
      }
      else {
        puVar16 = (undefined2 *)((int)param_1 + iVar21 + 6);
        do {
          puVar14 = puVar16;
          iVar3 = (int)(uVar26 >> 0x20);
          uVar5 = (uint)uVar26;
          uVar26 = FUN_0002a500(uVar5,iVar3,100,0);
          *puVar14 = *(undefined2 *)
                      (
                      "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
                      + (uVar5 + (int)uVar26 * -100) * 2);
          puVar16 = puVar14 + -1;
        } while ((uint)(uVar5 < 10000) <= (uint)-iVar3);
        uVar2 = uVar26;
      }
      uVar17 = (uint)(uVar2 >> 0x20);
      uVar5 = (uint)uVar2;
      if (uVar17 == 0 && (9 < uVar5) <= uVar17) goto LAB_0001bd54;
      puVar14[-1] = *(undefined2 *)
                     (
                     "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
                     + uVar5 * 2);
    }
    if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001bd84. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,param_1 + 2,iVar21);
      return;
    }
    break;
  case 7:
    dVar24 = *(double *)(param_2 + 8);
    if ((INFINITY <= ABS(dVar24)) && (ABS(dVar24) == INFINITY)) goto switchD_0001b3ba_caseD_0;
    puVar13 = param_1 + 2;
    if ((longlong)dVar24 < 0) {
      puVar22 = (undefined4 *)((int)param_1 + 9);
      *(undefined1 *)(param_1 + 2) = 0x2d;
      if (-dVar24 == 0.0) goto LAB_0001b69a;
LAB_0001bae6:
      local_30 = 0;
      local_2c = (undefined4 *)0x0;
      FUN_0001c818(puVar22,&local_2c,&local_30);
      iVar3 = FUN_0001ca80(puVar22,local_2c,local_30,0xfffffffc);
    }
    else {
      puVar22 = puVar13;
      if (dVar24 != 0.0) goto LAB_0001bae6;
LAB_0001b69a:
      *(undefined1 *)((int)puVar22 + 2) = 0x30;
      *(undefined2 *)puVar22 = 0x2e30;
      iVar3 = (int)puVar22 + 3;
    }
    (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,puVar13,iVar3 - (int)puVar13);
  default:
    if (__stack_chk_guard == local_28) {
      return;
    }
    break;
  case 8:
    piVar4 = (int *)*param_1;
    if (param_3 == 0) {
      (**(code **)(*piVar4 + 4))(piVar4,"{\"bytes\":[",10);
      pbVar19 = (byte *)**(undefined4 **)(param_2 + 8);
      pbVar6 = (byte *)(*(undefined4 **)(param_2 + 8))[1];
      if (pbVar19 != pbVar6) {
        if (pbVar19 != pbVar6 + -1) {
          do {
            bVar8 = *pbVar19;
            uVar5 = (uint)bVar8;
            if (uVar5 == 0) {
              (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
            }
            else {
              if (uVar5 < 10) {
                uVar15 = 1;
LAB_0001b8d4:
                cVar9 = bVar8 + 0x30;
              }
              else {
                if (99 < uVar5) {
                  uVar15 = 3;
                  uVar17 = (uint)bVar8 * 0x29 >> 0xc;
                  bVar8 = (byte)uVar17;
                  *(undefined2 *)((int)param_1 + 9) =
                       *(undefined2 *)(&DAT_000175eb + (uVar5 + uVar17 * -100 & 0xff) * 2);
                  goto LAB_0001b8d4;
                }
                cVar9 = (&DAT_000175eb)[uVar5 * 2];
                uVar15 = 2;
                *(undefined *)((int)param_1 + 9) = (&DAT_000175ec)[uVar5 * 2];
              }
              *(char *)(param_1 + 2) = cVar9;
              (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,param_1 + 2,uVar15);
            }
            (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x2c);
            pbVar19 = pbVar19 + 1;
          } while (pbVar19 != (byte *)(*(int *)(*(int *)(param_2 + 8) + 4) + -1));
        }
        bVar8 = *pbVar19;
        uVar5 = (uint)bVar8;
        if (uVar5 == 0) {
          (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
        }
        else {
          if (uVar5 < 10) {
            uVar15 = 1;
LAB_0001be62:
            cVar9 = bVar8 + 0x30;
          }
          else {
            if (99 < uVar5) {
              uVar17 = (uint)bVar8 * 0x29 >> 0xc;
              bVar8 = (byte)uVar17;
              uVar15 = 3;
              *(undefined2 *)((int)param_1 + 9) =
                   *(undefined2 *)(&DAT_000175eb + (uVar5 + uVar17 * -100 & 0xff) * 2);
              goto LAB_0001be62;
            }
            cVar9 = (&DAT_000175eb)[uVar5 * 2];
            uVar15 = 2;
            *(undefined *)((int)param_1 + 9) = (&DAT_000175ec)[uVar5 * 2];
          }
          *(char *)(param_1 + 2) = cVar9;
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,param_1 + 2,uVar15);
        }
      }
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,"],\"subtype\":",0xc);
      if (*(char *)(*(int *)(param_2 + 8) + 0xd) == '\0') {
        if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001bec4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&UNK_00016f8d,5);
          return;
        }
        break;
      }
      bVar8 = *(byte *)(*(int *)(param_2 + 8) + 0xc);
      uVar5 = (uint)bVar8;
      if (uVar5 == 0) {
        (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
        goto LAB_0001bf7a;
      }
      if (uVar5 < 10) {
        param_6 = 1;
LAB_0001bf68:
        cVar9 = bVar8 + 0x30;
      }
      else {
        if (99 < uVar5) {
          uVar17 = (uint)bVar8 * 0x29 >> 0xc;
          bVar8 = (byte)uVar17;
          param_6 = 3;
          *(undefined2 *)((int)param_1 + 9) =
               *(undefined2 *)(&DAT_000175eb + (uVar5 + uVar17 * -100 & 0xff) * 2);
          goto LAB_0001bf68;
        }
        cVar9 = (&DAT_000175eb)[uVar5 * 2];
        param_6 = 2;
        *(undefined *)((int)param_1 + 9) = (&DAT_000175ec)[uVar5 * 2];
      }
      piVar4 = (int *)*param_1;
      *(char *)(param_1 + 2) = cVar9;
      UNRECOVERED_JUMPTABLE = *(code **)(*piVar4 + 4);
      puVar13 = param_1 + 2;
    }
    else {
      (**(code **)(*piVar4 + 4))(piVar4,&DAT_00016f15,2);
      bVar8 = *(byte *)(param_1 + 0x94);
      uVar17 = param_6 + param_5;
      uVar5 = param_1[0x95];
      if ((bVar8 & 1) == 0) {
        uVar5 = (uint)(bVar8 >> 1);
      }
      if (uVar5 < uVar17) {
        FUN_0001f4f6(param_1 + 0x94,uVar5 << 1,0x20);
        bVar8 = *(byte *)(param_1 + 0x94);
      }
      puVar22 = (undefined4 *)((int)param_1 + 0x251);
      puVar13 = (undefined4 *)param_1[0x96];
      if ((bVar8 & 1) == 0) {
        puVar13 = puVar22;
      }
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,puVar13,uVar17);
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,"\"bytes\": [",10);
      pbVar19 = (byte *)**(undefined4 **)(param_2 + 8);
      pbVar6 = (byte *)(*(undefined4 **)(param_2 + 8))[1];
      if (pbVar19 != pbVar6) {
        if (pbVar19 != pbVar6 + -1) {
          do {
            bVar8 = *pbVar19;
            uVar5 = (uint)bVar8;
            if (uVar5 == 0) {
              (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
            }
            else {
              if (uVar5 < 10) {
                uVar15 = 1;
LAB_0001b7fc:
                cVar9 = bVar8 + 0x30;
              }
              else {
                if (99 < uVar5) {
                  uVar12 = (uint)bVar8 * 0x29 >> 0xc;
                  bVar8 = (byte)uVar12;
                  uVar15 = 3;
                  *(undefined2 *)((int)param_1 + 9) =
                       *(undefined2 *)(&DAT_000175eb + (uVar5 + uVar12 * -100 & 0xff) * 2);
                  goto LAB_0001b7fc;
                }
                cVar9 = (&DAT_000175eb)[uVar5 * 2];
                uVar15 = 2;
                *(undefined *)((int)param_1 + 9) = (&DAT_000175ec)[uVar5 * 2];
              }
              *(char *)(param_1 + 2) = cVar9;
              (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,param_1 + 2,uVar15);
            }
            (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016fe4,2);
            pbVar19 = pbVar19 + 1;
          } while (pbVar19 != (byte *)(*(int *)(*(int *)(param_2 + 8) + 4) + -1));
        }
        bVar8 = *pbVar19;
        uVar5 = (uint)bVar8;
        if (uVar5 == 0) {
          (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
        }
        else {
          if (uVar5 < 10) {
            uVar15 = 1;
LAB_0001bda6:
            cVar9 = bVar8 + 0x30;
          }
          else {
            if (99 < uVar5) {
              uVar12 = (uint)bVar8 * 0x29 >> 0xc;
              bVar8 = (byte)uVar12;
              uVar15 = 3;
              *(undefined2 *)((int)param_1 + 9) =
                   *(undefined2 *)(&DAT_000175eb + (uVar5 + uVar12 * -100 & 0xff) * 2);
              goto LAB_0001bda6;
            }
            cVar9 = (&DAT_000175eb)[uVar5 * 2];
            uVar15 = 2;
            *(undefined *)((int)param_1 + 9) = (&DAT_000175ec)[uVar5 * 2];
          }
          *(char *)(param_1 + 2) = cVar9;
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,param_1 + 2,uVar15);
        }
      }
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,&DAT_00016b32,3);
      puVar13 = (undefined4 *)param_1[0x96];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        puVar13 = puVar22;
      }
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,puVar13,uVar17);
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,"\"subtype\": ",0xb);
      if (*(char *)(*(int *)(param_2 + 8) + 0xd) == '\0') {
        piVar4 = (int *)*param_1;
        uVar15 = 4;
        UNRECOVERED_JUMPTABLE = *(code **)(*piVar4 + 4);
        puVar13 = (undefined4 *)&DAT_00015f61;
LAB_0001bf1e:
        (*UNRECOVERED_JUMPTABLE)(piVar4,puVar13,uVar15);
      }
      else {
        bVar8 = *(byte *)(*(int *)(param_2 + 8) + 0xc);
        uVar5 = (uint)bVar8;
        if (uVar5 != 0) {
          puVar13 = param_1 + 2;
          if (uVar5 < 10) {
            uVar15 = 1;
LAB_0001bf0e:
            cVar9 = bVar8 + 0x30;
          }
          else {
            if (99 < uVar5) {
              uVar17 = (uint)bVar8 * 0x29 >> 0xc;
              bVar8 = (byte)uVar17;
              uVar15 = 3;
              *(undefined2 *)((int)param_1 + 9) =
                   *(undefined2 *)(&DAT_000175eb + (uVar5 + uVar17 * -100 & 0xff) * 2);
              goto LAB_0001bf0e;
            }
            cVar9 = (&DAT_000175eb)[uVar5 * 2];
            uVar15 = 2;
            *(undefined *)((int)param_1 + 9) = (&DAT_000175ec)[uVar5 * 2];
          }
          piVar4 = (int *)*param_1;
          *(char *)(param_1 + 2) = cVar9;
          UNRECOVERED_JUMPTABLE = *(code **)(*piVar4 + 4);
          goto LAB_0001bf1e;
        }
        (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
      }
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,10);
      piVar4 = (int *)*param_1;
      UNRECOVERED_JUMPTABLE = *(code **)(*piVar4 + 4);
      puVar13 = (undefined4 *)param_1[0x96];
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        puVar13 = puVar22;
      }
    }
LAB_0001bf78:
    (*UNRECOVERED_JUMPTABLE)(piVar4,puVar13,param_6);
LAB_0001bf7a:
    if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001bf9c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x7d);
      return;
    }
    break;
  case 9:
                    /* WARNING: Could not recover jumptable at 0x0001b83c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,"<discarded>",0xb);
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0001c044 @ 0001c044

int FUN_0001c044(int param_1)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  if ((*(byte *)(param_1 + 0x250) & 1) != 0) {
    free(*(void **)(param_1 + 600));
  }
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    piVar2 = piVar4 + 1;
    DataMemoryBarrier(0x1b);
    do {
      ExclusiveAccess(piVar2);
      iVar3 = *piVar2;
      bVar1 = (bool)hasExclusiveAccess(piVar2);
    } while (!bVar1);
    *piVar2 = iVar3 + -1;
    DataMemoryBarrier(0x1b);
    if (iVar3 == 0) {
      (**(code **)(*piVar4 + 8))(piVar4);
      FUN_0001ee0e(piVar4);
      return param_1;
    }
  }
  return param_1;
}


// ==== FUN_0001c092 @ 0001c092

void FUN_0001c092(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_0001ee0c();
  free(__ptr);
  return;
}


// ==== FUN_0001c0a2 @ 0001c0a2

void FUN_0001c0a2(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001c0a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)(param_1 + 0xc) + 8))((int *)(param_1 + 0xc));
  return;
}


// ==== FUN_0001c0c0 @ 0001c0c0

/* WARNING: Type propagation algorithm not settling */

void FUN_0001c0c0(undefined4 *param_1,byte *param_2,int param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  undefined8 *puVar5;
  undefined4 uVar6;
  undefined1 uVar7;
  undefined2 uVar8;
  uint uVar9;
  int iVar10;
  undefined1 *puVar11;
  int iVar12;
  undefined1 uVar13;
  byte *pbVar15;
  uint uVar14;
  uint unaff_r8;
  int iVar16;
  int iVar17;
  undefined1 auStack_6c [12];
  undefined8 local_60;
  undefined4 local_58;
  undefined8 local_50;
  undefined4 local_48;
  byte local_40 [8];
  void *local_38;
  byte local_34;
  undefined4 local_33;
  void *local_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  bVar1 = *param_2;
  uVar9 = *(uint *)(param_2 + 4);
  if ((bVar1 & 1) == 0) {
    uVar9 = (uint)(bVar1 >> 1);
  }
  if (uVar9 != 0) {
    iVar17 = (int)param_1 + 0x4e;
    iVar16 = 0;
    uVar9 = 0;
    iVar10 = 0;
    iVar12 = 0;
    uVar2 = 0;
    do {
      pbVar15 = *(byte **)(param_2 + 8);
      if ((bVar1 & 1) != 1) {
        pbVar15 = param_2 + 1;
      }
      bVar1 = pbVar15[uVar9];
      uVar14 = (uint)bVar1;
      if (uVar2 == 0) {
        unaff_r8 = 0xffU >> (uint)(byte)(&DAT_0001745b)[uVar14] & uVar14;
      }
      else {
        unaff_r8 = uVar14 & 0x3f | unaff_r8 << 6;
      }
      uVar2 = (uint)(byte)(&DAT_0001755b)[(uint)(byte)(&DAT_0001745b)[uVar14] + uVar2 * 0x10];
      if (uVar2 == 1) {
        iVar3 = param_1[0x97];
        if (1 < iVar3 - 1U) {
          if (iVar3 != 0) {
            uVar2 = 1;
            goto LAB_0001c12c;
          }
          local_34 = 6;
          local_33 = 0;
          FUN_0001c7d4(&local_33,0xb,3,&DAT_00016a32);
          iVar12 = FUN_0001fcbc(0x10);
          FUN_0001f5b8(auStack_6c,uVar9);
          puVar5 = (undefined8 *)FUN_0001f3aa(auStack_6c,0,"invalid UTF-8 byte at index ");
          local_60 = *puVar5;
          local_58 = *(undefined4 *)(puVar5 + 1);
          *(undefined4 *)puVar5 = 0;
          *(undefined4 *)((int)puVar5 + 4) = 0;
          *(undefined4 *)(puVar5 + 1) = 0;
          puVar5 = (undefined8 *)FUN_0001f4da(&local_60,&DAT_00016dc4);
          local_50 = *puVar5;
          local_48 = *(undefined4 *)(puVar5 + 1);
          *(undefined4 *)puVar5 = 0;
          *(undefined4 *)((int)puVar5 + 4) = 0;
          *(undefined4 *)(puVar5 + 1) = 0;
          FUN_0001a800(local_40,&local_50,&local_34);
          FUN_0001a634(iVar12,0x13c,local_40);
          uVar6 = 0;
          FUN_0001fcf8(iVar12,&PTR_PTR_00031404,0x1a7b9);
          goto LAB_0001c504;
        }
        if (iVar10 != 0) {
          uVar9 = uVar9 - 1;
        }
        if (iVar3 == 1) {
          puVar11 = (undefined1 *)((int)param_1 + iVar12 + 0x4e);
          iVar16 = iVar12 + 1;
          if (param_3 == 0) {
            uVar13 = 0xbf;
            *puVar11 = 0xef;
            uVar7 = 0xbd;
            iVar3 = 3;
            iVar10 = 2;
          }
          else {
            uVar13 = 0x66;
            *(undefined1 *)(iVar17 + iVar16) = 0x75;
            iVar3 = 6;
            *puVar11 = 0x5c;
            iVar10 = 5;
            *(undefined2 *)(iVar12 + iVar17 + 2) = 0x6666;
            iVar16 = iVar12 + 4;
            uVar7 = 100;
          }
          *(undefined1 *)(iVar17 + iVar16) = uVar13;
          iVar10 = iVar12 + iVar10;
          iVar12 = iVar12 + iVar3;
          *(undefined1 *)(iVar17 + iVar10) = uVar7;
          uVar2 = iVar12 - 500;
          goto joined_r0x0001c232;
        }
LAB_0001c234:
        uVar2 = 0;
        iVar10 = 0;
        iVar16 = iVar12;
      }
      else if (uVar2 == 0) {
        switch(unaff_r8) {
        case 8:
          uVar8 = 0x625c;
          break;
        case 9:
          uVar8 = 0x745c;
          break;
        case 10:
          uVar8 = 0x6e5c;
          break;
        case 0xb:
        case 0xe:
        case 0xf:
        case 0x10:
        case 0x11:
        case 0x12:
        case 0x13:
        case 0x14:
        case 0x15:
        case 0x16:
        case 0x17:
        case 0x18:
        case 0x19:
        case 0x1a:
        case 0x1b:
        case 0x1c:
        case 0x1d:
        case 0x1e:
        case 0x1f:
        case 0x20:
        case 0x21:
switchD_0001c18c_caseD_b:
          if (unaff_r8 < 0x20) {
LAB_0001c242:
            FUN_0001c7d4((int)param_1 + iVar16 + 0x4e,0xffffffff,7,"\\u%04x");
            iVar12 = iVar16 + 6;
            uVar2 = iVar16 - 0x1ee;
          }
          else if ((param_3 == 0) || (unaff_r8 < 0x7f)) {
            iVar12 = iVar16 + 1;
            *(byte *)((int)param_1 + iVar16 + 0x4e) = bVar1;
            uVar2 = iVar16 - 499;
          }
          else {
            if (unaff_r8 >> 0x10 == 0) goto LAB_0001c242;
            FUN_0001c7d4((int)param_1 + iVar16 + 0x4e,0xffffffff,0xd,"\\u%04x\\u%04x");
            iVar12 = iVar16 + 0xc;
            uVar2 = iVar16 - 0x1e8;
          }
          goto joined_r0x0001c232;
        case 0xc:
          uVar8 = 0x665c;
          break;
        case 0xd:
          uVar8 = 0x725c;
          break;
        case 0x22:
          uVar8 = 0x225c;
          break;
        default:
          if (unaff_r8 != 0x5c) goto switchD_0001c18c_caseD_b;
          uVar8 = 0x5c5c;
        }
        *(undefined2 *)((int)param_1 + iVar16 + 0x4e) = uVar8;
        iVar12 = iVar16 + 2;
        uVar2 = iVar16 - 0x1f2;
joined_r0x0001c232:
        if (0xc < uVar2) goto LAB_0001c234;
        (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,iVar17);
        uVar2 = 0;
        iVar12 = 0;
        iVar10 = 0;
        iVar16 = 0;
      }
      else {
        if (param_3 == 0) {
          *(byte *)((int)param_1 + iVar16 + 0x4e) = bVar1;
          iVar16 = iVar16 + 1;
        }
        iVar10 = iVar10 + 1;
      }
LAB_0001c12c:
      bVar1 = *param_2;
      uVar9 = uVar9 + 1;
      uVar14 = *(uint *)(param_2 + 4);
      if ((bVar1 & 1) == 0) {
        uVar14 = (uint)(bVar1 >> 1);
      }
    } while (uVar9 < uVar14);
    if (uVar2 == 0) {
      if (iVar16 != 0) {
        if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001c35e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,iVar17,iVar16);
          return;
        }
        goto LAB_0001c38a;
      }
    }
    else {
      iVar12 = param_1[0x97];
      if (iVar12 == 1) {
        (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,iVar17);
        piVar4 = (int *)*param_1;
        if (param_3 == 0) {
          if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001c406. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (**(code **)(*piVar4 + 4))(piVar4,&UNK_00016eb7,3);
            return;
          }
        }
        else if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001c3e6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*piVar4 + 4))(piVar4,&UNK_000166fa,6);
          return;
        }
        goto LAB_0001c38a;
      }
      if (iVar12 == 2) {
        if (__stack_chk_guard == local_28) {
                    /* WARNING: Could not recover jumptable at 0x0001c3b0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,iVar17);
          return;
        }
        goto LAB_0001c38a;
      }
      if (iVar12 == 0) {
        local_34 = 6;
        local_33 = 0;
        FUN_0001c7d4(&local_33,0xb,3,&DAT_00016a32);
        uVar6 = FUN_0001fcbc(0x10);
        FUN_0001f51a(local_40,"incomplete UTF-8 string; last byte: 0x",&local_34);
        FUN_0001a634(uVar6,0x13c,local_40);
        iVar12 = 0;
        FUN_0001fcf8(uVar6,&PTR_PTR_00031404,0x1a7b9);
LAB_0001c504:
        if ((local_40[0] & 1) != 0) {
          free(local_38);
        }
        if (iVar12 != 0) {
          FUN_0001fce6(uVar6);
        }
        if ((local_34 & 1) != 0) {
          free(local_2c);
        }
                    /* WARNING: Subroutine does not return */
        FUN_0001fc74();
      }
    }
  }
  if (__stack_chk_guard == local_28) {
    return;
  }
LAB_0001c38a:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0001c7d4 @ 0001c7d4

void FUN_0001c7d4(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined1 param_5)

{
  int iVar1;
  undefined1 uStack00000000;
  
  iVar1 = __stack_chk_guard;
  __vsnprintf_chk(param_1,param_3,0,param_2,param_4,&param_5,&param_5);
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001c818 @ 0001c818

void FUN_0001c818(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5
                 ,uint param_6)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  int iVar21;
  int iVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  bool bVar26;
  bool bVar27;
  bool bVar28;
  
  iVar5 = (param_6 >> 0x14) - 0x433;
  uVar16 = param_6 & 0xfffff;
  if (param_6 < 0x100000) {
    iVar5 = -0x432;
    uVar17 = uVar16;
  }
  else {
    uVar17 = uVar16 + 0x100000;
  }
  uVar11 = uVar17 << 1 | param_5 >> 0x1f;
  iVar4 = iVar5 * -0x13441 + -0x483f3c;
  iVar8 = param_5 * 2;
  iVar9 = iVar5 + -1;
  uVar12 = uVar11;
  iVar22 = -0x3f - iVar5;
  uVar25 = iVar8 + 1;
  do {
    uVar20 = uVar25;
    iVar6 = iVar22;
    uVar10 = uVar12;
    uVar12 = uVar10 << 1 | uVar20 >> 0x1f;
    iVar4 = iVar4 + 0x13441;
    iVar22 = iVar6 + 1;
    uVar25 = uVar20 << 1;
  } while (uVar12 < 0x80000000);
  iVar21 = iVar5 + 0x40;
  uVar12 = uVar17;
  uVar24 = param_5;
  do {
    uVar15 = uVar24;
    uVar18 = uVar12;
    uVar12 = uVar18 << 1 | uVar15 >> 0x1f;
    iVar21 = iVar21 + -1;
    uVar24 = uVar15 << 1;
  } while (uVar12 < 0x80000000);
  iVar4 = (int)(iVar4 + ((uint)(iVar4 >> 0x1f) >> 0xe)) >> 0x12;
  if (0 < iVar6 + 4) {
    iVar4 = iVar4 + 1;
  }
  iVar4 = ((int)(short)((short)(iVar4 + 0x133) +
                       (((ushort)((uint)(iVar4 + 0x133) >> 0x10) & 0x7fff) >> 0xc)) & 0x7ffffff8U) *
          2;
  uVar12 = *(uint *)(&UNK_0001784c + iVar4);
  iVar6 = *(int *)(&UNK_00017850 + iVar4);
  *param_3 = -*(int *)(&UNK_00017854 + iVar4);
  iVar7 = iVar6 - iVar22;
  bVar26 = (param_5 == 0 && uVar16 == 0) && param_6 >> 0x15 != 0;
  if (bVar26) {
    uVar11 = uVar17 << 2 | param_5 >> 0x1e;
    iVar8 = param_5 << 2;
  }
  uVar16 = iVar8 - 1;
  if (bVar26) {
    iVar9 = iVar5 + -2;
  }
  iVar9 = iVar9 + iVar22;
  uVar13 = iVar9 + 0x20;
  uVar17 = uVar16 >> (-iVar9 - 0x20U & 0xff) | uVar11 - (iVar8 == 0) << (iVar9 + 0x40U & 0xff);
  if (-1 < (int)uVar13) {
    uVar17 = uVar16 << (uVar13 & 0xff);
  }
  uVar16 = uVar16 << (iVar9 + 0x40U & 0xff);
  if (-1 < (int)uVar13) {
    uVar16 = 0;
  }
  uVar14 = *(uint *)(&DAT_00017848 + iVar4);
  uVar23 = (uint)((ulonglong)uVar14 * (ulonglong)uVar16 >> 0x20);
  uVar11 = (uint)((ulonglong)uVar12 * (ulonglong)uVar16);
  uVar13 = uVar11 + uVar23;
  uVar19 = (uint)((ulonglong)uVar14 * (ulonglong)uVar17);
  lVar2 = (ulonglong)uVar12 * (ulonglong)uVar17 + ((ulonglong)uVar14 * (ulonglong)uVar17 >> 0x20) +
          ((ulonglong)uVar12 * (ulonglong)uVar16 >> 0x20);
  uVar16 = (uint)lVar2;
  uVar23 = (uint)CARRY4(uVar11,uVar23) + (uint)CARRY4(uVar13,uVar19);
  bVar26 = 0x7fffffff < uVar13 + uVar19;
  uVar17 = uVar16 + uVar23 + (uint)bVar26;
  uVar11 = uVar20 >> 0x1f | uVar10 << 1;
  lVar1 = (ulonglong)uVar14 * (ulonglong)uVar11;
  uVar13 = (uint)lVar1;
  uVar20 = (uint)((ulonglong)uVar12 * (ulonglong)uVar25);
  lVar3 = (ulonglong)uVar12 * (ulonglong)uVar11 +
          CONCAT44(uVar12 * -((int)uVar10 >> 0x1f),
                   uVar14 * -((int)uVar10 >> 0x1f) + (int)((ulonglong)lVar1 >> 0x20)) +
          ((ulonglong)uVar12 * (ulonglong)uVar25 >> 0x20);
  uVar10 = (uint)lVar3;
  uVar25 = (uint)((ulonglong)uVar14 * (ulonglong)uVar25 >> 0x20);
  uVar11 = uVar20 + uVar25;
  uVar25 = (uint)CARRY4(uVar20,uVar25) + (uint)CARRY4(uVar11,uVar13);
  bVar27 = 0x7fffffff < uVar11 + uVar13;
  iVar5 = uVar10 + uVar25 + bVar27;
  uVar11 = uVar15 >> 0x1f | uVar18 << 1;
  lVar1 = (ulonglong)uVar14 * (ulonglong)uVar11;
  uVar13 = (uint)lVar1;
  uVar20 = (uint)((ulonglong)uVar12 * (ulonglong)uVar24);
  uVar15 = (uint)((ulonglong)uVar14 * (ulonglong)uVar24 >> 0x20);
  lVar1 = (ulonglong)uVar12 * (ulonglong)uVar11 +
          CONCAT44(uVar12 * -((int)uVar18 >> 0x1f),
                   uVar14 * -((int)uVar18 >> 0x1f) + (int)((ulonglong)lVar1 >> 0x20)) +
          ((ulonglong)uVar12 * (ulonglong)uVar24 >> 0x20);
  uVar12 = (uint)lVar1;
  uVar11 = uVar20 + uVar15;
  uVar20 = (uint)CARRY4(uVar20,uVar15) + (uint)CARRY4(uVar11,uVar13);
  bVar28 = 0x7fffffff < uVar11 + uVar13;
  FUN_0001cbb8(param_1,param_2,param_3,uVar15,uVar17 + 1,
               (int)((ulonglong)lVar2 >> 0x20) +
               (uint)(CARRY4(uVar16,uVar23) || CARRY4(uVar16 + uVar23,(uint)bVar26)) +
               (uint)(0xfffffffe < uVar17),iVar7,0,uVar12 + uVar20 + bVar28,
               (int)((ulonglong)lVar1 >> 0x20) +
               (uint)(CARRY4(uVar12,uVar20) || CARRY4(uVar12 + uVar20,(uint)bVar28)),iVar6 + iVar21,
               0,iVar5 + -1,
               ((int)((ulonglong)lVar3 >> 0x20) +
               (uint)(CARRY4(uVar10,uVar25) || CARRY4(uVar10 + uVar25,(uint)bVar27))) -
               (uint)(iVar5 == 0),iVar7,0);
  return;
}


// ==== FUN_0001ca80 @ 0001ca80

undefined2 * FUN_0001ca80(undefined2 *param_1,size_t param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  undefined1 uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = param_3 + param_2;
  if ((-1 < param_3) && (iVar5 <= param_5)) {
    FUN_0002a2e8((int)param_1 + param_2,param_3,0x30);
    *(undefined2 *)((int)param_1 + iVar5) = 0x302e;
    return (undefined2 *)((int)param_1 + iVar5) + 1;
  }
  if ((0 < iVar5) && (iVar5 <= param_5)) {
    memmove((void *)((int)param_1 + iVar5 + 1),(void *)((int)param_1 + iVar5),-param_3);
    *(undefined1 *)((int)param_1 + iVar5) = 0x2e;
    return (undefined2 *)((int)param_1 + param_2 + 1);
  }
  if ((param_4 < iVar5) && (iVar5 < 1)) {
    memmove((void *)((int)param_1 + (2 - iVar5)),param_1,param_2);
    *param_1 = 0x2e30;
    FUN_0002a2e8(param_1 + 1,-iVar5,0x30);
    return (undefined2 *)((2 - iVar5) + param_2 + (int)param_1);
  }
  if (param_2 - 1 == 0) {
    iVar1 = 1;
  }
  else {
    memmove(param_1 + 1,(void *)((int)param_1 + 1),param_2 - 1);
    *(undefined1 *)((int)param_1 + 1) = 0x2e;
    iVar1 = param_2 + 1;
  }
  *(undefined1 *)((int)param_1 + iVar1) = 0x65;
  uVar2 = 0x2b;
  if (iVar5 < 1) {
    uVar2 = 0x2d;
  }
  *(undefined1 *)((int)param_1 + iVar1 + 1) = uVar2;
  uVar3 = iVar5 - 1;
  if (iVar5 < 1) {
    uVar3 = 1 - iVar5;
  }
  if (uVar3 < 10) {
    *(char *)((int)param_1 + iVar1 + 3) = (char)uVar3 + '0';
    *(undefined1 *)((int)param_1 + iVar1 + 2) = 0x30;
    return (undefined2 *)((int)param_1 + iVar1 + 4);
  }
  if (uVar3 < 100) {
    *(char *)((int)param_1 + iVar1 + 2) = (char)((uVar3 & 0xff) / 10) + '0';
    *(byte *)((int)param_1 + iVar1 + 3) = (char)uVar3 + (char)((uVar3 & 0xff) / 10) * -10 | 0x30;
    return (undefined2 *)((int)param_1 + iVar1 + 4);
  }
  uVar4 = uVar3 % 100;
  *(char *)((int)param_1 + iVar1 + 2) = (char)(uVar3 / 100) + '0';
  *(byte *)((int)param_1 + iVar1 + 3) = (byte)(uVar4 / 10) | 0x30;
  *(byte *)((int)param_1 + iVar1 + 4) = (char)uVar4 + (char)(uVar4 / 10) * -10 | 0x30;
  return (undefined2 *)((int)param_1 + iVar1 + 5);
}


// ==== FUN_0001cbb8 @ 0001cbb8

uint FUN_0001cbb8(int param_1,uint *param_2,int *param_3,undefined4 param_4,uint param_5,int param_6
                 ,undefined4 param_7,undefined4 param_8,uint param_9,int param_10,
                 undefined4 param_11,undefined4 param_12,uint param_13,uint param_14,int param_15)

{
  ulonglong uVar1;
  ulonglong uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  byte bVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  bool bVar26;
  char *local_44;
  char *local_38;
  int local_34;
  
  uVar12 = -param_15 - 0x20;
  uVar15 = 1 >> (param_15 + 0x20U & 0xff);
  uVar6 = -param_15;
  if (-1 < (int)uVar12) {
    uVar15 = 1 << (uVar12 & 0xff);
  }
  local_38 = (char *)(param_13 >> (uVar6 & 0xff) | param_14 << (param_15 + 0x20U & 0xff));
  if (-1 < (int)uVar12) {
    local_38 = (char *)(param_14 >> (uVar12 & 0xff));
  }
  uVar13 = 1 << (uVar6 & 0xff);
  if (-1 < (int)uVar12) {
    uVar13 = 0;
  }
  uVar23 = param_13 - param_9;
  uVar11 = (param_14 - param_10) - (uint)(param_13 < param_9);
  uVar7 = uVar13 - 1 & param_13;
  uVar18 = uVar15 - (uVar13 == 0);
  uVar25 = param_13 - param_5;
  uVar12 = uVar18 & param_14;
  uVar16 = (param_14 - param_6) - (uint)(param_13 < param_5);
  if (local_38 < (char *)0x3b9aca00) {
    if (local_38 < (char *)0x5f5e100) {
      if (local_38 < (char *)0x989680) {
        if (local_38 < (char *)0xf4240) {
          if (local_38 < "2_GLOBAL__N_116itanium_demangle12InitListExprE") {
            if (local_38 < (char *)0x2710) {
              if ((uint)local_38 >> 3 < 0x7d) {
                if (local_38 < (char *)0x64) {
                  local_44 = (char *)0x1;
                  local_34 = 1;
                  if ((char *)0x9 < local_38) {
                    local_34 = 2;
                    local_44 = (char *)0xa;
                  }
                }
                else {
                  local_34 = 3;
                  local_44 = (char *)0x64;
                }
              }
              else {
                local_34 = 4;
                local_44 = (char *)0x3e8;
              }
            }
            else {
              local_34 = 5;
              local_44 = (char *)0x2710;
            }
          }
          else {
            local_44 = "2_GLOBAL__N_116itanium_demangle12InitListExprE";
            local_34 = 6;
          }
        }
        else {
          local_44 = (char *)0xf4240;
          local_34 = 7;
        }
      }
      else {
        local_44 = (char *)0x989680;
        local_34 = 8;
      }
    }
    else {
      local_44 = (char *)0x5f5e100;
      local_34 = 9;
    }
  }
  else {
    local_34 = 10;
    local_44 = (char *)0x3b9aca00;
  }
  uVar8 = uVar12;
  while (0 < local_34) {
    iVar3 = FUN_00029b64(local_38,local_44,uVar8);
    uVar8 = *param_2;
    local_38 = local_38 + -(iVar3 * (int)local_44);
    *param_2 = uVar8 + 1;
    local_34 = local_34 + -1;
    *(char *)(param_1 + uVar8) = (char)iVar3 + '0';
    uVar8 = param_15 + 0x20;
    uVar14 = (int)local_38 << (uVar6 & 0xff);
    uVar9 = (uint)local_38 >> (uVar8 & 0xff);
    uVar4 = uVar6 - 0x20;
    if (-1 < (int)uVar4) {
      uVar9 = (int)local_38 << (uVar4 & 0xff);
      uVar14 = 0;
    }
    uVar19 = uVar7 + uVar14;
    uVar9 = uVar12 + uVar9 + (uint)CARRY4(uVar7,uVar14);
    if (uVar9 < uVar16 || uVar16 - uVar9 < (uint)(uVar19 <= uVar25)) {
      *param_3 = *param_3 + local_34;
      uVar14 = (uint)local_44 >> (uVar8 & 0xff);
      if (-1 < (int)uVar4) {
        uVar14 = (int)local_44 << (uVar4 & 0xff);
      }
      uVar8 = (uVar16 - uVar9) - (uint)(uVar25 < uVar19);
      uVar22 = (int)local_44 << (uVar6 & 0xff);
      if (-1 < (int)uVar4) {
        uVar22 = 0;
      }
      if (uVar11 < uVar9 || uVar9 - uVar11 < (uint)(uVar23 <= uVar19)) {
        return (uVar9 - uVar11) - (uint)(uVar23 > uVar19);
      }
      bVar26 = uVar22 <= uVar25 - uVar19;
      if (uVar8 <= uVar14 && (uint)bVar26 <= uVar8 - uVar14) {
        return (uVar8 - uVar14) - (uint)!bVar26;
      }
      uVar5 = *param_2;
      uVar4 = uVar9;
      uVar20 = uVar19;
      do {
        uVar10 = uVar20 + uVar22;
        uVar24 = uVar4 + uVar14 + CARRY4(uVar20,uVar22);
        if ((uVar11 < uVar24 || uVar24 - uVar11 < (uint)(uVar23 <= uVar10)) &&
           (uVar4 = (uVar11 - uVar4) - (uint)(uVar23 < uVar20),
           uVar8 = (uVar24 - uVar11) - (uint)(uVar10 < uVar23),
           uVar4 < uVar8 || uVar8 - uVar4 < (uint)(uVar23 - uVar20 <= uVar10 - uVar23))) break;
        *(char *)(param_1 + (uVar5 - 1)) = *(char *)(param_1 + (uVar5 - 1)) + -1;
        uVar21 = (uVar16 - uVar24) - (uint)(uVar25 < uVar10);
        uVar8 = (uVar24 - uVar11) - (uint)(uVar23 > uVar10);
        if (uVar11 < uVar24 || uVar24 - uVar11 < (uint)(uVar23 <= uVar10)) break;
        uVar4 = uVar24;
        uVar20 = uVar10;
      } while (!(uVar21 <= uVar14 && (uint)(uVar22 <= uVar25 - uVar10) <= uVar21 - uVar14));
      if (uVar9 < uVar16 || uVar16 - uVar9 < (uint)(uVar19 <= uVar25)) {
        return (uVar16 - uVar9) - (uint)(uVar19 > uVar25);
      }
    }
    else {
      local_44 = (char *)((uint)local_44 / 10);
      if (uVar9 < uVar16 || uVar16 - uVar9 < (uint)(uVar19 <= uVar25)) {
        return (uVar16 - uVar9) - (uint)(uVar19 > uVar25);
      }
    }
  }
  iVar3 = 0;
  do {
    uVar9 = *param_2;
    uVar8 = (uint)((ulonglong)uVar7 * 10);
    *param_2 = uVar9 + 1;
    uVar12 = (int)((ulonglong)uVar7 * 10 >> 0x20) + uVar12 * 10;
    uVar1 = (ulonglong)uVar25;
    uVar25 = (uint)(uVar1 * 10);
    bVar17 = (byte)(uVar8 >> (uVar6 & 0xff)) | (byte)(uVar12 << (param_15 + 0x20U & 0xff));
    if (-1 < (int)(uVar6 - 0x20)) {
      bVar17 = (byte)(uVar12 >> (uVar6 - 0x20 & 0xff));
    }
    uVar2 = (ulonglong)uVar23;
    uVar23 = (uint)(uVar2 * 10);
    iVar3 = iVar3 + -1;
    *(byte *)(param_1 + uVar9) = bVar17 + 0x30;
    uVar11 = (int)(uVar2 * 10 >> 0x20) + uVar11 * 10;
    uVar16 = (int)(uVar1 * 10 >> 0x20) + uVar16 * 10;
    uVar12 = uVar12 & uVar18;
    uVar7 = uVar8 & uVar13 - 1;
  } while (uVar16 <= uVar12 && (uint)(uVar7 <= uVar25) <= uVar16 - uVar12);
  *param_3 = iVar3 + *param_3;
  uVar18 = uVar25 - uVar7;
  uVar8 = (uVar16 - uVar12) - (uint)(uVar25 < uVar7);
  uVar6 = uVar18;
  if ((uVar11 < uVar12 || uVar12 - uVar11 < (uint)(uVar23 <= uVar7)) ||
     (uVar6 = (uVar8 - uVar15) - (uint)(uVar13 > uVar18),
     uVar8 <= uVar15 && (uint)(uVar13 <= uVar18) <= uVar8 - uVar15)) {
LAB_0001cf64:
    return uVar6;
  }
  uVar6 = *param_2;
  iVar3 = uVar6 - 1;
  do {
    uVar18 = uVar13 + uVar7;
    uVar8 = uVar15 + uVar12 + (uint)CARRY4(uVar13,uVar7);
    if (uVar11 < uVar8 || uVar8 - uVar11 < (uint)(uVar23 <= uVar18)) {
      uVar9 = (uVar11 - uVar12) - (uint)(uVar23 < uVar7);
      uVar12 = (uVar8 - uVar11) - (uint)(uVar18 < uVar23);
      uVar6 = uVar16;
      if (uVar9 < uVar12 || uVar12 - uVar9 < (uint)(uVar23 - uVar7 <= uVar18 - uVar23))
      goto LAB_0001cf64;
    }
    *(char *)(param_1 + iVar3) = *(char *)(param_1 + iVar3) + -1;
    uVar9 = (uVar16 - uVar8) - (uint)(uVar25 < uVar18);
    if (uVar11 < uVar8 || uVar8 - uVar11 < (uint)(uVar23 <= uVar18)) {
      return uVar6;
    }
    uVar12 = uVar8;
    uVar7 = uVar18;
    if (uVar9 <= uVar15 && (uint)(uVar13 <= uVar25 - uVar18) <= uVar9 - uVar15) {
      return uVar6;
    }
  } while( true );
}


// ==== FUN_0001cf6c @ 0001cf6c

void FUN_0001cf6c(undefined4 *param_1,void *param_2)

{
  int iVar1;
  void *pvVar2;
  uint uVar3;
  size_t __n;
  void *__src;
  
  pvVar2 = (void *)param_1[1];
  if (pvVar2 < (void *)param_1[2]) {
    memcpy(pvVar2,param_2,0x50);
    param_1[1] = (int)pvVar2 + 0x50;
  }
  else {
    __src = (void *)*param_1;
    __n = (int)pvVar2 - (int)__src;
    uVar3 = ((int)__n >> 4) * -0x33333333 + 1;
    if (0x3333333 < uVar3) {
      FUN_0001fc64(param_1);
LAB_0001d050:
                    /* WARNING: Subroutine does not return */
      FUN_0001a480("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
    }
    iVar1 = (int)param_1[2] - (int)__src >> 4;
    if (uVar3 <= (uint)(iVar1 * -0x66666666)) {
      uVar3 = iVar1 * -0x66666666;
    }
    if (0x1999998 < (uint)(iVar1 * -0x33333333)) {
      uVar3 = 0x3333333;
    }
    if (uVar3 == 0) {
      iVar1 = 0;
    }
    else {
      if (0x3333333 < uVar3) goto LAB_0001d050;
      iVar1 = FUN_0001ee80(uVar3 * 0x50);
    }
    pvVar2 = (void *)(iVar1 + ((int)__n >> 4) * 0x10);
    memcpy(pvVar2,param_2,0x50);
    if (0 < (int)__n) {
      memcpy((void *)((int)pvVar2 - __n),__src,__n);
      __src = (void *)*param_1;
    }
    *param_1 = (void *)((int)pvVar2 - __n);
    param_1[1] = (int)pvVar2 + 0x50;
    param_1[2] = iVar1 + uVar3 * 0x50;
    if (__src != (void *)0x0) {
      free(__src);
      return;
    }
  }
  return;
}


// ==== _INIT_0 @ 0001d05c

void _INIT_0(void)

{
  DAT_00036a54._4_4_ = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
  DAT_00036a5c._0_4_ = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
  DAT_00036a5c._4_4_ = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
  DAT_00036a50 = 1000;
  DAT_00036a54._0_4_ = 0;
  DAT_00036a64 = (undefined *)0x0;
  DAT_00036a5c._0_4_ = FUN_0001ee80(&DAT_00013880);
  DAT_00036a64 = &DAT_00013880 + (int)DAT_00036a5c;
  DAT_00036a5c._4_4_ = (int)DAT_00036a5c;
  __cxa_atexit(&UNK_00018f2d,&DAT_00036a50,&DAT_000313d0);
  return;
}


// ==== thunk_FUN_0001d0e0 @ 0001d0d0

void thunk_FUN_0001d0e0(char *param_1,char *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  undefined8 *__ptr;
  char *pcVar2;
  int unaff_r4;
  undefined1 auStack_38 [20];
  uchar *puStack_24;
  
  puStack_24 = __stack_chk_guard;
  if (param_1 != (char *)0x0) {
    if (param_2 != (char *)0x0) {
      unaff_r4 = param_3;
    }
    if (param_2 != (char *)0x0 && param_3 != 0) {
      if (DAT_00036b6c == 0) {
        iVar1 = regcomp((regex_t *)auStack_38,param_1,4);
        if ((iVar1 == 0) && (__ptr = malloc(0x24), __ptr != (undefined8 *)0x0)) {
          pcVar2 = strdup(param_2);
          *(char **)(__ptr + 2) = pcVar2;
          if (pcVar2 == (char *)0x0) {
            free(__ptr);
          }
          else {
            *__ptr = auStack_38._0_8_;
            __ptr[1] = auStack_38._8_8_;
            *(int *)((int)__ptr + 0x14) = unaff_r4;
            *(undefined4 *)(__ptr + 3) = param_4;
            pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
            *(undefined4 *)((int)__ptr + 0x1c) = 0;
            *(undefined4 **)(__ptr + 4) = DAT_00036a0c;
            *DAT_00036a0c = __ptr;
            DAT_00036a0c = (undefined4 *)((int)__ptr + 0x1c);
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
          }
        }
      }
      else if (DAT_00036a18 < 7) {
        __android_log_print(6,"xhook","do not register hook after refresh(): %s, %s",param_1,param_2
                           );
      }
    }
  }
  if (__stack_chk_guard != puStack_24) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puStack_24);
  }
  return;
}


// ==== thunk_FUN_0001d1e4 @ 0001d0d4

void thunk_FUN_0001d1e4(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  pthread_mutex_t *__mutex;
  _union_1051 _Stack_2c;
  undefined4 uStack_28;
  int iStack_1c;
  
  iStack_1c = __stack_chk_guard;
  if (DAT_00036b6c == 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
    if (DAT_00036b6c == 0) {
      DAT_00036b6c = 1;
      if (DAT_00036a18 < 5) {
        uVar2 = FUN_0001ede0();
        __android_log_print(4,"xhook",&DAT_00017232,uVar2);
      }
      if (DAT_00036a04 != 0) {
        _Stack_2c.sa_handler = FUN_0001d754 + 1;
        uStack_28 = 0;
        iVar1 = sigaction(0xb,(sigaction *)&_Stack_2c,(sigaction *)&DAT_00036b9c);
        if (iVar1 != 0) goto LAB_0001d25c;
      }
      DAT_00036b74 = 1;
    }
LAB_0001d25c:
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
  }
  if (DAT_00036b74 == 0) {
LAB_0001d2da:
    uVar2 = 0x3e9;
  }
  else {
    if (param_1 == 0) {
      __mutex = (pthread_mutex_t *)&DAT_00036b84;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b84);
      FUN_0001d80c();
    }
    else {
      if (DAT_00036b90 == 0) {
        pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
        if (DAT_00036b90 == 0) {
          DAT_00036b90 = 1;
          DAT_00036b88 = 1;
          iVar1 = pthread_create(&DAT_00036b8c,(pthread_attr_t *)0x0,FUN_0001d788 + 1,(void *)0x0);
          if (iVar1 == 0) {
            DAT_00036b78 = 1;
          }
          else {
            DAT_00036b88 = 0;
          }
        }
        pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
      }
      if (DAT_00036b78 == 0) goto LAB_0001d2da;
      __mutex = (pthread_mutex_t *)&DAT_00036b70;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
      DAT_00036b7c = 1;
      pthread_cond_signal((pthread_cond_t *)&DAT_00036b80);
    }
    pthread_mutex_unlock(__mutex);
    uVar2 = 0;
  }
  if (__stack_chk_guard != iStack_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar2);
  }
  return;
}


// ==== thunk_FUN_0001d31c @ 0001d0d8

void thunk_FUN_0001d31c(void)

{
  undefined4 *puVar1;
  regex_t *prVar2;
  undefined4 *puVar3;
  uchar *puVar4;
  undefined4 *__ptr;
  undefined4 *puVar5;
  regex_t *prVar6;
  
  if (DAT_00036b78 != 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
    DAT_00036b88 = 0;
    pthread_cond_signal((pthread_cond_t *)&DAT_00036b80);
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
    pthread_join(DAT_00036b8c,(void **)0x0);
    DAT_00036b78 = 0;
  }
  DAT_00036b90 = 0;
  if (DAT_00036b74 != 0) {
    if (DAT_00036a04 != 0) {
      sigaction(0xb,(sigaction *)&DAT_00036b9c,(sigaction *)0x0);
    }
    DAT_00036b74 = 0;
  }
  DAT_00036b6c = 0;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b84);
  puVar3 = &DAT_00036b94;
  puVar5 = (undefined4 *)0x0;
  do {
    __ptr = puVar5;
    puVar5 = (undefined4 *)*puVar3;
    puVar3 = puVar5 + 0x1b;
  } while (puVar5 != (undefined4 *)0x0);
  do {
    if (__ptr == (undefined4 *)0x0) {
      prVar2 = DAT_00036a08;
      while (prVar2 != (regex_t *)0x0) {
        prVar6 = *(regex_t **)&prVar2->field_0x1c;
        puVar4 = prVar2[1].buffer;
        if (prVar6 == (regex_t *)0x0) {
          DAT_00036a0c = puVar4;
        }
        else {
          prVar6[1].buffer = puVar4;
          puVar4 = prVar2[1].buffer;
        }
        *(regex_t **)puVar4 = prVar6;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar6;
      }
      prVar2 = DAT_00036a10;
      while (prVar2 != (regex_t *)0x0) {
        prVar6 = (regex_t *)prVar2->translate;
        puVar5 = (undefined4 *)prVar2->re_nsub;
        if (prVar6 == (regex_t *)0x0) {
          DAT_00036a14 = puVar5;
        }
        else {
          prVar6->re_nsub = (size_t)puVar5;
          puVar5 = (undefined4 *)prVar2->re_nsub;
        }
        *puVar5 = prVar6;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar6;
      }
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b84);
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
      return;
    }
    puVar5 = (undefined4 *)__ptr[0x1c];
    if ((undefined4 *)__ptr[0x1c] == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)__ptr[0x1d];
      if (puVar3 != (undefined4 *)0x0) {
        if ((undefined4 *)puVar3[0x1b] == __ptr) goto LAB_0001d40a;
        puVar5 = __ptr;
        do {
          if (puVar5 != (undefined4 *)puVar3[0x1c]) goto LAB_0001d40a;
          puVar1 = puVar3 + 0x1d;
          puVar5 = puVar3;
          puVar3 = (undefined4 *)*puVar1;
        } while ((undefined4 *)*puVar1 != (undefined4 *)0x0);
      }
      puVar3 = (undefined4 *)0x0;
    }
    else {
      do {
        puVar3 = puVar5;
        puVar5 = (undefined4 *)puVar3[0x1b];
      } while ((undefined4 *)puVar3[0x1b] != (undefined4 *)0x0);
    }
LAB_0001d40a:
    FUN_0001d45c(__ptr);
    if ((void *)*__ptr != (void *)0x0) {
      free((void *)*__ptr);
    }
    free(__ptr);
    __ptr = puVar3;
  } while( true );
}


// ==== thunk_FUN_0001d740 @ 0001d0dc

void thunk_FUN_0001d740(int param_1)

{
  DAT_00036a04 = (uint)(param_1 != 0);
  return;
}


// ==== FUN_0001d0e0 @ 0001d0e0

void FUN_0001d0e0(char *param_1,char *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  undefined8 *__ptr;
  char *pcVar2;
  int unaff_r4;
  undefined1 local_38 [20];
  uchar *local_24;
  
  local_24 = __stack_chk_guard;
  if (param_1 != (char *)0x0) {
    if (param_2 != (char *)0x0) {
      unaff_r4 = param_3;
    }
    if (param_2 != (char *)0x0 && param_3 != 0) {
      if (DAT_00036b6c == 0) {
        iVar1 = regcomp((regex_t *)local_38,param_1,4);
        if ((iVar1 == 0) && (__ptr = malloc(0x24), __ptr != (undefined8 *)0x0)) {
          pcVar2 = strdup(param_2);
          *(char **)(__ptr + 2) = pcVar2;
          if (pcVar2 == (char *)0x0) {
            free(__ptr);
          }
          else {
            *__ptr = local_38._0_8_;
            __ptr[1] = local_38._8_8_;
            *(int *)((int)__ptr + 0x14) = unaff_r4;
            *(undefined4 *)(__ptr + 3) = param_4;
            pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
            *(undefined4 *)((int)__ptr + 0x1c) = 0;
            *(undefined4 **)(__ptr + 4) = DAT_00036a0c;
            *DAT_00036a0c = __ptr;
            DAT_00036a0c = (undefined4 *)((int)__ptr + 0x1c);
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
          }
        }
      }
      else if (DAT_00036a18 < 7) {
        __android_log_print(6,"xhook","do not register hook after refresh(): %s, %s",param_1,param_2
                           );
      }
    }
  }
  if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_24);
  }
  return;
}


// ==== FUN_0001d1e4 @ 0001d1e4

void FUN_0001d1e4(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  pthread_mutex_t *__mutex;
  _union_1051 local_2c;
  undefined4 uStack_28;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  if (DAT_00036b6c == 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
    if (DAT_00036b6c == 0) {
      DAT_00036b6c = 1;
      if (DAT_00036a18 < 5) {
        uVar2 = FUN_0001ede0();
        __android_log_print(4,"xhook",&DAT_00017232,uVar2);
      }
      if (DAT_00036a04 != 0) {
        local_2c.sa_handler = FUN_0001d754 + 1;
        uStack_28 = 0;
        iVar1 = sigaction(0xb,(sigaction *)&local_2c,(sigaction *)&DAT_00036b9c);
        if (iVar1 != 0) goto LAB_0001d25c;
      }
      DAT_00036b74 = 1;
    }
LAB_0001d25c:
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
  }
  if (DAT_00036b74 == 0) {
LAB_0001d2da:
    uVar2 = 0x3e9;
  }
  else {
    if (param_1 == 0) {
      __mutex = (pthread_mutex_t *)&DAT_00036b84;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b84);
      FUN_0001d80c();
    }
    else {
      if (DAT_00036b90 == 0) {
        pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
        if (DAT_00036b90 == 0) {
          DAT_00036b90 = 1;
          DAT_00036b88 = 1;
          iVar1 = pthread_create(&DAT_00036b8c,(pthread_attr_t *)0x0,FUN_0001d788 + 1,(void *)0x0);
          if (iVar1 == 0) {
            DAT_00036b78 = 1;
          }
          else {
            DAT_00036b88 = 0;
          }
        }
        pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
      }
      if (DAT_00036b78 == 0) goto LAB_0001d2da;
      __mutex = (pthread_mutex_t *)&DAT_00036b70;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
      DAT_00036b7c = 1;
      pthread_cond_signal((pthread_cond_t *)&DAT_00036b80);
    }
    pthread_mutex_unlock(__mutex);
    uVar2 = 0;
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar2);
  }
  return;
}


// ==== FUN_0001d31c @ 0001d31c

void FUN_0001d31c(void)

{
  undefined4 *puVar1;
  regex_t *prVar2;
  undefined4 *puVar3;
  uchar *puVar4;
  undefined4 *__ptr;
  undefined4 *puVar5;
  regex_t *prVar6;
  
  if (DAT_00036b78 != 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
    DAT_00036b88 = 0;
    pthread_cond_signal((pthread_cond_t *)&DAT_00036b80);
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
    pthread_join(DAT_00036b8c,(void **)0x0);
    DAT_00036b78 = 0;
  }
  DAT_00036b90 = 0;
  if (DAT_00036b74 != 0) {
    if (DAT_00036a04 != 0) {
      sigaction(0xb,(sigaction *)&DAT_00036b9c,(sigaction *)0x0);
    }
    DAT_00036b74 = 0;
  }
  DAT_00036b6c = 0;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b84);
  puVar3 = &DAT_00036b94;
  puVar5 = (undefined4 *)0x0;
  do {
    __ptr = puVar5;
    puVar5 = (undefined4 *)*puVar3;
    puVar3 = puVar5 + 0x1b;
  } while (puVar5 != (undefined4 *)0x0);
  do {
    if (__ptr == (undefined4 *)0x0) {
      prVar2 = DAT_00036a08;
      while (prVar2 != (regex_t *)0x0) {
        prVar6 = *(regex_t **)&prVar2->field_0x1c;
        puVar4 = prVar2[1].buffer;
        if (prVar6 == (regex_t *)0x0) {
          DAT_00036a0c = puVar4;
        }
        else {
          prVar6[1].buffer = puVar4;
          puVar4 = prVar2[1].buffer;
        }
        *(regex_t **)puVar4 = prVar6;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar6;
      }
      prVar2 = DAT_00036a10;
      while (prVar2 != (regex_t *)0x0) {
        prVar6 = (regex_t *)prVar2->translate;
        puVar5 = (undefined4 *)prVar2->re_nsub;
        if (prVar6 == (regex_t *)0x0) {
          DAT_00036a14 = puVar5;
        }
        else {
          prVar6->re_nsub = (size_t)puVar5;
          puVar5 = (undefined4 *)prVar2->re_nsub;
        }
        *puVar5 = prVar6;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar6;
      }
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b84);
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
      return;
    }
    puVar5 = (undefined4 *)__ptr[0x1c];
    if ((undefined4 *)__ptr[0x1c] == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)__ptr[0x1d];
      if (puVar3 != (undefined4 *)0x0) {
        if ((undefined4 *)puVar3[0x1b] == __ptr) goto LAB_0001d40a;
        puVar5 = __ptr;
        do {
          if (puVar5 != (undefined4 *)puVar3[0x1c]) goto LAB_0001d40a;
          puVar1 = puVar3 + 0x1d;
          puVar5 = puVar3;
          puVar3 = (undefined4 *)*puVar1;
        } while ((undefined4 *)*puVar1 != (undefined4 *)0x0);
      }
      puVar3 = (undefined4 *)0x0;
    }
    else {
      do {
        puVar3 = puVar5;
        puVar5 = (undefined4 *)puVar3[0x1b];
      } while ((undefined4 *)puVar3[0x1b] != (undefined4 *)0x0);
    }
LAB_0001d40a:
    FUN_0001d45c(__ptr);
    if ((void *)*__ptr != (void *)0x0) {
      free((void *)*__ptr);
    }
    free(__ptr);
    __ptr = puVar3;
  } while( true );
}


// ==== FUN_0001d45c @ 0001d45c

undefined4 * FUN_0001d45c(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  undefined8 uVar12;
  
  puVar10 = (undefined4 *)param_1[0x1b];
  puVar5 = (undefined4 *)param_1[0x1c];
  if (puVar10 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)param_1[0x1d];
    iVar11 = param_1[0x1e];
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
      goto joined_r0x0001d512;
    }
    puVar5[0x1d] = puVar3;
    if (puVar3 != (undefined4 *)0x0) goto LAB_0001d4be;
LAB_0001d514:
    param_1 = &DAT_00036b6c;
    puVar10 = &DAT_00036b94;
    puVar3 = (undefined4 *)0x0;
  }
  else {
    if (puVar5 != (undefined4 *)0x0) {
      do {
        puVar2 = puVar5;
        puVar5 = (undefined4 *)puVar2[0x1b];
      } while (puVar5 != (undefined4 *)0x0);
      puVar5 = (undefined4 *)puVar2[0x1c];
      puVar3 = (undefined4 *)puVar2[0x1d];
      puVar10 = &DAT_00036b94;
      iVar11 = puVar2[0x1e];
      if (puVar5 != (undefined4 *)0x0) {
        puVar5[0x1d] = puVar3;
      }
      if (puVar3 == (undefined4 *)0x0) {
        puVar6 = &DAT_00036b94;
      }
      else {
        puVar6 = puVar3 + 0x1b;
        if ((undefined4 *)*puVar6 != puVar2) {
          puVar6 = puVar3 + 0x1c;
        }
      }
      *puVar6 = puVar5;
      puVar6 = (undefined4 *)puVar2[0x1d];
      uVar12 = *(undefined8 *)(param_1 + 0x1d);
      *(undefined8 *)(puVar2 + 0x1b) = *(undefined8 *)(param_1 + 0x1b);
      *(undefined8 *)(puVar2 + 0x1d) = uVar12;
      if (puVar6 == param_1) {
        puVar3 = puVar2;
      }
      iVar7 = param_1[0x1d];
      if ((iVar7 != 0) &&
         (puVar10 = (undefined4 *)(iVar7 + 0x6c), (undefined4 *)*puVar10 != param_1)) {
        puVar10 = (undefined4 *)(iVar7 + 0x70);
      }
      *puVar10 = puVar2;
      piVar1 = param_1 + 0x1b;
      param_1 = (undefined4 *)param_1[0x1c];
      *(undefined4 **)(*piVar1 + 0x74) = puVar2;
      puVar10 = DAT_00036b94;
      if (param_1 != (undefined4 *)0x0) {
        param_1[0x1d] = puVar2;
        puVar10 = DAT_00036b94;
      }
      goto joined_r0x0001d506;
    }
    puVar3 = (undefined4 *)param_1[0x1d];
    iVar11 = param_1[0x1e];
    puVar10[0x1d] = puVar3;
    puVar5 = puVar10;
joined_r0x0001d512:
    if (puVar3 == (undefined4 *)0x0) goto LAB_0001d514;
LAB_0001d4be:
    puVar10 = puVar3 + 0x1b;
    if ((undefined4 *)*puVar10 != param_1) {
      puVar10 = puVar3 + 0x1c;
    }
  }
  *puVar10 = puVar5;
  puVar10 = DAT_00036b94;
joined_r0x0001d506:
  if (iVar11 != 0) {
    DAT_00036b94 = puVar10;
    return param_1;
  }
  puVar2 = &DAT_00036b6c;
  DAT_00036b94 = puVar10;
  do {
    puVar6 = puVar3;
    if (puVar5 == (undefined4 *)0x0) {
      if (puVar10 == (undefined4 *)0x0) {
        return puVar2;
      }
    }
    else {
      if (puVar5[0x1e] != 0) goto LAB_0001d646;
      if (puVar5 == puVar10) {
        puVar5[0x1e] = 0;
        return (undefined4 *)0x0;
      }
    }
    puVar3 = (undefined4 *)puVar6[0x1b];
    if (puVar3 == puVar5) {
      puVar9 = (undefined4 *)puVar6[0x1c];
      puVar3 = (undefined4 *)puVar9[0x1e];
      if (puVar3 == (undefined4 *)0x1) {
        puVar5 = (undefined4 *)puVar9[0x1b];
        puVar9[0x1e] = 0;
        puVar6[0x1e] = 1;
        puVar6[0x1c] = puVar5;
        if (puVar5 != (undefined4 *)0x0) {
          puVar5[0x1d] = puVar6;
        }
        iVar11 = puVar6[0x1d];
        puVar9[0x1d] = iVar11;
        if (iVar11 == 0) {
          puVar3 = &DAT_00036b6c;
          puVar10 = puVar9;
          DAT_00036b94 = puVar9;
        }
        else {
          puVar3 = (undefined4 *)puVar6[0x1d];
          if (puVar6 == (undefined4 *)puVar3[0x1b]) {
            puVar3[0x1b] = puVar9;
          }
          else {
            puVar3[0x1c] = puVar9;
            puVar5 = (undefined4 *)puVar6[0x1c];
          }
        }
        puVar6[0x1d] = puVar9;
        puVar9[0x1b] = puVar6;
        puVar9 = puVar5;
        puVar5 = puVar10;
      }
      else {
        puVar5 = puVar10;
      }
      puVar2 = (undefined4 *)puVar9[0x1b];
      if (puVar2 != (undefined4 *)0x0) {
        puVar3 = (undefined4 *)puVar2[0x1e];
      }
      if (puVar2 != (undefined4 *)0x0 && puVar3 != (undefined4 *)0x0) {
        iVar11 = puVar9[0x1c];
        if (iVar11 != 0) {
          puVar3 = *(undefined4 **)(iVar11 + 0x78);
        }
        if (iVar11 != 0 && puVar3 != (undefined4 *)0x0) goto LAB_0001d68e;
        puVar2[0x1e] = 0;
        iVar11 = puVar2[0x1c];
        puVar9[0x1e] = 1;
        puVar9[0x1b] = iVar11;
        if (iVar11 != 0) {
          *(undefined4 **)(iVar11 + 0x74) = puVar9;
        }
        iVar11 = puVar9[0x1d];
        puVar2[0x1d] = iVar11;
        if (iVar11 == 0) {
          puVar10 = &DAT_00036b94;
          puVar5 = puVar2;
        }
        else {
          puVar10 = (undefined4 *)(puVar9[0x1d] + 0x6c);
          if (puVar9 != (undefined4 *)*puVar10) {
            puVar10 = (undefined4 *)(puVar9[0x1d] + 0x70);
          }
        }
        *puVar10 = puVar2;
        puVar2[0x1c] = puVar9;
        puVar10 = (undefined4 *)puVar6[0x1c];
        uVar8 = puVar6[0x1e];
        puVar9[0x1d] = puVar2;
        puVar10[0x1e] = uVar8;
        iVar11 = puVar10[0x1c];
        puVar6[0x1e] = 0;
        if (iVar11 != 0) goto LAB_0001d706;
      }
      else {
        iVar11 = puVar9[0x1c];
        if (iVar11 != 0) {
          puVar2 = *(undefined4 **)(iVar11 + 0x78);
        }
        puVar10 = puVar5;
        if (iVar11 == 0 || puVar2 == (undefined4 *)0x0) goto LAB_0001d532;
LAB_0001d68e:
        puVar9[0x1e] = puVar6[0x1e];
        puVar6[0x1e] = 0;
        puVar10 = puVar9;
LAB_0001d706:
        *(undefined4 *)(iVar11 + 0x78) = 0;
      }
      iVar11 = puVar10[0x1b];
      puVar6[0x1c] = iVar11;
      if (iVar11 != 0) {
        *(undefined4 **)(iVar11 + 0x74) = puVar6;
      }
      iVar11 = puVar6[0x1d];
      puVar10[0x1d] = iVar11;
      if (iVar11 == 0) {
        puVar3 = &DAT_00036b94;
        puVar5 = puVar10;
      }
      else {
        puVar3 = (undefined4 *)(puVar6[0x1d] + 0x6c);
        if (puVar6 != (undefined4 *)*puVar3) {
          puVar3 = (undefined4 *)(puVar6[0x1d] + 0x70);
        }
      }
      *puVar3 = puVar10;
      puVar6[0x1d] = puVar10;
      puVar10[0x1b] = puVar6;
      if (puVar5 == (undefined4 *)0x0) {
        return puVar3;
      }
      goto LAB_0001d646;
    }
    puVar4 = (undefined4 *)puVar3[0x1e];
    if (puVar4 == (undefined4 *)0x1) {
      puVar9 = (undefined4 *)puVar3[0x1c];
      puVar3[0x1e] = 0;
      puVar6[0x1e] = 1;
      puVar6[0x1b] = puVar9;
      if (puVar9 != (undefined4 *)0x0) {
        puVar9[0x1d] = puVar6;
      }
      iVar11 = puVar6[0x1d];
      puVar3[0x1d] = iVar11;
      if (iVar11 == 0) {
        puVar4 = &DAT_00036b6c;
        puVar10 = puVar3;
        DAT_00036b94 = puVar3;
      }
      else {
        puVar4 = (undefined4 *)puVar6[0x1d];
        if (puVar6 == (undefined4 *)puVar4[0x1b]) {
          puVar4[0x1b] = puVar3;
          puVar9 = (undefined4 *)puVar6[0x1b];
        }
        else {
          puVar4[0x1c] = puVar3;
        }
      }
      puVar6[0x1d] = puVar3;
      puVar3[0x1c] = puVar6;
      puVar5 = puVar10;
    }
    else {
      puVar9 = puVar3;
      puVar5 = puVar10;
    }
    iVar11 = puVar9[0x1b];
    if (iVar11 != 0) {
      puVar3 = *(undefined4 **)(iVar11 + 0x78);
    }
    if (iVar11 != 0 && puVar3 != (undefined4 *)0x0) goto LAB_0001d638;
    puVar2 = (undefined4 *)puVar9[0x1c];
    if (puVar2 != (undefined4 *)0x0) {
      puVar4 = (undefined4 *)puVar2[0x1e];
    }
    puVar10 = puVar5;
    if (puVar2 != (undefined4 *)0x0 && puVar4 != (undefined4 *)0x0) break;
LAB_0001d532:
    puVar3 = (undefined4 *)puVar6[0x1d];
    puVar9[0x1e] = 1;
    puVar5 = puVar6;
  } while( true );
  if (iVar11 != 0) {
    puVar4 = *(undefined4 **)(iVar11 + 0x78);
  }
  if (iVar11 != 0 && puVar4 != (undefined4 *)0x0) {
LAB_0001d638:
    puVar9[0x1e] = puVar6[0x1e];
    puVar6[0x1e] = 0;
  }
  else {
    puVar2[0x1e] = 0;
    iVar11 = puVar2[0x1b];
    puVar9[0x1e] = 1;
    puVar9[0x1c] = iVar11;
    if (iVar11 != 0) {
      *(undefined4 **)(iVar11 + 0x74) = puVar9;
    }
    iVar11 = puVar9[0x1d];
    puVar2[0x1d] = iVar11;
    if (iVar11 == 0) {
      puVar10 = &DAT_00036b94;
      puVar5 = puVar2;
    }
    else {
      puVar10 = (undefined4 *)(puVar9[0x1d] + 0x6c);
      if (puVar9 != (undefined4 *)*puVar10) {
        puVar10 = (undefined4 *)(puVar9[0x1d] + 0x70);
      }
    }
    *puVar10 = puVar2;
    puVar2[0x1b] = puVar9;
    puVar10 = (undefined4 *)puVar6[0x1b];
    uVar8 = puVar6[0x1e];
    puVar9[0x1d] = puVar2;
    puVar10[0x1e] = uVar8;
    iVar11 = puVar10[0x1b];
    puVar6[0x1e] = 0;
    puVar9 = puVar10;
    if (iVar11 == 0) goto LAB_0001d6ba;
  }
  *(undefined4 *)(iVar11 + 0x78) = 0;
LAB_0001d6ba:
  iVar11 = puVar9[0x1c];
  puVar6[0x1b] = iVar11;
  if (iVar11 != 0) {
    *(undefined4 **)(iVar11 + 0x74) = puVar6;
  }
  iVar11 = puVar6[0x1d];
  puVar9[0x1d] = iVar11;
  if (iVar11 == 0) {
    puVar10 = &DAT_00036b94;
    puVar5 = puVar9;
  }
  else {
    puVar10 = (undefined4 *)(puVar6[0x1d] + 0x6c);
    if (puVar6 != (undefined4 *)*puVar10) {
      puVar10 = (undefined4 *)(puVar6[0x1d] + 0x70);
    }
  }
  *puVar10 = puVar9;
  puVar6[0x1d] = puVar9;
  puVar9[0x1c] = puVar6;
  if (puVar5 == (undefined4 *)0x0) {
    return puVar10;
  }
LAB_0001d646:
  puVar5[0x1e] = 0;
  return (undefined4 *)0x0;
}


// ==== FUN_0001d740 @ 0001d740

void FUN_0001d740(int param_1)

{
  DAT_00036a04 = (uint)(param_1 != 0);
  return;
}


// ==== FUN_0001d754 @ 0001d754

void FUN_0001d754(void)

{
  if (DAT_00036b98 != 0) {
                    /* WARNING: Subroutine does not return */
    siglongjmp((__jmp_buf_tag *)&DAT_00036a68,1);
  }
  sigaction(0xb,(sigaction *)&DAT_00036b9c,(sigaction *)0x0);
  return;
}


// ==== FUN_0001d788 @ 0001d788

undefined4 FUN_0001d788(void)

{
  pthread_t __target_thread;
  
  __target_thread = pthread_self();
  pthread_setname_np(__target_thread,"xh_refresh_loop");
  while( true ) {
    if (DAT_00036b88 == 0) {
      return 0;
    }
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b70);
    while ((DAT_00036b7c == 0 && (DAT_00036b88 != 0))) {
      pthread_cond_wait((pthread_cond_t *)&DAT_00036b80,(pthread_mutex_t *)&DAT_00036b70);
    }
    if (DAT_00036b88 == 0) break;
    DAT_00036b7c = 0;
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00036b84);
    FUN_0001d80c();
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b84);
  }
  pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036b70);
  return 0;
}


// ==== FUN_0001d80c @ 0001d80c

void FUN_0001d80c(void)

{
  char *__s;
  undefined4 *puVar1;
  regex_t *__preg;
  FILE *__stream;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  size_t sVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *__ptr;
  undefined4 *puVar8;
  regex_t *__preg_00;
  bool bVar9;
  undefined4 *local_240;
  int local_23c;
  uint local_238;
  uint local_234;
  byte local_22d [3];
  byte local_22a;
  char acStack_229 [513];
  int local_28;
  
  local_28 = __stack_chk_guard;
  local_240 = (undefined4 *)0x0;
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    if (DAT_00036a18 < 7) {
      if (__stack_chk_guard == local_28) {
        __android_log_print(6,"xhook","fopen /proc/self/maps failed");
        return;
      }
      goto LAB_0001daa0;
    }
  }
  else {
    __s = acStack_229 + 1;
    pcVar2 = fgets(__s,0x200,__stream);
    if (pcVar2 != (char *)0x0) {
LAB_0001d8ba:
      uVar3 = sscanf(__s,"%x-%*lx %4s %lx %*x:%*x %*d%n",&local_234,(char *)local_22d,&local_238,
                     &local_23c);
      bVar9 = uVar3 == 3;
      if (bVar9) {
        uVar3 = (uint)local_22d[0];
      }
      if (bVar9 && uVar3 == 0x72) {
        uVar4 = (uint)local_22a;
        uVar3 = uVar4;
        if (uVar4 == 0x70) {
          uVar3 = local_238;
        }
        if (uVar4 == 0x70 && uVar3 == 0) {
          if (((byte)__s[local_23c] == 0x20 || (byte)__s[local_23c] - 9 < 5) &&
             (iVar6 = local_23c, local_23c < 0x1ff)) {
            do {
              local_23c = iVar6 + 1;
              if ((byte)acStack_229[iVar6 + 2] != 0x20 && 4 < (byte)acStack_229[iVar6 + 2] - 9)
              break;
              bVar9 = iVar6 < 0x1fe;
              iVar6 = local_23c;
            } while (bVar9);
          }
          if (local_23c < 0x1ff) {
            pcVar2 = __s + local_23c;
            sVar5 = strlen(pcVar2);
            if ((sVar5 != 0) &&
               (((iVar6 = sVar5 - 1, pcVar2[iVar6] != '\n' || (pcVar2[iVar6] = '\0', iVar6 != 0)) &&
                (__preg = DAT_00036a08, *pcVar2 != '[')))) {
              for (; __preg != (regex_t *)0x0; __preg = *(regex_t **)&__preg->field_0x1c) {
                iVar6 = regexec(__preg,pcVar2,0,(regmatch_t *)0x0,0);
                if (iVar6 == 0) {
                  __preg_00 = DAT_00036a10;
                  goto LAB_0001d998;
                }
              }
            }
          }
        }
      }
      goto LAB_0001d8a8;
    }
LAB_0001da4e:
    fclose(__stream);
    puVar7 = &DAT_00036b94;
    puVar8 = (undefined4 *)0x0;
    do {
      __ptr = puVar8;
      puVar8 = (undefined4 *)*puVar7;
      puVar7 = puVar8 + 0x1b;
    } while (puVar8 != (undefined4 *)0x0);
    while (__ptr != (undefined4 *)0x0) {
      puVar8 = (undefined4 *)__ptr[0x1c];
      if ((undefined4 *)__ptr[0x1c] == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)__ptr[0x1d];
        if (puVar7 != (undefined4 *)0x0) {
          if ((undefined4 *)puVar7[0x1b] == __ptr) goto LAB_0001daa6;
          puVar8 = __ptr;
          do {
            if (puVar8 != (undefined4 *)puVar7[0x1c]) goto LAB_0001daa6;
            puVar1 = puVar7 + 0x1d;
            puVar8 = puVar7;
            puVar7 = (undefined4 *)*puVar1;
          } while ((undefined4 *)*puVar1 != (undefined4 *)0x0);
        }
        puVar7 = (undefined4 *)0x0;
      }
      else {
        do {
          puVar7 = puVar8;
          puVar8 = (undefined4 *)puVar7[0x1b];
        } while ((undefined4 *)puVar7[0x1b] != (undefined4 *)0x0);
      }
LAB_0001daa6:
      FUN_0001d45c(__ptr);
      if ((void *)*__ptr != (void *)0x0) {
        free((void *)*__ptr);
      }
      free(__ptr);
      __ptr = puVar7;
    }
    DAT_00036b94 = local_240;
    if (DAT_00036a18 < 5) {
      __android_log_print(4,"xhook","map refreshed");
    }
  }
  if (__stack_chk_guard == local_28) {
    return;
  }
LAB_0001daa0:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
LAB_0001d998:
  if (__preg_00 == (regex_t *)0x0) goto LAB_0001d89a;
  iVar6 = regexec(__preg_00,pcVar2,0,(regmatch_t *)0x0,0);
  if ((iVar6 == 0) &&
     ((__preg_00->fastmap == (char *)0x0 ||
      (iVar6 = strcmp(__preg_00->fastmap,__preg->fastmap), iVar6 == 0)))) goto LAB_0001d8a8;
  __preg_00 = (regex_t *)__preg_00->translate;
  goto LAB_0001d998;
LAB_0001d89a:
  iVar6 = FUN_0001db28(local_234,pcVar2);
  puVar8 = DAT_00036b94;
  if (iVar6 == 0) {
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)puVar8[0x1b]) {
      while (iVar6 = strcmp(pcVar2,(char *)*puVar8), -1 < iVar6) {
        if (iVar6 == 0) {
          FUN_0001d45c(puVar8);
          iVar6 = FUN_0001dbac(&local_240,puVar8);
          if (iVar6 != 0) goto LAB_0001da2c;
          if (puVar8[1] == local_234) goto LAB_0001d8a8;
          puVar8[1] = local_234;
          goto LAB_0001da46;
        }
        puVar8 = (undefined4 *)puVar8[0x1c];
        if (puVar8 == (undefined4 *)0x0) goto LAB_0001d9f4;
      }
    }
LAB_0001d9f4:
    puVar8 = malloc(0x7c);
    if (puVar8 != (undefined4 *)0x0) {
      pcVar2 = strdup(pcVar2);
      *puVar8 = pcVar2;
      if (pcVar2 != (char *)0x0) {
        puVar8[1] = local_234;
        iVar6 = FUN_0001dbac(&local_240,puVar8);
        if (iVar6 == 0) {
LAB_0001da46:
          FUN_0001dd28(puVar8);
          goto LAB_0001d8a8;
        }
LAB_0001da2c:
        free((void *)*puVar8);
      }
      free(puVar8);
    }
  }
LAB_0001d8a8:
  pcVar2 = fgets(__s,0x200,__stream);
  if (pcVar2 == (char *)0x0) goto LAB_0001da4e;
  goto LAB_0001d8ba;
}


// ==== FUN_0001db28 @ 0001db28

undefined4 FUN_0001db28(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (DAT_00036a04 == 0) {
    uVar2 = FUN_0001de28(param_1);
    return uVar2;
  }
  DAT_00036b98 = 1;
  iVar1 = sigsetjmp(&DAT_00036a68);
  if (iVar1 == 0) {
    uVar2 = FUN_0001de28(param_1);
    DAT_00036b98 = 0;
    return uVar2;
  }
  if (DAT_00036a18 < 6) {
    __android_log_print(5,"xhook","catch SIGSEGV when check_elfheader: %s",param_2);
  }
  DAT_00036b98 = 0;
  return 0x3f1;
}


// ==== FUN_0001dbac @ 0001dbac

undefined4 * FUN_0001dbac(int *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  char *__s1;
  undefined4 *puVar7;
  int *piVar8;
  
  if ((undefined4 *)*param_1 == (undefined4 *)0x0) {
    param_2[0x1b] = 0;
    param_2[0x1c] = 0;
    param_2[0x1d] = 0;
    param_2[0x1e] = 1;
    *param_1 = (int)param_2;
  }
  else {
    __s1 = (char *)*param_2;
    puVar4 = (undefined4 *)*param_1;
    do {
      while (puVar7 = puVar4, iVar1 = strcmp(__s1,(char *)*puVar7), -1 < iVar1) {
        if (iVar1 == 0) {
          return puVar7;
        }
        puVar4 = (undefined4 *)puVar7[0x1c];
        if ((undefined4 *)puVar7[0x1c] == (undefined4 *)0x0) goto LAB_0001dbec;
      }
      puVar4 = (undefined4 *)puVar7[0x1b];
    } while ((undefined4 *)puVar7[0x1b] != (undefined4 *)0x0);
LAB_0001dbec:
    iVar3 = 0x70;
    param_2[0x1d] = puVar7;
    param_2[0x1b] = 0;
    param_2[0x1c] = 0;
    if (iVar1 < 0) {
      iVar3 = 0x6c;
    }
    *(undefined4 **)((int)puVar7 + iVar3) = param_2;
    param_2[0x1e] = 1;
    do {
      if (puVar7[0x1e] != 1) break;
      puVar4 = (undefined4 *)puVar7[0x1d];
      puVar5 = (undefined4 *)puVar4[0x1b];
      if (puVar7 == puVar5) {
        puVar5 = (undefined4 *)puVar4[0x1c];
        if ((puVar5 != (undefined4 *)0x0) && (puVar5[0x1e] == 1)) goto LAB_0001dc08;
        puVar5 = (undefined4 *)puVar7[0x1c];
        if (puVar5 == param_2) {
          iVar1 = param_2[0x1b];
          puVar7[0x1c] = iVar1;
          if (iVar1 == 0) {
            param_2[0x1d] = puVar4;
LAB_0001dcc0:
            piVar8 = (int *)(puVar7[0x1d] + 0x6c);
            if (puVar7 != (undefined4 *)*piVar8) {
              piVar8 = (int *)(puVar7[0x1d] + 0x70);
            }
          }
          else {
            *(undefined4 **)(iVar1 + 0x74) = puVar7;
            iVar1 = puVar7[0x1d];
            param_2[0x1d] = iVar1;
            if (iVar1 != 0) goto LAB_0001dcc0;
            piVar8 = param_1;
          }
          *piVar8 = (int)param_2;
          param_2[0x1b] = puVar7;
          puVar6 = (undefined4 *)puVar4[0x1b];
          puVar7[0x1d] = param_2;
          puVar5 = (undefined4 *)puVar6[0x1c];
          puVar2 = param_2;
        }
        else {
          puVar2 = puVar7;
          puVar6 = puVar7;
          puVar7 = param_2;
        }
        puVar2[0x1e] = 0;
        puVar4[0x1b] = puVar5;
        puVar4[0x1e] = 1;
        if (puVar5 != (undefined4 *)0x0) {
          puVar5[0x1d] = puVar4;
        }
        iVar1 = puVar4[0x1d];
        puVar6[0x1d] = iVar1;
        if (iVar1 == 0) {
          piVar8 = param_1;
        }
        else {
          piVar8 = (int *)(puVar4[0x1d] + 0x6c);
          if (puVar4 != (undefined4 *)*piVar8) {
            piVar8 = (int *)(puVar4[0x1d] + 0x70);
          }
        }
        *piVar8 = (int)puVar6;
        puVar4[0x1d] = puVar6;
        puVar6[0x1c] = puVar4;
        param_2 = puVar7;
      }
      else if ((puVar5 == (undefined4 *)0x0) || (puVar5[0x1e] != 1)) {
        if ((undefined4 *)puVar7[0x1b] == param_2) {
          iVar1 = param_2[0x1c];
          puVar7[0x1b] = iVar1;
          if (iVar1 == 0) {
            param_2[0x1d] = puVar4;
LAB_0001dc78:
            piVar8 = (int *)(puVar7[0x1d] + 0x6c);
            if (puVar7 != (undefined4 *)*piVar8) {
              piVar8 = (int *)(puVar7[0x1d] + 0x70);
            }
          }
          else {
            *(undefined4 **)(iVar1 + 0x74) = puVar7;
            iVar1 = puVar7[0x1d];
            param_2[0x1d] = iVar1;
            if (iVar1 != 0) goto LAB_0001dc78;
            piVar8 = param_1;
          }
          *piVar8 = (int)param_2;
          puVar7[0x1d] = param_2;
          param_2[0x1c] = puVar7;
          puVar5 = param_2;
        }
        else {
          puVar5 = puVar7;
          puVar7 = param_2;
        }
        iVar3 = puVar4[0x1c];
        puVar5[0x1e] = 0;
        puVar4[0x1e] = 1;
        iVar1 = *(int *)(iVar3 + 0x6c);
        puVar4[0x1c] = iVar1;
        if (iVar1 != 0) {
          *(undefined4 **)(iVar1 + 0x74) = puVar4;
        }
        iVar1 = puVar4[0x1d];
        *(int *)(iVar3 + 0x74) = iVar1;
        if (iVar1 == 0) {
          piVar8 = param_1;
        }
        else {
          piVar8 = (int *)(puVar4[0x1d] + 0x6c);
          if (puVar4 != (undefined4 *)*piVar8) {
            piVar8 = (int *)(puVar4[0x1d] + 0x70);
          }
        }
        *piVar8 = iVar3;
        puVar4[0x1d] = iVar3;
        *(undefined4 **)(iVar3 + 0x6c) = puVar4;
        param_2 = puVar7;
      }
      else {
LAB_0001dc08:
        puVar5[0x1e] = 0;
        puVar7[0x1e] = 0;
        puVar4[0x1e] = 1;
        param_2 = puVar4;
      }
      puVar7 = (undefined4 *)param_2[0x1d];
    } while (puVar7 != (undefined4 *)0x0);
    param_2 = (undefined4 *)*param_1;
  }
  param_2[0x1e] = 0;
  return (undefined4 *)0x0;
}


// ==== FUN_0001dd28 @ 0001dd28

void FUN_0001dd28(undefined4 *param_1)

{
  int iVar1;
  
  if (DAT_00036a04 == 0) {
    FUN_0001dd98(param_1);
    return;
  }
  DAT_00036b98 = 1;
  iVar1 = sigsetjmp(&DAT_00036a68);
  if (iVar1 == 0) {
    FUN_0001dd98(param_1);
    DAT_00036b98 = 0;
    return;
  }
  if (DAT_00036a18 < 6) {
    __android_log_print(5,"xhook","catch SIGSEGV when init or hook: %s",*param_1);
  }
  DAT_00036b98 = 0;
  return;
}


// ==== FUN_0001dd98 @ 0001dd98

void FUN_0001dd98(undefined4 *param_1)

{
  regex_t *__preg;
  int iVar1;
  regex_t *__preg_00;
  
  iVar1 = FUN_0001de6c(param_1 + 2,param_1[1],*param_1);
  __preg = DAT_00036a08;
  if (iVar1 == 0) {
    for (; __preg != (regex_t *)0x0; __preg = *(regex_t **)&__preg->field_0x1c) {
      iVar1 = regexec(__preg,(char *)*param_1,0,(regmatch_t *)0x0,0);
      if (iVar1 == 0) {
        for (__preg_00 = DAT_00036a10; __preg_00 != (regex_t *)0x0;
            __preg_00 = (regex_t *)__preg_00->translate) {
          iVar1 = regexec(__preg_00,(char *)*param_1,0,(regmatch_t *)0x0,0);
          if (iVar1 == 0) {
            if (__preg_00->fastmap == (char *)0x0) {
              return;
            }
            iVar1 = strcmp(__preg_00->fastmap,__preg->fastmap);
            if (iVar1 == 0) goto LAB_0001ddd0;
          }
        }
        FUN_0001e274(param_1 + 2,__preg->fastmap,__preg->translate,__preg->re_nsub);
      }
LAB_0001ddd0:
    }
  }
  return;
}


// ==== FUN_0001de28 @ 0001de28

undefined4 FUN_0001de28(uint *param_1)

{
  char cVar1;
  undefined4 uVar2;
  ushort uVar3;
  uint uVar4;
  bool bVar5;
  
  uVar4 = *param_1;
  bVar5 = uVar4 == 0x464c457f;
  if (bVar5) {
    uVar4 = (uint)(byte)param_1[1];
  }
  if (bVar5 && uVar4 == 1) {
    cVar1 = *(char *)((int)param_1 + 5);
    bVar5 = cVar1 == '\x01';
    if (bVar5) {
      cVar1 = *(char *)((int)param_1 + 6);
    }
    if (bVar5 && cVar1 == '\x01') {
      uVar3 = (ushort)param_1[4] & 0xfffe;
      bVar5 = uVar3 == 2;
      if (bVar5) {
        uVar3 = *(ushort *)((int)param_1 + 0x12);
      }
      if (bVar5 && uVar3 == 0x28) {
        uVar2 = 0;
        if (param_1[5] != 1) {
          uVar2 = 0x3ef;
        }
        return uVar2;
      }
    }
  }
  return 0x3ef;
}


// ==== FUN_0001de6c @ 0001de6c

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_0001de6c(int *param_1,int *param_2,int param_3)

{
  char cVar1;
  ushort uVar2;
  undefined *puVar3;
  char *pcVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  int iVar12;
  int *piVar13;
  bool bVar14;
  
  if (param_2 == (int *)0x0 || param_3 == 0) {
    return 0x3ea;
  }
  iVar9 = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
  iVar6 = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
  iVar12 = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
  *param_1 = 0;
  param_1[1] = iVar9;
  param_1[2] = iVar6;
  param_1[3] = iVar12;
  param_1[4] = 0;
  param_1[5] = iVar9;
  param_1[6] = iVar6;
  param_1[7] = iVar12;
  param_1[8] = 0;
  param_1[9] = iVar9;
  param_1[10] = iVar6;
  param_1[0xb] = iVar12;
  param_1[0xc] = 0;
  param_1[0xd] = iVar9;
  param_1[0xe] = iVar6;
  param_1[0xf] = iVar12;
  param_1[0x10] = 0;
  param_1[0x11] = iVar9;
  param_1[0x12] = iVar6;
  param_1[0x13] = iVar12;
  param_1[0x14] = 0;
  param_1[0x15] = iVar9;
  param_1[0x16] = iVar6;
  param_1[0x17] = iVar12;
  param_1[0x18] = 0;
  uVar2 = *(ushort *)(param_2 + 0xb);
  piVar10 = (int *)(param_2[7] + (int)param_2);
  param_1[3] = (int)param_2;
  *param_1 = param_3;
  param_1[1] = (int)param_2;
  param_1[4] = (int)piVar10;
  if (uVar2 != 0) {
    piVar8 = piVar10;
    do {
      iVar9 = *piVar8;
      bVar14 = iVar9 == 1;
      if (bVar14) {
        iVar9 = piVar8[1];
      }
      if (bVar14 && iVar9 == 0) {
        if (param_2 < (int *)piVar8[2]) {
          return 0x3ef;
        }
        iVar9 = (int)param_2 - piVar8[2];
        param_1[2] = iVar9;
        piVar8 = piVar10;
        goto LAB_0001df14;
      }
      piVar8 = piVar8 + 8;
    } while (piVar8 < piVar10 + (uint)uVar2 * 8);
  }
  if (6 < DAT_00036a18) {
    return 0x3ef;
  }
  pcVar4 = "Can NOT found the first load segment. %s";
  goto LAB_0001deee;
  while (piVar8 = piVar8 + 8, piVar8 < piVar10 + (uint)uVar2 * 8) {
LAB_0001df14:
    if (*piVar8 == 2) {
      uVar5 = piVar8[5];
      piVar8 = (int *)(piVar8[2] + iVar9);
      param_1[5] = (int)piVar8;
      param_1[6] = uVar5;
      uVar5 = uVar5 >> 3;
      if (uVar5 == 0) goto LAB_0001e066;
      piVar13 = piVar8 + uVar5 * 2;
      goto LAB_0001df64;
    }
  }
  if (6 < DAT_00036a18) {
    return 0x3ef;
  }
  pcVar4 = "Can NOT found dynamic segment. %s";
  goto LAB_0001deee;
LAB_0001df64:
  do {
    iVar6 = *piVar8;
    switch(iVar6) {
    case 0:
      piVar8 = piVar13;
      break;
    case 1:
    case 3:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x10:
    case 0x13:
    case 0x15:
    case 0x16:
      break;
    case 2:
      param_1[10] = piVar8[1];
      break;
    case 4:
      if (param_1[0x18] != 1) {
        piVar7 = (int *)(piVar8[1] + iVar9);
        if (piVar7 < param_2) {
          return 0x3ef;
        }
        iVar12 = *piVar7;
        param_1[0x10] = iVar12;
        iVar6 = piVar7[1];
        param_1[0xf] = (int)(piVar7 + 2);
        param_1[0x11] = (int)(piVar7 + 2 + iVar12);
        param_1[0x12] = iVar6;
      }
      break;
    case 5:
      piVar7 = (int *)(piVar8[1] + iVar9);
      param_1[7] = (int)piVar7;
      goto joined_r0x0001dfb2;
    case 6:
      piVar7 = (int *)(piVar8[1] + iVar9);
      param_1[8] = (int)piVar7;
      goto joined_r0x0001dfb2;
    case 7:
    case 0x11:
      piVar7 = (int *)(piVar8[1] + iVar9);
      param_1[0xb] = (int)piVar7;
      goto joined_r0x0001dfb2;
    case 8:
    case 0x12:
      param_1[0xc] = piVar8[1];
      break;
    case 0x14:
      param_1[0x17] = (uint)(piVar8[1] == 7);
      break;
    case 0x17:
      piVar7 = (int *)(piVar8[1] + iVar9);
      param_1[9] = (int)piVar7;
joined_r0x0001dfb2:
      if (piVar7 < param_2) {
        return 0x3ef;
      }
      break;
    default:
      switch(iVar6) {
      case 0x6000000f:
      case 0x60000011:
        piVar7 = (int *)(piVar8[1] + iVar9);
        param_1[0xd] = (int)piVar7;
        goto joined_r0x0001dfb2;
      case 0x60000010:
      case 0x60000012:
        param_1[0xe] = piVar8[1];
        break;
      default:
        if (iVar6 == 0x6ffffef5) {
          piVar7 = (int *)(piVar8[1] + iVar9);
          if (piVar7 < param_2) {
            return 0x3ef;
          }
          iVar12 = *piVar7;
          piVar11 = piVar7 + 4;
          param_1[0x10] = iVar12;
          param_1[0x13] = piVar7[1];
          iVar6 = piVar7[2];
          param_1[0x15] = iVar6;
          param_1[0x16] = piVar7[3];
          param_1[0x18] = 1;
          param_1[0xf] = (int)(piVar11 + iVar6);
          param_1[0x14] = (int)piVar11;
          param_1[0x11] = (int)(piVar11 + iVar6 + iVar12);
        }
      }
    }
    piVar8 = piVar8 + 2;
  } while (piVar8 < piVar13);
LAB_0001e066:
  pcVar4 = (char *)param_1[0xd];
  if (pcVar4 != (char *)0x0) {
    if (((uint)param_1[0xe] < 4) || (*pcVar4 != 'A')) {
LAB_0001e082:
      if (DAT_00036a18 < 7) {
        __android_log_print(6,"xhook","android rel/rela format error\n");
        return 0x3ef;
      }
      return 0x3ef;
    }
    cVar1 = pcVar4[1];
    bVar14 = cVar1 == 'P';
    if (bVar14) {
      cVar1 = pcVar4[2];
    }
    if ((!bVar14 || cVar1 != 'S') || (pcVar4[3] != '2')) goto LAB_0001e082;
    param_1[0xd] = (int)(pcVar4 + 4);
    param_1[0xe] = param_1[0xe] - 4;
  }
  if (iVar9 == 0) {
    if (6 < DAT_00036a18) {
      return 0x3ef;
    }
    pcVar4 = "bias_addr == 0\n";
  }
  else if (piVar10 == (int *)0x0) {
    if (6 < DAT_00036a18) {
      return 0x3ef;
    }
    pcVar4 = "phdr == NULL\n";
  }
  else if (param_1[7] == 0) {
    if (6 < DAT_00036a18) {
      return 0x3ef;
    }
    pcVar4 = "strtab == NULL\n";
  }
  else if (param_1[8] == 0) {
    if (6 < DAT_00036a18) {
      return 0x3ef;
    }
    pcVar4 = "symtab == NULL\n";
  }
  else if (param_1[0xf] == 0) {
    if (6 < DAT_00036a18) {
      return 0x3ef;
    }
    pcVar4 = "bucket == NULL\n";
  }
  else {
    iVar9 = param_1[0x11];
    if (iVar9 == 0) {
      if (6 < DAT_00036a18) {
        return 0x3ef;
      }
      pcVar4 = "chain == NULL\n";
    }
    else {
      iVar6 = param_1[0x18];
      if (iVar6 == 1) {
        iVar9 = param_1[0x14];
      }
      if (iVar6 != 1 || iVar9 != 0) {
        if (DAT_00036a18 < 5) {
          pcVar4 = "GNU_HASH";
          if (iVar6 == 0) {
            pcVar4 = "ELF_HASH";
          }
          puVar3 = &DAT_00016685;
          if (param_1[0x17] != 0) {
            puVar3 = &DAT_00016723;
          }
          __android_log_print(4,"xhook","init OK: %s (%s %s PLT:%u DYN:%u ANDROID:%u)\n",param_3,
                              puVar3,pcVar4,param_1[10],param_1[0xc],param_1[0xe]);
        }
        return 0;
      }
      if (6 < DAT_00036a18) {
        return 0x3ef;
      }
      pcVar4 = "bloom == NULL\n";
    }
  }
  __android_log_print(6,"xhook",pcVar4);
  if (6 < DAT_00036a18) {
    return 0x3ef;
  }
  pcVar4 = "elf init check failed. %s";
LAB_0001deee:
  __android_log_print(6,"xhook",pcVar4,param_3);
  return 0x3ef;
}


// ==== FUN_0001e274 @ 0001e274

void FUN_0001e274(int *param_1,byte *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  byte *pbVar2;
  int iVar3;
  uint uVar4;
  byte *pbVar5;
  uint *puVar6;
  uint uVar7;
  int extraout_r1;
  int extraout_r1_00;
  int extraout_r1_01;
  char *pcVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  int *piVar14;
  byte *pbVar15;
  uint uVar16;
  uint uVar17;
  int local_a8;
  uint local_a4;
  int local_a0;
  uint local_9c;
  uint local_98;
  uint local_94;
  uint local_88;
  undefined4 local_80;
  byte *local_7c;
  int local_74;
  byte *local_70;
  byte *local_6c;
  uint local_68;
  uint uStack_64;
  uint local_60;
  uint local_5c;
  uint local_58;
  uint uStack_54;
  uint uStack_50;
  uint local_4c;
  int local_48;
  uint uStack_44;
  uint uStack_40;
  uint local_3c;
  uint local_38;
  int local_34;
  int iStack_30;
  int local_28;
  
  local_28 = __stack_chk_guard;
  if (*param_1 == 0) {
    if (DAT_00036a18 < 7) {
      __android_log_print(6,"xhook","not inited\n");
    }
    iVar1 = 0x3f0;
  }
  else {
    iVar1 = 0x3ea;
    iVar12 = 0;
    if (param_2 != (byte *)0x0) {
      iVar12 = param_3;
      local_80 = param_4;
      local_7c = param_2;
    }
    if (param_2 == (byte *)0x0 || iVar12 == 0) goto LAB_0001e458;
    if (DAT_00036a18 < 5) {
      __android_log_print(4,"xhook","hooking %s in %s\n",local_7c,*param_1);
    }
    uVar7 = (uint)*local_7c;
    if (param_1[0x18] == 0) {
      if (uVar7 == 0) {
        uVar13 = 0;
      }
      else {
        uVar13 = 0;
        pbVar2 = local_7c;
        do {
          pbVar2 = pbVar2 + 1;
          uVar13 = uVar7 + uVar13 * 0x10;
          uVar7 = (uint)*pbVar2;
          uVar13 = uVar13 & 0xfffffff ^ uVar13 >> 0x18 & 0xf0;
        } while (uVar7 != 0);
      }
      iVar1 = param_1[0xf];
      FUN_0002a304(uVar13,param_1[0x10]);
      uVar7 = *(uint *)(iVar1 + extraout_r1_01 * 4);
      if (uVar7 != 0) {
        iVar1 = param_1[7];
        iVar12 = param_1[8];
        do {
          iVar3 = strcmp((char *)local_7c,(char *)(iVar1 + *(int *)(iVar12 + uVar7 * 0x10)));
          if (iVar3 == 0) {
            if (4 < DAT_00036a18) goto LAB_0001e490;
            pcVar8 = "found %s at symidx: %u (ELF_HASH)\n";
            goto LAB_0001e48c;
          }
          uVar7 = *(uint *)(param_1[0x11] + uVar7 * 4);
        } while (uVar7 != 0);
      }
    }
    else {
      if (uVar7 == 0) {
        uVar13 = 0x1505;
      }
      else {
        uVar13 = 0x1505;
        pbVar2 = local_7c;
        do {
          pbVar2 = pbVar2 + 1;
          uVar13 = uVar13 * 0x21 + uVar7;
          uVar7 = (uint)*pbVar2;
        } while (*pbVar2 != 0);
      }
      iVar1 = param_1[0x14];
      uVar7 = param_1[0x16];
      FUN_0002a304(uVar13 >> 5,param_1[0x15]);
      uVar7 = 1 << (uVar13 & 0x1f) | 1 << (uVar13 >> (uVar7 & 0xff) & 0x1f);
      if ((*(uint *)(iVar1 + extraout_r1 * 4) & uVar7) == uVar7) {
        iVar1 = param_1[0xf];
        uVar17 = param_1[0x13];
        FUN_0002a304(uVar13,param_1[0x10]);
        uVar7 = *(uint *)(iVar1 + extraout_r1_00 * 4);
        if (uVar7 < uVar17) goto LAB_0001e438;
        iVar1 = param_1[0x11];
        iVar12 = uVar7 << 4;
        do {
          uVar16 = *(uint *)(iVar1 + uVar17 * -4 + uVar7 * 4);
          if (((uVar16 ^ uVar13) < 2) &&
             (iVar3 = strcmp((char *)local_7c,(char *)(*(int *)(param_1[8] + iVar12) + param_1[7])),
             iVar3 == 0)) {
            if (4 < DAT_00036a18) goto LAB_0001e490;
            pcVar8 = "found %s at symidx: %u (GNU_HASH DEF)\n";
            goto LAB_0001e48c;
          }
          iVar12 = iVar12 + 0x10;
          uVar7 = uVar7 + 1;
        } while ((uVar16 & 1) == 0);
      }
      else {
        uVar17 = param_1[0x13];
      }
      if (uVar17 != 0) {
LAB_0001e438:
        iVar1 = param_1[7];
        piVar14 = (int *)param_1[8];
        uVar7 = 0;
LAB_0001e440:
        iVar12 = strcmp((char *)(*piVar14 + iVar1),(char *)local_7c);
        if (iVar12 != 0) goto code_r0x0001e44c;
        if (DAT_00036a18 < 5) {
          pcVar8 = "found %s at symidx: %u (GNU_HASH UNDEF)\n";
LAB_0001e48c:
          __android_log_print(4,"xhook",pcVar8,local_7c,uVar7);
        }
LAB_0001e490:
        uVar13 = param_1[9];
        if (uVar13 != 0) {
          iVar12 = 0xc;
          uVar17 = uVar13 + param_1[10];
          if (param_1[0x17] == 0) {
            iVar12 = 8;
          }
          do {
            if (uVar17 <= uVar13) break;
            pcVar8 = ".rela.plt";
            if (param_1[0x17] == 0) {
              pcVar8 = ".rel.plt";
            }
            iVar1 = FUN_0001e9d4(param_1,pcVar8,1,local_7c,param_3,local_80,uVar7,uVar13,&local_74);
            if (iVar1 != 0) goto LAB_0001e458;
            uVar13 = uVar13 + iVar12;
          } while (local_74 == 0);
        }
        uVar13 = param_1[0xb];
        if (uVar13 != 0) {
          iVar12 = 0xc;
          if (param_1[0x17] == 0) {
            iVar12 = 8;
          }
          uVar17 = uVar13 + param_1[0xc];
          while (uVar13 < uVar17) {
            pcVar8 = ".rela.dyn";
            if (param_1[0x17] == 0) {
              pcVar8 = ".rel.dyn";
            }
            iVar1 = FUN_0001e9d4(param_1,pcVar8,0,local_7c,param_3,local_80,uVar7,uVar13,0);
            uVar13 = uVar13 + iVar12;
            if (iVar1 != 0) goto LAB_0001e458;
          }
        }
        pbVar2 = (byte *)param_1[0xd];
        iVar1 = 0;
        if (pbVar2 == (byte *)0x0) goto LAB_0001e458;
        uStack_64 = *(uint *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
        local_60 = *(uint *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
        local_5c = *(uint *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
        iVar12 = param_1[0x17];
        local_68 = 0;
        pbVar15 = pbVar2 + param_1[0xe];
        local_58 = 0;
        local_48 = 0;
        local_38 = 0;
        local_34 = 0;
        if (param_1[0xe] < 1) {
LAB_0001e5ec:
          uVar16 = 0;
          local_70 = pbVar2;
          local_3c = local_5c;
        }
        else {
          uVar17 = 0;
          uVar13 = 0;
          pbVar5 = pbVar2;
          while( true ) {
            pbVar2 = pbVar5 + 1;
            uVar16 = (uint)*pbVar5;
            uVar13 = uVar13 | (uVar16 & 0x7f) << (uVar17 & 0xff);
            if (-1 < (int)(uVar16 << 0x18)) break;
            uVar17 = uVar17 + 7;
            pbVar5 = pbVar2;
            if (pbVar15 <= pbVar2) goto LAB_0001e5ec;
          }
          local_68 = uVar13;
          if ((int)(uVar16 << 0x19) < 0) {
            local_68 = uVar13 | -1 << (uVar17 + 7 & 0xff);
          }
          if (0x1f < uVar17 + 7) {
            local_68 = uVar13;
          }
          uVar13 = 0;
          uVar17 = 0;
          local_70 = pbVar5 + 1;
          do {
            if (pbVar15 <= local_70) {
              uVar16 = 0;
              local_3c = local_5c;
              goto LAB_0001e5f8;
            }
            pbVar2 = local_70 + 1;
            uVar4 = (uint)*local_70;
            uVar13 = uVar13 | (uVar4 & 0x7f) << (uVar17 & 0xff);
            uVar17 = uVar17 + 7;
            local_70 = pbVar2;
          } while ((int)(uVar4 << 0x18) < 0);
          uVar16 = uVar13;
          if ((int)(uVar4 << 0x19) < 0) {
            uVar16 = uVar13 | -1 << (uVar17 & 0xff);
          }
          if (0x1f < uVar17) {
            uVar16 = uVar13;
          }
          local_3c = uVar16;
        }
LAB_0001e5f8:
        uVar13 = local_68;
        local_94 = 0;
        local_a0 = 0;
        local_a4 = 0;
        local_a8 = 0;
        local_9c = 0;
        local_98 = 0;
        uVar17 = 0;
        local_88 = 0;
        pbVar2 = local_70;
        local_6c = pbVar15;
        uStack_54 = uStack_64;
        uStack_50 = local_60;
        local_4c = local_5c;
        uStack_44 = uStack_64;
        uStack_40 = local_60;
        iStack_30 = iVar12;
        while (uVar17 < uVar13) {
          if (local_98 == local_9c) {
            uVar4 = 0;
            uVar9 = 0;
            do {
              if (pbVar15 <= pbVar2) goto LAB_0001e456;
              local_70 = pbVar2 + 1;
              uVar10 = (uint)*pbVar2;
              uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
              uVar9 = uVar9 + 7;
              pbVar2 = local_70;
            } while ((int)(uVar10 << 0x18) < 0);
            local_9c = uVar4;
            if ((int)(uVar10 << 0x19) < 0) {
              local_9c = uVar4 | -1 << (uVar9 & 0xff);
            }
            if (0x1f < uVar9) {
              local_9c = uVar4;
            }
            uVar4 = 0;
            uVar9 = 0;
            do {
              uStack_64 = local_9c;
              if (pbVar15 <= local_70) goto LAB_0001e456;
              pbVar2 = local_70 + 1;
              uVar10 = (uint)*local_70;
              uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
              uVar9 = uVar9 + 7;
              local_70 = pbVar2;
            } while ((int)(uVar10 << 0x18) < 0);
            local_88 = uVar4;
            if ((int)(uVar10 << 0x19) < 0) {
              local_88 = uVar4 | -1 << (uVar9 & 0xff);
            }
            if (0x1f < uVar9) {
              local_88 = uVar4;
            }
            local_60 = local_88;
            if ((int)(local_88 << 0x1e) < 0) {
              uVar4 = 0;
              uVar9 = 0;
              do {
                if (pbVar15 <= local_70) goto LAB_0001e456;
                pbVar2 = local_70 + 1;
                uVar10 = (uint)*local_70;
                uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
                uVar9 = uVar9 + 7;
                local_70 = pbVar2;
              } while ((int)(uVar10 << 0x18) < 0);
              local_a4 = uVar4;
              if ((int)(uVar10 << 0x19) < 0) {
                local_a4 = uVar4 | -1 << (uVar9 & 0xff);
              }
              if (0x1f < uVar9) {
                local_a4 = uVar4;
              }
              local_5c = local_a4;
            }
            if ((local_88 & 1) == 0) {
            }
            else {
              uVar4 = 0;
              uVar9 = 0;
              do {
                if (pbVar15 <= local_70) goto LAB_0001e456;
                pbVar2 = local_70 + 1;
                uVar10 = (uint)*local_70;
                uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
                uVar9 = uVar9 + 7;
                local_70 = pbVar2;
              } while ((int)(uVar10 << 0x18) < 0);
              local_94 = uVar4;
              if ((int)(uVar10 << 0x19) < 0) {
                local_94 = uVar4 | -1 << (uVar9 & 0xff);
              }
              if (0x1f < uVar9) {
                local_94 = uVar4;
              }
              local_38 = local_94;
            }
            if ((local_88 & 0xc) == 0xc) {
              if (iVar12 == 0) {
                if (DAT_00036a18 < 7) {
                  __android_log_print(6,"xhook","unexpected r_addend in android.rel section");
                  iVar1 = 0;
                  goto LAB_0001e458;
                }
                break;
              }
              uVar4 = 0;
              uVar9 = 0;
              do {
                if (pbVar15 <= local_70) goto LAB_0001e456;
                pbVar2 = local_70 + 1;
                uVar10 = (uint)*local_70;
                uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
                uVar9 = uVar9 + 7;
                local_70 = pbVar2;
              } while ((int)(uVar10 << 0x18) < 0);
              uVar11 = uVar4;
              if ((int)(uVar10 << 0x19) < 0) {
                uVar11 = uVar4 | -1 << (uVar9 & 0xff);
              }
              if (0x1f < uVar9) {
                uVar11 = uVar4;
              }
              local_a8 = local_a8 + uVar11;
LAB_0001e7e8:
              local_a0 = local_a8;
              local_34 = local_a8;
            }
            else if (-1 < (int)(local_88 << 0x1c)) {
              local_a8 = 0;
              goto LAB_0001e7e8;
            }
            uStack_54 = 0;
            local_98 = 1;
            pbVar2 = local_70;
            if (-1 < (int)(local_88 << 0x1e)) goto LAB_0001e6c2;
LAB_0001e80a:
            uVar11 = local_a4;
          }
          else {
            local_98 = local_98 + 1;
            if ((int)(local_88 << 0x1e) < 0) goto LAB_0001e80a;
LAB_0001e6c2:
            uVar4 = 0;
            uVar9 = 0;
            pbVar5 = pbVar2;
            do {
              if (pbVar15 <= pbVar5) goto LAB_0001e456;
              pbVar2 = pbVar5 + 1;
              uVar10 = (uint)*pbVar5;
              uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
              uVar9 = uVar9 + 7;
              pbVar5 = pbVar2;
              local_70 = pbVar2;
            } while ((int)(uVar10 << 0x18) < 0);
            uVar11 = uVar4;
            if ((int)(uVar10 << 0x19) < 0) {
              uVar11 = uVar4 | -1 << (uVar9 & 0xff);
            }
            if (0x1f < uVar9) {
              uVar11 = uVar4;
            }
          }
          uVar16 = uVar16 + uVar11;
          local_3c = uVar16;
          if ((local_88 & 1) == 0) {
            uVar4 = 0;
            uVar9 = 0;
            pbVar5 = pbVar2;
            do {
              if (pbVar15 <= pbVar5) goto LAB_0001e456;
              pbVar2 = pbVar5 + 1;
              uVar10 = (uint)*pbVar5;
              uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
              uVar9 = uVar9 + 7;
              pbVar5 = pbVar2;
              local_70 = pbVar2;
            } while ((int)(uVar10 << 0x18) < 0);
            local_94 = uVar4;
            if ((int)(uVar10 << 0x19) < 0) {
              local_94 = uVar4 | -1 << (uVar9 & 0xff);
            }
            if (0x1f < uVar9) {
              local_94 = uVar4;
            }
            local_38 = local_94;
          }
          if (iVar12 == 0) {
            uStack_40 = local_94;
            puVar6 = &uStack_44;
            uStack_44 = uVar16;
          }
          else {
            if ((local_88 & 0xc) == 8) {
              uVar4 = 0;
              uVar9 = 0;
              pbVar5 = pbVar2;
              do {
                if (pbVar15 <= pbVar5) goto LAB_0001e456;
                pbVar2 = pbVar5 + 1;
                uVar10 = (uint)*pbVar5;
                uVar4 = uVar4 | (uVar10 & 0x7f) << (uVar9 & 0xff);
                uVar9 = uVar9 + 7;
                pbVar5 = pbVar2;
                local_70 = pbVar2;
              } while ((int)(uVar10 << 0x18) < 0);
              uVar11 = uVar4;
              if ((int)(uVar10 << 0x19) < 0) {
                uVar11 = uVar4 | -1 << (uVar9 & 0xff);
              }
              if (0x1f < uVar9) {
                uVar11 = uVar4;
              }
              local_a0 = local_a0 + uVar11;
              local_34 = local_a0;
            }
            local_4c = local_94;
            puVar6 = &uStack_50;
            local_a8 = local_a0;
            uStack_50 = uVar16;
            local_48 = local_a0;
          }
          uStack_54 = local_98;
          uVar17 = uVar17 + 1;
          pcVar8 = ".rela.android";
          if (param_1[0x17] == 0) {
            pcVar8 = ".rel.android";
          }
          local_58 = uVar17;
          iVar1 = FUN_0001e9d4(param_1,pcVar8,0,local_7c,param_3,local_80,uVar7,puVar6,0);
          if (iVar1 != 0) goto LAB_0001e458;
        }
      }
    }
LAB_0001e456:
    iVar1 = 0;
  }
LAB_0001e458:
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar1);
  }
  return;
code_r0x0001e44c:
  uVar7 = uVar7 + 1;
  piVar14 = piVar14 + 4;
  if (uVar17 == uVar7) goto LAB_0001e456;
  goto LAB_0001e440;
}


// ==== FUN_0001e9d4 @ 0001e9d4

void FUN_0001e9d4(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5,
                 int *param_6,uint param_7,int *param_8,undefined4 *param_9)

{
  uint uVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  int *piVar5;
  int local_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  if (param_9 != (undefined4 *)0x0) {
    *param_9 = 0;
  }
  if (param_7 == (uint)param_8[1] >> 8) {
    iVar4 = *param_8;
    uVar1 = param_8[1] & 0xff;
    if ((param_3 == 0 || uVar1 == 0x16) && ((param_3 != 0 || (uVar1 == 0x15 || uVar1 == 2)))) {
      if (DAT_00036a18 < 5) {
        __android_log_print(4,"xhook","found %s at %s offset: %p\n",param_4,param_2,iVar4);
      }
      if (param_9 != (undefined4 *)0x0) {
        *param_9 = 1;
      }
      piVar5 = (int *)(param_1[2] + iVar4);
      if (((int *)param_1[1] <= piVar5) && (local_2c = 0, *piVar5 != param_5)) {
        iVar4 = FUN_0001ed48(piVar5,*param_1,&local_2c);
        if (iVar4 == 0) {
          if ((local_2c == 3) || (iVar4 = FUN_0001ed52(piVar5,3), iVar4 == 0)) {
            iVar4 = *piVar5;
            if (param_6 != (int *)0x0) {
              *param_6 = iVar4;
            }
            *piVar5 = param_5;
            if (((local_2c != 3) && (iVar2 = FUN_0001ed52(piVar5), iVar2 != 0)) &&
               (DAT_00036a18 < 6)) {
              __android_log_print(5,"xhook","restore addr prot failed. ret: %d",iVar2);
            }
            FUN_0001edae(piVar5);
            if (DAT_00036a18 < 5) {
              __android_log_print(4,"xhook","XH_HK_OK %p: %p -> %p %s %s\n",piVar5,iVar4,param_5,
                                  param_4,*param_1);
            }
            goto LAB_0001eb32;
          }
          if (6 < DAT_00036a18) goto LAB_0001eb32;
          pcVar3 = "set addr prot failed. ret: %d";
        }
        else {
          if (6 < DAT_00036a18) goto LAB_0001eb32;
          pcVar3 = "get addr prot failed. ret: %d";
        }
        __android_log_print(6,"xhook",pcVar3,iVar4);
        if (DAT_00036a18 < 7) {
          __android_log_print(6,"xhook","replace function failed: %s at %s\n",param_4,param_2);
        }
      }
    }
  }
LAB_0001eb32:
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_28);
  }
  return;
}


// ==== FUN_0001ed48 @ 0001ed48

void FUN_0001ed48(uint param_1,char *param_2,uint *param_3)

{
  FILE *__stream;
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  bool bVar4;
  uint local_244;
  int local_23c;
  uint local_238;
  uint local_234;
  char local_22d;
  char local_22c;
  char local_22b;
  byte local_22a;
  char acStack_228 [512];
  int local_28;
  
  local_28 = __stack_chk_guard;
  *param_3 = 0;
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    local_23c = 0x3ee;
  }
  else {
    pcVar1 = fgets(acStack_228,0x200,__stream);
    if (pcVar1 != (char *)0x0) {
      uVar2 = param_1 + 4;
      local_23c = 1;
      do {
        if (param_2 != (char *)0x0) {
          do {
            pcVar1 = strstr(acStack_228,param_2);
            if (pcVar1 != (char *)0x0) {
              uVar3 = sscanf(acStack_228,"%x-%x %4s ",&local_234,&local_238,&local_22d);
              bVar4 = uVar3 == 3;
              if (bVar4) {
                uVar3 = (uint)local_22a;
              }
              if (bVar4 && uVar3 == 0x70) goto LAB_0001ec62;
            }
            pcVar1 = fgets(acStack_228,0x200,__stream);
            if (pcVar1 == (char *)0x0) goto LAB_0001ed04;
          } while( true );
        }
        while( true ) {
          uVar3 = sscanf(acStack_228,"%x-%x %4s ",&local_234,&local_238,&local_22d);
          bVar4 = uVar3 == 3;
          if (bVar4) {
            uVar3 = (uint)local_22a;
          }
          if (bVar4 && uVar3 == 0x70) break;
          pcVar1 = fgets(acStack_228,0x200,__stream);
          if (pcVar1 == (char *)0x0) goto LAB_0001ed04;
        }
LAB_0001ec62:
        if ((param_1 < local_234) || (local_244 = local_238, local_238 <= param_1)) {
          local_244 = param_1;
        }
        else {
          if (local_23c == 0) {
            if (local_22d != 'r') {
              *param_3 = *param_3 & 0xfffffffe;
            }
            if (local_22c != 'w') {
              *param_3 = *param_3 & 0xfffffffd;
            }
            if (local_22b != 'x') {
              uVar3 = *param_3 & 0xfffffffb;
              goto LAB_0001ece2;
            }
          }
          else {
            if (local_22d == 'r') {
              *param_3 = *param_3 | 1;
            }
            if (local_22c == 'w') {
              *param_3 = *param_3 | 2;
            }
            if (local_22b == 'x') {
              uVar3 = *param_3 | 4;
LAB_0001ece2:
              *param_3 = uVar3;
            }
          }
          local_23c = 0;
          if (uVar2 <= local_238) goto LAB_0001ed0a;
        }
        pcVar1 = fgets(acStack_228,0x200,__stream);
        param_1 = local_244;
      } while (pcVar1 != (char *)0x0);
    }
LAB_0001ed04:
    local_23c = 0x3f1;
LAB_0001ed0a:
    fclose(__stream);
  }
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_23c);
  }
  return;
}


// ==== FUN_0001ed52 @ 0001ed52

int FUN_0001ed52(uint param_1,int param_2)

{
  long lVar1;
  long lVar2;
  long lVar3;
  long lVar4;
  int iVar5;
  int *piVar6;
  
  lVar1 = sysconf(0x27);
  lVar2 = sysconf(0x27);
  lVar3 = sysconf(0x27);
  lVar4 = sysconf(0x27);
  iVar5 = mprotect((void *)(-lVar1 & param_1),((param_1 + 3 & -lVar2) + lVar3) - (-lVar4 & param_1),
                   param_2);
  if (iVar5 == 0) {
    return 0;
  }
  piVar6 = (int *)__errno();
  iVar5 = *piVar6;
  if (iVar5 == 0) {
    iVar5 = 0x3e9;
  }
  return iVar5;
}


// ==== FUN_0001edae @ 0001edae

undefined8 FUN_0001edae(uint param_1)

{
  long lVar1;
  long lVar2;
  long lVar3;
  
  lVar1 = sysconf(0x27);
  lVar2 = sysconf(0x27);
  lVar3 = sysconf(0x27);
  software_interrupt(0);
  return CONCAT44((param_1 + 3 & -lVar2) + lVar3,-lVar1 & param_1);
}


// ==== FUN_0001ede0 @ 0001ede0

char * FUN_0001ede0(void)

{
  return "libxhook 1.2.0 (arm)";
}


// ==== FUN_0001edec @ 0001edec

void FUN_0001edec(pthread_cond_t *param_1)

{
  pthread_cond_signal(param_1);
  return;
}


// ==== FUN_0001ee0c @ 0001ee0c

void FUN_0001ee0c(void)

{
  return;
}


// ==== FUN_0001ee0e @ 0001ee0e

void FUN_0001ee0e(int *param_1)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  
  DataMemoryBarrier(0x1b);
  if (param_1[2] != 0) {
    piVar2 = param_1 + 2;
    DataMemoryBarrier(0x1b);
    do {
      ExclusiveAccess(piVar2);
      iVar3 = *piVar2;
      bVar1 = (bool)hasExclusiveAccess(piVar2);
    } while (!bVar1);
    *piVar2 = iVar3 + -1;
    DataMemoryBarrier(0x1b);
    if (iVar3 != 0) {
      return;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001ee40. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x10))();
  return;
}


// ==== FUN_0001ee48 @ 0001ee48

/* WARNING: Control flow encountered bad instruction data */

void FUN_0001ee48(pthread_mutex_t *param_1)

{
  int iVar1;
  
  iVar1 = pthread_mutex_lock(param_1);
  if (iVar1 != 0) {
    FUN_0001fba4(iVar1,"mutex lock failed");
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}


// ==== FUN_0001ee60 @ 0001ee60

void FUN_0001ee60(pthread_mutex_t *param_1)

{
  pthread_mutex_unlock(param_1);
  return;
}


// ==== FUN_0001ee80 @ 0001ee80

void FUN_0001ee80(size_t param_1)

{
  void *pvVar1;
  code *pcVar2;
  undefined4 uVar3;
  
  if (param_1 == 0) {
    param_1 = 1;
  }
  while( true ) {
    pvVar1 = malloc(param_1);
    if (pvVar1 != (void *)0x0) {
      return;
    }
    pcVar2 = (code *)FUN_000202d4();
    if (pcVar2 == (code *)0x0) break;
    (*pcVar2)();
  }
  FUN_0001fcbc(4);
  uVar3 = FUN_00029a1c();
  pvVar1 = (void *)FUN_0001fcf8(uVar3,&DAT_00032678,FUN_00029a0a + 1);
  free(pvVar1);
  return;
}


// ==== free @ 0001eec4

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== FUN_0001eec8 @ 0001eec8

undefined4 * FUN_0001eec8(undefined4 *param_1,char *param_2)

{
  size_t sVar1;
  size_t *psVar2;
  
  sVar1 = strlen(param_2);
  psVar2 = (size_t *)FUN_0001ee80(sVar1 + 0xd);
  *psVar2 = sVar1;
  psVar2[1] = sVar1;
  psVar2[2] = 0;
  memcpy(psVar2 + 3,param_2,sVar1 + 1);
  *param_1 = psVar2 + 3;
  return param_1;
}


// ==== FUN_0001ef04 @ 0001ef04

undefined4 * FUN_0001ef04(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_00029a3c_1_0003268c;
  FUN_0001eec8(param_1 + 1);
  return param_1;
}


// ==== FUN_0001ef30 @ 0001ef30

undefined4 * FUN_0001ef30(undefined4 *param_1,byte *param_2)

{
  byte *pbVar1;
  
  *param_1 = &PTR_FUN_00029aa8_1_000326a0;
  pbVar1 = *(byte **)(param_2 + 8);
  if ((*param_2 & 1) == 0) {
    pbVar1 = param_2 + 1;
  }
  FUN_0001eec8(param_1 + 1,pbVar1);
  return param_1;
}


// ==== FUN_0001ef68 @ 0001ef68

undefined4 * FUN_0001ef68(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_00029aa8_1_000326a0;
  FUN_0001eec8(param_1 + 1);
  return param_1;
}


// ==== FUN_0001ef94 @ 0001ef94

void FUN_0001ef94(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0001a480("basic_string");
}


// ==== FUN_0001efa4 @ 0001efa4

void FUN_0001efa4(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 in_d16;
  undefined8 in_d27;
  
                    /* WARNING: Call to offcut address within same function */
  uVar1 = func_0x0001efb4("basic_string");
  VectorShiftLeftInsert(in_d27,in_d16,0x3f);
  uVar2 = FUN_0001fcbc(8);
  FUN_0001f5fc(uVar2,uVar1);
  FUN_0001fcf8(uVar2,&PTR_PTR_000326ec,FUN_00029a3c + 1);
  FUN_0001fce6(uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0001fc74();
}


// ==== FUN_0001efec @ 0001efec

void * FUN_0001efec(void *param_1,void *param_2,size_t param_3)

{
  if (param_3 != 0) {
    memmove(param_1,param_2,param_3);
  }
  return param_1;
}


// ==== FUN_0001f000 @ 0001f000

void FUN_0001f000(uint *param_1,uint param_2,uint param_3,int param_4,int param_5,int param_6,
                 int param_7,undefined4 param_8)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  byte *__ptr;
  
  if (-param_2 - 0x12 < param_3) {
                    /* WARNING: Subroutine does not return */
    FUN_0001ef94(param_1);
  }
  __ptr = (byte *)param_1[2];
  if ((*param_1 & 1) == 0) {
    __ptr = (byte *)((int)param_1 + 1);
  }
  if (param_2 < 0x7fffffe7) {
    param_3 = param_3 + param_2;
    if (param_3 < param_2 << 1) {
      param_3 = param_2 << 1;
    }
    uVar3 = param_3 + 0x10 & 0xfffffff0;
    if (param_3 < 0xb) {
      uVar3 = 0xb;
    }
  }
  else {
    uVar3 = 0xffffffef;
  }
  uVar1 = FUN_0001ee80(uVar3);
  if (param_5 != 0) {
    FUN_0001f11e(uVar1,__ptr,param_5);
  }
  if (param_7 != 0) {
    FUN_0001f11e(uVar1 + param_5,param_8,param_7);
  }
  param_4 = param_4 - (param_5 + param_6);
  if (param_4 != 0) {
    FUN_0001f11e(uVar1 + param_5 + param_7,__ptr + param_6 + param_5,param_4);
  }
  if (param_2 != 10) {
    free(__ptr);
  }
  uVar2 = param_7 + param_5 + param_4;
  param_1[2] = uVar1;
  *(undefined1 *)(uVar1 + uVar2) = 0;
  *param_1 = uVar3 | 1;
  param_1[1] = uVar2;
  return;
}


// ==== FUN_0001f0cc @ 0001f0cc

void FUN_0001f0cc(int *param_1,undefined4 param_2,int param_3,uint param_4)

{
  undefined1 *puVar1;
  uint uVar2;
  
  if (0xffffffef < param_4) {
                    /* WARNING: Subroutine does not return */
    FUN_0001ef94(param_1);
  }
  if (param_4 < 0xb) {
    puVar1 = (undefined1 *)((int)param_1 + 1);
    *(char *)param_1 = (char)(param_3 << 1);
  }
  else {
    uVar2 = param_4 + 0x10 & 0xfffffff0;
    puVar1 = (undefined1 *)FUN_0001ee80(uVar2);
    *param_1 = uVar2 + 1;
    param_1[1] = param_3;
    param_1[2] = (int)puVar1;
  }
  FUN_0001f11e(puVar1,param_2,param_3);
  puVar1[param_3] = 0;
  return;
}


// ==== FUN_0001f11e @ 0001f11e

void * FUN_0001f11e(void *param_1,void *param_2,size_t param_3)

{
  if (param_3 != 0) {
    memcpy(param_1,param_2,param_3);
  }
  return param_1;
}


// ==== FUN_0001f130 @ 0001f130

undefined8 * FUN_0001f130(undefined8 *param_1,byte *param_2)

{
  if ((*param_2 & 1) == 0) {
    *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 8);
    *param_1 = *(undefined8 *)param_2;
  }
  else {
    FUN_0001f158(param_1,*(undefined4 *)(param_2 + 8),*(undefined4 *)(param_2 + 4));
  }
  return param_1;
}


// ==== FUN_0001f158 @ 0001f158

void FUN_0001f158(int *param_1,undefined4 param_2,uint param_3)

{
  uint uVar1;
  undefined1 *puVar2;
  
  if (param_3 < 0xb) {
    puVar2 = (undefined1 *)((int)param_1 + 1);
    *(char *)param_1 = (char)(param_3 << 1);
  }
  else {
    if (0xffffffef < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_0001ef94(param_1);
    }
    uVar1 = param_3 + 0x10 & 0xfffffff0;
    puVar2 = (undefined1 *)FUN_0001ee80(uVar1);
    *param_1 = uVar1 + 1;
    param_1[1] = param_3;
    param_1[2] = (int)puVar2;
  }
  FUN_0001f11e(puVar2,param_2,param_3 + 1);
  return;
}


// ==== FUN_0001f1a8 @ 0001f1a8

byte * FUN_0001f1a8(byte *param_1)

{
  if ((*param_1 & 1) != 0) {
    free(*(void **)(param_1 + 8));
  }
  return param_1;
}


// ==== FUN_0001f1c0 @ 0001f1c0

void FUN_0001f1c0(uint *param_1,uint param_2,uint param_3,int param_4,int param_5,int param_6,
                 int param_7)

{
  uint uVar1;
  byte *__ptr;
  uint uVar2;
  undefined1 auStackY_a8 [128];
  undefined1 *puVar3;
  
  puVar3 = auStackY_a8 + 0xa0;
  if (-param_2 - 0x11 < param_3) {
                    /* WARNING: Subroutine does not return */
    FUN_0001ef94(param_1);
  }
  __ptr = (byte *)param_1[2];
  if ((*param_1 & 1) == 0) {
    __ptr = (byte *)((int)param_1 + 1);
  }
  if (param_2 < 0x7fffffe7) {
    param_3 = param_3 + param_2;
    if (param_3 < param_2 << 1) {
      param_3 = param_2 << 1;
    }
    uVar2 = param_3 + 0x10 & 0xfffffff0;
    if (param_3 < 0xb) {
      uVar2 = 0xb;
    }
  }
  else {
    uVar2 = 0xffffffef;
  }
  uVar1 = FUN_0001ee80(uVar2);
  if (param_5 != 0) {
    FUN_0001f11e(uVar1,__ptr,param_5);
  }
  param_4 = param_4 - (param_5 + param_6);
  if (param_4 != 0) {
    FUN_0001f11e(param_7 + uVar1 + param_5,__ptr + param_6 + param_5,param_4,param_6,puVar3);
  }
  if (param_2 != 10) {
    free(__ptr);
  }
  param_1[2] = uVar1;
  *param_1 = uVar2 | 1;
  return;
}


// ==== FUN_0001f268 @ 0001f268

undefined4 FUN_0001f268(undefined4 param_1,int param_2)

{
  if (param_2 != 0) {
    FUN_0002a2e8(param_1);
  }
  return param_1;
}


// ==== FUN_0001f32c @ 0001f32c

uint * FUN_0001f32c(uint *param_1,undefined4 param_2,uint param_3)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  
  uVar3 = param_1[1];
  bVar1 = (byte)*param_1;
  iVar2 = (*param_1 & 0xfffffffe) - 1;
  if ((bVar1 & 1) == 0) {
    uVar3 = (uint)(bVar1 >> 1);
    iVar2 = 10;
  }
  if (iVar2 - uVar3 < param_3) {
    FUN_0001f000(param_1,iVar2,(uVar3 + param_3) - iVar2,uVar3,uVar3,0,param_3,param_2);
  }
  else if (param_3 != 0) {
    pbVar4 = (byte *)param_1[2];
    if ((bVar1 & 1) == 0) {
      pbVar4 = (byte *)((int)param_1 + 1);
    }
    FUN_0001f11e(pbVar4 + uVar3,param_2,param_3);
    uVar3 = uVar3 + param_3;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar3 * '\x02';
    }
    else {
      param_1[1] = uVar3;
    }
    pbVar4[uVar3] = 0;
  }
  return param_1;
}


// ==== FUN_0001f3aa @ 0001f3aa

uint * FUN_0001f3aa(uint *param_1,uint param_2,byte *param_3)

{
  byte bVar1;
  size_t sVar2;
  int iVar3;
  byte *pbVar4;
  size_t extraout_r3;
  size_t sVar5;
  undefined4 unaff_r4;
  uint uVar6;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  byte *pbVar7;
  byte *pbVar8;
  undefined1 auStackY_b8 [128];
  size_t sVar9;
  undefined1 *puVar10;
  
  sVar2 = strlen((char *)param_3);
  puVar10 = auStackY_b8 + 0xb0;
  bVar1 = (byte)*param_1;
  uVar6 = param_1[1];
  if ((bVar1 & 1) == 0) {
    uVar6 = (uint)(bVar1 >> 1);
  }
  if (uVar6 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_0001efa4(param_1);
  }
  iVar3 = (*param_1 & 0xfffffffe) - 1;
  if ((bVar1 & 1) == 0) {
    iVar3 = 10;
  }
  if (iVar3 - uVar6 < sVar2) {
    FUN_0001f000(param_1,iVar3,(uVar6 + sVar2) - iVar3,uVar6,param_2,0,sVar2,param_3);
  }
  else if (sVar2 != 0) {
    pbVar8 = (byte *)param_1[2];
    if ((bVar1 & 1) == 0) {
      pbVar8 = (byte *)((int)param_1 + 1);
    }
    pbVar4 = param_3;
    sVar9 = sVar2;
    if (uVar6 - param_2 == 0) {
      sVar5 = sVar2;
    }
    else {
      pbVar7 = pbVar8 + param_2;
      FUN_0001efec(pbVar7 + sVar2,pbVar7,uVar6 - param_2,sVar2,sVar2,unaff_r4,unaff_r5,unaff_r6,
                   puVar10);
      if (param_3 < pbVar8 + uVar6) {
        pbVar4 = param_3 + sVar2;
      }
      sVar5 = extraout_r3;
      if (param_3 < pbVar7) {
        pbVar4 = param_3;
      }
    }
    FUN_0001efec(pbVar8 + param_2,pbVar4,sVar2,sVar5,sVar9,unaff_r4,unaff_r5,unaff_r6,puVar10);
    uVar6 = uVar6 + sVar2;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar6 * '\x02';
    }
    else {
      param_1[1] = uVar6;
    }
    pbVar8[uVar6] = 0;
  }
  return param_1;
}


// ==== FUN_0001f3d2 @ 0001f3d2

void FUN_0001f3d2(uint *param_1,byte param_2)

{
  uint uVar1;
  byte *pbVar2;
  uint uVar3;
  
  if (((byte)*param_1 & 1) == 0) {
    uVar3 = (uint)(byte)((byte)*param_1 >> 1);
    if (uVar3 == 10) {
      uVar3 = 10;
      uVar1 = 10;
LAB_0001f400:
      FUN_0001f1c0(param_1,uVar1,1,uVar1,uVar1,0,0);
      if ((*param_1 & 1) != 0) goto LAB_0001f424;
    }
    pbVar2 = (byte *)((int)param_1 + 1);
    *(byte *)param_1 = (char)(uVar3 << 1) + 2;
  }
  else {
    uVar3 = param_1[1];
    uVar1 = (*param_1 & 0xfffffffe) - 1;
    if (uVar3 == uVar1) goto LAB_0001f400;
LAB_0001f424:
    param_1[1] = uVar3 + 1;
    pbVar2 = (byte *)param_1[2];
  }
  pbVar2[uVar3] = param_2;
  pbVar2[uVar3 + 1] = 0;
  return;
}


// ==== FUN_0001f4da @ 0001f4da

void FUN_0001f4da(undefined4 param_1,char *param_2)

{
  size_t sVar1;
  
  sVar1 = strlen(param_2);
  FUN_0001f32c(param_1,param_2,sVar1);
  return;
}


// ==== FUN_0001f4f6 @ 0001f4f6

uint * FUN_0001f4f6(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  uint uVar5;
  bool bVar6;
  undefined1 auStack_14 [4];
  
  uVar3 = param_1[1];
  if (((byte)*param_1 & 1) == 0) {
    uVar3 = (uint)(byte)((byte)*param_1 >> 1);
  }
  if (param_2 <= uVar3) {
    if ((*param_1 & 1) == 0) {
      *(byte *)((int)param_1 + param_2 + 1) = 0;
      *(byte *)param_1 = (byte)(param_2 << 1);
      return param_1;
    }
    *(undefined1 *)(param_1[2] + param_2) = 0;
    param_1[1] = param_2;
    return param_1;
  }
  param_2 = param_2 - uVar3;
  if (param_2 != 0) {
    uVar3 = param_1[1];
    bVar6 = ((byte)*param_1 & 1) == 0;
    if (bVar6) {
      uVar3 = (uint)(byte)((byte)*param_1 >> 1);
    }
    iVar2 = (*param_1 & 0xfffffffe) - 1;
    if (bVar6) {
      iVar2 = 10;
    }
    if (iVar2 - uVar3 < param_2) {
      FUN_0001f1c0(param_1,iVar2,(uVar3 + param_2) - iVar2,uVar3,uVar3,0,0,auStack_14 + 0xc);
      uVar1 = (uint)(byte)*param_1;
    }
    else {
      uVar1 = *param_1 & 0xff;
    }
    uVar5 = uVar3 + param_2;
    pbVar4 = (byte *)param_1[2];
    if ((uVar1 & 1) == 0) {
      pbVar4 = (byte *)((int)param_1 + 1);
    }
    FUN_0001f268(pbVar4 + uVar3,param_2,param_3);
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar5 * '\x02';
    }
    else {
      param_1[1] = uVar5;
    }
    pbVar4[uVar5] = 0;
  }
  return param_1;
}


// ==== FUN_0001f51a @ 0001f51a

void FUN_0001f51a(undefined4 param_1,char *param_2,byte *param_3)

{
  size_t sVar1;
  byte *pbVar2;
  uint uVar3;
  
  FUN_0001f614();
  sVar1 = strlen(param_2);
  uVar3 = *(uint *)(param_3 + 4);
  if ((*param_3 & 1) == 0) {
    uVar3 = (uint)(*param_3 >> 1);
  }
  FUN_0001f0cc(param_1,param_2,sVar1,uVar3 + sVar1);
  pbVar2 = *(byte **)(param_3 + 8);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
  }
  FUN_0001f32c(param_1,pbVar2,uVar3);
  return;
}


// ==== FUN_0001f56c @ 0001f56c

void FUN_0001f56c(undefined4 param_1,undefined4 param_2)

{
  undefined4 local_28 [2];
  undefined1 auStack_1f [11];
  int local_14;
  
  local_14 = __stack_chk_guard;
  FUN_0001f626(local_28,auStack_1f,&local_14,param_2);
  FUN_0001f6b8(param_1,auStack_1f,local_28[0]);
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001f5b8 @ 0001f5b8

undefined8 FUN_0001f5b8(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  uStack_20 = param_1;
  uStack_1c = param_2;
  uStack_18 = param_3;
  uVar1 = FUN_0001f718(param_2,(int)&uStack_20 + 1);
  FUN_0001f6b8(param_1,(int)&uStack_20 + 1,uVar1);
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return CONCAT44(uStack_1c,uStack_20);
}


// ==== FUN_0001f5fc @ 0001f5fc

void FUN_0001f5fc(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_0001ef04();
  *puVar1 = &PTR_FUN_00029a3c_1_000326e0;
  return;
}


// ==== FUN_0001f614 @ 0001f614

void FUN_0001f614(int param_1)

{
  int iVar1;
  
  for (iVar1 = 0; iVar1 != 3; iVar1 = iVar1 + 1) {
    *(undefined4 *)(param_1 + iVar1 * 4) = 0;
  }
  return;
}


// ==== FUN_0001f626 @ 0001f626

void FUN_0001f626(undefined4 param_1,undefined1 *param_2,undefined1 *param_3,uint param_4)

{
  undefined1 *puVar1;
  
  puVar1 = param_2;
  if ((0x7fffffff < param_4) && (param_2 != param_3)) {
    puVar1 = param_2 + 1;
    *param_2 = 0x2d;
    param_4 = -param_4;
  }
  FUN_0001f642(param_1,puVar1,param_3,param_4);
  return;
}


// ==== FUN_0001f642 @ 0001f642

void FUN_0001f642(int *param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  
  if ((param_3 - param_2 < 10) && (iVar1 = FUN_0001f684(param_4), param_3 - param_2 < iVar1)) {
    iVar1 = 0x4b;
    *param_1 = param_3;
  }
  else {
    iVar1 = FUN_0001f718(param_4,param_2);
    *param_1 = iVar1;
    iVar1 = 0;
  }
  param_1[1] = iVar1;
  return;
}


// ==== FUN_0001f684 @ 0001f684

int FUN_0001f684(uint param_1)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = (0x20 - LZCOUNT(param_1 | 1)) * 0x4d1;
  uVar2 = uVar1 >> 0xc;
  if (param_1 < *(uint *)(&DAT_00017d38 + uVar2 * 4)) {
    uVar2 = (uVar1 >> 0xc) - 1;
  }
  return uVar2 + 1;
}


// ==== FUN_0001f6b8 @ 0001f6b8

void FUN_0001f6b8(int *param_1,char *param_2,char *param_3)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = (int)param_3 - (int)param_2;
  if (0xffffffef < uVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_0001ef94(param_1);
  }
  if (uVar3 < 0xb) {
    *(char *)param_1 = (char)uVar3 * '\x02';
    pcVar1 = (char *)((int)param_1 + 1);
  }
  else {
    uVar2 = uVar3 + 0x10 & 0xfffffff0;
    pcVar1 = (char *)FUN_0001ee80(uVar2);
    *param_1 = uVar2 + 1;
    param_1[1] = uVar3;
    param_1[2] = (int)pcVar1;
  }
  for (; param_2 != param_3; param_2 = param_2 + 1) {
    *pcVar1 = *param_2;
    pcVar1 = pcVar1 + 1;
  }
  *pcVar1 = '\0';
  return;
}


// ==== FUN_0001f718 @ 0001f718

void FUN_0001f718(uint param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  if (99999999 < param_1) {
    iVar1 = FUN_00029b64(param_1,100000000);
    uVar2 = FUN_0001f7cc(param_2,iVar1);
    iVar3 = param_1 + iVar1 * -100000000;
    iVar1 = FUN_00029b64(iVar3,10000);
    uVar2 = FUN_0001f7dc(uVar2,iVar1);
    FUN_0001f7dc(uVar2,iVar3 + iVar1 * -10000);
    return;
  }
  if (param_1 < 10000) {
    FUN_0001f80e(param_2,param_1);
    return;
  }
  iVar1 = FUN_00029b64(param_1,10000);
  uVar2 = FUN_0001f80e(param_2,iVar1);
  FUN_0001f7dc(uVar2,param_1 + iVar1 * -10000);
  return;
}


// ==== FUN_0001f7cc @ 0001f7cc

char * FUN_0001f7cc(char *param_1,uint param_2)

{
  if (param_2 < 10) {
    *param_1 = (char)param_2 + '0';
    return param_1 + 1;
  }
  *(undefined2 *)param_1 =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + param_2 * 2);
  return param_1 + 2;
}


// ==== FUN_0001f7dc @ 0001f7dc

void FUN_0001f7dc(undefined4 param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_00029b64(param_2,100);
  uVar2 = FUN_0001f824(param_1,iVar1);
  FUN_0001f824(uVar2,param_2 + iVar1 * -100);
  return;
}


// ==== FUN_0001f80e @ 0001f80e

char * FUN_0001f80e(char *param_1,uint param_2)

{
  int iVar1;
  char *pcVar2;
  
  if (99 < param_2) {
    if (param_2 >> 3 < 0x7d) {
      iVar1 = FUN_00029b64(param_2,100);
      *param_1 = (char)iVar1 + '0';
      pcVar2 = (char *)FUN_0001f824(param_1 + 1,param_2 + iVar1 * -100);
      return pcVar2;
    }
    pcVar2 = (char *)FUN_0001f7dc();
    return pcVar2;
  }
  if (param_2 < 10) {
    *param_1 = (char)param_2 + '0';
    return param_1 + 1;
  }
  *(undefined2 *)param_1 =
       *(undefined2 *)
        (
        "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
        + param_2 * 2);
  return param_1 + 2;
}


// ==== FUN_0001f824 @ 0001f824

undefined2 * FUN_0001f824(undefined2 *param_1,int param_2)

{
  *param_1 = *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + param_2 * 2);
  return param_1 + 1;
}


// ==== FUN_0001f838 @ 0001f838

void FUN_0001f838(char *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_00029b64(param_2,100);
  *param_1 = (char)iVar1 + '0';
  FUN_0001f824(param_1 + 1,param_2 + iVar1 * -100);
  return;
}


// ==== FUN_0001f86c @ 0001f86c

void FUN_0001f86c(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 local_1c;
  undefined4 *puStack_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  local_1c = param_2;
  puStack_18 = param_3;
  (**(code **)(*param_1 + 0xc))(&local_1c,param_1,param_2,*(code **)(*param_1 + 0xc),param_1);
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(*param_3);
  }
  return;
}


// ==== FUN_0001f8d0 @ 0001f8d0

void FUN_0001f8d0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 *puVar1;
  char *pcVar2;
  char *__buf;
  undefined4 uVar3;
  char acStack_424 [1024];
  int iStack_24;
  
  iStack_24 = __stack_chk_guard;
  puVar1 = (undefined4 *)__errno();
  uVar3 = *puVar1;
  __buf = acStack_424;
  pcVar2 = strerror_r(param_3,__buf,0x400);
  if (pcVar2 != (char *)0x0) {
    if (pcVar2 == (char *)0xffffffff) {
      pcVar2 = (char *)*puVar1;
    }
    if (pcVar2 != (char *)0x16) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    __buf = "";
  }
  if (*__buf == '\0') {
    __buf = acStack_424;
    FUN_0001fc04(__buf);
  }
  *puVar1 = uVar3;
  FUN_0001a758(param_1,__buf);
  if (__stack_chk_guard != iStack_24) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001f968 @ 0001f968

void FUN_0001f968(undefined4 param_1,undefined4 param_2,int param_3)

{
  if (param_3 < 0x1000) {
    FUN_0001f8d0();
    return;
  }
  FUN_0001a758(param_1,"unspecified generic_category error");
  return;
}


// ==== FUN_0001f988 @ 0001f988

undefined4 * FUN_0001f988(void)

{
  int iVar1;
  
  DataMemoryBarrier(0x1b);
  if (((DAT_00036bb0 & 1) == 0) && (iVar1 = FUN_0001ffe4(&DAT_00036bb0), iVar1 != 0)) {
    DAT_00036bac = &PTR_LAB_0001fbf8_1_000314d0;
    FUN_000200c0(&DAT_00036bb0);
  }
  return &DAT_00036bac;
}


// ==== FUN_0001f9d4 @ 0001f9d4

void FUN_0001f9d4(undefined4 param_1,undefined4 param_2,int param_3)

{
  if (param_3 < 0x1000) {
    FUN_0001f8d0();
    return;
  }
  FUN_0001a758(param_1,"unspecified system_category error");
  return;
}


// ==== FUN_0001f9f4 @ 0001f9f4

void FUN_0001f9f4(int *param_1,undefined4 param_2,int param_3)

{
  undefined4 *puVar1;
  
  if (param_3 < 0x1000) {
    FUN_0001f988();
    puVar1 = &DAT_00036bac;
  }
  else {
    FUN_0001fa24();
    puVar1 = &DAT_00036bb4;
  }
  *param_1 = param_3;
  param_1[1] = (int)puVar1;
  return;
}


// ==== FUN_0001fa24 @ 0001fa24

undefined4 * FUN_0001fa24(void)

{
  int iVar1;
  
  DataMemoryBarrier(0x1b);
  if (((DAT_00036bb8 & 1) == 0) && (iVar1 = FUN_0001ffe4(&DAT_00036bb8), iVar1 != 0)) {
    DAT_00036bb4 = &PTR_LAB_0001fbf8_1_00031500;
    FUN_000200c0(&DAT_00036bb8);
  }
  return &DAT_00036bb4;
}


// ==== FUN_0001fa64 @ 0001fa64

void FUN_0001fa64(undefined8 *param_1,int *param_2,undefined8 *param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_28 [12];
  int local_1c;
  
  local_1c = __stack_chk_guard;
  if (*param_2 != 0) {
    iVar1 = FUN_0001faf4(param_3);
    if (iVar1 == 0) {
      FUN_0001f4da(param_3,&DAT_00016b5f);
    }
    (**(code **)(*(int *)param_2[1] + 0x18))(auStack_28,(int *)param_2[1],*param_2);
    FUN_0001fc44(param_3,auStack_28);
    FUN_0001f1a8(auStack_28);
  }
  uVar2 = *param_3;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_3 + 1);
  *param_1 = uVar2;
  FUN_0001f614(param_3);
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001faf4 @ 0001faf4

bool FUN_0001faf4(byte *param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 4);
  if ((*param_1 & 1) == 0) {
    uVar1 = (uint)(*param_1 >> 1);
  }
  return uVar1 == 0;
}


// ==== FUN_0001fb08 @ 0001fb08

void FUN_0001fb08(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_38 [12];
  undefined1 auStack_2c [12];
  undefined4 local_20;
  undefined4 uStack_1c;
  int local_14;
  
  local_14 = __stack_chk_guard;
  local_20 = param_2;
  uStack_1c = param_3;
  FUN_0001a758(auStack_38,param_4);
  FUN_0001fa64(auStack_2c,&local_20,auStack_38);
  FUN_0001ef30(param_1,auStack_2c);
  FUN_0001f1a8(auStack_2c);
  FUN_0001f1a8(auStack_38);
  param_1[2] = local_20;
  param_1[3] = uStack_1c;
  *param_1 = &PTR_LAB_0001fb90_1_0003149c;
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_14);
  }
  return;
}


// ==== FUN_0001fb94 @ 0001fb94

void FUN_0001fb94(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_00029aa8();
  free(__ptr);
  return;
}


// ==== FUN_0001fba4 @ 0001fba4

void FUN_0001fba4(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0001fcbc(0x10);
  FUN_0001fa24();
  FUN_0001fb08(uVar1,param_1,&DAT_00036bb4,param_2);
  FUN_0001fcf8(uVar1,&DAT_000314a8,&LAB_0001fb90_1);
  FUN_0001fce6(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0001fc74();
}


// ==== FUN_0001fc04 @ 0001fc04

void FUN_0001fc04(char *param_1)

{
  int iVar1;
  undefined1 uStack00000000;
  
  iVar1 = __stack_chk_guard;
  vsnprintf(param_1,0x400,"Unknown error %d",&uStack00000000);
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0001fc44 @ 0001fc44

void FUN_0001fc44(undefined4 param_1,byte *param_2)

{
  uint uVar1;
  byte *pbVar2;
  
  uVar1 = *(uint *)(param_2 + 4);
  pbVar2 = *(byte **)(param_2 + 8);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (uint)(*param_2 >> 1);
  }
  FUN_0001f32c(param_1,pbVar2,uVar1);
  return;
}


// ==== FUN_0001fc64 @ 0001fc64

void FUN_0001fc64(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0001a480("vector");
}


// ==== FUN_0001fc74 @ 0001fc74

void FUN_0001fc74(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined1 auStack_2e8 [392];
  undefined1 auStack_160 [336];
  undefined4 uStack_10;
  
  uStack_10 = param_2;
  iVar1 = FUN_0001fde4();
  FUN_0002ce70(auStack_160,uStack_10,param_3,param_4);
  if (*(int *)(iVar1 + 0xc) == 0) {
    FUN_0002b574(auStack_160,auStack_2e8,iVar1,1);
  }
  else {
    FUN_0002b770(auStack_160,auStack_2e8,iVar1,*(int *)(iVar1 + 0xc),*(undefined4 *)(iVar1 + 0x14));
  }
  fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","_Unwind_Resume","_Unwind_Resume() can\'t return");
  fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_0001fc8a @ 0001fc8a

undefined8 FUN_0001fc8a(undefined8 *param_1)

{
  return *param_1;
}


// ==== FUN_0001fc94 @ 0001fc94

bool FUN_0001fc94(uint *param_1)

{
  return (*param_1 >> 8 | param_1[1] << 0x18) == 0x47432b2b && param_1[1] >> 8 == 0x434c4e;
}


// ==== FUN_0001fcbc @ 0001fcbc

int FUN_0001fcbc(int param_1)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_1 + 0x87U & 0xfffffff8;
  iVar1 = FUN_000293bc(uVar2);
  if (iVar1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_00020238();
  }
  FUN_0002a2f8(iVar1,uVar2);
  return iVar1 + 0x80;
}


// ==== FUN_0001fce6 @ 0001fce6

void FUN_0001fce6(int param_1)

{
  FUN_000294c0(param_1 + -0x80);
  return;
}


// ==== FUN_0001fcf8 @ 0001fcf8

void FUN_0001fcf8(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  
  iVar1 = FUN_0001ffbc();
  uVar2 = FUN_00020224();
  *(undefined4 *)(param_1 + -0x70) = uVar2;
  uVar2 = FUN_0002028c();
  *(undefined4 *)(param_1 + -0x78) = param_2;
  *(undefined4 *)(param_1 + -0x74) = param_3;
  *(undefined4 *)(param_1 + -0x6c) = uVar2;
  FUN_0001fd50(param_1 + -0x58);
  *(undefined4 *)(param_1 + -0x7c) = 1;
  *(undefined **)(param_1 + -0x50) = &DAT_0001fd61;
  *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
  FUN_0002b488(param_1 + -0x58);
  puVar3 = (undefined4 *)FUN_0001fd78(param_1 + -0x80);
  puVar3[1] = 0x434c4e47;
  *puVar3 = 0x432b2b00;
  return;
}


// ==== FUN_0001fd50 @ 0001fd50

void FUN_0001fd50(undefined4 *param_1)

{
  param_1[1] = 0x434c4e47;
  *param_1 = 0x432b2b00;
  return;
}


// ==== FUN_0001fd78 @ 0001fd78

void FUN_0001fd78(int param_1)

{
  undefined4 *puVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  int unaff_r5;
  char cVar5;
  
  cVar5 = param_1 + 0x28 < 0;
  FUN_0001fe34();
  puVar2 = (uint *)FUN_000202a0(*(undefined4 *)(param_1 + 0x14));
  if (cVar5 != '\0') {
    *(int *)(unaff_r5 + 4) = *(int *)(unaff_r5 + 4) + 1;
    FUN_0002b488();
    puVar1 = (undefined4 *)FUN_0001fd78(param_1 + -0x80);
    puVar1[1] = 0x434c4e47;
    *puVar1 = 0x432b2b00;
    return;
  }
  iVar3 = FUN_0001ffbc();
  if ((*puVar2 >> 8 | puVar2[1] << 0x18) == 0x47432b2b && puVar2[1] >> 8 == 0x434c4e) {
    uVar4 = puVar2[-1];
    if (uVar4 == 0) {
      puVar2[-2] = *(uint *)(iVar3 + 8);
      *(uint **)(iVar3 + 8) = puVar2 + -10;
    }
    puVar2[-1] = uVar4 + 1;
  }
  else {
    if (*(int *)(iVar3 + 8) != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_00020238();
    }
    *(uint **)(iVar3 + 8) = puVar2 + -10;
  }
                    /* WARNING: Could not recover jumptable at 0x0001fdd0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)0x1fd8b)(1);
  return;
}


// ==== FUN_0001fde4 @ 0001fde4

uint * FUN_0001fde4(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = FUN_0001ffbc();
  iVar2 = *(int *)(iVar1 + 8);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_00020238();
  }
  if ((*(uint *)(iVar2 + 0x28) >> 8 | *(uint *)(iVar2 + 0x2c) << 0x18) == 0x47432b2b &&
      *(uint *)(iVar2 + 0x2c) >> 8 == 0x434c4e) {
    iVar3 = *(int *)(iVar2 + 0x24) + -1;
    *(int *)(iVar2 + 0x24) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(iVar1 + 8) = *(undefined4 *)(iVar2 + 0x20);
      *(undefined4 *)(iVar2 + 0x20) = 0;
    }
  }
  else {
    *(undefined4 *)(iVar1 + 8) = 0;
  }
  return (uint *)(iVar2 + 0x28);
}


// ==== FUN_0001fe34 @ 0001fe34

uint * FUN_0001fe34(uint *param_1)

{
  int *piVar1;
  uint *puVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  
  uVar4 = *param_1;
  uVar5 = param_1[1];
  piVar1 = (int *)FUN_0001ffbc();
  puVar2 = param_1 + -10;
  if (uVar5 >> 8 == 0x434c4e && (uVar4 >> 8 | uVar5 << 0x18) == 0x47432b2b) {
    uVar4 = param_1[-3];
    if ((int)uVar4 < 0) {
      uVar4 = -uVar4;
    }
    param_1[-3] = uVar4 + 1;
    puVar3 = (uint *)*piVar1;
    if (puVar3 != puVar2) {
      *piVar1 = (int)puVar2;
      param_1[-4] = (uint)puVar3;
    }
    piVar1[1] = piVar1[1] + -1;
    param_1 = (uint *)param_1[9];
  }
  else {
    if (*piVar1 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_00020238();
    }
    *piVar1 = (int)puVar2;
    param_1 = param_1 + 0x16;
  }
  return param_1;
}


// ==== FUN_0001fea4 @ 0001fea4

void FUN_0001fea4(void)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  piVar2 = (int *)FUN_0001ffd0();
  iVar3 = *piVar2;
  if (iVar3 != 0) {
    if ((*(uint *)(iVar3 + 0x28) >> 8 | *(uint *)(iVar3 + 0x2c) << 0x18) != 0x47432b2b ||
        *(uint *)(iVar3 + 0x2c) >> 8 != 0x434c4e) {
      FUN_0002b8bc((uint *)(iVar3 + 0x28));
      iVar3 = 0;
LAB_0001fee6:
      *piVar2 = iVar3;
      return;
    }
    iVar4 = *(int *)(iVar3 + 0x1c);
    if (iVar4 < 0) {
      *(int *)(iVar3 + 0x1c) = iVar4 + 1;
      if (iVar4 == -1) {
        iVar3 = *(int *)(iVar3 + 0x18);
        goto LAB_0001fee6;
      }
    }
    else {
      *(int *)(iVar3 + 0x1c) = iVar4 + -1;
      if (iVar4 + -1 == 0) {
        *piVar2 = *(int *)(iVar3 + 0x18);
        if (*(char *)(iVar3 + 0x28) == '\x01') {
          iVar3 = *(int *)(iVar3 + 4);
          FUN_000294c0();
          iVar3 = iVar3 + -0x80;
        }
        iVar4 = iVar3 + 0x80;
        if (iVar4 != 0) {
          piVar2 = (int *)(iVar3 + 4);
          DataMemoryBarrier(0x1b);
          do {
            ExclusiveAccess(piVar2);
            iVar5 = *piVar2;
            bVar1 = (bool)hasExclusiveAccess(piVar2);
          } while (!bVar1);
          *piVar2 = iVar5 + -1;
          DataMemoryBarrier(0x1b);
          if (iVar5 == 1) {
            if (*(code **)(iVar3 + 0xc) != (code *)0x0) {
              (**(code **)(iVar3 + 0xc))(iVar4);
            }
            FUN_0001fce6(iVar4);
            return;
          }
        }
        return;
      }
    }
  }
  return;
}


// ==== FUN_0001ff60 @ 0001ff60

void FUN_0001ff60(void)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  piVar2 = (int *)FUN_0001ffbc();
  iVar5 = *piVar2;
  if (iVar5 != 0) {
    puVar1 = (uint *)(iVar5 + 0x28);
    uVar4 = *(uint *)(iVar5 + 0x2c) ^ 0x434c4e47;
    uVar3 = *puVar1 & 0xffffff00 ^ 0x432b2b00;
    if (uVar3 == 0 && uVar4 == 0) {
      *(int *)(iVar5 + 0x1c) = -*(int *)(iVar5 + 0x1c);
      piVar2[1] = piVar2[1] + 1;
    }
    else {
      *piVar2 = 0;
    }
    FUN_0002b488(puVar1);
    FUN_0001fe34(puVar1);
    if (uVar3 == 0 && uVar4 == 0) {
      FUN_000202a0(*(undefined4 *)(iVar5 + 0x14));
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_00020238();
}


// ==== FUN_0001ffbc @ 0001ffbc

void FUN_0001ffbc(void)

{
  FUN_00029d34(&DAT_00036a1c);
  return;
}


// ==== FUN_0001ffd0 @ 0001ffd0

void FUN_0001ffd0(void)

{
  FUN_00029d34(&DAT_00036a1c);
  return;
}


// ==== FUN_0001ffe4 @ 0001ffe4

void FUN_0001ffe4(char *param_1)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  undefined1 auStack_34 [4];
  char *local_30;
  char *pcStack_2c;
  byte *local_28;
  int *local_24;
  char local_20;
  undefined1 auStack_1c [4];
  undefined1 local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  local_28 = (byte *)(param_1 + 1);
  local_18 = 0;
  local_20 = '\0';
  local_24 = (int *)0x0;
  DataMemoryBarrier(0x1b);
  local_30 = param_1;
  pcStack_2c = param_1;
  if (*param_1 == '\0') {
    FUN_00020134(auStack_34,"__cxa_guard_acquire");
    if (((local_20 != '\0') && ((int)((uint)*local_28 << 0x1e) < 0)) &&
       (iVar3 = *local_24, piVar2 = (int *)FUN_00020160(auStack_1c), iVar3 == *piVar2)) {
                    /* WARNING: Subroutine does not return */
      FUN_000201c4("__cxa_guard_acquire detected recursive initialization");
    }
    while( true ) {
      bVar1 = *local_28;
      if (-1 < (int)((uint)bVar1 << 0x1e)) break;
      *local_28 = bVar1 | 4;
      pthread_cond_wait((pthread_cond_t *)&DAT_00036bc0,(pthread_mutex_t *)&DAT_00036bbc);
    }
    if (bVar1 != 1) {
      if (local_20 != '\0') {
        piVar2 = (int *)FUN_00020160(auStack_1c);
        *local_24 = *piVar2;
      }
      *local_28 = 2;
    }
    FUN_0002017c(auStack_34);
  }
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_14);
  }
  return;
}


// ==== FUN_000200c0 @ 000200c0

void FUN_000200c0(undefined1 *param_1)

{
  byte bVar1;
  int iVar2;
  undefined1 auStack_20 [4];
  int local_1c;
  
  local_1c = __stack_chk_guard;
  DataMemoryBarrier(0x1b);
  *param_1 = 1;
  FUN_00020134(auStack_20,"__cxa_guard_release");
  bVar1 = param_1[1];
  param_1[1] = 1;
  FUN_0002017c();
  if (((int)((uint)bVar1 << 0x1d) < 0) && (iVar2 = FUN_000201a8(), iVar2 != 0)) {
                    /* WARNING: Subroutine does not return */
    FUN_000201c4("%s failed to broadcast","__cxa_guard_release");
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00020134 @ 00020134

undefined4 * FUN_00020134(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  
  *param_1 = param_2;
  iVar1 = pthread_mutex_lock((pthread_mutex_t *)&DAT_00036bbc);
  if (iVar1 != 0) {
                    /* WARNING: Subroutine does not return */
    FUN_000201c4("%s failed to acquire mutex",param_2);
  }
  return param_1;
}


// ==== FUN_00020160 @ 00020160

long * FUN_00020160(long *param_1)

{
  long lVar1;
  
  if ((char)param_1[1] == '\0') {
    lVar1 = syscall(0xe0);
    *param_1 = lVar1;
    *(undefined1 *)(param_1 + 1) = 1;
  }
  return param_1;
}


// ==== FUN_0002017c @ 0002017c

undefined4 * FUN_0002017c(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036bbc);
  if (iVar1 != 0) {
                    /* WARNING: Subroutine does not return */
    FUN_000201c4("%s failed to release mutex",*param_1);
  }
  return param_1;
}


// ==== FUN_000201a8 @ 000201a8

bool FUN_000201a8(void)

{
  int iVar1;
  
  iVar1 = pthread_cond_broadcast((pthread_cond_t *)&DAT_00036bc0);
  return iVar1 != 0;
}


// ==== FUN_000201c4 @ 000201c4

undefined8 FUN_000201c4(char *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int extraout_r2;
  undefined4 extraout_r3;
  undefined4 unaff_pc;
  undefined4 *__arg;
  char *local_2c;
  undefined4 *local_28;
  undefined4 local_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  __arg = &local_c;
  local_28 = __arg;
  local_c = param_2;
  uStack_8 = param_3;
  uStack_4 = param_4;
  vfprintf((FILE *)0x371b0,param_1,__arg);
  fputc(10,(FILE *)0x371b0);
  vasprintf(&local_2c,param_1,__arg);
  iVar1 = __assert2("/buildbot/src/android/ndk-r25-release/toolchain/llvm-project/libcxx/../../../toolchain/llvm-project/libcxxabi/src/abort_message.cpp"
                    ,0x48,"abort_message",local_2c,__arg);
  *(undefined4 *)(extraout_r2 + 0x50) = 0xb0;
  VectorTableLookup(iVar1,unaff_pc,3);
  VectorTableLookup(extraout_r3,unaff_pc,1);
  DataMemoryBarrier(0x1b);
  return CONCAT44(iVar1,**(undefined4 **)(FUN_00020224 + iVar1 + 6));
}


// ==== FUN_00020224 @ 00020224

undefined4 FUN_00020224(void)

{
  DataMemoryBarrier(0x1b);
  return DAT_00036a30;
}


// ==== FUN_00020238 @ 00020238

void FUN_00020238(void)

{
  int *piVar1;
  int iVar2;
  int unaff_r4;
  
  piVar1 = (int *)FUN_0001ffd0();
  if (piVar1 != (int *)0x0) {
    unaff_r4 = *piVar1;
  }
  if (piVar1 != (int *)0x0 && unaff_r4 != 0) goto LAB_00020258;
  do {
    DataMemoryBarrier(0x1b);
    FUN_000202a0(DAT_00036a2c);
LAB_00020258:
    iVar2 = FUN_0001fc94(unaff_r4 + 0x28);
  } while (iVar2 == 0);
  FUN_000202a0(*(undefined4 *)(unaff_r4 + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_00019e94();
}


// ==== FUN_00020278 @ 00020278

void FUN_00020278(code *param_1)

{
  (*param_1)();
                    /* WARNING: Subroutine does not return */
  FUN_000201c4("unexpected_handler unexpectedly returned");
}


// ==== FUN_0002028c @ 0002028c

undefined4 FUN_0002028c(void)

{
  DataMemoryBarrier(0x1b);
  return DAT_00036a2c;
}


// ==== FUN_000202a0 @ 000202a0

void FUN_000202a0(code *param_1)

{
  (*param_1)();
                    /* WARNING: Subroutine does not return */
  FUN_000201c4("terminate_handler unexpectedly returned");
}


// ==== FUN_000202d4 @ 000202d4

undefined4 FUN_000202d4(void)

{
  DataMemoryBarrier(0x1b);
  return DAT_00036bc4;
}


// ==== FUN_000202e8 @ 000202e8

void FUN_000202e8(void)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  longlong lVar7;
  undefined4 local_41c;
  undefined1 auStack_418 [1024];
  int iStack_18;
  int *piStack_14;
  
  piVar2 = (int *)FUN_0001ffd0();
  if ((piVar2 == (int *)0x0) || (iVar6 = *piVar2, iVar6 == 0)) {
                    /* WARNING: Subroutine does not return */
    FUN_000201c4("terminating");
  }
  iVar3 = FUN_0001fc94(iVar6 + 0x28);
  if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_000201c4("terminating with %s foreign exception",DAT_00036a34);
  }
  lVar7 = FUN_0001fc8a(iVar6 + 0x28);
  if (lVar7 == 0x434c4e47432b2b01) {
    piStack_14 = *(int **)(iVar6 + 4);
  }
  else {
    piStack_14 = (int *)(iVar6 + 0x80);
  }
  iVar6 = *(int *)(iVar6 + 8);
  local_41c = 0x400;
  uVar4 = FUN_000203e0(*(undefined4 *)(iVar6 + 4),auStack_418,&local_41c,&iStack_18);
  if (iStack_18 != 0) {
    uVar4 = *(undefined4 *)(iVar6 + 4);
  }
  iVar6 = FUN_00029604(&PTR_PTR_00032650,iVar6,&piStack_14);
  uVar1 = DAT_00036a34;
  if (iVar6 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_000201c4("terminating with %s exception of type %s",DAT_00036a34,uVar4);
  }
  uVar5 = (**(code **)(*piStack_14 + 8))();
                    /* WARNING: Subroutine does not return */
  FUN_000201c4("terminating with %s exception of type %s: %s",uVar1,uVar4,uVar5);
}


// ==== FUN_000203c4 @ 000203c4

void FUN_000203c4(void)

{
  DAT_00036a34 = "unexpected";
                    /* WARNING: Subroutine does not return */
  FUN_00020238();
}


// ==== FUN_000203e0 @ 000203e0

void FUN_000203e0(char *param_1,void *param_2,uint *param_3,undefined4 *param_4)

{
  bool bVar1;
  char *pcVar2;
  char *pcVar3;
  size_t sVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  uint uVar9;
  void *local_11f0;
  longlong local_11ec;
  undefined8 uStack_11e4;
  int local_11dc;
  int iStack_11d8;
  int local_11d4;
  char *local_11d0;
  char *local_11cc;
  undefined1 *local_11c8;
  undefined1 *puStack_11c4;
  undefined1 **local_11c0;
  undefined1 auStack_11bc [128];
  undefined1 *local_113c;
  undefined1 *puStack_1138;
  undefined4 **local_1134;
  undefined1 auStack_1130 [128];
  undefined4 *local_10b0;
  undefined4 *puStack_10ac;
  undefined4 **local_10a8;
  undefined4 local_10a4;
  undefined4 uStack_10a0;
  undefined4 uStack_109c;
  undefined4 uStack_1098;
  undefined4 local_1094;
  undefined4 uStack_1090;
  undefined4 uStack_108c;
  undefined4 uStack_1088;
  undefined4 *local_1084;
  undefined4 *puStack_1080;
  undefined4 **local_107c;
  undefined4 local_1078;
  undefined4 uStack_1074;
  undefined4 uStack_1070;
  undefined4 uStack_106c;
  undefined4 *local_1068;
  undefined4 *puStack_1064;
  undefined2 *local_1060;
  undefined4 local_105c;
  undefined4 uStack_1058;
  undefined4 uStack_1054;
  undefined4 uStack_1050;
  undefined2 local_104c [2];
  undefined4 local_1048;
  undefined4 local_1044;
  undefined4 uStack_1040;
  undefined4 uStack_103c;
  undefined4 uStack_1038;
  undefined4 local_1034;
  undefined4 *puStack_38;
  int iStack_2c;
  
  iStack_2c = __stack_chk_guard;
  if ((param_1 == (char *)0x0) || ((param_2 != (void *)0x0 && (param_3 == (uint *)0x0)))) {
    if (param_4 != (undefined4 *)0x0) {
      *param_4 = 0xfffffffd;
    }
    goto LAB_0002061c;
  }
  sVar4 = strlen(param_1);
  local_11cc = param_1 + sVar4;
  local_11c0 = &local_113c;
  local_11c8 = auStack_11bc;
  local_11d0 = param_1;
  puStack_11c4 = local_11c8;
  FUN_0002a2f8(local_11c8,0x80);
  local_1134 = &local_10b0;
  local_113c = auStack_1130;
  puStack_1138 = local_113c;
  FUN_0002a2f8(local_113c,0x80);
  uStack_10a0 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
  uStack_109c = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
  uStack_1098 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
  local_1044 = 0;
  local_1084 = &local_1078;
  local_1034 = 0;
  local_10b0 = &local_10a4;
  local_1048 = 0xffffffff;
  local_10a4 = 0;
  local_104c[0] = 1;
  local_1068 = &local_105c;
  local_1094 = 0;
  local_10a8 = &local_1084;
  local_105c = 0;
  local_1060 = local_104c;
  local_1078 = 0;
  local_107c = &local_1068;
  local_11ec = 0;
  uStack_11e4 = 0xffffffffffffffff;
  local_11f0 = (void *)0x0;
  puStack_10ac = local_10b0;
  uStack_1090 = uStack_10a0;
  uStack_108c = uStack_109c;
  uStack_1088 = uStack_1098;
  puStack_1080 = local_1084;
  uStack_1074 = uStack_10a0;
  uStack_1070 = uStack_109c;
  uStack_106c = uStack_1098;
  puStack_1064 = local_1068;
  uStack_1058 = uStack_10a0;
  uStack_1054 = uStack_109c;
  uStack_1050 = uStack_1098;
  uStack_1040 = uStack_10a0;
  uStack_103c = uStack_109c;
  uStack_1038 = uStack_1098;
  puStack_38 = &uStack_1038;
  iVar5 = FUN_0002079c(&local_11d0,&DAT_000168e5,&DAT_000168e7);
  if ((iVar5 == 0) && (iVar5 = FUN_0002079c(&local_11d0,&DAT_00016c6f,&DAT_00016c72), iVar5 == 0)) {
    iVar5 = FUN_0002079c(&local_11d0,&DAT_00016426,&DAT_0001642a);
    if ((iVar5 == 0) && (iVar5 = FUN_0002079c(&local_11d0,&DAT_00016965,&DAT_0001696a), iVar5 == 0))
    {
      puVar6 = (undefined4 *)FUN_00020e00(&local_11d0);
      if (local_11cc != local_11d0) goto LAB_000205ca;
    }
    else {
      local_11d4 = FUN_0002080c(&local_11d0);
      if ((local_11d4 == 0) || (iVar5 = FUN_0002079c(&local_11d0,"_block_invoke",""), iVar5 == 0)) {
LAB_000205b4:
        puVar6 = (undefined4 *)0x0;
      }
      else {
        if ((local_11d0 == local_11cc) || (*local_11d0 != '_')) {
          bVar1 = false;
        }
        else {
          bVar1 = true;
          local_11d0 = local_11d0 + 1;
        }
        puVar6 = (undefined4 *)0x0;
        FUN_00020d6c(&local_11dc,&local_11d0,0);
        if ((!bVar1) || (local_11dc != iStack_11d8)) {
          if (local_11cc != local_11d0) {
            if (*local_11d0 != '.') goto LAB_000205b4;
            local_11d0 = local_11cc;
          }
          puVar6 = (undefined4 *)
                   FUN_00020dbc(&local_11d0,"invocation function for block in ",&local_11d4);
        }
      }
    }
    if (puVar6 != (undefined4 *)0x0) goto LAB_000205be;
LAB_000205ca:
    uVar8 = 0xfffffffe;
  }
  else {
    puVar6 = (undefined4 *)FUN_0002080c(&local_11d0);
    pcVar3 = local_11cc;
    pcVar2 = local_11d0;
    if (puVar6 == (undefined4 *)0x0) goto LAB_000205ca;
    if (local_11cc != local_11d0) {
      if (*local_11d0 != '.') goto LAB_000205ca;
      puVar7 = (undefined4 *)FUN_000220a8(&uStack_1038,0x14);
      puVar7[2] = puVar6;
      puVar7[3] = pcVar2;
      puVar7[4] = pcVar3;
      *puVar7 = &PTR_LAB_00022116_1_00032258;
      puVar7[1] = 0x1010101;
      local_11d0 = local_11cc;
      puVar6 = puVar7;
    }
LAB_000205be:
    if (param_2 == (void *)0x0) {
      uVar9 = 0x400;
      param_2 = malloc(0x400);
      if (param_2 != (void *)0x0) goto LAB_000205e2;
      uVar8 = 0xffffffff;
    }
    else {
      uVar9 = *param_3;
LAB_000205e2:
      local_11ec = (ulonglong)uVar9 << 0x20;
      local_11f0 = param_2;
      FUN_00020684(puVar6,&local_11f0);
      FUN_000206aa(&local_11f0,0);
      if (param_3 != (uint *)0x0) {
        *param_3 = (uint)local_11ec;
      }
      uVar8 = 0;
    }
  }
  if (param_4 != (undefined4 *)0x0) {
    *param_4 = uVar8;
  }
  FUN_000206c4(&local_11d0);
LAB_0002061c:
  if (__stack_chk_guard != iStack_2c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iStack_2c);
  }
  return;
}


// ==== FUN_00020684 @ 00020684

void FUN_00020684(int *param_1,undefined4 param_2)

{
  (**(code **)(*param_1 + 0x10))(param_1);
  if (*(char *)((int)param_1 + 5) == '\x01') {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000206a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x14))(param_1,param_2);
  return;
}


// ==== FUN_000206aa @ 000206aa

void FUN_000206aa(int *param_1,undefined1 param_2)

{
  int iVar1;
  
  FUN_00020772(param_1,1);
  iVar1 = param_1[1];
  param_1[1] = iVar1 + 1;
  *(undefined1 *)(*param_1 + iVar1) = param_2;
  return;
}


// ==== FUN_000206c4 @ 000206c4

int FUN_000206c4(int param_1)

{
  undefined4 *__ptr;
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(param_1 + 0x1198);
  while (__ptr = (undefined4 *)*puVar1, __ptr != (undefined4 *)0x0) {
    *puVar1 = *__ptr;
    if ((undefined4 *)(param_1 + 0x198) != __ptr) {
      free(__ptr);
    }
  }
  *(undefined4 *)(param_1 + 0x198) = 0;
  *(undefined4 *)(param_1 + 0x19c) = 0;
  *puVar1 = (undefined4 *)(param_1 + 0x198);
  if (*(void **)(param_1 + 0x168) != (void *)(param_1 + 0x174)) {
    free(*(void **)(param_1 + 0x168));
  }
  FUN_0002072a(param_1 + 0x14c);
  FUN_00020742(param_1 + 0x120);
  FUN_0002075a(param_1 + 0x94);
  FUN_0002075a(param_1 + 8);
  return param_1;
}


// ==== FUN_0002072a @ 0002072a

undefined4 * FUN_0002072a(undefined4 *param_1)

{
  if ((undefined4 *)*param_1 != param_1 + 3) {
    free((undefined4 *)*param_1);
  }
  return param_1;
}


// ==== FUN_00020742 @ 00020742

undefined4 * FUN_00020742(undefined4 *param_1)

{
  if ((undefined4 *)*param_1 != param_1 + 3) {
    free((undefined4 *)*param_1);
  }
  return param_1;
}


// ==== FUN_0002075a @ 0002075a

undefined4 * FUN_0002075a(undefined4 *param_1)

{
  if ((undefined4 *)*param_1 != param_1 + 3) {
    free((undefined4 *)*param_1);
  }
  return param_1;
}


// ==== FUN_00020772 @ 00020772

void FUN_00020772(undefined4 *param_1,int param_2)

{
  uint uVar1;
  void *pvVar2;
  size_t __size;
  
  uVar1 = param_1[2];
  __size = param_2 + param_1[1];
  if (uVar1 <= __size) {
    if (__size <= uVar1 * 2) {
      __size = uVar1 << 1;
    }
    param_1[2] = __size;
    pvVar2 = realloc((void *)*param_1,__size);
    *param_1 = pvVar2;
    if (pvVar2 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_00020238();
    }
  }
  return;
}


// ==== FUN_0002079c @ 0002079c

void FUN_0002079c(int *param_1,int param_2,int param_3)

{
  int iVar1;
  int local_24;
  int iStack_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  local_24 = *param_1;
  iStack_20 = param_1[1];
  iVar1 = FUN_00021884(&local_24,param_2);
  if (iVar1 != 0) {
    *param_1 = (param_3 - param_2) + *param_1;
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_000207f4 @ 000207f4

undefined4 * FUN_000207f4(undefined4 *param_1,char *param_2)

{
  size_t sVar1;
  
  *param_1 = param_2;
  sVar1 = strlen(param_2);
  param_1[1] = param_2 + sVar1;
  return param_1;
}


// ==== FUN_0002080c @ 0002080c

void FUN_0002080c(undefined4 *param_1)

{
  char cVar1;
  bool bVar2;
  char *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  char *pcVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  int *piVar14;
  int local_50;
  int local_4c;
  undefined4 uStack_48;
  undefined4 *local_44;
  int local_40;
  undefined4 local_3c;
  char *local_38;
  undefined1 local_34 [4];
  uint local_30;
  undefined4 *local_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  pcVar3 = (char *)*param_1;
  pcVar9 = (char *)param_1[1];
  if ((pcVar9 == pcVar3) || (cVar1 = *pcVar3, cVar1 != 'T' && cVar1 != 'G')) {
    local_34[0] = 0;
    local_30 = (int)(param_1[0x5b] - param_1[0x5a]) >> 2;
    local_38 = (char *)0x0;
    local_3c = (char *)((uint)local_3c & 0xffff0000);
    local_2c = param_1;
    local_40 = FUN_000218c8(param_1,&local_3c);
    if (local_40 != 0) {
      iVar4 = param_1[0x5a];
      piVar6 = (int *)param_1[0x53];
      piVar14 = (int *)param_1[0x54];
      piVar10 = (int *)(param_1[0x5b] - iVar4);
      uVar13 = (int)piVar10 >> 2;
      for (uVar11 = local_30; uVar11 < uVar13; uVar11 = uVar11 + 1) {
        if (piVar6 != piVar14) {
          piVar10 = (int *)*piVar6;
        }
        if (piVar6 == piVar14 || piVar10 == (int *)0x0) goto LAB_00020926;
        iVar7 = *(int *)(iVar4 + uVar11 * 4);
        uVar12 = *(uint *)(iVar7 + 8);
        if ((uint)(piVar10[1] - *piVar10 >> 2) <= uVar12) goto LAB_00020926;
        piVar10 = *(int **)(*piVar10 + uVar12 * 4);
        *(int **)(iVar7 + 0xc) = piVar10;
      }
      param_1[0x5b] = iVar4 + local_30 * 4;
      iVar4 = FUN_00021d40(&local_2c);
      if (iVar4 == 0) {
        local_44 = (undefined4 *)0x0;
        iVar4 = FUN_0002079c(param_1,"Ua9enable_ifI","");
        if (iVar4 == 0) {
LAB_00020c74:
          local_50 = 0;
          if ((((char)local_3c != '\0') || (local_3c._1_1_ == '\0')) ||
             (local_50 = FUN_00020e00(param_1), local_50 != 0)) {
            pcVar3 = (char *)*param_1;
            if ((pcVar3 == (char *)param_1[1]) || (*pcVar3 != 'v')) {
              iVar4 = param_1[2];
              iVar7 = param_1[3];
              do {
                local_4c = FUN_00020e00(param_1);
                if (local_4c == 0) goto LAB_00020926;
                FUN_00021ea4(param_1 + 2,&local_4c);
                iVar8 = FUN_00021d40(&local_2c);
              } while (iVar8 == 0);
              FUN_00021f18(&local_4c,param_1,iVar7 - iVar4 >> 2);
            }
            else {
              *param_1 = pcVar3 + 1;
              local_4c = 0;
              uStack_48 = 0;
            }
            FUN_00021f38(param_1,&local_50,&local_40,&local_4c,&local_44,&local_38,local_34);
          }
        }
        else {
          iVar4 = param_1[2];
          iVar7 = param_1[3];
          while( true ) {
            pcVar3 = (char *)*param_1;
            if ((pcVar3 != (char *)param_1[1]) && (*pcVar3 == 'E')) {
              *param_1 = pcVar3 + 1;
              FUN_00021f18(&local_4c,param_1,iVar7 - iVar4 >> 2);
              local_44 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
              local_44[2] = local_4c;
              local_44[3] = uStack_48;
              *local_44 = &PTR_LAB_00022116_1_000321e8;
              local_44[1] = 0x1010109;
              goto LAB_00020c74;
            }
            local_4c = FUN_00021d64(param_1);
            if (local_4c == 0) break;
            FUN_00021ea4(param_1 + 2,&local_4c);
          }
        }
      }
    }
    goto LAB_00020926;
  }
  if (pcVar9 == pcVar3) goto LAB_00020926;
  if (cVar1 == 'G') {
    if ((uint)((int)pcVar9 - (int)pcVar3) < 2) goto LAB_00020926;
    if (pcVar3[1] == 'R') {
      *param_1 = pcVar3 + 2;
      iVar4 = FUN_000218c8(param_1,0);
      if (iVar4 == 0) goto LAB_00020926;
      iVar7 = FUN_00022048(param_1,&local_3c);
      pcVar3 = (char *)*param_1;
      if ((pcVar3 == (char *)param_1[1]) || (*pcVar3 != '_')) {
        if (iVar7 == 0) goto LAB_00020926;
      }
      else {
        *param_1 = pcVar3 + 1;
      }
      puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
      pcVar3 = "reference temporary for ";
      pcVar9 = "";
    }
    else {
      if (pcVar3[1] != 'V') goto LAB_00020926;
      *param_1 = pcVar3 + 2;
      iVar4 = FUN_000218c8(param_1,0);
      if (iVar4 == 0) goto LAB_00020926;
      puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
      pcVar3 = "guard variable for ";
      pcVar9 = "";
    }
    goto LAB_00020c20;
  }
  if (cVar1 != 'T') goto LAB_00020926;
  if ((uint)((int)pcVar9 - (int)pcVar3) < 2) {
switchD_00020984_caseD_55:
    pcVar3 = pcVar3 + 1;
    *param_1 = pcVar3;
    if (pcVar9 == pcVar3) {
      bVar2 = false;
    }
    else {
      bVar2 = *pcVar3 == 'v';
    }
    iVar4 = FUN_00021f94(param_1);
    if ((iVar4 != 0) || (iVar4 = FUN_0002080c(param_1), iVar4 == 0)) goto LAB_00020926;
    puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
    *puVar5 = &PTR_LAB_00022116_1_00031530;
    puVar5[1] = 0x1010114;
    if (bVar2) {
      pcVar3 = "virtual thunk to ";
      pcVar9 = "";
    }
    else {
      pcVar3 = "non-virtual thunk to ";
      pcVar9 = "";
    }
    puVar5[2] = pcVar3;
    puVar5[3] = pcVar9;
  }
  else {
    cVar1 = pcVar3[1];
    switch(cVar1) {
    case 'S':
      *param_1 = pcVar3 + 2;
      iVar4 = FUN_00020e00(param_1);
      if (iVar4 == 0) goto LAB_00020926;
      puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
      pcVar3 = "typeinfo name for ";
      pcVar9 = "";
      break;
    case 'T':
      *param_1 = pcVar3 + 2;
      iVar4 = FUN_00020e00(param_1);
      if (iVar4 == 0) goto LAB_00020926;
      puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
      pcVar3 = "VTT for ";
      pcVar9 = "";
      break;
    case 'U':
      goto switchD_00020984_caseD_55;
    case 'V':
      *param_1 = pcVar3 + 2;
      iVar4 = FUN_00020e00(param_1);
      if (iVar4 == 0) goto LAB_00020926;
      puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
      pcVar3 = "vtable for ";
      pcVar9 = "";
      break;
    case 'W':
      *param_1 = pcVar3 + 2;
      local_3c = (char *)FUN_000218c8(param_1,0);
      if (local_3c != (char *)0x0) {
        FUN_00020dbc(param_1,"thread-local wrapper routine for ",&local_3c);
      }
      goto LAB_00020926;
    default:
      if (cVar1 == 'C') {
        *param_1 = pcVar3 + 2;
        iVar4 = FUN_00020e00(param_1);
        if (iVar4 != 0) {
          FUN_00020d6c(&local_3c,param_1,1);
          pcVar3 = local_3c;
          pcVar9 = local_38;
          if (local_3c != local_38) {
            pcVar3 = (char *)*param_1;
            pcVar9 = (char *)param_1[1];
          }
          if ((local_3c != local_38 && pcVar3 != pcVar9) && (*pcVar3 == '_')) {
            *param_1 = pcVar3 + 1;
            iVar7 = FUN_00020e00(param_1);
            if (iVar7 != 0) {
              puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
              puVar5[2] = iVar7;
              puVar5[3] = iVar4;
              *puVar5 = &PTR_LAB_00022116_1_00031570;
              puVar5[1] = 0x1010115;
            }
          }
        }
        goto LAB_00020926;
      }
      if (cVar1 == 'H') {
        *param_1 = pcVar3 + 2;
        iVar4 = FUN_000218c8(param_1,0);
        if (iVar4 == 0) goto LAB_00020926;
        puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
        pcVar3 = "thread-local initialization routine for ";
        pcVar9 = "";
      }
      else if (cVar1 == 'I') {
        *param_1 = pcVar3 + 2;
        iVar4 = FUN_00020e00(param_1);
        if (iVar4 == 0) goto LAB_00020926;
        puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
        pcVar3 = "typeinfo for ";
        pcVar9 = "";
      }
      else {
        if (cVar1 != 'c') goto switchD_00020984_caseD_55;
        *param_1 = pcVar3 + 2;
        iVar4 = FUN_00021f94(param_1);
        if (((iVar4 != 0) || (iVar4 = FUN_00021f94(param_1), iVar4 != 0)) ||
           (iVar4 = FUN_0002080c(param_1), iVar4 == 0)) goto LAB_00020926;
        puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
        pcVar3 = "covariant return thunk to ";
        pcVar9 = "";
      }
    }
LAB_00020c20:
    *puVar5 = &PTR_LAB_00022116_1_00031530;
    puVar5[1] = 0x1010114;
    puVar5[2] = pcVar3;
    puVar5[3] = pcVar9;
  }
  puVar5[4] = iVar4;
LAB_00020926:
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_28);
  }
  return;
}


// ==== FUN_00020d6c @ 00020d6c

void FUN_00020d6c(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  
  pbVar2 = (byte *)*param_2;
  pbVar3 = (byte *)param_2[1];
  pbVar1 = pbVar2;
  if (param_3 == 0) {
LAB_00020d8a:
    if ((pbVar3 != pbVar1) && (0xfffffff5 < *pbVar1 - 0x3a)) {
      while (pbVar1 != pbVar3) {
        if (*pbVar1 - 0x3a < 0xfffffff6) {
          pbVar3 = pbVar1;
          break;
        }
        pbVar1 = pbVar1 + 1;
        *param_2 = pbVar1;
      }
      goto LAB_00020d9c;
    }
  }
  else if (pbVar2 != pbVar3) {
    if (*pbVar2 == 0x6e) {
      pbVar1 = pbVar2 + 1;
      *param_2 = pbVar1;
    }
    goto LAB_00020d8a;
  }
  pbVar2 = (byte *)0x0;
  pbVar3 = (byte *)0x0;
LAB_00020d9c:
  *param_1 = pbVar2;
  param_1[1] = pbVar3;
  return;
}


// ==== FUN_00020dbc @ 00020dbc

undefined4 * FUN_00020dbc(int param_1,char *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  size_t sVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
  sVar2 = strlen(param_2);
  puVar1[1] = 0x1010114;
  *puVar1 = &PTR_LAB_00022116_1_00031530;
  uVar3 = *param_3;
  puVar1[3] = param_2 + sVar2;
  puVar1[4] = uVar3;
  puVar1[2] = param_2;
  return puVar1;
}


// ==== FUN_00020e00 @ 00020e00

int * FUN_00020e00(undefined4 *param_1)

{
  byte bVar1;
  uint uVar2;
  byte *pbVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int iVar9;
  size_t sVar10;
  byte *pbVar11;
  undefined *puVar12;
  int **ppiVar13;
  byte *pbVar14;
  uint uVar15;
  char *pcVar16;
  int **ppiVar17;
  char *pcVar18;
  uint uVar19;
  int *local_2c;
  int *local_28;
  int *local_24;
  int *piStack_20;
  int *local_1c;
  
  piVar5 = __stack_chk_guard;
  local_1c = __stack_chk_guard;
  pbVar11 = (byte *)*param_1;
  pbVar14 = (byte *)param_1[1];
  local_2c = (int *)0x0;
  uVar2 = (int)pbVar14 - (int)pbVar11;
  if (pbVar14 == pbVar11) goto switchD_00020e32_caseD_42;
  bVar1 = *pbVar11;
  switch(bVar1) {
  case 0x41:
    if (pbVar11 != pbVar14) {
      pbVar3 = pbVar11 + 1;
      *param_1 = pbVar3;
      if (pbVar14 == pbVar3) {
LAB_00021508:
        iVar4 = FUN_00022cf0(param_1);
        if ((iVar4 != 0) && (pcVar16 = (char *)*param_1, pcVar16 != (char *)param_1[1])) {
LAB_00021542:
          if (*pcVar16 == '_') {
            pbVar11 = (byte *)(pcVar16 + 1);
            goto LAB_0002154c;
          }
        }
      }
      else {
        if (0xfffffff5 < *pbVar3 - 0x3a) {
          piVar5 = (int *)0x0;
          FUN_00020d6c(&local_24,param_1,0);
          iVar4 = FUN_00028674(param_1,&local_24);
          pcVar16 = (char *)*param_1;
          if (pcVar16 == (char *)param_1[1]) goto LAB_000217a8;
          goto LAB_00021542;
        }
        if (*pbVar3 != 0x5f) goto LAB_00021508;
        pbVar11 = pbVar11 + 2;
        iVar4 = 0;
LAB_0002154c:
        *param_1 = pbVar11;
        iVar9 = FUN_00020e00(param_1);
        if (iVar9 != 0) {
          piVar5 = (int *)FUN_000220a8(param_1 + 0x66,0x10);
          iVar6 = 0x100000e;
          puVar12 = &UNK_00032448;
          piVar5[2] = iVar9;
          piVar5[3] = iVar4;
LAB_00021572:
          *piVar5 = (int)(puVar12 + 8);
          piVar5[1] = iVar6;
          goto LAB_000217a8;
        }
      }
    }
    goto LAB_000217a6;
  default:
    goto switchD_00020e32_caseD_42;
  case 0x43:
    *param_1 = pbVar11 + 1;
    iVar6 = FUN_00020e00(param_1);
    if (iVar6 == 0) goto LAB_0002165a;
    local_2c = (int *)FUN_000220a8(param_1 + 0x66,0x14);
    pcVar16 = " complex";
    pcVar18 = "";
LAB_00021000:
    *local_2c = (int)&PTR_LAB_00022116_1_00032568;
    local_2c[1] = 0x1010105;
    local_2c[2] = iVar6;
    local_2c[3] = (int)pcVar16;
    local_2c[4] = (int)pcVar18;
    goto LAB_0002114a;
  case 0x44:
    if (uVar2 < 2) goto LAB_0002165a;
    piVar7 = (int *)0x0;
    switch(pbVar11[1]) {
    case 0x4f:
    case 0x6f:
    case 0x77:
    case 0x78:
      goto switchD_00020e32_caseD_46;
    default:
      goto switchD_00020f7a_caseD_50;
    case 0x54:
    case 0x74:
      local_2c = (int *)FUN_00022834(param_1);
      goto LAB_00021140;
    case 0x61:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        puVar12 = &DAT_00016375;
        goto LAB_0002140e;
      }
      break;
    case 99:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "decltype(auto)";
LAB_000213c2:
        puVar8 = (undefined4 *)FUN_00027300(param_1,pcVar16);
        return puVar8;
      }
      break;
    case 100:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "decimal64";
LAB_00021462:
        puVar8 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
        sVar10 = strlen(pcVar16);
        puVar8[2] = pcVar16;
        puVar8[3] = pcVar16 + sVar10;
        *puVar8 = &PTR_LAB_00022116_1_000315a8;
        puVar8[1] = 0x1010107;
        return puVar8;
      }
      break;
    case 0x65:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "decimal128";
        goto LAB_00021224;
      }
      break;
    case 0x66:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "decimal32";
        goto LAB_00021462;
      }
      break;
    case 0x68:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "decimal16";
        goto LAB_00021462;
      }
      break;
    case 0x69:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "char32_t";
LAB_00021344:
        puVar8 = (undefined4 *)FUN_000282e8(param_1,pcVar16);
        return puVar8;
      }
      break;
    case 0x6e:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "std::nullptr_t";
        goto LAB_000213c2;
      }
      break;
    case 0x70:
      *param_1 = pbVar11 + 2;
      local_24 = (int *)FUN_00020e00(param_1);
      if (local_24 != (int *)0x0) {
        local_2c = (int *)FUN_0002503c(param_1,&local_24);
        goto LAB_0002114a;
      }
      goto LAB_0002165a;
    case 0x73:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "char16_t";
        goto LAB_00021344;
      }
      break;
    case 0x75:
      *param_1 = pbVar11 + 2;
      if (__stack_chk_guard == piVar5) {
        pcVar16 = "char8_t";
        goto LAB_00021438;
      }
      break;
    case 0x76:
      iVar6 = FUN_0002079c(param_1,&DAT_00016fd9,&DAT_00016fdb);
      if (iVar6 == 0) goto LAB_000217a6;
      pbVar11 = (byte *)*param_1;
      if (((byte *)param_1[1] == pbVar11) || (bVar1 = *pbVar11, bVar1 < 0x31)) {
LAB_00021762:
        local_24 = (int *)FUN_00022cf0(param_1);
        if (((local_24 != (int *)0x0) && (pcVar16 = (char *)*param_1, pcVar16 != (char *)param_1[1])
            ) && (*pcVar16 == '_')) {
          *param_1 = pcVar16 + 1;
          local_28 = (int *)FUN_00020e00(param_1);
          if (local_28 != (int *)0x0) {
            ppiVar13 = &local_28;
            ppiVar17 = &local_24;
LAB_0002178c:
            piVar5 = (int *)FUN_000286a4(param_1,ppiVar13,ppiVar17);
            goto LAB_000217a8;
          }
        }
        goto LAB_000217a6;
      }
      if (bVar1 < 0x3a) {
        piVar5 = (int *)0x0;
        FUN_00020d6c(&local_24,param_1,0);
        piVar7 = (int *)FUN_00028674(param_1,&local_24);
        pcVar16 = (char *)*param_1;
        local_28 = piVar7;
        if (pcVar16 != (char *)param_1[1]) {
          if (*pcVar16 != '_') goto LAB_000217a6;
          pcVar18 = pcVar16 + 1;
          *param_1 = pcVar18;
          if ((pcVar18 == (char *)param_1[1]) || (*pcVar18 != 'p')) {
            local_24 = (int *)FUN_00020e00(param_1);
            if (local_24 == (int *)0x0) goto LAB_000217a6;
            ppiVar13 = &local_24;
            ppiVar17 = &local_28;
            goto LAB_0002178c;
          }
          *param_1 = pcVar16 + 2;
          piVar5 = (int *)FUN_000220a8(param_1 + 0x66,0xc);
          iVar6 = 0x101011a;
          puVar12 = &UNK_000323d8;
          piVar5[2] = (int)piVar7;
          goto LAB_00021572;
        }
      }
      else {
        if (bVar1 != 0x5f) goto LAB_00021762;
        *param_1 = pbVar11 + 1;
        iVar6 = FUN_00020e00(param_1);
        piVar5 = (int *)0x0;
        if (iVar6 != 0) {
          piVar5 = (int *)FUN_000220a8(param_1 + 0x66,0x10);
          piVar5[2] = iVar6;
          piVar5[3] = 0;
          *piVar5 = (int)&PTR_LAB_00022116_1_00032418;
          piVar5[1] = 0x1010119;
        }
      }
      goto LAB_000217a8;
    }
    break;
  case 0x46:
switchD_00020e32_caseD_46:
    local_2c = (int *)FUN_00027f48(param_1);
    goto LAB_00021140;
  case 0x47:
    *param_1 = pbVar11 + 1;
    iVar6 = FUN_00020e00(param_1);
    if (iVar6 != 0) {
      local_2c = (int *)FUN_000220a8(param_1 + 0x66,0x14);
      pcVar16 = " imaginary";
      pcVar18 = "";
      goto LAB_00021000;
    }
    goto LAB_0002165a;
  case 0x4b:
  case 0x56:
  case 0x72:
    uVar15 = (uint)(bVar1 == 0x72);
    if (uVar15 < uVar2) {
      uVar19 = 1;
      if (bVar1 == 0x72) {
        uVar19 = 2;
      }
      if (pbVar11[uVar15] == 0x56) {
        uVar15 = uVar19;
      }
    }
    if ((uVar15 < uVar2) && (pbVar11[uVar15] == 0x4b)) {
      uVar15 = uVar15 + 1;
    }
    if (uVar15 < uVar2) {
      if (pbVar11[uVar15] == 0x46) goto switchD_00020e32_caseD_46;
      if ((pbVar11[uVar15] == 0x44) && (uVar15 + 1 < uVar2)) {
        uVar2 = pbVar11[uVar15 + 1] - 0x6f;
        if (((uVar2 < 10) && ((1 << (uVar2 & 0xff) & 0x301U) != 0)) || (pbVar11[uVar15 + 1] == 0x4f)
           ) goto switchD_00020e32_caseD_46;
      }
    }
  case 0x55:
    local_2c = (int *)FUN_00028180(param_1);
    goto LAB_00021140;
  case 0x4d:
    if (pbVar11 != pbVar14) {
      *param_1 = pbVar11 + 1;
      iVar6 = FUN_00020e00(param_1);
      if (iVar6 != 0) {
        iVar4 = FUN_00020e00(param_1);
        if (iVar4 != 0) {
          piVar5 = (int *)FUN_000220a8(param_1 + 0x66,0x10);
          *(undefined2 *)((int)piVar5 + 6) = 0x101;
          *(undefined1 *)(piVar5 + 1) = 0xd;
          piVar5[2] = iVar6;
          piVar5[3] = iVar4;
          *piVar5 = (int)&PTR_LAB_000287c8_1_00032488;
          *(undefined1 *)((int)piVar5 + 5) = *(undefined1 *)(iVar4 + 5);
          goto LAB_000217a8;
        }
      }
    }
LAB_000217a6:
    piVar5 = (int *)0x0;
LAB_000217a8:
    local_2c = piVar5;
LAB_00021144:
    if (local_2c == (int *)0x0) goto LAB_0002165a;
LAB_0002114a:
    FUN_00021ea4(param_1 + 0x25,&local_2c);
    piVar7 = local_2c;
    goto switchD_00020f7a_caseD_50;
  case 0x4f:
    *param_1 = pbVar11 + 1;
    local_24 = (int *)FUN_00020e00(param_1);
    if (local_24 != (int *)0x0) {
      local_28 = (int *)0x1;
LAB_000210c2:
      local_2c = (int *)FUN_000283d8(param_1,&local_24,&local_28);
      goto LAB_0002114a;
    }
    goto LAB_0002165a;
  case 0x50:
    *param_1 = pbVar11 + 1;
    iVar6 = FUN_00020e00(param_1);
    if (iVar6 != 0) {
      local_2c = (int *)FUN_000220a8(param_1 + 0x66,0xc);
      local_2c[2] = iVar6;
      *(undefined2 *)((int)local_2c + 6) = 0x101;
      *(undefined1 *)(local_2c + 1) = 0xb;
      *local_2c = (int)&PTR_LAB_000288a2_1_000324f8;
      *(undefined1 *)((int)local_2c + 5) = *(undefined1 *)(iVar6 + 5);
      goto LAB_0002114a;
    }
    goto LAB_0002165a;
  case 0x52:
    *param_1 = pbVar11 + 1;
    local_24 = (int *)FUN_00020e00(param_1);
    if (local_24 != (int *)0x0) {
      local_28 = (int *)0x0;
      goto LAB_000210c2;
    }
    goto LAB_0002165a;
  case 0x53:
    if (((1 < uVar2) && (pbVar11[1] != 0)) && (pbVar11[1] != 0x74)) {
      local_24 = (int *)FUN_000221c4(param_1);
      piVar7 = local_24;
      if ((((local_24 == (int *)0x0) || (*(char *)(param_1 + 0x61) == '\0')) ||
          ((char *)param_1[1] == (char *)*param_1)) || (*(char *)*param_1 != 'I'))
      goto switchD_00020f7a_caseD_50;
      local_28 = (int *)FUN_000222e8(param_1,0);
      if (local_28 == (int *)0x0) goto LAB_0002165a;
      ppiVar13 = &local_24;
      ppiVar17 = &local_28;
LAB_00021500:
      local_2c = (int *)FUN_00022574(param_1,ppiVar13,ppiVar17);
      goto LAB_0002114a;
    }
    goto switchD_00020e32_caseD_42;
  case 0x54:
    if (((1 < uVar2) && (pbVar11[1] - 0x65 < 0x11)) &&
       ((1 << (pbVar11[1] - 0x65 & 0xff) & 0x14001U) != 0)) goto switchD_00020e32_caseD_42;
    local_2c = (int *)FUN_00022680(param_1);
    if (local_2c != (int *)0x0) {
      if (((*(char *)(param_1 + 0x61) == '\0') || ((char *)param_1[1] == (char *)*param_1)) ||
         (*(char *)*param_1 != 'I')) goto LAB_0002114a;
      local_24 = (int *)FUN_000222e8(param_1,0);
      if (local_24 != (int *)0x0) {
        ppiVar13 = &local_2c;
        ppiVar17 = &local_24;
        goto LAB_00021500;
      }
    }
    goto LAB_0002165a;
  case 0x61:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "signed char";
LAB_000211de:
      puVar8 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      sVar10 = strlen(pcVar16);
      puVar8[2] = pcVar16;
      puVar8[3] = pcVar16 + sVar10;
      *puVar8 = &PTR_LAB_00022116_1_000315a8;
      puVar8[1] = 0x1010107;
      return puVar8;
    }
    break;
  case 0x62:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar12 = &DAT_00016b87;
LAB_0002140e:
      puVar8 = (undefined4 *)FUN_00022b78(param_1,puVar12);
      return puVar8;
    }
    break;
  case 99:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar12 = &DAT_00016862;
      goto LAB_0002140e;
    }
    break;
  case 100:
    *param_1 = pbVar11 + 1;
    piVar7 = (int *)FUN_000220a8(param_1 + 0x66,0x10);
    pcVar16 = "double";
    pcVar18 = "";
    goto LAB_0002148a;
  case 0x65:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "long double";
      goto LAB_000211de;
    }
    break;
  case 0x66:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "float";
LAB_00021398:
      puVar8 = (undefined4 *)FUN_00025104(param_1,pcVar16);
      return puVar8;
    }
    break;
  case 0x67:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "__float128";
LAB_00021224:
      puVar8 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      sVar10 = strlen(pcVar16);
      puVar8[2] = pcVar16;
      puVar8[3] = pcVar16 + sVar10;
      *puVar8 = &PTR_LAB_00022116_1_000315a8;
      puVar8[1] = 0x1010107;
      return puVar8;
    }
    break;
  case 0x68:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "unsigned char";
LAB_0002131a:
      puVar8 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      sVar10 = strlen(pcVar16);
      puVar8[2] = pcVar16;
      puVar8[3] = pcVar16 + sVar10;
      *puVar8 = &PTR_LAB_00022116_1_000315a8;
      puVar8[1] = 0x1010107;
      return puVar8;
    }
    break;
  case 0x69:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar12 = &DAT_00016461;
LAB_000214b2:
      puVar8 = (undefined4 *)FUN_000225e8(param_1,puVar12);
      return puVar8;
    }
    break;
  case 0x6a:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar8 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      sVar10 = strlen("unsigned int");
      puVar8[2] = "unsigned int";
      puVar8[3] = "unsigned int" + sVar10;
      *puVar8 = &PTR_LAB_00022116_1_000315a8;
      puVar8[1] = 0x1010107;
      return puVar8;
    }
    break;
  case 0x6c:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar12 = &DAT_00015e85;
      goto LAB_0002140e;
    }
    break;
  case 0x6d:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "unsigned long";
      goto LAB_0002131a;
    }
    break;
  case 0x6e:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "__int128";
      goto LAB_00021344;
    }
    break;
  case 0x6f:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar8 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      sVar10 = strlen("unsigned __int128");
      puVar8[2] = "unsigned __int128";
      puVar8[3] = "unsigned __int128" + sVar10;
      *puVar8 = &PTR_LAB_00022116_1_000315a8;
      puVar8[1] = 0x1010107;
      return puVar8;
    }
    break;
  case 0x73:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "short";
      goto LAB_00021398;
    }
    break;
  case 0x74:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "unsigned short";
      goto LAB_000213c2;
    }
    break;
  case 0x75:
    *param_1 = pbVar11 + 1;
    FUN_000279b8(&local_24,param_1);
    if (local_24 != piStack_20) {
      local_2c = (int *)FUN_00026838(param_1,&local_24);
      goto LAB_0002114a;
    }
LAB_0002165a:
    piVar7 = (int *)0x0;
switchD_00020f7a_caseD_50:
    piVar5 = piVar7;
    if (__stack_chk_guard == local_1c) {
      return piVar5;
    }
    break;
  case 0x76:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar12 = &DAT_0001708d;
      goto LAB_0002140e;
    }
    break;
  case 0x77:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "wchar_t";
LAB_00021438:
      puVar8 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      sVar10 = strlen(pcVar16);
      puVar8[2] = pcVar16;
      puVar8[3] = pcVar16 + sVar10;
      *puVar8 = &PTR_LAB_00022116_1_000315a8;
      puVar8[1] = 0x1010107;
      return puVar8;
    }
    break;
  case 0x78:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      pcVar16 = "long long";
      goto LAB_00021462;
    }
    break;
  case 0x79:
    *param_1 = pbVar11 + 1;
    piVar7 = (int *)FUN_000220a8(param_1 + 0x66,0x10);
    pcVar16 = "unsigned long long";
    pcVar18 = "";
LAB_0002148a:
    *piVar7 = (int)&PTR_LAB_00022116_1_000315a8;
    piVar7[1] = 0x1010107;
    piVar7[2] = (int)pcVar16;
    piVar7[3] = (int)pcVar18;
    goto switchD_00020f7a_caseD_50;
  case 0x7a:
    *param_1 = pbVar11 + 1;
    if (__stack_chk_guard == piVar5) {
      puVar12 = &DAT_00016c8f;
      goto LAB_000214b2;
    }
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(piVar5);
switchD_00020e32_caseD_42:
  local_2c = (int *)FUN_00028320(param_1);
LAB_00021140:
  goto LAB_00021144;
}


// ==== FUN_00021884 @ 00021884

bool FUN_00021884(undefined4 *param_1,char *param_2,char *param_3)

{
  char *pcVar1;
  
  pcVar1 = (char *)*param_1;
  if ((uint)(param_1[1] - (int)pcVar1) < (uint)((int)param_3 - (int)param_2)) {
    return false;
  }
  for (; (param_2 != param_3 && (*param_2 == *pcVar1)); param_2 = param_2 + 1) {
    pcVar1 = pcVar1 + 1;
  }
  return param_2 == param_3;
}


// ==== FUN_000218c8 @ 000218c8

void FUN_000218c8(undefined4 *param_1,undefined1 *param_2)

{
  char cVar1;
  byte bVar2;
  undefined1 *puVar3;
  undefined1 uVar4;
  char *pcVar5;
  undefined4 uVar6;
  undefined4 *****pppppuVar7;
  int iVar8;
  byte *pbVar9;
  char *pcVar10;
  byte *pbVar11;
  byte *pbVar12;
  undefined4 ****ppppuVar13;
  bool bVar14;
  undefined4 *****local_44;
  undefined4 *puStack_40;
  undefined1 **local_3c;
  undefined4 *****local_38;
  undefined1 *local_34;
  undefined1 uStack_2d;
  undefined4 *****local_2c;
  int local_28;
  
  local_28 = __stack_chk_guard;
  pcVar5 = (char *)*param_1;
  pcVar10 = (char *)param_1[1];
  if ((pcVar5 != pcVar10) && (*pcVar5 == 'L')) {
    pcVar5 = pcVar5 + 1;
    *param_1 = pcVar5;
  }
  if (pcVar10 == pcVar5) goto LAB_000219a6;
  cVar1 = *pcVar5;
  if (cVar1 == 'Z') {
    if (pcVar5 != pcVar10) {
      *param_1 = pcVar5 + 1;
      local_2c = (undefined4 *****)FUN_0002080c(param_1);
      if (local_2c != (undefined4 *****)0x0) {
        pcVar5 = (char *)*param_1;
        if ((pcVar5 != (char *)param_1[1]) && (*pcVar5 == 'E')) {
          pcVar10 = pcVar5 + 1;
          *param_1 = pcVar10;
          if (pcVar10 == (char *)param_1[1]) {
LAB_00021a6c:
            local_44 = (undefined4 *****)FUN_000218c8(param_1,param_2);
            if (local_44 != (undefined4 *****)0x0) {
              uVar6 = FUN_00027a96(*param_1,param_1[1]);
              *param_1 = uVar6;
LAB_00021a84:
              pppppuVar7 = (undefined4 *****)FUN_00027afc(param_1,&local_2c,&local_44);
              goto LAB_00021a4c;
            }
          }
          else {
            if (*pcVar10 != 'd') {
              if (*pcVar10 != 's') goto LAB_00021a6c;
              *param_1 = pcVar5 + 2;
              uVar6 = FUN_00027a96();
              *param_1 = uVar6;
              local_44 = (undefined4 *****)FUN_00027300(param_1,"string literal");
              goto LAB_00021a84;
            }
            *param_1 = pcVar5 + 2;
            FUN_00020d6c(&local_44,param_1,1);
            pcVar5 = (char *)*param_1;
            if ((pcVar5 != (char *)param_1[1]) && (*pcVar5 == '_')) {
              *param_1 = pcVar5 + 1;
              local_44 = (undefined4 *****)FUN_000218c8(param_1,param_2);
              if (local_44 != (undefined4 *****)0x0) goto LAB_00021a84;
            }
          }
        }
      }
    }
    goto LAB_00021a4a;
  }
  if (cVar1 == 'S') {
    if ((1 < (uint)((int)pcVar10 - (int)pcVar5)) && (pcVar5[1] == 't')) goto LAB_000219a6;
    local_44 = (undefined4 *****)FUN_000221c4(param_1);
    if ((local_44 == (undefined4 *****)0x0) ||
       (((char *)param_1[1] == (char *)*param_1 || (*(char *)*param_1 != 'I')))) goto LAB_00021a4a;
LAB_00021a0e:
    local_2c = (undefined4 *****)FUN_000222e8(param_1,param_2 != (undefined1 *)0x0);
    if (local_2c != (undefined4 *****)0x0) {
      if (param_2 != (undefined1 *)0x0) {
        param_2[1] = 1;
      }
      pppppuVar7 = (undefined4 *****)FUN_00022574(param_1,&local_44,&local_2c);
      goto LAB_00021a4c;
    }
  }
  else {
    if (cVar1 == 'N') {
      local_34 = param_2;
      if ((pcVar5 == pcVar10) || (*pcVar5 != 'N')) goto LAB_00021a4a;
      *param_1 = pcVar5 + 1;
      uVar6 = FUN_000225a4(param_1);
      if (param_2 != (undefined1 *)0x0) {
        *(undefined4 *)(param_2 + 4) = uVar6;
      }
      pcVar5 = (char *)*param_1;
      if (pcVar5 == (char *)param_1[1]) {
LAB_00021a66:
        if (param_2 != (undefined1 *)0x0) {
          uVar4 = 0;
LAB_00021a98:
          param_2[8] = uVar4;
        }
      }
      else if (*pcVar5 == 'R') {
        *param_1 = pcVar5 + 1;
        if (param_2 != (undefined1 *)0x0) {
          uVar4 = 1;
          goto LAB_00021a98;
        }
      }
      else {
        if (*pcVar5 != 'O') goto LAB_00021a66;
        *param_1 = pcVar5 + 1;
        if (param_2 != (undefined1 *)0x0) {
          uVar4 = 2;
          goto LAB_00021a98;
        }
      }
      local_38 = (undefined4 *****)0x0;
      local_3c = &local_34;
      local_44 = &local_38;
      puStack_40 = param_1;
      iVar8 = FUN_0002079c(param_1,&DAT_00015e48,&DAT_00015e4a);
      if (iVar8 != 0) {
        local_38 = (undefined4 *****)FUN_000225e8(param_1,&DAT_000162c4);
      }
LAB_00021ad6:
      do {
        puVar3 = local_34;
        pbVar9 = (byte *)*param_1;
        pbVar11 = (byte *)param_1[1];
        if (pbVar9 != pbVar11) {
          if (*pbVar9 == 0x4c) {
            pbVar9 = pbVar9 + 1;
            *param_1 = pbVar9;
          }
          else if (*pbVar9 == 0x45) {
            *param_1 = pbVar9 + 1;
            if ((local_38 != (undefined4 *****)0x0) && (param_1[0x25] != param_1[0x26])) {
              param_1[0x26] = param_1[0x26] + -4;
              pppppuVar7 = local_38;
              goto LAB_00021a4c;
            }
            break;
          }
        }
        if ((pbVar9 == pbVar11) || (*pbVar9 != 0x4d)) {
          if (pbVar11 == pbVar9) goto LAB_00021c16;
          bVar2 = *pbVar9;
          if (bVar2 == 0x43) {
LAB_00021b42:
            if (local_38 == (undefined4 *****)0x0) break;
            if ((*(char *)(local_38 + 1) == ')') &&
               (ppppuVar13 = local_38[2], (int)ppppuVar13 - 2U < 4)) {
              local_38 = (undefined4 *****)FUN_000220a8(param_1 + 0x66,0xc);
              *local_38 = (undefined4 ****)&PTR_LAB_00022116_1_00031f80;
              local_38[1] = (undefined4 ****)0x1010128;
              local_38[2] = ppppuVar13;
              pbVar9 = (byte *)*param_1;
              pbVar11 = (byte *)param_1[1];
            }
            if ((pbVar9 == pbVar11) || (*pbVar9 != 0x43)) {
              if (pbVar11 == pbVar9) goto LAB_00021cb6;
              uVar6 = 0;
              if ((*pbVar9 == 0x44) && ((int)pbVar11 - (int)pbVar9 != 1)) {
                pppppuVar7 = (undefined4 *****)(pbVar9[1] - 0x30);
                uVar6 = 0;
                if ((pppppuVar7 < (undefined4 *****)0x6) && (pppppuVar7 != (undefined4 *****)0x3)) {
                  *param_1 = pbVar9 + 2;
                  uStack_2d = 1;
                  local_2c = pppppuVar7;
                  if (puVar3 != (undefined1 *)0x0) {
                    *puVar3 = 1;
                  }
                  goto LAB_00021ca0;
                }
              }
            }
            else {
              pbVar12 = pbVar9 + 1;
              *param_1 = pbVar12;
              if (pbVar12 == pbVar11) {
                bVar14 = false;
                pbVar12 = pbVar11;
              }
              else {
                bVar14 = *pbVar12 == 0x49;
                if (bVar14) {
                  pbVar12 = pbVar9 + 2;
                  *param_1 = pbVar12;
                }
              }
              if ((pbVar11 != pbVar12) && (*pbVar12 - 0x31 < 5)) {
                local_2c = (undefined4 *****)(*pbVar12 - 0x30);
                *param_1 = pbVar12 + 1;
                if (puVar3 != (undefined1 *)0x0) {
                  *puVar3 = 1;
                }
                if ((!bVar14) || (iVar8 = FUN_000218c8(param_1,puVar3), iVar8 != 0)) {
                  uStack_2d = 0;
LAB_00021ca0:
                  uVar6 = FUN_00027890(param_1,&local_38,&uStack_2d,&local_2c);
                  goto LAB_00021cb8;
                }
              }
LAB_00021cb6:
              uVar6 = 0;
            }
LAB_00021cb8:
            iVar8 = FUN_00022620(&local_44,uVar6);
            if (iVar8 == 0) break;
            pppppuVar7 = (undefined4 *****)FUN_000228b4(param_1,local_38);
            local_38 = pppppuVar7;
LAB_00021c26:
            if (pppppuVar7 == (undefined4 *****)0x0) break;
          }
          else {
            if (bVar2 == 0x44) {
              if (1 < (uint)((int)pbVar11 - (int)pbVar9)) {
                bVar2 = pbVar9[1];
                if (bVar2 == 0x43) goto LAB_00021c16;
                if (bVar2 == 0x74 || bVar2 == 0x54) {
                  uVar6 = FUN_00022834(param_1);
                  goto LAB_00021c1e;
                }
              }
              goto LAB_00021b42;
            }
            if (bVar2 != 0x49) {
              if (bVar2 == 0x53) {
                if (((uint)((int)pbVar11 - (int)pbVar9) < 2) || (pbVar9[1] != 0x74)) {
                  pppppuVar7 = (undefined4 *****)FUN_000221c4(param_1);
                  local_2c = pppppuVar7;
                  iVar8 = FUN_00022620(&local_44,pppppuVar7);
                  if (iVar8 == 0) break;
                  if (local_38 != pppppuVar7) {
                    FUN_00021ea4(param_1 + 0x25,&local_2c);
                  }
                  goto LAB_00021ad6;
                }
LAB_00021c16:
                uVar6 = FUN_00022944(param_1,local_34);
              }
              else {
                if (bVar2 != 0x54) goto LAB_00021c16;
                uVar6 = FUN_00022680(param_1);
              }
LAB_00021c1e:
              pppppuVar7 = (undefined4 *****)FUN_00022620(&local_44,uVar6);
              goto LAB_00021c26;
            }
            local_2c = (undefined4 *****)FUN_000222e8(param_1,local_34 != (undefined1 *)0x0);
            if ((local_2c == (undefined4 *****)0x0) || (local_38 == (undefined4 *****)0x0)) break;
            local_38 = (undefined4 *****)FUN_00022574(param_1,&local_38,&local_2c);
            if (local_34 != (undefined1 *)0x0) {
              local_34[1] = 1;
            }
          }
          FUN_00021ea4(param_1 + 0x25,&local_38);
          goto LAB_00021ad6;
        }
        *param_1 = pbVar9 + 1;
      } while (local_38 != (undefined4 *****)0x0);
      goto LAB_00021a4a;
    }
LAB_000219a6:
    iVar8 = FUN_0002079c(param_1,&DAT_0001699a,&DAT_0001699d);
    if ((iVar8 == 0) && (iVar8 = FUN_0002079c(param_1,&DAT_00015e48,&DAT_00015e4a), iVar8 == 0)) {
      local_44 = (undefined4 *****)FUN_00022944(param_1,param_2);
      if (local_44 != (undefined4 *****)0x0) {
LAB_000219f6:
        pppppuVar7 = local_44;
        if (((char *)param_1[1] == (char *)*param_1) || (*(char *)*param_1 != 'I'))
        goto LAB_00021a4c;
        FUN_00021ea4(param_1 + 0x25,&local_44);
        goto LAB_00021a0e;
      }
    }
    else {
      ppppuVar13 = (undefined4 ****)FUN_00022944(param_1,param_2);
      if (ppppuVar13 != (undefined4 ****)0x0) {
        local_44 = (undefined4 *****)FUN_000220a8(param_1 + 0x66,0xc);
        local_44[2] = ppppuVar13;
        *local_44 = (undefined4 ****)&PTR_LAB_00022116_1_00032178;
        local_44[1] = (undefined4 ****)0x1010127;
        goto LAB_000219f6;
      }
    }
  }
LAB_00021a4a:
  pppppuVar7 = (undefined4 *****)0x0;
LAB_00021a4c:
  if (__stack_chk_guard != local_28) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(pppppuVar7);
  }
  return;
}


// ==== FUN_00021d40 @ 00021d40

bool FUN_00021d40(undefined4 *param_1)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = *(char **)*param_1;
  if ((char *)((undefined4 *)*param_1)[1] == pcVar2) {
    return true;
  }
  cVar1 = *pcVar2;
  if (cVar1 == '.' || cVar1 == 'E') {
    return true;
  }
  return cVar1 == '_';
}


// ==== FUN_00021d64 @ 00021d64

/* WARNING: Removing unreachable block (ram,0x00021e5a) */
/* WARNING: Removing unreachable block (ram,0x00021dbc) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

int * FUN_00021d64(undefined8 *param_1)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  byte *pbVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  char *pcVar8;
  int *piVar9;
  int iVar10;
  size_t sVar11;
  byte *pbVar12;
  undefined *puVar13;
  int **ppiVar14;
  char *pcVar15;
  char *pcVar16;
  byte *pbVar17;
  uint uVar18;
  int **ppiVar19;
  int iVar20;
  int *unaff_r5;
  uint uVar21;
  int *unaff_r6;
  char *pcVar22;
  bool bVar23;
  undefined8 uVar24;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *local_24;
  int *in_stack_ffffffe0;
  
  piVar5 = __stack_chk_guard;
  pcVar8 = *(char **)param_1;
  pcVar15 = *(char **)((int)param_1 + 4);
  if (pcVar15 == pcVar8) {
code_r0x00020e00:
    pbVar12 = *(byte **)param_1;
    pbVar17 = *(byte **)((int)param_1 + 4);
    piStack_2c = (int *)0x0;
    uVar3 = (int)pbVar17 - (int)pbVar12;
    if (pbVar17 == pbVar12) goto switchD_00020e32_caseD_42;
    bVar1 = *pbVar12;
    switch(bVar1) {
    case 0x41:
      if (pbVar12 != pbVar17) {
        pbVar4 = pbVar12 + 1;
        *(byte **)param_1 = pbVar4;
        if (pbVar17 == pbVar4) {
LAB_00021508:
          iVar20 = FUN_00022cf0(param_1);
          if ((iVar20 != 0) && (pcVar8 = *(char **)param_1, pcVar8 != *(char **)((int)param_1 + 4)))
          {
LAB_00021542:
            if (*pcVar8 == '_') {
              pbVar12 = (byte *)(pcVar8 + 1);
              goto LAB_0002154c;
            }
          }
        }
        else {
          if (0xfffffff5 < *pbVar4 - 0x3a) {
            piVar9 = (int *)0x0;
            FUN_00020d6c(&local_24,param_1,0);
            iVar20 = FUN_00028674(param_1,&local_24);
            pcVar8 = *(char **)param_1;
            if (pcVar8 == *(char **)((int)param_1 + 4)) goto LAB_000217a8;
            goto LAB_00021542;
          }
          if (*pbVar4 != 0x5f) goto LAB_00021508;
          pbVar12 = pbVar12 + 2;
          iVar20 = 0;
LAB_0002154c:
          *(byte **)param_1 = pbVar12;
          iVar6 = FUN_00020e00(param_1);
          if (iVar6 != 0) {
            piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
            iVar10 = 0x100000e;
            puVar13 = &UNK_00032448;
            piVar9[2] = iVar6;
            piVar9[3] = iVar20;
LAB_00021572:
            *piVar9 = (int)(puVar13 + 8);
            piVar9[1] = iVar10;
            goto LAB_000217a8;
          }
        }
      }
      goto LAB_000217a6;
    default:
      goto switchD_00020e32_caseD_42;
    case 0x43:
      *(byte **)param_1 = pbVar12 + 1;
      iVar10 = FUN_00020e00(param_1);
      if (iVar10 == 0) goto LAB_0002165a;
      piStack_2c = (int *)FUN_000220a8(param_1 + 0x33,0x14);
      pcVar8 = " complex";
      pcVar15 = "";
LAB_00021000:
      *piStack_2c = (int)&PTR_LAB_00022116_1_00032568;
      piStack_2c[1] = 0x1010105;
      piStack_2c[2] = iVar10;
      piStack_2c[3] = (int)pcVar8;
      piStack_2c[4] = (int)pcVar15;
      goto LAB_0002114a;
    case 0x44:
      if (uVar3 < 2) goto LAB_0002165a;
      piVar9 = (int *)0x0;
      switch(pbVar12[1]) {
      case 0x4f:
      case 0x6f:
      case 0x77:
      case 0x78:
        goto switchD_00020e32_caseD_46;
      default:
        goto switchD_00020f7a_caseD_50;
      case 0x54:
      case 0x74:
        piStack_2c = (int *)FUN_00022834(param_1);
        goto LAB_00021140;
      case 0x61:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          puVar13 = &DAT_00016375;
          goto LAB_0002140e;
        }
        break;
      case 99:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "decltype(auto)";
LAB_000213c2:
          piVar5 = (int *)FUN_00027300(param_1,pcVar8);
          return piVar5;
        }
        break;
      case 100:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "decimal64";
LAB_00021462:
          piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
          sVar11 = strlen(pcVar8);
          piVar5[2] = (int)pcVar8;
          piVar5[3] = (int)(pcVar8 + sVar11);
          *piVar5 = (int)&PTR_LAB_00022116_1_000315a8;
          piVar5[1] = 0x1010107;
          return piVar5;
        }
        break;
      case 0x65:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "decimal128";
          goto LAB_00021224;
        }
        break;
      case 0x66:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "decimal32";
          goto LAB_00021462;
        }
        break;
      case 0x68:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "decimal16";
          goto LAB_00021462;
        }
        break;
      case 0x69:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "char32_t";
LAB_00021344:
          piVar5 = (int *)FUN_000282e8(param_1,pcVar8);
          return piVar5;
        }
        break;
      case 0x6e:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "std::nullptr_t";
          goto LAB_000213c2;
        }
        break;
      case 0x70:
        *(byte **)param_1 = pbVar12 + 2;
        iVar10 = FUN_00020e00(param_1);
        if (iVar10 != 0) {
          piStack_2c = (int *)FUN_0002503c(param_1,&local_24);
          goto LAB_0002114a;
        }
        goto LAB_0002165a;
      case 0x73:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "char16_t";
          goto LAB_00021344;
        }
        break;
      case 0x75:
        *(byte **)param_1 = pbVar12 + 2;
        if (__stack_chk_guard == piVar5) {
          pcVar8 = "char8_t";
          goto LAB_00025220;
        }
        break;
      case 0x76:
        iVar10 = FUN_0002079c(param_1,&DAT_00016fd9,&DAT_00016fdb);
        if (iVar10 == 0) goto LAB_000217a6;
        pbVar12 = *(byte **)param_1;
        if ((*(byte **)((int)param_1 + 4) == pbVar12) || (bVar1 = *pbVar12, bVar1 < 0x31)) {
LAB_00021762:
          iVar10 = FUN_00022cf0(param_1);
          if (((iVar10 != 0) && (pcVar8 = *(char **)param_1, pcVar8 != *(char **)((int)param_1 + 4))
              ) && (*pcVar8 == '_')) {
            *(char **)param_1 = pcVar8 + 1;
            piStack_28 = (int *)FUN_00020e00(param_1);
            if (piStack_28 != (int *)0x0) {
              ppiVar14 = &piStack_28;
              ppiVar19 = &local_24;
LAB_0002178c:
              piVar9 = (int *)FUN_000286a4(param_1,ppiVar14,ppiVar19);
              goto LAB_000217a8;
            }
          }
          goto LAB_000217a6;
        }
        if (bVar1 < 0x3a) {
          piVar9 = (int *)0x0;
          FUN_00020d6c(&local_24,param_1,0);
          piVar7 = (int *)FUN_00028674(param_1,&local_24);
          pcVar8 = *(char **)param_1;
          piStack_28 = piVar7;
          if (pcVar8 != *(char **)((int)param_1 + 4)) {
            if (*pcVar8 != '_') goto LAB_000217a6;
            pcVar15 = pcVar8 + 1;
            *(char **)param_1 = pcVar15;
            if ((pcVar15 == *(char **)((int)param_1 + 4)) || (*pcVar15 != 'p')) {
              iVar10 = FUN_00020e00(param_1);
              if (iVar10 == 0) goto LAB_000217a6;
              ppiVar14 = &local_24;
              ppiVar19 = &piStack_28;
              goto LAB_0002178c;
            }
            *(char **)param_1 = pcVar8 + 2;
            piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0xc);
            iVar10 = 0x101011a;
            puVar13 = &UNK_000323d8;
            piVar9[2] = (int)piVar7;
            goto LAB_00021572;
          }
        }
        else {
          if (bVar1 != 0x5f) goto LAB_00021762;
          *(byte **)param_1 = pbVar12 + 1;
          iVar10 = FUN_00020e00(param_1);
          piVar9 = (int *)0x0;
          if (iVar10 != 0) {
            piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
            piVar9[2] = iVar10;
            piVar9[3] = 0;
            *piVar9 = (int)&PTR_LAB_00022116_1_00032418;
            piVar9[1] = 0x1010119;
          }
        }
        goto LAB_000217a8;
      }
      break;
    case 0x46:
switchD_00020e32_caseD_46:
      piStack_2c = (int *)FUN_00027f48(param_1);
      goto LAB_00021140;
    case 0x47:
      *(byte **)param_1 = pbVar12 + 1;
      iVar10 = FUN_00020e00(param_1);
      if (iVar10 != 0) {
        piStack_2c = (int *)FUN_000220a8(param_1 + 0x33,0x14);
        pcVar8 = " imaginary";
        pcVar15 = "";
        goto LAB_00021000;
      }
      goto LAB_0002165a;
    case 0x4b:
    case 0x56:
    case 0x72:
      uVar18 = (uint)(bVar1 == 0x72);
      if (uVar18 < uVar3) {
        uVar21 = 1;
        if (bVar1 == 0x72) {
          uVar21 = 2;
        }
        if (pbVar12[uVar18] == 0x56) {
          uVar18 = uVar21;
        }
      }
      if ((uVar18 < uVar3) && (pbVar12[uVar18] == 0x4b)) {
        uVar18 = uVar18 + 1;
      }
      if (uVar18 < uVar3) {
        if (pbVar12[uVar18] == 0x46) goto switchD_00020e32_caseD_46;
        if ((pbVar12[uVar18] == 0x44) && (uVar18 + 1 < uVar3)) {
          uVar3 = pbVar12[uVar18 + 1] - 0x6f;
          if (((uVar3 < 10) && ((1 << (uVar3 & 0xff) & 0x301U) != 0)) ||
             (pbVar12[uVar18 + 1] == 0x4f)) goto switchD_00020e32_caseD_46;
        }
      }
    case 0x55:
      piStack_2c = (int *)FUN_00028180(param_1);
      goto LAB_00021140;
    case 0x4d:
      if (pbVar12 != pbVar17) {
        *(byte **)param_1 = pbVar12 + 1;
        iVar10 = FUN_00020e00(param_1);
        if (iVar10 != 0) {
          iVar20 = FUN_00020e00(param_1);
          if (iVar20 != 0) {
            piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
            *(undefined2 *)((int)piVar9 + 6) = 0x101;
            *(undefined1 *)(piVar9 + 1) = 0xd;
            piVar9[2] = iVar10;
            piVar9[3] = iVar20;
            *piVar9 = (int)&PTR_LAB_000287c8_1_00032488;
            *(undefined1 *)((int)piVar9 + 5) = *(undefined1 *)(iVar20 + 5);
            goto LAB_000217a8;
          }
        }
      }
LAB_000217a6:
      piVar9 = (int *)0x0;
LAB_000217a8:
      piStack_2c = piVar9;
LAB_00021144:
      if (piStack_2c == (int *)0x0) goto LAB_0002165a;
LAB_0002114a:
      FUN_00021ea4((undefined4 *)((int)param_1 + 0x94),&piStack_2c);
      piVar9 = piStack_2c;
      goto switchD_00020f7a_caseD_50;
    case 0x4f:
      *(byte **)param_1 = pbVar12 + 1;
      iVar10 = FUN_00020e00(param_1);
      if (iVar10 != 0) {
        piStack_28 = (int *)0x1;
LAB_000210c2:
        piStack_2c = (int *)FUN_000283d8(param_1,&local_24,&piStack_28);
        goto LAB_0002114a;
      }
      goto LAB_0002165a;
    case 0x50:
      *(byte **)param_1 = pbVar12 + 1;
      iVar10 = FUN_00020e00(param_1);
      if (iVar10 != 0) {
        piStack_2c = (int *)FUN_000220a8(param_1 + 0x33,0xc);
        piStack_2c[2] = iVar10;
        *(undefined2 *)((int)piStack_2c + 6) = 0x101;
        *(undefined1 *)(piStack_2c + 1) = 0xb;
        *piStack_2c = (int)&PTR_LAB_000288a2_1_000324f8;
        *(undefined1 *)((int)piStack_2c + 5) = *(undefined1 *)(iVar10 + 5);
        goto LAB_0002114a;
      }
      goto LAB_0002165a;
    case 0x52:
      *(byte **)param_1 = pbVar12 + 1;
      iVar10 = FUN_00020e00(param_1);
      if (iVar10 != 0) {
        piStack_28 = (int *)0x0;
        goto LAB_000210c2;
      }
      goto LAB_0002165a;
    case 0x53:
      if (((1 < uVar3) && (pbVar12[1] != 0)) && (pbVar12[1] != 0x74)) {
        piVar9 = (int *)FUN_000221c4(param_1);
        if (((piVar9 == (int *)0x0) || (*(char *)((int)param_1 + 0x184) == '\0')) ||
           ((*(char **)((int)param_1 + 4) == *(char **)param_1 || (**(char **)param_1 != 'I'))))
        goto switchD_00020f7a_caseD_50;
        piStack_28 = (int *)FUN_000222e8(param_1,0);
        if (piStack_28 == (int *)0x0) goto LAB_0002165a;
        ppiVar14 = &local_24;
        ppiVar19 = &piStack_28;
LAB_00021500:
        piStack_2c = (int *)FUN_00022574(param_1,ppiVar14,ppiVar19);
        goto LAB_0002114a;
      }
      goto switchD_00020e32_caseD_42;
    case 0x54:
      if (((1 < uVar3) && (pbVar12[1] - 0x65 < 0x11)) &&
         ((1 << (pbVar12[1] - 0x65 & 0xff) & 0x14001U) != 0)) goto switchD_00020e32_caseD_42;
      piStack_2c = (int *)FUN_00022680(param_1);
      if (piStack_2c != (int *)0x0) {
        if (((*(char *)((int)param_1 + 0x184) == '\0') ||
            (*(char **)((int)param_1 + 4) == *(char **)param_1)) || (**(char **)param_1 != 'I'))
        goto LAB_0002114a;
        iVar10 = FUN_000222e8(param_1,0);
        if (iVar10 != 0) {
          ppiVar14 = &piStack_2c;
          ppiVar19 = &local_24;
          goto LAB_00021500;
        }
      }
      goto LAB_0002165a;
    case 0x61:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "signed char";
LAB_000211de:
        piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        sVar11 = strlen(pcVar8);
        piVar5[2] = (int)pcVar8;
        piVar5[3] = (int)(pcVar8 + sVar11);
        *piVar5 = (int)&PTR_LAB_00022116_1_000315a8;
        piVar5[1] = 0x1010107;
        return piVar5;
      }
      break;
    case 0x62:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        puVar13 = &DAT_00016b87;
LAB_0002140e:
        piVar5 = (int *)FUN_00022b78(param_1,puVar13);
        return piVar5;
      }
      break;
    case 99:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        puVar13 = &DAT_00016862;
        goto LAB_0002140e;
      }
      break;
    case 100:
      *(byte **)param_1 = pbVar12 + 1;
      piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
      pcVar8 = "double";
      pcVar15 = "";
      goto LAB_0002148a;
    case 0x65:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "long double";
        goto LAB_000211de;
      }
      break;
    case 0x66:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "float";
LAB_00021398:
        piVar5 = (int *)FUN_00025104(param_1,pcVar8);
        return piVar5;
      }
      break;
    case 0x67:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "__float128";
LAB_00021224:
        piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        sVar11 = strlen(pcVar8);
        piVar5[2] = (int)pcVar8;
        piVar5[3] = (int)(pcVar8 + sVar11);
        *piVar5 = (int)&PTR_LAB_00022116_1_000315a8;
        piVar5[1] = 0x1010107;
        return piVar5;
      }
      break;
    case 0x68:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "unsigned char";
LAB_0002131a:
        piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        sVar11 = strlen(pcVar8);
        piVar5[2] = (int)pcVar8;
        piVar5[3] = (int)(pcVar8 + sVar11);
        *piVar5 = (int)&PTR_LAB_00022116_1_000315a8;
        piVar5[1] = 0x1010107;
        return piVar5;
      }
      break;
    case 0x69:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        puVar13 = &DAT_00016461;
LAB_000214b2:
        piVar5 = (int *)FUN_000225e8(param_1,puVar13);
        return piVar5;
      }
      break;
    case 0x6a:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        sVar11 = strlen("unsigned int");
        piVar5[2] = (int)"unsigned int";
        piVar5[3] = (int)("unsigned int" + sVar11);
        *piVar5 = (int)&PTR_LAB_00022116_1_000315a8;
        piVar5[1] = 0x1010107;
        return piVar5;
      }
      break;
    case 0x6c:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        puVar13 = &DAT_00015e85;
        goto LAB_0002140e;
      }
      break;
    case 0x6d:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "unsigned long";
        goto LAB_0002131a;
      }
      break;
    case 0x6e:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "__int128";
        goto LAB_00021344;
      }
      break;
    case 0x6f:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        sVar11 = strlen("unsigned __int128");
        piVar5[2] = (int)"unsigned __int128";
        piVar5[3] = (int)("unsigned __int128" + sVar11);
        *piVar5 = (int)&PTR_LAB_00022116_1_000315a8;
        piVar5[1] = 0x1010107;
        return piVar5;
      }
      break;
    case 0x73:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "short";
        goto LAB_00021398;
      }
      break;
    case 0x74:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "unsigned short";
        goto LAB_000213c2;
      }
      break;
    case 0x75:
      *(byte **)param_1 = pbVar12 + 1;
      FUN_000279b8(&local_24,param_1);
      if (local_24 != in_stack_ffffffe0) {
        piStack_2c = (int *)FUN_00026838(param_1,&local_24);
        goto LAB_0002114a;
      }
LAB_0002165a:
      piVar9 = (int *)0x0;
switchD_00020f7a_caseD_50:
      bVar23 = __stack_chk_guard == piVar5;
      piVar5 = piVar9;
      if (bVar23) {
        return piVar9;
      }
      break;
    case 0x76:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        puVar13 = &DAT_0001708d;
        goto LAB_0002140e;
      }
      break;
    case 0x77:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "wchar_t";
LAB_00025220:
        piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        sVar11 = strlen(pcVar8);
        piVar5[2] = (int)pcVar8;
        piVar5[3] = (int)(pcVar8 + sVar11);
        *piVar5 = (int)&PTR_LAB_00022116_1_000315a8;
        piVar5[1] = 0x1010107;
        return piVar5;
      }
      break;
    case 0x78:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        pcVar8 = "long long";
        goto LAB_00021462;
      }
      break;
    case 0x79:
      *(byte **)param_1 = pbVar12 + 1;
      piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
      pcVar8 = "unsigned long long";
      pcVar15 = "";
LAB_0002148a:
      *piVar9 = (int)&PTR_LAB_00022116_1_000315a8;
      piVar9[1] = 0x1010107;
      piVar9[2] = (int)pcVar8;
      piVar9[3] = (int)pcVar15;
      goto switchD_00020f7a_caseD_50;
    case 0x7a:
      *(byte **)param_1 = pbVar12 + 1;
      if (__stack_chk_guard == piVar5) {
        puVar13 = &DAT_00016c8f;
        goto LAB_000214b2;
      }
    }
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(piVar5);
  }
  cVar2 = *pcVar8;
  if (cVar2 == 'J') {
    iVar20 = *(int *)((int)param_1 + 0xc);
    iVar10 = *(int *)(param_1 + 1);
    pcVar8 = pcVar8 + 1;
    *(char **)param_1 = pcVar8;
    while( true ) {
      if ((pcVar8 != pcVar15) && (*pcVar8 == 'E')) {
        *(char **)param_1 = pcVar8 + 1;
        FUN_00021f18(&local_24,param_1,iVar20 - iVar10 >> 2);
        piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        piVar9[2] = (int)local_24;
        piVar9[3] = (int)in_stack_ffffffe0;
        *piVar9 = (int)&PTR_LAB_00022116_1_000321b0;
        piVar9[1] = 0x1010121;
        goto LAB_00021e20;
      }
      local_24 = (int *)FUN_00021d64(param_1);
      if (local_24 == (int *)0x0) break;
      FUN_00021ea4(param_1 + 1,&local_24);
      pcVar8 = *(char **)param_1;
      pcVar15 = *(char **)((int)param_1 + 4);
    }
LAB_00021e1e:
    piVar9 = (int *)0x0;
LAB_00021e20:
    if (__stack_chk_guard != piVar5) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(piVar9);
    }
    return piVar9;
  }
  if (cVar2 != 'L') {
    if (cVar2 != 'X') goto code_r0x00020e00;
    *(char **)param_1 = pcVar8 + 1;
    piVar9 = (int *)FUN_00022cf0(param_1);
LAB_00021e08:
    if (((piVar9 != (int *)0x0) &&
        (pcVar8 = *(char **)param_1, pcVar8 != *(char **)((int)param_1 + 4))) && (*pcVar8 == 'E')) {
      *(char **)param_1 = pcVar8 + 1;
      goto LAB_00021e20;
    }
    goto LAB_00021e1e;
  }
  if ((1 < (uint)((int)pcVar15 - (int)pcVar8)) && (pcVar8[1] == 'Z')) {
    *(char **)param_1 = pcVar8 + 2;
    piVar9 = (int *)FUN_0002080c(param_1);
    goto LAB_00021e08;
  }
  piStack_28 = __stack_chk_guard;
  pcVar15 = *(char **)param_1;
  pcVar8 = *(char **)((int)param_1 + 4);
  piStack_30 = unaff_r5;
  if ((pcVar15 == pcVar8) || (*pcVar15 != 'L')) goto LAB_00024ab6;
  pcVar16 = pcVar15 + 1;
  *(char **)param_1 = pcVar16;
  piStack_2c = unaff_r6;
  if (pcVar8 == pcVar16) {
switchD_0002459a_caseD_42:
    iVar10 = FUN_00020e00(param_1);
    if (iVar10 == 0) goto LAB_00024ab6;
    piVar9 = (int *)0x0;
    FUN_00020d6c(&piStack_30,param_1,0);
    piVar5 = piStack_30;
    if (piStack_30 != piStack_2c) {
      pcVar8 = *(char **)param_1;
      if ((pcVar8 == *(char **)((int)param_1 + 4)) || (*pcVar8 != 'E')) goto LAB_00024ab6;
      *(char **)param_1 = pcVar8 + 1;
      piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x14);
      piVar9[2] = iVar10;
      piVar9[3] = (int)piVar5;
      piVar9[4] = (int)piStack_2c;
      *piVar9 = (int)&PTR_LAB_00022116_1_00031960;
      piVar9[1] = 0x1010144;
    }
    goto switchD_0002459a_caseD_54;
  }
  piVar9 = (int *)0x0;
  switch(*pcVar16) {
  case 'A':
    iVar10 = FUN_00020e00(param_1);
    if (((iVar10 == 0) || (pcVar8 = *(char **)param_1, pcVar8 == *(char **)((int)param_1 + 4))) ||
       (*pcVar8 != 'E')) goto LAB_00024ab6;
    *(char **)param_1 = pcVar8 + 1;
    piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0xc);
    iVar20 = 0x1010142;
    puVar13 = &UNK_00031760;
LAB_0002472e:
    *piVar9 = (int)(puVar13 + 8);
    piVar9[1] = iVar20;
    piVar9[2] = iVar10;
    goto switchD_0002459a_caseD_54;
  default:
    goto switchD_0002459a_caseD_42;
  case 'D':
    iVar10 = FUN_0002079c(param_1,&DAT_000165aa,&DAT_000165ad);
    if (iVar10 != 0) {
      if (__stack_chk_guard != piStack_28) break;
      pcVar8 = "nullptr";
      goto LAB_00025220;
    }
    goto LAB_00024ab6;
  case 'T':
    goto switchD_0002459a_caseD_54;
  case 'U':
    if ((1 < (uint)((int)pcVar8 - (int)pcVar16)) && (pcVar15[2] == 'l')) {
      piVar9 = (int *)0x0;
      iVar10 = FUN_00025258(param_1,0);
      if (iVar10 == 0) goto switchD_0002459a_caseD_54;
      pcVar8 = *(char **)param_1;
      if ((pcVar8 != *(char **)((int)param_1 + 4)) && (*pcVar8 == 'E')) {
        *(char **)param_1 = pcVar8 + 1;
        piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0xc);
        iVar20 = 0x1010143;
        puVar13 = &UNK_00031920;
        goto LAB_0002472e;
      }
    }
    goto LAB_00024ab6;
  case '_':
    iVar10 = FUN_0002079c(param_1,&DAT_000168e5,&DAT_000168e7);
    if ((((iVar10 == 0) || (piVar9 = (int *)FUN_0002080c(param_1), piVar9 == (int *)0x0)) ||
        (pcVar8 = *(char **)param_1, pcVar8 == *(char **)((int)param_1 + 4))) || (*pcVar8 != 'E'))
    goto LAB_00024ab6;
    *(char **)param_1 = pcVar8 + 1;
    goto switchD_0002459a_caseD_54;
  case 'a':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard != piVar5) break;
    pcVar8 = "signed char";
    pcVar15 = "";
    goto LAB_000249d0;
  case 'b':
    iVar10 = FUN_0002079c(param_1,&DAT_000171aa,&DAT_000171ad);
    if (iVar10 == 0) {
      iVar10 = FUN_0002079c(param_1,&DAT_0001637c,&DAT_0001637f);
      if (iVar10 == 0) goto LAB_00024ab6;
      piStack_30 = (int *)0x1;
    }
    else {
      piStack_30 = (int *)0x0;
    }
    piVar9 = (int *)FUN_000251f0(param_1,&piStack_30);
    goto switchD_0002459a_caseD_54;
  case 'c':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "char";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 'd':
    pcVar16 = pcVar15 + 2;
    *(char **)param_1 = pcVar16;
    if (0x10 < (uint)((int)pcVar8 - (int)pcVar16)) {
      pcVar22 = pcVar15 + 0x12;
      iVar10 = 0;
      piVar9 = (int *)0x0;
LAB_000247e8:
      if (iVar10 != 0x10) goto code_r0x000247ee;
      *(char **)param_1 = pcVar22;
      if ((pcVar22 != pcVar8) && (*pcVar22 == 'E')) {
        *(char **)param_1 = pcVar15 + 0x13;
        piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        iVar10 = 0x1010147;
        puVar13 = &UNK_000316f0;
LAB_00024aa2:
        *piVar9 = (int)(puVar13 + 8);
        piVar9[1] = iVar10;
        piVar9[2] = (int)(pcVar15 + 2);
        piVar9[3] = (int)pcVar22;
        goto switchD_0002459a_caseD_54;
      }
    }
LAB_00024ab6:
    piVar9 = (int *)0x0;
    goto switchD_0002459a_caseD_54;
  case 'e':
    pcVar16 = pcVar15 + 2;
    *(char **)param_1 = pcVar16;
    if ((uint)((int)pcVar8 - (int)pcVar16) < 0x11) goto LAB_00024ab6;
    pcVar22 = pcVar15 + 0x12;
    iVar10 = 0;
    piVar9 = (int *)0x0;
    do {
      if (iVar10 == 0x10) {
        *(char **)param_1 = pcVar22;
        if ((pcVar22 == pcVar8) || (*pcVar22 != 'E')) goto LAB_00024ab6;
        *(char **)param_1 = pcVar15 + 0x13;
        piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        iVar10 = 0x1010148;
        puVar13 = &UNK_00031728;
        goto LAB_00024aa2;
      }
      iVar20 = FUN_00025594(pcVar16[iVar10]);
      iVar10 = iVar10 + 1;
    } while (iVar20 != 0);
    goto switchD_0002459a_caseD_54;
  case 'f':
    pcVar16 = pcVar15 + 2;
    *(char **)param_1 = pcVar16;
    if ((uint)((int)pcVar8 - (int)pcVar16) < 9) goto LAB_00024ab6;
    pcVar22 = pcVar15 + 10;
    iVar10 = 0;
    piVar9 = (int *)0x0;
    do {
      if (iVar10 == 8) {
        *(char **)param_1 = pcVar22;
        if ((pcVar22 == pcVar8) || (*pcVar22 != 'E')) goto LAB_00024ab6;
        *(char **)param_1 = pcVar15 + 0xb;
        piVar9 = (int *)FUN_000220a8(param_1 + 0x33,0x10);
        iVar10 = 0x1010146;
        puVar13 = &UNK_000316b8;
        goto LAB_00024aa2;
      }
      iVar20 = FUN_00025594(pcVar16[iVar10]);
      iVar10 = iVar10 + 1;
    } while (iVar20 != 0);
switchD_0002459a_caseD_54:
    if (__stack_chk_guard == piStack_28) {
      return piVar9;
    }
    break;
  case 'h':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "unsigned char";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 'i':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 'j':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard != piVar5) break;
    pcVar8 = "u";
    goto LAB_000248d8;
  case 'l':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard != piVar5) break;
    pcVar8 = "l";
LAB_000248d8:
    pcVar15 = pcVar8 + 1;
LAB_000249d0:
    local_24 = __stack_chk_guard;
    piStack_2c = unaff_r5;
    piStack_28 = unaff_r6;
    uVar24 = FUN_00020d6c(&piStack_2c,param_1,1);
    if (piStack_2c != piStack_28) {
      uVar24 = *param_1;
    }
    pcVar16 = (char *)uVar24;
    if ((piStack_2c == piStack_28 || pcVar16 == (char *)((ulonglong)uVar24 >> 0x20)) ||
       (*pcVar16 != 'E')) {
      piVar5 = (int *)0x0;
    }
    else {
      *(char **)param_1 = pcVar16 + 1;
      piVar5 = (int *)FUN_000220a8(param_1 + 0x33,0x18);
      piVar5[2] = (int)pcVar8;
      piVar5[3] = (int)pcVar15;
      piVar5[4] = (int)piStack_2c;
      piVar5[5] = (int)piStack_28;
      *piVar5 = (int)&PTR_LAB_00022116_1_00031650;
      piVar5[1] = 0x1010145;
    }
    if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(piVar5);
    }
    return piVar5;
  case 'm':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard != piVar5) break;
    pcVar8 = "ul";
    goto LAB_000249ae;
  case 'n':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "__int128";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 'o':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "unsigned __int128";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 's':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "short";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 't':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "unsigned short";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 'w':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "wchar_t";
      pcVar15 = "";
      goto LAB_000249d0;
    }
    break;
  case 'x':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard != piVar5) break;
    pcVar8 = "ll";
LAB_000249ae:
    pcVar15 = pcVar8 + 2;
    goto LAB_000249d0;
  case 'y':
    *(char **)param_1 = pcVar15 + 2;
    if (__stack_chk_guard == piVar5) {
      pcVar8 = "ull";
      pcVar15 = "";
      goto LAB_000249d0;
    }
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(piStack_28,__stack_chk_guard);
code_r0x000247ee:
  iVar20 = FUN_00025594(pcVar16[iVar10]);
  iVar10 = iVar10 + 1;
  if (iVar20 == 0) goto switchD_0002459a_caseD_54;
  goto LAB_000247e8;
switchD_00020e32_caseD_42:
  piStack_2c = (int *)FUN_00028320(param_1);
LAB_00021140:
  goto LAB_00021144;
}


// ==== FUN_00021ea4 @ 00021ea4

void FUN_00021ea4(undefined4 *param_1,undefined4 *param_2)

{
  void *pvVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *__ptr;
  int iVar4;
  
  puVar3 = (undefined4 *)param_1[1];
  if (puVar3 == (undefined4 *)param_1[2]) {
    __ptr = (undefined4 *)*param_1;
    iVar4 = (int)puVar3 - (int)__ptr;
    if (__ptr == param_1 + 3) {
      pvVar1 = malloc(iVar4 * 2);
      if (pvVar1 == (void *)0x0) goto LAB_00021f14;
      FUN_00025d38(__ptr,puVar3,pvVar1);
      *param_1 = pvVar1;
    }
    else {
      pvVar1 = realloc(__ptr,iVar4 * 2);
      *param_1 = pvVar1;
      if (pvVar1 == (void *)0x0) {
LAB_00021f14:
                    /* WARNING: Subroutine does not return */
        FUN_00020238();
      }
    }
    puVar3 = (undefined4 *)((int)pvVar1 + (iVar4 >> 2) * 4);
    param_1[1] = puVar3;
    param_1[2] = (void *)((int)pvVar1 + (iVar4 >> 1) * 4);
  }
  uVar2 = *param_2;
  param_1[1] = puVar3 + 1;
  *puVar3 = uVar2;
  return;
}


// ==== FUN_00021f18 @ 00021f18

void FUN_00021f18(undefined4 param_1,int param_2,int param_3)

{
  FUN_00026444(param_1,param_2,*(int *)(param_2 + 8) + param_3 * 4,*(undefined4 *)(param_2 + 0xc));
  *(int *)(param_2 + 0xc) = *(int *)(param_2 + 8) + param_3 * 4;
  return;
}


// ==== FUN_00021f38 @ 00021f38

void FUN_00021f38(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6,undefined1 *param_7)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x24);
  uVar5 = *param_2;
  uVar6 = *param_6;
  uVar4 = *param_4;
  uVar3 = param_4[1];
  *(undefined1 *)(puVar1 + 8) = *param_7;
  uVar2 = *param_5;
  puVar1[3] = *param_3;
  puVar1[4] = uVar4;
  puVar1[5] = uVar3;
  puVar1[6] = uVar2;
  *puVar1 = &PTR_LAB_00027df8_1_00032220;
  puVar1[1] = 0x10012;
  puVar1[2] = uVar5;
  puVar1[7] = uVar6;
  return;
}


// ==== FUN_00021f94 @ 00021f94

void FUN_00021f94(undefined4 *param_1)

{
  char *pcVar1;
  int local_24;
  int iStack_20;
  int local_1c;
  int iStack_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  pcVar1 = (char *)*param_1;
  if (pcVar1 == (char *)param_1[1]) goto LAB_00022026;
  if (*pcVar1 == 'h') {
    *param_1 = pcVar1 + 1;
    FUN_00020d6c(&local_1c,param_1,1);
  }
  else {
    if (*pcVar1 != 'v') goto LAB_00022026;
    *param_1 = pcVar1 + 1;
    FUN_00020d6c(&local_1c,param_1,1);
    if (((local_1c == iStack_18) || (pcVar1 = (char *)*param_1, pcVar1 == (char *)param_1[1])) ||
       (*pcVar1 != '_')) goto LAB_00022026;
    *param_1 = pcVar1 + 1;
    FUN_00020d6c(&local_24,param_1,1);
    local_1c = local_24;
    iStack_18 = iStack_20;
  }
  if (((local_1c != iStack_18) && (pcVar1 = (char *)*param_1, pcVar1 != (char *)param_1[1])) &&
     (*pcVar1 == '_')) {
    *param_1 = pcVar1 + 1;
  }
LAB_00022026:
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_14);
  }
  return;
}


// ==== FUN_00022048 @ 00022048

undefined4 FUN_00022048(undefined4 *param_1,int *param_2)

{
  byte *pbVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  bool bVar5;
  bool bVar6;
  
  pbVar1 = (byte *)*param_1;
  if (((byte *)param_1[1] != pbVar1) && (uVar2 = (uint)*pbVar1, 0x2f < uVar2)) {
    bVar6 = 0x39 < uVar2;
    bVar5 = uVar2 == 0x3a;
    if (bVar6) {
      uVar2 = uVar2 - 0x41;
      bVar5 = uVar2 == 0x19;
    }
    if ((!bVar6 || uVar2 < 0x19) || bVar5) {
      iVar3 = 0;
      while ((pbVar1 != (byte *)param_1[1] && (uVar2 = (uint)*pbVar1, 0x2f < uVar2))) {
        if (uVar2 < 0x3a) {
          iVar4 = -0x30;
        }
        else {
          if (0x19 < uVar2 - 0x41) break;
          iVar4 = -0x37;
        }
        pbVar1 = pbVar1 + 1;
        *param_1 = pbVar1;
        iVar3 = iVar4 + iVar3 * 0x24 + uVar2;
      }
      *param_2 = iVar3;
      return 0;
    }
  }
  return 1;
}


// ==== FUN_000220a8 @ 000220a8

undefined4 * FUN_000220a8(int param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  puVar3 = *(undefined4 **)(param_1 + 0x1000);
  uVar4 = param_2 + 0xfU & 0xfffffff0;
  iVar2 = puVar3[1];
  if (0xff7 < iVar2 + uVar4) {
    if (0xff8 < uVar4) {
      puVar1 = malloc(uVar4 | 8);
      if (puVar1 == (undefined4 *)0x0) goto LAB_00022112;
      *puVar1 = *puVar3;
      puVar1[1] = 0;
      *puVar3 = puVar1;
      goto LAB_0002210a;
    }
    puVar1 = malloc(0x1000);
    if (puVar1 == (undefined4 *)0x0) {
LAB_00022112:
                    /* WARNING: Subroutine does not return */
      FUN_00020238();
    }
    iVar2 = 0;
    *puVar1 = puVar3;
    puVar1[1] = 0;
    *(undefined4 **)(param_1 + 0x1000) = puVar1;
    puVar3 = puVar1;
  }
  puVar3[1] = iVar2 + uVar4;
  puVar1 = (undefined4 *)((int)puVar3 + iVar2);
LAB_0002210a:
  return puVar1 + 2;
}


// ==== FUN_00022124 @ 00022124

void FUN_00022124(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  FUN_00020684(*(undefined4 *)(param_1 + 0x10),param_2);
  return;
}


// ==== FUN_00022150 @ 00022150

void FUN_00022150(int *param_1,void *param_2,int param_3)

{
  size_t __n;
  
  __n = param_3 - (int)param_2;
  if (__n != 0) {
    FUN_00020772(param_1,__n);
    memmove((void *)(*param_1 + param_1[1]),param_2,__n);
    param_1[1] = param_1[1] + __n;
  }
  return;
}


// ==== FUN_00022180 @ 00022180

void FUN_00022180(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,"construction vtable for ","");
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_0001602a,&DAT_0001602e);
  FUN_00020684(*(undefined4 *)(param_1 + 0xc),param_2);
  return;
}


// ==== FUN_000221c4 @ 000221c4

void FUN_000221c4(undefined4 *param_1)

{
  byte *pbVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  byte *pbVar5;
  int local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  pbVar1 = (byte *)*param_1;
  if ((pbVar1 == (byte *)param_1[1]) || (*pbVar1 != 0x53)) goto LAB_0002224a;
  pbVar5 = pbVar1 + 1;
  *param_1 = pbVar5;
  if ((byte *)param_1[1] != pbVar5) {
    uVar4 = (uint)*pbVar5;
    if (0xffffffe5 < uVar4 - 0x7b) {
      switch(*pbVar5) {
      case 0x61:
        *param_1 = pbVar1 + 2;
        local_20 = 0;
        break;
      case 0x62:
        *param_1 = pbVar1 + 2;
        local_20 = 1;
        break;
      case 99:
      case 0x65:
      case 0x66:
      case 0x67:
      case 0x68:
        goto LAB_0002224a;
      case 100:
        *param_1 = pbVar1 + 2;
        local_20 = 5;
        break;
      case 0x69:
        *param_1 = pbVar1 + 2;
        local_20 = 3;
        break;
      default:
        if (uVar4 == 0x6f) {
          *param_1 = pbVar1 + 2;
          local_20 = 4;
        }
        else {
          if (uVar4 != 0x73) goto LAB_0002224a;
          *param_1 = pbVar1 + 2;
          local_20 = 2;
        }
      }
      iVar2 = FUN_00027b5c(param_1,&local_20);
      local_20 = FUN_000228b4(param_1,iVar2);
      if (local_20 != iVar2) {
        FUN_00021ea4(param_1 + 0x25,&local_20);
      }
      goto LAB_0002224a;
    }
    if (*pbVar5 == 0x5f) {
      *param_1 = pbVar1 + 2;
      goto LAB_0002224a;
    }
  }
  local_20 = 0;
  iVar2 = FUN_00022048(param_1,&local_20);
  if (((iVar2 == 0) && (pcVar3 = (char *)*param_1, pcVar3 != (char *)param_1[1])) &&
     (*pcVar3 == '_')) {
    *param_1 = pcVar3 + 1;
  }
LAB_0002224a:
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_1c);
  }
  return;
}


// ==== FUN_000222e8 @ 000222e8

void FUN_000222e8(undefined4 *param_1,int param_2)

{
  int *piVar1;
  char *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  int *piVar10;
  int iVar11;
  int iVar12;
  undefined4 *puVar13;
  int *piVar14;
  undefined8 in_d3;
  undefined8 in_d4;
  undefined8 in_d5;
  undefined8 in_d6;
  undefined4 in_s14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined8 local_60;
  undefined8 local_58;
  undefined8 local_50;
  undefined8 uStack_48;
  undefined4 uStack_40;
  int local_3c [5];
  int *piStack_28;
  
  piStack_28 = local_3c + 0xd;
  _uStack_40 = CONCAT44(__stack_chk_guard,in_s14);
  pcVar2 = (char *)*param_1;
  local_60 = in_d3;
  local_58 = in_d4;
  local_50 = in_d5;
  uStack_48 = in_d6;
  if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'I')) {
    *param_1 = pcVar2 + 1;
    if (param_2 != 0) {
      param_1[0x54] = param_1[0x53];
      local_58._4_4_ = (int)((ulonglong)in_d4 >> 0x20);
      local_58 = CONCAT44(local_58._4_4_,param_1 + 0x48);
      FUN_00022b02(param_1 + 0x53,&local_58);
      param_1[0x49] = param_1[0x48];
    }
    uVar15 = 0;
    uVar16 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
    uVar17 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
    uVar18 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
    piVar1 = param_1 + 2;
    iVar3 = *piVar1;
    puVar13 = param_1 + 0x56;
    iVar7 = param_1[3];
    puVar6 = (undefined4 *)((int)&local_50 + 4);
    while( true ) {
      while( true ) {
        pcVar2 = (char *)*param_1;
        if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == 'E')) {
          *param_1 = pcVar2 + 1;
          FUN_00021f18(&local_58,param_1,iVar7 - iVar3 >> 2);
          puVar6 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
          puVar6[1] = 0x1010123;
          *puVar6 = &PTR_LAB_00022116_1_00032108;
          puVar6[2] = (undefined4 *)local_58;
          puVar6[3] = local_58._4_4_;
          goto LAB_00022536;
        }
        if (param_2 != 0) break;
        iVar5 = FUN_00021d64(param_1);
        local_58 = CONCAT44(local_58._4_4_,iVar5);
        if (iVar5 == 0) goto LAB_00022534;
        FUN_00021ea4(piVar1,&local_58);
      }
      puVar4 = (undefined4 *)param_1[0x53];
      local_50 = CONCAT44(uVar15,local_3c);
      uStack_48 = CONCAT44(uVar17,uVar16);
      _uStack_40 = CONCAT44(local_3c[0],uVar18);
      local_58 = CONCAT44(puVar6,puVar6);
      if (puVar4 == puVar13) {
        FUN_00022cd6(puVar13,param_1[0x54],puVar6);
        iVar5 = param_1[0x54];
        param_1[0x54] = param_1[0x53];
        local_58._4_4_ = (iVar5 - param_1[0x53]) + (int)(undefined4 *)local_58;
      }
      else {
        local_58._4_4_ = param_1[0x54];
        uVar8 = param_1[0x55];
        param_1[0x53] = puVar13;
        param_1[0x54] = puVar13;
        param_1[0x55] = param_1 + 0x5a;
        local_50 = CONCAT44(uVar15,uVar8);
        local_58._0_4_ = puVar4;
      }
      iVar5 = FUN_00021d64(param_1);
      local_60 = CONCAT44(iVar5,(undefined4)local_60);
      puVar4 = (undefined4 *)param_1[0x53];
      if ((undefined4 *)local_58 == puVar6) {
        puVar9 = puVar6;
        if (puVar4 != puVar13) {
          free(puVar4);
          param_1[0x53] = puVar13;
          param_1[0x54] = puVar13;
          param_1[0x55] = param_1 + 0x5a;
          puVar9 = (undefined4 *)local_58;
        }
        FUN_00022cd6(puVar9,local_58._4_4_,puVar13);
        iVar11 = local_58._4_4_ - (int)(undefined4 *)local_58;
        local_58 = CONCAT44((undefined4 *)local_58,(undefined4 *)local_58);
        param_1[0x54] = param_1[0x53] + iVar11;
      }
      else {
        param_1[0x53] = (undefined4 *)local_58;
        if (puVar4 == puVar13) {
          param_1[0x54] = local_58._4_4_;
          param_1[0x55] = (undefined4)local_50;
          local_50 = CONCAT44(local_50._4_4_,local_3c);
          local_58 = CONCAT44(puVar6,puVar6);
        }
        else {
          param_1[0x54] = local_58._4_4_;
          uVar8 = param_1[0x55];
          param_1[0x55] = (undefined4)local_50;
          local_58 = CONCAT44(puVar4,puVar4);
          local_50 = CONCAT44(local_50._4_4_,uVar8);
        }
      }
      if (iVar5 == 0) break;
      FUN_00021ea4(piVar1,(int)&local_60 + 4);
      local_60 = CONCAT44(local_60._4_4_,iVar5);
      if (*(char *)(iVar5 + 4) == '!') {
        piVar14 = *(int **)(iVar5 + 8);
        iVar11 = *(int *)(iVar5 + 0xc);
        puVar4 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
        puVar4[2] = piVar14;
        puVar4[3] = iVar11;
        *(undefined1 *)(puVar4 + 1) = 0x20;
        *puVar4 = &PTR_LAB_00027c14_1_000320d0;
        *(undefined1 *)((int)puVar4 + 7) = 2;
        *(undefined2 *)((int)puVar4 + 5) = 0x202;
        iVar11 = iVar11 << 2;
        iVar5 = iVar11;
        piVar10 = piVar14;
        do {
          if (iVar5 == 0) {
            *(undefined1 *)((int)puVar4 + 6) = 1;
            break;
          }
          iVar12 = *piVar10;
          piVar10 = piVar10 + 1;
          iVar5 = iVar5 + -4;
        } while (*(char *)(iVar12 + 6) == '\x01');
        iVar5 = iVar11;
        piVar10 = piVar14;
        do {
          if (iVar5 == 0) {
            *(undefined1 *)((int)puVar4 + 7) = 1;
            break;
          }
          iVar12 = *piVar10;
          piVar10 = piVar10 + 1;
          iVar5 = iVar5 + -4;
        } while (*(char *)(iVar12 + 7) == '\x01');
        do {
          if (iVar11 == 0) {
            *(undefined1 *)((int)puVar4 + 5) = 1;
            break;
          }
          iVar5 = *piVar14;
          iVar11 = iVar11 + -4;
          piVar14 = piVar14 + 1;
        } while (*(char *)(iVar5 + 5) == '\x01');
        local_60 = CONCAT44(local_60._4_4_,puVar4);
      }
      FUN_00025be4(*(undefined4 *)(param_1[0x54] + -4),&local_60);
      FUN_0002072a(&local_58);
    }
    FUN_0002072a(&local_58);
  }
LAB_00022534:
  puVar6 = (undefined4 *)0x0;
LAB_00022536:
  if (__stack_chk_guard != local_3c[0]) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar6);
  }
  return;
}


// ==== FUN_00022574 @ 00022574

void FUN_00022574(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  puVar1[1] = 0x1010125;
  uVar3 = *param_2;
  *puVar1 = &PTR_LAB_00022116_1_00032140;
  uVar2 = *param_3;
  puVar1[2] = uVar3;
  puVar1[3] = uVar2;
  return;
}


// ==== FUN_000225a4 @ 000225a4

uint FUN_000225a4(undefined4 *param_1)

{
  uint uVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)*param_1;
  pcVar3 = (char *)param_1[1];
  if ((pcVar2 == pcVar3) || (*pcVar2 != 'r')) {
    uVar1 = 0;
  }
  else {
    pcVar2 = pcVar2 + 1;
    uVar1 = 4;
    *param_1 = pcVar2;
  }
  if (pcVar2 != pcVar3) {
    if (*pcVar2 == 'V') {
      pcVar2 = pcVar2 + 1;
      *param_1 = pcVar2;
      uVar1 = uVar1 | 2;
    }
    if ((pcVar2 != pcVar3) && (*pcVar2 == 'K')) {
      *param_1 = pcVar2 + 1;
      uVar1 = uVar1 | 1;
    }
  }
  return uVar1;
}


// ==== FUN_000225e8 @ 000225e8

undefined4 * FUN_000225e8(int param_1,char *param_2)

{
  undefined4 *puVar1;
  size_t sVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  sVar2 = strlen(param_2);
  puVar1[2] = param_2;
  puVar1[3] = param_2 + sVar2;
  *puVar1 = &PTR_LAB_00022116_1_000315a8;
  puVar1[1] = 0x1010107;
  return puVar1;
}


// ==== FUN_00022620 @ 00022620

bool FUN_00022620(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  
  if (param_2 == 0) {
    return false;
  }
  piVar2 = (int *)*param_1;
  if (*piVar2 == 0) {
    *piVar2 = param_2;
  }
  else {
    puVar1 = (undefined4 *)FUN_000220a8(param_1[1] + 0x198,0x10);
    puVar1[2] = *piVar2;
    puVar1[3] = param_2;
    *puVar1 = &PTR_LAB_00022116_1_000315e0;
    puVar1[1] = 0x1010117;
    *(undefined4 **)*param_1 = puVar1;
  }
  if (*(int *)param_1[2] != 0) {
    *(undefined1 *)(*(int *)param_1[2] + 1) = 0;
  }
  return *(int *)*param_1 != 0;
}


// ==== FUN_00022680 @ 00022680

void FUN_00022680(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *__dest;
  char *pcVar7;
  char *pcVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  size_t __n;
  undefined4 *__src;
  undefined1 auStack_b0 [128];
  undefined1 auStack_22 [2];
  
  iVar2 = __stack_chk_guard;
  pcVar8 = (char *)*param_1;
  pcVar7 = (char *)param_1[1];
  if ((pcVar8 == pcVar7) || (*pcVar8 != 'T')) goto LAB_000227a2;
  pcVar3 = pcVar8 + 1;
  *param_1 = pcVar3;
  if (pcVar3 == pcVar7) {
    uVar10 = 0;
LAB_000226f4:
    iVar4 = FUN_00022aae(param_1,auStack_b0 + 0x84);
    if (iVar4 != 0) goto LAB_000227a2;
    uVar11 = 1;
    pcVar3 = (char *)*param_1;
    if ((pcVar3 == (char *)param_1[1]) || (*pcVar3 != '_')) goto LAB_000227a2;
  }
  else {
    uVar10 = 0;
    if (*pcVar3 == 'L') {
      *param_1 = pcVar8 + 2;
      iVar4 = FUN_00022aae(param_1,auStack_22 + -6);
      if (iVar4 != 0) goto LAB_000227a2;
      pcVar3 = (char *)*param_1;
      pcVar7 = (char *)param_1[1];
      if ((pcVar3 == pcVar7) || (*pcVar3 != '_')) goto LAB_000227a2;
      pcVar3 = pcVar3 + 1;
      *param_1 = pcVar3;
      uVar10 = 1;
    }
    if ((pcVar3 == pcVar7) || (*pcVar3 != '_')) goto LAB_000226f4;
    uVar11 = 0;
  }
  *param_1 = pcVar3 + 1;
  if ((*(char *)((int)param_1 + 0x185) == '\0') || (uVar10 != 0)) {
    uVar1 = (int)(param_1[0x54] - param_1[0x53]) >> 2;
    if ((((uVar1 <= uVar10) ||
         (piVar9 = *(int **)(param_1[0x53] + uVar10 * 4), piVar9 == (int *)0x0)) ||
        ((uint)(piVar9[1] - *piVar9 >> 2) <= uVar11)) &&
       ((param_1[0x62] == uVar10 && (uVar10 <= uVar1)))) {
      if (uVar10 == uVar1) {
        FUN_00022b02(param_1 + 0x53,auStack_b0 + 0x80);
      }
      FUN_00022b78(param_1,&DAT_00016375);
    }
  }
  else {
    puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
    *(undefined1 *)(puVar5 + 4) = 0;
    puVar5[2] = uVar11;
    puVar5[3] = 0;
    *puVar5 = &PTR_FUN_00022bb0_1_00031618;
    puVar5[1] = 0x2020224;
    puVar6 = (undefined4 *)param_1[0x5b];
    if (puVar6 == (undefined4 *)param_1[0x5c]) {
      __src = (undefined4 *)param_1[0x5a];
      __n = (int)puVar6 - (int)__src;
      if (__src == param_1 + 0x5d) {
        __dest = malloc(__n * 2);
        if (__dest == (void *)0x0) goto LAB_0002281a;
        if (__n != 0) {
          memmove(__dest,__src,__n);
        }
        param_1[0x5a] = __dest;
      }
      else {
        __dest = realloc(__src,__n * 2);
        param_1[0x5a] = __dest;
        if (__dest == (void *)0x0) {
LAB_0002281a:
                    /* WARNING: Subroutine does not return */
          FUN_00020238();
        }
      }
      param_1[0x5c] = (void *)((int)__dest + ((int)__n >> 1) * 4);
      puVar6 = (undefined4 *)((int)__dest + ((int)__n >> 2) * 4);
    }
    param_1[0x5b] = puVar6 + 1;
    *puVar6 = puVar5;
  }
LAB_000227a2:
  if (__stack_chk_guard != iVar2) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar2);
  }
  return;
}


// ==== FUN_00022834 @ 00022834

void FUN_00022834(undefined4 *param_1,undefined4 param_2,int param_3)

{
  byte *pbVar1;
  char *pcVar2;
  undefined4 uVar3;
  byte *pbVar4;
  int local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  pbVar1 = (byte *)*param_1;
  local_18 = param_3;
  if ((pbVar1 != (byte *)param_1[1]) && (*pbVar1 == 0x44)) {
    pbVar4 = pbVar1 + 1;
    *param_1 = pbVar4;
    if ((pbVar4 != (byte *)param_1[1]) && ((*pbVar4 | 0x20) == 0x74)) {
      *param_1 = pbVar1 + 2;
      local_18 = FUN_00022cf0(param_1);
      if (((local_18 != 0) && (pcVar2 = (char *)*param_1, pcVar2 != (char *)param_1[1])) &&
         (*pcVar2 == 'E')) {
        *param_1 = pcVar2 + 1;
        uVar3 = FUN_00024504(param_1,"decltype(",&local_18);
        goto LAB_00022894;
      }
    }
  }
  uVar3 = 0;
LAB_00022894:
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar3);
  }
  return;
}


// ==== FUN_000228b4 @ 000228b4

void FUN_000228b4(undefined4 *param_1,undefined4 *param_2)

{
  undefined1 uVar1;
  undefined2 uVar2;
  int iVar3;
  char *pcVar4;
  undefined4 *puVar5;
  int unaff_r5;
  int unaff_r6;
  undefined1 auStack_b0 [128];
  
  iVar3 = __stack_chk_guard;
  while ((pcVar4 = (char *)*param_1, pcVar4 != (char *)param_1[1] && (*pcVar4 == 'B'))) {
    *param_1 = pcVar4 + 1;
    FUN_000279b8(auStack_b0 + 0x80,param_1);
    if (unaff_r5 == unaff_r6) break;
    puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
    puVar5[2] = param_2;
    *(undefined1 *)(puVar5 + 1) = 8;
    *puVar5 = &PTR_LAB_00022116_1_00031ff0;
    uVar2 = *(undefined2 *)((int)param_2 + 6);
    uVar1 = *(undefined1 *)((int)param_2 + 5);
    puVar5[3] = unaff_r5;
    puVar5[4] = unaff_r6;
    *(undefined1 *)((int)puVar5 + 5) = uVar1;
    *(undefined2 *)((int)puVar5 + 6) = uVar2;
    param_2 = puVar5;
  }
  if (__stack_chk_guard != iVar3) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar3,__stack_chk_guard);
  }
  return;
}


// ==== FUN_00022944 @ 00022944

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00022944(undefined4 *param_1,undefined4 param_2)

{
  undefined1 uVar1;
  undefined2 uVar2;
  int iVar3;
  char *pcVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  int unaff_r5;
  int unaff_r6;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int local_24;
  undefined4 in_stack_ffffffe0;
  
  iVar3 = __stack_chk_guard;
  if ((byte *)param_1[1] == (byte *)*param_1) {
LAB_00022982:
    iVar8 = FUN_0002079c(param_1,&DAT_00016cc8,&DAT_00016cca);
    if (iVar8 == 0) {
      puVar7 = (undefined4 *)FUN_000268a8(param_1,param_2);
      goto LAB_000229f8;
    }
    iVar8 = param_1[2];
    iVar9 = param_1[3];
    do {
      local_24 = FUN_00026790(param_1);
      if (local_24 == 0) goto LAB_00022a1e;
      FUN_00021ea4(param_1 + 2,&local_24);
      pcVar4 = (char *)*param_1;
    } while ((pcVar4 == (char *)param_1[1]) || (*pcVar4 != 'E'));
    *param_1 = pcVar4 + 1;
    FUN_00021f18(&local_24,param_1,iVar9 - iVar8 >> 2);
    puVar7 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
    puVar7[2] = local_24;
    puVar7[3] = in_stack_ffffffe0;
    *puVar7 = &PTR_LAB_00022116_1_00032028;
    puVar7[1] = 0x101012e;
  }
  else {
    uVar6 = (uint)*(byte *)*param_1;
    if (uVar6 == 0x55) {
      puVar7 = (undefined4 *)FUN_00025258(param_1,param_2);
    }
    else {
      if (8 < uVar6 - 0x31) goto LAB_00022982;
      puVar7 = (undefined4 *)FUN_00026790(param_1);
    }
LAB_000229f8:
    if (puVar7 == (undefined4 *)0x0) {
LAB_00022a1e:
      if (__stack_chk_guard == iVar3) {
        return;
      }
      goto LAB_00022a36;
    }
  }
  if (__stack_chk_guard == iVar3) {
    iStack_28 = __stack_chk_guard;
    iStack_30 = unaff_r5;
    iStack_2c = unaff_r6;
    while ((pcVar4 = (char *)*param_1, pcVar4 != (char *)param_1[1] && (*pcVar4 == 'B'))) {
      *param_1 = pcVar4 + 1;
      FUN_000279b8(&iStack_30,param_1);
      iVar8 = iStack_2c;
      iVar3 = iStack_30;
      if (iStack_30 == iStack_2c) break;
      puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
      puVar5[2] = puVar7;
      *(undefined1 *)(puVar5 + 1) = 8;
      *puVar5 = &PTR_LAB_00022116_1_00031ff0;
      uVar2 = *(undefined2 *)((int)puVar7 + 6);
      uVar1 = *(undefined1 *)((int)puVar7 + 5);
      puVar5[3] = iVar3;
      puVar5[4] = iVar8;
      *(undefined1 *)((int)puVar5 + 5) = uVar1;
      *(undefined2 *)((int)puVar5 + 6) = uVar2;
      puVar7 = puVar5;
    }
    if (__stack_chk_guard != iStack_28) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(iStack_28,__stack_chk_guard);
    }
    return;
  }
LAB_00022a36:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(iVar3);
}


// ==== FUN_00022a9c @ 00022a9c

void FUN_00022a9c(undefined4 param_1,int param_2)

{
  (**(code **)(**(int **)(param_2 + 0xc) + 0x18))();
  return;
}


// ==== FUN_00022aae @ 00022aae

undefined4 FUN_00022aae(undefined4 *param_1,int *param_2)

{
  undefined4 uVar1;
  byte *pbVar2;
  byte *pbVar3;
  int iVar4;
  
  *param_2 = 0;
  pbVar3 = (byte *)*param_1;
  pbVar2 = (byte *)param_1[1];
  if (((pbVar2 == pbVar3) || (*pbVar3 < 0x30)) || (0x39 < *pbVar3)) {
    uVar1 = 1;
  }
  else {
    iVar4 = 0;
    while ((pbVar3 != pbVar2 && (*pbVar3 - 0x30 < 10))) {
      *param_1 = pbVar3 + 1;
      *param_2 = iVar4 * 10;
      iVar4 = (uint)*pbVar3 + iVar4 * 10 + -0x30;
      *param_2 = iVar4;
      pbVar3 = pbVar3 + 1;
    }
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_00022b02 @ 00022b02

void FUN_00022b02(undefined4 *param_1,undefined4 *param_2)

{
  void *pvVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *__ptr;
  int iVar4;
  
  puVar3 = (undefined4 *)param_1[1];
  if (puVar3 == (undefined4 *)param_1[2]) {
    __ptr = (undefined4 *)*param_1;
    iVar4 = (int)puVar3 - (int)__ptr;
    if (__ptr == param_1 + 3) {
      pvVar1 = malloc(iVar4 * 2);
      if (pvVar1 == (void *)0x0) goto LAB_00022b72;
      FUN_00022cd6(__ptr,puVar3,pvVar1);
      *param_1 = pvVar1;
    }
    else {
      pvVar1 = realloc(__ptr,iVar4 * 2);
      *param_1 = pvVar1;
      if (pvVar1 == (void *)0x0) {
LAB_00022b72:
                    /* WARNING: Subroutine does not return */
        FUN_00020238();
      }
    }
    puVar3 = (undefined4 *)((int)pvVar1 + (iVar4 >> 2) * 4);
    param_1[1] = puVar3;
    param_1[2] = (void *)((int)pvVar1 + (iVar4 >> 1) * 4);
  }
  uVar2 = *param_2;
  param_1[1] = puVar3 + 1;
  *puVar3 = uVar2;
  return;
}


// ==== FUN_00022b78 @ 00022b78

undefined4 * FUN_00022b78(int param_1,char *param_2)

{
  undefined4 *puVar1;
  size_t sVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  sVar2 = strlen(param_2);
  puVar1[2] = param_2;
  puVar1[3] = param_2 + sVar2;
  *puVar1 = &PTR_LAB_00022116_1_000315a8;
  puVar1[1] = 0x1010107;
  return puVar1;
}


// ==== FUN_00022bb0 @ 00022bb0

undefined4 FUN_00022bb0(int param_1)

{
  undefined4 uVar1;
  
  if (*(char *)(param_1 + 0x10) == '\0') {
    *(undefined1 *)(param_1 + 0x10) = 1;
    uVar1 = FUN_00022c9a(*(undefined4 *)(param_1 + 0xc));
    *(undefined1 *)(param_1 + 0x10) = 0;
    return uVar1;
  }
  return 0;
}


// ==== FUN_00022c9a @ 00022c9a

void FUN_00022c9a(undefined4 *param_1)

{
  if (*(char *)((int)param_1 + 5) == '\x02') {
                    /* WARNING: Could not recover jumptable at 0x00022cac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*param_1)();
    return;
  }
  return;
}


// ==== FUN_00022cae @ 00022cae

void FUN_00022cae(int *param_1)

{
  if (*(char *)((int)param_1 + 6) == '\x02') {
                    /* WARNING: Could not recover jumptable at 0x00022cc0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 4))();
    return;
  }
  return;
}


// ==== FUN_00022cc2 @ 00022cc2

void FUN_00022cc2(int *param_1)

{
  if (*(char *)((int)param_1 + 7) == '\x02') {
                    /* WARNING: Could not recover jumptable at 0x00022cd4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 8))();
    return;
  }
  return;
}


// ==== FUN_00022cd6 @ 00022cd6

void FUN_00022cd6(void *param_1,int param_2,void *param_3)

{
  if (param_2 - (int)param_1 == 0) {
    return;
  }
  memmove(param_3,param_1,param_2 - (int)param_1);
  return;
}


// ==== FUN_00022cdc @ 00022cdc

void FUN_00022cdc(void *param_1,undefined4 param_2,void *param_3,size_t param_4)

{
  memmove(param_3,param_1,param_4);
  return;
}


// ==== FUN_00022cf0 @ 00022cf0

/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 * FUN_00022cf0(byte *param_1)

{
  uint uVar1;
  byte *pbVar2;
  byte bVar3;
  bool bVar4;
  char *pcVar5;
  undefined4 *puVar6;
  void *__dest;
  byte *pbVar7;
  int iVar8;
  int iVar9;
  char *pcVar10;
  int iVar11;
  int iVar12;
  byte *pbVar13;
  undefined4 uVar14;
  int *piVar15;
  byte *pbVar16;
  char *pcVar17;
  byte *pbVar18;
  undefined *puVar19;
  undefined *puVar20;
  uint uVar21;
  int unaff_r5;
  undefined4 *puVar22;
  uint uVar23;
  int unaff_r6;
  size_t sVar24;
  byte *pbVar25;
  char *pcVar26;
  byte *pbVar27;
  undefined8 uVar28;
  undefined *local_4c;
  undefined *local_48;
  undefined *local_44;
  undefined1 uStack_39;
  int local_38;
  undefined4 local_34;
  
  pbVar25 = __stack_chk_guard;
  uStack_39 = FUN_0002079c(param_1,&DAT_0001602f,&DAT_00016031);
  pbVar18 = __stack_chk_guard;
  pbVar27 = *(byte **)param_1;
  pbVar13 = *(byte **)(param_1 + 4);
  pbVar16 = pbVar13 + -(int)pbVar27;
  if (pbVar16 < (byte *)0x2) goto LAB_00022d28;
  pbVar7 = param_1;
  switch((uint)*pbVar27) {
  case 0x4c:
    if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
    pcVar17 = *(char **)param_1;
    pcVar10 = *(char **)(param_1 + 4);
    if ((pcVar17 == pcVar10) || (*pcVar17 != 'L')) goto LAB_00024ab6;
    pcVar5 = pcVar17 + 1;
    *(char **)param_1 = pcVar5;
    if (pcVar10 == pcVar5) {
switchD_0002459a_caseD_42:
      iVar9 = FUN_00020e00(param_1);
      if (iVar9 == 0) goto LAB_00024ab6;
      puVar22 = (undefined4 *)0x0;
      FUN_00020d6c((int)register0x00000054 + -0x30,param_1,0);
      if (unaff_r5 != unaff_r6) {
        pcVar10 = *(char **)param_1;
        if ((pcVar10 == *(char **)(param_1 + 4)) || (*pcVar10 != 'E')) goto LAB_00024ab6;
        *(char **)param_1 = pcVar10 + 1;
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
        puVar22[2] = iVar9;
        puVar22[3] = unaff_r5;
        puVar22[4] = unaff_r6;
        *puVar22 = &PTR_LAB_00022116_1_00031960;
        puVar22[1] = 0x1010144;
      }
      goto switchD_0002459a_caseD_54;
    }
    puVar22 = (undefined4 *)0x0;
    switch(*pcVar5) {
    case 'A':
      iVar9 = FUN_00020e00(param_1);
      if (((iVar9 == 0) || (pcVar10 = *(char **)param_1, pcVar10 == *(char **)(param_1 + 4))) ||
         (*pcVar10 != 'E')) goto LAB_00024ab6;
      *(char **)param_1 = pcVar10 + 1;
      puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
      uVar14 = 0x1010142;
      puVar20 = &UNK_00031760;
LAB_0002472e:
      *puVar22 = puVar20 + 8;
      puVar22[1] = uVar14;
      puVar22[2] = iVar9;
      goto switchD_0002459a_caseD_54;
    default:
      goto switchD_0002459a_caseD_42;
    case 'D':
      iVar9 = FUN_0002079c(param_1,&DAT_000165aa,&DAT_000165ad);
      if (iVar9 != 0) {
        if (__stack_chk_guard == pbVar18) {
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          sVar24 = strlen("nullptr");
          puVar22[2] = "nullptr";
          puVar22[3] = "nullptr" + sVar24;
          *puVar22 = &PTR_LAB_00022116_1_000315a8;
          puVar22[1] = 0x1010107;
          return puVar22;
        }
        break;
      }
      goto LAB_00024ab6;
    case 'T':
      goto switchD_0002459a_caseD_54;
    case 'U':
      if ((1 < (uint)((int)pcVar10 - (int)pcVar5)) && (pcVar17[2] == 'l')) {
        puVar22 = (undefined4 *)0x0;
        iVar9 = FUN_00025258(param_1,0);
        if (iVar9 == 0) goto switchD_0002459a_caseD_54;
        pcVar10 = *(char **)param_1;
        if ((pcVar10 != *(char **)(param_1 + 4)) && (*pcVar10 == 'E')) {
          *(char **)param_1 = pcVar10 + 1;
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
          uVar14 = 0x1010143;
          puVar20 = &UNK_00031920;
          goto LAB_0002472e;
        }
      }
      goto LAB_00024ab6;
    case '_':
      iVar9 = FUN_0002079c(param_1,&DAT_000168e5,&DAT_000168e7);
      if ((((iVar9 == 0) ||
           (puVar22 = (undefined4 *)FUN_0002080c(param_1), puVar22 == (undefined4 *)0x0)) ||
          (pcVar10 = *(char **)param_1, pcVar10 == *(char **)(param_1 + 4))) || (*pcVar10 != 'E'))
      goto LAB_00024ab6;
      *(char **)param_1 = pcVar10 + 1;
      goto switchD_0002459a_caseD_54;
    case 'a':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard != pbVar18) break;
      pcVar10 = "signed char";
      pcVar17 = "";
      goto LAB_000249d0;
    case 'b':
      iVar9 = FUN_0002079c(param_1,&DAT_000171aa,&DAT_000171ad);
      if ((iVar9 == 0) && (iVar9 = FUN_0002079c(param_1,&DAT_0001637c,&DAT_0001637f), iVar9 == 0))
      goto LAB_00024ab6;
      puVar22 = (undefined4 *)FUN_000251f0(param_1,(int)register0x00000054 + -0x30);
      goto switchD_0002459a_caseD_54;
    case 'c':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "char";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 'd':
      pcVar5 = pcVar17 + 2;
      *(char **)param_1 = pcVar5;
      if (0x10 < (uint)((int)pcVar10 - (int)pcVar5)) {
        pcVar26 = pcVar17 + 0x12;
        iVar9 = 0;
        puVar22 = (undefined4 *)0x0;
LAB_000247e8:
        if (iVar9 != 0x10) goto code_r0x000247ee;
        *(char **)param_1 = pcVar26;
        if ((pcVar26 != pcVar10) && (*pcVar26 == 'E')) {
          *(char **)param_1 = pcVar17 + 0x13;
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          uVar14 = 0x1010147;
          puVar20 = &UNK_000316f0;
LAB_00024aa2:
          *puVar22 = puVar20 + 8;
          puVar22[1] = uVar14;
          puVar22[2] = pcVar17 + 2;
          puVar22[3] = pcVar26;
          goto switchD_0002459a_caseD_54;
        }
      }
LAB_00024ab6:
      puVar22 = (undefined4 *)0x0;
      goto switchD_0002459a_caseD_54;
    case 'e':
      pcVar5 = pcVar17 + 2;
      *(char **)param_1 = pcVar5;
      if ((uint)((int)pcVar10 - (int)pcVar5) < 0x11) goto LAB_00024ab6;
      pcVar26 = pcVar17 + 0x12;
      iVar9 = 0;
      puVar22 = (undefined4 *)0x0;
      do {
        if (iVar9 == 0x10) {
          *(char **)param_1 = pcVar26;
          if ((pcVar26 == pcVar10) || (*pcVar26 != 'E')) goto LAB_00024ab6;
          *(char **)param_1 = pcVar17 + 0x13;
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          uVar14 = 0x1010148;
          puVar20 = &UNK_00031728;
          goto LAB_00024aa2;
        }
        iVar11 = FUN_00025594(pcVar5[iVar9]);
        iVar9 = iVar9 + 1;
      } while (iVar11 != 0);
      goto switchD_0002459a_caseD_54;
    case 'f':
      pcVar5 = pcVar17 + 2;
      *(char **)param_1 = pcVar5;
      if ((uint)((int)pcVar10 - (int)pcVar5) < 9) goto LAB_00024ab6;
      pcVar26 = pcVar17 + 10;
      iVar9 = 0;
      puVar22 = (undefined4 *)0x0;
      do {
        if (iVar9 == 8) {
          *(char **)param_1 = pcVar26;
          if ((pcVar26 == pcVar10) || (*pcVar26 != 'E')) goto LAB_00024ab6;
          *(char **)param_1 = pcVar17 + 0xb;
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          uVar14 = 0x1010146;
          puVar20 = &UNK_000316b8;
          goto LAB_00024aa2;
        }
        iVar11 = FUN_00025594(pcVar5[iVar9]);
        iVar9 = iVar9 + 1;
      } while (iVar11 != 0);
switchD_0002459a_caseD_54:
      if (__stack_chk_guard == pbVar18) {
        return puVar22;
      }
      break;
    case 'h':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "unsigned char";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 'i':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 'j':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard != pbVar18) break;
      pcVar10 = "u";
      goto LAB_000248d8;
    case 'l':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard != pbVar18) break;
      pcVar10 = "l";
LAB_000248d8:
      pcVar17 = pcVar10 + 1;
LAB_000249d0:
      pbVar25 = __stack_chk_guard;
      uVar28 = FUN_00020d6c((int)register0x00000054 + -0x2c,param_1,1);
      if (unaff_r5 != unaff_r6) {
        uVar28 = *(undefined8 *)param_1;
      }
      pcVar5 = (char *)uVar28;
      if ((unaff_r5 == unaff_r6 || pcVar5 == (char *)((ulonglong)uVar28 >> 0x20)) ||
         (*pcVar5 != 'E')) {
        puVar22 = (undefined4 *)0x0;
      }
      else {
        *(char **)param_1 = pcVar5 + 1;
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
        puVar22[2] = pcVar10;
        puVar22[3] = pcVar17;
        puVar22[4] = unaff_r5;
        puVar22[5] = unaff_r6;
        *puVar22 = &PTR_LAB_00022116_1_00031650;
        puVar22[1] = 0x1010145;
      }
      if (__stack_chk_guard != pbVar25) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail(puVar22);
      }
      return puVar22;
    case 'm':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard != pbVar18) break;
      pcVar10 = "ul";
      goto LAB_000249ae;
    case 'n':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "__int128";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 'o':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "unsigned __int128";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 's':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "short";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 't':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "unsigned short";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 'w':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "wchar_t";
        pcVar17 = "";
        goto LAB_000249d0;
      }
      break;
    case 'x':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard != pbVar18) break;
      pcVar10 = "ll";
LAB_000249ae:
      pcVar17 = pcVar10 + 2;
      goto LAB_000249d0;
    case 'y':
      *(char **)param_1 = pcVar17 + 2;
      if (__stack_chk_guard == pbVar18) {
        pcVar10 = "ull";
        pcVar17 = "";
        goto LAB_000249d0;
      }
    }
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(pbVar18,__stack_chk_guard);
  case 0x4d:
  case 0x4e:
  case 0x4f:
  case 0x50:
  case 0x51:
  case 0x52:
  case 0x53:
  case 0x55:
  case 0x56:
  case 0x57:
  case 0x58:
  case 0x59:
  case 0x5a:
  case 0x5b:
  case 0x5c:
  case 0x5d:
  case 0x5e:
  case 0x5f:
  case 0x60:
  case 0x62:
  case 0x68:
  case 0x6a:
  case 0x6b:
    goto switchD_00022d78_caseD_1;
  case 0x54:
    if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
    pcVar17 = *(char **)param_1;
    pcVar10 = *(char **)(param_1 + 4);
    if (pcVar17 == pcVar10) goto LAB_000227a0;
    puVar22 = (undefined4 *)0x0;
    if (*pcVar17 != 'T') goto LAB_000227a2;
    pcVar5 = pcVar17 + 1;
    *(char **)param_1 = pcVar5;
    if (pcVar5 == pcVar10) {
      uVar21 = 0;
LAB_000226f4:
      iVar9 = FUN_00022aae(param_1,(int)register0x00000054 + -0x2c);
      if (iVar9 == 0) {
        uVar23 = 1;
        pcVar5 = *(char **)param_1;
        if ((pcVar5 != *(char **)(param_1 + 4)) && (*pcVar5 == '_')) goto LAB_00022714;
      }
    }
    else {
      uVar21 = 0;
      if (*pcVar5 == 'L') {
        *(char **)param_1 = pcVar17 + 2;
        iVar9 = FUN_00022aae(param_1,(int)register0x00000054 + -0x28);
        if (iVar9 == 0) {
          pcVar5 = *(char **)param_1;
          pcVar10 = *(char **)(param_1 + 4);
          if ((pcVar5 != pcVar10) && (*pcVar5 == '_')) {
            pcVar5 = pcVar5 + 1;
            *(char **)param_1 = pcVar5;
            uVar21 = 1;
            goto LAB_000226e0;
          }
        }
      }
      else {
LAB_000226e0:
        if ((pcVar5 == pcVar10) || (*pcVar5 != '_')) goto LAB_000226f4;
        uVar23 = 0;
LAB_00022714:
        *(char **)param_1 = pcVar5 + 1;
        if ((param_1[0x185] != 0) && (uVar21 == 0)) {
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
          *(undefined1 *)(puVar22 + 4) = 0;
          puVar22[2] = uVar23;
          puVar22[3] = 0;
          *puVar22 = &PTR_FUN_00022bb0_1_00031618;
          puVar22[1] = 0x2020224;
          puVar6 = *(undefined4 **)(param_1 + 0x16c);
          if (puVar6 == *(undefined4 **)(param_1 + 0x170)) {
            pbVar25 = *(byte **)(param_1 + 0x168);
            sVar24 = (int)puVar6 - (int)pbVar25;
            if (pbVar25 == param_1 + 0x174) {
              __dest = malloc(sVar24 * 2);
              if (__dest == (void *)0x0) goto LAB_0002281a;
              if (sVar24 != 0) {
                memmove(__dest,pbVar25,sVar24);
              }
              *(void **)(param_1 + 0x168) = __dest;
            }
            else {
              __dest = realloc(pbVar25,sVar24 * 2);
              *(void **)(param_1 + 0x168) = __dest;
              if (__dest == (void *)0x0) {
LAB_0002281a:
                    /* WARNING: Subroutine does not return */
                FUN_00020238();
              }
            }
            *(void **)(param_1 + 0x170) = (void *)((int)__dest + ((int)sVar24 >> 1) * 4);
            puVar6 = (undefined4 *)((int)__dest + ((int)sVar24 >> 2) * 4);
          }
          *(undefined4 **)(param_1 + 0x16c) = puVar6 + 1;
          *puVar6 = puVar22;
          goto LAB_000227a2;
        }
        uVar1 = *(int *)(param_1 + 0x150) - *(int *)(param_1 + 0x14c) >> 2;
        if (((uVar21 < uVar1) &&
            (piVar15 = *(int **)(*(int *)(param_1 + 0x14c) + uVar21 * 4), piVar15 != (int *)0x0)) &&
           (uVar23 < (uint)(piVar15[1] - *piVar15 >> 2))) {
          puVar22 = *(undefined4 **)(*piVar15 + uVar23 * 4);
          goto LAB_000227a2;
        }
        if ((*(uint *)(param_1 + 0x188) == uVar21) && (uVar21 <= uVar1)) {
          if (uVar21 == uVar1) {
            FUN_00022b02(param_1 + 0x14c,(int)register0x00000054 + -0x30);
          }
          puVar22 = (undefined4 *)FUN_00022b78(param_1,&DAT_00016375);
          goto LAB_000227a2;
        }
      }
    }
LAB_000227a0:
    puVar22 = (undefined4 *)0x0;
LAB_000227a2:
    if (__stack_chk_guard != pbVar18) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(pbVar18);
    }
    return puVar22;
  case 0x61:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x4e) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016689;
      puVar19 = &UNK_0001668b;
      goto LAB_00023e7a;
    }
    if (bVar3 == 0x53) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar7 = pbVar25;
      if (__stack_chk_guard == pbVar25) {
        puVar19 = &UNK_00016ab1;
        puVar20 = &DAT_00016ab0;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar3 == 0x7a) {
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00022cf0(param_1);
    }
    else {
      if (bVar3 == 100) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard == pbVar25) {
          puVar19 = &UNK_0001702b;
          puVar20 = &DAT_0001702a;
          goto LAB_00023e4c;
        }
        goto LAB_00022d44;
      }
      if (bVar3 == 0x6e) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard == pbVar25) {
          puVar19 = &UNK_0001702b;
          puVar20 = &DAT_0001702a;
          goto LAB_00023e7a;
        }
        goto LAB_00022d44;
      }
      if (bVar3 != 0x74) {
        if (bVar3 == 0x61) {
          *(byte **)param_1 = pbVar27 + 2;
          pbVar7 = pbVar25;
          if (__stack_chk_guard == pbVar25) {
            puVar19 = &DAT_00016fb0;
            puVar20 = &DAT_00016fae;
            goto LAB_00023e7a;
          }
          goto LAB_00022d44;
        }
        break;
      }
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00020e00(param_1);
    }
    if (local_38 == 0) break;
    puVar22 = (undefined4 *)FUN_00024504(param_1,"alignof (",&local_38);
    goto LAB_00022d2a;
  case 99:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x76) {
      iVar9 = FUN_0002079c(param_1,&DAT_00016397,&DAT_00016399);
      puVar22 = (undefined4 *)0x0;
      if (iVar9 == 0) goto LAB_00022d2a;
      bVar3 = param_1[0x184];
      param_1[0x184] = 0;
      iVar9 = FUN_00020e00(param_1);
      param_1[0x184] = bVar3;
      if (iVar9 != 0) {
        pcVar17 = *(char **)param_1;
        pcVar10 = *(char **)(param_1 + 4);
        if ((pcVar17 == pcVar10) || (*pcVar17 != '_')) {
          iVar11 = FUN_00022cf0(param_1);
          if (iVar11 != 0) {
            FUN_00026444(&local_38,param_1,(int)register0x00000054 + -0x30,
                         (int)register0x00000054 + -0x2c);
LAB_0002416e:
            puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
            puVar22[1] = 0x101013c;
            puVar22[2] = iVar9;
            puVar20 = &UNK_00031b18;
LAB_00024186:
            *puVar22 = puVar20 + 8;
            puVar22[4] = local_34;
            puVar22[3] = local_38;
            goto LAB_00022d2a;
          }
        }
        else {
          iVar12 = *(int *)(param_1 + 0xc);
          iVar11 = *(int *)(param_1 + 8);
          pcVar17 = pcVar17 + 1;
          *(char **)param_1 = pcVar17;
          while( true ) {
            if ((pcVar17 != pcVar10) && (*pcVar17 == 'E')) {
              *(char **)param_1 = pcVar17 + 1;
              FUN_00021f18(&local_38,param_1,iVar12 - iVar11 >> 2);
              goto LAB_0002416e;
            }
            local_38 = FUN_00022cf0(param_1);
            if (local_38 == 0) break;
            FUN_00021ea4(param_1 + 8,&local_38);
            pcVar17 = *(char **)param_1;
            pcVar10 = *(char **)(param_1 + 4);
          }
        }
      }
    }
    else if (bVar3 == 0x6c) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_00022cf0(param_1);
      if (iVar9 != 0) {
        iVar11 = *(int *)(param_1 + 8);
        iVar12 = *(int *)(param_1 + 0xc);
        while( true ) {
          pcVar10 = *(char **)param_1;
          if ((pcVar10 != *(char **)(param_1 + 4)) && (*pcVar10 == 'E')) {
            *(char **)param_1 = pcVar10 + 1;
            FUN_00021f18(&local_38,param_1,iVar12 - iVar11 >> 2);
            puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
            puVar22[1] = 0x1010137;
            puVar22[2] = iVar9;
            puVar20 = &UNK_00031ae0;
            goto LAB_00024186;
          }
          local_38 = FUN_00022cf0(param_1);
          if (local_38 == 0) break;
          FUN_00021ea4(param_1 + 8,&local_38);
        }
      }
    }
    else {
      if (bVar3 == 0x6d) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard == pbVar25) {
          puVar19 = &UNK_000165a6;
          puVar20 = &DAT_000165a5;
          goto LAB_00023e7a;
        }
        goto LAB_00022d44;
      }
      if (bVar3 == 0x6f) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &DAT_0001702c;
        goto LAB_00023e48;
      }
      if (bVar3 == 99) {
        *(byte **)param_1 = pbVar27 + 2;
        iVar9 = FUN_00020e00(param_1);
        if ((iVar9 != 0) && (iVar11 = FUN_00022cf0(param_1), iVar11 != 0)) {
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
          pcVar10 = "const_cast";
          pcVar17 = "";
          goto LAB_00023e14;
        }
      }
    }
    break;
  case 100:
    bVar3 = pbVar27[1];
    puVar22 = (undefined4 *)0x0;
    switch(bVar3) {
    case 0x6c:
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00022cf0(param_1);
      puVar22 = (undefined4 *)0x0;
      if (local_38 != 0) {
LAB_000233d6:
        puVar22 = (undefined4 *)
                  FUN_00024cb8(param_1,&local_38,&uStack_39,(int)register0x00000054 + -0x30);
      }
      break;
    case 0x6d:
    case 0x6f:
    case 0x70:
    case 0x71:
    case 0x72:
    case 0x75:
      break;
    case 0x6e:
joined_r0x0002331c:
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      iVar9 = FUN_0002079c(param_1,&DAT_00016e47,&DAT_00016e4a);
      if (iVar9 == 0) {
        iVar9 = FUN_0002079c(param_1,&DAT_0001602f,&DAT_00016031);
        iVar11 = FUN_0002079c(param_1,&DAT_00016c93,&DAT_00016c95);
        if (iVar11 == 0) {
          puVar22 = (undefined4 *)FUN_0002664c(param_1);
          if (iVar9 == 1 && puVar22 != (undefined4 *)0x0) {
            puVar22 = (undefined4 *)FUN_00026764(param_1,(int)register0x00000054 + -0x28);
          }
          goto LAB_00024e60;
        }
        if ((*(byte **)(param_1 + 4) == *(byte **)param_1) ||
           (**(byte **)param_1 - 0x3a < 0xfffffff6)) {
          iVar9 = FUN_00026528(param_1);
          if (iVar9 == 0) goto LAB_00024e5e;
          if ((*(char **)(param_1 + 4) != *(char **)param_1) && (**(char **)param_1 == 'I')) {
            iVar9 = FUN_000222e8(param_1,0);
            if (iVar9 == 0) goto LAB_00024e5e;
            FUN_00022574(param_1,(int)register0x00000054 + -0x28,(int)register0x00000054 + -0x2c);
          }
        }
        else {
          iVar11 = 0;
          do {
            iVar12 = FUN_000265b4(param_1);
            if (iVar12 == 0) goto LAB_00024e5e;
            if (iVar11 == 0) {
              if (iVar9 != 0) {
                iVar12 = FUN_00026764(param_1,(int)register0x00000054 + -0x2c);
              }
            }
            else {
              iVar12 = FUN_0002661c(param_1,(int)register0x00000054 + -0x28,
                                    (int)register0x00000054 + -0x2c);
            }
            pcVar10 = *(char **)param_1;
            iVar11 = iVar12;
          } while ((pcVar10 == *(char **)(param_1 + 4)) || (*pcVar10 != 'E'));
LAB_00024e44:
          *(char **)param_1 = pcVar10 + 1;
        }
        iVar9 = FUN_0002664c(param_1);
        if (iVar9 != 0) {
          puVar22 = (undefined4 *)
                    FUN_0002661c(param_1,(int)register0x00000054 + -0x28,
                                 (int)register0x00000054 + -0x2c);
          goto LAB_00024e60;
        }
      }
      else {
        iVar9 = FUN_00026528(param_1);
        if (iVar9 != 0) {
          if ((*(char **)(param_1 + 4) != *(char **)param_1) && (**(char **)param_1 == 'I')) {
            iVar9 = FUN_000222e8(param_1,0);
            if (iVar9 == 0) goto LAB_00024e5e;
            FUN_00022574(param_1,(int)register0x00000054 + -0x28,(int)register0x00000054 + -0x2c);
          }
          while( true ) {
            pcVar10 = *(char **)param_1;
            if ((pcVar10 != *(char **)(param_1 + 4)) && (*pcVar10 == 'E')) goto LAB_00024e44;
            iVar9 = FUN_000265b4(param_1);
            if (iVar9 == 0) break;
            FUN_0002661c(param_1,(int)register0x00000054 + -0x28,(int)register0x00000054 + -0x2c);
          }
        }
      }
LAB_00024e5e:
      puVar22 = (undefined4 *)0x0;
LAB_00024e60:
      if (__stack_chk_guard != pbVar18) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail(puVar22);
      }
      return puVar22;
    case 0x73:
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00022cf0(param_1);
      if ((local_38 == 0) || (iVar9 = FUN_00022cf0(param_1), iVar9 == 0)) goto LAB_00022d28;
      puVar20 = &DAT_0001697f;
LAB_00023d46:
      puVar22 = (undefined4 *)
                FUN_00024e90(param_1,&local_38,puVar20,(int)register0x00000054 + -0x30);
      break;
    case 0x74:
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_00022cf0(param_1);
      if ((iVar9 == 0) || (iVar11 = FUN_00022cf0(param_1), iVar11 == 0)) goto LAB_00022d28;
      puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
      puVar22[2] = iVar9;
      puVar22[3] = &DAT_00015eae;
      *puVar22 = &PTR_LAB_00022116_1_00031ca8;
      puVar22[1] = 0x1010133;
      puVar22[4] = &DAT_00015eaf;
      puVar22[5] = iVar11;
      break;
    case 0x76:
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard == pbVar25) {
        puVar20 = &DAT_00015eed;
        puVar19 = &UNK_00015eee;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    default:
      if (bVar3 == 0x56) {
        *(byte **)param_1 = pbVar27 + 2;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &UNK_000162c8;
        goto LAB_00023e78;
      }
      if (bVar3 == 0x65) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &DAT_000164bb;
LAB_00023e48:
        puVar19 = puVar20 + 1;
        goto LAB_00023e4c;
      }
      if (bVar3 == 99) {
        *(byte **)param_1 = pbVar27 + 2;
        iVar9 = FUN_00020e00(param_1);
        if ((iVar9 == 0) || (iVar11 = FUN_00022cf0(param_1), iVar11 == 0)) goto LAB_00022d28;
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
        pcVar10 = "dynamic_cast";
        pcVar17 = "";
LAB_00023e14:
        *puVar22 = &PTR_LAB_00022116_1_00031ab0;
        puVar22[1] = 0x1010135;
        puVar22[2] = pcVar10;
        puVar22[3] = pcVar17;
        puVar22[4] = iVar9;
        puVar22[5] = iVar11;
      }
      else if (bVar3 == 0x61) {
        *(byte **)param_1 = pbVar27 + 2;
        local_38 = FUN_00022cf0(param_1);
        if (local_38 != 0) goto LAB_000233d6;
        goto LAB_00022d28;
      }
    }
    goto LAB_00022d2a;
  case 0x65:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x4f) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_000168f5;
    }
    else {
      if (bVar3 != 0x71) {
        if (bVar3 == 0x6f) {
          *(byte **)param_1 = pbVar27 + 2;
          if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
          puVar20 = &UNK_00016b62;
          goto LAB_00023576;
        }
        break;
      }
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_000168f8;
    }
    goto LAB_00023e78;
  case 0x66:
    local_44 = &DAT_00016ab0;
    pbVar2 = pbVar27 + 1;
    local_4c = &DAT_00015eed;
    local_48 = &DAT_000165a5;
    if ((*pbVar2 == 0x70) ||
       (((*pbVar2 == 0x4c && ((byte *)0x2 < pbVar16)) &&
        (pbVar16 = (byte *)(pbVar27[2] - 0x3a), (byte *)0xfffffff5 < pbVar16)))) {
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      iVar11 = (int)register0x00000054 + -0x1c;
      iVar9 = FUN_0002079c(param_1,&DAT_00016b6f,&DAT_00016b71);
      if (iVar9 == 0) {
        iVar9 = FUN_0002079c(param_1,&DAT_00016903,&DAT_00016905);
        if (iVar9 != 0) {
          puVar22 = (undefined4 *)0x0;
          FUN_00020d6c(iVar11,param_1,0);
          if (pbVar18 == pbVar16) goto LAB_00024bfa;
          pcVar10 = *(char **)param_1;
          if ((pcVar10 != *(char **)(param_1 + 4)) && (*pcVar10 == 'p')) {
            *(char **)param_1 = pcVar10 + 1;
            goto LAB_00024b92;
          }
        }
      }
      else {
LAB_00024b92:
        FUN_000225a4(param_1);
        puVar22 = (undefined4 *)0x0;
        FUN_00020d6c(iVar11,param_1,0);
        pcVar10 = *(char **)param_1;
        if (pcVar10 == *(char **)(param_1 + 4)) goto LAB_00024bfa;
        if (*pcVar10 == '_') {
          *(char **)param_1 = pcVar10 + 1;
          puVar22 = (undefined4 *)FUN_00025fe0(param_1,iVar11);
          goto LAB_00024bfa;
        }
      }
      puVar22 = (undefined4 *)0x0;
LAB_00024bfa:
      if (__stack_chk_guard != pbVar18) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail(pbVar18);
      }
      return puVar22;
    }
    if (pbVar27 != pbVar13) {
      *(byte **)param_1 = pbVar2;
    }
    if (pbVar27 != pbVar13 && pbVar13 != pbVar2) {
      bVar3 = *pbVar2;
      bVar4 = true;
      if (bVar3 != 0x4c) {
        if (bVar3 != 0x72) {
          if (bVar3 == 0x6c) goto LAB_00023f94;
          if (bVar3 != 0x52) break;
        }
        bVar4 = false;
      }
LAB_00023f94:
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_0002079c(param_1,&DAT_000160d1,&DAT_000160d3);
      puVar20 = &DAT_00016fae;
      if (iVar9 == 0) {
        iVar9 = FUN_0002079c(param_1,&DAT_00015e09,&DAT_00015e0b);
        if (iVar9 == 0) {
          iVar9 = FUN_0002079c(param_1,&DAT_00016edc,&DAT_00016ede);
          if (iVar9 == 0) {
            iVar9 = FUN_0002079c(param_1,&DAT_00015e0c,&DAT_00015e0e);
            if (iVar9 == 0) {
              iVar9 = FUN_0002079c(param_1,&DAT_000170fe,&DAT_00017100);
              if (iVar9 == 0) {
                iVar9 = FUN_0002079c(param_1,&DAT_00016e41,&DAT_00016e43);
                if (iVar9 != 0) {
                  puVar20 = &DAT_0001697f;
                  goto LAB_00023fae;
                }
                iVar9 = FUN_0002079c(param_1,&DAT_000164cc,&DAT_000164ce);
                if (iVar9 == 0) {
                  iVar9 = FUN_0002079c(param_1,&DAT_0001669a,&DAT_0001669c);
                  if (iVar9 == 0) {
                    iVar9 = FUN_0002079c(param_1,&DAT_00016f73,&DAT_00016f75);
                    if (iVar9 != 0) {
                      local_4c = &UNK_00016b62;
                      goto LAB_000241ba;
                    }
                    iVar9 = FUN_0002079c(param_1,&DAT_00016906,&DAT_00016908);
                    if (iVar9 == 0) {
                      iVar9 = FUN_0002079c(param_1,&DAT_00016edf,&DAT_00016ee1);
                      if (iVar9 == 0) {
                        iVar9 = FUN_0002079c(param_1,&DAT_000162d4,&DAT_000162d6);
                        if (iVar9 == 0) {
                          iVar9 = FUN_0002079c(param_1,&DAT_0001686c,&DAT_0001686e);
                          if (iVar9 != 0) {
                            local_4c = &DAT_000168fb;
                            goto LAB_000241ba;
                          }
                          iVar9 = FUN_0002079c(param_1,&DAT_000164cf,&DAT_000164d1);
                          if (iVar9 == 0) {
                            iVar9 = FUN_0002079c(param_1,&DAT_0001686f,&DAT_00016871);
                            if (iVar9 == 0) {
                              iVar9 = FUN_0002079c(param_1,&DAT_0001669d,&DAT_0001669f);
                              if (iVar9 != 0) {
                                local_4c = &UNK_00016be4;
LAB_00024278:
                                puVar20 = local_4c + 3;
                                goto LAB_00024096;
                              }
                              iVar9 = FUN_0002079c(param_1,&DAT_00016909,&DAT_0001690b);
                              if (iVar9 == 0) {
                                iVar9 = FUN_0002079c(param_1,&DAT_000167ba,&DAT_000167bc);
                                if (iVar9 == 0) {
                                  iVar9 = FUN_0002079c(param_1,&DAT_00016d7a,&DAT_00016d7c);
                                  if (iVar9 == 0) {
                                    iVar9 = FUN_0002079c(param_1,&DAT_00016be8,&DAT_00016bea);
                                    if (iVar9 != 0) {
                                      local_4c = &DAT_000164bb;
                                      goto LAB_000241ba;
                                    }
                                    iVar9 = FUN_0002079c(param_1,&DAT_00015e67,&DAT_00015e69);
                                    if (iVar9 == 0) {
                                      iVar9 = FUN_0002079c(param_1,&DAT_00015e6a,&DAT_00015e6c);
                                      if (iVar9 == 0) {
                                        iVar9 = FUN_0002079c(param_1,&DAT_00016985,&DAT_00016987);
                                        if (iVar9 == 0) {
                                          iVar9 = FUN_0002079c(param_1,&DAT_000167bd,&DAT_000167bf);
                                          if (iVar9 != 0) {
                                            local_4c = &UNK_00016fb1;
                                            goto LAB_000241ba;
                                          }
                                          iVar9 = FUN_0002079c(param_1,&DAT_000169ee,&DAT_000169f0);
                                          if (iVar9 == 0) {
                                            iVar9 = FUN_0002079c(param_1,&DAT_00016ac8,&DAT_00016aca
                                                                );
                                            if (iVar9 != 0) {
                                              local_4c = &UNK_00016b67;
                                              goto LAB_000241ba;
                                            }
                                            iVar9 = FUN_0002079c(param_1,&DAT_000164d2,&DAT_000164d4
                                                                );
                                            if (iVar9 == 0) {
                                              iVar9 = FUN_0002079c(param_1,&DAT_000169f1,
                                                                   &DAT_000169f3);
                                              if (iVar9 != 0) {
                                                local_4c = &UNK_00017359;
                                                goto LAB_000241ba;
                                              }
                                              iVar9 = FUN_0002079c(param_1,&DAT_000160d4,
                                                                   &DAT_000160d6);
                                              if (iVar9 == 0) {
                                                iVar9 = FUN_0002079c(param_1,&DAT_00016872,
                                                                     &DAT_00016874);
                                                if (iVar9 == 0) {
                                                  iVar9 = FUN_0002079c(param_1,&DAT_00016e44,
                                                                       &DAT_00016e46);
                                                  if (iVar9 == 0) break;
                                                  local_4c = &UNK_000169e3;
                                                  goto LAB_00024278;
                                                }
                                                local_4c = &UNK_0001603d;
                                              }
                                              else {
                                                local_4c = &UNK_00016ec9;
                                              }
                                            }
                                            else {
                                              local_4c = &UNK_000169e0;
                                            }
                                          }
                                          else {
                                            local_4c = &UNK_00016b64;
                                          }
                                        }
                                        else {
                                          local_4c = &UNK_00016ab2;
                                        }
                                      }
                                      else {
                                        local_4c = &UNK_00016e3e;
                                      }
                                    }
                                    else {
                                      local_4c = &UNK_000165a7;
                                    }
                                  }
                                  else {
                                    local_4c = &UNK_000162cb;
                                  }
                                  goto LAB_000241d2;
                                }
                                local_4c = &DAT_0001637a;
                              }
                              else {
                                local_4c = &DAT_00015e04;
                              }
                              goto LAB_000241ba;
                            }
                            local_4c = &UNK_00016d66;
                          }
                          else {
                            local_4c = &UNK_00016ec6;
                          }
                        }
                        else {
                          local_4c = &UNK_00015e55;
                        }
                      }
                      else {
                        local_4c = &UNK_000168f8;
                      }
                    }
                    else {
                      local_4c = &UNK_000168f5;
                    }
                  }
                  else {
                    local_4c = &UNK_000162c8;
                  }
LAB_000241d2:
                  puVar20 = local_4c + 2;
                }
                else {
LAB_000241ba:
                  puVar20 = local_4c + 1;
                }
                goto LAB_00024096;
              }
              local_4c = local_48;
            }
            else {
              local_4c = local_44;
            }
            puVar20 = local_4c + 1;
          }
          else {
            puVar20 = &UNK_0001668b;
            local_4c = &UNK_00016689;
          }
        }
        else {
          puVar20 = &UNK_0001702b;
          local_4c = &DAT_0001702a;
        }
      }
      else {
LAB_00023fae:
        local_4c = puVar20;
        puVar20 = local_4c + 2;
      }
LAB_00024096:
      iVar9 = FUN_00022cf0(param_1);
      if (iVar9 != 0) {
        iVar11 = iVar9;
        if (bVar3 == 0x52 || bVar3 == 0x4c) {
          iVar12 = FUN_00022cf0(param_1);
          if (iVar12 == 0) break;
          if (bVar4) {
            iVar11 = iVar12;
            iVar12 = iVar9;
          }
        }
        else {
          iVar12 = 0;
        }
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x1c);
        *(bool *)(puVar22 + 6) = bVar4;
        puVar22[5] = puVar20;
        *puVar22 = &PTR_LAB_00022116_1_000319d0;
        puVar22[1] = 0x101013e;
        puVar22[2] = iVar11;
        puVar22[3] = iVar12;
        puVar22[4] = local_4c;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x67:
    if (pbVar27[1] == 0x74) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &DAT_000168fb;
LAB_00023576:
      puVar19 = puVar20 + 1;
      goto LAB_00023e7a;
    }
    if (pbVar27[1] == 0x65) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00015e55;
      goto LAB_00023e78;
    }
    break;
  case 0x69:
    if (pbVar27[1] == 0x6c) {
      pbVar27 = pbVar27 + 2;
      iVar11 = *(int *)(param_1 + 0xc);
      iVar9 = *(int *)(param_1 + 8);
      *(byte **)param_1 = pbVar27;
      while( true ) {
        if ((pbVar27 != pbVar13) && (*pbVar27 == 0x45)) {
          *(byte **)param_1 = pbVar27 + 1;
          FUN_00021f18(&local_38,param_1,iVar11 - iVar9 >> 2);
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
          puVar22[1] = 0x101013d;
          puVar22[2] = 0;
          puVar20 = &UNK_00031d80;
          goto LAB_00024186;
        }
        local_38 = FUN_00024edc(param_1);
        if (local_38 == 0) break;
        FUN_00021ea4(param_1 + 8,&local_38);
        pbVar27 = *(byte **)param_1;
        pbVar13 = *(byte **)(param_1 + 4);
      }
    }
    else if (pbVar27[1] == 0x78) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_00022cf0(param_1);
      if ((iVar9 != 0) && (iVar11 = FUN_00022cf0(param_1), iVar11 != 0)) {
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
        puVar22[2] = iVar9;
        puVar22[3] = iVar11;
        *puVar22 = &PTR_LAB_00022116_1_00031ce0;
        puVar22[1] = 0x1010130;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x6c:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x53) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016be4;
LAB_0002398a:
      puVar19 = puVar20 + 3;
      goto LAB_00023e7a;
    }
    if (bVar3 == 0x74) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &DAT_00015e04;
      goto LAB_00023576;
    }
    if (bVar3 == 0x73) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016d66;
    }
    else {
      if (bVar3 != 0x65) break;
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016ec6;
    }
    goto LAB_00023e78;
  case 0x6d:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x49) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_000162cb;
      goto LAB_00023e78;
    }
    if (bVar3 == 0x4c) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar7 = pbVar25;
      if (__stack_chk_guard == pbVar25) {
        puVar20 = &UNK_000165a7;
        puVar19 = &UNK_000165a9;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar3 != 0x6d) {
      if (bVar3 == 0x6c) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &DAT_000164bb;
      }
      else {
        if (bVar3 != 0x69) break;
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &DAT_0001637a;
      }
      puVar19 = puVar20 + 1;
      goto LAB_00023e7a;
    }
    pbVar18 = pbVar27 + 2;
    *(byte **)param_1 = pbVar18;
    if ((pbVar18 != pbVar13) && (*pbVar18 == 0x5f)) {
      *(byte **)param_1 = pbVar27 + 3;
      pbVar7 = pbVar25;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &DAT_000170f9;
      goto LAB_00023966;
    }
    local_38 = FUN_00022cf0(param_1);
    if (local_38 != 0) {
      puVar20 = &DAT_000170f9;
      goto LAB_00023dd4;
    }
    break;
  case 0x6e:
    bVar3 = pbVar27[1];
    if (bVar3 != 0x61) {
      if (bVar3 != 0x65) {
        if (bVar3 == 0x67) {
          *(byte **)param_1 = pbVar27 + 2;
          pbVar7 = pbVar25;
          if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
          puVar20 = &DAT_0001637a;
        }
        else {
          if (bVar3 != 0x74) {
            if (bVar3 == 0x78) {
              *(byte **)param_1 = pbVar27 + 2;
              iVar9 = FUN_00022cf0(param_1);
              if (iVar9 != 0) {
                puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x1c);
                *puVar22 = &PTR_LAB_00022116_1_00031e30;
                puVar22[1] = 0x1010134;
                puVar22[2] = "noexcept (";
                puVar22[3] = "";
                puVar22[4] = iVar9;
                puVar22[5] = &DAT_000170f7;
                puVar22[6] = &DAT_000170f8;
                goto LAB_00022d2a;
              }
            }
            else if (bVar3 == 0x77) goto LAB_0002334c;
            break;
          }
          *(byte **)param_1 = pbVar27 + 2;
          pbVar7 = pbVar25;
          if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
          puVar20 = &UNK_00016855;
        }
        puVar19 = puVar20 + 1;
LAB_00023e4c:
        iVar9 = FUN_00022cf0();
        if (iVar9 == 0) {
          puVar22 = (undefined4 *)0x0;
        }
        else {
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
          puVar22[2] = puVar20;
          puVar22[3] = puVar19;
          puVar22[4] = iVar9;
          *puVar22 = &PTR_LAB_00022116_1_00031a78;
          puVar22[1] = 0x101013a;
        }
        return puVar22;
      }
      *(byte **)param_1 = pbVar27 + 2;
      pbVar7 = pbVar25;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016e3e;
      goto LAB_00023e78;
    }
LAB_0002334c:
    FUN_0002079c(param_1,&DAT_0001602f,&DAT_00016031);
    iVar9 = FUN_0002079c(param_1,&DAT_000165c7,&DAT_000165c9);
    if ((iVar9 != 0) || (iVar9 = FUN_0002079c(param_1,&DAT_00016a09,&DAT_00016a0b), iVar9 != 0)) {
      pbVar18 = param_1 + 8;
      iVar9 = *(int *)pbVar18;
      iVar11 = *(int *)(param_1 + 0xc);
      while ((pcVar10 = *(char **)param_1, pcVar10 == *(char **)(param_1 + 4) || (*pcVar10 != '_')))
      {
        local_38 = FUN_00022cf0(param_1);
        if (local_38 == 0) goto LAB_00022d28;
        FUN_00021ea4(pbVar18,&local_38);
      }
      *(char **)param_1 = pcVar10 + 1;
      FUN_00021f18(&local_38,param_1,iVar11 - iVar9 >> 2);
      iVar9 = FUN_00020e00(param_1);
      if (iVar9 != 0) {
        iVar11 = FUN_0002079c(param_1,&DAT_00017045,&DAT_00017047);
        if (iVar11 != 0) {
          iVar11 = *(int *)(param_1 + 8);
          iVar12 = *(int *)(param_1 + 0xc);
          goto LAB_00023ec2;
        }
        pcVar10 = *(char **)param_1;
        if (pcVar10 != *(char **)(param_1 + 4)) {
          puVar22 = (undefined4 *)0x0;
          if (*pcVar10 == 'E') {
            *(char **)param_1 = pcVar10 + 1;
            uVar14 = FUN_000220a8(param_1 + 0x198,0x20);
            puVar22 = (undefined4 *)FUN_0002760c(uVar14,local_38,local_34,iVar9);
          }
          goto LAB_00022d2a;
        }
      }
    }
    break;
  case 0x6f:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x52) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016b64;
    }
    else {
      if (bVar3 == 0x72) {
        *(byte **)param_1 = pbVar27 + 2;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &UNK_00016fb1;
        goto LAB_00023576;
      }
      if (bVar3 != 0x6f) {
        if (bVar3 == 0x6e) goto joined_r0x0002331c;
        break;
      }
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016ab2;
    }
LAB_00023e78:
    puVar19 = puVar20 + 2;
LAB_00023e7a:
    iVar9 = FUN_00022cf0();
    if ((iVar9 == 0) || (iVar11 = FUN_00022cf0(param_1), iVar11 == 0)) {
      puVar22 = (undefined4 *)0x0;
    }
    else {
      puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
      puVar22[2] = iVar9;
      puVar22[3] = puVar20;
      puVar22[4] = puVar19;
      puVar22[5] = iVar11;
      *puVar22 = &PTR_LAB_00022116_1_00031a40;
      puVar22[1] = 0x101012f;
    }
    return puVar22;
  case 0x70:
    puVar22 = (undefined4 *)0x0;
    switch(pbVar27[1]) {
    case 0x6c:
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016b67;
      goto LAB_00023576;
    case 0x6d:
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_0001668c;
      goto LAB_0002398a;
    case 0x6e:
    case 0x6f:
    case 0x71:
    case 0x72:
      break;
    case 0x70:
      pbVar18 = pbVar27 + 2;
      *(byte **)param_1 = pbVar18;
      if ((pbVar18 != pbVar13) && (*pbVar18 == 0x5f)) {
        *(byte **)param_1 = pbVar27 + 3;
        pbVar7 = pbVar25;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &DAT_00015e06;
LAB_00023966:
        puVar19 = puVar20 + 2;
        goto LAB_00023e4c;
      }
      local_38 = FUN_00022cf0(param_1);
      if (local_38 == 0) goto LAB_00022d28;
      puVar20 = &DAT_00015e06;
LAB_00023dd4:
      puVar22 = (undefined4 *)FUN_00024ff8(param_1,&local_38,puVar20);
      break;
    case 0x73:
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016b67;
      puVar19 = &UNK_00016b68;
      goto LAB_00023e4c;
    case 0x74:
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00022cf0(param_1);
      if ((local_38 != 0) && (iVar9 = FUN_00022cf0(param_1), iVar9 != 0)) {
        puVar20 = &DAT_00016c89;
        goto LAB_00023d46;
      }
      goto LAB_00022d28;
    default:
      if (pbVar27[1] == 0x4c) {
        *(byte **)param_1 = pbVar27 + 2;
        if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
        puVar20 = &UNK_000169e0;
        goto LAB_00023e78;
      }
    }
    goto LAB_00022d2a;
  case 0x71:
    if (pbVar27[1] == 0x75) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_00022cf0(param_1);
      if (((iVar9 != 0) && (iVar11 = FUN_00022cf0(param_1), iVar11 != 0)) &&
         (iVar12 = FUN_00022cf0(param_1), iVar12 != 0)) {
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
        *puVar22 = &PTR_LAB_00022116_1_00031e68;
        puVar22[1] = 0x1010132;
        puVar22[2] = iVar9;
        puVar22[3] = iVar11;
        puVar22[4] = iVar12;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x72:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x4d) {
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != pbVar25) goto LAB_00022d44;
      puVar20 = &UNK_00016ec9;
      goto LAB_00023e78;
    }
    if (bVar3 == 0x53) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar7 = pbVar25;
      if (__stack_chk_guard == pbVar25) {
        puVar20 = &UNK_000169e3;
        puVar19 = &UNK_000169e6;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar3 == 0x73) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar7 = pbVar25;
      if (__stack_chk_guard == pbVar25) {
        puVar20 = &UNK_0001603d;
        puVar19 = &UNK_0001603f;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar3 == 0x6d) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar7 = pbVar25;
      if (__stack_chk_guard == pbVar25) {
        puVar20 = &UNK_00017359;
        puVar19 = &UNK_0001735a;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar3 == 99) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_00020e00(param_1);
      if ((iVar9 != 0) && (iVar11 = FUN_00022cf0(param_1), iVar11 != 0)) {
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
        pcVar10 = "reinterpret_cast";
        pcVar17 = "";
LAB_000232dc:
        *puVar22 = &PTR_LAB_00022116_1_00031ab0;
        puVar22[1] = 0x1010135;
        puVar22[2] = pcVar10;
        puVar22[3] = pcVar17;
        puVar22[4] = iVar9;
        puVar22[5] = iVar11;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x73:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x50) {
      pbVar27 = pbVar27 + 2;
      iVar11 = *(int *)(param_1 + 0xc);
      iVar9 = *(int *)(param_1 + 8);
      *(byte **)param_1 = pbVar27;
      while( true ) {
        if ((pbVar27 != pbVar13) && (*pbVar27 == 0x45)) {
          *(byte **)param_1 = pbVar27 + 1;
          FUN_00021f18(&local_38,param_1,iVar11 - iVar9 >> 2);
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          puVar22[1] = 0x1010100;
          *puVar22 = &PTR_LAB_00022116_1_00031ed8;
          puVar22[2] = local_38;
          puVar22[3] = local_34;
          piVar15 = (int *)((int)register0x00000054 + -0x30);
          goto LAB_00024028;
        }
        local_38 = FUN_00021d64(param_1);
        if (local_38 == 0) break;
        FUN_00021ea4(param_1 + 8,&local_38);
        pbVar27 = *(byte **)param_1;
        pbVar13 = *(byte **)(param_1 + 4);
      }
    }
    else if (bVar3 == 0x5a) {
      pbVar27 = pbVar27 + 2;
      *(byte **)param_1 = pbVar27;
      if (pbVar13 != pbVar27) {
        if (*pbVar27 == 0x66) {
          local_38 = FUN_00024b74(param_1);
          if (local_38 != 0) {
            piVar15 = &local_38;
LAB_00024028:
            puVar22 = (undefined4 *)FUN_000250bc(param_1,piVar15);
            goto LAB_00022d2a;
          }
        }
        else if ((*pbVar27 == 0x54) && (iVar9 = FUN_00022680(param_1), iVar9 != 0)) {
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
          uVar14 = 0x1010136;
          puVar20 = &UNK_00031e98;
          goto LAB_0002385c;
        }
      }
    }
    else if (bVar3 == 0x7a) {
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00022cf0(param_1);
LAB_00023c2a:
      if (local_38 != 0) {
        pcVar10 = "sizeof (";
        goto LAB_00023c3a;
      }
    }
    else if (bVar3 == 0x70) {
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00022cf0(param_1);
      if (local_38 != 0) {
        puVar22 = (undefined4 *)FUN_0002503c(param_1,&local_38);
        goto LAB_00022d2a;
      }
    }
    else {
      pbVar7 = pbVar25;
      if (bVar3 == 0x72) goto joined_r0x0002331c;
      if (bVar3 == 0x74) {
        *(byte **)param_1 = pbVar27 + 2;
        local_38 = FUN_00020e00(param_1);
        goto LAB_00023c2a;
      }
      if (bVar3 == 99) {
        *(byte **)param_1 = pbVar27 + 2;
        iVar9 = FUN_00020e00(param_1);
        if ((iVar9 != 0) && (iVar11 = FUN_00022cf0(param_1), iVar11 != 0)) {
          puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
          pcVar10 = "static_cast";
          pcVar17 = "";
          goto LAB_000232dc;
        }
      }
    }
    break;
  case 0x74:
    bVar3 = pbVar27[1];
    if (bVar3 == 0x77) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_00022cf0(param_1);
      if (iVar9 != 0) {
        puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
        uVar14 = 0x101013f;
        puVar20 = &UNK_00031f08;
LAB_0002385c:
        *puVar22 = puVar20 + 8;
        puVar22[1] = uVar14;
        puVar22[2] = iVar9;
        goto LAB_00022d2a;
      }
    }
    else if (bVar3 == 0x69) {
      *(byte **)param_1 = pbVar27 + 2;
      local_38 = FUN_00020e00(param_1);
LAB_000236ca:
      if (local_38 != 0) {
        pcVar10 = "typeid (";
LAB_00023c3a:
        puVar22 = (undefined4 *)FUN_00025068(param_1,pcVar10,&local_38);
        goto LAB_00022d2a;
      }
    }
    else if (bVar3 == 0x6c) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar9 = FUN_00020e00(param_1);
      if (iVar9 != 0) {
        iVar11 = *(int *)(param_1 + 8);
        iVar12 = *(int *)(param_1 + 0xc);
        while( true ) {
          pcVar10 = *(char **)param_1;
          if ((pcVar10 != *(char **)(param_1 + 4)) && (*pcVar10 == 'E')) {
            *(char **)param_1 = pcVar10 + 1;
            FUN_00021f18(&local_38,param_1,iVar12 - iVar11 >> 2);
            puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
            puVar22[1] = 0x101013d;
            puVar22[2] = iVar9;
            *puVar22 = &PTR_LAB_00022116_1_00031d88;
            puVar22[3] = local_38;
            puVar22[4] = local_34;
            goto LAB_00022d2a;
          }
          local_38 = FUN_00024edc(param_1);
          if (local_38 == 0) break;
          FUN_00021ea4(param_1 + 8,&local_38);
        }
      }
    }
    else {
      if (bVar3 == 0x72) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar7 = pbVar25;
        if (__stack_chk_guard == pbVar25) {
          puVar22 = (undefined4 *)FUN_00025104(param_1,"throw");
          return puVar22;
        }
        goto LAB_00022d44;
      }
      if (bVar3 == 0x65) {
        *(byte **)param_1 = pbVar27 + 2;
        local_38 = FUN_00022cf0(param_1);
        goto LAB_000236ca;
      }
    }
    break;
  default:
    if (*pbVar27 - 0x31 < 9) goto joined_r0x0002331c;
switchD_00022d78_caseD_1:
    iVar9 = FUN_0002079c(param_1,&DAT_00016d69,&DAT_00016d74);
    if (iVar9 == 0) {
      iVar9 = FUN_0002079c(param_1,&DAT_0001735b,&DAT_00017366);
      if (iVar9 == 0) break;
      local_38 = FUN_00022cf0(param_1);
    }
    else {
      local_38 = FUN_00020e00(param_1);
    }
    if (local_38 == 0) break;
    puVar22 = (undefined4 *)FUN_0002513c(param_1,&local_38);
    goto LAB_00022d2a;
  }
LAB_00022d28:
  puVar22 = (undefined4 *)0x0;
LAB_00022d2a:
  pbVar7 = pbVar25;
  if (__stack_chk_guard == pbVar25) {
    return puVar22;
  }
LAB_00022d44:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(pbVar7);
LAB_00023ec2:
  pcVar10 = *(char **)param_1;
  if ((pcVar10 != *(char **)(param_1 + 4)) && (*pcVar10 == 'E')) {
    *(char **)param_1 = pcVar10 + 1;
    FUN_00021f18((int)register0x00000054 + -0x30,param_1,iVar12 - iVar11 >> 2);
    puVar22 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x20);
    FUN_0002760c(puVar22,local_38,local_34,iVar9);
    goto LAB_00022d2a;
  }
  iVar8 = FUN_00022cf0(param_1);
  if (iVar8 == 0) goto LAB_00022d28;
  FUN_00021ea4(pbVar18,(int)register0x00000054 + -0x30);
  goto LAB_00023ec2;
code_r0x000247ee:
  iVar11 = FUN_00025594(pcVar5[iVar9]);
  iVar9 = iVar9 + 1;
  if (iVar11 == 0) goto switchD_0002459a_caseD_54;
  goto LAB_000247e8;
}


// ==== FUN_00024504 @ 00024504

undefined4 * FUN_00024504(int param_1,char *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  size_t sVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x1c);
  sVar2 = strlen(param_2);
  puVar1[1] = 0x1010134;
  *puVar1 = &PTR_LAB_00022116_1_00031e30;
  puVar1[4] = *param_3;
  puVar1[2] = param_2;
  puVar1[3] = param_2 + sVar2;
  puVar1[5] = &DAT_000170f7;
  puVar1[6] = &DAT_000170f8;
  return puVar1;
}


// ==== FUN_00024558 @ 00024558

undefined4 * FUN_00024558(undefined8 *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  size_t sVar5;
  char *pcVar6;
  undefined *puVar7;
  char *pcVar8;
  int unaff_r5;
  int unaff_r6;
  char *pcVar9;
  char *pcVar10;
  undefined4 *puVar11;
  undefined8 uVar12;
  undefined1 auStack_b0 [128];
  undefined1 auStack_26 [2];
  
  iVar1 = __stack_chk_guard;
  pcVar9 = *(char **)param_1;
  pcVar8 = *(char **)((int)param_1 + 4);
  if ((pcVar9 == pcVar8) || (*pcVar9 != 'L')) goto LAB_00024ab6;
  pcVar6 = pcVar9 + 1;
  *(char **)param_1 = pcVar6;
  if (pcVar8 == pcVar6) {
switchD_0002459a_caseD_42:
    iVar2 = FUN_00020e00(param_1);
    if (iVar2 == 0) goto LAB_00024ab6;
    puVar11 = (undefined4 *)0x0;
    FUN_00020d6c(auStack_b0 + 0x80,param_1,0);
    if (unaff_r5 != unaff_r6) {
      pcVar8 = *(char **)param_1;
      if ((pcVar8 == *(char **)((int)param_1 + 4)) || (*pcVar8 != 'E')) goto LAB_00024ab6;
      *(char **)param_1 = pcVar8 + 1;
      puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0x14);
      puVar11[2] = iVar2;
      puVar11[3] = unaff_r5;
      puVar11[4] = unaff_r6;
      *puVar11 = &PTR_LAB_00022116_1_00031960;
      puVar11[1] = 0x1010144;
    }
    goto switchD_0002459a_caseD_54;
  }
  puVar11 = (undefined4 *)0x0;
  switch(*pcVar6) {
  case 'A':
    iVar2 = FUN_00020e00(param_1);
    if (((iVar2 == 0) || (pcVar8 = *(char **)param_1, pcVar8 == *(char **)((int)param_1 + 4))) ||
       (*pcVar8 != 'E')) goto LAB_00024ab6;
    *(char **)param_1 = pcVar8 + 1;
    puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0xc);
    uVar4 = 0x1010142;
    puVar7 = &UNK_00031760;
LAB_0002472e:
    *puVar11 = puVar7 + 8;
    puVar11[1] = uVar4;
    puVar11[2] = iVar2;
    goto switchD_0002459a_caseD_54;
  default:
    goto switchD_0002459a_caseD_42;
  case 'D':
    iVar2 = FUN_0002079c(param_1,&DAT_000165aa,&DAT_000165ad);
    if (iVar2 != 0) {
      if (__stack_chk_guard == iVar1) {
        puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0x10);
        sVar5 = strlen("nullptr");
        puVar11[2] = "nullptr";
        puVar11[3] = "nullptr" + sVar5;
        *puVar11 = &PTR_LAB_00022116_1_000315a8;
        puVar11[1] = 0x1010107;
        return puVar11;
      }
      break;
    }
    goto LAB_00024ab6;
  case 'T':
    goto switchD_0002459a_caseD_54;
  case 'U':
    if ((1 < (uint)((int)pcVar8 - (int)pcVar6)) && (pcVar9[2] == 'l')) {
      puVar11 = (undefined4 *)0x0;
      iVar2 = FUN_00025258(param_1,0);
      if (iVar2 == 0) goto switchD_0002459a_caseD_54;
      pcVar8 = *(char **)param_1;
      if ((pcVar8 != *(char **)((int)param_1 + 4)) && (*pcVar8 == 'E')) {
        *(char **)param_1 = pcVar8 + 1;
        puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0xc);
        uVar4 = 0x1010143;
        puVar7 = &UNK_00031920;
        goto LAB_0002472e;
      }
    }
    goto LAB_00024ab6;
  case '_':
    iVar2 = FUN_0002079c(param_1,&DAT_000168e5,&DAT_000168e7);
    if ((((iVar2 == 0) ||
         (puVar11 = (undefined4 *)FUN_0002080c(param_1), puVar11 == (undefined4 *)0x0)) ||
        (pcVar8 = *(char **)param_1, pcVar8 == *(char **)((int)param_1 + 4))) || (*pcVar8 != 'E'))
    goto LAB_00024ab6;
    *(char **)param_1 = pcVar8 + 1;
    goto switchD_0002459a_caseD_54;
  case 'a':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard != iVar1) break;
    pcVar8 = "signed char";
    pcVar9 = "";
    goto LAB_000249d0;
  case 'b':
    iVar2 = FUN_0002079c(param_1,&DAT_000171aa,&DAT_000171ad);
    if ((iVar2 == 0) && (iVar2 = FUN_0002079c(param_1,&DAT_0001637c,&DAT_0001637f), iVar2 == 0))
    goto LAB_00024ab6;
    puVar11 = (undefined4 *)FUN_000251f0(param_1,auStack_b0 + 0x80);
    goto switchD_0002459a_caseD_54;
  case 'c':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "char";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 'd':
    pcVar6 = pcVar9 + 2;
    *(char **)param_1 = pcVar6;
    if (0x10 < (uint)((int)pcVar8 - (int)pcVar6)) {
      pcVar10 = pcVar9 + 0x12;
      iVar2 = 0;
      puVar11 = (undefined4 *)0x0;
LAB_000247e8:
      if (iVar2 != 0x10) goto code_r0x000247ee;
      *(char **)param_1 = pcVar10;
      if ((pcVar10 != pcVar8) && (*pcVar10 == 'E')) {
        *(char **)param_1 = pcVar9 + 0x13;
        puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0x10);
        uVar4 = 0x1010147;
        puVar7 = &UNK_000316f0;
LAB_00024aa2:
        *puVar11 = puVar7 + 8;
        puVar11[1] = uVar4;
        puVar11[2] = pcVar9 + 2;
        puVar11[3] = pcVar10;
        goto switchD_0002459a_caseD_54;
      }
    }
LAB_00024ab6:
    puVar11 = (undefined4 *)0x0;
    goto switchD_0002459a_caseD_54;
  case 'e':
    pcVar6 = pcVar9 + 2;
    *(char **)param_1 = pcVar6;
    if ((uint)((int)pcVar8 - (int)pcVar6) < 0x11) goto LAB_00024ab6;
    pcVar10 = pcVar9 + 0x12;
    iVar2 = 0;
    puVar11 = (undefined4 *)0x0;
    do {
      if (iVar2 == 0x10) {
        *(char **)param_1 = pcVar10;
        if ((pcVar10 == pcVar8) || (*pcVar10 != 'E')) goto LAB_00024ab6;
        *(char **)param_1 = pcVar9 + 0x13;
        puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0x10);
        uVar4 = 0x1010148;
        puVar7 = &UNK_00031728;
        goto LAB_00024aa2;
      }
      iVar3 = FUN_00025594(pcVar6[iVar2]);
      iVar2 = iVar2 + 1;
    } while (iVar3 != 0);
    goto switchD_0002459a_caseD_54;
  case 'f':
    pcVar6 = pcVar9 + 2;
    *(char **)param_1 = pcVar6;
    if ((uint)((int)pcVar8 - (int)pcVar6) < 9) goto LAB_00024ab6;
    pcVar10 = pcVar9 + 10;
    iVar2 = 0;
    puVar11 = (undefined4 *)0x0;
    do {
      if (iVar2 == 8) {
        *(char **)param_1 = pcVar10;
        if ((pcVar10 == pcVar8) || (*pcVar10 != 'E')) goto LAB_00024ab6;
        *(char **)param_1 = pcVar9 + 0xb;
        puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0x10);
        uVar4 = 0x1010146;
        puVar7 = &UNK_000316b8;
        goto LAB_00024aa2;
      }
      iVar3 = FUN_00025594(pcVar6[iVar2]);
      iVar2 = iVar2 + 1;
    } while (iVar3 != 0);
switchD_0002459a_caseD_54:
    if (__stack_chk_guard == iVar1) {
      return puVar11;
    }
    break;
  case 'h':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "unsigned char";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 'i':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 'j':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard != iVar1) break;
    pcVar8 = "u";
    goto LAB_000248d8;
  case 'l':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard != iVar1) break;
    pcVar8 = "l";
LAB_000248d8:
    pcVar9 = pcVar8 + 1;
LAB_000249d0:
    iVar1 = __stack_chk_guard;
    uVar12 = FUN_00020d6c(auStack_b0 + 0x84,param_1,1);
    if (unaff_r5 != unaff_r6) {
      uVar12 = *param_1;
    }
    pcVar6 = (char *)uVar12;
    if ((unaff_r5 == unaff_r6 || pcVar6 == (char *)((ulonglong)uVar12 >> 0x20)) || (*pcVar6 != 'E'))
    {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      *(char **)param_1 = pcVar6 + 1;
      puVar11 = (undefined4 *)FUN_000220a8(param_1 + 0x33,0x18);
      puVar11[2] = pcVar8;
      puVar11[3] = pcVar9;
      puVar11[4] = unaff_r5;
      puVar11[5] = unaff_r6;
      *puVar11 = &PTR_LAB_00022116_1_00031650;
      puVar11[1] = 0x1010145;
    }
    if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(puVar11);
    }
    return puVar11;
  case 'm':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard != iVar1) break;
    pcVar8 = "ul";
    goto LAB_000249ae;
  case 'n':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "__int128";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 'o':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "unsigned __int128";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 's':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "short";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 't':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "unsigned short";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 'w':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "wchar_t";
      pcVar9 = "";
      goto LAB_000249d0;
    }
    break;
  case 'x':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard != iVar1) break;
    pcVar8 = "ll";
LAB_000249ae:
    pcVar9 = pcVar8 + 2;
    goto LAB_000249d0;
  case 'y':
    *(char **)param_1 = pcVar9 + 2;
    if (__stack_chk_guard == iVar1) {
      pcVar8 = "ull";
      pcVar9 = "";
      goto LAB_000249d0;
    }
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(iVar1,__stack_chk_guard);
code_r0x000247ee:
  iVar3 = FUN_00025594(pcVar6[iVar2]);
  iVar2 = iVar2 + 1;
  if (iVar3 == 0) goto switchD_0002459a_caseD_54;
  goto LAB_000247e8;
}


// ==== FUN_00024b74 @ 00024b74

void FUN_00024b74(undefined4 *param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  char *pcVar2;
  int local_1c;
  int iStack_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  local_1c = param_2;
  iStack_18 = param_3;
  iVar1 = FUN_0002079c(param_1,&DAT_00016b6f,&DAT_00016b71,param_4,param_1);
  if (iVar1 == 0) {
    iVar1 = FUN_0002079c(param_1,&DAT_00016903,&DAT_00016905);
    if ((((iVar1 == 0) || (FUN_00020d6c(&local_1c,param_1,0), local_1c == iStack_18)) ||
        (pcVar2 = (char *)*param_1, pcVar2 == (char *)param_1[1])) || (*pcVar2 != 'p'))
    goto LAB_00024bfa;
    *param_1 = pcVar2 + 1;
  }
  FUN_000225a4(param_1);
  FUN_00020d6c(&local_1c,param_1,0);
  pcVar2 = (char *)*param_1;
  if ((pcVar2 != (char *)param_1[1]) && (*pcVar2 == '_')) {
    *param_1 = pcVar2 + 1;
    FUN_00025fe0(param_1,&local_1c);
  }
LAB_00024bfa:
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_14);
  }
  return;
}


// ==== FUN_00024cb8 @ 00024cb8

void FUN_00024cb8(int param_1,undefined4 *param_2,undefined1 *param_3,undefined1 *param_4)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined4 *puVar3;
  
  puVar3 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  puVar3[1] = 0x1010139;
  uVar1 = *param_3;
  *puVar3 = &PTR_LAB_00022116_1_00031b58;
  puVar3[2] = *param_2;
  uVar2 = *param_4;
  *(undefined1 *)(puVar3 + 3) = uVar1;
  *(undefined1 *)((int)puVar3 + 0xd) = uVar2;
  return;
}


// ==== FUN_00024e90 @ 00024e90

undefined4 * FUN_00024e90(int param_1,undefined4 *param_2,char *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  size_t sVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
  uVar4 = *param_2;
  sVar2 = strlen(param_3);
  puVar1[1] = 0x1010133;
  *puVar1 = &PTR_LAB_00022116_1_00031ca8;
  uVar3 = *param_4;
  puVar1[4] = param_3 + sVar2;
  puVar1[5] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = param_3;
  return puVar1;
}


// ==== FUN_00024edc @ 00024edc

/* WARNING: Removing unreachable block (ram,0x00024f54) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 * FUN_00024edc(byte *param_1)

{
  uint uVar1;
  byte *pbVar2;
  char cVar3;
  byte bVar4;
  bool bVar5;
  char *pcVar6;
  undefined4 *puVar7;
  void *__dest;
  byte *pbVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  char *pcVar12;
  int iVar13;
  undefined4 *puVar14;
  int iVar15;
  byte *pbVar16;
  undefined4 uVar17;
  int **ppiVar18;
  byte *pbVar19;
  char *pcVar20;
  byte *pbVar21;
  undefined *puVar22;
  undefined *puVar23;
  int *unaff_r4;
  uint uVar24;
  int *unaff_r5;
  int *unaff_r6;
  size_t sVar25;
  char *pcVar26;
  byte *pbVar27;
  undefined8 uVar28;
  undefined *puStack_4c;
  undefined *puStack_48;
  undefined *puStack_44;
  undefined1 uStack_39;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 local_24;
  
  pbVar21 = __stack_chk_guard;
  pcVar12 = *(char **)param_1;
  if (((*(char **)(param_1 + 4) != pcVar12) && (*pcVar12 == 'd')) &&
     ((int)*(char **)(param_1 + 4) - (int)pcVar12 != 1)) {
    cVar3 = pcVar12[1];
    if (cVar3 == 'X') {
      *(char **)param_1 = pcVar12 + 2;
      iVar13 = FUN_00022cf0(param_1);
      if (((iVar13 != 0) && (iVar9 = FUN_00022cf0(param_1), iVar9 != 0)) &&
         (iVar15 = FUN_00024edc(param_1), iVar15 != 0)) {
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
        *puVar14 = &PTR_LAB_00022116_1_00031d50;
        puVar14[1] = 0x101014a;
        puVar14[2] = iVar13;
        puVar14[3] = iVar9;
        puVar14[4] = iVar15;
        goto LAB_00024fc8;
      }
    }
    else if (cVar3 == 'x') {
      *(char **)param_1 = pcVar12 + 2;
      iVar13 = FUN_00022cf0(param_1);
      if ((iVar13 != 0) && (local_24 = (byte *)FUN_00024edc(param_1), local_24 != (byte *)0x0)) {
        puVar14 = (undefined4 *)0x1;
LAB_00024fb2:
        uStack_28 = (byte *)CONCAT13((char)puVar14,(undefined3)uStack_28);
        puVar14 = (undefined4 *)
                  FUN_00027484(param_1,(int)register0x00000054 + -0x20,&local_24,(int)&uStack_28 + 3
                              );
        goto LAB_00024fc8;
      }
    }
    else {
      if (cVar3 != 'i') goto code_r0x00022cf0;
      *(char **)param_1 = pcVar12 + 2;
      iVar13 = FUN_00026790(param_1);
      if (iVar13 != 0) {
        local_24 = (byte *)FUN_00024edc(param_1);
        puVar14 = (undefined4 *)0x0;
        if (local_24 == (byte *)0x0) goto LAB_00024fc8;
        goto LAB_00024fb2;
      }
    }
    puVar14 = (undefined4 *)0x0;
LAB_00024fc8:
    if (__stack_chk_guard != pbVar21) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(puVar14);
    }
    return puVar14;
  }
code_r0x00022cf0:
  uStack_28 = __stack_chk_guard;
  uStack_39 = FUN_0002079c(param_1,&DAT_0001602f,&DAT_00016031);
  pbVar21 = __stack_chk_guard;
  pbVar27 = *(byte **)param_1;
  pbVar16 = *(byte **)(param_1 + 4);
  pbVar19 = pbVar16 + -(int)pbVar27;
  if (pbVar19 < (byte *)0x2) goto LAB_00022d28;
  pbVar8 = param_1;
  piStack_2c = unaff_r5;
  switch((uint)*pbVar27) {
  case 0x4c:
    if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
    uStack_28 = __stack_chk_guard;
    pcVar20 = *(char **)param_1;
    pcVar12 = *(char **)(param_1 + 4);
    piStack_30 = unaff_r5;
    if ((pcVar20 == pcVar12) || (*pcVar20 != 'L')) goto LAB_00024ab6;
    pcVar6 = pcVar20 + 1;
    *(char **)param_1 = pcVar6;
    if (pcVar12 == pcVar6) {
switchD_0002459a_caseD_42:
      piStack_2c = unaff_r6;
      iVar13 = FUN_00020e00(param_1);
      if (iVar13 == 0) goto LAB_00024ab6;
      puVar14 = (undefined4 *)0x0;
      FUN_00020d6c(&piStack_30,param_1,0);
      piVar11 = piStack_30;
      if (piStack_30 != piStack_2c) {
        pcVar12 = *(char **)param_1;
        if ((pcVar12 == *(char **)(param_1 + 4)) || (*pcVar12 != 'E')) goto LAB_00024ab6;
        *(char **)param_1 = pcVar12 + 1;
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
        puVar14[2] = iVar13;
        puVar14[3] = piVar11;
        puVar14[4] = piStack_2c;
        *puVar14 = &PTR_LAB_00022116_1_00031960;
        puVar14[1] = 0x1010144;
      }
      goto switchD_0002459a_caseD_54;
    }
    puVar14 = (undefined4 *)0x0;
    switch(*pcVar6) {
    case 'A':
      iVar13 = FUN_00020e00(param_1);
      if (((iVar13 == 0) || (pcVar12 = *(char **)param_1, pcVar12 == *(char **)(param_1 + 4))) ||
         (*pcVar12 != 'E')) goto LAB_00024ab6;
      *(char **)param_1 = pcVar12 + 1;
      puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
      uVar17 = 0x1010142;
      puVar23 = &UNK_00031760;
LAB_0002472e:
      *puVar14 = puVar23 + 8;
      puVar14[1] = uVar17;
      puVar14[2] = iVar13;
      goto switchD_0002459a_caseD_54;
    default:
      goto switchD_0002459a_caseD_42;
    case 'D':
      iVar13 = FUN_0002079c(param_1,&DAT_000165aa,&DAT_000165ad);
      if (iVar13 != 0) {
        if (__stack_chk_guard == uStack_28) {
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          sVar25 = strlen("nullptr");
          puVar14[2] = "nullptr";
          puVar14[3] = "nullptr" + sVar25;
          *puVar14 = &PTR_LAB_00022116_1_000315a8;
          puVar14[1] = 0x1010107;
          return puVar14;
        }
        break;
      }
      goto LAB_00024ab6;
    case 'T':
      goto switchD_0002459a_caseD_54;
    case 'U':
      if ((1 < (uint)((int)pcVar12 - (int)pcVar6)) && (pcVar20[2] == 'l')) {
        puVar14 = (undefined4 *)0x0;
        iVar13 = FUN_00025258(param_1,0);
        if (iVar13 == 0) goto switchD_0002459a_caseD_54;
        pcVar12 = *(char **)param_1;
        if ((pcVar12 != *(char **)(param_1 + 4)) && (*pcVar12 == 'E')) {
          *(char **)param_1 = pcVar12 + 1;
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
          uVar17 = 0x1010143;
          puVar23 = &UNK_00031920;
          goto LAB_0002472e;
        }
      }
      goto LAB_00024ab6;
    case '_':
      iVar13 = FUN_0002079c(param_1,&DAT_000168e5,&DAT_000168e7);
      if ((((iVar13 == 0) ||
           (puVar14 = (undefined4 *)FUN_0002080c(param_1), puVar14 == (undefined4 *)0x0)) ||
          (pcVar12 = *(char **)param_1, pcVar12 == *(char **)(param_1 + 4))) || (*pcVar12 != 'E'))
      goto LAB_00024ab6;
      *(char **)param_1 = pcVar12 + 1;
      goto switchD_0002459a_caseD_54;
    case 'a':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard != pbVar21) break;
      pcVar12 = "signed char";
      pcVar20 = "";
      goto LAB_000249d0;
    case 'b':
      iVar13 = FUN_0002079c(param_1,&DAT_000171aa,&DAT_000171ad);
      if (iVar13 == 0) {
        iVar13 = FUN_0002079c(param_1,&DAT_0001637c,&DAT_0001637f);
        if (iVar13 == 0) goto LAB_00024ab6;
        piStack_30 = (int *)0x1;
      }
      else {
        piStack_30 = (int *)0x0;
      }
      puVar14 = (undefined4 *)FUN_000251f0(param_1,&piStack_30);
      goto switchD_0002459a_caseD_54;
    case 'c':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "char";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 'd':
      pcVar6 = pcVar20 + 2;
      *(char **)param_1 = pcVar6;
      if (0x10 < (uint)((int)pcVar12 - (int)pcVar6)) {
        pcVar26 = pcVar20 + 0x12;
        iVar13 = 0;
        puVar14 = (undefined4 *)0x0;
LAB_000247e8:
        if (iVar13 != 0x10) goto code_r0x000247ee;
        *(char **)param_1 = pcVar26;
        if ((pcVar26 != pcVar12) && (*pcVar26 == 'E')) {
          *(char **)param_1 = pcVar20 + 0x13;
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          uVar17 = 0x1010147;
          puVar23 = &UNK_000316f0;
LAB_00024aa2:
          *puVar14 = puVar23 + 8;
          puVar14[1] = uVar17;
          puVar14[2] = pcVar20 + 2;
          puVar14[3] = pcVar26;
          goto switchD_0002459a_caseD_54;
        }
      }
LAB_00024ab6:
      puVar14 = (undefined4 *)0x0;
      goto switchD_0002459a_caseD_54;
    case 'e':
      pcVar6 = pcVar20 + 2;
      *(char **)param_1 = pcVar6;
      if ((uint)((int)pcVar12 - (int)pcVar6) < 0x11) goto LAB_00024ab6;
      pcVar26 = pcVar20 + 0x12;
      iVar13 = 0;
      puVar14 = (undefined4 *)0x0;
      do {
        if (iVar13 == 0x10) {
          *(char **)param_1 = pcVar26;
          if ((pcVar26 == pcVar12) || (*pcVar26 != 'E')) goto LAB_00024ab6;
          *(char **)param_1 = pcVar20 + 0x13;
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          uVar17 = 0x1010148;
          puVar23 = &UNK_00031728;
          goto LAB_00024aa2;
        }
        iVar9 = FUN_00025594(pcVar6[iVar13]);
        iVar13 = iVar13 + 1;
      } while (iVar9 != 0);
      goto switchD_0002459a_caseD_54;
    case 'f':
      pcVar6 = pcVar20 + 2;
      *(char **)param_1 = pcVar6;
      if ((uint)((int)pcVar12 - (int)pcVar6) < 9) goto LAB_00024ab6;
      pcVar26 = pcVar20 + 10;
      iVar13 = 0;
      puVar14 = (undefined4 *)0x0;
      do {
        if (iVar13 == 8) {
          *(char **)param_1 = pcVar26;
          if ((pcVar26 == pcVar12) || (*pcVar26 != 'E')) goto LAB_00024ab6;
          *(char **)param_1 = pcVar20 + 0xb;
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
          uVar17 = 0x1010146;
          puVar23 = &UNK_000316b8;
          goto LAB_00024aa2;
        }
        iVar9 = FUN_00025594(pcVar6[iVar13]);
        iVar13 = iVar13 + 1;
      } while (iVar9 != 0);
switchD_0002459a_caseD_54:
      if (__stack_chk_guard == uStack_28) {
        return puVar14;
      }
      break;
    case 'h':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "unsigned char";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 'i':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 'j':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard != pbVar21) break;
      pcVar12 = "u";
      goto LAB_000248d8;
    case 'l':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard != pbVar21) break;
      pcVar12 = "l";
LAB_000248d8:
      pcVar20 = pcVar12 + 1;
LAB_000249d0:
      local_24 = __stack_chk_guard;
      uStack_28 = (byte *)unaff_r6;
      uVar28 = FUN_00020d6c(&piStack_2c,param_1,1);
      if ((byte *)piStack_2c != uStack_28) {
        uVar28 = *(undefined8 *)param_1;
      }
      pcVar6 = (char *)uVar28;
      if (((byte *)piStack_2c == uStack_28 || pcVar6 == (char *)((ulonglong)uVar28 >> 0x20)) ||
         (*pcVar6 != 'E')) {
        puVar14 = (undefined4 *)0x0;
      }
      else {
        *(char **)param_1 = pcVar6 + 1;
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
        puVar14[2] = pcVar12;
        puVar14[3] = pcVar20;
        puVar14[4] = piStack_2c;
        puVar14[5] = uStack_28;
        *puVar14 = &PTR_LAB_00022116_1_00031650;
        puVar14[1] = 0x1010145;
      }
      if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail(puVar14);
      }
      return puVar14;
    case 'm':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard != pbVar21) break;
      pcVar12 = "ul";
      goto LAB_000249ae;
    case 'n':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "__int128";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 'o':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "unsigned __int128";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 's':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "short";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 't':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "unsigned short";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 'w':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "wchar_t";
        pcVar20 = "";
        goto LAB_000249d0;
      }
      break;
    case 'x':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard != pbVar21) break;
      pcVar12 = "ll";
LAB_000249ae:
      pcVar20 = pcVar12 + 2;
      goto LAB_000249d0;
    case 'y':
      *(char **)param_1 = pcVar20 + 2;
      if (__stack_chk_guard == pbVar21) {
        pcVar12 = "ull";
        pcVar20 = "";
        goto LAB_000249d0;
      }
    }
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uStack_28,__stack_chk_guard);
  case 0x4d:
  case 0x4e:
  case 0x4f:
  case 0x50:
  case 0x51:
  case 0x52:
  case 0x53:
  case 0x55:
  case 0x56:
  case 0x57:
  case 0x58:
  case 0x59:
  case 0x5a:
  case 0x5b:
  case 0x5c:
  case 0x5d:
  case 0x5e:
  case 0x5f:
  case 0x60:
  case 0x62:
  case 0x68:
  case 0x6a:
  case 0x6b:
    goto switchD_00022d78_caseD_1;
  case 0x54:
    if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
    local_24 = __stack_chk_guard;
    pcVar20 = *(char **)param_1;
    pcVar12 = *(char **)(param_1 + 4);
    piStack_30 = unaff_r4;
    uStack_28 = (byte *)unaff_r6;
    if (pcVar20 == pcVar12) goto LAB_000227a0;
    puVar14 = (undefined4 *)0x0;
    if (*pcVar20 != 'T') goto LAB_000227a2;
    pcVar6 = pcVar20 + 1;
    *(char **)param_1 = pcVar6;
    uStack_28 = (byte *)0x0;
    if (pcVar6 == pcVar12) {
      uVar24 = 0;
LAB_000226f4:
      piStack_2c = (int *)0x0;
      iVar13 = FUN_00022aae(param_1,&piStack_2c);
      if (iVar13 == 0) {
        piStack_2c = (int *)((int)piStack_2c + 1);
        pcVar6 = *(char **)param_1;
        if ((pcVar6 != *(char **)(param_1 + 4)) && (*pcVar6 == '_')) goto LAB_00022714;
      }
    }
    else {
      uVar24 = 0;
      if (*pcVar6 == 'L') {
        *(char **)param_1 = pcVar20 + 2;
        iVar13 = FUN_00022aae(param_1,&uStack_28);
        if (iVar13 == 0) {
          pcVar6 = *(char **)param_1;
          pcVar12 = *(char **)(param_1 + 4);
          if ((pcVar6 != pcVar12) && (*pcVar6 == '_')) {
            pcVar6 = pcVar6 + 1;
            *(char **)param_1 = pcVar6;
            uVar24 = (int)uStack_28 + 1;
            goto LAB_000226e0;
          }
        }
      }
      else {
LAB_000226e0:
        piStack_2c = (int *)0x0;
        if ((pcVar6 == pcVar12) || (*pcVar6 != '_')) goto LAB_000226f4;
LAB_00022714:
        piVar11 = piStack_2c;
        *(char **)param_1 = pcVar6 + 1;
        if ((param_1[0x185] != 0) && (uVar24 == 0)) {
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
          *(undefined1 *)(puVar14 + 4) = 0;
          puVar14[2] = piVar11;
          puVar14[3] = 0;
          *puVar14 = &PTR_FUN_00022bb0_1_00031618;
          puVar14[1] = 0x2020224;
          puVar7 = *(undefined4 **)(param_1 + 0x16c);
          if (puVar7 == *(undefined4 **)(param_1 + 0x170)) {
            pbVar21 = *(byte **)(param_1 + 0x168);
            sVar25 = (int)puVar7 - (int)pbVar21;
            if (pbVar21 == param_1 + 0x174) {
              __dest = malloc(sVar25 * 2);
              if (__dest == (void *)0x0) goto LAB_0002281a;
              if (sVar25 != 0) {
                memmove(__dest,pbVar21,sVar25);
              }
              *(void **)(param_1 + 0x168) = __dest;
            }
            else {
              __dest = realloc(pbVar21,sVar25 * 2);
              *(void **)(param_1 + 0x168) = __dest;
              if (__dest == (void *)0x0) {
LAB_0002281a:
                    /* WARNING: Subroutine does not return */
                FUN_00020238();
              }
            }
            *(void **)(param_1 + 0x170) = (void *)((int)__dest + ((int)sVar25 >> 1) * 4);
            puVar7 = (undefined4 *)((int)__dest + ((int)sVar25 >> 2) * 4);
          }
          *(undefined4 **)(param_1 + 0x16c) = puVar7 + 1;
          *puVar7 = puVar14;
          goto LAB_000227a2;
        }
        uVar1 = *(int *)(param_1 + 0x150) - *(int *)(param_1 + 0x14c) >> 2;
        if (((uVar24 < uVar1) &&
            (piVar11 = *(int **)(*(int *)(param_1 + 0x14c) + uVar24 * 4), piVar11 != (int *)0x0)) &&
           (piStack_2c < (int *)(piVar11[1] - *piVar11 >> 2))) {
          puVar14 = *(undefined4 **)(*piVar11 + (int)piStack_2c * 4);
          goto LAB_000227a2;
        }
        if ((*(uint *)(param_1 + 0x188) == uVar24) && (uVar24 <= uVar1)) {
          if (uVar24 == uVar1) {
            piStack_30 = (int *)0x0;
            FUN_00022b02(param_1 + 0x14c,&piStack_30);
          }
          puVar14 = (undefined4 *)FUN_00022b78(param_1,&DAT_00016375);
          goto LAB_000227a2;
        }
      }
    }
LAB_000227a0:
    puVar14 = (undefined4 *)0x0;
LAB_000227a2:
    if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(local_24);
    }
    return puVar14;
  case 0x61:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x4e) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016689;
      puVar22 = &UNK_0001668b;
      goto LAB_00023e7a;
    }
    if (bVar4 == 0x53) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = uStack_28;
      if (__stack_chk_guard == uStack_28) {
        puVar22 = &UNK_00016ab1;
        puVar23 = &DAT_00016ab0;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar4 == 0x7a) {
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00022cf0(param_1);
    }
    else {
      if (bVar4 == 100) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard == uStack_28) {
          puVar22 = &UNK_0001702b;
          puVar23 = &DAT_0001702a;
          goto LAB_00023e4c;
        }
        goto LAB_00022d44;
      }
      if (bVar4 == 0x6e) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard == uStack_28) {
          puVar22 = &UNK_0001702b;
          puVar23 = &DAT_0001702a;
          goto LAB_00023e7a;
        }
        goto LAB_00022d44;
      }
      if (bVar4 != 0x74) {
        if (bVar4 == 0x61) {
          *(byte **)param_1 = pbVar27 + 2;
          pbVar8 = uStack_28;
          if (__stack_chk_guard == uStack_28) {
            puVar22 = &DAT_00016fb0;
            puVar23 = &DAT_00016fae;
            goto LAB_00023e7a;
          }
          goto LAB_00022d44;
        }
        break;
      }
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00020e00(param_1);
    }
    if (piStack_38 == (int *)0x0) break;
    puVar14 = (undefined4 *)FUN_00024504(param_1,"alignof (",&piStack_38);
    goto LAB_00022d2a;
  case 99:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x76) {
      iVar13 = FUN_0002079c(param_1,&DAT_00016397,&DAT_00016399);
      puVar14 = (undefined4 *)0x0;
      if (iVar13 == 0) goto LAB_00022d2a;
      bVar4 = param_1[0x184];
      param_1[0x184] = 0;
      iVar13 = FUN_00020e00(param_1);
      param_1[0x184] = bVar4;
      if (iVar13 != 0) {
        pcVar20 = *(char **)param_1;
        pcVar12 = *(char **)(param_1 + 4);
        if ((pcVar20 == pcVar12) || (*pcVar20 != '_')) {
          piStack_30 = (int *)FUN_00022cf0(param_1);
          if (piStack_30 != (int *)0x0) {
            FUN_00026444(&piStack_38,param_1,&piStack_30,&piStack_2c);
LAB_0002416e:
            puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
            puVar14[1] = 0x101013c;
            puVar14[2] = iVar13;
            puVar23 = &UNK_00031b18;
LAB_00024186:
            *puVar14 = puVar23 + 8;
            puVar14[4] = iStack_34;
            puVar14[3] = piStack_38;
            goto LAB_00022d2a;
          }
        }
        else {
          iVar15 = *(int *)(param_1 + 0xc);
          iVar9 = *(int *)(param_1 + 8);
          pcVar20 = pcVar20 + 1;
          *(char **)param_1 = pcVar20;
          while( true ) {
            if ((pcVar20 != pcVar12) && (*pcVar20 == 'E')) {
              *(char **)param_1 = pcVar20 + 1;
              FUN_00021f18(&piStack_38,param_1,iVar15 - iVar9 >> 2);
              goto LAB_0002416e;
            }
            piStack_38 = (int *)FUN_00022cf0(param_1);
            if (piStack_38 == (int *)0x0) break;
            FUN_00021ea4(param_1 + 8,&piStack_38);
            pcVar20 = *(char **)param_1;
            pcVar12 = *(char **)(param_1 + 4);
          }
        }
      }
    }
    else if (bVar4 == 0x6c) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_00022cf0(param_1);
      if (iVar13 != 0) {
        iVar9 = *(int *)(param_1 + 8);
        iVar15 = *(int *)(param_1 + 0xc);
        while( true ) {
          pcVar12 = *(char **)param_1;
          if ((pcVar12 != *(char **)(param_1 + 4)) && (*pcVar12 == 'E')) {
            *(char **)param_1 = pcVar12 + 1;
            FUN_00021f18(&piStack_38,param_1,iVar15 - iVar9 >> 2);
            puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
            puVar14[1] = 0x1010137;
            puVar14[2] = iVar13;
            puVar23 = &UNK_00031ae0;
            goto LAB_00024186;
          }
          piStack_38 = (int *)FUN_00022cf0(param_1);
          if (piStack_38 == (int *)0x0) break;
          FUN_00021ea4(param_1 + 8,&piStack_38);
        }
      }
    }
    else {
      if (bVar4 == 0x6d) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard == uStack_28) {
          puVar22 = &UNK_000165a6;
          puVar23 = &DAT_000165a5;
          goto LAB_00023e7a;
        }
        goto LAB_00022d44;
      }
      if (bVar4 == 0x6f) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &DAT_0001702c;
        goto LAB_00023e48;
      }
      if (bVar4 == 99) {
        *(byte **)param_1 = pbVar27 + 2;
        iVar13 = FUN_00020e00(param_1);
        if ((iVar13 != 0) && (iVar9 = FUN_00022cf0(param_1), iVar9 != 0)) {
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
          pcVar12 = "const_cast";
          pcVar20 = "";
          goto LAB_00023e14;
        }
      }
    }
    break;
  case 100:
    bVar4 = pbVar27[1];
    puVar14 = (undefined4 *)0x0;
    switch(bVar4) {
    case 0x6c:
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00022cf0(param_1);
      puVar14 = (undefined4 *)0x0;
      if (piStack_38 != (int *)0x0) {
        piStack_30 = (int *)((uint)piStack_30 & 0xffffff00);
LAB_000233d6:
        puVar14 = (undefined4 *)FUN_00024cb8(param_1,&piStack_38,&uStack_39,&piStack_30);
      }
      break;
    case 0x6d:
    case 0x6f:
    case 0x70:
    case 0x71:
    case 0x72:
    case 0x75:
      break;
    case 0x6e:
joined_r0x0002331c:
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      local_24 = __stack_chk_guard;
      uStack_28 = (byte *)0x0;
      iVar13 = FUN_0002079c(param_1,&DAT_00016e47,&DAT_00016e4a);
      if (iVar13 == 0) {
        iVar13 = FUN_0002079c(param_1,&DAT_0001602f,&DAT_00016031);
        iVar9 = FUN_0002079c(param_1,&DAT_00016c93,&DAT_00016c95);
        if (iVar9 == 0) {
          piVar11 = (int *)FUN_0002664c(param_1);
          uStack_28 = (byte *)piVar11;
          if (iVar13 == 1 && piVar11 != (int *)0x0) {
            piVar11 = (int *)FUN_00026764(param_1,&uStack_28);
          }
          goto LAB_00024e60;
        }
        if ((*(byte **)(param_1 + 4) == *(byte **)param_1) ||
           (**(byte **)param_1 - 0x3a < 0xfffffff6)) {
          uStack_28 = (byte *)FUN_00026528(param_1);
          if (uStack_28 == (byte *)0x0) goto LAB_00024e5e;
          if ((*(char **)(param_1 + 4) != *(char **)param_1) && (**(char **)param_1 == 'I')) {
            piStack_2c = (int *)FUN_000222e8(param_1,0);
            if (piStack_2c == (int *)0x0) goto LAB_00024e5e;
            uStack_28 = (byte *)FUN_00022574(param_1,&uStack_28,&piStack_2c);
          }
        }
        else {
          piVar11 = (int *)0x0;
          do {
            piVar10 = (int *)FUN_000265b4(param_1);
            piStack_2c = piVar10;
            if (piVar10 == (int *)0x0) goto LAB_00024e5e;
            if (piVar11 == (int *)0x0) {
              if (iVar13 != 0) {
                piVar10 = (int *)FUN_00026764(param_1,&piStack_2c);
              }
            }
            else {
              piVar10 = (int *)FUN_0002661c(param_1,&uStack_28,&piStack_2c);
            }
            pcVar12 = *(char **)param_1;
            piVar11 = piVar10;
            uStack_28 = (byte *)piVar10;
          } while ((pcVar12 == *(char **)(param_1 + 4)) || (*pcVar12 != 'E'));
LAB_00024e44:
          *(char **)param_1 = pcVar12 + 1;
        }
        piStack_2c = (int *)FUN_0002664c(param_1);
        if (piStack_2c != (int *)0x0) {
          piVar11 = (int *)FUN_0002661c(param_1,&uStack_28,&piStack_2c);
          goto LAB_00024e60;
        }
      }
      else {
        uStack_28 = (byte *)FUN_00026528(param_1);
        if (uStack_28 != (byte *)0x0) {
          if ((*(char **)(param_1 + 4) != *(char **)param_1) && (**(char **)param_1 == 'I')) {
            piStack_2c = (int *)FUN_000222e8(param_1,0);
            if (piStack_2c == (int *)0x0) goto LAB_00024e5e;
            uStack_28 = (byte *)FUN_00022574(param_1,&uStack_28,&piStack_2c);
          }
          while( true ) {
            pcVar12 = *(char **)param_1;
            if ((pcVar12 != *(char **)(param_1 + 4)) && (*pcVar12 == 'E')) goto LAB_00024e44;
            piStack_2c = (int *)FUN_000265b4(param_1);
            if (piStack_2c == (int *)0x0) break;
            uStack_28 = (byte *)FUN_0002661c(param_1,&uStack_28,&piStack_2c);
          }
        }
      }
LAB_00024e5e:
      piVar11 = (int *)0x0;
LAB_00024e60:
      if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail(piVar11);
      }
      return piVar11;
    case 0x73:
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00022cf0(param_1);
      if ((piStack_38 == (int *)0x0) ||
         (piStack_30 = (int *)FUN_00022cf0(param_1), piStack_30 == (int *)0x0)) goto LAB_00022d28;
      puVar23 = &DAT_0001697f;
LAB_00023d46:
      puVar14 = (undefined4 *)FUN_00024e90(param_1,&piStack_38,puVar23,&piStack_30);
      break;
    case 0x74:
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_00022cf0(param_1);
      if ((iVar13 == 0) || (iVar9 = FUN_00022cf0(param_1), iVar9 == 0)) goto LAB_00022d28;
      puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
      puVar14[2] = iVar13;
      puVar14[3] = &DAT_00015eae;
      *puVar14 = &PTR_LAB_00022116_1_00031ca8;
      puVar14[1] = 0x1010133;
      puVar14[4] = &DAT_00015eaf;
      puVar14[5] = iVar9;
      break;
    case 0x76:
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard == uStack_28) {
        puVar23 = &DAT_00015eed;
        puVar22 = &UNK_00015eee;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    default:
      if (bVar4 == 0x56) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = param_1;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &UNK_000162c8;
        goto LAB_00023e78;
      }
      if (bVar4 == 0x65) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &DAT_000164bb;
LAB_00023e48:
        puVar22 = puVar23 + 1;
        goto LAB_00023e4c;
      }
      if (bVar4 == 99) {
        *(byte **)param_1 = pbVar27 + 2;
        iVar13 = FUN_00020e00(param_1);
        if ((iVar13 == 0) || (iVar9 = FUN_00022cf0(param_1), iVar9 == 0)) goto LAB_00022d28;
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
        pcVar12 = "dynamic_cast";
        pcVar20 = "";
LAB_00023e14:
        *puVar14 = &PTR_LAB_00022116_1_00031ab0;
        puVar14[1] = 0x1010135;
        puVar14[2] = pcVar12;
        puVar14[3] = pcVar20;
        puVar14[4] = iVar13;
        puVar14[5] = iVar9;
      }
      else if (bVar4 == 0x61) {
        *(byte **)param_1 = pbVar27 + 2;
        piStack_38 = (int *)FUN_00022cf0(param_1);
        if (piStack_38 != (int *)0x0) {
          piStack_30 = (int *)CONCAT31(piStack_30._1_3_,1);
          goto LAB_000233d6;
        }
        goto LAB_00022d28;
      }
    }
    goto LAB_00022d2a;
  case 0x65:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x4f) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_000168f5;
    }
    else {
      if (bVar4 != 0x71) {
        if (bVar4 == 0x6f) {
          *(byte **)param_1 = pbVar27 + 2;
          pbVar8 = param_1;
          if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
          puVar23 = &UNK_00016b62;
          goto LAB_00023576;
        }
        break;
      }
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_000168f8;
    }
    goto LAB_00023e78;
  case 0x66:
    puStack_44 = &DAT_00016ab0;
    pbVar2 = pbVar27 + 1;
    puStack_4c = &DAT_00015eed;
    puStack_48 = &DAT_000165a5;
    if ((*pbVar2 == 0x70) ||
       (((*pbVar2 == 0x4c && ((byte *)0x2 < pbVar19)) &&
        (pbVar19 = (byte *)(pbVar27[2] - 0x3a), (byte *)0xfffffff5 < pbVar19)))) {
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      iVar9 = (int)register0x00000054 + -0x1c;
      iVar13 = FUN_0002079c(param_1,&DAT_00016b6f,&DAT_00016b71);
      if (iVar13 == 0) {
        iVar13 = FUN_0002079c(param_1,&DAT_00016903,&DAT_00016905);
        if (iVar13 != 0) {
          puVar14 = (undefined4 *)0x0;
          FUN_00020d6c(iVar9,param_1,0);
          if (pbVar21 == pbVar19) goto LAB_00024bfa;
          pcVar12 = *(char **)param_1;
          if ((pcVar12 != *(char **)(param_1 + 4)) && (*pcVar12 == 'p')) {
            *(char **)param_1 = pcVar12 + 1;
            goto LAB_00024b92;
          }
        }
      }
      else {
LAB_00024b92:
        FUN_000225a4(param_1);
        puVar14 = (undefined4 *)0x0;
        FUN_00020d6c(iVar9,param_1,0);
        pcVar12 = *(char **)param_1;
        if (pcVar12 == *(char **)(param_1 + 4)) goto LAB_00024bfa;
        if (*pcVar12 == '_') {
          *(char **)param_1 = pcVar12 + 1;
          puVar14 = (undefined4 *)FUN_00025fe0(param_1,iVar9);
          goto LAB_00024bfa;
        }
      }
      puVar14 = (undefined4 *)0x0;
LAB_00024bfa:
      if (__stack_chk_guard != pbVar21) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail(pbVar21);
      }
      return puVar14;
    }
    if (pbVar27 != pbVar16) {
      *(byte **)param_1 = pbVar2;
    }
    if (pbVar27 != pbVar16 && pbVar16 != pbVar2) {
      bVar4 = *pbVar2;
      bVar5 = true;
      if (bVar4 != 0x4c) {
        if (bVar4 != 0x72) {
          if (bVar4 == 0x6c) goto LAB_00023f94;
          if (bVar4 != 0x52) break;
        }
        bVar5 = false;
      }
LAB_00023f94:
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_0002079c(param_1,&DAT_000160d1,&DAT_000160d3);
      puVar23 = &DAT_00016fae;
      if (iVar13 == 0) {
        iVar13 = FUN_0002079c(param_1,&DAT_00015e09,&DAT_00015e0b);
        if (iVar13 == 0) {
          iVar13 = FUN_0002079c(param_1,&DAT_00016edc,&DAT_00016ede);
          if (iVar13 == 0) {
            iVar13 = FUN_0002079c(param_1,&DAT_00015e0c,&DAT_00015e0e);
            if (iVar13 == 0) {
              iVar13 = FUN_0002079c(param_1,&DAT_000170fe,&DAT_00017100);
              if (iVar13 == 0) {
                iVar13 = FUN_0002079c(param_1,&DAT_00016e41,&DAT_00016e43);
                if (iVar13 != 0) {
                  puVar23 = &DAT_0001697f;
                  goto LAB_00023fae;
                }
                iVar13 = FUN_0002079c(param_1,&DAT_000164cc,&DAT_000164ce);
                if (iVar13 == 0) {
                  iVar13 = FUN_0002079c(param_1,&DAT_0001669a,&DAT_0001669c);
                  if (iVar13 == 0) {
                    iVar13 = FUN_0002079c(param_1,&DAT_00016f73,&DAT_00016f75);
                    if (iVar13 != 0) {
                      puStack_4c = &UNK_00016b62;
                      goto LAB_000241ba;
                    }
                    iVar13 = FUN_0002079c(param_1,&DAT_00016906,&DAT_00016908);
                    if (iVar13 == 0) {
                      iVar13 = FUN_0002079c(param_1,&DAT_00016edf,&DAT_00016ee1);
                      if (iVar13 == 0) {
                        iVar13 = FUN_0002079c(param_1,&DAT_000162d4,&DAT_000162d6);
                        if (iVar13 == 0) {
                          iVar13 = FUN_0002079c(param_1,&DAT_0001686c,&DAT_0001686e);
                          if (iVar13 != 0) {
                            puStack_4c = &DAT_000168fb;
                            goto LAB_000241ba;
                          }
                          iVar13 = FUN_0002079c(param_1,&DAT_000164cf,&DAT_000164d1);
                          if (iVar13 == 0) {
                            iVar13 = FUN_0002079c(param_1,&DAT_0001686f,&DAT_00016871);
                            if (iVar13 == 0) {
                              iVar13 = FUN_0002079c(param_1,&DAT_0001669d,&DAT_0001669f);
                              if (iVar13 != 0) {
                                puStack_4c = &UNK_00016be4;
LAB_00024278:
                                puVar23 = puStack_4c + 3;
                                goto LAB_00024096;
                              }
                              iVar13 = FUN_0002079c(param_1,&DAT_00016909,&DAT_0001690b);
                              if (iVar13 == 0) {
                                iVar13 = FUN_0002079c(param_1,&DAT_000167ba,&DAT_000167bc);
                                if (iVar13 == 0) {
                                  iVar13 = FUN_0002079c(param_1,&DAT_00016d7a,&DAT_00016d7c);
                                  if (iVar13 == 0) {
                                    iVar13 = FUN_0002079c(param_1,&DAT_00016be8,&DAT_00016bea);
                                    if (iVar13 != 0) {
                                      puStack_4c = &DAT_000164bb;
                                      goto LAB_000241ba;
                                    }
                                    iVar13 = FUN_0002079c(param_1,&DAT_00015e67,&DAT_00015e69);
                                    if (iVar13 == 0) {
                                      iVar13 = FUN_0002079c(param_1,&DAT_00015e6a,&DAT_00015e6c);
                                      if (iVar13 == 0) {
                                        iVar13 = FUN_0002079c(param_1,&DAT_00016985,&DAT_00016987);
                                        if (iVar13 == 0) {
                                          iVar13 = FUN_0002079c(param_1,&DAT_000167bd,&DAT_000167bf)
                                          ;
                                          if (iVar13 != 0) {
                                            puStack_4c = &UNK_00016fb1;
                                            goto LAB_000241ba;
                                          }
                                          iVar13 = FUN_0002079c(param_1,&DAT_000169ee,&DAT_000169f0)
                                          ;
                                          if (iVar13 == 0) {
                                            iVar13 = FUN_0002079c(param_1,&DAT_00016ac8,
                                                                  &DAT_00016aca);
                                            if (iVar13 != 0) {
                                              puStack_4c = &UNK_00016b67;
                                              goto LAB_000241ba;
                                            }
                                            iVar13 = FUN_0002079c(param_1,&DAT_000164d2,
                                                                  &DAT_000164d4);
                                            if (iVar13 == 0) {
                                              iVar13 = FUN_0002079c(param_1,&DAT_000169f1,
                                                                    &DAT_000169f3);
                                              if (iVar13 != 0) {
                                                puStack_4c = &UNK_00017359;
                                                goto LAB_000241ba;
                                              }
                                              iVar13 = FUN_0002079c(param_1,&DAT_000160d4,
                                                                    &DAT_000160d6);
                                              if (iVar13 == 0) {
                                                iVar13 = FUN_0002079c(param_1,&DAT_00016872,
                                                                      &DAT_00016874);
                                                if (iVar13 == 0) {
                                                  iVar13 = FUN_0002079c(param_1,&DAT_00016e44,
                                                                        &DAT_00016e46);
                                                  if (iVar13 == 0) break;
                                                  puStack_4c = &UNK_000169e3;
                                                  goto LAB_00024278;
                                                }
                                                puStack_4c = &UNK_0001603d;
                                              }
                                              else {
                                                puStack_4c = &UNK_00016ec9;
                                              }
                                            }
                                            else {
                                              puStack_4c = &UNK_000169e0;
                                            }
                                          }
                                          else {
                                            puStack_4c = &UNK_00016b64;
                                          }
                                        }
                                        else {
                                          puStack_4c = &UNK_00016ab2;
                                        }
                                      }
                                      else {
                                        puStack_4c = &UNK_00016e3e;
                                      }
                                    }
                                    else {
                                      puStack_4c = &UNK_000165a7;
                                    }
                                  }
                                  else {
                                    puStack_4c = &UNK_000162cb;
                                  }
                                  goto LAB_000241d2;
                                }
                                puStack_4c = &DAT_0001637a;
                              }
                              else {
                                puStack_4c = &DAT_00015e04;
                              }
                              goto LAB_000241ba;
                            }
                            puStack_4c = &UNK_00016d66;
                          }
                          else {
                            puStack_4c = &UNK_00016ec6;
                          }
                        }
                        else {
                          puStack_4c = &UNK_00015e55;
                        }
                      }
                      else {
                        puStack_4c = &UNK_000168f8;
                      }
                    }
                    else {
                      puStack_4c = &UNK_000168f5;
                    }
                  }
                  else {
                    puStack_4c = &UNK_000162c8;
                  }
LAB_000241d2:
                  puVar23 = puStack_4c + 2;
                }
                else {
LAB_000241ba:
                  puVar23 = puStack_4c + 1;
                }
                goto LAB_00024096;
              }
              puStack_4c = puStack_48;
            }
            else {
              puStack_4c = puStack_44;
            }
            puVar23 = puStack_4c + 1;
          }
          else {
            puVar23 = &UNK_0001668b;
            puStack_4c = &UNK_00016689;
          }
        }
        else {
          puVar23 = &UNK_0001702b;
          puStack_4c = &DAT_0001702a;
        }
      }
      else {
LAB_00023fae:
        puStack_4c = puVar23;
        puVar23 = puStack_4c + 2;
      }
LAB_00024096:
      iVar13 = FUN_00022cf0(param_1);
      if (iVar13 != 0) {
        iVar9 = iVar13;
        if (bVar4 == 0x52 || bVar4 == 0x4c) {
          iVar15 = FUN_00022cf0(param_1);
          if (iVar15 == 0) break;
          if (bVar5) {
            iVar9 = iVar15;
            iVar15 = iVar13;
          }
        }
        else {
          iVar15 = 0;
        }
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x1c);
        *(bool *)(puVar14 + 6) = bVar5;
        puVar14[5] = puVar23;
        *puVar14 = &PTR_LAB_00022116_1_000319d0;
        puVar14[1] = 0x101013e;
        puVar14[2] = iVar9;
        puVar14[3] = iVar15;
        puVar14[4] = puStack_4c;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x67:
    if (pbVar27[1] == 0x74) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &DAT_000168fb;
LAB_00023576:
      puVar22 = puVar23 + 1;
      goto LAB_00023e7a;
    }
    if (pbVar27[1] == 0x65) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00015e55;
      goto LAB_00023e78;
    }
    break;
  case 0x69:
    if (pbVar27[1] == 0x6c) {
      pbVar27 = pbVar27 + 2;
      iVar9 = *(int *)(param_1 + 0xc);
      iVar13 = *(int *)(param_1 + 8);
      *(byte **)param_1 = pbVar27;
      while( true ) {
        if ((pbVar27 != pbVar16) && (*pbVar27 == 0x45)) {
          *(byte **)param_1 = pbVar27 + 1;
          FUN_00021f18(&piStack_38,param_1,iVar9 - iVar13 >> 2);
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
          puVar14[1] = 0x101013d;
          puVar14[2] = 0;
          puVar23 = &UNK_00031d80;
          goto LAB_00024186;
        }
        piStack_38 = (int *)FUN_00024edc(param_1);
        if (piStack_38 == (int *)0x0) break;
        FUN_00021ea4(param_1 + 8,&piStack_38);
        pbVar27 = *(byte **)param_1;
        pbVar16 = *(byte **)(param_1 + 4);
      }
    }
    else if (pbVar27[1] == 0x78) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_00022cf0(param_1);
      if ((iVar13 != 0) && (iVar9 = FUN_00022cf0(param_1), iVar9 != 0)) {
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
        puVar14[2] = iVar13;
        puVar14[3] = iVar9;
        *puVar14 = &PTR_LAB_00022116_1_00031ce0;
        puVar14[1] = 0x1010130;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x6c:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x53) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016be4;
LAB_0002398a:
      puVar22 = puVar23 + 3;
      goto LAB_00023e7a;
    }
    if (bVar4 == 0x74) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &DAT_00015e04;
      goto LAB_00023576;
    }
    if (bVar4 == 0x73) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016d66;
    }
    else {
      if (bVar4 != 0x65) break;
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016ec6;
    }
    goto LAB_00023e78;
  case 0x6d:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x49) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_000162cb;
      goto LAB_00023e78;
    }
    if (bVar4 == 0x4c) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = uStack_28;
      if (__stack_chk_guard == uStack_28) {
        puVar23 = &UNK_000165a7;
        puVar22 = &UNK_000165a9;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar4 != 0x6d) {
      if (bVar4 == 0x6c) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &DAT_000164bb;
      }
      else {
        if (bVar4 != 0x69) break;
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &DAT_0001637a;
      }
      puVar22 = puVar23 + 1;
      goto LAB_00023e7a;
    }
    pbVar21 = pbVar27 + 2;
    *(byte **)param_1 = pbVar21;
    if ((pbVar21 != pbVar16) && (*pbVar21 == 0x5f)) {
      *(byte **)param_1 = pbVar27 + 3;
      pbVar8 = uStack_28;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &DAT_000170f9;
      goto LAB_00023966;
    }
    piStack_38 = (int *)FUN_00022cf0(param_1);
    if (piStack_38 != (int *)0x0) {
      puVar23 = &DAT_000170f9;
      goto LAB_00023dd4;
    }
    break;
  case 0x6e:
    bVar4 = pbVar27[1];
    if (bVar4 != 0x61) {
      if (bVar4 != 0x65) {
        if (bVar4 == 0x67) {
          *(byte **)param_1 = pbVar27 + 2;
          pbVar8 = uStack_28;
          if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
          puVar23 = &DAT_0001637a;
        }
        else {
          if (bVar4 != 0x74) {
            if (bVar4 == 0x78) {
              *(byte **)param_1 = pbVar27 + 2;
              iVar13 = FUN_00022cf0(param_1);
              if (iVar13 != 0) {
                puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x1c);
                *puVar14 = &PTR_LAB_00022116_1_00031e30;
                puVar14[1] = 0x1010134;
                puVar14[2] = "noexcept (";
                puVar14[3] = "";
                puVar14[4] = iVar13;
                puVar14[5] = &DAT_000170f7;
                puVar14[6] = &DAT_000170f8;
                goto LAB_00022d2a;
              }
            }
            else if (bVar4 == 0x77) goto LAB_0002334c;
            break;
          }
          *(byte **)param_1 = pbVar27 + 2;
          pbVar8 = uStack_28;
          if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
          puVar23 = &UNK_00016855;
        }
        puVar22 = puVar23 + 1;
LAB_00023e4c:
        iVar13 = FUN_00022cf0();
        if (iVar13 == 0) {
          puVar14 = (undefined4 *)0x0;
        }
        else {
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
          puVar14[2] = puVar23;
          puVar14[3] = puVar22;
          puVar14[4] = iVar13;
          *puVar14 = &PTR_LAB_00022116_1_00031a78;
          puVar14[1] = 0x101013a;
        }
        return puVar14;
      }
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = uStack_28;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016e3e;
      goto LAB_00023e78;
    }
LAB_0002334c:
    FUN_0002079c(param_1,&DAT_0001602f,&DAT_00016031);
    iVar13 = FUN_0002079c(param_1,&DAT_000165c7,&DAT_000165c9);
    if ((iVar13 != 0) || (iVar13 = FUN_0002079c(param_1,&DAT_00016a09,&DAT_00016a0b), iVar13 != 0))
    {
      pbVar21 = param_1 + 8;
      iVar13 = *(int *)pbVar21;
      iVar9 = *(int *)(param_1 + 0xc);
      while ((pcVar12 = *(char **)param_1, pcVar12 == *(char **)(param_1 + 4) || (*pcVar12 != '_')))
      {
        piStack_38 = (int *)FUN_00022cf0(param_1);
        if (piStack_38 == (int *)0x0) goto LAB_00022d28;
        FUN_00021ea4(pbVar21,&piStack_38);
      }
      *(char **)param_1 = pcVar12 + 1;
      FUN_00021f18(&piStack_38,param_1,iVar9 - iVar13 >> 2);
      iVar13 = FUN_00020e00(param_1);
      if (iVar13 != 0) {
        iVar9 = FUN_0002079c(param_1,&DAT_00017045,&DAT_00017047);
        if (iVar9 != 0) {
          iVar9 = *(int *)(param_1 + 8);
          iVar15 = *(int *)(param_1 + 0xc);
          goto LAB_00023ec2;
        }
        pcVar12 = *(char **)param_1;
        if (pcVar12 != *(char **)(param_1 + 4)) {
          puVar14 = (undefined4 *)0x0;
          if (*pcVar12 == 'E') {
            *(char **)param_1 = pcVar12 + 1;
            uVar17 = FUN_000220a8(param_1 + 0x198,0x20);
            puVar14 = (undefined4 *)FUN_0002760c(uVar17,piStack_38,iStack_34,iVar13);
          }
          goto LAB_00022d2a;
        }
      }
    }
    break;
  case 0x6f:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x52) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016b64;
    }
    else {
      if (bVar4 == 0x72) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = param_1;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &UNK_00016fb1;
        goto LAB_00023576;
      }
      if (bVar4 != 0x6f) {
        if (bVar4 == 0x6e) goto joined_r0x0002331c;
        break;
      }
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016ab2;
    }
LAB_00023e78:
    puVar22 = puVar23 + 2;
LAB_00023e7a:
    iVar13 = FUN_00022cf0();
    if ((iVar13 == 0) || (iVar9 = FUN_00022cf0(param_1), iVar9 == 0)) {
      puVar14 = (undefined4 *)0x0;
    }
    else {
      puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
      puVar14[2] = iVar13;
      puVar14[3] = puVar23;
      puVar14[4] = puVar22;
      puVar14[5] = iVar9;
      *puVar14 = &PTR_LAB_00022116_1_00031a40;
      puVar14[1] = 0x101012f;
    }
    return puVar14;
  case 0x70:
    puVar14 = (undefined4 *)0x0;
    switch(pbVar27[1]) {
    case 0x6c:
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016b67;
      goto LAB_00023576;
    case 0x6d:
      *(byte **)param_1 = pbVar27 + 2;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_0001668c;
      goto LAB_0002398a;
    case 0x6e:
    case 0x6f:
    case 0x71:
    case 0x72:
      break;
    case 0x70:
      pbVar21 = pbVar27 + 2;
      *(byte **)param_1 = pbVar21;
      if ((pbVar21 != pbVar16) && (*pbVar21 == 0x5f)) {
        *(byte **)param_1 = pbVar27 + 3;
        pbVar8 = uStack_28;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &DAT_00015e06;
LAB_00023966:
        puVar22 = puVar23 + 2;
        goto LAB_00023e4c;
      }
      piStack_38 = (int *)FUN_00022cf0(param_1);
      if (piStack_38 == (int *)0x0) goto LAB_00022d28;
      puVar23 = &DAT_00015e06;
LAB_00023dd4:
      puVar14 = (undefined4 *)FUN_00024ff8(param_1,&piStack_38,puVar23);
      break;
    case 0x73:
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016b67;
      puVar22 = &UNK_00016b68;
      goto LAB_00023e4c;
    case 0x74:
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00022cf0(param_1);
      if ((piStack_38 != (int *)0x0) &&
         (piStack_30 = (int *)FUN_00022cf0(param_1), piStack_30 != (int *)0x0)) {
        puVar23 = &DAT_00016c89;
        goto LAB_00023d46;
      }
      goto LAB_00022d28;
    default:
      if (pbVar27[1] == 0x4c) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = param_1;
        if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
        puVar23 = &UNK_000169e0;
        goto LAB_00023e78;
      }
    }
    goto LAB_00022d2a;
  case 0x71:
    if (pbVar27[1] == 0x75) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_00022cf0(param_1);
      if (((iVar13 != 0) && (iVar9 = FUN_00022cf0(param_1), iVar9 != 0)) &&
         (iVar15 = FUN_00022cf0(param_1), iVar15 != 0)) {
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
        *puVar14 = &PTR_LAB_00022116_1_00031e68;
        puVar14[1] = 0x1010132;
        puVar14[2] = iVar13;
        puVar14[3] = iVar9;
        puVar14[4] = iVar15;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x72:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x4d) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = param_1;
      if (__stack_chk_guard != uStack_28) goto LAB_00022d44;
      puVar23 = &UNK_00016ec9;
      goto LAB_00023e78;
    }
    if (bVar4 == 0x53) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = uStack_28;
      if (__stack_chk_guard == uStack_28) {
        puVar23 = &UNK_000169e3;
        puVar22 = &UNK_000169e6;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar4 == 0x73) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = uStack_28;
      if (__stack_chk_guard == uStack_28) {
        puVar23 = &UNK_0001603d;
        puVar22 = &UNK_0001603f;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar4 == 0x6d) {
      *(byte **)param_1 = pbVar27 + 2;
      pbVar8 = uStack_28;
      if (__stack_chk_guard == uStack_28) {
        puVar23 = &UNK_00017359;
        puVar22 = &UNK_0001735a;
        goto LAB_00023e7a;
      }
      goto LAB_00022d44;
    }
    if (bVar4 == 99) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_00020e00(param_1);
      if ((iVar13 != 0) && (iVar9 = FUN_00022cf0(param_1), iVar9 != 0)) {
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
        pcVar12 = "reinterpret_cast";
        pcVar20 = "";
LAB_000232dc:
        *puVar14 = &PTR_LAB_00022116_1_00031ab0;
        puVar14[1] = 0x1010135;
        puVar14[2] = pcVar12;
        puVar14[3] = pcVar20;
        puVar14[4] = iVar13;
        puVar14[5] = iVar9;
        goto LAB_00022d2a;
      }
    }
    break;
  case 0x73:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x50) {
      pbVar27 = pbVar27 + 2;
      iVar9 = *(int *)(param_1 + 0xc);
      iVar13 = *(int *)(param_1 + 8);
      *(byte **)param_1 = pbVar27;
      while( true ) {
        if ((pbVar27 != pbVar16) && (*pbVar27 == 0x45)) {
          *(byte **)param_1 = pbVar27 + 1;
          FUN_00021f18(&piStack_38,param_1,iVar9 - iVar13 >> 2);
          piStack_30 = (int *)FUN_000220a8(param_1 + 0x198,0x10);
          piStack_30[1] = 0x1010100;
          *piStack_30 = (int)&PTR_LAB_00022116_1_00031ed8;
          piStack_30[2] = (int)piStack_38;
          piStack_30[3] = iStack_34;
          ppiVar18 = &piStack_30;
          goto LAB_00024028;
        }
        piStack_38 = (int *)FUN_00021d64(param_1);
        if (piStack_38 == (int *)0x0) break;
        FUN_00021ea4(param_1 + 8,&piStack_38);
        pbVar27 = *(byte **)param_1;
        pbVar16 = *(byte **)(param_1 + 4);
      }
    }
    else if (bVar4 == 0x5a) {
      pbVar27 = pbVar27 + 2;
      *(byte **)param_1 = pbVar27;
      if (pbVar16 != pbVar27) {
        if (*pbVar27 == 0x66) {
          piStack_38 = (int *)FUN_00024b74(param_1);
          if (piStack_38 != (int *)0x0) {
            ppiVar18 = &piStack_38;
LAB_00024028:
            puVar14 = (undefined4 *)FUN_000250bc(param_1,ppiVar18);
            goto LAB_00022d2a;
          }
        }
        else if ((*pbVar27 == 0x54) && (iVar13 = FUN_00022680(param_1), iVar13 != 0)) {
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
          uVar17 = 0x1010136;
          puVar23 = &UNK_00031e98;
          goto LAB_0002385c;
        }
      }
    }
    else if (bVar4 == 0x7a) {
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00022cf0(param_1);
LAB_00023c2a:
      if (piStack_38 != (int *)0x0) {
        pcVar12 = "sizeof (";
        goto LAB_00023c3a;
      }
    }
    else if (bVar4 == 0x70) {
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00022cf0(param_1);
      if (piStack_38 != (int *)0x0) {
        puVar14 = (undefined4 *)FUN_0002503c(param_1,&piStack_38);
        goto LAB_00022d2a;
      }
    }
    else {
      pbVar8 = uStack_28;
      if (bVar4 == 0x72) goto joined_r0x0002331c;
      if (bVar4 == 0x74) {
        *(byte **)param_1 = pbVar27 + 2;
        piStack_38 = (int *)FUN_00020e00(param_1);
        goto LAB_00023c2a;
      }
      if (bVar4 == 99) {
        *(byte **)param_1 = pbVar27 + 2;
        iVar13 = FUN_00020e00(param_1);
        if ((iVar13 != 0) && (iVar9 = FUN_00022cf0(param_1), iVar9 != 0)) {
          puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x18);
          pcVar12 = "static_cast";
          pcVar20 = "";
          goto LAB_000232dc;
        }
      }
    }
    break;
  case 0x74:
    bVar4 = pbVar27[1];
    if (bVar4 == 0x77) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_00022cf0(param_1);
      if (iVar13 != 0) {
        puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
        uVar17 = 0x101013f;
        puVar23 = &UNK_00031f08;
LAB_0002385c:
        *puVar14 = puVar23 + 8;
        puVar14[1] = uVar17;
        puVar14[2] = iVar13;
        goto LAB_00022d2a;
      }
    }
    else if (bVar4 == 0x69) {
      *(byte **)param_1 = pbVar27 + 2;
      piStack_38 = (int *)FUN_00020e00(param_1);
LAB_000236ca:
      if (piStack_38 != (int *)0x0) {
        pcVar12 = "typeid (";
LAB_00023c3a:
        puVar14 = (undefined4 *)FUN_00025068(param_1,pcVar12,&piStack_38);
        goto LAB_00022d2a;
      }
    }
    else if (bVar4 == 0x6c) {
      *(byte **)param_1 = pbVar27 + 2;
      iVar13 = FUN_00020e00(param_1);
      if (iVar13 != 0) {
        iVar9 = *(int *)(param_1 + 8);
        iVar15 = *(int *)(param_1 + 0xc);
        while( true ) {
          pcVar12 = *(char **)param_1;
          if ((pcVar12 != *(char **)(param_1 + 4)) && (*pcVar12 == 'E')) {
            *(char **)param_1 = pcVar12 + 1;
            FUN_00021f18(&piStack_38,param_1,iVar15 - iVar9 >> 2);
            puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
            puVar14[1] = 0x101013d;
            puVar14[2] = iVar13;
            *puVar14 = &PTR_LAB_00022116_1_00031d88;
            puVar14[3] = piStack_38;
            puVar14[4] = iStack_34;
            goto LAB_00022d2a;
          }
          piStack_38 = (int *)FUN_00024edc(param_1);
          if (piStack_38 == (int *)0x0) break;
          FUN_00021ea4(param_1 + 8,&piStack_38);
        }
      }
    }
    else {
      if (bVar4 == 0x72) {
        *(byte **)param_1 = pbVar27 + 2;
        pbVar8 = uStack_28;
        if (__stack_chk_guard == uStack_28) {
          puVar14 = (undefined4 *)FUN_00025104(param_1,"throw");
          return puVar14;
        }
        goto LAB_00022d44;
      }
      if (bVar4 == 0x65) {
        *(byte **)param_1 = pbVar27 + 2;
        piStack_38 = (int *)FUN_00022cf0(param_1);
        goto LAB_000236ca;
      }
    }
    break;
  default:
    if (*pbVar27 - 0x31 < 9) goto joined_r0x0002331c;
switchD_00022d78_caseD_1:
    iVar13 = FUN_0002079c(param_1,&DAT_00016d69,&DAT_00016d74);
    if (iVar13 == 0) {
      iVar13 = FUN_0002079c(param_1,&DAT_0001735b,&DAT_00017366);
      if (iVar13 == 0) break;
      piStack_38 = (int *)FUN_00022cf0(param_1);
    }
    else {
      piStack_38 = (int *)FUN_00020e00(param_1);
    }
    if (piStack_38 == (int *)0x0) break;
    puVar14 = (undefined4 *)FUN_0002513c(param_1,&piStack_38);
    goto LAB_00022d2a;
  }
LAB_00022d28:
  puVar14 = (undefined4 *)0x0;
LAB_00022d2a:
  pbVar8 = uStack_28;
  if (__stack_chk_guard == uStack_28) {
    return puVar14;
  }
LAB_00022d44:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(pbVar8);
LAB_00023ec2:
  pcVar12 = *(char **)param_1;
  if ((pcVar12 != *(char **)(param_1 + 4)) && (*pcVar12 == 'E')) {
    *(char **)param_1 = pcVar12 + 1;
    FUN_00021f18(&piStack_30,param_1,iVar15 - iVar9 >> 2);
    puVar14 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x20);
    FUN_0002760c(puVar14,piStack_38,iStack_34,iVar13);
    goto LAB_00022d2a;
  }
  piStack_30 = (int *)FUN_00022cf0(param_1);
  if (piStack_30 == (int *)0x0) goto LAB_00022d28;
  FUN_00021ea4(pbVar21,&piStack_30);
  goto LAB_00023ec2;
code_r0x000247ee:
  iVar9 = FUN_00025594(pcVar6[iVar13]);
  iVar13 = iVar13 + 1;
  if (iVar9 == 0) goto switchD_0002459a_caseD_54;
  goto LAB_000247e8;
}


// ==== FUN_00024ff8 @ 00024ff8

undefined4 * FUN_00024ff8(int param_1,undefined4 *param_2,char *param_3)

{
  undefined4 *puVar1;
  size_t sVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
  uVar3 = *param_2;
  sVar2 = strlen(param_3);
  puVar1[4] = param_3 + sVar2;
  puVar1[2] = uVar3;
  puVar1[3] = param_3;
  *puVar1 = &PTR_LAB_00022116_1_00031dc0;
  puVar1[1] = 0x1010131;
  return puVar1;
}


// ==== FUN_0002503c @ 0002503c

void FUN_0002503c(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
  puVar1[1] = 0x1010122;
  *puVar1 = &PTR_LAB_00022116_1_00031a08;
  puVar1[2] = *param_2;
  return;
}


// ==== FUN_00025068 @ 00025068

undefined4 * FUN_00025068(int param_1,char *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  size_t sVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x1c);
  sVar2 = strlen(param_2);
  puVar1[1] = 0x1010134;
  *puVar1 = &PTR_LAB_00022116_1_00031e30;
  puVar1[4] = *param_3;
  puVar1[2] = param_2;
  puVar1[3] = param_2 + sVar2;
  puVar1[5] = &DAT_000170f7;
  puVar1[6] = &DAT_000170f8;
  return puVar1;
}


// ==== FUN_000250bc @ 000250bc

void FUN_000250bc(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x1c);
  puVar1[1] = 0x1010134;
  *puVar1 = &PTR_LAB_00022116_1_00031e30;
  puVar1[4] = *param_2;
  puVar1[2] = "sizeof... (";
  puVar1[3] = "";
  puVar1[5] = &DAT_000170f7;
  puVar1[6] = &DAT_000170f8;
  return;
}


// ==== FUN_00025104 @ 00025104

undefined4 * FUN_00025104(int param_1,char *param_2)

{
  undefined4 *puVar1;
  size_t sVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  sVar2 = strlen(param_2);
  puVar1[2] = param_2;
  puVar1[3] = param_2 + sVar2;
  *puVar1 = &PTR_LAB_00022116_1_000315a8;
  puVar1[1] = 0x1010107;
  return puVar1;
}


// ==== FUN_0002513c @ 0002513c

void FUN_0002513c(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
  puVar1[1] = 0x1010140;
  *puVar1 = &PTR_LAB_00022116_1_00031f48;
  puVar1[2] = *param_2;
  return;
}


// ==== FUN_000251f0 @ 000251f0

void FUN_000251f0(int param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
  *puVar1 = &PTR_LAB_00022116_1_00031688;
  puVar1[1] = 0x1010141;
  *(bool *)(puVar1 + 2) = *param_2 != 0;
  return;
}


// ==== FUN_00025258 @ 00025258

undefined4 * FUN_00025258(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  size_t sVar4;
  undefined *puVar5;
  int iVar6;
  uint __c;
  undefined4 *puVar7;
  int iVar8;
  undefined4 local_70;
  undefined4 uStack_6c;
  int local_68;
  undefined4 uStack_64;
  int local_60;
  int local_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  int local_24;
  
  local_24 = __stack_chk_guard;
  if (param_2 != 0) {
    param_1[0x54] = param_1[0x53];
  }
  iVar2 = FUN_0002079c(param_1,&DAT_000172d4,&DAT_000172d6);
  if (iVar2 == 0) {
    iVar2 = FUN_0002079c(param_1,&DAT_00016b69,&DAT_00016b6b);
    if (iVar2 == 0) {
      iVar2 = FUN_0002079c(param_1,&DAT_000162ce,&DAT_000162d0);
      if (iVar2 != 0) {
        puVar7 = (undefined4 *)0x0;
        FUN_00020d6c(&local_58,param_1,0);
        pcVar3 = (char *)*param_1;
        if (pcVar3 == (char *)param_1[1]) goto LAB_00025464;
        if (*pcVar3 == '_') {
          *param_1 = (int)(pcVar3 + 1);
          if (__stack_chk_guard == local_24) {
            puVar7 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
            sVar4 = strlen("\'block-literal\'");
            puVar7[2] = "\'block-literal\'";
            puVar7[3] = "\'block-literal\'" + sVar4;
            *puVar7 = &PTR_LAB_00022116_1_000315a8;
            puVar7[1] = 0x1010107;
            return puVar7;
          }
          goto LAB_0002547c;
        }
      }
LAB_000253a0:
      puVar7 = (undefined4 *)0x0;
    }
    else {
      iVar8 = param_1[0x62];
      param_1[0x62] = param_1[0x54] - param_1[0x53] >> 2;
      FUN_00025894(&local_58,param_1);
      piVar1 = param_1 + 2;
      iVar2 = param_1[3] - *piVar1 >> 2;
      while (((char *)param_1[1] != (char *)*param_1 && (*(char *)*param_1 == 'T'))) {
        sVar4 = __strlen_chk(&DAT_00016d75,5);
        if ((uint)(param_1[1] - *param_1) < 2) {
          __c = 0;
        }
        else {
          __c = (uint)*(byte *)(*param_1 + 1);
        }
        if (((sVar4 == 0) || (puVar5 = memchr(&DAT_00016d75,__c,sVar4), puVar5 == (undefined *)0x0))
           || (puVar5 == &DAT_00016d74)) break;
        local_60 = FUN_000258f8(param_1);
        if (local_60 == 0) goto LAB_00025458;
        FUN_00021ea4(piVar1,&local_60);
      }
      FUN_00021f18(&local_60,param_1,iVar2);
      if (local_5c == 0) {
        param_1[0x54] = param_1[0x54] + -4;
      }
      iVar6 = __strlen_chk(&DAT_00016b6c,3);
      iVar6 = FUN_0002079c(param_1,&DAT_00016b6c,&DAT_00016b6c + iVar6);
      if (iVar6 == 0) {
        do {
          local_68 = FUN_00020e00(param_1);
          if (local_68 == 0) goto LAB_00025458;
          FUN_00021ea4(piVar1,&local_68);
          pcVar3 = (char *)*param_1;
        } while ((pcVar3 == (char *)param_1[1]) || (*pcVar3 != 'E'));
        *param_1 = (int)(pcVar3 + 1);
      }
      FUN_00021f18(&local_68,param_1,iVar2);
      puVar7 = (undefined4 *)0x0;
      FUN_00020d6c(&local_70,param_1,0);
      pcVar3 = (char *)*param_1;
      if (pcVar3 != (char *)param_1[1]) {
        if (*pcVar3 == '_') {
          *param_1 = (int)(pcVar3 + 1);
          puVar7 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x20);
          *puVar7 = &PTR_LAB_00022116_1_000318f0;
          puVar7[1] = 0x101012d;
          puVar7[2] = local_60;
          puVar7[3] = local_5c;
          puVar7[4] = local_68;
          puVar7[5] = uStack_64;
          puVar7[6] = local_70;
          puVar7[7] = uStack_6c;
        }
        else {
LAB_00025458:
          puVar7 = (undefined4 *)0x0;
        }
      }
      FUN_00025ac0(&local_58);
      param_1[0x62] = iVar8;
    }
  }
  else {
    puVar7 = (undefined4 *)0x0;
    FUN_00020d6c(&local_58,param_1,0);
    pcVar3 = (char *)*param_1;
    if (pcVar3 != (char *)param_1[1]) {
      if (*pcVar3 != '_') goto LAB_000253a0;
      *param_1 = (int)(pcVar3 + 1);
      puVar7 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      puVar7[1] = 0x101012c;
      *puVar7 = &PTR_LAB_00022116_1_000317a0;
      puVar7[2] = local_58;
      puVar7[3] = uStack_54;
    }
  }
LAB_00025464:
  if (__stack_chk_guard == local_24) {
    return puVar7;
  }
LAB_0002547c:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(local_24);
}


// ==== FUN_000254cc @ 000254cc

void FUN_000254cc(int param_1,undefined4 param_2)

{
  char *pcVar1;
  char *pcVar2;
  
  if (3 < (uint)(*(int *)(param_1 + 0xc) - *(int *)(param_1 + 8))) {
    FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
    FUN_00022150(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
    FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  }
  if (**(char **)(param_1 + 0x10) == 'n') {
    FUN_00022150(param_2,&DAT_0001637a,&DAT_0001637b);
    pcVar2 = *(char **)(param_1 + 0x14);
    pcVar1 = pcVar2;
    if (pcVar2 != *(char **)(param_1 + 0x10)) {
      pcVar1 = *(char **)(param_1 + 0x10) + 1;
    }
  }
  else {
    pcVar2 = *(char **)(param_1 + 0x14);
    pcVar1 = *(char **)(param_1 + 0x10);
  }
  FUN_00022150(param_2,pcVar1,pcVar2);
  if ((uint)(*(int *)(param_1 + 0xc) - *(int *)(param_1 + 8)) < 4) {
    FUN_00022150(param_2);
    return;
  }
  return;
}


// ==== FUN_00025560 @ 00025560

void FUN_00025560(int param_1,undefined4 param_2)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = "true";
  pcVar2 = "";
  if (*(char *)(param_1 + 8) == '\0') {
    pcVar1 = "false";
    pcVar2 = "";
  }
  FUN_00022150(param_2,pcVar1,pcVar2);
  return;
}


// ==== FUN_00025594 @ 00025594

bool FUN_00025594(int param_1)

{
  uint uVar1;
  bool bVar2;
  
  uVar1 = param_1 - 0x30;
  bVar2 = 9 < uVar1;
  if (bVar2) {
    uVar1 = param_1 - 0x61;
  }
  if (bVar2 && 5 < uVar1) {
    return param_1 - 0x41U < 6;
  }
  return true;
}


// ==== FUN_0002567c @ 0002567c

void FUN_0002567c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined1 param_5)

{
  int iVar1;
  undefined1 uStack00000000;
  
  iVar1 = __stack_chk_guard;
  __vsnprintf_chk(param_1,param_3,0,param_2,param_4,&param_5,&param_5);
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_000256c0 @ 000256c0

void FUN_000256c0(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  
  if (param_1 != param_2) {
    for (; param_2 = param_2 + -1, param_1 < param_2; param_1 = param_1 + 1) {
      uVar1 = *param_1;
      *param_1 = *param_2;
      *param_2 = uVar1;
    }
  }
  return;
}


// ==== FUN_00025798 @ 00025798

void FUN_00025798(int param_1,undefined4 param_2)

{
  byte bVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  byte bVar5;
  char cVar6;
  undefined8 local_50;
  undefined4 local_48 [4];
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 local_24;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  iVar4 = *(int *)(param_1 + 8);
  if (0x10 < (*(int *)(param_1 + 0xc) - iVar4) + 1U) {
    pcVar3 = (char *)&local_50;
    for (iVar2 = 0; iVar2 != 0x10; iVar2 = iVar2 + 2) {
      bVar5 = *(byte *)(iVar4 + iVar2);
      if (bVar5 - 0x3a < 0xfffffff6) {
        bVar5 = bVar5 + 9;
      }
      bVar1 = *(byte *)(iVar4 + iVar2 + 1);
      cVar6 = -0x30;
      if (bVar1 - 0x3a < 0xfffffff6) {
        cVar6 = -0x57;
      }
      *pcVar3 = bVar1 + cVar6 + bVar5 * '\x10';
      pcVar3 = pcVar3 + 1;
    }
    FUN_000256c0(&local_50);
    local_48[1] = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
    local_48[2] = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
    local_48[3] = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
    local_24 = 0;
    local_48[0] = 0;
    local_38 = 0;
    local_28 = 0;
    uStack_34 = local_48[1];
    uStack_30 = local_48[2];
    uStack_2c = local_48[3];
    iVar4 = FUN_0002567c(local_48,0x28,0x28,&DAT_0001638f,local_50);
    FUN_00022150(param_2,local_48,(int)local_48 + iVar4);
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0002585c @ 0002585c

void FUN_0002585c(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00016fbb,&DAT_00016fbd);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_00016869,&DAT_0001686b);
  return;
}


// ==== FUN_00025894 @ 00025894

void FUN_00025894(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  piVar1 = param_1 + 5;
  iVar2 = *(int *)(param_2 + 0x14c);
  iVar3 = *(int *)(param_2 + 0x150);
  param_1[3] = (int)piVar1;
  *piVar1 = 0;
  param_1[6] = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
  param_1[7] = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
  param_1[8] = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
  param_1[1] = iVar3 - iVar2 >> 2;
  local_18 = param_1 + 2;
  *local_18 = (int)piVar1;
  *param_1 = param_2;
  param_1[9] = 0;
  param_1[10] = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
  param_1[0xb] = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
  param_1[0xc] = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
  param_1[4] = (int)(param_1 + 0xd);
  FUN_00022b02(param_2 + 0x14c,&local_18);
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_14);
  }
  return;
}


// ==== FUN_000258f8 @ 000258f8

void FUN_000258f8(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined *puVar6;
  int iVar7;
  int local_64;
  undefined4 uStack_60;
  int local_5c;
  undefined1 auStack_58 [52];
  int local_24;
  
  local_24 = __stack_chk_guard;
  local_5c = param_1;
  iVar1 = FUN_0002079c(param_1,&DAT_00016394,&DAT_00016396);
  if (iVar1 == 0) {
    iVar1 = FUN_0002079c(param_1,&DAT_000162d1,&DAT_000162d3);
    if (iVar1 != 0) {
      iVar1 = FUN_00025b64(&local_5c,1);
      if ((iVar1 != 0) && (iVar4 = FUN_00020e00(param_1), iVar4 != 0)) {
        puVar2 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
        puVar2[2] = iVar1;
        puVar2[3] = iVar4;
        *puVar2 = &PTR_LAB_00022116_1_00031848;
        puVar2[1] = 0x101001d;
      }
      goto LAB_00025a5a;
    }
    iVar1 = FUN_0002079c(param_1,&DAT_00016fbe,&DAT_00016fc0);
    if (iVar1 != 0) {
      iVar1 = FUN_00025b64(&local_5c,2);
      if (iVar1 != 0) {
        iVar7 = *(int *)(param_1 + 8);
        iVar4 = *(int *)(param_1 + 0xc);
        FUN_00025894(auStack_58,param_1);
        while( true ) {
          iVar5 = __strlen_chk(&DAT_000170fc,2);
          iVar5 = FUN_0002079c(param_1,&DAT_000170fc,&DAT_000170fc + iVar5);
          if (iVar5 != 0) break;
          local_64 = FUN_000258f8(param_1);
          if (local_64 == 0) goto LAB_00025a54;
          FUN_00021ea4((int *)(param_1 + 8),&local_64);
        }
        FUN_00021f18(&local_64,param_1,iVar4 - iVar7 >> 2);
        puVar2 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
        puVar2[4] = uStack_60;
        puVar2[2] = iVar1;
        puVar2[3] = local_64;
        *puVar2 = &PTR_LAB_00022116_1_00031880;
        puVar2[1] = 0x101001e;
LAB_00025a54:
        FUN_00025ac0(auStack_58);
      }
      goto LAB_00025a5a;
    }
    iVar1 = FUN_0002079c(param_1,&DAT_00016982,&DAT_00016984);
    if ((iVar1 == 0) || (iVar1 = FUN_000258f8(param_1), iVar1 == 0)) goto LAB_00025a5a;
    puVar2 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
    uVar3 = 0x101001f;
    puVar6 = &UNK_000318b0;
  }
  else {
    iVar1 = FUN_00025b64(&local_5c,0);
    if (iVar1 == 0) goto LAB_00025a5a;
    puVar2 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
    uVar3 = 0x101001c;
    puVar6 = &UNK_00031808;
  }
  *puVar2 = puVar6 + 8;
  puVar2[1] = uVar3;
  puVar2[2] = iVar1;
LAB_00025a5a:
  if (__stack_chk_guard != local_24) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_24);
  }
  return;
}


// ==== FUN_00025ac0 @ 00025ac0

int * FUN_00025ac0(int *param_1)

{
  *(int *)(*param_1 + 0x150) = *(int *)(*param_1 + 0x14c) + param_1[1] * 4;
  FUN_00020742(param_1 + 2);
  return param_1;
}


// ==== FUN_00025b1c @ 00025b1c

void FUN_00025b1c(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,"\'unnamed","");
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  FUN_00022150(param_2,&DAT_000167ac,&DAT_000167ad);
  return;
}


// ==== FUN_00025b64 @ 00025b64

void FUN_00025b64(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 *local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  iVar3 = *param_1;
  iVar1 = iVar3 + param_2 * 4;
  iVar2 = *(int *)(iVar1 + 0x18c);
  *(int *)(iVar1 + 0x18c) = iVar2 + 1;
  local_20 = (undefined4 *)FUN_000220a8(iVar3 + 0x198,0x10);
  local_20[2] = param_2;
  local_20[3] = iVar2;
  *local_20 = &PTR_LAB_00022116_1_000317d8;
  local_20[1] = 0x101011b;
  FUN_00025be4(*(undefined4 *)(*(int *)(iVar3 + 0x150) + -4),&local_20);
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_1c);
  }
  return;
}


// ==== FUN_00025be4 @ 00025be4

void FUN_00025be4(undefined4 *param_1,undefined4 *param_2)

{
  void *pvVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *__ptr;
  int iVar4;
  
  puVar3 = (undefined4 *)param_1[1];
  if (puVar3 == (undefined4 *)param_1[2]) {
    __ptr = (undefined4 *)*param_1;
    iVar4 = (int)puVar3 - (int)__ptr;
    if (__ptr == param_1 + 3) {
      pvVar1 = malloc(iVar4 * 2);
      if (pvVar1 == (void *)0x0) goto LAB_00025c54;
      FUN_00025d38(__ptr,puVar3,pvVar1);
      *param_1 = pvVar1;
    }
    else {
      pvVar1 = realloc(__ptr,iVar4 * 2);
      *param_1 = pvVar1;
      if (pvVar1 == (void *)0x0) {
LAB_00025c54:
                    /* WARNING: Subroutine does not return */
        FUN_00020238();
      }
    }
    puVar3 = (undefined4 *)((int)pvVar1 + (iVar4 >> 2) * 4);
    param_1[1] = puVar3;
    param_1[2] = (void *)((int)pvVar1 + (iVar4 >> 1) * 4);
  }
  uVar2 = *param_2;
  param_1[1] = puVar3 + 1;
  *puVar3 = uVar2;
  return;
}


// ==== FUN_00025c58 @ 00025c58

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00025c58(int param_1,int *param_2)

{
  ulonglong uVar1;
  int iVar2;
  undefined *puVar3;
  undefined *puVar4;
  byte *pbVar5;
  undefined4 *puVar6;
  uint uVar7;
  ulonglong uVar8;
  undefined4 local_24;
  
  local_24 = __stack_chk_guard;
  iVar2 = *(int *)(param_1 + 8);
  if (iVar2 == 0) {
    puVar3 = &UNK_00016c8c;
LAB_00025c84:
    puVar4 = puVar3 + 2;
LAB_00025c8e:
    FUN_00022150(param_2,puVar3,puVar4);
  }
  else {
    if (iVar2 == 2) {
      puVar3 = &DAT_0001642b;
      puVar4 = &DAT_0001642e;
      goto LAB_00025c8e;
    }
    if (iVar2 == 1) {
      puVar3 = &DAT_00016052;
      goto LAB_00025c84;
    }
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    uVar7 = *(int *)(param_1 + 0xc) - 1;
    if (uVar7 == 0) {
      if (__stack_chk_guard == local_24) {
        FUN_00020772(param_2,1);
        iVar2 = param_2[1];
        param_2[1] = iVar2 + 1;
        *(undefined1 *)(*param_2 + iVar2) = 0x30;
        return;
      }
      goto LAB_00025cf2;
    }
    pbVar5 = (byte *)((int)register0x00000054 + -0x25);
    puVar6 = &local_24;
    uVar1 = (ulonglong)uVar7;
    while( true ) {
      if (uVar1 == 0) break;
      uVar8 = FUN_0002a500((int)uVar1,(int)(uVar1 >> 0x20),10,0);
      puVar6 = (undefined4 *)((int)puVar6 + -1);
      *pbVar5 = (char)uVar1 + (char)uVar8 * -10 | 0x30;
      pbVar5 = pbVar5 + -1;
      uVar1 = uVar8;
    }
    FUN_00022150(param_2,puVar6,&local_24);
  }
  if (__stack_chk_guard == local_24) {
    return;
  }
LAB_00025cf2:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00025d38 @ 00025d38

void FUN_00025d38(void *param_1,int param_2,void *param_3)

{
  if (param_2 - (int)param_1 == 0) {
    return;
  }
  memmove(param_3,param_1,param_2 - (int)param_1);
  return;
}


// ==== FUN_00025d3e @ 00025d3e

void FUN_00025d3e(void *param_1,undefined4 param_2,void *param_3,size_t param_4)

{
  memmove(param_3,param_1,param_4);
  return;
}


// ==== FUN_00025da4 @ 00025da4

void FUN_00025da4(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
                    /* WARNING: Could not recover jumptable at 0x00025dbe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0xc) + 0x14))(*(int **)(param_1 + 0xc),param_2);
  return;
}


// ==== FUN_00025dc4 @ 00025dc4

void FUN_00025dc4(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,"template<","");
  FUN_00025e0c(param_1 + 0xc,param_2);
  FUN_00022150(param_2,"> typename ","");
  return;
}


// ==== FUN_00025e0c @ 00025e0c

void FUN_00025e0c(int *param_1,int param_2)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  bVar1 = true;
  for (iVar3 = 0; iVar3 != param_1[1]; iVar3 = iVar3 + 1) {
    iVar4 = *(int *)(param_2 + 4);
    iVar2 = iVar4;
    if (!bVar1) {
      FUN_00022150(param_2,&DAT_00016fe4,&DAT_00016fe6);
      iVar2 = *(int *)(param_2 + 4);
    }
    FUN_00020684(*(undefined4 *)(*param_1 + iVar3 * 4),param_2);
    if (iVar2 == *(int *)(param_2 + 4)) {
      *(int *)(param_2 + 4) = iVar4;
    }
    else {
      bVar1 = false;
    }
  }
  return;
}


// ==== FUN_00025e70 @ 00025e70

void FUN_00025e70(int param_1,undefined4 param_2)

{
  (**(code **)(**(int **)(param_1 + 8) + 0x10))(*(int **)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_00016c8f,&DAT_00016c92);
  return;
}


// ==== FUN_00025ea0 @ 00025ea0

void FUN_00025ea0(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00015efd,&DAT_00015f04);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x1c));
  FUN_00022150(param_2,&DAT_000167ac,&DAT_000167ad);
  FUN_00025eec(param_1,param_2);
  return;
}


// ==== FUN_00025eec @ 00025eec

void FUN_00025eec(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00022150(param_2,&DAT_00015e04,&DAT_00015e05);
    FUN_00025e0c(param_1 + 8,param_2);
    FUN_00022150(param_2,&DAT_000168fb,&DAT_000168fc);
  }
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00025e0c(param_1 + 0x10,param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00025f50 @ 00025f50

void FUN_00025f50(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_0001722f,&DAT_00017231);
  if (*(char *)(*(int *)(param_1 + 8) + 4) == '-') {
    FUN_00025eec(*(int *)(param_1 + 8),param_2);
  }
  FUN_00022150(param_2,&DAT_00015e61,&DAT_00015e66);
  return;
}


// ==== FUN_00025f90 @ 00025f90

void FUN_00025f90(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  return;
}


// ==== FUN_00025fe0 @ 00025fe0

void FUN_00025fe0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  uVar2 = param_2[1];
  puVar1[2] = *param_2;
  puVar1[3] = uVar2;
  *puVar1 = &PTR_LAB_00022116_1_00031998;
  puVar1[1] = 0x101013b;
  return;
}


// ==== FUN_00026010 @ 00026010

void FUN_00026010(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00016b6f,&DAT_00016b71);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  return;
}


// ==== FUN_0002612c @ 0002612c

undefined8 FUN_0002612c(undefined **param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *puVar1;
  undefined **local_20;
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  puVar1 = param_1[1];
  local_20 = param_1;
  local_1c = param_2;
  local_18 = param_3;
  FUN_000206aa(*param_1,0x28);
  local_1c = 0x1010122;
  local_20 = &PTR_LAB_00022116_1_00031a08;
  local_18 = *(undefined4 *)(puVar1 + 8);
  FUN_00020684(&local_20,*param_1);
  FUN_000206aa(*param_1,0x29);
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return CONCAT44(local_1c,local_20);
}


// ==== FUN_0002618c @ 0002618c

void FUN_0002618c(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  
  uVar5 = *(undefined4 *)(param_2 + 0xc);
  uVar4 = *(undefined4 *)(param_2 + 0x10);
  *(undefined4 *)(param_2 + 0xc) = 0xffffffff;
  *(undefined4 *)(param_2 + 0x10) = 0xffffffff;
  uVar2 = *(undefined4 *)(param_2 + 4);
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  uVar6 = *(uint *)(param_2 + 0x10);
  if (uVar6 == 0xffffffff) {
    iVar1 = __strlen_chk(&DAT_00016c8f,4);
    FUN_00022150(param_2,&DAT_00016c8f,&DAT_00016c8f + iVar1);
  }
  else if (uVar6 == 0) {
    *(undefined4 *)(param_2 + 4) = uVar2;
  }
  else {
    for (uVar3 = 1; uVar3 < uVar6; uVar3 = uVar3 + 1) {
      iVar1 = __strlen_chk(&DAT_00016fe4,3);
      FUN_00022150(param_2,&DAT_00016fe4,&DAT_00016fe4 + iVar1);
      uVar2 = *(undefined4 *)(param_1 + 8);
      *(uint *)(param_2 + 0xc) = uVar3;
      FUN_00020684(uVar2,param_2);
    }
  }
  *(undefined4 *)(param_2 + 0xc) = uVar5;
  *(undefined4 *)(param_2 + 0x10) = uVar4;
  return;
}


// ==== FUN_00026224 @ 00026224

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00026224(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined1 auStack_b0 [128];
  
  iVar1 = __stack_chk_guard;
  iVar2 = FUN_00026328(param_1 + 0xc,auStack_b0 + 0x80);
  if (iVar2 != 0) {
    FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  }
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_00017367,&DAT_00017369);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  FUN_00022150(param_2,&DAT_00016875,&DAT_00016877);
  FUN_00020684(*(undefined4 *)(param_1 + 0x14),param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  iVar2 = FUN_00026328(param_1 + 0xc,auStack_b0 + 0x80);
  if (iVar2 == 0) {
    if (__stack_chk_guard == iVar1) {
      return;
    }
  }
  else if (__stack_chk_guard == iVar1) {
    FUN_00020772(param_2,1);
    memmove((void *)(*param_2 + param_2[1]),&DAT_000170f7,1);
    param_2[1] = param_2[1] + 1;
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(iVar1,__stack_chk_guard);
}


// ==== FUN_00026328 @ 00026328

bool FUN_00026328(undefined4 *param_1,undefined4 *param_2)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar3 = (char *)*param_2;
  pcVar1 = (char *)*param_1;
  pcVar2 = (char *)param_1[1];
  if ((int)pcVar2 - (int)pcVar1 != param_2[1] - (int)pcVar3) {
    return false;
  }
  for (; (pcVar1 != pcVar2 && (*pcVar1 == *pcVar3)); pcVar1 = pcVar1 + 1) {
    pcVar3 = pcVar3 + 1;
  }
  return pcVar1 == pcVar2;
}


// ==== FUN_0002639c @ 0002639c

void FUN_0002639c(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  FUN_00022150(param_2,&DAT_00015e04,&DAT_00015e05);
  (**(code **)(**(int **)(param_1 + 0x10) + 0x10))(*(int **)(param_1 + 0x10),param_2);
  FUN_00022150(param_2,&DAT_000164d5,&DAT_000164d7);
  (**(code **)(**(int **)(param_1 + 0x14) + 0x10))(*(int **)(param_1 + 0x14),param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00026404 @ 00026404

void FUN_00026404(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00025e0c(param_1 + 0xc,param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00026444 @ 00026444

void FUN_00026444(undefined4 *param_1,int param_2,int param_3,int param_4)

{
  undefined4 uVar1;
  
  uVar1 = FUN_000220a8(param_2 + 0x198,param_4 - param_3);
  FUN_00025d38(param_3,param_4,uVar1);
  *param_1 = uVar1;
  param_1[1] = param_4 - param_3 >> 2;
  return;
}


// ==== FUN_000264d8 @ 000264d8

void FUN_000264d8(int param_1,undefined4 param_2)

{
  if (*(char *)(param_1 + 0xc) != '\0') {
    FUN_00022150(param_2,&DAT_00016aad,&DAT_00016aaf);
  }
  FUN_00022150(param_2,"delete","");
  if (*(char *)(param_1 + 0xd) != '\0') {
    FUN_00022150(param_2,&DAT_000166a0,&DAT_000166a3);
  }
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  return;
}


// ==== FUN_00026528 @ 00026528

/* WARNING: Removing unreachable block (ram,0x00026578) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00026528(undefined4 *param_1,int param_2)

{
  char cVar1;
  byte *pbVar2;
  int iVar3;
  char *pcVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  byte *pbVar9;
  undefined4 *puStack_20;
  int local_1c;
  
  iVar3 = __stack_chk_guard;
  piVar8 = &local_1c;
  puStack_20 = param_1;
  if ((char *)param_1[1] != (char *)*param_1) {
    cVar1 = *(char *)*param_1;
    local_1c = param_2;
    if (cVar1 == 'D') {
      local_1c = FUN_00022834(param_1);
      if (local_1c == 0) goto LAB_00026590;
    }
    else {
      if (cVar1 != 'T') goto FUN_000221c4;
      iVar6 = FUN_00022680(param_1);
      if (iVar6 == 0) goto LAB_00026590;
      piVar8 = (int *)((int)register0x00000054 + -0x18);
    }
    FUN_00021ea4(param_1 + 0x25,piVar8);
LAB_00026590:
    if (__stack_chk_guard != iVar3) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(iVar3);
    }
    return;
  }
FUN_000221c4:
  local_1c = __stack_chk_guard;
  pbVar2 = (byte *)*param_1;
  if ((pbVar2 == (byte *)param_1[1]) || (*pbVar2 != 0x53)) goto LAB_0002224a;
  pbVar9 = pbVar2 + 1;
  *param_1 = pbVar9;
  if ((byte *)param_1[1] != pbVar9) {
    uVar7 = (uint)*pbVar9;
    if (0xffffffe5 < uVar7 - 0x7b) {
      switch(*pbVar9) {
      case 0x61:
        *param_1 = pbVar2 + 2;
        puStack_20 = (undefined4 *)0x0;
        break;
      case 0x62:
        *param_1 = pbVar2 + 2;
        puStack_20 = (undefined4 *)0x1;
        break;
      case 99:
      case 0x65:
      case 0x66:
      case 0x67:
      case 0x68:
        goto LAB_0002224a;
      case 100:
        *param_1 = pbVar2 + 2;
        puStack_20 = (undefined4 *)0x5;
        break;
      case 0x69:
        *param_1 = pbVar2 + 2;
        puStack_20 = (undefined4 *)0x3;
        break;
      default:
        if (uVar7 == 0x6f) {
          *param_1 = pbVar2 + 2;
          puStack_20 = (undefined4 *)0x4;
        }
        else {
          if (uVar7 != 0x73) goto LAB_0002224a;
          *param_1 = pbVar2 + 2;
          puStack_20 = (undefined4 *)0x2;
        }
      }
      puVar5 = (undefined4 *)FUN_00027b5c(param_1,&puStack_20);
      puStack_20 = (undefined4 *)FUN_000228b4(param_1,puVar5);
      if (puStack_20 != puVar5) {
        FUN_00021ea4(param_1 + 0x25,&puStack_20);
      }
      goto LAB_0002224a;
    }
    if (*pbVar9 == 0x5f) {
      *param_1 = pbVar2 + 2;
      goto LAB_0002224a;
    }
  }
  puStack_20 = (undefined4 *)0x0;
  iVar3 = FUN_00022048(param_1,&puStack_20);
  if (((iVar3 == 0) && (pcVar4 = (char *)*param_1, pcVar4 != (char *)param_1[1])) &&
     (*pcVar4 == '_')) {
    *param_1 = pcVar4 + 1;
  }
LAB_0002224a:
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_1c);
  }
  return;
}


// ==== FUN_000265b4 @ 000265b4

void FUN_000265b4(undefined4 *param_1,int param_2,int param_3)

{
  int local_1c;
  int local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  local_1c = param_2;
  local_18 = param_3;
  local_18 = FUN_00026790(param_1);
  if ((((local_18 != 0) && ((char *)param_1[1] != (char *)*param_1)) && (*(char *)*param_1 == 'I'))
     && (local_1c = FUN_000222e8(param_1,0), local_1c != 0)) {
    FUN_00022574(param_1,&local_18,&local_1c);
  }
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_14);
  }
  return;
}


// ==== FUN_0002661c @ 0002661c

void FUN_0002661c(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  puVar1[1] = 0x1010116;
  uVar3 = *param_2;
  *puVar1 = &PTR_LAB_00022116_1_00031b90;
  uVar2 = *param_3;
  puVar1[2] = uVar3;
  puVar1[3] = uVar2;
  return;
}


// ==== FUN_0002664c @ 0002664c

/* WARNING: Removing unreachable block (ram,0x00026700) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_0002664c(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int local_24;
  int local_20;
  undefined4 local_1c;
  
  iVar2 = __stack_chk_guard;
  local_1c = __stack_chk_guard;
  if (((byte *)param_1[1] != (byte *)*param_1) && (0xfffffff5 < *(byte *)*param_1 - 0x3a)) {
    iVar1 = FUN_00026790(param_1);
    if ((iVar1 != 0) &&
       ((((char *)param_1[1] != (char *)*param_1 && (*(char *)*param_1 == 'I')) &&
        (local_1c = FUN_000222e8(param_1,0), local_1c != 0)))) {
      FUN_00022574(param_1,(int)register0x00000054 + -0x18,&local_1c);
    }
    if (__stack_chk_guard != iVar2) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail(iVar2);
    }
    return;
  }
  iVar2 = FUN_0002079c(param_1,&DAT_0001698d,&DAT_0001698f);
  if (iVar2 == 0) {
    FUN_0002079c(param_1,&DAT_000160d7,&DAT_000160d9);
    local_20 = FUN_000268a8(param_1,0);
    if (((local_20 != 0) && ((char *)param_1[1] != (char *)*param_1)) &&
       ((*(char *)*param_1 == 'I' && (local_24 = FUN_000222e8(param_1,0), local_24 != 0)))) {
      FUN_00022574(param_1,&local_20,&local_24);
    }
  }
  else {
    if (((byte *)param_1[1] == (byte *)*param_1) || (*(byte *)*param_1 - 0x3a < 0xfffffff6)) {
      iVar2 = FUN_00026528(param_1);
    }
    else {
      iVar2 = FUN_000265b4(param_1);
    }
    if (iVar2 != 0) {
      puVar3 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0xc);
      puVar3[2] = iVar2;
      *puVar3 = &PTR_LAB_00022116_1_00031bc8;
      puVar3[1] = 0x101012b;
    }
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_1c);
  }
  return;
}


// ==== FUN_00026764 @ 00026764

void FUN_00026764(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
  puVar1[1] = 0x1010126;
  *puVar1 = &PTR_LAB_00022116_1_00031c70;
  puVar1[2] = *param_2;
  return;
}


// ==== FUN_00026790 @ 00026790

void FUN_00026790(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *local_20;
  int local_1c;
  uint local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  local_18 = 0;
  local_20 = param_1;
  local_1c = param_2;
  iVar1 = FUN_00022aae(param_1,&local_18);
  if (((iVar1 == 0) && (piVar2 = (int *)*param_1, local_18 <= (uint)(param_1[1] - (int)piVar2))) &&
     (local_18 != 0)) {
    local_1c = (int)piVar2 + local_18;
    *param_1 = local_1c;
    local_20 = piVar2;
    iVar1 = FUN_00021884(&local_20,"_GLOBAL__N","");
    if (iVar1 == 0) {
      FUN_00026838(param_1,&local_20);
    }
    else {
      puVar3 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
      *puVar3 = &PTR_LAB_00022116_1_000315a8;
      puVar3[1] = 0x1010107;
      puVar3[2] = "(anonymous namespace)";
      puVar3[3] = "";
    }
  }
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_14);
  }
  return;
}


// ==== FUN_00026838 @ 00026838

void FUN_00026838(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  uVar2 = param_2[1];
  puVar1[2] = *param_2;
  puVar1[3] = uVar2;
  *puVar1 = &PTR_LAB_00022116_1_000315a8;
  puVar1[1] = 0x1010107;
  return;
}


// ==== FUN_00026868 @ 00026868

void FUN_00026868(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2,&DAT_00016aad,&DAT_00016aaf);
  FUN_00020684(*(undefined4 *)(param_1 + 0xc),param_2);
  return;
}


// ==== FUN_00026894 @ 00026894

void FUN_00026894(undefined4 param_1,int param_2)

{
  (**(code **)(**(int **)(param_2 + 0xc) + 0x18))();
  return;
}


// ==== FUN_000268a8 @ 000268a8

undefined4 * FUN_000268a8(undefined4 *param_1,undefined1 *param_2)

{
  char cVar1;
  undefined1 uVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  size_t sVar6;
  undefined1 *puVar7;
  char *pcVar8;
  uint uVar9;
  int local_24;
  int local_20;
  undefined4 *local_1c;
  
  puVar5 = __stack_chk_guard;
  local_1c = __stack_chk_guard;
  puVar7 = (undefined1 *)*param_1;
  uVar9 = (int)param_1[1] - (int)puVar7;
  if ((undefined1 *)param_1[1] == puVar7) goto LAB_00026f3e;
  puVar3 = (undefined4 *)0x0;
  switch(*puVar7) {
  case 0x61:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'N') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator&=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'S') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard != puVar5) goto LAB_00026f56;
        pcVar8 = "operator=";
        goto LAB_0002700e;
      }
      if (cVar1 == 'n' || cVar1 == 'd') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator&";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'a') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator&&";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
    }
    break;
  default:
    goto switchD_000268da_caseD_62;
  case 99:
    if (uVar9 < 2) break;
    cVar1 = puVar7[1];
    if (cVar1 == 'v') {
      uVar2 = *(undefined1 *)(param_1 + 0x61);
      cVar1 = *(char *)((int)param_1 + 0x185);
      *(undefined1 *)(param_1 + 0x61) = 0;
      *param_1 = puVar7 + 2;
      *(bool *)((int)param_1 + 0x185) = param_2 != (undefined1 *)0x0 || cVar1 != '\0';
      local_20 = FUN_00020e00(param_1);
      if (local_20 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
      else {
        if (param_2 != (undefined1 *)0x0) {
          *param_2 = 1;
        }
        puVar3 = (undefined4 *)FUN_00027264(param_1,&local_20);
      }
      *(undefined1 *)(param_1 + 0x61) = uVar2;
      *(char *)((int)param_1 + 0x185) = cVar1;
    }
    else {
      if (cVar1 == 'm') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator,";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'o') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator~";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      puVar3 = (undefined4 *)0x0;
      if (cVar1 == 'l') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator()";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
    }
    goto switchD_000268da_caseD_62;
  case 100:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'V') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator/=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'v') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator/";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'e') {
LAB_00026c6c:
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator*";
LAB_0002700e:
          puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
          sVar6 = strlen(pcVar8);
          puVar5[2] = pcVar8;
          puVar5[3] = pcVar8 + sVar6;
          *puVar5 = &PTR_LAB_00022116_1_000315a8;
          puVar5[1] = 0x1010107;
          return puVar5;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'l') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
          sVar6 = strlen("operator delete");
          puVar5[2] = "operator delete";
          puVar5[3] = "operator delete" + sVar6;
          *puVar5 = &PTR_LAB_00022116_1_000315a8;
          puVar5[1] = 0x1010107;
          return puVar5;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'a') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
          sVar6 = strlen("operator delete[]");
          puVar5[2] = "operator delete[]";
          puVar5[3] = "operator delete[]" + sVar6;
          *puVar5 = &PTR_LAB_00022116_1_000315a8;
          puVar5[1] = 0x1010107;
          return puVar5;
        }
        goto LAB_00026f56;
      }
    }
    break;
  case 0x65:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'O') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator^=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'q') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator==";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'o') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator^";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
    }
    break;
  case 0x67:
    if (1 < uVar9) {
      if (puVar7[1] == 't') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator>";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      if (puVar7[1] == 'e') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator>=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
    }
    break;
  case 0x69:
    if ((1 < uVar9) && (puVar7[1] == 'x')) {
      *param_1 = puVar7 + 2;
      if (__stack_chk_guard == puVar5) {
        pcVar8 = "operator[]";
        goto LAB_00027076;
      }
      goto LAB_00026f56;
    }
    break;
  case 0x6c:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'S') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator<<=";
          goto LAB_00027034;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 't') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator<";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'i') {
        *param_1 = puVar7 + 2;
        iVar4 = FUN_00026790(param_1);
        if (iVar4 != 0) {
          puVar3 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0xc);
          puVar3[2] = iVar4;
          *puVar3 = &PTR_LAB_00022116_1_00031c38;
          puVar3[1] = 0x1010113;
          goto switchD_000268da_caseD_62;
        }
      }
      else {
        if (cVar1 == 's') {
          *param_1 = puVar7 + 2;
          if (__stack_chk_guard == puVar5) {
            pcVar8 = "operator<<";
            goto LAB_00027076;
          }
          goto LAB_00026f56;
        }
        if (cVar1 == 'e') {
          *param_1 = puVar7 + 2;
          if (__stack_chk_guard == puVar5) {
            pcVar8 = "operator<=";
            goto LAB_00027076;
          }
          goto LAB_00026f56;
        }
      }
    }
    break;
  case 0x6d:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'I') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator-=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'L') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator*=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'm') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator--";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'l') goto LAB_00026c6c;
      if (cVar1 == 'i') goto LAB_00026c88;
    }
    break;
  case 0x6e:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'w') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
          sVar6 = strlen("operator new");
          puVar5[2] = "operator new";
          puVar5[3] = "operator new" + sVar6;
          *puVar5 = &PTR_LAB_00022116_1_000315a8;
          puVar5[1] = 0x1010107;
          return puVar5;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'e') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator!=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'g') {
LAB_00026c88:
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard != puVar5) goto LAB_00026f56;
        pcVar8 = "operator-";
        goto LAB_0002700e;
      }
      if (cVar1 == 't') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator!";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'a') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          puVar5 = (undefined4 *)FUN_00027300(param_1,"operator new[]");
          return puVar5;
        }
        goto LAB_00026f56;
      }
    }
    break;
  case 0x6f:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'R') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator|=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'r') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator|";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'o') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator||";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
    }
    break;
  case 0x70:
    if (uVar9 < 2) break;
    puVar3 = (undefined4 *)0x0;
    switch(puVar7[1]) {
    case 0x6c:
    case 0x73:
      *param_1 = puVar7 + 2;
      if (__stack_chk_guard == puVar5) {
        pcVar8 = "operator+";
        goto LAB_0002700e;
      }
      break;
    case 0x6d:
      *param_1 = puVar7 + 2;
      if (__stack_chk_guard == puVar5) {
        pcVar8 = "operator->*";
        goto LAB_00027034;
      }
      break;
    case 0x6e:
    case 0x6f:
    case 0x71:
    case 0x72:
      goto switchD_000268da_caseD_62;
    case 0x70:
      *param_1 = puVar7 + 2;
      if (__stack_chk_guard == puVar5) {
        pcVar8 = "operator++";
LAB_00027076:
        puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
        sVar6 = strlen(pcVar8);
        puVar5[2] = pcVar8;
        puVar5[3] = pcVar8 + sVar6;
        *puVar5 = &PTR_LAB_00022116_1_000315a8;
        puVar5[1] = 0x1010107;
        return puVar5;
      }
      break;
    case 0x74:
      *param_1 = puVar7 + 2;
      if (__stack_chk_guard == puVar5) {
        pcVar8 = "operator->";
        goto LAB_00027076;
      }
      break;
    default:
      puVar3 = (undefined4 *)0x0;
      if (puVar7[1] == 'L') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator+=";
          goto LAB_00027076;
        }
        break;
      }
      goto switchD_000268da_caseD_62;
    }
    goto LAB_00026f56;
  case 0x71:
    if ((1 < uVar9) && (puVar7[1] == 'u')) {
      *param_1 = puVar7 + 2;
      if (__stack_chk_guard == puVar5) {
        pcVar8 = "operator?";
        goto LAB_0002700e;
      }
      goto LAB_00026f56;
    }
    break;
  case 0x72:
    if (1 < uVar9) {
      cVar1 = puVar7[1];
      if (cVar1 == 'M') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator%=";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'S') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator>>=";
          goto LAB_00027034;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 's') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator>>";
          goto LAB_00027076;
        }
        goto LAB_00026f56;
      }
      if (cVar1 == 'm') {
        *param_1 = puVar7 + 2;
        if (__stack_chk_guard == puVar5) {
          pcVar8 = "operator%";
          goto LAB_0002700e;
        }
        goto LAB_00026f56;
      }
    }
    break;
  case 0x73:
    if ((1 < uVar9) && (puVar7[1] == 's')) {
      *param_1 = puVar7 + 2;
      if (__stack_chk_guard == puVar5) {
        pcVar8 = "operator<=>";
LAB_00027034:
        puVar5 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
        sVar6 = strlen(pcVar8);
        puVar5[2] = pcVar8;
        puVar5[3] = pcVar8 + sVar6;
        *puVar5 = &PTR_LAB_00022116_1_000315a8;
        puVar5[1] = 0x1010107;
        return puVar5;
      }
      goto LAB_00026f56;
    }
    break;
  case 0x76:
    if ((1 < uVar9) && (0xfffffff5 < (byte)puVar7[1] - 0x3a)) {
      *param_1 = puVar7 + 2;
      local_24 = FUN_00026790(param_1);
      if (local_24 != 0) {
        puVar3 = (undefined4 *)FUN_00027264(param_1,&local_24);
        goto switchD_000268da_caseD_62;
      }
    }
  }
LAB_00026f3e:
  puVar3 = (undefined4 *)0x0;
switchD_000268da_caseD_62:
  puVar5 = puVar3;
  if (__stack_chk_guard == local_1c) {
    return puVar5;
  }
LAB_00026f56:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(puVar5);
}


// ==== FUN_000271c8 @ 000271c8

void FUN_000271c8(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_0001702c,&DAT_0001702d);
                    /* WARNING: Could not recover jumptable at 0x000271e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 8) + 0x10))(*(int **)(param_1 + 8),param_2);
  return;
}


// ==== FUN_00027264 @ 00027264

void FUN_00027264(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
  puVar1[1] = 0x1010104;
  *puVar1 = &PTR_LAB_00022116_1_00031c00;
  puVar1[2] = *param_2;
  return;
}


// ==== FUN_00027300 @ 00027300

undefined4 * FUN_00027300(int param_1,char *param_2)

{
  undefined4 *puVar1;
  size_t sVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  sVar2 = strlen(param_2);
  puVar1[2] = param_2;
  puVar1[3] = param_2 + sVar2;
  *puVar1 = &PTR_LAB_00022116_1_000315a8;
  puVar1[1] = 0x1010107;
  return puVar1;
}


// ==== FUN_00027370 @ 00027370

void FUN_00027370(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,"operator ","");
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  return;
}


// ==== FUN_0002739c @ 0002739c

void FUN_0002739c(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,"operator\"\" ","");
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  return;
}


// ==== FUN_000273c8 @ 000273c8

void FUN_000273c8(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00016aad,&DAT_00016aaf);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  return;
}


// ==== FUN_000273ec @ 000273ec

void FUN_000273ec(undefined4 param_1,int param_2)

{
  (**(code **)(**(int **)(param_2 + 8) + 0x18))();
  return;
}


// ==== FUN_000273fe @ 000273fe

void FUN_000273fe(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  FUN_00020684(*(undefined4 *)(param_1 + 0x14),param_2);
  return;
}


// ==== FUN_00027484 @ 00027484

void FUN_00027484(int param_1,undefined4 *param_2,undefined4 *param_3,undefined1 *param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
  puVar1[1] = 0x1010149;
  uVar3 = *param_2;
  *puVar1 = &PTR_LAB_00022116_1_00031d18;
  uVar2 = *param_3;
  puVar1[2] = uVar3;
  puVar1[3] = uVar2;
  *(undefined1 *)(puVar1 + 4) = *param_4;
  return;
}


// ==== FUN_000274c4 @ 000274c4

void FUN_000274c4(int param_1,undefined4 param_2)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x10) == '\0') {
    FUN_000206aa(param_2,0x2e);
    FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  }
  else {
    FUN_000206aa(param_2,0x5b);
    FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
    FUN_000206aa(param_2,0x5d);
  }
  iVar1 = *(int *)(param_1 + 0xc);
  if (1 < *(byte *)(iVar1 + 4) - 0x49) {
    FUN_00022150(param_2,&DAT_000162e9,&DAT_000162ec);
    iVar1 = *(int *)(param_1 + 0xc);
  }
  FUN_00020684(iVar1,param_2);
  return;
}


// ==== FUN_00027524 @ 00027524

void FUN_00027524(int param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_000206aa(param_2,0x5b);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_0001690f,&DAT_00016914);
  FUN_00020684(*(undefined4 *)(param_1 + 0xc),param_2);
  FUN_000206aa(param_2,0x5d);
  iVar1 = *(int *)(param_1 + 0x10);
  if (1 < *(byte *)(iVar1 + 4) - 0x49) {
    FUN_00022150(param_2,&DAT_000162e9,&DAT_000162ec);
    iVar1 = *(int *)(param_1 + 0x10);
  }
  FUN_00020684(iVar1,param_2);
  return;
}


// ==== FUN_00027588 @ 00027588

void FUN_00027588(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 8) != 0) {
    FUN_00020684(*(int *)(param_1 + 8),param_2);
  }
  FUN_000206aa(param_2,0x7b);
  FUN_00025e0c(param_1 + 0xc,param_2);
  FUN_000206aa(param_2,0x7d);
  return;
}


// ==== FUN_000275bc @ 000275bc

void FUN_000275bc(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  return;
}


// ==== FUN_0002760c @ 0002760c

void FUN_0002760c(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined1 param_7,undefined1 param_8)

{
  param_1[1] = 0x1010138;
  *(undefined1 *)((int)param_1 + 0x1d) = param_8;
  *(undefined1 *)(param_1 + 7) = param_7;
  param_1[6] = param_6;
  param_1[2] = param_2;
  param_1[3] = param_3;
  param_1[4] = param_4;
  param_1[5] = param_5;
  *param_1 = &PTR_LAB_00022116_1_00031df8;
  return;
}


// ==== FUN_0002763c @ 0002763c

void FUN_0002763c(int param_1,undefined4 param_2)

{
  if (*(char *)(param_1 + 0x1c) != '\0') {
    FUN_00022150(param_2,"::operator ","");
  }
  FUN_00022150(param_2,&DAT_000162ed,&DAT_000162f0);
  if (*(char *)(param_1 + 0x1d) != '\0') {
    FUN_00022150(param_2,&DAT_0001722f,&DAT_00017231);
  }
  FUN_000206aa(param_2,0x20);
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
    FUN_00025e0c(param_1 + 8,param_2);
    FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  }
  FUN_00020684(*(undefined4 *)(param_1 + 0x10),param_2);
  if (*(int *)(param_1 + 0x18) == 0) {
    return;
  }
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00025e0c(param_1 + 0x14,param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00027700 @ 00027700

void FUN_00027700(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  FUN_00020684(*(undefined4 *)(param_1 + 0x10),param_2);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0x14),*(undefined4 *)(param_1 + 0x18));
  return;
}


// ==== FUN_0002772c @ 0002772c

void FUN_0002772c(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_000160e7,&DAT_000160ec);
  FUN_00020684(*(undefined4 *)(param_1 + 0xc),param_2);
  FUN_00022150(param_2,&DAT_00016455,&DAT_0001645a);
  FUN_00020684(*(undefined4 *)(param_1 + 0x10),param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00027854 @ 00027854

void FUN_00027854(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_000171c2,&DAT_000171cb);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00027890 @ 00027890

void FUN_00027890(int param_1,undefined4 *param_2,undefined1 *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
  puVar1[1] = 0x101012a;
  *puVar1 = &PTR_LAB_00022116_1_00031fb8;
  puVar1[2] = *param_2;
  *(undefined1 *)(puVar1 + 3) = *param_3;
  puVar1[4] = *param_4;
  return;
}


// ==== FUN_000278d0 @ 000278d0

void FUN_000278d0(int param_1,undefined4 param_2)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar2 = "std::allocator";
  pcVar1 = "";
  switch(*(undefined4 *)(param_1 + 8)) {
  case 0:
    break;
  case 1:
    pcVar2 = "std::basic_string";
    pcVar1 = "";
    break;
  case 2:
    pcVar2 = "std::basic_string<char, std::char_traits<char>, std::allocator<char> >";
    pcVar1 = "";
    break;
  case 3:
    pcVar2 = "std::basic_istream<char, std::char_traits<char> >";
    goto LAB_0002790c;
  case 4:
    pcVar2 = "std::basic_ostream<char, std::char_traits<char> >";
LAB_0002790c:
    pcVar1 = pcVar2 + 0x31;
    break;
  case 5:
    pcVar2 = "std::basic_iostream<char, std::char_traits<char> >";
    pcVar1 = "";
    break;
  default:
    return;
  }
  FUN_00022150(param_2,pcVar2,pcVar1);
  return;
}


// ==== FUN_00027940 @ 00027940

void FUN_00027940(undefined4 param_1,int param_2)

{
  FUN_000207f4(param_1,(&PTR_s_allocator_00032598)[*(int *)(param_2 + 8)]);
  return;
}


// ==== FUN_000279b8 @ 000279b8

void FUN_000279b8(int *param_1,int *param_2)

{
  int iVar1;
  uint local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  local_20 = 0;
  iVar1 = FUN_00022aae(param_2,&local_20);
  if ((iVar1 == 0) && (iVar1 = *param_2, local_20 <= (uint)(param_2[1] - iVar1))) {
    *param_2 = local_20 + iVar1;
    *param_1 = iVar1;
    param_1[1] = local_20 + iVar1;
  }
  else {
    *param_1 = 0;
    param_1[1] = 0;
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00027a1c @ 00027a1c

void FUN_00027a1c(int param_1,undefined4 param_2)

{
  (**(code **)(**(int **)(param_1 + 8) + 0x10))(*(int **)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_0001645b,&DAT_00016460);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  FUN_00022150(param_2,&DAT_000167e1,&DAT_000167e2);
  return;
}


// ==== FUN_00027a6c @ 00027a6c

void FUN_00027a6c(int param_1,undefined4 param_2)

{
  FUN_000206aa(param_2,0x5b);
  FUN_00025e0c(param_1 + 8,param_2);
  FUN_000206aa(param_2,0x5d);
  return;
}


// ==== FUN_00027a96 @ 00027a96

byte * FUN_00027a96(byte *param_1,byte *param_2)

{
  uint uVar1;
  byte *pbVar2;
  
  if (param_1 != param_2) {
    if (*param_1 == 0x5f) {
      if (param_1 + 1 != param_2) {
        uVar1 = (uint)param_1[1];
        if (0xfffffff5 < uVar1 - 0x3a) {
          return param_1 + 2;
        }
        if (uVar1 == 0x5f) {
          for (pbVar2 = param_1 + 2; pbVar2 != param_2; pbVar2 = pbVar2 + 1) {
            if (*pbVar2 - 0x3a < 0xfffffff6) {
              if (*pbVar2 == 0x5f) {
                param_1 = pbVar2 + 1;
              }
              return param_1;
            }
          }
        }
      }
    }
    else {
      pbVar2 = param_1;
      if (0xfffffff5 < *param_1 - 0x3a) {
        do {
          pbVar2 = pbVar2 + 1;
          if (pbVar2 == param_2) {
            return param_2;
          }
        } while (0xfffffff4 < *pbVar2 - 0x3a && *pbVar2 != 0x2f);
      }
    }
  }
  return param_1;
}


// ==== FUN_00027afc @ 00027afc

void FUN_00027afc(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  puVar1[1] = 0x1010118;
  uVar3 = *param_2;
  *puVar1 = &PTR_LAB_00022116_1_00032060;
  uVar2 = *param_3;
  puVar1[2] = uVar3;
  puVar1[3] = uVar2;
  return;
}


// ==== FUN_00027b2c @ 00027b2c

void FUN_00027b2c(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2,&DAT_00016aad,&DAT_00016aaf);
  FUN_00020684(*(undefined4 *)(param_1 + 0xc),param_2);
  return;
}


// ==== FUN_00027b5c @ 00027b5c

void FUN_00027b5c(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0xc);
  *puVar1 = &PTR_LAB_00022116_1_00032098;
  puVar1[2] = *param_2;
  puVar1[1] = 0x1010129;
  return;
}


// ==== FUN_00027b88 @ 00027b88

void FUN_00027b88(int param_1,undefined4 param_2)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar2 = "std::allocator";
  pcVar1 = "";
  switch(*(undefined4 *)(param_1 + 8)) {
  case 0:
    break;
  case 1:
    pcVar2 = "std::basic_string";
    pcVar1 = "";
    break;
  case 2:
    pcVar2 = "std::string";
    pcVar1 = "";
    break;
  case 3:
    pcVar2 = "std::istream";
    goto LAB_00027bc4;
  case 4:
    pcVar2 = "std::ostream";
LAB_00027bc4:
    pcVar1 = pcVar2 + 0xc;
    break;
  case 5:
    pcVar2 = "std::iostream";
    pcVar1 = "";
    break;
  default:
    return;
  }
  FUN_00022150(param_2,pcVar2,pcVar1);
  return;
}


// ==== FUN_00027bf8 @ 00027bf8

void FUN_00027bf8(undefined4 param_1,int param_2)

{
  FUN_000207f4(param_1,(&PTR_s_allocator_000325b0)[*(int *)(param_2 + 8)]);
  return;
}


// ==== FUN_00027cfc @ 00027cfc

void FUN_00027cfc(int param_1,int *param_2)

{
  FUN_00022150(param_2,&DAT_00015e04,&DAT_00015e05);
  FUN_00025e0c(param_1 + 8,param_2);
  if ((param_2[1] != 0) && (*(char *)(param_2[1] + *param_2 + -1) == '>')) {
    FUN_00022150(param_2,&DAT_000161a1,&DAT_000161a2);
  }
  FUN_00022150(param_2,&DAT_000168fb,&DAT_000168fc);
  return;
}


// ==== FUN_00027d58 @ 00027d58

void FUN_00027d58(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00020684(*(undefined4 *)(param_1 + 0xc),param_2);
  return;
}


// ==== FUN_00027d72 @ 00027d72

void FUN_00027d72(undefined4 param_1,int param_2)

{
  (**(code **)(**(int **)(param_2 + 8) + 0x18))();
  return;
}


// ==== FUN_00027d84 @ 00027d84

void FUN_00027d84(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_00017379,&DAT_0001737e);
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  return;
}


// ==== FUN_00027da8 @ 00027da8

void FUN_00027da8(undefined4 param_1,int param_2)

{
  (**(code **)(**(int **)(param_2 + 8) + 0x18))();
  return;
}


// ==== FUN_00027dc4 @ 00027dc4

void FUN_00027dc4(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2," [enable_if:","");
  FUN_00025e0c(param_1 + 8,param_2);
  FUN_000206aa(param_2,0x5d);
  return;
}


// ==== FUN_00027e00 @ 00027e00

void FUN_00027e00(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 8);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x10))(piVar1,param_2);
    iVar2 = FUN_00022c9a(*(undefined4 *)(param_1 + 8),param_2);
    if (iVar2 == 0) {
      FUN_00022150(param_2,&DAT_000161a1,&DAT_000161a2);
    }
  }
  FUN_00020684(*(undefined4 *)(param_1 + 0xc),param_2);
  return;
}


// ==== FUN_00027e3c @ 00027e3c

void FUN_00027e3c(int param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  undefined *puVar3;
  undefined *puVar4;
  
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00025e0c(param_1 + 0x10,param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  piVar1 = *(int **)(param_1 + 8);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x14))(piVar1,param_2);
  }
  uVar2 = *(uint *)(param_1 + 0x1c);
  if ((uVar2 & 1) != 0) {
    FUN_00022150(param_2," const","");
    uVar2 = *(uint *)(param_1 + 0x1c);
  }
  if ((int)(uVar2 << 0x1e) < 0) {
    FUN_00022150(param_2," volatile","");
    uVar2 = *(uint *)(param_1 + 0x1c);
  }
  if ((int)(uVar2 << 0x1d) < 0) {
    FUN_00022150(param_2," restrict","");
  }
  if (*(char *)(param_1 + 0x20) == '\x01') {
    puVar3 = &DAT_00016cd4;
    puVar4 = &DAT_00016cd6;
  }
  else {
    if (*(char *)(param_1 + 0x20) != '\x02') goto LAB_00027ecc;
    puVar3 = &DAT_00016a14;
    puVar4 = &DAT_00016a17;
  }
  FUN_00022150(param_2,puVar3,puVar4);
LAB_00027ecc:
  if (*(int *)(param_1 + 0x18) == 0) {
    return;
  }
  FUN_00020684(*(int *)(param_1 + 0x18),param_2);
  return;
}


// ==== FUN_00027efc @ 00027efc

void FUN_00027efc(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2,&DAT_00016875,&DAT_00016877);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00027f48 @ 00027f48

void FUN_00027f48(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  char *pcVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined **ppuVar11;
  char *pcVar12;
  undefined1 uVar13;
  int unaff_r5;
  undefined4 unaff_r6;
  undefined1 auStack_b4 [128];
  
  iVar1 = __stack_chk_guard;
  uVar2 = FUN_000225a4(param_1);
  iVar3 = FUN_0002079c(param_1,&DAT_000167ec,&DAT_000167ee);
  if (iVar3 == 0) {
    iVar3 = FUN_0002079c(param_1,&DAT_000166dd,&DAT_000166df);
    if (iVar3 == 0) {
      iVar3 = FUN_0002079c(param_1,&DAT_00015e93,&DAT_00015e95);
      if (iVar3 != 0) {
        iVar3 = param_1[2];
        iVar6 = param_1[3];
        while( true ) {
          pcVar5 = (char *)*param_1;
          if ((pcVar5 != (char *)param_1[1]) && (*pcVar5 == 'E')) {
            *param_1 = pcVar5 + 1;
            FUN_00021f18(auStack_b4 + 0x84,param_1,iVar6 - iVar3 >> 2);
            puVar4 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
            uVar8 = 0x1010111;
            ppuVar11 = &PTR_LAB_00022116_1_000322c8;
            puVar4[2] = unaff_r5;
            puVar4[3] = unaff_r6;
            goto LAB_000280fa;
          }
          unaff_r5 = FUN_00020e00(param_1);
          if (unaff_r5 == 0) break;
          FUN_00021ea4(param_1 + 2,auStack_b4 + 0x84);
        }
        goto LAB_000280ae;
      }
      puVar4 = (undefined4 *)0x0;
    }
    else {
      iVar3 = FUN_00022cf0(param_1);
      if (((iVar3 == 0) || (pcVar5 = (char *)*param_1, pcVar5 == (char *)param_1[1])) ||
         (*pcVar5 != 'E')) goto LAB_000280ae;
      *param_1 = pcVar5 + 1;
      puVar4 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0xc);
      uVar8 = 0x1010110;
      puVar4[2] = iVar3;
      ppuVar11 = &PTR_LAB_00022116_1_00032290;
LAB_000280fa:
      *puVar4 = ppuVar11;
      puVar4[1] = uVar8;
    }
  }
  else {
    puVar4 = (undefined4 *)FUN_000282e8(param_1,"noexcept");
  }
  FUN_0002079c(param_1,&DAT_00016b8c,&DAT_00016b8e);
  pcVar5 = (char *)*param_1;
  if ((pcVar5 != (char *)param_1[1]) && (*pcVar5 == 'F')) {
    pcVar12 = pcVar5 + 1;
    *param_1 = pcVar12;
    if ((pcVar12 != (char *)param_1[1]) && (*pcVar12 == 'Y')) {
      *param_1 = pcVar5 + 2;
    }
    iVar3 = FUN_00020e00(param_1);
    if (iVar3 != 0) {
      iVar6 = param_1[2];
      iVar10 = param_1[3];
LAB_00027fdc:
      while (pcVar5 = (char *)*param_1, pcVar5 != (char *)param_1[1]) {
        if (*pcVar5 != 'v') {
          if (*pcVar5 != 'E') break;
          uVar13 = 0;
          *param_1 = pcVar5 + 1;
          goto LAB_0002810e;
        }
        *param_1 = pcVar5 + 1;
      }
      iVar7 = FUN_0002079c(param_1,&DAT_00016b23,&DAT_00016b25);
      if (iVar7 == 0) {
        iVar7 = FUN_0002079c(param_1,&DAT_00017389,&DAT_0001738b);
        if (iVar7 == 0) {
          unaff_r5 = FUN_00020e00(param_1);
          if (unaff_r5 != 0) {
            FUN_00021ea4(param_1 + 2,auStack_b4 + 0x84);
            goto LAB_00027fdc;
          }
          goto LAB_000280ae;
        }
        uVar13 = 2;
      }
      else {
        uVar13 = 1;
      }
LAB_0002810e:
      FUN_00021f18(auStack_b4 + 0x84,param_1,iVar10 - iVar6 >> 2);
      puVar9 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x20);
      puVar9[7] = puVar4;
      *(undefined1 *)(puVar9 + 6) = uVar13;
      *puVar9 = &PTR_LAB_00028484_1_00032300;
      puVar9[1] = 0x1000f;
      puVar9[2] = iVar3;
      puVar9[3] = unaff_r5;
      puVar9[4] = unaff_r6;
      puVar9[5] = uVar2;
      goto LAB_000280b0;
    }
  }
LAB_000280ae:
  puVar9 = (undefined4 *)0x0;
LAB_000280b0:
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar9);
  }
  return;
}


// ==== FUN_00028180 @ 00028180

void FUN_00028180(int *param_1,undefined4 param_2,int param_3,int param_4)

{
  int iVar1;
  char *pcVar2;
  int iVar3;
  uint uVar4;
  undefined *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int unaff_r5;
  int unaff_r6;
  int iVar8;
  undefined1 uVar9;
  int local_38;
  undefined4 uStack_34;
  
  iVar1 = __stack_chk_guard;
  pcVar2 = (char *)*param_1;
  local_38 = param_3;
  uStack_34 = param_4;
  if ((pcVar2 == (char *)param_1[1]) || (*pcVar2 != 'U')) {
    iVar3 = FUN_000225a4(param_1);
    puVar7 = (undefined4 *)FUN_00020e00(param_1);
    if (puVar7 != (undefined4 *)0x0) {
      if (iVar3 != 0) {
        puVar6 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x10);
        puVar6[2] = iVar3;
        puVar6[3] = puVar7;
        *(undefined1 *)(puVar6 + 1) = 3;
        *puVar6 = &PTR_LAB_000285f4_1_000323a8;
        *(undefined1 *)((int)puVar6 + 5) = *(undefined1 *)((int)puVar7 + 5);
        *(undefined2 *)((int)puVar6 + 6) = *(undefined2 *)((int)puVar7 + 6);
        puVar7 = puVar6;
      }
      goto LAB_0002827c;
    }
  }
  else {
    *param_1 = (int)(pcVar2 + 1);
    FUN_000279b8((int)register0x00000054 + -0x2c,param_1);
    if (unaff_r5 != unaff_r6) {
      iVar3 = FUN_00021884((int)register0x00000054 + -0x2c,"objcproto","");
      if (iVar3 == 0) {
        iVar3 = FUN_00028180(param_1);
        if (iVar3 != 0) {
          uVar9 = 2;
          puVar5 = &UNK_00032368;
          goto LAB_00028250;
        }
      }
      else {
        uVar4 = unaff_r6 - unaff_r5;
        iVar3 = *param_1;
        iVar8 = param_1[1];
        if (8 < uVar4) {
          uVar4 = 9;
        }
        *param_1 = uVar4 + unaff_r5;
        param_1[1] = unaff_r6;
        FUN_000279b8(&local_38,param_1);
        unaff_r6 = uStack_34;
        unaff_r5 = local_38;
        *param_1 = iVar3;
        param_1[1] = iVar8;
        if ((local_38 != uStack_34) && (iVar3 = FUN_00028180(param_1), iVar3 != 0)) {
          uVar9 = 10;
          puVar5 = &UNK_00032330;
LAB_00028250:
          puVar7 = (undefined4 *)FUN_000220a8(param_1 + 0x66,0x14);
          *(undefined1 *)(puVar7 + 1) = uVar9;
          *(undefined1 *)((int)puVar7 + 7) = 1;
          *(undefined2 *)((int)puVar7 + 5) = 0x101;
          puVar7[2] = iVar3;
          puVar7[3] = unaff_r5;
          puVar7[4] = unaff_r6;
          *puVar7 = puVar5 + 8;
          goto LAB_0002827c;
        }
      }
    }
  }
  puVar7 = (undefined4 *)0x0;
LAB_0002827c:
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar7);
  }
  return;
}


// ==== FUN_000282e8 @ 000282e8

undefined4 * FUN_000282e8(int param_1,char *param_2)

{
  undefined4 *puVar1;
  size_t sVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  sVar2 = strlen(param_2);
  puVar1[2] = param_2;
  puVar1[3] = param_2 + sVar2;
  *puVar1 = &PTR_LAB_00022116_1_000315a8;
  puVar1[1] = 0x1010107;
  return puVar1;
}


// ==== FUN_00028320 @ 00028320

undefined4 * FUN_00028320(int param_1)

{
  int iVar1;
  char *pcVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  char *pcVar5;
  
  iVar1 = FUN_0002079c(param_1,&DAT_000170a3,&DAT_000170a5);
  if (iVar1 == 0) {
    iVar1 = FUN_0002079c(param_1,&DAT_00016d8f,&DAT_00016d91);
    if (iVar1 == 0) {
      iVar1 = FUN_0002079c(param_1,&DAT_00016b8f,&DAT_00016b91);
      if (iVar1 == 0) {
        pcVar2 = (char *)0x0;
        pcVar5 = (char *)0x0;
      }
      else {
        pcVar2 = "enum";
        pcVar5 = "";
      }
    }
    else {
      pcVar2 = "union";
      pcVar5 = "";
    }
  }
  else {
    pcVar2 = "struct";
    pcVar5 = "";
  }
  puVar3 = (undefined4 *)FUN_000218c8(param_1,0);
  puVar4 = (undefined4 *)0x0;
  if (puVar3 != (undefined4 *)0x0) {
    if (pcVar2 == pcVar5) {
      puVar4 = puVar3;
    }
    else {
      puVar4 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
      puVar4[2] = pcVar2;
      puVar4[3] = pcVar5;
      puVar4[4] = puVar3;
      *puVar4 = &PTR_LAB_00022116_1_000324c0;
      puVar4[1] = 0x1010106;
    }
  }
  return puVar4;
}


// ==== FUN_000283d8 @ 000283d8

void FUN_000283d8(int param_1,int *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x14);
  iVar3 = *param_2;
  *puVar1 = &PTR_LAB_00028a00_1_00032530;
  uVar2 = *param_3;
  puVar1[2] = iVar3;
  puVar1[3] = uVar2;
  *(undefined2 *)((int)puVar1 + 6) = 0x101;
  *(undefined1 *)(puVar1 + 1) = 0xc;
  *(undefined1 *)(puVar1 + 4) = 0;
  *(undefined1 *)((int)puVar1 + 5) = *(undefined1 *)(iVar3 + 5);
  return;
}


// ==== FUN_00028414 @ 00028414

void FUN_00028414(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,"noexcept(","");
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  return;
}


// ==== FUN_00028450 @ 00028450

void FUN_00028450(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,&DAT_0001738c,&DAT_00017392);
  FUN_00025e0c(param_1 + 8,param_2);
  FUN_000206aa(param_2,0x29);
  return;
}


// ==== FUN_0002848c @ 0002848c

void FUN_0002848c(int param_1,undefined4 param_2)

{
  (**(code **)(**(int **)(param_1 + 8) + 0x10))(*(int **)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_000161a1,&DAT_000161a2);
  return;
}


// ==== FUN_000284b0 @ 000284b0

void FUN_000284b0(int param_1,undefined4 param_2)

{
  uint uVar1;
  undefined *puVar2;
  undefined *puVar3;
  
  FUN_00022150(param_2,&DAT_00016f71,&DAT_00016f72);
  FUN_00025e0c(param_1 + 0xc,param_2);
  FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  (**(code **)(**(int **)(param_1 + 8) + 0x14))(*(int **)(param_1 + 8),param_2);
  uVar1 = *(uint *)(param_1 + 0x14);
  if ((uVar1 & 1) != 0) {
    FUN_00022150(param_2," const","");
    uVar1 = *(uint *)(param_1 + 0x14);
  }
  if ((int)(uVar1 << 0x1e) < 0) {
    FUN_00022150(param_2," volatile","");
    uVar1 = *(uint *)(param_1 + 0x14);
  }
  if ((int)(uVar1 << 0x1d) < 0) {
    FUN_00022150(param_2," restrict","");
  }
  if (*(char *)(param_1 + 0x18) == '\x01') {
    puVar2 = &DAT_00016cd4;
    puVar3 = &DAT_00016cd6;
  }
  else {
    if (*(char *)(param_1 + 0x18) != '\x02') goto LAB_0002853c;
    puVar2 = &DAT_00016a14;
    puVar3 = &DAT_00016a17;
  }
  FUN_00022150(param_2,puVar2,puVar3);
LAB_0002853c:
  if (*(int *)(param_1 + 0x1c) == 0) {
    return;
  }
  FUN_000206aa(param_2,0x20);
  FUN_00020684(*(undefined4 *)(param_1 + 0x1c),param_2);
  return;
}


// ==== FUN_00028578 @ 00028578

void FUN_00028578(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2,&DAT_00015e04,&DAT_00015e05);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  FUN_00022150(param_2,&DAT_000168fb,&DAT_000168fc);
  return;
}


// ==== FUN_000285c4 @ 000285c4

void FUN_000285c4(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2,&DAT_000161a1,&DAT_000161a2);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  return;
}


// ==== FUN_00028674 @ 00028674

void FUN_00028674(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  uVar2 = param_2[1];
  puVar1[2] = *param_2;
  puVar1[3] = uVar2;
  *puVar1 = &PTR_LAB_00022116_1_000315a8;
  puVar1[1] = 0x1010107;
  return;
}


// ==== FUN_000286a4 @ 000286a4

void FUN_000286a4(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)FUN_000220a8(param_1 + 0x198,0x10);
  puVar1[1] = 0x1010119;
  uVar3 = *param_2;
  *puVar1 = &PTR_LAB_00022116_1_00032418;
  uVar2 = *param_3;
  puVar1[2] = uVar3;
  puVar1[3] = uVar2;
  return;
}


// ==== FUN_000286d4 @ 000286d4

void FUN_000286d4(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,"pixel vector[","");
  FUN_00020684(*(undefined4 *)(param_1 + 8),param_2);
  FUN_00022150(param_2,&DAT_000167e1,&DAT_000167e2);
  return;
}


// ==== FUN_00028710 @ 00028710

void FUN_00028710(int param_1,undefined4 param_2)

{
  FUN_00020684(*(undefined4 *)(param_1 + 8));
  FUN_00022150(param_2," vector[","");
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00020684(*(int *)(param_1 + 0xc),param_2);
  }
  FUN_00022150(param_2,&DAT_000167e1,&DAT_000167e2);
  return;
}


// ==== FUN_00028764 @ 00028764

void FUN_00028764(int param_1,int *param_2)

{
  if ((param_2[1] == 0) || (*(char *)(param_2[1] + *param_2 + -1) != ']')) {
    FUN_00022150(param_2,&DAT_000161a1,&DAT_000161a2);
  }
  FUN_00022150(param_2,&DAT_00016070,&DAT_00016071);
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00020684(*(int *)(param_1 + 0xc),param_2);
  }
  FUN_00022150(param_2,&DAT_000167e1,&DAT_000167e2);
                    /* WARNING: Could not recover jumptable at 0x000287b6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 8) + 0x14))(*(int **)(param_1 + 8),param_2);
  return;
}


// ==== FUN_0002883c @ 0002883c

void FUN_0002883c(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_00022cae(*(undefined4 *)(param_1 + 0xc));
  if ((iVar1 != 0) || (iVar1 = FUN_00022cc2(*(undefined4 *)(param_1 + 0xc),param_2), iVar1 != 0)) {
    FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  }
                    /* WARNING: Could not recover jumptable at 0x0002886e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0xc) + 0x14))(*(int **)(param_1 + 0xc),param_2);
  return;
}


// ==== FUN_00028878 @ 00028878

void FUN_00028878(int param_1,undefined4 param_2)

{
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  FUN_000206aa(param_2,0x20);
  FUN_00020684(*(undefined4 *)(param_1 + 0x10),param_2);
  return;
}


// ==== FUN_000288a8 @ 000288a8

void FUN_000288a8(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  undefined *puVar4;
  undefined *puVar5;
  undefined *puVar6;
  
  piVar1 = *(int **)(param_1 + 8);
  if ((char)piVar1[1] == '\n') {
    iVar2 = FUN_000289a8();
    if (iVar2 == 0) {
      piVar1 = *(int **)(param_1 + 8);
      goto LAB_000288e2;
    }
    iVar2 = *(int *)(param_1 + 8);
    FUN_00022150(param_2,&DAT_000166e0,&DAT_000166e3);
    puVar3 = *(undefined **)(iVar2 + 0xc);
    puVar5 = *(undefined **)(iVar2 + 0x10);
    puVar4 = &DAT_000168fc;
    puVar6 = &DAT_000168fb;
  }
  else {
LAB_000288e2:
    (**(code **)(*piVar1 + 0x10))(piVar1,param_2);
    iVar2 = FUN_00022cae(*(undefined4 *)(param_1 + 8),param_2);
    if (iVar2 != 0) {
      FUN_00022150(param_2,&DAT_000161a1,&DAT_000161a2);
    }
    iVar2 = FUN_00022cae(*(undefined4 *)(param_1 + 8),param_2);
    puVar3 = &DAT_00016f71;
    puVar4 = &DAT_000164bc;
    puVar5 = &DAT_00016f72;
    puVar6 = &DAT_000164bb;
    if ((iVar2 == 0) && (iVar2 = FUN_00022cc2(*(undefined4 *)(param_1 + 8),param_2), iVar2 == 0))
    goto LAB_00028930;
  }
  FUN_00022150(param_2,puVar3,puVar5);
LAB_00028930:
  FUN_00022150(param_2,puVar6,puVar4);
  return;
}


// ==== FUN_00028958 @ 00028958

void FUN_00028958(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 8);
  if (*(char *)(iVar1 + 4) == '\n') {
    iVar1 = FUN_000289a8();
    if (iVar1 != 0) {
      return;
    }
    iVar1 = *(int *)(param_1 + 8);
  }
  iVar1 = FUN_00022cae(iVar1,param_2);
  if ((iVar1 != 0) || (iVar1 = FUN_00022cc2(*(undefined4 *)(param_1 + 8),param_2), iVar1 != 0)) {
    FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f8);
  }
                    /* WARNING: Could not recover jumptable at 0x0002899c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 8) + 0x14))(*(int **)(param_1 + 8),param_2);
  return;
}


// ==== FUN_000289a8 @ 000289a8

void FUN_000289a8(int param_1,char *param_2,char *param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  char *local_20;
  char *local_1c;
  undefined4 local_18;
  
  iVar1 = __stack_chk_guard;
  if (*(char *)(*(int *)(param_1 + 8) + 4) == '\a') {
    local_18 = *(undefined4 *)(*(int *)(param_1 + 8) + 8);
    local_20 = "objc_object";
    local_1c = "";
    uVar2 = FUN_00026328(&local_18,&local_20);
  }
  else {
    uVar2 = 0;
    local_20 = param_2;
    local_1c = param_3;
    local_18 = param_4;
  }
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar2);
  }
  return;
}


// ==== FUN_00028af4 @ 00028af4

void FUN_00028af4(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined1 auStack_24 [4];
  int *local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  if (*(char *)(param_1 + 0x10) == '\0') {
    *(undefined1 *)(param_1 + 0x10) = 1;
    FUN_00028b90(auStack_24,param_1,param_2);
    iVar1 = FUN_00022cae(local_20,param_2);
    if ((iVar1 != 0) || (iVar1 = FUN_00022cc2(local_20,param_2), iVar1 != 0)) {
      iVar1 = __strlen_chk(&DAT_000170f7,2);
      FUN_00022150(param_2,&DAT_000170f7,&DAT_000170f7 + iVar1);
    }
    (**(code **)(*local_20 + 0x14))(local_20,param_2);
    *(undefined1 *)(param_1 + 0x10) = 0;
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00028b90 @ 00028b90

void FUN_00028b90(int *param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_2 + 8);
  iVar3 = *(int *)(param_2 + 0xc);
  while( true ) {
    iVar2 = *piVar1;
    *param_1 = iVar3;
    param_1[1] = (int)piVar1;
    iVar2 = (**(code **)(iVar2 + 0xc))(piVar1,param_3);
    if (*(char *)(iVar2 + 4) != '\f') break;
    piVar1 = *(int **)(iVar2 + 8);
    if (*(int *)(iVar2 + 0xc) < iVar3) {
      iVar3 = *(int *)(iVar2 + 0xc);
    }
  }
  return;
}


// ==== FUN_00028bc6 @ 00028bc6

void FUN_00028bc6(int param_1,undefined4 param_2)

{
  (**(code **)(**(int **)(param_1 + 8) + 0x10))(*(int **)(param_1 + 8),param_2);
  FUN_00022150(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  return;
}


// ==== FUN_00028fe8 @ 00028fe8

void FUN_00028fe8(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 unaff_r5;
  undefined1 auStackY_98 [128];
  
  iVar1 = __stack_chk_guard;
  FUN_0002aaac(param_1,0,param_2,0,auStackY_98 + 0x88);
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(unaff_r5);
  }
  return;
}


// ==== FUN_00029024 @ 00029024

void FUN_00029024(int param_1,int param_2)

{
  FUN_0001fe34(param_2);
  if (param_1 != 0) {
    FUN_000202a0(*(undefined4 *)(param_2 + -0x14));
  }
                    /* WARNING: Subroutine does not return */
  FUN_00020238();
}


// ==== FUN_00029040 @ 00029040

void FUN_00029040(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  
  FUN_00029380(param_2,0,param_1);
  FUN_00029380(param_2,1,*param_3);
  uVar2 = param_3[4];
  uVar1 = FUN_00028fe8(param_2,0xf);
  FUN_00029380(param_2,0xf,uVar1 & 1 | uVar2);
  return;
}


// ==== FUN_00029088 @ 00029088

/* WARNING: Type propagation algorithm not settling */

void FUN_00029088(undefined **param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  char cVar1;
  char *pcVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined **unaff_r4;
  undefined **ppuVar7;
  undefined **ppuVar8;
  int unaff_r8;
  undefined **ppuVar9;
  undefined *puVar10;
  undefined *unaff_r11;
  longlong lVar11;
  undefined4 *local_38;
  undefined4 local_28;
  
  local_28 = (undefined **)((int)register0x00000054 + -8);
  if (param_1 == (undefined **)0x0) {
    param_1 = (undefined **)FUN_00029024(0,0,param_3,param_4,param_2,param_3);
  }
  FUN_0001fe34();
  pcVar2 = (char *)FUN_0001fc94(param_1);
  if (pcVar2 == (char *)0x0) {
    puVar10 = (undefined *)FUN_0002028c();
    ppuVar9 = (undefined **)0x0;
    puVar3 = (undefined *)FUN_00020224();
    ppuVar7 = unaff_r4;
  }
  else {
    unaff_r11 = param_1[0xd];
    ppuVar9 = param_1 + -10;
    puVar3 = param_1[-6];
    puVar10 = param_1[-5];
    unaff_r8 = (int)unaff_r11 >> 0x1f;
    ppuVar7 = (undefined **)param_1[0xb];
  }
  FUN_00020278(puVar3);
  FUN_0001fe34();
  local_38 = param_4;
  if (pcVar2 == (char *)0x0) goto LAB_00029144;
  local_28 = (undefined **)((int)ppuVar7 + 1);
  FUN_000291e8(&local_28,*(char *)ppuVar7);
  ppuVar4 = (undefined **)((int)local_28 + 1);
  cVar1 = *(char *)local_28;
  ppuVar7 = (undefined **)((int)ppuVar7 + 1);
  puVar6 = param_4;
  local_28 = ppuVar4;
  if (cVar1 == -1) goto LAB_00029148;
  pcVar2 = (char *)FUN_0002928c(&local_28);
  ppuVar7 = local_28;
  local_38 = (undefined4 *)FUN_0001ffd0();
  ppuVar4 = (undefined **)*local_38;
  puVar6 = param_4;
  if (ppuVar4 == (undefined **)0x0) goto LAB_00029148;
  unaff_r4 = ppuVar4 + 10;
  iVar5 = FUN_0001fc94();
  pcVar2 = pcVar2 + (int)ppuVar7;
  ppuVar8 = param_1;
  if ((iVar5 != 0) && (ppuVar4 != ppuVar9)) goto LAB_0002914e;
  do {
    ppuVar7 = (undefined **)&DAT_00032660;
    param_1 = &PTR_PTR_0003266c;
    iVar5 = FUN_000292b0(unaff_r11,unaff_r8,pcVar2,&PTR_PTR_0003266c,(int)register0x00000054 + -0x2c
                         ,ppuVar8);
    if (iVar5 == 0) {
      FUN_0001fea4();
      puVar6 = (undefined4 *)FUN_0001fcbc(4);
      *puVar6 = &DAT_00032660;
      FUN_0001fcf8(puVar6,&PTR_PTR_0003266c,FUN_00029a0a + 1);
      goto LAB_000291b8;
    }
    FUN_00029a0a((int)register0x00000054 + -0x2c);
LAB_00029144:
    FUN_0001fea4();
    puVar6 = local_38;
LAB_00029148:
    local_38 = puVar6;
    ppuVar4 = ppuVar7;
    FUN_000202a0(puVar10);
LAB_0002914e:
    puVar3 = ppuVar4[2];
    lVar11 = FUN_0001fc8a(unaff_r4);
    if (lVar11 == 0x434c4e47432b2b01) {
      ppuVar7 = (undefined **)ppuVar4[1];
    }
    else {
      ppuVar7 = ppuVar4 + 0x20;
    }
    iVar5 = FUN_000292b0(unaff_r11,unaff_r8,pcVar2,puVar3,ppuVar7,param_1);
    ppuVar8 = param_1;
  } while (iVar5 != 0);
  ppuVar4[7] = (undefined *)-(int)ppuVar4[7];
  local_38[1] = local_38[1] + 1;
  FUN_0001fea4();
  FUN_0001fea4();
  FUN_0001fe34(unaff_r4);
  FUN_0001ff60();
LAB_000291b8:
  FUN_0001fea4();
                    /* WARNING: Subroutine does not return */
  FUN_0001fc74();
}


// ==== FUN_000291e8 @ 000291e8

void FUN_000291e8(int *param_1,uint param_2,ushort *param_3)

{
  uint *puVar1;
  ushort *puVar2;
  uint uVar3;
  ushort *local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  if (param_2 == 0xff) {
    puVar1 = (uint *)0x0;
    local_18 = param_3;
    goto LAB_00029268;
  }
  local_18 = (ushort *)*param_1;
  switch(param_2 & 0xf) {
  case 0:
  case 3:
  case 0xb:
    puVar2 = local_18 + 2;
    puVar1 = *(uint **)local_18;
    break;
  case 1:
    puVar1 = (uint *)FUN_0002928c(&local_18);
    goto LAB_00029248;
  case 2:
    puVar2 = local_18 + 1;
    puVar1 = (uint *)(uint)*local_18;
    break;
  case 4:
  case 0xc:
    puVar2 = local_18 + 4;
    puVar1 = *(uint **)local_18;
    break;
  default:
                    /* WARNING: Subroutine does not return */
    abort();
  case 9:
    puVar1 = (uint *)FUN_00029320(&local_18);
    goto LAB_00029248;
  case 10:
    puVar2 = local_18 + 1;
    puVar1 = (uint *)(int)(short)*local_18;
  }
  local_18 = puVar2;
LAB_00029248:
  uVar3 = (param_2 & 0x7f) >> 4;
  if (uVar3 == 0) {
LAB_00029258:
    if (puVar1 == (uint *)0x0) goto LAB_00029262;
    if ((int)(param_2 << 0x18) < 0) {
      puVar1 = (uint *)*puVar1;
    }
  }
  else {
    if (uVar3 != 1) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    if (puVar1 != (uint *)0x0) {
      puVar1 = (uint *)((int)puVar1 + *param_1);
      goto LAB_00029258;
    }
LAB_00029262:
    puVar1 = (uint *)0x0;
  }
  *param_1 = (int)local_18;
LAB_00029268:
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(puVar1);
  }
  return;
}


// ==== FUN_0002928c @ 0002928c

uint FUN_0002928c(undefined4 *param_1)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar5;
  byte *pbVar4;
  uint uVar6;
  
  uVar6 = 0;
  uVar3 = 0;
  pbVar5 = (byte *)*param_1;
  do {
    pbVar4 = pbVar5 + 1;
    bVar1 = *pbVar5;
    uVar2 = uVar6 & 0xff;
    uVar6 = uVar6 + 7;
    uVar3 = uVar3 | (bVar1 & 0x7f) << uVar2;
    pbVar5 = pbVar4;
  } while ((int)((uint)bVar1 << 0x18) < 0);
  *param_1 = pbVar4;
  return uVar3;
}


// ==== FUN_000292b0 @ 000292b0

uint FUN_000292b0(uint param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  byte *pbVar8;
  byte *pbVar7;
  int *piVar9;
  uint uVar10;
  int iVar11;
  int *piVar12;
  undefined1 auStack_30 [8];
  
  iVar1 = __stack_chk_guard;
  if (param_3 == 0) {
    puVar3 = (undefined4 *)FUN_00029024(0,param_6);
    uVar6 = 0;
    uVar5 = 0;
    pbVar8 = (byte *)*puVar3;
    do {
      pbVar7 = pbVar8 + 1;
      uVar10 = (uint)*pbVar8;
      uVar4 = uVar6 & 0xff;
      uVar6 = uVar6 + 7;
      uVar5 = uVar5 | (uVar10 & 0x7f) << uVar4;
      pbVar8 = pbVar7;
    } while ((int)(uVar10 << 0x18) < 0);
    *puVar3 = pbVar7;
    uVar4 = uVar5;
    if (uVar6 < 0x20) {
      uVar4 = uVar5 | -1 << (uVar6 & 0xff);
    }
    if (-1 < (int)(uVar10 << 0x19)) {
      uVar4 = uVar5;
    }
    return uVar4;
  }
  piVar9 = (int *)(param_3 + ~param_1 * 4);
  piVar12 = piVar9;
  do {
    iVar11 = *piVar12;
    if (iVar11 == 0) break;
    iVar2 = (**(code **)(**(int **)((int)piVar9 + iVar11) + 0x10))
                      (*(int **)((int)piVar9 + iVar11),param_4,auStack_30 + 8);
    piVar9 = piVar9 + 1;
    piVar12 = piVar12 + 1;
  } while (iVar2 == 0);
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar1);
  }
  return (uint)(iVar11 == 0);
}


// ==== FUN_00029320 @ 00029320

uint FUN_00029320(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar5;
  byte *pbVar4;
  uint uVar6;
  
  uVar3 = 0;
  uVar2 = 0;
  pbVar5 = (byte *)*param_1;
  do {
    pbVar4 = pbVar5 + 1;
    uVar6 = (uint)*pbVar5;
    uVar1 = uVar3 & 0xff;
    uVar3 = uVar3 + 7;
    uVar2 = uVar2 | (uVar6 & 0x7f) << uVar1;
    pbVar5 = pbVar4;
  } while ((int)(uVar6 << 0x18) < 0);
  *param_1 = pbVar4;
  uVar1 = uVar2;
  if (uVar3 < 0x20) {
    uVar1 = uVar2 | -1 << (uVar3 & 0xff);
  }
  if (-1 < (int)(uVar6 << 0x19)) {
    uVar1 = uVar2;
  }
  return uVar1;
}


// ==== FUN_00029380 @ 00029380

undefined8 FUN_00029380(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 unaff_r4;
  undefined1 auStack_94 [128];
  
  iVar1 = __stack_chk_guard;
  FUN_0002abc4(param_1,0,param_2,0);
  if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return CONCAT44(unaff_r4,auStack_94 + 0x84);
}


// ==== FUN_000293bc @ 000293bc

void FUN_000293bc(size_t param_1,undefined4 param_2,void *param_3)

{
  int iVar1;
  void *pvVar2;
  void *local_18;
  int local_14;
  
  local_14 = __stack_chk_guard;
  if (param_1 == 0) {
    param_1 = 1;
  }
  local_18 = param_3;
  iVar1 = posix_memalign(&local_18,0x10,param_1);
  if (iVar1 == 0) {
    pvVar2 = local_18;
  }
  else {
    pvVar2 = (void *)FUN_00029404(param_1);
  }
  if (__stack_chk_guard != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(pvVar2);
  }
  return;
}


// ==== FUN_00029404 @ 00029404

void FUN_00029404(int param_1)

{
  ushort *puVar1;
  ushort *puVar2;
  uint uVar3;
  ushort *puVar4;
  uint uVar5;
  uint uVar6;
  undefined2 *local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  local_20 = &DAT_00036dd0;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00036dd0);
  uVar3 = (param_1 + 3U >> 2) + 1;
  if (DAT_00036dd4 == (ushort *)0x0) {
    DAT_00036dd4 = (ushort *)&DAT_00036bd0;
    DAT_00036bd0 = 0x800080;
  }
  puVar1 = DAT_00036dd4;
  puVar4 = (ushort *)0x0;
  while( true ) {
    puVar2 = puVar1;
    if ((puVar2 == (ushort *)0x0) || (puVar2 == &DAT_00036dd0)) goto LAB_0002948e;
    uVar6 = (uint)puVar2[1];
    if (uVar3 < uVar6) break;
    if (uVar3 == uVar6) {
      if (puVar4 == (ushort *)0x0) {
        DAT_00036dd4 = (ushort *)(&DAT_00036bd0 + *puVar2);
      }
      else {
        *puVar4 = *puVar2;
      }
      *puVar2 = 0;
LAB_0002948e:
      FUN_000295a0(&local_20);
      if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail(local_1c);
      }
      return;
    }
    puVar1 = (ushort *)(&DAT_00036bd0 + *puVar2);
    puVar4 = puVar2;
  }
  uVar5 = uVar6 - uVar3 & 0xffff;
  puVar2[1] = (ushort)(uVar6 - uVar3);
  puVar2[uVar5 * 2] = 0;
  puVar2[uVar5 * 2 + 1] = (ushort)uVar3;
  goto LAB_0002948e;
}


// ==== FUN_000294c0 @ 000294c0

void FUN_000294c0(undefined4 *param_1)

{
  int iVar1;
  ushort *puVar2;
  ushort *puVar3;
  ushort uVar4;
  ushort *puVar5;
  ushort *puVar6;
  undefined1 auStack_a8 [128];
  
  iVar1 = __stack_chk_guard;
  if ((param_1 < &DAT_00036bd0) || ((undefined4 *)0x36dcf < param_1)) {
    free(param_1);
    return;
  }
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00036dd0);
  puVar3 = (ushort *)(param_1 + -1);
  puVar2 = DAT_00036dd4;
  puVar6 = (ushort *)0x0;
  do {
    puVar5 = puVar2;
    if ((puVar5 == (ushort *)0x0) || (puVar5 == &DAT_00036dd0)) {
      uVar4 = (ushort)((uint)(DAT_00036dd4 + -0x1b5e8) >> 2);
LAB_0002956e:
      DAT_00036dd4 = puVar3;
      *puVar3 = uVar4;
LAB_00029570:
      FUN_000295a0(auStack_a8 + 0x80);
      if (__stack_chk_guard != iVar1) {
                    /* WARNING: Subroutine does not return */
        __stack_chk_fail();
      }
      return;
    }
    uVar4 = puVar5[1];
    if (puVar5 + (uint)uVar4 * 2 == puVar3) {
      puVar5[1] = *(short *)((int)param_1 + -2) + uVar4;
      goto LAB_00029570;
    }
    if (puVar3 + (uint)*(ushort *)((int)param_1 + -2) * 2 == puVar5) {
      *(ushort *)((int)param_1 + -2) = *(ushort *)((int)param_1 + -2) + uVar4;
      if (puVar6 == (ushort *)0x0) {
        uVar4 = *puVar5;
        goto LAB_0002956e;
      }
      *puVar6 = (ushort)((uint)(param_1 + -0xdaf5) >> 2);
      goto LAB_00029570;
    }
    puVar2 = (ushort *)(&DAT_00036bd0 + *puVar5);
    puVar6 = puVar5;
  } while( true );
}


// ==== FUN_000295a0 @ 000295a0

undefined4 * FUN_000295a0(undefined4 *param_1)

{
  pthread_mutex_unlock((pthread_mutex_t *)*param_1);
  return param_1;
}


// ==== FUN_000295bc @ 000295bc

void FUN_000295bc(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_00029b04();
  free(__ptr);
  return;
}


// ==== FUN_000295cc @ 000295cc

void FUN_000295cc(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_00029b04();
  free(__ptr);
  return;
}


// ==== FUN_000295dc @ 000295dc

bool FUN_000295dc(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (param_3 == 0) {
    iVar1 = *(int *)(param_1 + 4) - *(int *)(param_2 + 4);
  }
  else {
    if (param_1 == param_2) {
      return true;
    }
    iVar1 = strcmp(*(char **)(param_1 + 4),*(char **)(param_2 + 4));
  }
  return iVar1 == 0;
}


// ==== FUN_00029604 @ 00029604

void FUN_00029604(int param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  int *local_54;
  undefined4 local_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 local_44;
  undefined4 local_40;
  int iStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 local_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 local_24;
  undefined4 local_20;
  int local_1c;
  
  local_1c = __stack_chk_guard;
  if ((*(int *)(param_1 + 4) != *(int *)(param_2 + 4)) &&
     (piVar1 = (int *)FUN_0002971c(param_2,&PTR_PTR_000325c8,&PTR_PTR_000325d4,0),
     piVar1 != (int *)0x0)) {
    iStack_3c = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
    uStack_38 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
    local_44 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
    local_50 = 0;
    local_40 = 0;
    local_30 = 0;
    local_20 = 0;
    local_24 = 1;
    uStack_48 = 0xffffffff;
    local_54 = piVar1;
    iStack_4c = param_1;
    uStack_34 = local_44;
    iStack_2c = iStack_3c;
    uStack_28 = uStack_38;
    (**(code **)(*piVar1 + 0x1c))(piVar1,&local_54,*param_3,1);
    if (iStack_3c == 1) {
      *param_3 = local_44;
    }
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_1c);
  }
  return;
}


// ==== FUN_000296e0 @ 000296e0

void FUN_000296e0(int param_1,int param_2,int param_3,undefined4 param_4)

{
  if (*(int *)(param_1 + 4) != *(int *)(*(int *)(param_2 + 8) + 4)) {
    return;
  }
  if (*(int *)(param_2 + 0x10) == 0) {
    *(undefined4 *)(param_2 + 0x18) = param_4;
    *(undefined4 *)(param_2 + 0x24) = 1;
    *(int *)(param_2 + 0x10) = param_3;
    return;
  }
  if (*(int *)(param_2 + 0x10) == param_3) {
    if (*(int *)(param_2 + 0x18) == 2) {
      *(undefined4 *)(param_2 + 0x18) = param_4;
      return;
    }
  }
  else {
    *(undefined1 *)(param_2 + 0x36) = 1;
    *(undefined4 *)(param_2 + 0x18) = 2;
    *(int *)(param_2 + 0x24) = *(int *)(param_2 + 0x24) + 1;
  }
  return;
}


// ==== FUN_000296f8 @ 000296f8

void FUN_000296f8(int param_1,int param_2,int param_3,undefined4 param_4)

{
  if (*(int *)(param_1 + 4) != *(int *)(*(int *)(param_2 + 8) + 4)) {
                    /* WARNING: Could not recover jumptable at 0x00029712. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 8) + 0x1c))();
    return;
  }
  if (*(int *)(param_2 + 0x10) == 0) {
    *(undefined4 *)(param_2 + 0x18) = param_4;
    *(undefined4 *)(param_2 + 0x24) = 1;
    *(int *)(param_2 + 0x10) = param_3;
    return;
  }
  if (*(int *)(param_2 + 0x10) == param_3) {
    if (*(int *)(param_2 + 0x18) == 2) {
      *(undefined4 *)(param_2 + 0x18) = param_4;
      return;
    }
  }
  else {
    *(undefined1 *)(param_2 + 0x36) = 1;
    *(undefined4 *)(param_2 + 0x18) = 2;
    *(int *)(param_2 + 0x24) = *(int *)(param_2 + 0x24) + 1;
  }
  return;
}


// ==== FUN_0002971c @ 0002971c

void FUN_0002971c(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int local_58;
  int *local_54;
  undefined4 uStack_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 local_40;
  uint local_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 local_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined3 uStack_24;
  int local_1c;
  
  uStack_44 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
  local_40 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
  local_3c = *(uint *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
  local_1c = __stack_chk_guard;
  piVar1 = *(int **)(*param_1 + -4);
  local_48 = 0;
  local_38 = 0;
  iVar2 = (int)param_1 + *(int *)(*param_1 + -8);
  uStack_2c = local_3c & 0xffffff;
  uStack_28 = 0;
  uStack_24 = 0;
  local_58 = param_3;
  local_54 = param_1;
  uStack_50 = param_2;
  local_4c = param_4;
  uStack_34 = uStack_44;
  local_30 = local_40;
  if (piVar1[1] == *(int *)(param_3 + 4)) {
    uStack_28 = 1;
    (**(code **)(*piVar1 + 0x14))(piVar1,&local_58,iVar2,iVar2,1,0);
  }
  else {
    (**(code **)(*piVar1 + 0x18))(piVar1,&local_58,iVar2,1,0);
  }
  if (__stack_chk_guard != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_1c);
  }
  return;
}


// ==== FUN_000297f8 @ 000297f8

void FUN_000297f8(undefined4 param_1,int param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  
  *(undefined1 *)(param_2 + 0x35) = 1;
  if (*(int *)(param_2 + 4) == param_4) {
    *(undefined1 *)(param_2 + 0x34) = 1;
    if (*(int *)(param_2 + 0x10) == 0) {
      *(int *)(param_2 + 0x18) = param_5;
      *(undefined4 *)(param_2 + 0x24) = 1;
      *(int *)(param_2 + 0x10) = param_3;
      if (param_5 != 1) {
        return;
      }
      iVar1 = *(int *)(param_2 + 0x30);
    }
    else {
      if (*(int *)(param_2 + 0x10) != param_3) {
        *(int *)(param_2 + 0x24) = *(int *)(param_2 + 0x24) + 1;
        goto LAB_00029848;
      }
      iVar1 = *(int *)(param_2 + 0x18);
      if (*(int *)(param_2 + 0x18) == 2) {
        *(int *)(param_2 + 0x18) = param_5;
        iVar1 = param_5;
      }
      if (*(int *)(param_2 + 0x30) != 1) {
        return;
      }
    }
    if (iVar1 == 1) {
LAB_00029848:
      *(undefined1 *)(param_2 + 0x36) = 1;
      return;
    }
  }
  return;
}


// ==== FUN_00029850 @ 00029850

void FUN_00029850(int param_1,undefined4 *param_2,int param_3,int param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  bool bVar3;
  undefined1 auStackY_a8 [128];
  undefined1 *puVar4;
  
  puVar4 = auStackY_a8 + 0xa0;
  iVar1 = FUN_000295dc(param_1,param_2[2],param_5);
  if (iVar1 == 0) {
    iVar1 = FUN_000295dc(param_1,*param_2,param_5);
    if (iVar1 == 0) {
      (**(code **)(**(int **)(param_1 + 8) + 0x18))
                (*(int **)(param_1 + 8),param_2,param_3,param_4,param_5,puVar4);
    }
    else {
      iVar1 = param_2[4];
      bVar3 = iVar1 != param_3;
      if (bVar3) {
        iVar1 = param_2[5];
      }
      if (bVar3 && iVar1 != param_3) {
        param_2[8] = param_4;
        if (param_2[0xb] != 4) {
          *(undefined2 *)(param_2 + 0xd) = 0;
          (**(code **)(**(int **)(param_1 + 8) + 0x14))
                    (*(int **)(param_1 + 8),param_2,param_3,param_3,1,param_5);
          if (*(char *)((int)param_2 + 0x35) == '\0') {
            uVar2 = 4;
          }
          else {
            uVar2 = 3;
            if (*(char *)(param_2 + 0xd) != '\0') {
              param_2[0xb] = 3;
              return;
            }
          }
          param_2[0xb] = uVar2;
        }
        param_2[5] = param_3;
        param_2[10] = param_2[10] + 1;
        if ((param_2[9] == 1) && (param_2[6] == 2)) {
          *(undefined1 *)((int)param_2 + 0x36) = 1;
        }
      }
      else if (param_4 == 1) {
        param_2[8] = 1;
      }
    }
  }
  else if ((param_2[1] == param_3) && (param_2[7] != 1)) {
    param_2[7] = param_4;
  }
  return;
}


// ==== FUN_0002998a @ 0002998a

void FUN_0002998a(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6)

{
  int iVar1;
  
  iVar1 = FUN_000295dc(param_1,*(undefined4 *)(param_2 + 8),param_6);
  if (iVar1 == 0) {
    (**(code **)(**(int **)(param_1 + 8) + 0x14))
              (*(int **)(param_1 + 8),param_2,param_3,param_4,param_5,param_6);
    return;
  }
  FUN_000297f8(iVar1,param_2,param_3,param_4);
  return;
}


// ==== FUN_00029a0a @ 00029a0a

void FUN_00029a0a(void)

{
  return;
}


// ==== FUN_00029a1c @ 00029a1c

void FUN_00029a1c(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_00029a0a_1_00032644;
  return;
}


// ==== FUN_00029a3c @ 00029a3c

void FUN_00029a3c(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_00029a3c_1_0003268c;
  FUN_00029a64(param_1 + 1);
  FUN_00029a0a(param_1);
  return;
}


// ==== FUN_00029a64 @ 00029a64

int * FUN_00029a64(int *param_1)

{
  bool bVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  
  iVar2 = *param_1;
  DataMemoryBarrier(0x1b);
  puVar3 = (uint *)(iVar2 + -4);
  do {
    ExclusiveAccess(puVar3);
    uVar4 = *puVar3;
    bVar1 = (bool)hasExclusiveAccess(puVar3);
  } while (!bVar1);
  *puVar3 = uVar4 - 1;
  DataMemoryBarrier(0x1b);
  if (0x7fffffff < uVar4 - 1) {
    free((void *)(iVar2 + -0xc));
  }
  return param_1;
}


// ==== FUN_00029a94 @ 00029a94

void FUN_00029a94(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_00029a3c();
  free(__ptr);
  return;
}


// ==== FUN_00029aa8 @ 00029aa8

void FUN_00029aa8(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_00029aa8_1_000326a0;
  FUN_00029a64(param_1 + 1);
  FUN_00029a0a(param_1);
  return;
}


// ==== FUN_00029ad0 @ 00029ad0

void FUN_00029ad0(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_00029aa8();
  free(__ptr);
  return;
}


// ==== FUN_00029ae4 @ 00029ae4

void FUN_00029ae4(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_00029a3c();
  free(__ptr);
  return;
}


// ==== FUN_00029af4 @ 00029af4

void FUN_00029af4(void)

{
  void *__ptr;
  
  __ptr = (void *)FUN_00029a3c();
  free(__ptr);
  return;
}


// ==== FUN_00029b04 @ 00029b04

void FUN_00029b04(void)

{
  return;
}


// ==== FUN_00029b08 @ 00029b08

undefined4 * FUN_00029b08(void)

{
  pthread_once((pthread_once_t *)&DAT_00036dd8,FUN_00029b28 + 1);
  return &DAT_00036ddc;
}


// ==== FUN_00029b28 @ 00029b28

void FUN_00029b28(void)

{
  DAT_00036e04 = 0xffffffff;
  DAT_00036e08 = 0xffffffff;
  DAT_00036ddc = &DAT_00015eae;
  DAT_00036de0 = &DAT_00017076;
  DAT_00036de4 = &DAT_00017076;
  DAT_00036de8 = &DAT_00017076;
  DAT_00036dec = &DAT_00017076;
  DAT_00036df0 = &DAT_00017076;
  DAT_00036df4 = &DAT_00017076;
  DAT_00036df8 = &DAT_00017076;
  DAT_00036dfc = &DAT_00017076;
  DAT_00036e00 = &DAT_00017076;
  DAT_00036e0c = 0xffffffff;
  DAT_00036e10 = 0xffff;
  return;
}


// ==== FUN_00029b64 @ 00029b64

void FUN_00029b64(uint param_1,uint param_2)

{
  if (param_2 == 0) {
    FUN_0002a00c(0);
    return;
  }
  if (param_2 == 1) {
    return;
  }
  if (param_1 < param_2) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00029b98. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(&UNK_00029d20 + (LZCOUNT(param_2) - LZCOUNT(param_1)) * -0xc))();
  return;
}


// ==== FUN_00029d34 @ 00029d34

void * FUN_00029d34(size_t *param_1)

{
  undefined4 *__ptr;
  void *pvVar1;
  uint uVar2;
  void *__s;
  int iVar3;
  size_t sVar4;
  int *piVar5;
  
  sVar4 = param_1[2];
  DataMemoryBarrier(0xb);
  if (sVar4 == 0) {
    pthread_once((pthread_once_t *)&DAT_00036e20,FUN_00029f38);
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00036e24);
    sVar4 = param_1[2];
    if (sVar4 == 0) {
      sVar4 = DAT_00036e1c + 1;
      DataMemoryBarrier(0xb);
      DAT_00036e1c = sVar4;
      param_1[2] = sVar4;
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00036e24);
    __ptr = pthread_getspecific(DAT_00036e18);
    if (__ptr == (undefined4 *)0x0) goto LAB_00029e0c;
LAB_00029d64:
    uVar2 = __ptr[1];
    if (sVar4 <= uVar2) goto LAB_00029e58;
    iVar3 = (sVar4 + 0x11 & 0xfffffff0) - 2;
    __ptr = realloc(__ptr,iVar3 * 4 + 8);
    if (__ptr == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    memset(__ptr + uVar2 + 2,0,(iVar3 - uVar2) * 4);
  }
  else {
    __ptr = pthread_getspecific(DAT_00036e18);
    if (__ptr != (undefined4 *)0x0) goto LAB_00029d64;
LAB_00029e0c:
    iVar3 = (sVar4 + 0x11 & 0xfffffff0) - 2;
    __ptr = malloc(iVar3 * 4 + 8);
    if (__ptr == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    memset(__ptr + 2,0,iVar3 * 4);
    *__ptr = 1;
  }
  __ptr[1] = iVar3;
  pthread_setspecific(DAT_00036e18,__ptr);
LAB_00029e58:
  piVar5 = __ptr + sVar4 + 1;
  if ((void *)*piVar5 != (void *)0x0) {
    return (void *)*piVar5;
  }
  uVar2 = param_1[1];
  if (uVar2 < 5) {
    uVar2 = 4;
  }
  if ((uVar2 & uVar2 - 1) != 0) {
                    /* WARNING: Subroutine does not return */
    abort();
  }
  sVar4 = *param_1;
  pvVar1 = malloc(uVar2 + 3 + sVar4);
  if (pvVar1 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
    abort();
  }
  __s = (void *)((int)pvVar1 + uVar2 + 3 & -uVar2);
  *(void **)((int)__s + -4) = pvVar1;
  if ((void *)param_1[3] == (void *)0x0) {
    memset(__s,0,sVar4);
    *piVar5 = (int)__s;
    return __s;
  }
  memcpy(__s,(void *)param_1[3],sVar4);
  *piVar5 = (int)__s;
  return __s;
}


// ==== FUN_00029f08 @ 00029f08

void FUN_00029f08(void)

{
  if (DAT_00036e14 == '\x01') {
    pthread_key_delete(DAT_00036e18);
    DAT_00036e14 = 0;
    return;
  }
  return;
}


// ==== FUN_00029f38 @ 00029f38

void FUN_00029f38(void)

{
  int iVar1;
  
  iVar1 = pthread_key_create(&DAT_00036e18,FUN_00029f70);
  if (iVar1 != 0) {
                    /* WARNING: Subroutine does not return */
    abort();
  }
  DAT_00036e14 = 1;
  return;
}


// ==== FUN_00029f70 @ 00029f70

void FUN_00029f70(int *param_1)

{
  uint uVar1;
  uint uVar2;
  
  if (*param_1 != 0) {
    *param_1 = *param_1 + -1;
    pthread_setspecific(DAT_00036e18,param_1);
    return;
  }
  uVar1 = param_1[1];
  if (uVar1 != 0) {
    uVar2 = 0;
    do {
      if (param_1[uVar2 + 2] != 0) {
        free(*(void **)(param_1[uVar2 + 2] + -4));
        uVar1 = param_1[1];
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < uVar1);
  }
  free(param_1);
  return;
}


// ==== FUN_0002a00c @ 0002a00c

void FUN_0002a00c(void)

{
  return;
}


// ==== FUN_0002a010 @ 0002a010

ulonglong FUN_0002a010(uint param_1,uint param_2,uint param_3,uint param_4,uint *param_5)

{
  uint uVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  ulonglong uVar13;
  
  if (param_2 == 0) {
    if (param_4 == 0) {
      uVar13 = FUN_00029b64(param_1,param_3);
      uVar12 = (uint)uVar13;
      if (param_5 != (uint *)0x0) {
        uVar12 = param_1 - uVar12 * param_3;
        uVar13 = uVar13 & 0xffffffff;
      }
LAB_0002a1d4:
      if (param_5 != (uint *)0x0) {
        *param_5 = uVar12;
        param_5[1] = (uint)(uVar13 >> 0x20);
      }
      return uVar13 & 0xffffffff;
    }
    if (param_5 != (uint *)0x0) {
      param_2 = 0;
      *param_5 = param_1;
      param_5[1] = 0;
      param_1 = 0;
LAB_0002a084:
      return CONCAT44(param_2,param_1);
    }
  }
  else {
    if (param_3 != 0) {
      if (param_4 == 0) {
        if ((param_3 & param_3 - 1) == 0) {
          if (param_5 != (uint *)0x0) {
            *param_5 = param_3 - 1 & param_1;
            param_5[1] = 0;
          }
          if (param_3 != 1) {
            bVar3 = (byte)param_3;
            bVar4 = (byte)(param_3 >> 8);
            bVar5 = (byte)(param_3 >> 0x10);
            bVar2 = (byte)(param_3 >> 0x18);
            uVar12 = LZCOUNT((uint)(byte)((((((((bVar3 & 1) << 1 | bVar3 >> 1 & 1) << 1 |
                                              bVar3 >> 2 & 1) << 1 | bVar3 >> 3 & 1) << 1 |
                                            bVar3 >> 4 & 1) << 1 | bVar3 >> 5 & 1) << 1 |
                                          bVar3 >> 6 & 1) << 1 | bVar3 >> 7) << 0x18 |
                             (uint)(byte)((((((((bVar4 & 1) << 1 | bVar4 >> 1 & 1) << 1 |
                                              bVar4 >> 2 & 1) << 1 | bVar4 >> 3 & 1) << 1 |
                                            bVar4 >> 4 & 1) << 1 | bVar4 >> 5 & 1) << 1 |
                                          bVar4 >> 6 & 1) << 1 | bVar4 >> 7) << 0x10 |
                             (uint)(byte)((((((((bVar5 & 1) << 1 | bVar5 >> 1 & 1) << 1 |
                                              bVar5 >> 2 & 1) << 1 | bVar5 >> 3 & 1) << 1 |
                                            bVar5 >> 4 & 1) << 1 | bVar5 >> 5 & 1) << 1 |
                                          bVar5 >> 6 & 1) << 1 | bVar5 >> 7) << 8 |
                             (uint)(byte)((((((((bVar2 & 1) << 1 | bVar2 >> 1 & 1) << 1 |
                                              bVar2 >> 2 & 1) << 1 | bVar2 >> 3 & 1) << 1 |
                                            bVar2 >> 4 & 1) << 1 | bVar2 >> 5 & 1) << 1 |
                                          bVar2 >> 6 & 1) << 1 | bVar2 >> 7));
            return CONCAT44(param_2 >> uVar12,
                            (param_2 << 1) << (~uVar12 & 0x1f) | param_1 >> (uVar12 & 0x1f));
          }
          goto LAB_0002a084;
        }
        uVar12 = (LZCOUNT(param_3) - LZCOUNT(param_2)) + 0x21;
        if (uVar12 == 0x20) goto LAB_0002a1a4;
        if (0x1f < uVar12) {
          uVar8 = (LZCOUNT(param_3) - LZCOUNT(param_2)) + 1;
          uVar11 = 0;
          uVar7 = param_2 << (0x40 - uVar12 & 0xff) | param_1 >> (uVar8 & 0xff);
          uVar9 = param_2 >> (uVar8 & 0xff);
          uVar8 = param_1 << (0x40 - uVar12 & 0xff);
          goto LAB_0002a25c;
        }
        uVar7 = 0x20 - uVar12;
      }
      else {
        uVar7 = LZCOUNT(param_4) - LZCOUNT(param_2);
        if (0x1f < uVar7) goto LAB_0002a05c;
        uVar12 = uVar7 + 1;
        if (uVar12 == 0x20) {
LAB_0002a1a4:
          uVar8 = 0;
          uVar12 = 0x20;
          uVar11 = 0;
          uVar9 = param_2;
          uVar7 = param_1;
          goto LAB_0002a25c;
        }
        uVar7 = 0x1f - uVar7;
      }
      uVar8 = 0;
      uVar11 = param_2 >> (uVar12 & 0xff);
      uVar9 = param_2 << (uVar7 & 0xff) | param_1 >> (uVar12 & 0xff);
      uVar7 = param_1 << (uVar7 & 0xff);
LAB_0002a25c:
      uVar10 = 0;
      do {
        uVar6 = uVar8;
        uVar11 = uVar11 << 1 | uVar9 >> 0x1f;
        uVar8 = uVar9 << 1 | uVar7 >> 0x1f;
        uVar1 = (int)(~uVar11 + param_4 + (uint)CARRY4(~uVar8,param_3)) >> 0x1f;
        uVar9 = uVar8 - (param_3 & uVar1);
        uVar11 = uVar11 - ((param_4 & uVar1) + (uint)(uVar8 < (param_3 & uVar1)));
        uVar7 = uVar7 << 1 | uVar6 >> 0x1f;
        uVar8 = uVar10 | uVar6 << 1;
        uVar12 = uVar12 - 1;
        uVar10 = uVar1 & 1;
      } while (uVar12 != 0);
      if (param_5 != (uint *)0x0) {
        *param_5 = uVar9;
        param_5[1] = uVar11;
      }
      return CONCAT44((uVar6 & 0x7fffffff) >> 0x1e | uVar7 << 1,uVar8 << 1 | uVar1 & 1);
    }
    if (param_4 == 0) {
      return CONCAT44(param_2,param_1);
    }
    if (param_1 == 0) {
      uVar13 = FUN_00029b64(param_2,param_4);
      uVar12 = (uint)uVar13;
      if (param_5 != (uint *)0x0) {
        uVar13 = CONCAT44(param_2 - uVar12 * param_4,uVar12);
        uVar12 = 0;
      }
      goto LAB_0002a1d4;
    }
    if ((param_4 & param_4 - 1) == 0) {
      uVar12 = param_2;
      if (param_5 != (uint *)0x0) {
        uVar12 = param_4 - 1 & param_2;
      }
      bVar3 = (byte)param_4;
      bVar4 = (byte)(param_4 >> 8);
      bVar5 = (byte)(param_4 >> 0x10);
      bVar2 = (byte)(param_4 >> 0x18);
      if (param_5 != (uint *)0x0) {
        *param_5 = param_1;
        param_5[1] = uVar12;
      }
      param_2 = param_2 >>
                LZCOUNT((uint)(byte)((((((((bVar3 & 1) << 1 | bVar3 >> 1 & 1) << 1 | bVar3 >> 2 & 1)
                                         << 1 | bVar3 >> 3 & 1) << 1 | bVar3 >> 4 & 1) << 1 |
                                      bVar3 >> 5 & 1) << 1 | bVar3 >> 6 & 1) << 1 | bVar3 >> 7) <<
                        0x18 | (uint)(byte)((((((((bVar4 & 1) << 1 | bVar4 >> 1 & 1) << 1 |
                                                bVar4 >> 2 & 1) << 1 | bVar4 >> 3 & 1) << 1 |
                                              bVar4 >> 4 & 1) << 1 | bVar4 >> 5 & 1) << 1 |
                                            bVar4 >> 6 & 1) << 1 | bVar4 >> 7) << 0x10 |
                        (uint)(byte)((((((((bVar5 & 1) << 1 | bVar5 >> 1 & 1) << 1 | bVar5 >> 2 & 1)
                                         << 1 | bVar5 >> 3 & 1) << 1 | bVar5 >> 4 & 1) << 1 |
                                      bVar5 >> 5 & 1) << 1 | bVar5 >> 6 & 1) << 1 | bVar5 >> 7) << 8
                        | (uint)(byte)((((((((bVar2 & 1) << 1 | bVar2 >> 1 & 1) << 1 |
                                           bVar2 >> 2 & 1) << 1 | bVar2 >> 3 & 1) << 1 |
                                         bVar2 >> 4 & 1) << 1 | bVar2 >> 5 & 1) << 1 |
                                       bVar2 >> 6 & 1) << 1 | bVar2 >> 7));
      goto LAB_0002a0d4;
    }
    uVar8 = LZCOUNT(param_4) - LZCOUNT(param_2);
    if (uVar8 < 0x1f) {
      uVar12 = uVar8 + 1;
      uVar7 = param_1 << (0x1f - uVar8 & 0xff);
      uVar9 = param_2 << (0x1f - uVar8 & 0xff) | param_1 >> (uVar12 & 0xff);
      uVar11 = param_2 >> (uVar12 & 0xff);
      uVar8 = 0;
      goto LAB_0002a25c;
    }
LAB_0002a05c:
    if (param_5 != (uint *)0x0) {
      *param_5 = param_1;
      param_5[1] = param_2;
    }
  }
  param_2 = 0;
LAB_0002a0d4:
  return (ulonglong)param_2;
}


// ==== memcpy @ 0002a2e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memcpy(__dest,__src,__n);
  return pvVar1;
}


// ==== memmove @ 0002a2e4

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memmove(__dest,__src,__n);
  return pvVar1;
}


// ==== FUN_0002a2e8 @ 0002a2e8

void FUN_0002a2e8(void *param_1,size_t param_2,int param_3)

{
  memset(param_1,param_3,param_2);
  return;
}


// ==== FUN_0002a2f8 @ 0002a2f8

void FUN_0002a2f8(void *param_1,size_t param_2)

{
  memset(param_1,0,param_2);
  return;
}


// ==== FUN_0002a304 @ 0002a304

void FUN_0002a304(undefined4 param_1,undefined4 param_2)

{
  undefined1 local_8 [4];
  
  FUN_0002a320(param_1,param_2,local_8);
  return;
}


// ==== FUN_0002a320 @ 0002a320

uint FUN_0002a320(uint param_1,uint param_2,uint *param_3)

{
  uint uVar1;
  
  if (param_2 == 0) {
    uVar1 = FUN_0002a00c(0);
    return uVar1;
  }
  if (param_2 == 1) {
    *param_3 = 0;
    return param_1;
  }
  if (param_1 < param_2) {
    *param_3 = param_1;
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0002a350. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (*(code *)(&UNK_0002a4c8 + (LZCOUNT(param_2) - LZCOUNT(param_1)) * -0xc))();
  return uVar1;
}


// ==== FUN_0002a500 @ 0002a500

void FUN_0002a500(void)

{
  FUN_0002a010();
  return;
}


// ==== FUN_0002a524 @ 0002a524

uint * FUN_0002a524(uint *param_1,undefined4 *param_2,int *param_3,uint *param_4)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  uint uVar4;
  
  uVar2 = *param_1;
  if ((int)uVar2 < 0) {
    uVar4 = (uVar2 & 0xfffffff) >> 0x18;
    if (uVar4 == 0) {
      uVar3 = 1;
      iVar1 = 4;
    }
    else {
      if (uVar4 != 3) {
        param_4 = (uint *)0x0;
      }
      if (uVar4 != 3 && uVar4 != 1) {
        return param_4;
      }
      iVar1 = ((uVar2 & 0xffffff) >> 0x10) * 4 + 4;
      uVar3 = 2;
    }
    *param_3 = iVar1;
    *param_2 = uVar3;
  }
  else {
    *param_2 = 1;
    param_1 = param_1 + 1;
    *param_3 = (*param_1 >> 0x18) * 4 + 4;
  }
  return param_1;
}


// ==== FUN_0002a5a4 @ 0002a5a4

undefined4 FUN_0002a5a4(undefined4 param_1,int param_2,uint param_3,uint param_4)

{
  byte bVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint local_30;
  undefined4 *local_28;
  
  if (param_3 < param_4) {
    local_30 = 0;
    do {
      uVar8 = param_3 + 1;
      bVar1 = *(byte *)(param_2 + (param_3 ^ 3));
      uVar7 = (uint)bVar1;
      if ((bVar1 & 0x80) == 0) {
        FUN_0002b9d8(param_1,0xd,&local_28);
        if ((bVar1 & 0x40) == 0) {
          local_28 = local_28 + uVar7 + 1;
        }
        else {
          local_28 = (undefined4 *)((int)local_28 + (-4 - (uVar7 * 4 & 0xfc)));
        }
LAB_0002a5e8:
        FUN_0002ba30(param_1,0xd);
        goto LAB_0002a5f8;
      }
      switch((uVar7 & 0xf0) - 0x80 >> 4) {
      case 0:
        if (param_4 <= uVar8) {
          return 9;
        }
        uVar8 = (uVar7 & 0xf) << 0xc | (uint)*(byte *)(param_2 + (uVar8 ^ 3)) << 4;
        if (uVar8 == 0) {
          return 9;
        }
        FUN_0002ace0(param_1,0,uVar8,0);
        uVar8 = param_3 + 2;
        local_30 = local_30 | (uVar7 & 8) >> 3;
        break;
      case 1:
        if ((uVar7 & 0xd) == 0xd) {
          return 9;
        }
        FUN_0002b9d8(param_1,uVar7 & 0xf,&local_28);
LAB_0002a6ec:
        FUN_0002ba30(param_1,0xd,local_28);
        break;
      case 2:
        FUN_0002ace0(param_1,0,(0x20 << (uVar7 & 7)) - 0x10U | (uVar7 & 8) << 0xb,0);
        break;
      case 3:
        switch(uVar7) {
        case 0xb0:
          goto switchD_0002a73c_caseD_b0;
        case 0xb1:
          if (param_4 <= uVar8) {
            return 9;
          }
          bVar1 = *(byte *)(param_2 + (uVar8 ^ 3));
          uVar7 = (uint)bVar1;
          if (uVar7 == 0) {
            return 9;
          }
          if ((bVar1 & 0xf0) != 0) {
            return 9;
          }
          uVar3 = 0;
          uVar5 = 0;
          goto LAB_0002aa38;
        case 0xb2:
          uVar6 = 0;
          uVar7 = 0;
          do {
            if (param_4 <= uVar8) {
              return 9;
            }
            uVar4 = uVar8 ^ 3;
            uVar8 = uVar8 + 1;
            bVar1 = *(byte *)(param_2 + uVar4);
            uVar6 = uVar6 | (bVar1 & 0x7f) << (uVar7 & 0xff);
            uVar7 = uVar7 + 7;
          } while ((bVar1 & 0x80) != 0);
          FUN_0002b9d8(param_1,0xd,&local_28);
          local_28 = local_28 + uVar6 + 0x81;
          goto LAB_0002a5e8;
        case 0xb3:
          uVar5 = 1;
          uVar7 = (uint)*(byte *)(param_2 + (uVar8 ^ 3));
          uVar3 = 1;
          uVar7 = ((uVar7 | uVar7 << 0xc) & 0xf000f) + 1;
LAB_0002aa38:
          FUN_0002ace0(param_1,uVar3,uVar7,uVar5);
          puVar9 = local_28;
LAB_0002aa3c:
          local_28 = puVar9;
          uVar8 = param_3 + 2;
          break;
        case 0xb4:
          iVar2 = FUN_0002b9d8(param_1,0xd,&local_28);
          if (iVar2 == 0) {
            local_28 = local_28 + 1;
            goto LAB_0002a6ec;
          }
          break;
        case 0xb5:
        case 0xb6:
        case 0xb7:
          return 9;
        default:
          FUN_0002ace0(param_1,1,(uVar7 & 7) + 0x80001,1);
        }
        break;
      case 4:
        if ((uVar7 & 0xfe) != 200) {
          return 9;
        }
        bVar1 = *(byte *)(param_2 + (uVar8 ^ 3));
        uVar7 = (uint)(bVar1 >> 4) | (uint)(uVar7 == 200) << 4;
        uVar8 = uVar7 + (bVar1 & 0xf);
        if (0x1f < uVar8) {
          return 9;
        }
        iVar2 = FUN_0002b9d8(param_1,0xd,&local_28);
        puVar9 = local_28;
        if (iVar2 == 0) {
          do {
            uVar3 = *local_28;
            puVar9 = local_28 + 2;
            if (uVar7 == 0x20) goto LAB_0002aa3c;
            puVar9 = local_28 + 1;
            local_28 = local_28 + 2;
            iVar2 = FUN_0002bb70(param_1,uVar7 + 0x100,uVar3,*puVar9);
            puVar9 = local_28;
            if (iVar2 != 0) goto LAB_0002aa3c;
            uVar7 = uVar7 + 1;
          } while (uVar7 < uVar8 + 1);
          FUN_0002ba30(param_1,0xd,local_28);
          puVar9 = local_28;
        }
        goto LAB_0002aa3c;
      case 5:
        if ((bVar1 & 8) != 0) {
          return 9;
        }
        iVar2 = FUN_0002b9d8(param_1,0xd,&local_28);
        if (iVar2 == 0) {
          uVar3 = *local_28;
          puVar9 = local_28 + 1;
          local_28 = local_28 + 2;
          iVar2 = FUN_0002bb70(param_1,0x108,uVar3,*puVar9);
          if (iVar2 == 0) {
            uVar7 = uVar7 & 7;
            if ((bVar1 & 7) != 0) {
              uVar3 = *local_28;
              puVar9 = local_28 + 1;
              local_28 = local_28 + 2;
              iVar2 = FUN_0002bb70(param_1,0x109,uVar3,*puVar9);
              if (iVar2 != 0) break;
              if (uVar7 != 1) {
                uVar3 = *local_28;
                puVar9 = local_28 + 1;
                local_28 = local_28 + 2;
                iVar2 = FUN_0002bb70(param_1,0x10a,uVar3,*puVar9);
                if (iVar2 != 0) break;
                if (uVar7 != 2) {
                  uVar3 = *local_28;
                  puVar9 = local_28 + 1;
                  local_28 = local_28 + 2;
                  iVar2 = FUN_0002bb70(param_1,0x10b,uVar3,*puVar9);
                  if (iVar2 != 0) break;
                  if (uVar7 != 3) {
                    uVar3 = *local_28;
                    puVar9 = local_28 + 1;
                    local_28 = local_28 + 2;
                    iVar2 = FUN_0002bb70(param_1,0x10c,uVar3,*puVar9);
                    if (iVar2 != 0) break;
                    if (uVar7 != 4) {
                      uVar3 = *local_28;
                      puVar9 = local_28 + 1;
                      local_28 = local_28 + 2;
                      iVar2 = FUN_0002bb70(param_1,0x10d,uVar3,*puVar9);
                      if (iVar2 != 0) break;
                      if (uVar7 != 5) {
                        uVar3 = *local_28;
                        puVar9 = local_28 + 1;
                        local_28 = local_28 + 2;
                        iVar2 = FUN_0002bb70(param_1,0x10e,uVar3,*puVar9);
                        if (iVar2 != 0) break;
                        if (uVar7 != 6) {
                          uVar3 = *local_28;
                          puVar9 = local_28 + 1;
                          local_28 = local_28 + 2;
                          iVar2 = FUN_0002bb70(param_1,0x10f,uVar3,*puVar9);
                          if (iVar2 != 0) break;
                        }
                      }
                    }
                  }
                }
              }
            }
            goto LAB_0002a6ec;
          }
        }
        break;
      default:
        return 9;
      }
LAB_0002a5f8:
      param_3 = uVar8;
    } while (uVar8 < param_4);
switchD_0002a73c_caseD_b0:
    if (local_30 != 0) {
      return 8;
    }
  }
  FUN_0002b9d8(param_1,0xe,&local_28);
  FUN_0002ba30(param_1,0xf,local_28);
  return 8;
}


// ==== FUN_0002aaac @ 0002aaac

int FUN_0002aaac(undefined4 param_1,int param_2,uint param_3,uint param_4,undefined4 param_5)

{
  int iVar1;
  
  if (param_2 == 5) {
    if (param_4 == 0 && param_3 == 0) {
      param_3 = 0x8f;
LAB_0002ab3c:
      iVar1 = FUN_0002b9d8(param_1,param_3,param_5);
      return (uint)(iVar1 != 0) << 1;
    }
  }
  else if (param_2 == 1) {
    if ((param_4 & 0xfffffffb) == 1) {
      if (param_4 == 1) {
        if (param_3 < 0x10) {
          FUN_0002bc3c(param_1);
          goto LAB_0002ab5c;
        }
      }
      else if (param_3 < 0x20) {
LAB_0002ab5c:
        iVar1 = FUN_0002bb18(param_1,param_3 + 0x100,param_5);
        return (uint)(iVar1 != 0) << 1;
      }
    }
  }
  else {
    if (param_2 != 0) {
      fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","_Unwind_VRS_Get_Internal",
              "unsupported register class");
      fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    if ((param_3 < 0x10) && (param_4 == 0)) goto LAB_0002ab3c;
  }
  return 2;
}


// ==== FUN_0002abc4 @ 0002abc4

int FUN_0002abc4(undefined4 param_1,int param_2,uint param_3,uint param_4,undefined4 *param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_2 == 5) {
    if (param_4 == 0 && param_3 == 0) {
      uVar2 = *param_5;
      param_3 = 0x8f;
LAB_0002ac5c:
      iVar1 = FUN_0002ba30(param_1,param_3,uVar2);
      return (uint)(iVar1 != 0) << 1;
    }
  }
  else if (param_2 == 1) {
    if ((param_4 & 0xfffffffb) == 1) {
      if (param_4 == 1) {
        if (param_3 < 0x10) {
          FUN_0002bc3c(param_1);
LAB_0002ac78:
          iVar1 = FUN_0002bb70(param_1,param_3 + 0x100,*param_5,param_5[1]);
          return (uint)(iVar1 != 0) << 1;
        }
      }
      else if (param_3 < 0x20) goto LAB_0002ac78;
    }
  }
  else {
    if (param_2 != 0) {
      fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","_Unwind_VRS_Set","unsupported register class")
      ;
      fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    if ((param_3 < 0x10) && (param_4 == 0)) {
      uVar2 = *param_5;
      goto LAB_0002ac5c;
    }
  }
  return 2;
}


// ==== FUN_0002ace0 @ 0002ace0

int FUN_0002ace0(undefined4 param_1,int param_2,uint param_3,uint param_4)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  int local_30;
  undefined4 *local_2c;
  undefined4 *local_28;
  
  if (param_2 == 5) {
    if ((param_4 == 0 && param_3 == 0) && (iVar2 = FUN_0002b9d8(param_1,0xd,&local_30), iVar2 == 0))
    {
      local_30 = local_30 + 4;
      FUN_0002ba30(param_1,0xd);
      return 2;
    }
    return 2;
  }
  if (param_2 == 1) {
    if ((param_4 & 0xfffffffb) != 1) {
      return 2;
    }
    iVar2 = FUN_0002b9d8(param_1,0xd,&local_2c);
    if (iVar2 != 0) {
      return 2;
    }
    if ((param_3 & 0xffff) != 0) {
      uVar7 = param_3 >> 0x10;
      uVar5 = uVar7 + (param_3 & 0xffff);
      if (param_4 == 1) {
        iVar2 = 0x10 - uVar7;
        if (0x10 < uVar7) {
          iVar2 = 0;
        }
        do {
          uVar6 = *local_2c;
          if (iVar2 == 0) {
            return 2;
          }
          uVar3 = local_2c[1];
          local_2c = local_2c + 2;
          FUN_0002bc3c(param_1);
          iVar4 = FUN_0002bb70(param_1,uVar7 + 0x100,uVar6,uVar3);
          if (iVar4 != 0) {
            return 2;
          }
          uVar7 = uVar7 + 1;
          iVar2 = iVar2 + -1;
        } while (uVar7 < uVar5);
      }
      else {
        iVar2 = 0x20 - uVar7;
        if (0x20 < uVar7) {
          iVar2 = 0;
        }
        do {
          uVar6 = *local_2c;
          if (iVar2 == 0) {
            return 2;
          }
          puVar1 = local_2c + 1;
          local_2c = local_2c + 2;
          iVar4 = FUN_0002bb70(param_1,uVar7 + 0x100,uVar6,*puVar1);
          if (iVar4 != 0) {
            return 2;
          }
          uVar7 = uVar7 + 1;
          iVar2 = iVar2 + -1;
        } while (uVar7 < uVar5);
      }
    }
    if (param_4 == 1) {
      local_2c = local_2c + 1;
    }
    iVar2 = FUN_0002ba30(param_1,0xd,local_2c);
    return (uint)(iVar2 != 0) << 1;
  }
  if (param_2 != 0) {
    fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","_Unwind_VRS_Pop","unsupported register class");
    fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  if (param_4 != 0) {
    return 2;
  }
  iVar2 = FUN_0002b9d8(param_1,0xd,&local_28);
  if (iVar2 != 0) {
    return 2;
  }
  if ((param_3 & 1) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,0,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 2) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,1,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 4) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,2,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 8) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,3,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x10) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,4,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x20) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,5,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x40) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,6,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x80) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,7,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x100) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,8,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x200) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,9,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x400) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,10,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x800) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,0xb,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x1000) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,0xc,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  uVar7 = param_3 & 0x2000;
  if (uVar7 != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,0xd,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x4000) != 0) {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,0xe,uVar6);
    if (iVar2 != 0) {
      return 2;
    }
  }
  if ((param_3 & 0x8000) == 0) {
    if (uVar7 != 0) {
      return 0;
    }
  }
  else {
    uVar6 = *local_28;
    local_28 = local_28 + 1;
    iVar2 = FUN_0002ba30(param_1,0xf,uVar6);
    uVar5 = (uint)(iVar2 != 0);
    if (iVar2 != 0 || uVar7 != 0) goto LAB_0002b1a0;
  }
  iVar2 = FUN_0002ba30(param_1,0xd,local_28);
  uVar5 = 0;
  if (iVar2 != 0) {
    uVar5 = 1;
  }
LAB_0002b1a0:
  return uVar5 << 1;
}


// ==== FUN_0002b210 @ 0002b210

undefined4 FUN_0002b210(int param_1,undefined4 param_2)

{
  ushort uVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  uint *puVar8;
  uint uVar9;
  uint local_4c [2];
  uint *local_44;
  
  bVar5 = *(byte *)(*(int *)(param_1 + 0x4c) + 3);
  iVar2 = FUN_0002bbe8(param_2,local_4c);
  puVar8 = local_44;
  if (iVar2 != 0) {
    puVar8 = (uint *)0x0;
  }
  if (((*(byte *)(param_1 + 0x50) & 1) == 0) && (uVar7 = *puVar8, uVar7 != 0)) {
    bVar5 = bVar5 & 0xf;
    if (bVar5 == 3) {
      do {
        local_4c[0] = 0;
        iVar2 = *(int *)(param_1 + 0x48);
        uVar9 = puVar8[1];
        FUN_0002b9d8(param_2,0xf,local_4c);
        puVar3 = puVar8 + 2;
        uVar6 = uVar7 & 1 | (uVar9 & 1) << 1;
        if (uVar6 < 2) {
          puVar8 = puVar3;
        }
        else {
          if (uVar6 != 2) goto LAB_0002b3c8;
          uVar6 = iVar2 + (uVar9 & 0xfffffffe);
          puVar8 = puVar8 + 3;
          if ((uVar6 <= (local_4c[0] & 0xfffffffe)) &&
             ((local_4c[0] & 0xfffffffe) < uVar6 + (uVar7 & 0xfffffffe))) goto LAB_0002b374;
        }
        uVar7 = *puVar8;
      } while (uVar7 != 0);
    }
    else {
      if (bVar5 != 1) {
        return 9;
      }
      do {
        uVar7 = *puVar8;
        uVar1 = *(ushort *)((int)puVar8 + 2);
        local_4c[0] = 0;
        iVar2 = *(int *)(param_1 + 0x48);
        FUN_0002b9d8(param_2,0xf,local_4c);
        puVar3 = puVar8 + 1;
        uVar6 = (ushort)uVar7 & 1 | (uVar1 & 1) << 1;
        if (uVar6 < 2) {
          puVar8 = puVar3;
        }
        else {
          if (uVar6 != 2) {
LAB_0002b3c8:
            fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","ProcessDescriptors",
                    "Invalid descriptor kind found.");
            fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
            abort();
          }
          uVar6 = (uVar1 & 0xfffffffe) + iVar2;
          puVar8 = puVar8 + 2;
          if ((uVar6 <= (local_4c[0] & 0xfffffffe)) &&
             ((local_4c[0] & 0xfffffffe) < uVar6 + ((ushort)uVar7 & 0xfffffffe))) {
LAB_0002b374:
            uVar7 = (*puVar3 & 0x40000000) << 1 | *puVar3 & 0x7fffffff;
            uVar4 = 6;
            if (uVar7 != 0xffffffff) {
              if (uVar7 != 0xfffffffe) {
                fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","ProcessDescriptors",
                        "Type matching not implemented");
                fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
                abort();
              }
              uVar4 = 9;
            }
            return uVar4;
          }
        }
      } while (*puVar8 != 0);
    }
  }
  iVar2 = FUN_0002bbd0(param_2);
  uVar4 = 9;
  if (iVar2 == 0) {
    uVar4 = 5;
  }
  if (iVar2 == 1) {
    uVar4 = 8;
  }
  return uVar4;
}


// ==== FUN_0002b470 @ 0002b470

void FUN_0002b470(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0002b210(param_2,param_3);
  return;
}


// ==== FUN_0002b488 @ 0002b488

undefined4 FUN_0002b488(int param_1)

{
  int iVar1;
  undefined1 auStack_318 [392];
  undefined1 auStack_190 [336];
  undefined4 local_40 [3];
  code *local_34;
  undefined4 local_2c;
  undefined4 local_20;
  
  FUN_0002ce70(auStack_190);
  *(undefined4 *)(param_1 + 0xc) = 0;
  FUN_0002b8fc(auStack_318,auStack_190);
  iVar1 = FUN_0002bbe8(auStack_318,local_40);
  if (iVar1 == 0) {
    do {
      if (local_34 != (code *)0x0) {
        *(undefined4 *)(param_1 + 0x48) = local_40[0];
        *(undefined4 *)(param_1 + 0x4c) = local_20;
        *(undefined4 *)(param_1 + 0x50) = local_2c;
        iVar1 = (*local_34)(0,param_1,auStack_318);
        if (iVar1 != 8) {
          if (iVar1 == 6) {
            FUN_0002b574(auStack_190,auStack_318,param_1,0);
            return 2;
          }
          if (iVar1 == 9) {
            return 9;
          }
          return 3;
        }
      }
      iVar1 = FUN_0002bbe8(auStack_318,local_40);
    } while (iVar1 == 0);
  }
  return 3;
}


// ==== FUN_0002b574 @ 0002b574

void FUN_0002b574(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 local_54;
  undefined4 local_50 [3];
  code *local_44;
  undefined4 local_3c;
  undefined4 local_30;
  int local_28;
  
  FUN_0002b8fc(param_2,param_1);
  iVar2 = 1;
  do {
    uVar3 = 1;
    if (((param_4 & 1) != 0) && (uVar3 = 2, iVar2 == 0)) {
      FUN_0002ba30(param_2,0xffffffff,*(undefined4 *)(param_3 + 0x10));
      param_4 = 0;
    }
    FUN_0002b9d8(param_2,0xfffffffe,&local_28);
    iVar1 = FUN_0002bbe8(param_2,local_50);
    if (iVar1 != 0) {
      return;
    }
    if (local_44 != (code *)0x0) {
      *(undefined4 *)(param_3 + 0x48) = local_50[0];
      *(undefined4 *)(param_3 + 0x4c) = local_30;
      *(undefined4 *)(param_3 + 0x50) = local_3c;
      iVar1 = (*local_44)(uVar3,param_3,param_2);
      if (iVar1 != 8) {
        if (iVar1 == 7) {
          FUN_0002b9d8(param_2,0xffffffff,&local_54);
          *(undefined4 *)(param_3 + 0x10) = local_54;
          FUN_0002bc1c(param_2);
          return;
        }
        if (iVar1 == 9) {
                    /* WARNING: Subroutine does not return */
          abort();
        }
        return;
      }
      if (local_28 == *(int *)(param_3 + 0x20)) {
        fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","unwind_phase2",
                "during phase1 personality function said it would stop here, but now in phase2 it did not stop here"
               );
        fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
        abort();
      }
    }
    iVar2 = iVar2 + -1;
  } while( true );
}


// ==== FUN_0002b770 @ 0002b770

void FUN_0002b770(undefined4 param_1,undefined4 param_2,int param_3,code *param_4,undefined4 param_5
                 )

{
  int iVar1;
  undefined4 local_48 [3];
  code *local_3c;
  undefined4 local_34;
  undefined4 local_28;
  
  FUN_0002b8fc(param_2,param_1);
  iVar1 = FUN_0002bbe8(param_2,local_48);
  if (iVar1 == 0) {
    do {
      iVar1 = (*param_4)(1,10,param_3,param_3,param_2,param_5);
      if (iVar1 != 0) {
        return;
      }
      if (local_3c != (code *)0x0) {
        *(undefined4 *)(param_3 + 0x48) = local_48[0];
        *(undefined4 *)(param_3 + 0x4c) = local_28;
        *(undefined4 *)(param_3 + 0x50) = local_34;
        iVar1 = (*local_3c)(9,param_3,param_2);
        if (iVar1 == 7) {
          FUN_0002bc1c(param_2);
        }
        else if (iVar1 != 8) {
          if (iVar1 == 5) {
            (*param_4)(1,0x1a,param_3,param_3,param_2,param_5);
            return;
          }
          return;
        }
      }
      iVar1 = FUN_0002bbe8(param_2,local_48);
    } while (iVar1 == 0);
  }
  return;
}


// ==== FUN_0002b864 @ 0002b864

undefined4 FUN_0002b864(undefined4 param_1)

{
  int iVar1;
  undefined1 auStack_30 [8];
  undefined4 local_28;
  
  iVar1 = FUN_0002bbe8(param_1,auStack_30);
  if (iVar1 != 0) {
    local_28 = 0;
  }
  return local_28;
}


// ==== FUN_0002b890 @ 0002b890

undefined4 FUN_0002b890(undefined4 param_1)

{
  int iVar1;
  undefined4 local_30 [10];
  
  iVar1 = FUN_0002bbe8(param_1,local_30);
  if (iVar1 != 0) {
    local_30[0] = 0;
  }
  return local_30[0];
}


// ==== FUN_0002b8bc @ 0002b8bc

void FUN_0002b8bc(int param_1)

{
  if (*(code **)(param_1 + 8) == (code *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0002b8d0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 8))(1,param_1);
  return;
}


// ==== FUN_0002b8d4 @ 0002b8d4

undefined4 FUN_0002b8d4(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  iVar1 = FUN_0002bbd0(param_2);
  uVar3 = 9;
  if (iVar1 == 0) {
    uVar3 = 5;
  }
  uVar2 = 0;
  if (iVar1 != 1) {
    uVar2 = uVar3;
  }
  return uVar2;
}


// ==== FUN_0002b8fc @ 0002b8fc

undefined4 FUN_0002b8fc(undefined4 *param_1,undefined8 *param_2)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  int local_24;
  int local_20;
  int local_1c;
  
  *(undefined1 *)((int)param_1 + 0x4e) = 0;
  *(undefined2 *)(param_1 + 0x13) = 0;
  *param_1 = &PTR_LAB_00032714;
  param_1[1] = &DAT_00036e28;
  uVar3 = param_2[1];
  uVar4 = param_2[2];
  uVar5 = param_2[3];
  uVar6 = param_2[4];
  uVar7 = param_2[5];
  uVar8 = param_2[6];
  uVar9 = param_2[7];
  *(undefined8 *)(param_1 + 2) = *param_2;
  *(undefined8 *)(param_1 + 4) = uVar3;
  *(undefined8 *)(param_1 + 6) = uVar4;
  *(undefined8 *)(param_1 + 8) = uVar5;
  *(undefined8 *)(param_1 + 10) = uVar6;
  *(undefined8 *)(param_1 + 0xc) = uVar7;
  *(undefined8 *)(param_1 + 0xe) = uVar8;
  *(undefined8 *)(param_1 + 0x10) = uVar9;
  param_1[0x12] = 0;
  FUN_0002a2f8(param_1 + 0x14,0x132);
  uVar2 = param_1[0x11] & 0xfffffffe;
  if (uVar2 != 0) {
    local_1c = 0;
    local_24 = dl_unwind_find_exidx(uVar2,&local_1c);
    local_20 = local_1c * 8;
    if ((local_24 != 0 && local_20 != 0) &&
       (iVar1 = FUN_0002c24c(param_1,uVar2,&local_24), iVar1 != 0)) {
      return 0;
    }
  }
  *(undefined1 *)(param_1 + 0x60) = 1;
  return 0;
}


// ==== FUN_0002b9d8 @ 0002b9d8

undefined4 FUN_0002b9d8(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = (**(code **)(*param_1 + 8))(param_1);
  if (iVar1 == 0) {
    return 0xffffe672;
  }
  uVar2 = (**(code **)(*param_1 + 0xc))(param_1,param_2);
  *param_3 = uVar2;
  return 0;
}


// ==== FUN_0002ba30 @ 0002ba30

undefined4 FUN_0002ba30(int *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined1 auStack_40 [16];
  int local_30;
  
  iVar1 = (**(code **)(*param_1 + 8))(param_1);
  if (iVar1 == 0) {
    return 0xffffe672;
  }
  (**(code **)(*param_1 + 0x10))(param_1,param_2,param_3);
  if (param_2 == -1) {
    (**(code **)(*param_1 + 0x24))(param_1,auStack_40);
    (**(code **)(*param_1 + 0x34))(param_1,0);
    if (local_30 != 0) {
      iVar1 = (**(code **)(*param_1 + 0xc))(param_1,0xfffffffe);
      (**(code **)(*param_1 + 0x10))(param_1,0xfffffffe,local_30 + iVar1);
      return 0;
    }
  }
  return 0;
}


// ==== FUN_0002bb18 @ 0002bb18

undefined4 FUN_0002bb18(int *param_1,undefined4 param_2,undefined8 *param_3)

{
  int iVar1;
  undefined8 uVar2;
  
  iVar1 = (**(code **)(*param_1 + 0x14))(param_1);
  if (iVar1 == 0) {
    return 0xffffe672;
  }
  uVar2 = (**(code **)(*param_1 + 0x18))(param_1,param_2);
  *param_3 = uVar2;
  return 0;
}


// ==== FUN_0002bb70 @ 0002bb70

undefined4 FUN_0002bb70(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x14))(param_1);
  if (iVar1 == 0) {
    return 0xffffe672;
  }
  (**(code **)(*param_1 + 0x1c))(param_1,param_2,param_3,param_4);
  return 0;
}


// ==== FUN_0002bbd0 @ 0002bbd0

void FUN_0002bbd0(int *param_1)

{
  (**(code **)(*param_1 + 0x20))();
  return;
}


// ==== FUN_0002bbe8 @ 0002bbe8

undefined4 FUN_0002bbe8(int *param_1,int param_2)

{
  undefined4 uVar1;
  
  (**(code **)(*param_1 + 0x24))(param_1,param_2);
  uVar1 = 0;
  if (*(int *)(param_2 + 4) == 0) {
    uVar1 = 0xffffe66b;
  }
  return uVar1;
}


// ==== FUN_0002bc1c @ 0002bc1c

undefined4 FUN_0002bc1c(int *param_1)

{
  (**(code **)(*param_1 + 0x28))();
  return 0xffffe674;
}


// ==== FUN_0002bc3c @ 0002bc3c

void FUN_0002bc3c(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0002bc44. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x3c))();
  return;
}


// ==== FUN_0002bc64 @ 0002bc64

undefined4 FUN_0002bc64(int param_1,uint param_2)

{
  switch(param_2) {
  case 0xe:
    return *(undefined4 *)(param_1 + 0x40);
  case 0xfffffffe:
  case 0xd:
    return *(undefined4 *)(param_1 + 0x3c);
  case 0xffffffff:
  case 0xf:
    return *(undefined4 *)(param_1 + 0x44);
  }
  if (0xc < param_2) {
    fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","getRegister","unsupported arm register");
    fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  return *(undefined4 *)(param_1 + param_2 * 4 + 8);
}


// ==== FUN_0002be48 @ 0002be48

undefined8 FUN_0002be48(int param_1,uint param_2)

{
  if ((param_2 & 0xfffffff0) == 0x110) {
    if (*(char *)(param_1 + 0x4e) == '\0') {
      *(undefined1 *)(param_1 + 0x4e) = 1;
      FUN_0002ce98(param_1 + 0xd8);
    }
    return *(undefined8 *)(param_1 + param_2 * 8 + -0x7a8);
  }
  if ((param_2 & 0xfffffff0) != 0x100) {
    fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","getFloatRegister","Unknown ARM float register");
    fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  if (*(char *)(param_1 + 0x4d) != '\0') {
    return *(undefined8 *)(param_1 + param_2 * 8 + -0x7b0);
  }
  *(undefined1 *)(param_1 + 0x4d) = 1;
  if (*(char *)(param_1 + 0x4c) == '\0') {
    FUN_0002ce88(param_1 + 0x50);
    return *(undefined8 *)(param_1 + param_2 * 8 + -0x7b0);
  }
  FUN_0002ce90();
  return *(undefined8 *)(param_1 + param_2 * 8 + -0x7b0);
}


// ==== FUN_0002bf40 @ 0002bf40

void FUN_0002bf40(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  if ((param_2 & 0xfffffff0) == 0x110) {
    if (*(char *)(param_1 + 0x4e) == '\0') {
      *(undefined1 *)(param_1 + 0x4e) = 1;
      FUN_0002ce98(param_1 + 0xd8);
    }
    param_1 = param_1 + param_2 * 8;
    *(undefined4 *)(param_1 + -0x7a8) = param_3;
    *(undefined4 *)(param_1 + -0x7a4) = param_4;
    return;
  }
  if ((param_2 & 0xfffffff0) != 0x100) {
    fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","setFloatRegister","Unknown ARM float register");
    fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  if (*(char *)(param_1 + 0x4d) != '\0') {
    param_1 = param_1 + param_2 * 8;
    *(undefined4 *)(param_1 + -0x7b0) = param_3;
    *(undefined4 *)(param_1 + -0x7ac) = param_4;
    return;
  }
  *(undefined1 *)(param_1 + 0x4d) = 1;
  if (*(char *)(param_1 + 0x4c) == '\0') {
    FUN_0002ce88(param_1 + 0x50);
    param_1 = param_1 + param_2 * 8;
    *(undefined4 *)(param_1 + -0x7b0) = param_3;
    *(undefined4 *)(param_1 + -0x7ac) = param_4;
    return;
  }
  FUN_0002ce90();
  param_1 = param_1 + param_2 * 8;
  *(undefined4 *)(param_1 + -0x7b0) = param_3;
  *(undefined4 *)(param_1 + -0x7ac) = param_4;
  return;
}


// ==== FUN_0002c040 @ 0002c040

bool FUN_0002c040(int *param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 local_20;
  undefined4 local_1c;
  
  if ((char)param_1[0x60] == '\0') {
    local_1c = 0;
    local_20 = 0;
    uVar1 = FUN_0002a524(param_1[0x5e],&local_20,&local_1c);
    iVar2 = FUN_0002a5a4(param_1,uVar1,local_20,local_1c);
    if ((iVar2 != 8) || ((**(code **)(*param_1 + 0x34))(param_1,1), (char)param_1[0x60] == '\0')) {
      return iVar2 == 8;
    }
  }
  return false;
}


// ==== FUN_0002c11c @ 0002c11c

undefined8 FUN_0002c11c(int param_1)

{
  char cVar1;
  
  if (*(char *)(param_1 + 0x4d) != '\0') {
    if (*(char *)(param_1 + 0x4c) == '\0') {
      FUN_0002ce58(param_1 + 0x50);
      cVar1 = *(char *)(param_1 + 0x4e);
      goto joined_r0x0002c150;
    }
    FUN_0002ce60();
  }
  cVar1 = *(char *)(param_1 + 0x4e);
joined_r0x0002c150:
  if (cVar1 != '\0') {
    FUN_0002ce68(param_1 + 0xd8);
  }
  return *(undefined8 *)(param_1 + 8);
}


// ==== FUN_0002c184 @ 0002c184

undefined4 FUN_0002c184(int *param_1)

{
  (**(code **)(*param_1 + 0xc))(param_1,0xffffffff);
  return 0;
}


// ==== FUN_0002c1a4 @ 0002c1a4

void FUN_0002c1a4(int *param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int local_1c;
  int local_18;
  int local_14;
  
  uVar1 = (**(code **)(*param_1 + 0xc))(param_1,0xffffffff);
  if ((uVar1 & 0xfffffffe) != 0) {
    param_2 = (uVar1 & 0xfffffffe) - param_2;
    local_14 = 0;
    local_1c = dl_unwind_find_exidx(param_2,&local_14);
    local_18 = local_14 * 8;
    if ((local_1c != 0 && local_18 != 0) &&
       (iVar2 = FUN_0002c24c(param_1,param_2,&local_1c), iVar2 != 0)) {
      return;
    }
  }
  *(undefined1 *)(param_1 + 0x60) = 1;
  return;
}


// ==== FUN_0002c24c @ 0002c24c

bool FUN_0002c24c(int param_1,uint param_2,int *param_3)

{
  uint *puVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  int iVar10;
  code *pcVar11;
  int iVar12;
  bool bVar13;
  
  if ((uint)param_3[1] >> 3 == 0) {
    return false;
  }
  iVar10 = *param_3;
  uVar2 = (uint)param_3[1] >> 3;
  uVar8 = 0;
  uVar4 = uVar2;
  do {
    iVar5 = uVar8 + (uVar4 >> 1);
    puVar1 = (uint *)(iVar10 + iVar5 * 8);
    uVar7 = *puVar1;
    if (param_2 < (uVar7 | (uVar7 & 0x40000000) << 1) + (int)puVar1) {
      uVar4 = uVar4 >> 1;
    }
    else {
      uVar8 = iVar5 + 1;
      uVar4 = uVar4 + ~(uVar4 >> 1);
    }
  } while (uVar4 != 0);
  if (uVar8 == 0) {
    return false;
  }
  iVar5 = iVar10 + uVar8 * 8;
  iVar12 = -1;
  if (uVar8 != uVar2) {
    puVar1 = (uint *)(iVar10 + uVar8 * 8);
    uVar2 = *puVar1;
    iVar12 = (uVar2 | (uVar2 & 0x40000000) << 1) + (int)puVar1;
  }
  puVar1 = (uint *)(iVar5 + -8);
  uVar2 = *puVar1;
  puVar3 = (uint *)(iVar5 + -4);
  if (puVar3 == (uint *)0x0) {
    return false;
  }
  uVar4 = *puVar3;
  if (uVar4 == 1) goto LAB_0002c3e8;
  if ((int)uVar4 < 0) {
    uVar8 = uVar4;
LAB_0002c340:
    uVar6 = (uVar8 & 0xfffffff) >> 0x18;
    uVar7 = uVar4 >> 0x1f;
    if (uVar6 == 2) {
      uVar6 = 2;
      pcVar11 = FUN_0002b470;
      uVar8 = (uVar8 & 0xffffff) >> 0x10;
      if ((int)uVar4 < 0) {
LAB_0002c3b0:
        bVar13 = uVar8 != 0;
        uVar8 = 0;
        if (bVar13) {
          fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","getInfoFromEHABISection",
                  "index inlined table detected but pr function requires extra words");
          fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
          abort();
        }
      }
LAB_0002c3b8:
      puVar9 = puVar3 + uVar8;
      goto LAB_0002c3bc;
    }
    if (uVar6 == 1) {
      uVar6 = 0;
      pcVar11 = (code *)&LAB_0002b458;
      uVar8 = (uVar8 & 0xffffff) >> 0x10;
      if (0x7fffffff < uVar4) goto LAB_0002c3b0;
      goto LAB_0002c3b8;
    }
    if (uVar6 != 0) {
      fprintf((FILE *)0x371b0,"libunwind: %s - %s\n","getInfoFromEHABISection",
              "unknown personality routine");
      fflush((FILE *)0x371b0);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    puVar9 = (uint *)0x0;
    uVar6 = 0;
    if (uVar4 < 0x80000000) {
      puVar9 = puVar3 + 1;
    }
    pcVar11 = (code *)&LAB_0002b1f8;
  }
  else {
    puVar3 = (uint *)((uVar4 | (uVar4 & 0x40000000) << 1) + (int)puVar3);
    uVar8 = *puVar3;
    if ((int)uVar8 < 0) goto LAB_0002c340;
    pcVar11 = (code *)((uVar8 | (uVar8 & 0x40000000) << 1) + (int)puVar3);
    uVar7 = 0;
    puVar9 = puVar3 + 1 + (puVar3[1] >> 0x18);
    uVar6 = 0;
LAB_0002c3bc:
    puVar9 = puVar9 + 1;
  }
  *(uint **)(param_1 + 0x178) = puVar3;
  *(int *)(param_1 + 0x15c) = iVar12;
  *(uint **)(param_1 + 0x160) = puVar9;
  *(uint *)(param_1 + 0x16c) = uVar6 | uVar7;
  *(uint *)(param_1 + 0x158) = (uVar2 | (uVar2 & 0x40000000) << 1) + (int)puVar1;
  *(code **)(param_1 + 0x164) = pcVar11;
LAB_0002c3e8:
  return uVar4 != 1;
}


// ==== FUN_0002ce58 @ 0002ce58

undefined4 FUN_0002ce58(undefined8 *param_1)

{
  return (int)*param_1;
}


// ==== FUN_0002ce60 @ 0002ce60

undefined4 FUN_0002ce60(undefined8 *param_1)

{
  return (int)*param_1;
}


// ==== FUN_0002ce68 @ 0002ce68

void FUN_0002ce68(void)

{
  return;
}


// ==== FUN_0002ce70 @ 0002ce70

undefined4 FUN_0002ce70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  undefined4 unaff_r7;
  undefined4 unaff_r8;
  undefined4 unaff_r9;
  undefined4 unaff_r10;
  undefined4 unaff_r11;
  undefined4 in_r12;
  undefined4 unaff_lr;
  
  *(int *)param_1 = param_1;
  *(undefined4 *)(param_1 + 4) = param_2;
  *(undefined4 *)(param_1 + 8) = param_3;
  *(undefined4 *)(param_1 + 0xc) = param_4;
  *(undefined4 *)(param_1 + 0x10) = unaff_r4;
  *(undefined4 *)(param_1 + 0x14) = unaff_r5;
  *(undefined4 *)(param_1 + 0x18) = unaff_r6;
  *(undefined4 *)(param_1 + 0x1c) = unaff_r7;
  *(undefined4 *)(param_1 + 0x20) = unaff_r8;
  *(undefined4 *)(param_1 + 0x24) = unaff_r9;
  *(undefined4 *)(param_1 + 0x28) = unaff_r10;
  *(undefined4 *)(param_1 + 0x2c) = unaff_r11;
  *(undefined4 *)(param_1 + 0x30) = in_r12;
  *(BADSPACEBASE **)(param_1 + 0x34) = register0x00000054;
  *(undefined4 *)(param_1 + 0x38) = unaff_lr;
  *(undefined4 *)(param_1 + 0x3c) = unaff_lr;
  return 0;
}


// ==== FUN_0002ce88 @ 0002ce88

void FUN_0002ce88(undefined8 *param_1)

{
  undefined8 in_d0;
  undefined8 in_d1;
  undefined8 in_d2;
  undefined8 in_d3;
  undefined8 in_d4;
  undefined8 in_d5;
  undefined8 in_d6;
  undefined8 in_d7;
  undefined8 unaff_d8;
  undefined8 unaff_d9;
  undefined8 unaff_d10;
  undefined8 unaff_d11;
  undefined8 unaff_d12;
  undefined8 unaff_d13;
  undefined8 unaff_d14;
  undefined8 unaff_d15;
  
  *param_1 = in_d0;
  param_1[1] = in_d1;
  param_1[2] = in_d2;
  param_1[3] = in_d3;
  param_1[4] = in_d4;
  param_1[5] = in_d5;
  param_1[6] = in_d6;
  param_1[7] = in_d7;
  param_1[8] = unaff_d8;
  param_1[9] = unaff_d9;
  param_1[10] = unaff_d10;
  param_1[0xb] = unaff_d11;
  param_1[0xc] = unaff_d12;
  param_1[0xd] = unaff_d13;
  param_1[0xe] = unaff_d14;
  param_1[0xf] = unaff_d15;
  return;
}


// ==== FUN_0002ce90 @ 0002ce90

void FUN_0002ce90(undefined8 *param_1)

{
  undefined8 in_d0;
  undefined8 in_d1;
  undefined8 in_d2;
  undefined8 in_d3;
  undefined8 in_d4;
  undefined8 in_d5;
  undefined8 in_d6;
  undefined8 in_d7;
  undefined8 unaff_d8;
  undefined8 unaff_d9;
  undefined8 unaff_d10;
  undefined8 unaff_d11;
  undefined8 unaff_d12;
  undefined8 unaff_d13;
  undefined8 unaff_d14;
  undefined8 unaff_d15;
  
  *param_1 = in_d0;
  param_1[1] = in_d1;
  param_1[2] = in_d2;
  param_1[3] = in_d3;
  param_1[4] = in_d4;
  param_1[5] = in_d5;
  param_1[6] = in_d6;
  param_1[7] = in_d7;
  param_1[8] = unaff_d8;
  param_1[9] = unaff_d9;
  param_1[10] = unaff_d10;
  param_1[0xb] = unaff_d11;
  param_1[0xc] = unaff_d12;
  param_1[0xd] = unaff_d13;
  param_1[0xe] = unaff_d14;
  param_1[0xf] = unaff_d15;
  return;
}


// ==== FUN_0002ce98 @ 0002ce98

void FUN_0002ce98(undefined8 *param_1)

{
  undefined8 in_d16;
  undefined8 in_d17;
  undefined8 in_d18;
  undefined8 in_d19;
  undefined8 in_d20;
  undefined8 in_d21;
  undefined8 in_d22;
  undefined8 in_d23;
  undefined8 in_d24;
  undefined8 in_d25;
  undefined8 in_d26;
  undefined8 in_d27;
  undefined8 in_d28;
  undefined8 in_d29;
  undefined8 in_d30;
  undefined8 in_d31;
  
  *param_1 = in_d16;
  param_1[1] = in_d17;
  param_1[2] = in_d18;
  param_1[3] = in_d19;
  param_1[4] = in_d20;
  param_1[5] = in_d21;
  param_1[6] = in_d22;
  param_1[7] = in_d23;
  param_1[8] = in_d24;
  param_1[9] = in_d25;
  param_1[10] = in_d26;
  param_1[0xb] = in_d27;
  param_1[0xc] = in_d28;
  param_1[0xd] = in_d29;
  param_1[0xe] = in_d30;
  param_1[0xf] = in_d31;
  return;
}


// ==== free @ 0002cedc

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== __stack_chk_fail @ 0002cf40

void __stack_chk_fail(void)

{
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== strlen @ 0002cf50

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
  size_t sVar1;
  
  sVar1 = strlen(__s);
  return sVar1;
}


// ==== AMotionEvent_getAction @ 0002cf60

void AMotionEvent_getAction(void)

{
  AMotionEvent_getAction();
  return;
}


// ==== AInputEvent_getDeviceId @ 0002cf70

void AInputEvent_getDeviceId(void)

{
  AInputEvent_getDeviceId();
  return;
}


// ==== AInputEvent_getSource @ 0002cf80

void AInputEvent_getSource(void)

{
  AInputEvent_getSource();
  return;
}


// ==== gettimeofday @ 0002cf90

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
  int iVar1;
  
  iVar1 = gettimeofday(__tv,__tz);
  return iVar1;
}


// ==== AMotionEvent_getX @ 0002cfa0

void AMotionEvent_getX(void)

{
  AMotionEvent_getX();
  return;
}


// ==== AMotionEvent_getY @ 0002cfb0

void AMotionEvent_getY(void)

{
  AMotionEvent_getY();
  return;
}


// ==== AMotionEvent_getToolType @ 0002cfc0

void AMotionEvent_getToolType(void)

{
  AMotionEvent_getToolType();
  return;
}


// ==== AMotionEvent_getPointerId @ 0002cfd0

void AMotionEvent_getPointerId(void)

{
  AMotionEvent_getPointerId();
  return;
}


// ==== AMotionEvent_getPressure @ 0002cfe0

void AMotionEvent_getPressure(void)

{
  AMotionEvent_getPressure();
  return;
}


// ==== AMotionEvent_getSize @ 0002cff0

void AMotionEvent_getSize(void)

{
  AMotionEvent_getSize();
  return;
}


// ==== AMotionEvent_getFlags @ 0002d000

void AMotionEvent_getFlags(void)

{
  AMotionEvent_getFlags();
  return;
}


// ==== AMotionEvent_getPointerCount @ 0002d010

void AMotionEvent_getPointerCount(void)

{
  AMotionEvent_getPointerCount();
  return;
}


// ==== AMotionEvent_getXPrecision @ 0002d020

void AMotionEvent_getXPrecision(void)

{
  AMotionEvent_getXPrecision();
  return;
}


// ==== AMotionEvent_getYPrecision @ 0002d030

void AMotionEvent_getYPrecision(void)

{
  AMotionEvent_getYPrecision();
  return;
}


// ==== AMotionEvent_getDownTime @ 0002d040

void AMotionEvent_getDownTime(void)

{
  AMotionEvent_getDownTime();
  return;
}


// ==== AMotionEvent_getEventTime @ 0002d050

void AMotionEvent_getEventTime(void)

{
  AMotionEvent_getEventTime();
  return;
}


// ==== memcmp @ 0002d060

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = memcmp(__s1,__s2,__n);
  return iVar1;
}


// ==== __vsnprintf_chk @ 0002d070

void __vsnprintf_chk(void)

{
  __vsnprintf_chk();
  return;
}


// ==== __android_log_print @ 0002d080

void __android_log_print(void)

{
  __android_log_print();
  return;
}


// ==== regcomp @ 0002d090

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
  int iVar1;
  
  iVar1 = regcomp(__preg,__pattern,__cflags);
  return iVar1;
}


// ==== malloc @ 0002d0a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = malloc(__size);
  return pvVar1;
}


// ==== strdup @ 0002d0b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
  char *pcVar1;
  
  pcVar1 = strdup(__s);
  return pcVar1;
}


// ==== pthread_mutex_lock @ 0002d0c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_lock(__mutex);
  return iVar1;
}


// ==== pthread_mutex_unlock @ 0002d0d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_unlock(__mutex);
  return iVar1;
}


// ==== free @ 0002d0e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== sigaction @ 0002d0f0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
  int iVar1;
  
  iVar1 = sigaction(__sig,__act,__oact);
  return iVar1;
}


// ==== pthread_cond_signal @ 0002d100

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_signal(__cond);
  return iVar1;
}


// ==== pthread_create @ 0002d110

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
  int iVar1;
  
  iVar1 = pthread_create(__newthread,__attr,__start_routine,__arg);
  return iVar1;
}


// ==== pthread_join @ 0002d120

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
  int iVar1;
  
  iVar1 = pthread_join(__th,__thread_return);
  return iVar1;
}


// ==== regfree @ 0002d130

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
  regfree(__preg);
  return;
}


// ==== siglongjmp @ 0002d140

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Subroutine does not return */
  siglongjmp(__env,__val);
}


// ==== pthread_self @ 0002d150

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
  pthread_t pVar1;
  
  pVar1 = pthread_self();
  return pVar1;
}


// ==== pthread_setname_np @ 0002d160

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
  int iVar1;
  
  iVar1 = pthread_setname_np(__target_thread,__name);
  return iVar1;
}


// ==== pthread_cond_wait @ 0002d170

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_cond_wait(__cond,__mutex);
  return iVar1;
}


// ==== fopen @ 0002d180

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
  FILE *pFVar1;
  
  pFVar1 = fopen(__filename,__modes);
  return pFVar1;
}


// ==== fgets @ 0002d190

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
  char *pcVar1;
  
  pcVar1 = fgets(__s,__n,__stream);
  return pcVar1;
}


// ==== sscanf @ 0002d1a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
  int iVar1;
  
  iVar1 = sscanf(__s,__format);
  return iVar1;
}


// ==== regexec @ 0002d1b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
  int iVar1;
  
  iVar1 = regexec(__preg,__string,__nmatch,__pmatch,__eflags);
  return iVar1;
}


// ==== strcmp @ 0002d1c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = strcmp(__s1,__s2);
  return iVar1;
}


// ==== fclose @ 0002d1d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fclose(__stream);
  return iVar1;
}


// ==== sigsetjmp @ 0002d1e0

void sigsetjmp(void)

{
  sigsetjmp();
  return;
}


// ==== sysconf @ 0002d1f0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long sysconf(int __name)

{
  long lVar1;
  
  lVar1 = sysconf(__name);
  return lVar1;
}


// ==== strstr @ 0002d200

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
  char *pcVar1;
  
  pcVar1 = strstr(__haystack,__needle);
  return pcVar1;
}


// ==== mprotect @ 0002d210

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
  int iVar1;
  
  iVar1 = mprotect(__addr,__len,__prot);
  return iVar1;
}


// ==== __errno @ 0002d220

void __errno(void)

{
  __errno();
  return;
}


// ==== pthread_cond_broadcast @ 0002d230

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_broadcast(__cond);
  return iVar1;
}


// ==== pthread_getspecific @ 0002d240

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
  void *pvVar1;
  
  pvVar1 = pthread_getspecific(__key);
  return pvVar1;
}


// ==== pthread_setspecific @ 0002d250

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
  int iVar1;
  
  iVar1 = pthread_setspecific(__key,__pointer);
  return iVar1;
}


// ==== posix_memalign @ 0002d280

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
  int iVar1;
  
  iVar1 = posix_memalign(__memptr,__alignment,__size);
  return iVar1;
}


// ==== memchr @ 0002d290

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memchr(__s,__c,__n);
  return pvVar1;
}


// ==== strerror_r @ 0002d2a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
  char *pcVar1;
  
  pcVar1 = strerror_r(__errnum,__buf,__buflen);
  return pcVar1;
}


// ==== abort @ 0002d2b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== vsnprintf @ 0002d2c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vsnprintf(__s,__maxlen,__format,__arg);
  return iVar1;
}


// ==== pthread_key_create @ 0002d2d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
  int iVar1;
  
  iVar1 = pthread_key_create(__key,__destr_function);
  return iVar1;
}


// ==== syscall @ 0002d2e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
  long lVar1;
  
  lVar1 = syscall(__sysno);
  return lVar1;
}


// ==== vfprintf @ 0002d2f0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vfprintf(__s,__format,__arg);
  return iVar1;
}


// ==== fputc @ 0002d300

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
  int iVar1;
  
  iVar1 = fputc(__c,__stream);
  return iVar1;
}


// ==== vasprintf @ 0002d310

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vasprintf(__ptr,__f,__arg);
  return iVar1;
}


// ==== __assert2 @ 0002d320

void __assert2(void)

{
  __assert2();
  return;
}


// ==== realloc @ 0002d330

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
  void *pvVar1;
  
  pvVar1 = realloc(__ptr,__size);
  return pvVar1;
}


// ==== __strlen_chk @ 0002d340

void __strlen_chk(void)

{
  __strlen_chk();
  return;
}


// ==== pthread_once @ 0002d350

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
  int iVar1;
  
  iVar1 = pthread_once(__once_control,__init_routine);
  return iVar1;
}


// ==== memset @ 0002d360

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memset(__s,__c,__n);
  return pvVar1;
}


// ==== memcpy @ 0002d370

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memcpy(__dest,__src,__n);
  return pvVar1;
}


// ==== pthread_key_delete @ 0002d380

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
  int iVar1;
  
  iVar1 = pthread_key_delete(__key);
  return iVar1;
}


// ==== memmove @ 0002d390

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memmove(__dest,__src,__n);
  return pvVar1;
}


// ==== fprintf @ 0002d3a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
  int iVar1;
  
  iVar1 = fprintf(__stream,__format);
  return iVar1;
}


// ==== fflush @ 0002d3b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fflush(__stream);
  return iVar1;
}


// ==== dl_unwind_find_exidx @ 0002d3c0

void dl_unwind_find_exidx(void)

{
  dl_unwind_find_exidx();
  return;
}


// ==== __cxa_finalize @ 00037000

/* WARNING: Control flow encountered bad instruction data */

void __cxa_finalize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __cxa_atexit @ 00037004

/* WARNING: Control flow encountered bad instruction data */

void __cxa_atexit(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __stack_chk_fail @ 00037008

/* WARNING: Control flow encountered bad instruction data */

void __stack_chk_fail(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strlen @ 00037010

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getAction @ 00037014

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getAction(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getDeviceId @ 00037018

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getDeviceId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getSource @ 0003701c

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getSource(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== gettimeofday @ 00037020

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getX @ 00037024

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getX(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getY @ 00037028

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getY(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getToolType @ 0003702c

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getToolType(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerId @ 00037030

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPressure @ 00037034

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPressure(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getSize @ 00037038

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getSize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getFlags @ 0003703c

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getFlags(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerCount @ 00037040

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerCount(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getXPrecision @ 00037044

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getXPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getYPrecision @ 00037048

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getYPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getDownTime @ 0003704c

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getDownTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getEventTime @ 00037050

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getEventTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcmp @ 00037054

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __vsnprintf_chk @ 00037058

/* WARNING: Control flow encountered bad instruction data */

void __vsnprintf_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __android_log_print @ 0003705c

/* WARNING: Control flow encountered bad instruction data */

void __android_log_print(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regcomp @ 00037060

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== malloc @ 00037064

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strdup @ 00037068

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_lock @ 0003706c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_unlock @ 00037070

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== free @ 00037074

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigaction @ 00037078

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_signal @ 0003707c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_create @ 00037080

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_join @ 00037084

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regfree @ 00037088

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== siglongjmp @ 0003708c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_self @ 00037090

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setname_np @ 00037094

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_wait @ 00037098

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fopen @ 0003709c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fgets @ 000370a0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sscanf @ 000370a4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regexec @ 000370a8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strcmp @ 000370ac

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fclose @ 000370b0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigsetjmp @ 000370b4

/* WARNING: Control flow encountered bad instruction data */

void sigsetjmp(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sysconf @ 000370b8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long sysconf(int __name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strstr @ 000370bc

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== mprotect @ 000370c0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __errno @ 000370c4

/* WARNING: Control flow encountered bad instruction data */

void __errno(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_broadcast @ 000370c8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_getspecific @ 000370cc

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setspecific @ 000370d0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_destroy @ 000370d4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_destroy(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_destroy @ 000370d8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== posix_memalign @ 000370dc

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memchr @ 000370e0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strerror_r @ 000370e4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== abort @ 000370e8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vsnprintf @ 000370ec

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_create @ 000370f0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== syscall @ 000370f4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vfprintf @ 000370f8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fputc @ 000370fc

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vasprintf @ 00037100

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __assert2 @ 00037104

/* WARNING: Control flow encountered bad instruction data */

void __assert2(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== realloc @ 0003710c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __strlen_chk @ 00037110

/* WARNING: Control flow encountered bad instruction data */

void __strlen_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_once @ 00037114

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memset @ 00037118

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcpy @ 0003711c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_delete @ 00037120

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memmove @ 00037124

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fprintf @ 00037128

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fflush @ 0003712c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== dl_unwind_find_exidx @ 00037130

/* WARNING: Control flow encountered bad instruction data */

void dl_unwind_find_exidx(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


