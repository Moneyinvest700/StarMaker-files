// ==== _FINI_1 @ 00020b60

void _FINI_1(void)

{
  __cxa_finalize(&PTR_LOOP_0004b1b0);
  return;
}


// ==== _FINI_0 @ 00020ba0

void _FINI_0(void)

{
  if (DAT_00050b88 == '\x01') {
    pthread_key_delete(DAT_00050b8c);
    DAT_00050b88 = '\0';
  }
  return;
}


// ==== FUN_00021800 @ 00021800

undefined4 * FUN_00021800(char *param_1,char *param_2)

{
  int *piVar1;
  size_t __n;
  void *__dest;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined8 *puVar4;
  int *piVar5;
  int in_GS_OFFSET;
  undefined4 local_54;
  undefined4 local_44;
  undefined4 local_38;
  undefined8 local_28;
  void *local_20;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if (*param_1 == '\0') {
    *param_1 = '\x01';
    local_54 = (undefined1 *)0x2183a;
    piVar1 = (int *)FUN_00029f70();
    piVar1[1] = 0;
    piVar1[2] = 0;
    *piVar1 = (int)(piVar1 + 1);
    *(int **)(param_1 + 4) = piVar1;
  }
  else if (*param_1 != '\x01') {
    local_54 = (undefined1 *)0x219c0;
    FUN_0002bad0();
    local_54 = (undefined1 *)0x219cc;
    FUN_00023780();
                    /* try { // try from 000219cc to 000219db has its CatchHandler @ 00021aee */
    local_54 = (undefined1 *)0x219dc;
    FUN_000236a0();
                    /* try { // try from 000219dc to 000219f5 has its CatchHandler @ 00021ad7 */
    local_54 = (undefined1 *)0x219f6;
    puVar4 = (undefined8 *)FUN_0002a7b0();
    local_20 = *(void **)(puVar4 + 1);
    local_28 = *puVar4;
    *(undefined4 *)((int)puVar4 + 4) = 0;
    *(undefined4 *)puVar4 = 0;
    *(undefined4 *)(puVar4 + 1) = 0;
                    /* try { // try from 00021a21 to 00021a67 has its CatchHandler @ 00021a96 */
    local_54 = (undefined1 *)0x21a3d;
    FUN_00023500();
    local_54 = (undefined1 *)local_44;
    FUN_0002bb70();
    piVar5 = &local_54;
    goto LAB_00021a68;
  }
  piVar1 = *(int **)(param_1 + 4);
  local_54 = (undefined1 *)0x21868;
  __n = strlen(param_2);
  piVar5 = (int *)((int)register0x00000010 + -0x50);
  if (0xffffffef < __n) {
LAB_00021a68:
    *piVar5 = (int)(piVar5 + 10);
                    /* WARNING: Subroutine does not return */
    piVar5[-1] = 0x21a74;
    FUN_0002a200();
  }
  if (__n < 0xb) {
    local_28 = CONCAT71(local_28._1_7_,(char)__n * '\x02');
    __dest = (void *)((int)&local_28 + 1);
    if (__n == 0) goto LAB_000218ce;
  }
  else {
    local_54 = (undefined1 *)0x218a0;
    __dest = (void *)FUN_00029f70();
    local_28 = CONCAT44(__n,__n + 0x10) & 0xfffffffffffffff0 | 1;
    local_20 = __dest;
  }
  local_54 = (undefined1 *)0x218c8;
  memcpy(__dest,param_2,__n);
LAB_000218ce:
  *(undefined1 *)((int)__dest + __n) = 0;
                    /* try { // try from 000218d2 to 0002192d has its CatchHandler @ 00021a79 */
  local_54 = (undefined1 *)0x218ea;
  puVar2 = (undefined4 *)FUN_000242b0();
  puVar3 = (undefined4 *)*puVar2;
  if (puVar3 == (undefined4 *)0x0) {
    local_54 = (undefined1 *)0x2192e;
    puVar3 = (undefined4 *)FUN_00029f70();
    puVar3[6] = local_20;
    *(ulonglong *)(puVar3 + 4) = local_28;
    local_28 = 0;
    local_20 = (void *)0x0;
    *(undefined1 *)(puVar3 + 7) = 0;
    puVar3[8] = 0;
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = local_38;
    *puVar2 = puVar3;
    if (*(int *)*piVar1 != 0) {
      *piVar1 = *(int *)*piVar1;
    }
    local_54 = (undefined1 *)0x219a0;
    FUN_00024420();
    piVar1[2] = piVar1[2] + 1;
  }
  if ((local_28 & 1) != 0) {
    local_54 = (undefined1 *)0x21905;
    FUN_0002a000();
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    local_54 = &LAB_00021a79;
    __stack_chk_fail();
  }
  return puVar3 + 7;
}


// ==== FUN_00021b10 @ 00021b10

undefined ** FUN_00021b10(undefined **param_1,undefined1 *param_2)

{
  undefined **ppuVar1;
  undefined8 *puVar2;
  undefined ***pppuVar3;
  undefined **ppuVar4;
  int in_GS_OFFSET;
  undefined **local_54;
  undefined **local_50;
  undefined1 *local_4c;
  char *local_48;
  undefined4 local_40;
  undefined4 local_3c;
  undefined *local_38 [4];
  undefined8 local_28;
  undefined4 local_20;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  local_4c = param_2;
  if (*(char *)param_1 == '\0') {
    *(char *)param_1 = '\x02';
    local_50 = (undefined **)0xc;
    local_54 = (undefined **)0x21b4a;
    ppuVar1 = (undefined **)FUN_00029f70();
    *ppuVar1 = (undefined *)0x0;
    ppuVar1[1] = (undefined *)0x0;
    ppuVar1[2] = (undefined *)0x0;
    param_1[1] = (undefined *)ppuVar1;
    ppuVar4 = (undefined **)ppuVar1[1];
    if (ppuVar4 < ppuVar1[2]) goto LAB_00021b6e;
LAB_00021b94:
    local_54 = (undefined **)0x21ba0;
    local_50 = ppuVar1;
    FUN_00024790();
    ppuVar4 = (undefined **)ppuVar1[1];
  }
  else {
    if (*(char *)param_1 != '\x02') {
      local_50 = (undefined **)0x10;
      local_54 = (undefined **)0x21bcc;
      ppuVar1 = (undefined **)FUN_0002bad0();
      local_50 = param_1;
      local_54 = (undefined **)0x21bd6;
      local_4c = (undefined1 *)FUN_00023780();
                    /* try { // try from 00021bd6 to 00021be5 has its CatchHandler @ 00021cd4 */
      local_54 = (undefined **)0x21be6;
      local_50 = local_38;
      FUN_000236a0();
                    /* try { // try from 00021be6 to 00021bff has its CatchHandler @ 00021cbd */
      local_48 = "cannot use emplace_back() with ";
      local_4c = (undefined1 *)0x0;
      local_54 = (undefined **)0x21c00;
      local_50 = local_38;
      puVar2 = (undefined8 *)FUN_0002a7b0();
      local_20 = *(undefined4 *)(puVar2 + 1);
      local_28 = *puVar2;
      *(undefined4 *)((int)puVar2 + 4) = 0;
      *(undefined4 *)puVar2 = 0;
      *(undefined4 *)(puVar2 + 1) = 0;
      local_3c = CONCAT31((int3)((uint)puVar2 >> 8),1);
                    /* try { // try from 00021c2b to 00021c69 has its CatchHandler @ 00021c76 */
      local_48 = (char *)&local_28;
      local_4c = (undefined1 *)0x137;
      local_54 = (undefined **)0x21c43;
      local_50 = ppuVar1;
      FUN_00023500();
      local_40 = 0;
      local_4c = &LAB_00023740;
      local_50 = &PTR_PTR_0004b1e4;
      local_54 = ppuVar1;
      FUN_0002bb70();
      pppuVar3 = &local_54;
      goto LAB_00021c6a;
    }
    ppuVar1 = (undefined **)param_1[1];
    ppuVar4 = (undefined **)ppuVar1[1];
    if (ppuVar1[2] <= ppuVar4) goto LAB_00021b94;
LAB_00021b6e:
                    /* try { // try from 00021b6e to 00021b79 has its CatchHandler @ 00021c6f */
    local_54 = (undefined **)0x21b7a;
    local_50 = ppuVar4;
    FUN_00023b40();
    ppuVar4 = ppuVar4 + 3;
    ppuVar1[1] = (undefined *)ppuVar4;
  }
  pppuVar3 = &local_50;
  if (*(int *)(in_GS_OFFSET + 0x14) == local_18) {
    return ppuVar4 + -3;
  }
LAB_00021c6a:
                    /* WARNING: Subroutine does not return */
  *(undefined1 **)((int)pppuVar3 + -4) = &LAB_00021c6f;
  __stack_chk_fail();
}


// ==== FUN_00021cf0 @ 00021cf0

undefined4 *
FUN_00021cf0(undefined4 *param_1,undefined4 param_2,int param_3,byte param_4,undefined1 param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined1 *puVar3;
  int *piVar4;
  void *__s;
  int in_GS_OFFSET;
  int *local_278;
  int *local_274;
  undefined4 local_270;
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined4 local_260;
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 local_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 local_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 *local_230;
  undefined1 local_22c;
  undefined1 local_22b;
  undefined1 local_22a [512];
  byte local_2a;
  uint local_28;
  undefined4 local_24;
  void *local_20;
  undefined4 local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  param_1[1] = 0;
  *param_1 = 0;
  param_1[2] = 0;
                    /* try { // try from 00021d2f to 00021d3a has its CatchHandler @ 00021f43 */
  piVar4 = (int *)FUN_00029f70(0x14);
  piVar4[1] = 0;
  piVar4[2] = 0;
  *piVar4 = (int)&PTR_LAB_0004b220;
  local_278 = piVar4 + 3;
  piVar4[3] = (int)&PTR_LAB_0004b23c;
  piVar4[4] = (int)param_1;
  LOCK();
  piVar4[1] = piVar4[1] + 1;
  UNLOCK();
  local_270 = 0;
  uStack_26c = 0;
  uStack_268 = 0;
  uStack_264 = 0;
  local_260 = 0;
  uStack_25c = 0;
  uStack_258 = 0;
  uStack_254 = 0;
  local_250 = 0;
  uStack_24c = 0;
  uStack_248 = 0;
  uStack_244 = 0;
  local_240 = 0;
  uStack_23c = 0;
  uStack_238 = 0;
  uStack_234 = 0;
  local_274 = piVar4;
                    /* try { // try from 00021da0 to 00021da4 has its CatchHandler @ 00021f47 */
  local_230 = (undefined4 *)FUN_00042dc0();
  if ((undefined1 *)local_230[1] == (undefined1 *)0x0) {
    local_22c = 0;
    puVar3 = (undefined1 *)*local_230;
  }
  else {
    local_22c = *(undefined1 *)local_230[1];
    puVar3 = (undefined1 *)*local_230;
  }
  if (puVar3 == (undefined1 *)0x0) {
    local_22b = 0;
  }
  else {
    local_22b = *puVar3;
  }
  memset(local_22a,0,0x200);
  local_2a = param_4;
                    /* try { // try from 00021df8 to 00021e03 has its CatchHandler @ 00021f47 */
  __s = (void *)FUN_00029f70(0x210);
  local_28 = 0x211;
  local_24 = 0x200;
  local_20 = __s;
  memset(__s,(uint)param_4,0x200);
  *(undefined1 *)((int)__s + 0x200) = 0;
  local_1c = param_6;
  LOCK();
  piVar1 = piVar4 + 1;
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 == 0) {
    (**(code **)(*piVar4 + 8))(piVar4);
    FUN_00029e80(piVar4);
  }
  if (param_3 < 0) {
    FUN_000249f0(&local_278,param_2,0,param_5,0,0);
  }
  else {
                    /* try { // try from 00021e77 to 00021ed2 has its CatchHandler @ 00021f33 */
    FUN_000249f0(&local_278,param_2,1,param_5,param_3,0);
  }
  if ((local_28 & 1) != 0) {
    FUN_0002a000(local_20);
  }
  piVar4 = local_274;
  if (local_274 != (int *)0x0) {
    LOCK();
    piVar1 = local_274 + 1;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*local_274 + 8))(local_274);
      FUN_00029e80(piVar4);
    }
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== JNI_OnLoad @ 00022260

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 JNI_OnLoad(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int in_GS_OFFSET;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  ushort uVar10;
  undefined6 uVar11;
  undefined8 uVar12;
  undefined1 auVar13 [12];
  undefined1 auVar14 [12];
  undefined1 auVar15 [14];
  undefined1 auVar16 [14];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  char cVar21;
  undefined1 auVar22 [12];
  undefined1 auVar23 [14];
  char cVar27;
  char cVar28;
  char cVar29;
  char cVar30;
  char cVar31;
  char cVar32;
  char cVar33;
  char cVar34;
  char cVar35;
  undefined1 auVar24 [16];
  undefined1 auVar25 [16];
  undefined1 auVar26 [16];
  undefined1 auVar36 [16];
  undefined1 auVar37 [12];
  undefined1 auVar39 [14];
  undefined1 auVar41 [16];
  undefined1 auVar42 [16];
  undefined1 auVar43 [16];
  undefined1 auVar38 [12];
  undefined1 auVar40 [14];
  undefined1 auVar44 [16];
  undefined1 auVar45 [16];
  int *local_74;
  undefined1 local_70;
  char cStack_6f;
  char cStack_6e;
  char cStack_6d;
  char cStack_6c;
  char cStack_6b;
  char cStack_6a;
  char cStack_69;
  char cStack_68;
  char cStack_67;
  char cStack_66;
  char cStack_65;
  char cStack_64;
  char cStack_63;
  char cStack_62;
  char cStack_61;
  char local_60;
  char cStack_5f;
  char cStack_5e;
  char cStack_5d;
  char cStack_5c;
  char cStack_5b;
  char cStack_5a;
  char cStack_59;
  char cStack_58;
  char cStack_57;
  char cStack_56;
  char cStack_55;
  char cStack_54;
  char cStack_53;
  char cStack_52;
  char cStack_51;
  char cStack_50;
  undefined4 local_4f;
  undefined4 local_4b;
  undefined1 local_40;
  char cStack_3f;
  char cStack_3e;
  char cStack_3d;
  char cStack_3c;
  char cStack_3b;
  char cStack_3a;
  char cStack_39;
  char cStack_38;
  char cStack_37;
  char cStack_36;
  char cStack_35;
  char cStack_34;
  char cStack_33;
  char cStack_32;
  char cStack_31;
  char cStack_30;
  undefined1 local_2f;
  undefined4 local_2e;
  undefined4 local_2a;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  iVar1 = (**(code **)(*param_1 + 0x18))(param_1,&local_74,0x10004);
  uVar3 = 0xffffffff;
  if (iVar1 == 0) {
    iVar1 = (**(code **)(*local_74 + 0x18))(local_74,"com/netease/mobsec/xt/a");
    iVar2 = (**(code **)(*local_74 + 0x3c))(local_74);
    if (iVar2 == 0) {
      if (iVar1 != 0) {
        iVar1 = (**(code **)(*local_74 + 0x35c))(local_74,iVar1,&PTR_DAT_0004b1b4,3);
        if (-1 < iVar1) {
          local_40 = 0x2e;
          auVar4[8] = 0x2e;
          auVar4._0_8_ = 0x1b18d1d2ebd4eca7;
          auVar4[9] = 0x45;
          auVar4[10] = 0x50;
          auVar4[0xb] = 0xcf;
          auVar4[0xc] = 0xe6;
          auVar4[0xd] = 0xe;
          auVar4[0xe] = 0x94;
          auVar4[0xf] = 0x8a;
          auVar4 = auVar4 ^ _DAT_00013970;
          auVar6._0_2_ = auVar4._0_2_ >> 3;
          auVar6._2_2_ = auVar4._2_2_ >> 3;
          auVar6._4_2_ = auVar4._4_2_ >> 3;
          auVar6._6_2_ = auVar4._6_2_ >> 3;
          auVar6._8_2_ = auVar4._8_2_ >> 3;
          auVar6._10_2_ = auVar4._10_2_ >> 3;
          auVar6._12_2_ = auVar4._12_2_ >> 3;
          auVar6._14_2_ = auVar4._14_2_ >> 3;
          auVar4 = psllw(auVar4,5);
          auVar4 = auVar4 & _DAT_00013940 | auVar6 & _DAT_000138c0;
          cVar21 = '\x02' - auVar4[0];
          cVar27 = '\x02' - auVar4[1];
          uVar10 = CONCAT11(cVar27,cVar21);
          cVar28 = '\x02' - auVar4[2];
          cVar29 = '\x02' - auVar4[3];
          uVar3 = CONCAT13(cVar29,CONCAT12(cVar28,uVar10));
          cVar30 = '\x02' - auVar4[4];
          cVar31 = '\x02' - auVar4[5];
          uVar11 = CONCAT15(cVar31,CONCAT14(cVar30,uVar3));
          cVar32 = '\x02' - auVar4[6];
          cVar33 = '\x02' - auVar4[7];
          uVar12 = CONCAT17(cVar33,CONCAT16(cVar32,uVar11));
          cVar34 = '\x02' - auVar4[8];
          cVar35 = '\x02' - auVar4[9];
          auVar22._0_10_ = CONCAT19(cVar35,CONCAT18(cVar34,uVar12));
          auVar22[10] = '\x02' - auVar4[10];
          auVar22[0xb] = '\x02' - auVar4[0xb];
          auVar23[0xc] = '\x02' - auVar4[0xc];
          auVar23._0_12_ = auVar22;
          auVar23[0xd] = '\x02' - auVar4[0xd];
          auVar24[0xe] = '\x02' - auVar4[0xe];
          auVar24._0_14_ = auVar23;
          auVar24[0xf] = '\x02' - auVar4[0xf];
          auVar26._0_2_ = uVar10 >> 7;
          auVar26._2_2_ = (ushort)((uint)uVar3 >> 0x17);
          auVar26._4_2_ = (ushort)((uint6)uVar11 >> 0x27);
          auVar26._6_2_ = (ushort)((ulonglong)uVar12 >> 0x37);
          auVar26._8_2_ = (ushort)((unkuint10)auVar22._0_10_ >> 0x47);
          auVar26._10_2_ = auVar22._10_2_ >> 7;
          auVar26._12_2_ = auVar23._12_2_ >> 7;
          auVar26._14_2_ = auVar24._14_2_ >> 7;
          auVar25[1] = cVar27 * '\x02';
          auVar25[0] = cVar21 * '\x02';
          auVar25[2] = cVar28 * '\x02';
          auVar25[3] = cVar29 * '\x02';
          auVar25[4] = cVar30 * '\x02';
          auVar25[5] = cVar31 * '\x02';
          auVar25[6] = cVar32 * '\x02';
          auVar25[7] = cVar33 * '\x02';
          auVar25[8] = cVar34 * '\x02';
          auVar25[9] = cVar35 * '\x02';
          auVar25[10] = auVar22[10] * '\x02';
          auVar25[0xb] = auVar22[0xb] * '\x02';
          auVar25[0xc] = auVar23[0xc] * '\x02';
          auVar25[0xd] = auVar23[0xd] * '\x02';
          auVar25[0xe] = auVar24[0xe] * '\x02';
          auVar25[0xf] = auVar24[0xf] * '\x02';
          auVar41[8] = 10;
          auVar41._0_8_ = 0x12b77e0e7a5386ce;
          auVar41[9] = 0x6e;
          auVar41[10] = 0xaa;
          auVar41[0xb] = 0x9a;
          auVar41[0xc] = 0x8a;
          auVar41[0xd] = 0x12;
          auVar41[0xe] = 0x9f;
          auVar41[0xf] = 0x4a;
          auVar41 = auVar41 ^ _DAT_00013950;
          auVar45._0_2_ = auVar41._0_2_ >> 1;
          auVar45._2_2_ = auVar41._2_2_ >> 1;
          auVar45._4_2_ = auVar41._4_2_ >> 1;
          auVar45._6_2_ = auVar41._6_2_ >> 1;
          auVar45._8_2_ = auVar41._8_2_ >> 1;
          auVar45._10_2_ = auVar41._10_2_ >> 1;
          auVar45._12_2_ = auVar41._12_2_ >> 1;
          auVar45._14_2_ = auVar41._14_2_ >> 1;
          auVar26 = (auVar25 | auVar26 & _DAT_00013860) ^ _DAT_00013900;
          auVar4 = psllw(auVar41,7);
          auVar4 = (auVar4 & _DAT_000138e0 | ~_DAT_000138e0 & auVar45) ^ _DAT_00013900;
          cVar21 = auVar4[0] + -10;
          cVar27 = auVar4[1] + -0xb;
          uVar10 = CONCAT11(cVar27,cVar21);
          cVar28 = auVar4[2] + -0xc;
          cVar29 = auVar4[3] + -0xd;
          uVar3 = CONCAT13(cVar29,CONCAT12(cVar28,uVar10));
          cVar30 = auVar4[4] + -0xe;
          cVar31 = auVar4[5] + -0xf;
          uVar11 = CONCAT15(cVar31,CONCAT14(cVar30,uVar3));
          cVar32 = auVar4[6] + -0x10;
          cVar33 = auVar4[7] + -0x11;
          uVar12 = CONCAT17(cVar33,CONCAT16(cVar32,uVar11));
          cVar34 = auVar4[8] + -0x12;
          cVar35 = auVar4[9] + -0x13;
          auVar37._0_10_ = CONCAT19(cVar35,CONCAT18(cVar34,uVar12));
          auVar37[10] = auVar4[10] + -0x14;
          auVar37[0xb] = auVar4[0xb] + -0x15;
          auVar39[0xc] = auVar4[0xc] + -0x16;
          auVar39._0_12_ = auVar37;
          auVar39[0xd] = auVar4[0xd] + -0x17;
          auVar42[0xe] = auVar4[0xe] + -0x18;
          auVar42._0_14_ = auVar39;
          auVar42[0xf] = auVar4[0xf] + -0x19;
          auVar5._0_2_ = uVar10 >> 7;
          auVar5._2_2_ = (ushort)((uint)uVar3 >> 0x17);
          auVar5._4_2_ = (ushort)((uint6)uVar11 >> 0x27);
          auVar5._6_2_ = (ushort)((ulonglong)uVar12 >> 0x37);
          auVar5._8_2_ = (ushort)((unkuint10)auVar37._0_10_ >> 0x47);
          auVar5._10_2_ = auVar37._10_2_ >> 7;
          auVar5._12_2_ = auVar39._12_2_ >> 7;
          auVar5._14_2_ = auVar42._14_2_ >> 7;
          auVar43[1] = cVar27 * '\x02';
          auVar43[0] = cVar21 * '\x02';
          auVar43[2] = cVar28 * '\x02';
          auVar43[3] = cVar29 * '\x02';
          auVar43[4] = cVar30 * '\x02';
          auVar43[5] = cVar31 * '\x02';
          auVar43[6] = cVar32 * '\x02';
          auVar43[7] = cVar33 * '\x02';
          auVar43[8] = cVar34 * '\x02';
          auVar43[9] = cVar35 * '\x02';
          auVar43[10] = auVar37[10] * '\x02';
          auVar43[0xb] = auVar37[0xb] * '\x02';
          auVar43[0xc] = auVar39[0xc] * '\x02';
          auVar43[0xd] = auVar39[0xd] * '\x02';
          auVar43[0xe] = auVar42[0xe] * '\x02';
          auVar43[0xf] = auVar42[0xf] * '\x02';
          auVar43 = auVar43 | auVar5 & _DAT_00013860;
          uVar10 = CONCAT11(auVar43[1] + '\x04',auVar43[0] + '\x04');
          uVar3 = CONCAT13(auVar43[3] + '\x04',CONCAT12(auVar43[2] + '\x04',uVar10));
          uVar11 = CONCAT15(auVar43[5] + '\x04',CONCAT14(auVar43[4] + '\x04',uVar3));
          uVar12 = CONCAT17(auVar43[7] + '\x04',CONCAT16(auVar43[6] + '\x04',uVar11));
          auVar38._0_10_ = CONCAT19(auVar43[9] + '\x04',CONCAT18(auVar43[8] + '\x04',uVar12));
          auVar38[10] = auVar43[10] + '\x04';
          auVar38[0xb] = auVar43[0xb] + '\x04';
          auVar40[0xc] = auVar43[0xc] + '\x04';
          auVar40._0_12_ = auVar38;
          auVar40[0xd] = auVar43[0xd] + '\x04';
          auVar44[0xe] = auVar43[0xe] + '\x04';
          auVar44._0_14_ = auVar40;
          auVar44[0xf] = auVar43[0xf] + '\x04';
          auVar20._0_2_ = uVar10 >> 2;
          auVar20._2_2_ = (ushort)((uint)uVar3 >> 0x12);
          auVar20._4_2_ = (ushort)((uint6)uVar11 >> 0x22);
          auVar20._6_2_ = (ushort)((ulonglong)uVar12 >> 0x32);
          auVar20._8_2_ = (ushort)((unkuint10)auVar38._0_10_ >> 0x42);
          auVar20._10_2_ = auVar38._10_2_ >> 2;
          auVar20._12_2_ = auVar40._12_2_ >> 2;
          auVar20._14_2_ = auVar44._14_2_ >> 2;
          auVar4 = psllw(auVar44,6);
          auVar45 = (auVar4 & _DAT_00013880 | ~_DAT_00013880 & auVar20) ^ _DAT_00013960;
          _local_70 = CONCAT13(auVar45[2] + DAT_00013860._2_1_,
                               CONCAT12(auVar45[1] + DAT_00013860._1_1_,
                                        CONCAT11(auVar45[0] + DAT_00013860,0x5f)));
          _cStack_6c = CONCAT13(auVar45[6] + DAT_00013860._6_1_,
                                CONCAT12(auVar45[5] + DAT_00013860._5_1_,
                                         CONCAT11(auVar45[4] + DAT_00013860._4_1_,
                                                  auVar45[3] + DAT_00013860._3_1_)));
          _cStack_68 = CONCAT13(auVar45[10] + DAT_00013860._10_1_,
                                CONCAT12(auVar45[9] + DAT_00013860._9_1_,
                                         CONCAT11(auVar45[8] + DAT_00013860._8_1_,
                                                  auVar45[7] + DAT_00013860._7_1_)));
          _cStack_64 = CONCAT13(auVar45[0xe] + DAT_00013860._14_1_,
                                CONCAT12(auVar45[0xd] + DAT_00013860._13_1_,
                                         CONCAT11(auVar45[0xc] + DAT_00013860._12_1_,
                                                  auVar45[0xb] + DAT_00013860._11_1_)));
          auVar9[8] = 0x62;
          auVar9._0_8_ = 0xb6bf466aafda4632;
          auVar9[9] = 0x52;
          auVar9[10] = 0x5e;
          auVar9[0xb] = 0xbb;
          auVar9[0xc] = 0xee;
          auVar9[0xd] = 0xd7;
          auVar9[0xe] = 0x52;
          auVar9[0xf] = 0x3a;
          auVar9 = auVar9 ^ _DAT_00013950;
          auVar36._0_2_ = auVar9._0_2_ >> 1;
          auVar36._2_2_ = auVar9._2_2_ >> 1;
          auVar36._4_2_ = auVar9._4_2_ >> 1;
          auVar36._6_2_ = auVar9._6_2_ >> 1;
          auVar36._8_2_ = auVar9._8_2_ >> 1;
          auVar36._10_2_ = auVar9._10_2_ >> 1;
          auVar36._12_2_ = auVar9._12_2_ >> 1;
          auVar36._14_2_ = auVar9._14_2_ >> 1;
          auVar4 = psllw(auVar9,7);
          cStack_3f = (auVar26[0] ^ 0xe2) - 1;
          cStack_3e = (auVar26[1] - 1U ^ 0xe2) - 2;
          cStack_3d = (auVar26[2] - 2U ^ 0xe2) - 3;
          cStack_3c = (auVar26[3] - 3U ^ 0xe2) - 4;
          cStack_3b = (auVar26[4] - 4U ^ 0xe2) - 5;
          cStack_3a = (auVar26[5] - 5U ^ 0xe2) - 6;
          cStack_39 = (auVar26[6] - 6U ^ 0xe2) - 7;
          cStack_38 = (auVar26[7] - 7U ^ 0xe2) - 8;
          cStack_37 = (auVar26[8] - 8U ^ 0xe2) - 9;
          cStack_36 = (auVar26[9] - 9U ^ 0xe2) - 10;
          cStack_35 = (auVar26[10] - 10U ^ 0xe2) - 0xb;
          cStack_34 = (auVar26[0xb] - 0xbU ^ 0xe2) - 0xc;
          cStack_33 = (auVar26[0xc] - 0xcU ^ 0xe2) - 0xd;
          cStack_32 = (auVar26[0xd] - 0xdU ^ 0xe2) - 0xe;
          cStack_31 = (auVar26[0xe] - 0xeU ^ 0xe2) - 0xf;
          cStack_30 = (auVar26[0xf] - 0xfU ^ 0xe2) - 0x10;
          auVar4 = (~_DAT_000138e0 & auVar36 | auVar4 & _DAT_000138e0) ^ _DAT_00013990;
          cVar21 = auVar4[0] + -0x1a;
          cVar27 = auVar4[1] + -0x1b;
          uVar10 = CONCAT11(cVar27,cVar21);
          cVar28 = auVar4[2] + -0x1c;
          cVar29 = auVar4[3] + -0x1d;
          uVar3 = CONCAT13(cVar29,CONCAT12(cVar28,uVar10));
          cVar30 = auVar4[4] + -0x1e;
          cVar31 = auVar4[5] + -0x1f;
          uVar11 = CONCAT15(cVar31,CONCAT14(cVar30,uVar3));
          cVar32 = auVar4[6] + -0x20;
          cVar33 = auVar4[7] + -0x21;
          uVar12 = CONCAT17(cVar33,CONCAT16(cVar32,uVar11));
          cVar34 = auVar4[8] + -0x22;
          cVar35 = auVar4[9] + -0x23;
          auVar13._0_10_ = CONCAT19(cVar35,CONCAT18(cVar34,uVar12));
          auVar13[10] = auVar4[10] + -0x24;
          auVar13[0xb] = auVar4[0xb] + -0x25;
          auVar15[0xc] = auVar4[0xc] + -0x26;
          auVar15._0_12_ = auVar13;
          auVar15[0xd] = auVar4[0xd] + -0x27;
          auVar17[0xe] = auVar4[0xe] + -0x28;
          auVar17._0_14_ = auVar15;
          auVar17[0xf] = auVar4[0xf] + -0x29;
          auVar7._0_2_ = uVar10 >> 7;
          auVar7._2_2_ = (ushort)((uint)uVar3 >> 0x17);
          auVar7._4_2_ = (ushort)((uint6)uVar11 >> 0x27);
          auVar7._6_2_ = (ushort)((ulonglong)uVar12 >> 0x37);
          auVar7._8_2_ = (ushort)((unkuint10)auVar13._0_10_ >> 0x47);
          auVar7._10_2_ = auVar13._10_2_ >> 7;
          auVar7._12_2_ = auVar15._12_2_ >> 7;
          auVar7._14_2_ = auVar17._14_2_ >> 7;
          auVar18[1] = cVar27 * '\x02';
          auVar18[0] = cVar21 * '\x02';
          auVar18[2] = cVar28 * '\x02';
          auVar18[3] = cVar29 * '\x02';
          auVar18[4] = cVar30 * '\x02';
          auVar18[5] = cVar31 * '\x02';
          auVar18[6] = cVar32 * '\x02';
          auVar18[7] = cVar33 * '\x02';
          auVar18[8] = cVar34 * '\x02';
          auVar18[9] = cVar35 * '\x02';
          auVar18[10] = auVar13[10] * '\x02';
          auVar18[0xb] = auVar13[0xb] * '\x02';
          auVar18[0xc] = auVar15[0xc] * '\x02';
          auVar18[0xd] = auVar15[0xd] * '\x02';
          auVar18[0xe] = auVar17[0xe] * '\x02';
          auVar18[0xf] = auVar17[0xf] * '\x02';
          auVar18 = auVar18 | auVar7 & _DAT_00013860;
          uVar10 = CONCAT11(auVar18[1] + '\x04',auVar18[0] + '\x04');
          uVar3 = CONCAT13(auVar18[3] + '\x04',CONCAT12(auVar18[2] + '\x04',uVar10));
          uVar11 = CONCAT15(auVar18[5] + '\x04',CONCAT14(auVar18[4] + '\x04',uVar3));
          uVar12 = CONCAT17(auVar18[7] + '\x04',CONCAT16(auVar18[6] + '\x04',uVar11));
          auVar14._0_10_ = CONCAT19(auVar18[9] + '\x04',CONCAT18(auVar18[8] + '\x04',uVar12));
          auVar14[10] = auVar18[10] + '\x04';
          auVar14[0xb] = auVar18[0xb] + '\x04';
          auVar16[0xc] = auVar18[0xc] + '\x04';
          auVar16._0_12_ = auVar14;
          auVar16[0xd] = auVar18[0xd] + '\x04';
          auVar19[0xe] = auVar18[0xe] + '\x04';
          auVar19._0_14_ = auVar16;
          auVar19[0xf] = auVar18[0xf] + '\x04';
          auVar8._0_2_ = uVar10 >> 2;
          auVar8._2_2_ = (ushort)((uint)uVar3 >> 0x12);
          auVar8._4_2_ = (ushort)((uint6)uVar11 >> 0x22);
          auVar8._6_2_ = (ushort)((ulonglong)uVar12 >> 0x32);
          auVar8._8_2_ = (ushort)((unkuint10)auVar14._0_10_ >> 0x42);
          auVar8._10_2_ = auVar14._10_2_ >> 2;
          auVar8._12_2_ = auVar16._12_2_ >> 2;
          auVar8._14_2_ = auVar19._14_2_ >> 2;
          auVar4 = psllw(auVar19,6);
          local_2f = 0x74;
          auVar4 = (~_DAT_00013880 & auVar8 | auVar4 & _DAT_00013880) ^ _DAT_00013960;
          local_2e = 0x2e656d69;
          cStack_58 = auVar4[7] + DAT_00013860._7_1_;
          cStack_57 = auVar4[8] + DAT_00013860._8_1_;
          cStack_56 = auVar4[9] + DAT_00013860._9_1_;
          cStack_55 = auVar4[10] + DAT_00013860._10_1_;
          cStack_54 = auVar4[0xb] + DAT_00013860._11_1_;
          cStack_53 = auVar4[0xc] + DAT_00013860._12_1_;
          cStack_52 = auVar4[0xd] + DAT_00013860._13_1_;
          cStack_51 = auVar4[0xe] + DAT_00013860._14_1_;
          cStack_50 = auVar4[0xf] + DAT_00013860._15_1_;
          _local_60 = CONCAT13(auVar4[2] + DAT_00013860._2_1_,
                               CONCAT12(auVar4[1] + DAT_00013860._1_1_,
                                        CONCAT11(auVar4[0] + DAT_00013860,
                                                 auVar45[0xf] + DAT_00013860._15_1_)));
          _cStack_5c = CONCAT13(auVar4[6] + DAT_00013860._6_1_,
                                CONCAT12(auVar4[5] + DAT_00013860._5_1_,
                                         CONCAT11(auVar4[4] + DAT_00013860._4_1_,
                                                  auVar4[3] + DAT_00013860._3_1_)));
          local_4f = 0x534b5045;
          local_2a = 0x246f73;
          local_4b = 0x625f30;
          iVar1 = FUN_00027420(&local_40,&local_70,&LAB_00021fb0,&DAT_00050898);
          if (iVar1 == 0) {
            FUN_000274b0(1);
            iVar1 = FUN_00027450(0);
            if (iVar1 == 0) {
              FUN_00027480();
              LOCK();
              DAT_0005089c = 1;
              UNLOCK();
            }
          }
          uVar3 = 0x10004;
        }
      }
    }
    else {
      (**(code **)(*local_74 + 0x44))(local_74);
    }
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar3;
}


// ==== FUN_000227c0 @ 000227c0

void FUN_000227c0(undefined4 param_1)

{
  FUN_0002bcb0(param_1);
                    /* WARNING: Subroutine does not return */
  FUN_0002c220();
}


// ==== FUN_000227f0 @ 000227f0

void FUN_000227f0(int *param_1,char param_2)

{
  uint uVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  undefined1 *puVar5;
  undefined1 *puVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  int iVar10;
  undefined1 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  undefined1 *puVar15;
  byte *pbVar16;
  undefined4 *puVar17;
  undefined1 *puVar18;
  int *piVar19;
  uint uVar20;
  undefined1 *puVar21;
  undefined1 *puVar22;
  int in_GS_OFFSET;
  undefined8 local_34;
  undefined1 *local_28;
  undefined1 *local_24;
  undefined1 *local_20;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  local_28 = (undefined1 *)0x0;
  local_24 = (undefined1 *)0x0;
  local_20 = (undefined1 *)0x0;
  if (param_2 == '\x01') {
    piVar4 = (int *)*param_1;
    uVar1 = piVar4[2];
    if (uVar1 != 0) {
      if (0x15555555 < uVar1) {
                    /* WARNING: Subroutine does not return */
        FUN_000231e0("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
      local_24 = (undefined1 *)FUN_00029f70(uVar1 * 0xc);
      local_20 = local_24 + uVar1 * 0xc;
    }
    piVar9 = (int *)*piVar4;
    local_28 = local_24;
    if (piVar9 != piVar4 + 1) {
      if (local_20 <= local_24) goto LAB_0002298e;
LAB_000229b0:
      *local_24 = (char)piVar9[7];
      *(undefined8 *)(local_24 + 4) = *(undefined8 *)(piVar9 + 8);
      *(undefined1 *)(piVar9 + 7) = 0;
      piVar9[9] = 0;
      piVar9[8] = 0;
      local_24 = local_24 + 0xc;
      piVar7 = (int *)piVar9[1];
      piVar19 = piVar9;
      if ((int *)piVar9[1] == (int *)0x0) goto LAB_000229f0;
      do {
        do {
          piVar9 = piVar7;
          piVar7 = (int *)*piVar9;
        } while ((int *)*piVar9 != (int *)0x0);
        while( true ) {
          if (piVar9 == piVar4 + 1) goto LAB_00022a16;
          if (local_24 < local_20) goto LAB_000229b0;
LAB_0002298e:
                    /* try { // try from 00022991 to 000229a0 has its CatchHandler @ 000230b7 */
          FUN_00023290(&local_28,piVar9 + 7);
          piVar7 = (int *)piVar9[1];
          piVar19 = piVar9;
          if ((int *)piVar9[1] != (int *)0x0) break;
LAB_000229f0:
          piVar9 = (int *)piVar19[2];
          if ((int *)*piVar9 != piVar19) {
            do {
              piVar19 = (int *)piVar19[2];
              piVar9 = (int *)piVar19[2];
            } while ((int *)*piVar9 != piVar19);
          }
        }
      } while( true );
    }
  }
  else if (param_2 == '\x02') {
    puVar13 = (undefined4 *)*param_1;
    puVar22 = (undefined1 *)*puVar13;
    puVar18 = (undefined1 *)puVar13[1];
    iVar8 = (int)puVar18 - (int)puVar22;
    if (iVar8 == 0) {
      if (puVar22 != puVar18) goto LAB_000228f0;
    }
    else {
      if (0x15555555 < (uint)((iVar8 >> 2) * -0x55555555)) {
                    /* try { // try from 00023088 to 000230ab has its CatchHandler @ 000230b5 */
                    /* WARNING: Subroutine does not return */
        FUN_000231e0("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
                    /* try { // try from 0002286f to 000228cd has its CatchHandler @ 000230b5 */
      local_28 = (undefined1 *)FUN_00029f70(iVar8);
      local_20 = local_28 + (iVar8 >> 2) * 4;
      puVar22 = (undefined1 *)*puVar13;
      puVar18 = (undefined1 *)puVar13[1];
      local_24 = local_28;
      if (puVar22 != puVar18) {
LAB_000228f0:
        local_28 = local_24;
        if (local_20 <= local_24) goto LAB_0002293d;
        do {
          *local_24 = *puVar22;
          *(undefined8 *)(local_24 + 4) = *(undefined8 *)(puVar22 + 4);
          *puVar22 = 0;
          *(undefined4 *)(puVar22 + 8) = 0;
          *(undefined4 *)(puVar22 + 4) = 0;
          local_24 = local_24 + 0xc;
          while( true ) {
            puVar22 = puVar22 + 0xc;
            if (puVar22 == puVar18) goto LAB_00022a16;
            if (local_24 < local_20) break;
LAB_0002293d:
                    /* try { // try from 0002293d to 0002294c has its CatchHandler @ 000230b9 */
            FUN_00023290(&local_28,puVar22);
          }
        } while( true );
      }
    }
  }
LAB_00022a16:
  if (local_28 != local_24) {
    do {
      cVar3 = local_24[-0xc];
      local_34 = *(undefined8 *)(local_24 + -8);
      local_24[-0xc] = 0;
      *(undefined4 *)(local_24 + -4) = 0;
      *(undefined4 *)(local_24 + -8) = 0;
      puVar22 = local_24 + -0xc;
      FUN_000227f0(local_24 + -8,local_24[-0xc]);
      local_24 = puVar22;
      if (cVar3 == '\x01') {
        puVar17 = (undefined4 *)*(undefined4 *)local_34;
        puVar13 = (undefined4 *)local_34 + 1;
        puVar14 = (undefined4 *)local_34;
        if (puVar17 != puVar13) {
          if (local_20 <= puVar22) goto LAB_00022d30;
          do {
            *local_24 = *(undefined1 *)(puVar17 + 7);
            *(undefined8 *)(local_24 + 4) = *(undefined8 *)(puVar17 + 8);
            *(undefined1 *)(puVar17 + 7) = 0;
            puVar17[9] = 0;
            puVar17[8] = 0;
            local_24 = local_24 + 0xc;
            while( true ) {
              puVar14 = (undefined4 *)puVar17[1];
              if ((undefined4 *)puVar17[1] == (undefined4 *)0x0) {
                puVar12 = (undefined4 *)puVar17[2];
                if ((undefined4 *)*puVar12 != puVar17) {
                  do {
                    puVar17 = (undefined4 *)puVar17[2];
                    puVar12 = (undefined4 *)puVar17[2];
                  } while ((undefined4 *)*puVar12 != puVar17);
                }
              }
              else {
                do {
                  puVar12 = puVar14;
                  puVar14 = (undefined4 *)*puVar12;
                } while ((undefined4 *)*puVar12 != (undefined4 *)0x0);
              }
              if (puVar12 == puVar13) {
                puVar14 = (undefined4 *)local_34;
                goto LAB_00022f34;
              }
              puVar17 = puVar12;
              if (local_24 < local_20) break;
LAB_00022d30:
              puVar22 = local_24;
              puVar18 = local_28;
              iVar8 = (int)local_24 - (int)local_28 >> 2;
              uVar1 = iVar8 * -0x55555555 + 1;
              if (0x15555555 < uVar1) {
                    /* try { // try from 00023044 to 00023053 has its CatchHandler @ 000230c7 */
                FUN_0002ba50(&local_28);
                goto LAB_00023054;
              }
              iVar10 = (int)local_20 - (int)local_28 >> 2;
              uVar20 = iVar10 * 0x55555556;
              if (uVar20 < uVar1) {
                uVar20 = uVar1;
              }
              if (0xaaaaaa9 < (uint)(iVar10 * -0x55555555)) {
                uVar20 = 0x15555555;
              }
              if (0x15555555 < uVar20) goto LAB_00023064;
                    /* try { // try from 00022d92 to 00022d9d has its CatchHandler @ 000230c3 */
              iVar10 = FUN_00029f70(uVar20 * 0xc);
              puVar6 = local_28;
              *(undefined1 *)(iVar10 + iVar8 * 4) = *(undefined1 *)(puVar17 + 7);
              local_28 = (undefined1 *)(iVar10 + iVar8 * 4);
              local_20 = (undefined1 *)(iVar10 + uVar20 * 0xc);
              *(undefined8 *)(iVar10 + 4 + iVar8 * 4) = *(undefined8 *)(puVar17 + 8);
              puVar15 = (undefined1 *)(iVar10 + 0xc + iVar8 * 4);
              *(undefined1 *)(puVar17 + 7) = 0;
              puVar17[9] = 0;
              puVar17[8] = 0;
              if (puVar22 != puVar18) {
                do {
                  local_28[-0xc] = puVar22[-0xc];
                  *(undefined8 *)(local_28 + -8) = *(undefined8 *)(puVar22 + -8);
                  puVar22[-0xc] = 0;
                  *(undefined4 *)(puVar22 + -4) = 0;
                  *(undefined4 *)(puVar22 + -8) = 0;
                  puVar22 = puVar22 + -0xc;
                  local_28 = local_28 + -0xc;
                  puVar21 = local_24;
                } while (puVar22 != puVar18);
                for (; local_24 = puVar15, puVar21 != puVar6; puVar21 = puVar21 + -0xc) {
                  FUN_000227f0(puVar21 + -8,puVar21[-0xc]);
                  puVar15 = local_24;
                }
                puVar15 = local_24;
                puVar22 = puVar6;
              }
              local_24 = puVar15;
              if (puVar22 != (undefined1 *)0x0) {
                FUN_0002a000(puVar22);
              }
            }
          } while( true );
        }
LAB_00022f34:
        FUN_00023410(puVar14,puVar14[1]);
        puVar14[2] = 0;
        *puVar14 = puVar14 + 1;
        puVar14[1] = 0;
      }
      else if (cVar3 == '\x02') {
        puVar15 = (undefined1 *)*(undefined4 *)local_34;
        puVar18 = (undefined1 *)((undefined4 *)local_34)[1];
        if (puVar15 != puVar18) {
          if (local_20 <= puVar22) goto LAB_00022b40;
          do {
            *local_24 = *puVar15;
            *(undefined8 *)(local_24 + 4) = *(undefined8 *)(puVar15 + 4);
            *puVar15 = 0;
            *(undefined4 *)(puVar15 + 8) = 0;
            *(undefined4 *)(puVar15 + 4) = 0;
            local_24 = local_24 + 0xc;
            while( true ) {
              puVar15 = puVar15 + 0xc;
              if (puVar15 == puVar18) {
                puVar15 = (undefined1 *)*(undefined4 *)local_34;
                puVar13 = (undefined4 *)local_34 + 1;
                if ((undefined1 *)((undefined4 *)local_34)[1] != puVar15) {
                  puVar22 = (undefined1 *)((undefined4 *)local_34)[1];
                  do {
                    puVar18 = puVar22 + -0xc;
                    FUN_000227f0(puVar22 + -8,puVar22[-0xc]);
                    puVar22 = puVar18;
                  } while (puVar18 != puVar15);
                }
                goto LAB_00022a65;
              }
              if (local_24 < local_20) break;
LAB_00022b40:
              puVar22 = local_28;
              iVar8 = (int)local_24 - (int)local_28 >> 2;
              uVar1 = iVar8 * -0x55555555 + 1;
              if (0x15555555 < uVar1) {
LAB_00023054:
                    /* try { // try from 00023054 to 00023063 has its CatchHandler @ 000230c5 */
                FUN_0002ba50(&local_28);
LAB_00023064:
                    /* try { // try from 00023064 to 00023075 has its CatchHandler @ 000230c7 */
                    /* WARNING: Subroutine does not return */
                FUN_000231e0("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size"
                            );
              }
              iVar10 = (int)local_20 - (int)local_28 >> 2;
              uVar20 = iVar10 * 0x55555556;
              if (uVar20 < uVar1) {
                uVar20 = uVar1;
              }
              if (0xaaaaaa9 < (uint)(iVar10 * -0x55555555)) {
                uVar20 = 0x15555555;
              }
              if (0x15555555 < uVar20) {
                    /* try { // try from 00023076 to 00023087 has its CatchHandler @ 000230c5 */
                    /* WARNING: Subroutine does not return */
                FUN_000231e0("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size"
                            );
              }
                    /* try { // try from 00022ba0 to 00022bab has its CatchHandler @ 000230c1 */
              iVar10 = FUN_00029f70(uVar20 * 0xc);
              puVar6 = local_28;
              *(undefined1 *)(iVar10 + iVar8 * 4) = *puVar15;
              local_28 = (undefined1 *)(iVar10 + iVar8 * 4);
              local_20 = (undefined1 *)(iVar10 + uVar20 * 0xc);
              *(undefined8 *)(iVar10 + 4 + iVar8 * 4) = *(undefined8 *)(puVar15 + 4);
              *puVar15 = 0;
              *(undefined4 *)(puVar15 + 8) = 0;
              *(undefined4 *)(puVar15 + 4) = 0;
              puVar11 = (undefined1 *)(iVar10 + iVar8 * 4 + 0xc);
              puVar21 = local_24;
              if (local_24 != puVar22) {
                do {
                  local_28[-0xc] = puVar21[-0xc];
                  *(undefined8 *)(local_28 + -8) = *(undefined8 *)(puVar21 + -8);
                  puVar21[-0xc] = 0;
                  *(undefined4 *)(puVar21 + -4) = 0;
                  *(undefined4 *)(puVar21 + -8) = 0;
                  puVar21 = puVar21 + -0xc;
                  local_28 = local_28 + -0xc;
                  puVar5 = local_24;
                } while (puVar21 != puVar22);
                for (; local_24 = puVar11, puVar5 != puVar6; puVar5 = puVar5 + -0xc) {
                  FUN_000227f0(puVar5 + -8,puVar5[-0xc]);
                  puVar11 = local_24;
                }
                puVar11 = local_24;
                puVar22 = puVar6;
              }
              local_24 = puVar11;
              if (puVar22 != (undefined1 *)0x0) {
                FUN_0002a000(puVar22);
              }
            }
          } while( true );
        }
        puVar13 = (undefined4 *)local_34 + 1;
LAB_00022a65:
        *puVar13 = puVar15;
      }
      FUN_000227f0(&local_34,cVar3);
    } while (local_28 != local_24);
  }
  switch(param_2) {
  case '\x01':
    FUN_00023410(*param_1,*(undefined4 *)(*param_1 + 4));
LAB_00022fd7:
    pbVar16 = (byte *)*param_1;
    break;
  case '\x02':
    pbVar16 = (byte *)*param_1;
    iVar10 = *(int *)pbVar16;
    if (iVar10 != 0) {
      iVar8 = iVar10;
      if (*(int *)(pbVar16 + 4) != iVar10) {
        iVar8 = *(int *)(pbVar16 + 4);
        do {
          iVar2 = iVar8 + -0xc;
          FUN_000227f0(iVar8 + -8,*(undefined1 *)(iVar8 + -0xc));
          iVar8 = iVar2;
        } while (iVar2 != iVar10);
        iVar8 = *(int *)pbVar16;
      }
      *(int *)(pbVar16 + 4) = iVar10;
LAB_00022fce:
      FUN_0002a000(iVar8);
      goto LAB_00022fd7;
    }
    break;
  case '\x03':
    pbVar16 = (byte *)*param_1;
    if ((*pbVar16 & 1) != 0) {
      iVar8 = *(int *)(pbVar16 + 8);
      goto LAB_00022fce;
    }
    break;
  default:
    goto switchD_00022a43_caseD_4;
  case '\b':
    pbVar16 = (byte *)*param_1;
    iVar8 = *(int *)pbVar16;
    if (iVar8 != 0) {
      *(int *)(pbVar16 + 4) = iVar8;
      goto LAB_00022fce;
    }
  }
  FUN_0002a000(pbVar16);
switchD_00022a43_caseD_4:
  puVar18 = local_28;
  puVar22 = local_24;
  if (local_28 != (undefined1 *)0x0) {
    for (; puVar22 != puVar18; puVar22 = puVar22 + -0xc) {
      FUN_000227f0(puVar22 + -8,puVar22[-0xc]);
    }
    local_24 = puVar18;
    FUN_0002a000(local_28);
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00023100 @ 00023100

void FUN_00023100(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    iVar2 = param_1[1];
    iVar3 = iVar1;
    if (param_1[1] != iVar1) {
      do {
        iVar3 = iVar2 + -0xc;
        FUN_000227f0(iVar2 + -8,*(undefined1 *)(iVar2 + -0xc));
        iVar2 = iVar3;
      } while (iVar3 != iVar1);
      iVar3 = *param_1;
    }
    param_1[1] = iVar1;
    FUN_0002a000(iVar3);
  }
  return;
}


// ==== FUN_00023170 @ 00023170

void FUN_00023170(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  iVar2 = param_1[2];
  while (iVar2 != iVar1) {
    param_1[2] = iVar2 + -0xc;
    FUN_000227f0(iVar2 + -8,*(undefined1 *)(iVar2 + -0xc));
    iVar2 = param_1[2];
  }
  if (*param_1 != 0) {
    FUN_0002a000(*param_1);
  }
  return;
}


// ==== FUN_000231e0 @ 000231e0

void FUN_000231e0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_0002bad0(8);
                    /* try { // try from 00023209 to 00023214 has its CatchHandler @ 00023231 */
  FUN_00023250(uVar1,param_1);
  uVar2 = FUN_0002bb70(uVar1,&PTR_PTR_0004c4dc,&LAB_00042b50);
                    /* catch() { ... } // from try @ 00023209 with catch @ 00023231 */
  FUN_0002bb30(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_00043410(uVar2);
}


// ==== FUN_00023250 @ 00023250

void FUN_00023250(undefined4 *param_1,undefined4 param_2)

{
  FUN_0002a030(param_1,param_2);
  *param_1 = &PTR_LAB_0004c4d0;
  return;
}


// ==== FUN_00023290 @ 00023290

void FUN_00023290(int *param_1,undefined1 *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  
  iVar3 = param_1[1] - *param_1 >> 2;
  uVar1 = iVar3 * -0x55555555 + 1;
  if (uVar1 < 0x15555556) {
    iVar4 = param_1[2] - *param_1 >> 2;
    uVar5 = iVar4 * 0x55555556;
    if (uVar5 < uVar1) {
      uVar5 = uVar1;
    }
    uVar1 = 0x15555555;
    if ((uint)(iVar4 * -0x55555555) < 0xaaaaaaa) {
      uVar1 = uVar5;
    }
    if (uVar1 < 0x15555556) {
      iVar2 = FUN_00029f70(uVar1 * 0xc);
      *(undefined1 *)(iVar2 + iVar3 * 4) = *param_2;
      iVar4 = iVar2 + iVar3 * 4;
      iVar7 = uVar1 * 0xc + iVar2;
      *(undefined8 *)(iVar2 + 4 + iVar3 * 4) = *(undefined8 *)(param_2 + 4);
      *param_2 = 0;
      *(undefined4 *)(param_2 + 8) = 0;
      *(undefined4 *)(param_2 + 4) = 0;
      iVar3 = iVar2 + 0xc + iVar3 * 4;
      iVar2 = *param_1;
      iVar6 = param_1[1];
      if (iVar6 == iVar2) {
        *param_1 = iVar4;
        param_1[1] = iVar3;
        param_1[2] = iVar7;
      }
      else {
        do {
          *(undefined1 *)(iVar4 + -0xc) = *(undefined1 *)(iVar6 + -0xc);
          *(undefined8 *)(iVar4 + -8) = *(undefined8 *)(iVar6 + -8);
          *(undefined1 *)(iVar6 + -0xc) = 0;
          *(undefined4 *)(iVar6 + -4) = 0;
          *(undefined4 *)(iVar6 + -8) = 0;
          iVar6 = iVar6 + -0xc;
          iVar4 = iVar4 + -0xc;
        } while (iVar6 != iVar2);
        iVar2 = *param_1;
        iVar6 = param_1[1];
        *param_1 = iVar4;
        param_1[1] = iVar3;
        param_1[2] = iVar7;
        for (; iVar6 != iVar2; iVar6 = iVar6 + -0xc) {
          FUN_000227f0(iVar6 + -8,*(undefined1 *)(iVar6 + -0xc));
        }
      }
      if (iVar2 != 0) {
        FUN_0002a000(iVar2);
      }
      return;
    }
  }
  else {
    FUN_0002ba50(param_1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_000231e0("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
}


// ==== FUN_00023410 @ 00023410

void FUN_00023410(undefined4 param_1,undefined4 *param_2)

{
  if (param_2 != (undefined4 *)0x0) {
    FUN_00023410(param_1,*param_2);
    FUN_00023410(param_1,param_2[1]);
    FUN_000227f0(param_2 + 8,*(undefined1 *)(param_2 + 7));
    if ((*(byte *)(param_2 + 4) & 1) != 0) {
      FUN_0002a000(param_2[6]);
    }
    FUN_0002a000(param_2);
  }
  return;
}


// ==== FUN_00023490 @ 00023490

void FUN_00023490(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    iVar2 = param_1[1];
    iVar3 = iVar1;
    if (param_1[1] != iVar1) {
      do {
        iVar3 = iVar2 + -0xc;
        FUN_000227f0(iVar2 + -8,*(undefined1 *)(iVar2 + -0xc));
        iVar2 = iVar3;
      } while (iVar3 != iVar1);
      iVar3 = *param_1;
    }
    param_1[1] = iVar1;
    FUN_0002a000(iVar3);
  }
  return;
}


// ==== FUN_00023500 @ 00023500

undefined4 * FUN_00023500(undefined4 *param_1,undefined4 param_2,byte *param_3)

{
  undefined4 uVar1;
  byte *pbVar2;
  ulonglong *puVar3;
  int iVar4;
  uint uVar5;
  int in_GS_OFFSET;
  byte local_4c;
  undefined1 local_48;
  undefined4 local_47;
  undefined4 local_43;
  undefined2 local_3f;
  undefined1 local_3d;
  byte local_3c;
  undefined1 local_38 [4];
  undefined4 local_34;
  undefined8 local_2c;
  int local_24;
  int local_1c;
  undefined4 local_18;
  
  local_18 = *(undefined4 *)(in_GS_OFFSET + 0x14);
  local_48 = 0x14;
  local_47 = 0x65707974;
  local_43 = 0x7272655f;
  local_3f = 0x726f;
  local_3d = 0;
                    /* try { // try from 00023546 to 00023560 has its CatchHandler @ 00023679 */
  FUN_00023830(local_38,&local_48,param_2);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar5 = (uint)(*param_3 >> 1);
  }
  else {
    uVar5 = *(uint *)(param_3 + 4);
    pbVar2 = *(byte **)(param_3 + 8);
  }
                    /* try { // try from 00023579 to 00023588 has its CatchHandler @ 00023662 */
  puVar3 = (ulonglong *)FUN_0002a6e0(local_38,pbVar2,uVar5);
  local_24 = (int)puVar3[1];
  local_2c = *puVar3;
  *(undefined4 *)((int)puVar3 + 4) = 0;
  *(undefined4 *)puVar3 = 0;
  *(undefined4 *)(puVar3 + 1) = 0;
  if ((local_3c & 1) != 0) {
    FUN_0002a000(local_34);
  }
  if ((local_4c & 1) != 0) {
    local_47._3_1_ = (undefined1)((uint)local_47 >> 0x18);
    uVar1 = CONCAT31((undefined3)local_43,local_47._3_1_);
    FUN_0002a000(uVar1);
  }
  if ((local_2c & 1) == 0) {
    iVar4 = (int)&local_2c + 1;
  }
  else {
    iVar4 = local_24;
  }
  *param_1 = &PTR_LAB_0004b20c;
  param_1[1] = param_2;
                    /* try { // try from 00023607 to 00023612 has its CatchHandler @ 0002364b */
  FUN_0002a170(param_1 + 2,iVar4);
  *param_1 = &PTR_LAB_0004b1f8;
  if ((local_2c & 1) != 0) {
    FUN_0002a000(local_24);
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_000236a0 @ 000236a0

void FUN_000236a0(uint *param_1,char *param_2)

{
  size_t __n;
  char *__dest;
  uint uVar1;
  
  __n = strlen(param_2);
  if (0xffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(param_1);
  }
  if (__n < 0xb) {
    *(char *)param_1 = (char)__n * '\x02';
    __dest = (char *)((int)param_1 + 1);
    if (__n == 0) goto LAB_0002371d;
  }
  else {
    uVar1 = __n + 0x10 & 0xfffffff0;
    __dest = (char *)FUN_00029f70(uVar1);
    param_1[2] = (uint)__dest;
    *param_1 = uVar1 | 1;
    param_1[1] = __n;
  }
  memcpy(__dest,param_2,__n);
LAB_0002371d:
  __dest[__n] = '\0';
  return;
}


// ==== FUN_00023780 @ 00023780

char * FUN_00023780(char *param_1)

{
  if ((uint)(int)*param_1 < 10) {
    return (&PTR_DAT_0004b24c)[*param_1];
  }
  return "number";
}


// ==== FUN_000237c0 @ 000237c0

undefined8 * FUN_000237c0(undefined8 *param_1,undefined4 param_2,byte *param_3)

{
  undefined8 *puVar1;
  byte *pbVar2;
  uint uVar3;
  
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar3 = (uint)(*param_3 >> 1);
  }
  else {
    uVar3 = *(uint *)(param_3 + 4);
    pbVar2 = *(byte **)(param_3 + 8);
  }
  puVar1 = (undefined8 *)FUN_0002a6e0(param_2,pbVar2,uVar3,0x237cd);
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar1 + 1);
  *param_1 = *puVar1;
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)(puVar1 + 1) = 0;
  *(undefined4 *)((int)puVar1 + 4) = 0;
  return param_1;
}


// ==== FUN_00023830 @ 00023830

undefined8 * FUN_00023830(undefined8 *param_1,uint param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  ulonglong *puVar3;
  int iVar4;
  int in_GS_OFFSET;
  undefined4 local_58;
  uint local_54;
  int local_50;
  byte local_48;
  undefined4 local_40 [2];
  byte local_38 [4];
  undefined8 local_34;
  undefined4 local_2c;
  ulonglong local_28;
  undefined4 local_20;
  int local_1c;
  undefined4 local_14;
  
  local_14 = *(undefined4 *)(in_GS_OFFSET + 0x14);
  local_58 = param_2;
  FUN_0002aaa0(local_40,"[json.exception.");
                    /* try { // try from 00023872 to 00023883 has its CatchHandler @ 00023a4c */
  puVar2 = (undefined8 *)FUN_0002a960(local_40,&DAT_00013c07);
  local_2c = *(undefined4 *)(puVar2 + 1);
  local_34 = *puVar2;
  *(undefined4 *)((int)puVar2 + 4) = 0;
  *(undefined4 *)puVar2 = 0;
  *(undefined4 *)(puVar2 + 1) = 0;
                    /* try { // try from 000238ac to 000238be has its CatchHandler @ 00023a2e */
  FUN_0002ac70(&local_54,param_3);
  if ((local_58 & 1) == 0) {
    local_54 = local_58 >> 1 & 0x7f;
    iVar4 = (int)&local_58 + 1;
  }
  else {
    iVar4 = local_50;
  }
                    /* try { // try from 000238d8 to 000238eb has its CatchHandler @ 00023a10 */
  puVar3 = (ulonglong *)FUN_0002a6e0(local_38,iVar4,local_54);
  local_20 = (undefined4)puVar3[1];
  local_28 = *puVar3;
  *(undefined4 *)((int)puVar3 + 4) = 0;
  *(undefined4 *)puVar3 = 0;
  *(undefined4 *)(puVar3 + 1) = 0;
                    /* try { // try from 00023911 to 00023926 has its CatchHandler @ 000239d5 */
  puVar2 = (undefined8 *)FUN_0002a960(&local_28,&DAT_00013e90);
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar2 + 1);
  *param_1 = *puVar2;
  *(undefined4 *)((int)puVar2 + 4) = 0;
  *(undefined4 *)puVar2 = 0;
  *(undefined4 *)(puVar2 + 1) = 0;
  if ((local_28 & 1) != 0) {
    FUN_0002a000(local_20);
  }
  if ((local_58 & 1) != 0) {
    FUN_0002a000(local_50);
  }
  if ((local_38[0] & 1) != 0) {
    local_34._4_4_ = (undefined4)((ulonglong)local_34 >> 0x20);
    uVar1 = local_34._4_4_;
    FUN_0002a000(uVar1);
  }
  if ((local_48 & 1) == 0) {
    if (*(int *)(in_GS_OFFSET + 0x14) != local_1c) {
LAB_000239d0:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  else {
    FUN_0002a000(local_40[0]);
    if (*(int *)(in_GS_OFFSET + 0x14) != local_1c) goto LAB_000239d0;
  }
  return param_1;
}


// ==== FUN_00023b40 @ 00023b40

void FUN_00023b40(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int **ppiVar5;
  int *piVar6;
  undefined4 uVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  undefined4 *puVar11;
  int *piVar14;
  int *piVar13;
  int *piVar12;
  int **ppiVar15;
  int in_GS_OFFSET;
  int iStack_54;
  int *local_50 [2];
  int local_48 [6];
  int *local_30 [4];
  int local_20 [4];
  
  local_20[2] = *(undefined4 *)(in_GS_OFFSET + 0x14);
  uVar1 = *param_2;
  *param_1 = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  ppiVar15 = local_50;
  switch(uVar1) {
  case 1:
    puVar2 = *(undefined4 **)(param_2 + 4);
    local_50[0] = (int *)0xc;
    local_30[0] = (int *)FUN_00029f70();
    local_30[0][1] = 0;
    local_30[0][2] = 0;
    local_30[1] = local_30[0] + 1;
    *local_30[0] = (int)(local_30[0] + 1);
    puVar11 = (undefined4 *)*puVar2;
    ppiVar15 = local_50;
    ppiVar5 = local_50;
    while (puVar4 = puVar11, puVar4 != puVar2 + 1) {
      ppiVar5[0xc] = ppiVar5[9];
                    /* try { // try from 00023c51 to 00023c77 has its CatchHandler @ 00023d9d */
      ppiVar5[2] = ppiVar5[0xc];
      ppiVar5[4] = puVar4 + 4;
      ppiVar5[3] = puVar4 + 4;
      ppiVar5[1] = ppiVar5[8];
      *ppiVar5 = (int *)(ppiVar5 + 10);
      ppiVar5[-1] = (int *)0x23c75;
      FUN_00023dd0();
      piVar12 = (int *)(ppiVar5 + -1);
      piVar13 = (int *)(ppiVar5 + -1);
      piVar14 = (int *)(ppiVar5 + -1);
      ppiVar15 = ppiVar5 + -1;
      puVar3 = (undefined4 *)puVar4[1];
      if ((undefined4 *)puVar4[1] == (undefined4 *)0x0) {
        puVar11 = (undefined4 *)puVar4[2];
        ppiVar15 = ppiVar5 + -1;
        ppiVar5 = ppiVar5 + -1;
        if (*(undefined4 **)puVar4[2] != puVar4) {
          do {
            puVar4 = (undefined4 *)puVar4[2];
            puVar11 = (undefined4 *)puVar4[2];
            ppiVar15 = (int **)piVar14;
            ppiVar5 = (int **)piVar12;
          } while (*(undefined4 **)puVar4[2] != puVar4);
        }
      }
      else {
        do {
          puVar11 = puVar3;
          puVar3 = (undefined4 *)*puVar11;
          ppiVar5 = (int **)piVar13;
        } while (puVar3 != (undefined4 *)0x0);
      }
    }
    piVar8 = *(int **)((int)ppiVar15 + 0x20);
    goto LAB_00023d52;
  case 2:
    piVar6 = *(int **)(param_2 + 4);
    local_50[0] = (int *)0xc;
    piVar8 = (int *)FUN_00029f70();
    *piVar8 = 0;
    piVar8[1] = 0;
    piVar8[2] = 0;
    piVar9 = (int *)(piVar6[1] - *piVar6);
    if (piVar9 != (int *)0x0) {
      local_30[0] = piVar8;
      local_30[1] = piVar6;
      if (0x15555555 < (uint)(((int)piVar9 >> 2) * -0x55555555)) {
        local_50[0] = piVar8;
                    /* try { // try from 00023d69 to 00023d74 has its CatchHandler @ 00023d82 */
        FUN_0002ba50();
        ppiVar15 = local_50;
        goto LAB_00023d75;
      }
      local_50[0] = piVar9;
                    /* try { // try from 00023cf5 to 00023cfc has its CatchHandler @ 00023d82 */
      piVar10 = (int *)FUN_00029f70();
      local_30[0][1] = (int)piVar10;
      *local_30[0] = (int)piVar10;
      local_30[0][2] = (int)(piVar10 + ((int)piVar9 >> 2));
      piVar6 = (int *)*local_30[1];
      piVar8 = local_30[1] + 1;
      local_30[1] = (int *)*piVar8;
      if (piVar6 != (int *)*piVar8) {
        do {
                    /* try { // try from 00023d30 to 00023d3b has its CatchHandler @ 00023d86 */
          local_50[0] = piVar10;
          local_50[1] = piVar6;
          FUN_00023b40();
          piVar6 = piVar6 + 3;
          piVar10 = piVar10 + 3;
        } while (piVar6 != local_30[1]);
      }
      local_30[0][1] = (int)piVar10;
      piVar8 = local_30[0];
    }
    ppiVar15 = local_50;
LAB_00023d52:
    *(int **)(param_1 + 4) = piVar8;
    break;
  case 3:
    piVar8 = *(int **)(param_2 + 4);
    local_50[0] = (int *)0xc;
    piVar6 = (int *)FUN_00029f70();
    local_50[0] = piVar6;
    local_50[1] = piVar8;
                    /* try { // try from 00023bb8 to 00023bc3 has its CatchHandler @ 00023d7a */
    FUN_0002a410();
    ppiVar15 = local_50;
    *(int **)(param_1 + 4) = piVar6;
    break;
  case 4:
    *(uint *)(param_1 + 4) = (uint)(byte)param_2[4];
    *(undefined4 *)(param_1 + 8) = 0;
    ppiVar15 = local_50;
    break;
  case 5:
  case 6:
  case 7:
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
    ppiVar15 = local_50;
    break;
  case 8:
    local_50[0] = *(int **)(param_2 + 4);
    uVar7 = FUN_00024560();
    *(undefined4 *)(param_1 + 4) = uVar7;
    ppiVar15 = local_50;
  }
  if (*(int *)(in_GS_OFFSET + 0x14) == *(int *)((int)ppiVar15 + 0x38)) {
    return;
  }
LAB_00023d75:
                    /* WARNING: Subroutine does not return */
  *(undefined1 **)((int)ppiVar15 + -4) = &LAB_00023d7a;
  __stack_chk_fail();
}


// ==== FUN_00023dd0 @ 00023dd0

void FUN_00023dd0(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 param_4,int param_5
                 )

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int in_GS_OFFSET;
  undefined1 local_30 [4];
  undefined4 local_2c;
  undefined4 *local_28;
  int *local_24;
  undefined1 local_20;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  puVar1 = (undefined4 *)FUN_00023f20(param_2,param_3,&local_2c,local_30,param_4);
  puVar2 = (undefined4 *)*puVar1;
  if ((undefined4 *)*puVar1 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)FUN_00029f70(0x28);
    local_20 = 0;
    local_28 = puVar2;
    local_24 = param_2 + 1;
                    /* try { // try from 00023e5e to 00023e6d has its CatchHandler @ 00023efb */
    FUN_0002a410(puVar2 + 4,param_5);
                    /* try { // try from 00023e76 to 00023e81 has its CatchHandler @ 00023ee3 */
    FUN_00023b40(puVar2 + 7,param_5 + 0xc);
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = local_2c;
    *puVar1 = puVar2;
    if (*(int *)*param_2 != 0) {
      *param_2 = *(int *)*param_2;
      puVar2 = (undefined4 *)*puVar1;
    }
    FUN_00024420(param_2[1],puVar2);
    param_2[2] = param_2[2] + 1;
    puVar2 = local_28;
  }
  *param_1 = puVar2;
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00023f20 @ 00023f20

/* WARNING: Type propagation algorithm not settling */

int * FUN_00023f20(undefined4 *param_1,int *param_2,undefined4 *param_3,int *param_4,byte *param_5)

{
  byte bVar1;
  size_t sVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  byte *pbVar6;
  int *piVar7;
  void *pvVar8;
  uint __n;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  uint local_30;
  uint local_20;
  
  if (param_2 == param_1 + 1) goto LAB_00023ff5;
  bVar1 = *(byte *)(param_2 + 4);
  if ((bVar1 & 1) == 0) {
    uVar5 = (uint)(bVar1 >> 1);
    local_20 = (uint)*param_5;
    if ((*param_5 & 1) != 0) goto LAB_00023f84;
LAB_00023f6f:
    uVar10 = local_20 >> 1;
  }
  else {
    uVar5 = param_2[5];
    local_20 = (uint)*param_5;
    if ((*param_5 & 1) == 0) goto LAB_00023f6f;
LAB_00023f84:
    uVar10 = *(uint *)(param_5 + 4);
  }
  uVar11 = uVar10;
  if (uVar5 < uVar10) {
    uVar11 = uVar5;
  }
  if (uVar11 == 0) {
    if (uVar10 < uVar5) goto LAB_00023ff5;
LAB_000240e9:
    if (uVar10 <= uVar5) {
LAB_000240da:
      *param_3 = param_2;
      *param_4 = (int)param_2;
      return param_4;
    }
LAB_000240f2:
    piVar7 = (int *)param_2[1];
    if ((int *)param_2[1] == (int *)0x0) {
      piVar9 = (int *)param_2[2];
      piVar7 = param_2;
      if ((int *)*piVar9 != param_2) {
        do {
          piVar7 = (int *)piVar7[2];
          piVar9 = (int *)piVar7[2];
        } while ((int *)*piVar9 != piVar7);
      }
    }
    else {
      do {
        piVar9 = piVar7;
        piVar7 = (int *)*piVar9;
      } while ((int *)*piVar9 != (int *)0x0);
    }
    if (piVar9 == param_1 + 1) goto LAB_00024226;
    bVar1 = *(byte *)(piVar9 + 4);
    sVar2 = uVar10;
    if ((bVar1 & 1) == 0) {
      uVar5 = (uint)(bVar1 >> 1);
      if (uVar5 < uVar10) {
        sVar2 = uVar5;
      }
    }
    else {
      uVar5 = piVar9[5];
      if (uVar5 < uVar10) {
        sVar2 = uVar5;
      }
    }
    if (sVar2 != 0) {
      if ((bVar1 & 1) == 0) {
        pvVar8 = (void *)((int)piVar9 + 0x11);
        if ((local_20 & 1) != 0) goto LAB_000241f0;
LAB_000241db:
        pbVar6 = param_5 + 1;
      }
      else {
        pvVar8 = (void *)piVar9[6];
        if ((local_20 & 1) == 0) goto LAB_000241db;
LAB_000241f0:
        pbVar6 = *(byte **)(param_5 + 8);
      }
      iVar4 = memcmp(pbVar6,pvVar8,sVar2);
      if (iVar4 != 0) {
        if (iVar4 < 0) goto LAB_00024226;
        goto LAB_00024142;
      }
    }
    if (uVar10 < uVar5) {
LAB_00024226:
      if (param_2[1] == 0) {
        *param_3 = param_2;
        return param_2 + 1;
      }
      *param_3 = piVar9;
      return piVar9;
    }
    goto LAB_00024142;
  }
  if ((bVar1 & 1) == 0) {
    pvVar8 = (void *)((int)param_2 + 0x11);
    if ((local_20 & 1) != 0) goto LAB_00023fc7;
LAB_00023fab:
    pbVar6 = param_5 + 1;
  }
  else {
    pvVar8 = (void *)param_2[6];
    if ((local_20 & 1) == 0) goto LAB_00023fab;
LAB_00023fc7:
    pbVar6 = *(byte **)(param_5 + 8);
  }
  iVar4 = memcmp(pbVar6,pvVar8,uVar11);
  if (iVar4 == 0) {
    if (uVar5 <= uVar10) goto LAB_000240b8;
  }
  else if (-1 < iVar4) {
LAB_000240b8:
    iVar4 = memcmp(pvVar8,pbVar6,uVar11);
    if (iVar4 == 0) goto LAB_000240e9;
    if (-1 < iVar4) goto LAB_000240da;
    goto LAB_000240f2;
  }
LAB_00023ff5:
  piVar9 = (int *)*param_2;
  piVar7 = param_2;
  if ((int *)*param_1 == param_2) goto LAB_00024161;
  if (piVar9 == (int *)0x0) {
    piVar7 = param_2 + 2;
    if (*(int **)param_2[2] == param_2) {
      do {
        iVar4 = *piVar7;
        piVar7 = (int *)(iVar4 + 8);
      } while (**(int **)(iVar4 + 8) == iVar4);
    }
    piVar7 = (int *)*piVar7;
    uVar5 = (uint)*param_5;
    if ((*param_5 & 1) == 0) goto LAB_00024068;
LAB_00024030:
    local_30 = *(uint *)(param_5 + 4);
    uVar10 = (uint)*(byte *)(piVar7 + 4);
    if ((*(byte *)(piVar7 + 4) & 1) == 0) goto LAB_0002403f;
LAB_00024078:
    uVar11 = piVar7[5];
  }
  else {
    piVar3 = piVar9;
    do {
      piVar7 = piVar3;
      piVar3 = (int *)piVar7[1];
    } while ((int *)piVar7[1] != (int *)0x0);
    uVar5 = (uint)*param_5;
    if ((*param_5 & 1) != 0) goto LAB_00024030;
LAB_00024068:
    local_30 = uVar5 >> 1;
    uVar10 = (uint)*(byte *)(piVar7 + 4);
    if ((*(byte *)(piVar7 + 4) & 1) != 0) goto LAB_00024078;
LAB_0002403f:
    uVar11 = uVar10 >> 1;
  }
  __n = uVar11;
  if (local_30 < uVar11) {
    __n = local_30;
  }
  if (__n != 0) {
    if ((uVar5 & 1) == 0) {
      pbVar6 = param_5 + 1;
      if ((uVar10 & 1) != 0) goto LAB_00024118;
LAB_0002409c:
      pvVar8 = (void *)((int)piVar7 + 0x11);
    }
    else {
      pbVar6 = *(byte **)(param_5 + 8);
      if ((uVar10 & 1) == 0) goto LAB_0002409c;
LAB_00024118:
      pvVar8 = (void *)piVar7[6];
    }
    iVar4 = memcmp(pvVar8,pbVar6,__n);
    if (iVar4 != 0) {
      if (-1 < iVar4) goto LAB_00024142;
      goto LAB_00024161;
    }
  }
  if (local_30 <= uVar11) {
LAB_00024142:
    piVar7 = (int *)FUN_000242b0(param_1,param_3,param_5);
    return piVar7;
  }
LAB_00024161:
  if (piVar9 == (int *)0x0) {
    *param_3 = param_2;
    return param_2;
  }
  *param_3 = piVar7;
  return piVar7 + 1;
}


// ==== FUN_00024250 @ 00024250

void FUN_00024250(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  *param_1 = 0;
  if (iVar1 != 0) {
    if ((char)param_1[2] != '\0') {
      FUN_000227f0(iVar1 + 0x20,*(undefined1 *)(iVar1 + 0x1c));
      if ((*(byte *)(iVar1 + 0x10) & 1) != 0) {
        FUN_0002a000(*(undefined4 *)(iVar1 + 0x18));
      }
    }
    FUN_0002a000(iVar1);
  }
  return;
}


// ==== FUN_000242b0 @ 000242b0

int * FUN_000242b0(int param_1,undefined4 *param_2,byte *param_3)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  uint __n;
  uint uVar6;
  void *__s2;
  uint local_2c;
  
  piVar2 = (int *)(param_1 + 4);
  if (*(int **)(param_1 + 4) == (int *)0x0) {
    *param_2 = piVar2;
    return piVar2;
  }
  if ((*param_3 & 1) == 0) {
    local_2c = (uint)(*param_3 >> 1);
    param_3 = param_3 + 1;
  }
  else {
    local_2c = *(uint *)(param_3 + 4);
    param_3 = *(byte **)(param_3 + 8);
  }
  piVar5 = *(int **)(param_1 + 4);
  do {
    bVar1 = *(byte *)(piVar5 + 4);
    if ((bVar1 & 1) == 0) {
      uVar6 = (uint)(bVar1 >> 1);
    }
    else {
      uVar6 = piVar5[5];
    }
    __n = local_2c;
    if (uVar6 < local_2c) {
      __n = uVar6;
    }
    if (__n == 0) {
      if (local_2c < uVar6) goto LAB_00024310;
LAB_000243e0:
      if (local_2c <= uVar6) {
LAB_00024408:
        *param_2 = piVar5;
        return piVar2;
      }
LAB_000243ea:
      piVar4 = (int *)piVar5[1];
      piVar2 = piVar5 + 1;
      if (piVar4 == (int *)0x0) {
        *param_2 = piVar5;
        return piVar5 + 1;
      }
    }
    else {
      if ((bVar1 & 1) == 0) {
        __s2 = (void *)((int)piVar5 + 0x11);
      }
      else {
        __s2 = (void *)piVar5[6];
      }
      iVar3 = memcmp(param_3,__s2,__n);
      if (iVar3 == 0) {
        if (uVar6 <= local_2c) goto LAB_000243b2;
      }
      else if (-1 < iVar3) {
LAB_000243b2:
        iVar3 = memcmp(__s2,param_3,__n);
        if (iVar3 == 0) goto LAB_000243e0;
        if (-1 < iVar3) goto LAB_00024408;
        goto LAB_000243ea;
      }
LAB_00024310:
      piVar4 = (int *)*piVar5;
      piVar2 = piVar5;
      if (piVar4 == (int *)0x0) {
        *param_2 = piVar5;
        return piVar5;
      }
    }
    piVar5 = piVar4;
  } while( true );
}


// ==== FUN_00024420 @ 00024420

void FUN_00024420(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  bool bVar5;
  
  bVar5 = param_2 == param_1;
  *(bool *)(param_2 + 3) = bVar5;
  do {
    if (bVar5) {
      return;
    }
    piVar3 = (int *)param_2[2];
    if ((char)piVar3[3] != '\0') {
      return;
    }
    piVar2 = (int *)piVar3[2];
    iVar4 = *piVar2;
    if ((int *)iVar4 == piVar3) {
      iVar4 = piVar2[1];
      if ((iVar4 == 0) || (*(char *)(iVar4 + 0xc) != '\0')) {
        if ((int *)*piVar3 != param_2) {
          piVar1 = (int *)piVar3[1];
          iVar4 = *piVar1;
          piVar3[1] = iVar4;
          if (iVar4 != 0) {
            *(int **)(iVar4 + 8) = piVar3;
            piVar2 = (int *)piVar3[2];
          }
          piVar1[2] = (int)piVar2;
          ((int *)piVar3[2])[(int *)*(int *)piVar3[2] != piVar3] = (int)piVar1;
          *piVar1 = (int)piVar3;
          piVar3[2] = (int)piVar1;
          piVar2 = (int *)piVar1[2];
          piVar3 = piVar1;
        }
        *(undefined1 *)(piVar3 + 3) = 1;
        *(undefined1 *)(piVar2 + 3) = 0;
        piVar3 = (int *)*piVar2;
        iVar4 = piVar3[1];
        *piVar2 = iVar4;
        if (iVar4 != 0) {
          *(int **)(iVar4 + 8) = piVar2;
        }
        piVar3[2] = piVar2[2];
        ((undefined4 *)piVar2[2])[*(int **)piVar2[2] != piVar2] = piVar3;
        piVar3[1] = (int)piVar2;
        goto LAB_00024553;
      }
    }
    else if ((iVar4 == 0) || (*(char *)(iVar4 + 0xc) != '\0')) {
      if ((int *)*piVar3 == param_2) {
        iVar4 = param_2[1];
        *piVar3 = iVar4;
        if (iVar4 != 0) {
          *(int **)(iVar4 + 8) = piVar3;
          piVar2 = (int *)piVar3[2];
        }
        param_2[2] = (int)piVar2;
        ((undefined4 *)piVar3[2])[*(int **)piVar3[2] != piVar3] = param_2;
        param_2[1] = (int)piVar3;
        piVar3[2] = (int)param_2;
        piVar2 = (int *)param_2[2];
      }
      else {
        param_2 = piVar3;
      }
      *(undefined1 *)(param_2 + 3) = 1;
      *(undefined1 *)(piVar2 + 3) = 0;
      piVar3 = (int *)piVar2[1];
      iVar4 = *piVar3;
      piVar2[1] = iVar4;
      if (iVar4 != 0) {
        *(int **)(iVar4 + 8) = piVar2;
      }
      piVar3[2] = piVar2[2];
      ((undefined4 *)piVar2[2])[*(int **)piVar2[2] != piVar2] = piVar3;
      *piVar3 = (int)piVar2;
LAB_00024553:
      piVar2[2] = (int)piVar3;
      return;
    }
    *(undefined1 *)(piVar3 + 3) = 1;
    bVar5 = piVar2 == param_1;
    *(bool *)(piVar2 + 3) = bVar5;
    *(undefined1 *)(iVar4 + 0xc) = 1;
    param_2 = piVar2;
  } while( true );
}


// ==== FUN_00024560 @ 00024560

int * FUN_00024560(undefined4 *param_1)

{
  void *__src;
  int iVar1;
  int *piVar2;
  void *__dest;
  undefined4 uVar3;
  size_t __n;
  
  piVar2 = (int *)FUN_00029f70(0x10);
  *piVar2 = 0;
  piVar2[1] = 0;
  piVar2[2] = 0;
  __src = (void *)*param_1;
  __n = param_1[1] - (int)__src;
  if (__n != 0) {
    if ((int)__n < 0) {
                    /* try { // try from 000245f9 to 00024600 has its CatchHandler @ 00024601 */
      uVar3 = FUN_0002ba50(piVar2);
                    /* catch() { ... } // from try @ 000245ac with catch @ 00024601
                       catch() { ... } // from try @ 000245f9 with catch @ 00024601 */
      iVar1 = *piVar2;
      if (iVar1 != 0) {
        piVar2[1] = iVar1;
        FUN_0002a000(iVar1);
      }
      FUN_0002a000(piVar2);
                    /* WARNING: Subroutine does not return */
      FUN_00043410(uVar3);
    }
                    /* try { // try from 000245ac to 000245b3 has its CatchHandler @ 00024601 */
    __dest = (void *)FUN_00029f70(__n);
    *piVar2 = (int)__dest;
    piVar2[2] = (int)__dest + __n;
    memcpy(__dest,__src,__n);
    piVar2[1] = (int)__dest + __n;
  }
  *(undefined2 *)(piVar2 + 3) = *(undefined2 *)(param_1 + 3);
  return piVar2;
}


// ==== FUN_00024630 @ 00024630

void FUN_00024630(int *param_1,int param_2,int param_3)

{
  undefined1 *puVar1;
  int iVar2;
  undefined1 *puVar3;
  int in_GS_OFFSET;
  undefined1 local_28 [4];
  undefined8 local_24;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_3 - param_2 != 0) {
    iVar2 = param_3 - param_2 >> 2;
    if (0x15555555 < (uint)(iVar2 * -0x33333333)) {
                    /* try { // try from 0002475e to 00024768 has its CatchHandler @ 0002476e */
      FUN_0002ba50(param_1);
      goto LAB_00024769;
    }
                    /* try { // try from 0002469b to 000246a2 has its CatchHandler @ 0002476e */
    puVar3 = (undefined1 *)FUN_00029f70(iVar2 * -0x66666664);
    param_1[1] = (int)puVar3;
    *param_1 = (int)puVar3;
    param_1[2] = (int)(puVar3 + iVar2 * -0x66666664);
    for (; param_2 != param_3; param_2 = param_2 + 0x14) {
      puVar1 = *(undefined1 **)(param_2 + 0xc);
      if (*(char *)(param_2 + 0x10) == '\0') {
                    /* try { // try from 00024732 to 00024741 has its CatchHandler @ 00024772 */
        FUN_00023b40(local_28,puVar1);
      }
      else {
        local_28[0] = *puVar1;
        local_24 = *(undefined8 *)(puVar1 + 4);
        *puVar1 = 0;
        *(undefined4 *)(puVar1 + 8) = 0;
        *(undefined4 *)(puVar1 + 4) = 0;
      }
      *puVar3 = local_28[0];
      *(undefined8 *)(puVar3 + 4) = local_24;
      local_28[0] = 0;
      local_24 = 0;
      FUN_000227f0(&local_24,0);
      puVar3 = puVar3 + 0xc;
    }
    param_1[1] = (int)puVar3;
  }
  if (*(int *)(in_GS_OFFSET + 0x14) == local_18) {
    return;
  }
LAB_00024769:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00024790 @ 00024790

void FUN_00024790(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int in_GS_OFFSET;
  int local_2c;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  iVar3 = param_1[1] - *param_1 >> 2;
  uVar4 = iVar3 * -0x55555555 + 1;
  if (0x15555555 < uVar4) {
    FUN_0002ba50(param_1);
LAB_00024924:
                    /* WARNING: Subroutine does not return */
    FUN_000231e0("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
  }
  iVar6 = param_1[2] - *param_1 >> 2;
  uVar7 = iVar6 * 0x55555556;
  if (uVar7 < uVar4) {
    uVar7 = uVar4;
  }
  uVar4 = 0x15555555;
  if ((uint)(iVar6 * -0x55555555) < 0xaaaaaaa) {
    uVar4 = uVar7;
  }
  if (uVar4 == 0) {
    iVar6 = 0;
  }
  else {
    if (0x15555555 < uVar4) goto LAB_00024924;
    iVar6 = FUN_00029f70(uVar4 * 0xc);
  }
  local_2c = iVar6 + iVar3 * 4;
                    /* try { // try from 0002484f to 0002485a has its CatchHandler @ 00024937 */
  FUN_00023b40(local_2c,param_2);
  iVar3 = local_2c + 0xc;
  iVar2 = *param_1;
  iVar5 = param_1[1];
  if (iVar5 == iVar2) {
    iVar5 = iVar2;
  }
  else {
    do {
      *(undefined1 *)(local_2c + -0xc) = *(undefined1 *)(iVar5 + -0xc);
      *(undefined8 *)(local_2c + -8) = *(undefined8 *)(iVar5 + -8);
      *(undefined1 *)(iVar5 + -0xc) = 0;
      *(undefined4 *)(iVar5 + -4) = 0;
      *(undefined4 *)(iVar5 + -8) = 0;
      iVar5 = iVar5 + -0xc;
      local_2c = local_2c + -0xc;
    } while (iVar5 != iVar2);
    iVar2 = param_1[1];
    iVar5 = *param_1;
  }
  *param_1 = local_2c;
  param_1[1] = iVar3;
  param_1[2] = iVar6 + uVar4 * 0xc;
  for (; iVar2 != iVar5; iVar2 = iVar2 + -0xc) {
    FUN_000227f0(iVar2 + -8,*(undefined1 *)(iVar2 + -0xc));
  }
  if (iVar5 != 0) {
    FUN_0002a000(iVar5);
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00024950 @ 00024950

void FUN_00024950(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 8))(piVar3);
      FUN_00029e80(piVar3);
    }
  }
  return;
}


// ==== FUN_000249a0 @ 000249a0

void FUN_000249a0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 8))(piVar3);
      FUN_00029e80(piVar3);
    }
  }
  return;
}


// ==== FUN_000249f0 @ 000249f0

void FUN_000249f0(undefined4 *param_1,undefined1 *param_2,char param_3,undefined1 param_4,
                 int param_5,int param_6)

{
  uint *puVar1;
  byte bVar2;
  byte *pbVar3;
  undefined8 uVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  char cVar9;
  int iVar10;
  uint uVar11;
  undefined4 *puVar12;
  int *piVar13;
  uint uVar14;
  byte *pbVar15;
  int *piVar16;
  int iVar17;
  int in_GS_OFFSET;
  double dVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined4 uVar21;
  int local_3c;
  uint local_38;
  undefined4 local_20;
  undefined4 local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  switch(*param_2) {
  case 0:
    goto switchD_00024a37_caseD_0;
  case 1:
    piVar13 = (int *)*param_1;
    if (*(int *)(*(int *)(param_2 + 4) + 8) != 0) {
      if (param_3 == '\0') {
        (**(code **)*piVar13)();
        piVar13 = (int *)**(undefined4 **)(param_2 + 4);
        if ((*(undefined4 **)(param_2 + 4))[2] != 1) {
          uVar6 = 0;
          do {
            (*(code *)**(undefined4 **)*param_1)();
            FUN_00025c40();
            uVar21 = 2;
            (**(code **)(*(int *)*param_1 + 4))();
            FUN_000249f0(param_1,piVar13 + 7,0,param_4,param_5,param_6,uVar21);
            (*(code *)**(undefined4 **)*param_1)();
            uVar6 = uVar6 + 1;
            piVar16 = (int *)piVar13[1];
            if ((int *)piVar13[1] == (int *)0x0) {
              piVar8 = (int *)piVar13[2];
              if (*(int **)piVar13[2] != piVar13) {
                do {
                  piVar13 = (int *)piVar13[2];
                  piVar8 = (int *)piVar13[2];
                } while (*(int **)piVar13[2] != piVar13);
              }
            }
            else {
              do {
                piVar8 = piVar16;
                piVar16 = (int *)*piVar8;
              } while (piVar16 != (int *)0x0);
            }
            piVar13 = piVar8;
          } while (uVar6 < *(int *)(*(int *)(param_2 + 4) + 8) - 1U);
        }
        (*(code *)**(undefined4 **)*param_1)();
        FUN_00025c40();
        uVar21 = 2;
        (**(code **)(*(int *)*param_1 + 4))();
        FUN_000249f0(param_1,piVar13 + 7,0,param_4,param_5,param_6,uVar21);
        goto LAB_000259aa;
      }
      (**(code **)(*piVar13 + 4))();
      uVar6 = param_5 + param_6;
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        uVar7 = (uint)(*(byte *)(param_1 + 0x94) >> 1);
      }
      else {
        uVar7 = param_1[0x95];
      }
      if (uVar7 < uVar6) {
        FUN_0002aa30();
      }
      piVar13 = (int *)**(undefined4 **)(param_2 + 4);
      if ((*(undefined4 **)(param_2 + 4))[2] != 1) {
        local_38 = 0;
        piVar16 = piVar13;
        do {
          (**(code **)(*(int *)*param_1 + 4))();
          (*(code *)**(undefined4 **)*param_1)();
          FUN_00025c40();
          uVar21 = 3;
          (**(code **)(*(int *)*param_1 + 4))();
          FUN_000249f0(param_1,piVar16 + 7,1,param_4,param_5,uVar6,uVar21);
          (**(code **)(*(int *)*param_1 + 4))();
          local_38 = local_38 + 1;
          piVar8 = (int *)piVar16[1];
          if ((int *)piVar16[1] == (int *)0x0) {
            piVar13 = (int *)piVar16[2];
            if ((int *)*piVar13 != piVar16) {
              do {
                piVar16 = (int *)piVar16[2];
                piVar13 = (int *)piVar16[2];
              } while ((int *)*piVar13 != piVar16);
            }
          }
          else {
            do {
              piVar13 = piVar8;
              piVar8 = (int *)*piVar13;
            } while ((int *)*piVar13 != (int *)0x0);
          }
          piVar16 = piVar13;
        } while (local_38 < *(int *)(*(int *)(param_2 + 4) + 8) - 1U);
      }
      (**(code **)(*(int *)*param_1 + 4))();
      (*(code *)**(undefined4 **)*param_1)();
      FUN_00025c40();
      uVar21 = 3;
      (**(code **)(*(int *)*param_1 + 4))();
      FUN_000249f0(param_1,piVar13 + 7,1,param_4,param_5,uVar6,uVar21);
      (*(code *)**(undefined4 **)*param_1)();
      (**(code **)(*(int *)*param_1 + 4))();
      param_1 = (undefined4 *)*param_1;
      goto LAB_000259ac;
    }
    iVar10 = *piVar13;
    break;
  case 2:
    piVar13 = (int *)*param_1;
    if (**(int **)(param_2 + 4) != (*(int **)(param_2 + 4))[1]) {
      if (param_3 == '\0') {
        (**(code **)*piVar13)();
        iVar10 = **(int **)(param_2 + 4);
        if (iVar10 != (*(int **)(param_2 + 4))[1] + -0xc) {
          do {
            FUN_000249f0(param_1,iVar10,0,param_4,param_5,param_6);
            (*(code *)**(undefined4 **)*param_1)();
            iVar10 = iVar10 + 0xc;
          } while (iVar10 != *(int *)(*(int *)(param_2 + 4) + 4) + -0xc);
        }
        FUN_000249f0(param_1,iVar10,0,param_4,param_5,param_6);
      }
      else {
        (**(code **)(*piVar13 + 4))();
        uVar6 = param_5 + param_6;
        if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
          uVar7 = (uint)(*(byte *)(param_1 + 0x94) >> 1);
        }
        else {
          uVar7 = param_1[0x95];
        }
        if (uVar7 < uVar6) {
          FUN_0002aa30();
        }
        iVar10 = **(int **)(param_2 + 4);
        if (iVar10 != (*(int **)(param_2 + 4))[1] + -0xc) {
          do {
            uVar7 = uVar6;
            (**(code **)(*(int *)*param_1 + 4))();
            FUN_000249f0(param_1,iVar10,1,param_4,param_5,uVar6,uVar7);
            (**(code **)(*(int *)*param_1 + 4))();
            iVar10 = iVar10 + 0xc;
          } while (iVar10 != *(int *)(*(int *)(param_2 + 4) + 4) + -0xc);
        }
        uVar7 = uVar6;
        (**(code **)(*(int *)*param_1 + 4))();
        FUN_000249f0(param_1,*(int *)(*(int *)(param_2 + 4) + 4) + -0xc,1,param_4,param_5,uVar6,
                     uVar7);
        (*(code *)**(undefined4 **)*param_1)();
        (**(code **)(*(int *)*param_1 + 4))();
      }
      param_1 = *(undefined4 **)*param_1;
      goto LAB_000259b3;
    }
    iVar10 = *piVar13;
    break;
  case 3:
    (*(code *)**(undefined4 **)*param_1)();
    FUN_00025c40();
    param_1 = *(undefined4 **)*param_1;
    goto LAB_000259b3;
  case 4:
    (**(code **)(*(int *)*param_1 + 4))();
    goto switchD_00024a37_default;
  case 5:
    FUN_000264c0();
    goto switchD_00024a37_default;
  case 6:
    puVar1 = (uint *)(param_2 + 4);
    uVar6 = *puVar1;
    uVar7 = *(uint *)(param_2 + 8);
    uVar4 = *(undefined8 *)puVar1;
    uVar20 = *(undefined8 *)puVar1;
    if (uVar6 == 0 && uVar7 == 0) {
      param_1 = *(undefined4 **)*param_1;
      goto LAB_000259b3;
    }
    if (uVar7 < (uVar6 < 10)) {
      iVar10 = (int)param_1 + 9;
LAB_000256e4:
      *(char *)(iVar10 + -1) = (char)uVar6 + '0';
    }
    else {
      local_3c = 4;
      iVar10 = local_3c;
      uVar19 = uVar20;
      do {
        local_3c = iVar10;
        uVar14 = (uint)((ulonglong)uVar19 >> 0x20);
        uVar11 = (uint)uVar19;
        if (uVar14 == 0 && (uint)(99 < uVar11) <= -uVar14) {
          local_3c = local_3c + -2;
          goto LAB_00025634;
        }
        if (uVar14 == 0 && (uint)(999 < uVar11) <= -uVar14) {
          local_3c = local_3c + -1;
          goto LAB_00025634;
        }
        if (uVar14 < (uVar11 < 10000)) goto LAB_00025634;
        uVar19 = FUN_00043140();
        iVar10 = local_3c + 4;
      } while (uVar14 != 0 || -uVar14 < (uint)(99999 < uVar11));
      local_3c = local_3c + 1;
LAB_00025634:
      iVar10 = (int)param_1 + local_3c + 8;
      if ((uVar6 < 100) <= uVar7) {
        do {
          iVar17 = (int)((ulonglong)uVar20 >> 0x20);
          uVar6 = (uint)uVar20;
          uVar20 = FUN_00043140();
          *(undefined2 *)(iVar10 + -2) =
               *(undefined2 *)
                (
                "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
                + (uVar6 + (int)uVar20 * -100) * 2);
          iVar10 = iVar10 + -2;
          uVar4 = uVar20;
        } while (iVar17 != 0 || (uint)-iVar17 < (uint)(9999 < uVar6));
      }
      uVar6 = (uint)uVar4;
      if ((uint)((ulonglong)uVar4 >> 0x20) < (uint)(uVar6 < 10)) goto LAB_000256e4;
      *(undefined2 *)(iVar10 + -2) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
            + uVar6 * 2);
    }
    iVar10 = *(int *)*param_1;
    break;
  case 7:
    dVar18 = *(double *)(param_2 + 4);
    if (ABS(dVar18) != INFINITY) {
      puVar12 = param_1 + 2;
      if ((longlong)dVar18 < 0) {
        dVar18 = -dVar18;
        puVar12 = (undefined4 *)((int)param_1 + 9);
        *(undefined1 *)(param_1 + 2) = 0x2d;
        if ((dVar18 != 0.0) || (NAN(dVar18))) goto LAB_0002509c;
LAB_00024b87:
        *(undefined2 *)puVar12 = 0x2e30;
        *(undefined1 *)((int)puVar12 + 2) = 0x30;
      }
      else {
        if ((dVar18 == 0.0) && (!NAN(dVar18))) goto LAB_00024b87;
LAB_0002509c:
        local_1c = 0;
        local_20 = 0;
        FUN_000267b0(puVar12,&local_1c,&local_20,dVar18);
        FUN_00026c00(puVar12,local_1c,local_20,0xfffffffc,0xf);
      }
      (**(code **)(*(int *)*param_1 + 4))();
      goto switchD_00024a37_default;
    }
    goto switchD_00024a37_caseD_0;
  case 8:
    if (param_3 == '\0') {
      (**(code **)(*(int *)*param_1 + 4))();
      pbVar15 = (byte *)**(undefined4 **)(param_2 + 4);
      pbVar3 = (byte *)(*(undefined4 **)(param_2 + 4))[1];
      if (pbVar15 != pbVar3) {
        if (pbVar15 != pbVar3 + -1) {
          do {
            bVar2 = *pbVar15;
            uVar6 = (uint)bVar2;
            if (uVar6 == 0) {
              (*(code *)**(undefined4 **)*param_1)();
            }
            else {
              bVar5 = bVar2;
              if (bVar2 < 10) {
LAB_00024d03:
                cVar9 = bVar5 + 0x30;
              }
              else {
                if (99 < bVar2) {
                  bVar5 = (byte)(uVar6 * 0x29 >> 0xc);
                  *(undefined2 *)((int)param_1 + 9) =
                       *(undefined2 *)(&DAT_000155df + (uint)(byte)(bVar2 + bVar5 * -100) * 2);
                  goto LAB_00024d03;
                }
                *(undefined *)((int)param_1 + 9) = (&DAT_000155e0)[uVar6 * 2];
                cVar9 = (&DAT_000155df)[uVar6 * 2];
              }
              *(char *)(param_1 + 2) = cVar9;
              (**(code **)(*(int *)*param_1 + 4))();
            }
            (*(code *)**(undefined4 **)*param_1)();
            pbVar15 = pbVar15 + 1;
          } while (pbVar15 != (byte *)(*(int *)(*(int *)(param_2 + 4) + 4) + -1));
        }
        bVar2 = *pbVar15;
        uVar6 = (uint)bVar2;
        if (uVar6 == 0) {
          (*(code *)**(undefined4 **)*param_1)();
        }
        else {
          bVar5 = bVar2;
          if (bVar2 < 10) {
LAB_0002583c:
            cVar9 = bVar5 + 0x30;
          }
          else {
            if (99 < bVar2) {
              bVar5 = (byte)(uVar6 * 0x29 >> 0xc);
              *(undefined2 *)((int)param_1 + 9) =
                   *(undefined2 *)(&DAT_000155df + (uint)(byte)(bVar2 + bVar5 * -100) * 2);
              goto LAB_0002583c;
            }
            *(undefined *)((int)param_1 + 9) = (&DAT_000155e0)[uVar6 * 2];
            cVar9 = (&DAT_000155df)[uVar6 * 2];
          }
          *(char *)(param_1 + 2) = cVar9;
          (**(code **)(*(int *)*param_1 + 4))();
        }
      }
      (**(code **)(*(int *)*param_1 + 4))();
      if (*(char *)(*(int *)(param_2 + 4) + 0xd) == '\0') {
        iVar10 = *(int *)*param_1;
        break;
      }
      bVar2 = *(byte *)(*(int *)(param_2 + 4) + 0xc);
      uVar6 = (uint)bVar2;
      if (uVar6 == 0) {
        (*(code *)**(undefined4 **)*param_1)();
        goto LAB_000259aa;
      }
      bVar5 = bVar2;
      if (bVar2 < 10) {
LAB_0002598f:
        cVar9 = bVar5 + 0x30;
      }
      else {
        if (99 < bVar2) {
          bVar5 = (byte)(uVar6 * 0x29 >> 0xc);
          *(undefined2 *)((int)param_1 + 9) =
               *(undefined2 *)(&DAT_000155df + (uint)(byte)(bVar2 + bVar5 * -100) * 2);
          goto LAB_0002598f;
        }
        *(undefined *)((int)param_1 + 9) = (&DAT_000155e0)[uVar6 * 2];
        cVar9 = (&DAT_000155df)[uVar6 * 2];
      }
      *(char *)(param_1 + 2) = cVar9;
      iVar10 = *(int *)*param_1;
    }
    else {
      (**(code **)(*(int *)*param_1 + 4))();
      if ((*(byte *)(param_1 + 0x94) & 1) == 0) {
        uVar6 = (uint)(*(byte *)(param_1 + 0x94) >> 1);
      }
      else {
        uVar6 = param_1[0x95];
      }
      if (uVar6 < (uint)(param_5 + param_6)) {
        FUN_0002aa30();
      }
      (**(code **)(*(int *)*param_1 + 4))();
      (**(code **)(*(int *)*param_1 + 4))();
      pbVar15 = (byte *)**(undefined4 **)(param_2 + 4);
      pbVar3 = (byte *)(*(undefined4 **)(param_2 + 4))[1];
      if (pbVar15 != pbVar3) {
        if (pbVar15 != pbVar3 + -1) {
          do {
            bVar2 = *pbVar15;
            uVar6 = (uint)bVar2;
            if (uVar6 == 0) {
              (*(code *)**(undefined4 **)*param_1)();
            }
            else {
              bVar5 = bVar2;
              if (bVar2 < 10) {
LAB_0002501c:
                cVar9 = bVar5 + 0x30;
              }
              else {
                if (99 < bVar2) {
                  bVar5 = (byte)(uVar6 * 0x29 >> 0xc);
                  *(undefined2 *)((int)param_1 + 9) =
                       *(undefined2 *)(&DAT_000155df + (uint)(byte)(bVar2 + bVar5 * -100) * 2);
                  goto LAB_0002501c;
                }
                *(undefined *)((int)param_1 + 9) = (&DAT_000155e0)[uVar6 * 2];
                cVar9 = (&DAT_000155df)[uVar6 * 2];
              }
              *(char *)(param_1 + 2) = cVar9;
              (**(code **)(*(int *)*param_1 + 4))();
            }
            (**(code **)(*(int *)*param_1 + 4))();
            pbVar15 = pbVar15 + 1;
          } while (pbVar15 != (byte *)(*(int *)(*(int *)(param_2 + 4) + 4) + -1));
        }
        bVar2 = *pbVar15;
        uVar6 = (uint)bVar2;
        if (uVar6 == 0) {
          (*(code *)**(undefined4 **)*param_1)();
        }
        else {
          bVar5 = bVar2;
          if (bVar2 < 10) {
LAB_00025721:
            cVar9 = bVar5 + 0x30;
          }
          else {
            if (99 < bVar2) {
              bVar5 = (byte)(uVar6 * 0x29 >> 0xc);
              *(undefined2 *)((int)param_1 + 9) =
                   *(undefined2 *)(&DAT_000155df + (uint)(byte)(bVar2 + bVar5 * -100) * 2);
              goto LAB_00025721;
            }
            *(undefined *)((int)param_1 + 9) = (&DAT_000155e0)[uVar6 * 2];
            cVar9 = (&DAT_000155df)[uVar6 * 2];
          }
          *(char *)(param_1 + 2) = cVar9;
          (**(code **)(*(int *)*param_1 + 4))();
        }
      }
      (**(code **)(*(int *)*param_1 + 4))();
      (**(code **)(*(int *)*param_1 + 4))();
      (**(code **)(*(int *)*param_1 + 4))();
      if (*(char *)(*(int *)(param_2 + 4) + 0xd) == '\0') {
        (**(code **)(*(int *)*param_1 + 4))();
      }
      else {
        bVar2 = *(byte *)(*(int *)(param_2 + 4) + 0xc);
        uVar6 = (uint)bVar2;
        if (uVar6 == 0) {
          (*(code *)**(undefined4 **)*param_1)();
        }
        else {
          bVar5 = bVar2;
          if (bVar2 < 10) {
LAB_00025916:
            cVar9 = bVar5 + 0x30;
          }
          else {
            if (99 < bVar2) {
              bVar5 = (byte)(uVar6 * 0x29 >> 0xc);
              *(undefined2 *)((int)param_1 + 9) =
                   *(undefined2 *)(&DAT_000155df + (uint)(byte)(bVar2 + bVar5 * -100) * 2);
              goto LAB_00025916;
            }
            *(undefined *)((int)param_1 + 9) = (&DAT_000155e0)[uVar6 * 2];
            cVar9 = (&DAT_000155df)[uVar6 * 2];
          }
          *(char *)(param_1 + 2) = cVar9;
          (**(code **)(*(int *)*param_1 + 4))();
        }
      }
      (*(code *)**(undefined4 **)*param_1)();
      iVar10 = *(int *)*param_1;
    }
    (**(code **)(iVar10 + 4))();
LAB_000259aa:
    param_1 = (undefined4 *)*param_1;
LAB_000259ac:
    param_1 = (undefined4 *)*param_1;
LAB_000259b3:
    (*(code *)*param_1)();
    goto switchD_00024a37_default;
  case 9:
    iVar10 = *(int *)*param_1;
    break;
  default:
    goto switchD_00024a37_default;
  }
LAB_000258cd:
  (**(code **)(iVar10 + 4))();
switchD_00024a37_default:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
switchD_00024a37_caseD_0:
  iVar10 = *(int *)*param_1;
  goto LAB_000258cd;
}


// ==== FUN_00025a50 @ 00025a50

void FUN_00025a50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if ((*(byte *)(param_1 + 0x250) & 1) != 0) {
    FUN_0002a000(*(undefined4 *)(param_1 + 600));
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 8))(piVar3);
      FUN_00029e80(piVar3);
    }
  }
  return;
}


// ==== FUN_00025b20 @ 00025b20

void FUN_00025b20(int param_1)

{
  (**(code **)(*(int *)(param_1 + 0xc) + 8))(param_1 + 0xc);
  return;
}


// ==== FUN_00025c40 @ 00025c40

void FUN_00025c40(undefined4 *param_1,byte *param_2,char param_3)

{
  byte bVar1;
  char cVar2;
  undefined **ppuVar3;
  int *piVar4;
  undefined8 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined2 uVar8;
  byte *pbVar9;
  byte bVar10;
  int iVar11;
  undefined1 *puVar12;
  undefined1 *puVar13;
  undefined ***pppuVar14;
  uint uVar15;
  int iVar16;
  undefined **ppuVar17;
  int in_GS_OFFSET;
  bool bVar18;
  undefined **ppuStack_9c;
  undefined1 *puStack_98;
  int local_94;
  int local_90;
  int local_8c;
  undefined **local_88;
  undefined **local_84;
  byte local_7d;
  undefined1 *local_7c;
  int local_78;
  uint local_74;
  undefined **local_70;
  byte *local_6c;
  undefined1 local_68 [12];
  undefined8 local_5c;
  undefined4 local_54;
  undefined8 local_4c;
  undefined4 local_44;
  undefined1 local_3c [4];
  undefined *local_38 [3];
  undefined *local_2c;
  undefined1 local_28;
  undefined4 auStack_27 [3];
  int local_18;
  
  local_94 = 0x25c54;
  local_88 = &__DT_PLTGOT;
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  bVar18 = (*param_2 & 1) == 0;
  if (bVar18) {
    if (*param_2 >> 1 == 0) goto LAB_00026068;
  }
  else if (*(int *)(param_2 + 4) == 0) goto LAB_00026068;
  local_6c = param_2 + 1;
  local_70 = (undefined **)((int)param_1 + 0x4e);
  puVar12 = (undefined1 *)0x0;
  local_84 = (undefined **)0x0;
  local_78 = 0;
  local_7c = (undefined1 *)0x0;
  bVar10 = 0;
LAB_00025ccd:
  do {
    pbVar9 = local_6c;
    if (!bVar18) {
      pbVar9 = *(byte **)(param_2 + 8);
    }
    local_7d = pbVar9[(int)local_84];
    uVar15 = (uint)local_7d;
    bVar1 = *(byte *)((int)local_88 + (uVar15 - 0x37299));
    if (bVar10 == 0) {
      local_74 = 0xffU >> (bVar1 & 0x1f) & uVar15;
    }
    else {
      local_74 = local_74 << 6 | uVar15 & 0x3f;
    }
    bVar10 = *(byte *)((int)local_88 + (uint)bVar10 * 0x10 + (uint)bVar1 + -0x37199);
    if (bVar10 == 1) {
      iVar11 = param_1[0x97];
      if (iVar11 - 1U < 2) {
        local_84 = (undefined **)((int)local_84 + ((local_78 == 0) - 1));
        bVar10 = 0;
        if (iVar11 == 1) {
          if (param_3 == '\0') {
            puVar12 = local_7c + 1;
            local_7c[(int)param_1 + 0x4e] = 0xef;
            iVar11 = 3;
            uVar8 = 0xbfbd;
            iVar16 = 2;
          }
          else {
            *(undefined4 *)(local_7c + (int)param_1 + 0x4e) = 0x6666755c;
            puVar12 = local_7c + 4;
            iVar11 = 6;
            uVar8 = 0x6664;
            iVar16 = 5;
          }
          puVar12[(int)param_1 + 0x4e] = (char)((ushort)uVar8 >> 8);
          local_7c[(int)param_1 + iVar16 + 0x4e] = (char)uVar8;
          puVar13 = local_7c + iVar11;
          bVar10 = 0;
          if (local_7c + iVar11 + -500 < (undefined1 *)0xd) {
            piVar4 = (int *)*param_1;
            goto LAB_00025f25;
          }
          local_78 = 0;
          puVar12 = puVar13;
          local_7c = puVar13;
        }
        else {
          local_78 = 0;
          puVar12 = local_7c;
        }
      }
      else {
        bVar10 = 1;
        if (iVar11 == 0) {
          local_28 = 6;
          auStack_27[0] = 0;
                    /* try { // try from 00026143 to 0002615e has its CatchHandler @ 0002648e */
          FUN_00026740(auStack_27,0xb,3,local_88 + -0xdfac,uVar15);
          uVar6 = FUN_0002bad0(0x10);
                    /* try { // try from 00026172 to 00026185 has its CatchHandler @ 00026473 */
          ppuStack_9c = local_84;
          FUN_0002adc0(local_68);
                    /* try { // try from 00026186 to 0002619e has its CatchHandler @ 00026455 */
          ppuStack_9c = (undefined **)(local_8c + -0x38140);
          puVar5 = (undefined8 *)FUN_0002a7b0(local_68,0);
          local_54 = *(undefined4 *)(puVar5 + 1);
          local_5c = *puVar5;
          *(undefined4 *)((int)puVar5 + 4) = 0;
          *(undefined4 *)puVar5 = 0;
          *(undefined4 *)(puVar5 + 1) = 0;
                    /* try { // try from 000261c4 to 000261de has its CatchHandler @ 00026409 */
          puVar5 = (undefined8 *)FUN_0002a960(&local_5c,local_8c + -0x37aad);
          local_44 = *(undefined4 *)(puVar5 + 1);
          local_4c = *puVar5;
          *(undefined4 *)((int)puVar5 + 4) = 0;
          *(undefined4 *)puVar5 = 0;
          *(undefined4 *)(puVar5 + 1) = 0;
                    /* try { // try from 00026204 to 00026221 has its CatchHandler @ 000263de */
          ppuStack_9c = &local_2c;
          uVar7 = FUN_000237c0(local_3c,&local_4c);
          local_8c = CONCAT31((int3)((uint)uVar7 >> 8),1);
                    /* try { // try from 00026228 to 00026263 has its CatchHandler @ 00026390 */
          FUN_00023500(uVar6,0x13c,local_3c);
          local_90 = 0;
          uVar7 = FUN_0002bb70(uVar6,local_94 + -0x1504,local_94 + -0x28fa8);
          pppuVar14 = &ppuStack_9c;
          goto LAB_00026328;
        }
      }
    }
    else if (bVar10 == 0) {
      if (local_74 - 8 < 0x1b) {
                    /* WARNING: Could not recover jumptable at 0x00025d6b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)(local_88[local_74 - 0xe33e] + (int)local_88))();
        return;
      }
      if (local_74 == 0x5c) {
        *(undefined2 *)(puVar12 + (int)param_1 + 0x4e) = 0x5c5c;
        puVar13 = puVar12 + 2;
        puVar12 = puVar12 + -0x1f2;
      }
      else if (local_74 < 0x20) {
LAB_00025e7f:
        FUN_00026740((undefined1 *)((int)param_1 + (int)puVar12) + 0x4e,0xffffffff,7,
                     (int)local_88 + -0x38adf,local_74);
        puVar13 = puVar12 + 6;
        puVar12 = puVar12 + -0x1ee;
      }
      else if ((param_3 == '\0') || (local_74 < 0x7f)) {
        puVar12[(int)param_1 + 0x4e] = local_7d;
        puVar13 = puVar12 + 1;
        puVar12 = puVar12 + -499;
      }
      else {
        if (local_74 < 0x10000) goto LAB_00025e7f;
        ppuStack_9c = (undefined **)(local_74 & 0x3ff | 0xdc00);
        FUN_00026740((undefined1 *)((int)param_1 + (int)puVar12) + 0x4e,0xffffffff,0xd,
                     (int)local_88 + -0x377c6,(local_74 >> 10) + 0xd7c0 & 0xffff);
        puVar13 = puVar12 + 0xc;
        puVar12 = puVar12 + -0x1e8;
      }
      if (puVar12 < (undefined1 *)0xd) {
        piVar4 = (int *)*param_1;
LAB_00025f25:
        ppuStack_9c = local_70;
        puStack_98 = puVar13;
        (**(code **)(*piVar4 + 4))(piVar4);
        bVar10 = 0;
        local_7c = (undefined1 *)0x0;
        local_78 = 0;
        puVar12 = (undefined1 *)0x0;
      }
      else {
        bVar10 = 0;
        local_78 = 0;
        puVar12 = puVar13;
        local_7c = puVar13;
      }
    }
    else {
      if (param_3 == '\0') {
        puVar12[(int)param_1 + 0x4e] = local_7d;
        puVar12 = puVar12 + 1;
      }
      local_78 = local_78 + 1;
    }
    ppuVar3 = local_88;
    local_84 = (undefined **)((int)local_84 + 1);
    bVar1 = *param_2;
    bVar18 = (bVar1 & 1) == 0;
    if (bVar18) {
      ppuVar17 = (undefined **)(uint)(bVar1 >> 1);
      if (ppuVar17 <= local_84) break;
      goto LAB_00025ccd;
    }
    ppuVar17 = *(undefined ***)(param_2 + 4);
  } while (local_84 < ppuVar17);
  if (bVar10 == 0) {
    if (puVar12 != (undefined1 *)0x0) {
      ppuStack_9c = local_70;
      puStack_98 = puVar12;
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1);
      if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
        local_94 = 0x2604d;
        __stack_chk_fail();
      }
      return;
    }
  }
  else {
    iVar11 = param_1[0x97];
    if (iVar11 == 1) {
      puStack_98 = local_7c;
      ppuStack_9c = local_70;
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1);
      piVar4 = (int *)*param_1;
      if (param_3 == '\0') {
        ppuStack_9c = ppuVar3 + -0xde65;
        puStack_98 = (undefined1 *)0x3;
        (**(code **)(*piVar4 + 4))(piVar4);
        if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
          local_94 = 0x26132;
          __stack_chk_fail();
        }
        return;
      }
      ppuStack_9c = (undefined **)((int)ppuVar3 + -0x3829e);
      puStack_98 = (undefined1 *)0x6;
      (**(code **)(*piVar4 + 4))(piVar4);
      if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
        local_94 = 0x26107;
        __stack_chk_fail();
      }
      return;
    }
    if (iVar11 == 2) {
      puStack_98 = local_7c;
      ppuStack_9c = local_70;
      (**(code **)(*(int *)*param_1 + 4))((int *)*param_1);
      if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
        local_94 = 0x260b2;
        __stack_chk_fail();
      }
      return;
    }
    if (iVar11 == 0) {
      local_28 = 6;
      auStack_27[0] = 0;
      if ((bVar1 & 1) != 0) {
        local_6c = *(byte **)(param_2 + 8);
      }
                    /* try { // try from 0002629b to 000262b6 has its CatchHandler @ 0002637e */
      FUN_00026740(auStack_27,0xb,3,local_88 + -0xdfac,local_6c[(int)ppuVar17 - 1]);
      ppuVar3 = local_88;
      uVar6 = FUN_0002bad0(0x10);
                    /* try { // try from 000262ca to 000262e5 has its CatchHandler @ 00026360 */
      puStack_98 = &local_28;
      ppuStack_9c = (undefined **)((int)ppuVar3 + -0x38855);
      uVar7 = FUN_0002aaa0(local_38);
      local_88 = (undefined **)CONCAT31((int3)((uint)uVar7 >> 8),1);
      ppuStack_9c = local_38;
                    /* try { // try from 000262ec to 00026327 has its CatchHandler @ 00026328 */
      FUN_00023500(uVar6,0x13c);
      local_8c = 0;
      uVar7 = FUN_0002bb70(uVar6,local_90 + -0x1504,local_90 + -0x28fa8);
      pppuVar14 = (undefined ***)&puStack_98;
LAB_00026328:
                    /* catch() { ... } // from try @ 000262ec with catch @ 00026328 */
      if ((*(byte *)((int)pppuVar14 + 0x58) & 1) == 0) {
        cVar2 = *(char *)((int)pppuVar14 + 0xc);
      }
      else {
        *(undefined4 *)((int)pppuVar14 + -0x10) = *(undefined4 *)((int)pppuVar14 + 0x60);
        *(undefined4 *)((int)pppuVar14 + -0x14) = 0x2634a;
        FUN_0002a000();
        cVar2 = *(char *)((int)pppuVar14 + 0xc);
      }
      if (cVar2 == '\0') {
        bVar10 = *(byte *)((int)pppuVar14 + 0x68);
      }
      else {
        *(undefined4 *)((int)pppuVar14 + -0x10) = uVar6;
        *(undefined4 *)((int)pppuVar14 + -0x14) = 0x2636f;
        FUN_0002bb30();
        bVar10 = *(byte *)((int)pppuVar14 + 0x68);
      }
      if ((bVar10 & 1) != 0) {
        *(undefined4 *)((int)pppuVar14 + -0x10) = *(undefined4 *)((int)pppuVar14 + 0x70);
        *(undefined4 *)((int)pppuVar14 + -0x14) = 0x264a7;
        FUN_0002a000();
      }
      *(undefined4 *)((int)pppuVar14 + -0x10) = uVar7;
                    /* WARNING: Subroutine does not return */
      *(undefined **)((int)pppuVar14 + -0x14) = &UNK_000264b7;
      FUN_00043410();
    }
  }
LAB_00026068:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    local_94 = 0x26272;
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_000264c0 @ 000264c0

void FUN_000264c0(undefined4 *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined8 uVar5;
  int local_2c;
  uint local_24;
  
  uVar5 = CONCAT44(param_3,param_2);
  if (param_2 == 0 && param_3 == 0) {
    (*(code *)**(undefined4 **)*param_1)((undefined4 *)*param_1,0x30);
    return;
  }
  local_24 = param_2;
  if ((int)param_3 < 0) {
    *(undefined1 *)(param_1 + 2) = 0x2d;
    local_24 = -param_2;
    param_3 = -(uint)(param_2 != 0) - param_3;
    uVar5 = CONCAT44(param_3,local_24);
    local_2c = 1;
    if ((local_24 < 10) <= param_3) {
      iVar2 = 4;
      do {
        local_2c = iVar2;
        uVar1 = (uint)((ulonglong)uVar5 >> 0x20);
        uVar3 = (uint)uVar5;
        if (uVar1 == 0 && (uint)(99 < uVar3) <= -uVar1) {
          local_2c = local_2c + -2;
          goto LAB_0002667b;
        }
        if (uVar1 == 0 && (uint)(999 < uVar3) <= -uVar1) {
          local_2c = local_2c + -1;
          goto LAB_0002667b;
        }
        if (uVar1 < (uVar3 < 10000)) goto LAB_0002667b;
        uVar5 = FUN_00043140(uVar5,10000,0);
        iVar2 = local_2c + 4;
      } while (uVar1 != 0 || -uVar1 < (uint)(99999 < uVar3));
      local_2c = local_2c + 1;
    }
LAB_0002667b:
    local_2c = local_2c + 1;
LAB_0002667e:
    uVar5 = CONCAT44(param_3,local_24);
    iVar2 = (int)param_1 + local_2c + 8;
    if (param_3 < (local_24 < 100)) {
      if (param_3 < (local_24 < 10)) goto LAB_00026715;
    }
    else {
      do {
        iVar4 = (int)((ulonglong)uVar5 >> 0x20);
        uVar1 = (uint)uVar5;
        uVar5 = FUN_00043140(uVar5,100,0);
        local_24 = (uint)uVar5;
        *(undefined2 *)(iVar2 + -2) = *(undefined2 *)(&DAT_000156a7 + (uVar1 + local_24 * -100) * 2)
        ;
        iVar2 = iVar2 + -2;
      } while (iVar4 != 0 || (uint)-iVar4 < (uint)(9999 < uVar1));
      if ((uint)((ulonglong)uVar5 >> 0x20) < (uint)(local_24 < 10)) {
LAB_00026715:
        param_2 = local_24;
        goto LAB_0002671a;
      }
    }
    *(undefined2 *)(iVar2 + -2) = *(undefined2 *)(&DAT_000156a7 + local_24 * 2);
  }
  else {
    if ((param_2 < 10) <= param_3) {
      local_2c = 4;
      iVar2 = local_2c;
      do {
        local_2c = iVar2;
        uVar1 = (uint)((ulonglong)uVar5 >> 0x20);
        uVar3 = (uint)uVar5;
        if (uVar1 == 0 && (uint)(99 < uVar3) <= -uVar1) {
          local_2c = local_2c + -2;
          goto LAB_0002667e;
        }
        if (uVar1 == 0 && (uint)(999 < uVar3) <= -uVar1) {
          local_2c = local_2c + -1;
          goto LAB_0002667e;
        }
        if (uVar1 < (uVar3 < 10000)) goto LAB_0002667e;
        uVar5 = FUN_00043140(uVar5,10000,0);
        iVar2 = local_2c + 4;
      } while (uVar1 != 0 || -uVar1 < (uint)(99999 < uVar3));
      local_2c = local_2c + 1;
      goto LAB_0002667e;
    }
    iVar2 = (int)param_1 + 9;
    local_2c = 1;
LAB_0002671a:
    *(char *)(iVar2 + -1) = (char)param_2 + '0';
  }
  (**(code **)(*(int *)*param_1 + 4))((int *)*param_1,param_1 + 2,local_2c);
  return;
}


// ==== FUN_00026740 @ 00026740

void FUN_00026740(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined1 param_5)

{
  int iVar1;
  int in_GS_OFFSET;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  __vsnprintf_chk(param_1,param_3,0,param_2,param_4,&param_5);
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_000267b0 @ 000267b0

/* WARNING: Removing unreachable block (ram,0x000268a6) */
/* WARNING: Removing unreachable block (ram,0x0002691f) */

void FUN_000267b0(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,uint param_5)

{
  int iVar1;
  uint uVar2;
  byte bVar3;
  short sVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  byte bVar13;
  short sVar14;
  int iVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  int iVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  uint uVar34;
  uint uVar35;
  uint uVar36;
  uint uVar37;
  uint uVar38;
  uint uVar39;
  uint uVar40;
  int in_GS_OFFSET;
  uint local_8c;
  uint local_88;
  int local_84;
  uint local_80;
  int local_7c;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  uVar37 = 0x100000;
  uVar5 = param_5 & 0xfffff;
  if ((param_5 & 0xfff00000) == 0) {
    uVar30 = uVar5 << 1 | param_4 >> 0x1f;
    local_80 = param_4 * 2 + 1;
    iVar21 = -0x432;
    local_7c = -0x433;
    uVar33 = uVar5;
  }
  else {
    uVar32 = param_5 >> 0x14;
    uVar33 = uVar5 | 0x100000;
    iVar21 = uVar32 - 0x433;
    uVar30 = uVar33 << 1 | param_4 >> 0x1f;
    local_7c = uVar32 - 0x434;
    local_80 = param_4 * 2 + 1;
    if (((param_5 & 0xffe00000) != 0) && (uVar5 == 0 && param_4 == 0)) {
      iVar15 = uVar32 - 0x435;
      local_84 = 0x3fffff;
      param_4 = 0;
      local_8c = 0xffffffff;
      goto LAB_000268f0;
    }
  }
  local_8c = param_4 * 2 - 1;
  local_84 = (uVar30 - 1) + (uint)(param_4 * 2 != 0);
  iVar15 = local_7c;
  uVar37 = uVar33;
LAB_000268f0:
  do {
    uVar30 = uVar30 << 1 | local_80 >> 0x1f;
    local_80 = local_80 * 2;
    local_7c = local_7c + -1;
  } while (-1 < (int)uVar30);
  do {
    uVar37 = uVar37 << 1 | param_4 >> 0x1f;
    param_4 = param_4 * 2;
    iVar21 = iVar21 + -1;
  } while (-1 < (int)uVar37);
  bVar13 = (byte)(iVar15 - local_7c);
  bVar3 = bVar13 & 0x1f;
  uVar32 = local_8c << (bVar13 & 0x1f);
  uVar33 = uVar32;
  uVar5 = local_84 << bVar3 | local_8c >> 0x20 - bVar3;
  if ((iVar15 - local_7c & 0x20U) != 0) {
    uVar33 = 0;
    uVar5 = uVar32;
  }
  iVar6 = -0x3d - local_7c;
  iVar16 = iVar6 * 0x13441;
  iVar15 = iVar16 + 0x3ffff;
  if (-1 < iVar16) {
    iVar15 = iVar16;
  }
  sVar14 = (short)(iVar15 >> 0x12);
  sVar4 = sVar14 + (ushort)(0 < iVar6) + 0x133;
  sVar14 = (ushort)(0 < iVar6) + sVar14 + 0x13a;
  if (-1 < sVar4) {
    sVar14 = sVar4;
  }
  uVar34 = (int)sVar14 & 0xfffffff8;
  uVar32 = *(uint *)(&UNK_00015838 + uVar34 * 2);
  uVar22 = (uint)((ulonglong)uVar32 * (ulonglong)param_4 >> 0x20);
  uVar2 = *(uint *)(&UNK_0001583c + uVar34 * 2);
  uVar23 = (uint)((ulonglong)uVar2 * (ulonglong)param_4 >> 0x20);
  uVar7 = (uint)((ulonglong)uVar2 * (ulonglong)param_4);
  uVar24 = (uint)((ulonglong)uVar32 * (ulonglong)uVar37 >> 0x20);
  uVar8 = (uint)((ulonglong)uVar32 * (ulonglong)uVar37);
  uVar9 = (uint)((ulonglong)uVar2 * (ulonglong)uVar37);
  uVar17 = uVar7 + uVar22;
  uVar10 = (uint)CARRY4(uVar7,uVar22) + (uint)CARRY4(uVar17,uVar8);
  uVar35 = uVar9 + uVar24;
  uVar36 = uVar35 + uVar23;
  uVar7 = (uint)(0x7fffffff < uVar17 + uVar8);
  uVar8 = uVar36 + uVar10;
  uVar25 = (uint)((ulonglong)uVar32 * (ulonglong)uVar33 >> 0x20);
  uVar26 = (uint)((ulonglong)uVar2 * (ulonglong)uVar33 >> 0x20);
  uVar33 = (uint)((ulonglong)uVar2 * (ulonglong)uVar33);
  uVar27 = (uint)((ulonglong)uVar32 * (ulonglong)uVar5 >> 0x20);
  uVar17 = (uint)((ulonglong)uVar32 * (ulonglong)uVar5);
  uVar11 = (uint)((ulonglong)uVar2 * (ulonglong)uVar5);
  uVar22 = uVar33 + uVar25;
  uVar12 = uVar22 + uVar17;
  uVar18 = (uint)CARRY4(uVar33,uVar25) + (uint)CARRY4(uVar22,uVar17);
  uVar17 = (uint)((ulonglong)uVar32 * (ulonglong)local_80 >> 0x20);
  uVar28 = (uint)((ulonglong)uVar2 * (ulonglong)local_80 >> 0x20);
  uVar33 = (uint)((ulonglong)uVar2 * (ulonglong)local_80);
  uVar29 = (uint)((ulonglong)uVar32 * (ulonglong)uVar30 >> 0x20);
  uVar32 = (uint)((ulonglong)uVar32 * (ulonglong)uVar30);
  uVar25 = (uint)((ulonglong)uVar2 * (ulonglong)uVar30);
  uVar22 = uVar33 + uVar17;
  uVar31 = (uint)CARRY4(uVar33,uVar17) + (uint)CARRY4(uVar22,uVar32);
  uVar38 = uVar11 + uVar27;
  uVar39 = uVar38 + uVar26;
  uVar33 = (uint)(0x7fffffff < uVar12);
  uVar17 = uVar39 + uVar18;
  uVar40 = uVar17 + uVar33;
  uVar19 = uVar25 + uVar29;
  uVar20 = uVar19 + uVar28;
  uVar32 = (uint)(0x7fffffff < uVar22 + uVar32);
  uVar22 = uVar20 + uVar31;
  iVar16 = uVar22 + uVar32;
  iVar15 = *(int *)(&UNK_00015840 + uVar34 * 2);
  iVar6 = local_7c + iVar15 + 0x40;
  *param_3 = -*(int *)(&UNK_00015844 + uVar34 * 2);
  FUN_00026db0(param_1,param_2,param_3,
               CONCAT44((int)((ulonglong)uVar2 * (ulonglong)uVar5 >> 0x20) +
                        (uint)CARRY4(uVar11,uVar27) + (uint)CARRY4(uVar38,uVar26) +
                        (uint)(CARRY4(uVar39,uVar18) || CARRY4(uVar17,uVar33)) +
                        (uint)(0xfffffffe < uVar40),uVar40 + 1),iVar6,
               CONCAT44((int)((ulonglong)uVar2 * (ulonglong)uVar37 >> 0x20) +
                        (uint)CARRY4(uVar9,uVar24) + (uint)CARRY4(uVar35,uVar23) +
                        (uint)(CARRY4(uVar36,uVar10) || CARRY4(uVar8,uVar7)),uVar8 + uVar7),
               iVar15 + 0x40 + iVar21,
               CONCAT44((int)((ulonglong)uVar2 * (ulonglong)uVar30 >> 0x20) +
                        (uint)CARRY4(uVar25,uVar29) + (uint)CARRY4(uVar19,uVar28) +
                        (uint)(CARRY4(uVar20,uVar31) || CARRY4(uVar22,uVar32)) + -1 +
                        (uint)(iVar16 != 0),iVar16 + -1),iVar6,uVar12 + 0x80000000);
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00026c00 @ 00026c00

int FUN_00026c00(undefined2 *param_1,size_t param_2,size_t param_3,int param_4,int param_5)

{
  int iVar1;
  char cVar2;
  byte bVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = param_3 + param_2;
  if (((int)param_3 < 0) || (param_5 < iVar5)) {
    if ((iVar5 < 1) || (param_5 < iVar5)) {
      if ((param_4 < iVar5) && (iVar5 < 1)) {
        memmove((void *)((2 - iVar5) + (int)param_1),param_1,param_2);
        *param_1 = 0x2e30;
        memset(param_1 + 1,0x30,-iVar5);
        iVar5 = (2 - iVar5) + param_2 + (int)param_1;
      }
      else {
        iVar1 = 1;
        if (param_2 != 1) {
          memmove(param_1 + 1,(void *)((int)param_1 + 1),param_2 - 1);
          *(undefined1 *)((int)param_1 + 1) = 0x2e;
          iVar1 = param_2 + 1;
        }
        uVar4 = 1 - iVar5;
        if (0 < iVar5) {
          uVar4 = iVar5 - 1;
        }
        *(undefined1 *)((int)param_1 + iVar1) = 0x65;
        *(char *)((int)param_1 + iVar1 + 1) = (iVar5 < 1) * '\x02' + '+';
        if (uVar4 < 10) {
          *(undefined1 *)((int)param_1 + iVar1 + 2) = 0x30;
          bVar3 = (char)uVar4 + 0x30;
        }
        else {
          if (99 < uVar4) {
            *(char *)((int)param_1 + iVar1 + 2) = (char)(uVar4 / 100) + '0';
            bVar3 = (byte)((uVar4 % 100) / 10);
            *(byte *)((int)param_1 + iVar1 + 3) = bVar3 | 0x30;
            *(byte *)((int)param_1 + iVar1 + 4) = (char)(uVar4 % 100) + bVar3 * -10 | 0x30;
            return (int)param_1 + iVar1 + 5;
          }
          cVar2 = (char)((uVar4 & 0xff) / 10);
          *(char *)((int)param_1 + iVar1 + 2) = cVar2 + '0';
          bVar3 = (char)uVar4 + cVar2 * -10 | 0x30;
        }
        *(byte *)((int)param_1 + iVar1 + 3) = bVar3;
        iVar5 = (int)param_1 + iVar1 + 4;
      }
    }
    else {
      memmove((void *)((int)param_1 + iVar5 + 1),(void *)((int)param_1 + iVar5),-param_3);
      *(undefined1 *)((int)param_1 + iVar5) = 0x2e;
      iVar5 = (int)param_1 + param_2 + 1;
    }
  }
  else {
    memset((void *)(param_2 + (int)param_1),0x30,param_3);
    *(undefined2 *)((int)param_1 + iVar5) = 0x302e;
    iVar5 = (int)param_1 + iVar5 + 2;
  }
  return iVar5;
}


// ==== FUN_00026db0 @ 00026db0

int * FUN_00026db0(int param_1,int *param_2,int *param_3,uint param_4,int param_5,undefined4 param_6
                  ,uint param_7,int param_8,undefined4 param_9,uint param_10,uint param_11,
                  char param_12)

{
  char *pcVar1;
  int iVar2;
  ulonglong uVar3;
  byte bVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint *puVar9;
  int *piVar10;
  int *piVar11;
  uint uVar12;
  int *piVar13;
  uint uVar14;
  int *piVar15;
  uint uVar16;
  int *piVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  int iVar22;
  bool bVar23;
  int *local_5c;
  int *local_58;
  uint local_54;
  int local_50;
  uint *local_28;
  
  uVar6 = param_10 - param_4;
  local_58 = (int *)((param_11 - param_5) - (uint)(param_10 < param_4));
  local_54 = param_10 - param_7;
  local_5c = (int *)((param_11 - param_8) - (uint)(param_10 < param_7));
  bVar4 = -param_12;
  piVar17 = (int *)(0 << (bVar4 & 0x1f) | 1U >> 0x20 - (bVar4 & 0x1f));
  piVar10 = (int *)(1 << (bVar4 & 0x1f));
  local_28 = (uint *)(param_10 >> (bVar4 & 0x1f) | param_11 << 0x20 - (bVar4 & 0x1f));
  piVar11 = piVar10;
  if ((bVar4 & 0x20) != 0) {
    piVar11 = (int *)0x0;
    piVar17 = piVar10;
    local_28 = (uint *)(param_11 >> (bVar4 & 0x1f));
  }
  uVar18 = (int)piVar17 + ((piVar11 != (int *)0x0) - 1);
  if (local_28 < (uint *)0x3b9aca00) {
    if (local_28 < (uint *)0x5f5e100) {
      if (local_28 < (uint *)0x989680) {
        if (local_28 < (uint *)0xf4240) {
          if (local_28 < &UINT_000186a0) {
            if (local_28 < (uint *)0x2710) {
              if (local_28 < (uint *)0x3e8) {
                if (local_28 < (uint *)0x64) {
                  puVar9 = (uint *)((uint)((uint *)0x9 < local_28) * 9 + 1);
                  iVar22 = ((uint *)0x9 < local_28) + 1;
                }
                else {
                  iVar22 = 3;
                  puVar9 = (uint *)0x64;
                }
              }
              else {
                iVar22 = 4;
                puVar9 = (uint *)0x3e8;
              }
            }
            else {
              iVar22 = 5;
              puVar9 = (uint *)0x2710;
            }
          }
          else {
            iVar22 = 6;
            puVar9 = &UINT_000186a0;
          }
        }
        else {
          iVar22 = 7;
          puVar9 = (uint *)0xf4240;
        }
      }
      else {
        iVar22 = 8;
        puVar9 = (uint *)0x989680;
      }
    }
    else {
      iVar22 = 9;
      puVar9 = (uint *)0x5f5e100;
    }
  }
  else {
    iVar22 = 10;
    puVar9 = (uint *)0x3b9aca00;
  }
  piVar10 = (int *)(param_11 & uVar18);
  param_10 = param_10 & (int)piVar11 - 1U;
  do {
    while( true ) {
      if (iVar22 < 1) {
        local_50 = 0;
        do {
          uVar7 = (uint)((ulonglong)param_10 * 10);
          uVar14 = (int)((ulonglong)param_10 * 10 >> 0x20) + (int)piVar10 * 10;
          bVar5 = (byte)(uVar14 >> (bVar4 & 0x1f));
          if ((bVar4 & 0x20) == 0) {
            bVar5 = (byte)(uVar7 >> (bVar4 & 0x1f)) | (byte)(uVar14 << 0x20 - (bVar4 & 0x1f));
          }
          iVar22 = *param_2;
          *param_2 = iVar22 + 1;
          *(byte *)(param_1 + iVar22) = bVar5 + 0x30;
          uVar3 = (ulonglong)uVar6;
          uVar6 = (uint)(uVar3 * 10);
          local_58 = (int *)((int)(uVar3 * 10 >> 0x20) + (int)local_58 * 10);
          uVar3 = (ulonglong)local_54;
          local_54 = (uint)(uVar3 * 10);
          local_5c = (int *)((int)(uVar3 * 10 >> 0x20) + (int)local_5c * 10);
          piVar10 = (int *)(uVar14 & uVar18);
          param_10 = uVar7 & (int)piVar11 - 1U;
          local_50 = local_50 + -1;
        } while (local_58 < piVar10 ||
                 (uint)((int)local_58 - (int)piVar10) < (uint)(uVar6 < param_10));
        *param_3 = *param_3 + local_50;
        piVar15 = (int *)((int)local_58 + (-(uint)(uVar6 < param_10) - (int)piVar10));
        if ((piVar10 < local_5c ||
             (uint)((int)piVar10 - (int)local_5c) < (uint)(param_10 < local_54)) &&
           (uVar18 = (uint)((int *)(uVar6 - param_10) < piVar11), bVar23 = piVar17 <= piVar15,
           uVar14 = (int)piVar15 - (int)piVar17, piVar15 = (int *)(uVar14 - uVar18),
           bVar23 && uVar18 <= uVar14)) {
          iVar22 = *param_2;
          while( true ) {
            uVar18 = param_10 + (int)piVar11;
            piVar13 = (int *)((int)piVar10 + (int)piVar17 + (uint)CARRY4(param_10,(uint)piVar11));
            if ((local_5c <= piVar13 &&
                 (uint)(uVar18 < local_54) <= (uint)((int)piVar13 - (int)local_5c)) &&
               (uVar20 = (int)local_5c + (-(uint)(local_54 < param_10) - (int)piVar10),
               uVar19 = (int)piVar13 + (-(uint)(uVar18 < local_54) - (int)local_5c),
               uVar14 = (uint)(uVar18 - local_54 < local_54 - param_10), uVar7 = uVar19 - uVar20,
               piVar15 = (int *)(uVar7 - uVar14), uVar20 <= uVar19 && uVar14 <= uVar7)) break;
            pcVar1 = (char *)(param_1 + -1 + iVar22);
            *pcVar1 = *pcVar1 + -1;
            piVar8 = (int *)((int)local_58 + (-(uint)(uVar6 < uVar18) - (int)piVar13));
            piVar15 = (int *)(((int)piVar13 - (int)local_5c) - (uint)(uVar18 < local_54));
            if (local_5c <= piVar13 &&
                (uint)(uVar18 < local_54) <= (uint)((int)piVar13 - (int)local_5c)) {
              return piVar15;
            }
            piVar10 = piVar13;
            param_10 = uVar18;
            if (piVar8 < piVar17 ||
                (uint)((int)piVar8 - (int)piVar17) < (uint)((int *)(uVar6 - uVar18) < piVar11)) {
              return piVar15;
            }
          }
        }
        return piVar15;
      }
      uVar7 = (uint)local_28 / (uint)puVar9;
      local_28 = (uint *)((uint)local_28 % (uint)puVar9);
      uVar19 = (int)local_28 << (bVar4 & 0x1f);
      iVar22 = iVar22 + -1;
      bVar23 = (bVar4 & 0x20) != 0;
      uVar14 = 0 << (bVar4 & 0x1f) | (uint)local_28 >> 0x20 - (bVar4 & 0x1f);
      if (bVar23) {
        uVar14 = uVar19;
      }
      iVar2 = *param_2;
      if (bVar23) {
        uVar19 = 0;
      }
      *param_2 = iVar2 + 1;
      uVar20 = uVar19 + param_10;
      piVar15 = (int *)((int)piVar10 + CARRY4(uVar19,param_10) + uVar14);
      *(char *)(param_1 + iVar2) = (char)uVar7 + '0';
      if (piVar15 <= local_58 && (uint)(uVar6 < uVar20) <= (uint)((int)local_58 - (int)piVar15))
      break;
      piVar13 = (int *)((int)puVar9 * -0x33333333);
      puVar9 = (uint *)((uint)puVar9 / 10);
      if (piVar15 <= local_58 && (uint)(uVar6 < uVar20) <= (uint)((int)local_58 - (int)piVar15)) {
        return piVar13;
      }
    }
    *param_3 = *param_3 + iVar22;
    uVar19 = (int)puVar9 << (bVar4 & 0x1f);
    uVar7 = uVar19;
    uVar14 = 0 << (bVar4 & 0x1f) | (uint)puVar9 >> 0x20 - (bVar4 & 0x1f);
    if ((bVar4 & 0x20) != 0) {
      uVar7 = 0;
      uVar14 = uVar19;
    }
    uVar19 = (int)local_58 + (-(uint)(uVar6 < uVar20) - (int)piVar15);
    if (local_5c <= piVar15 && (uint)(uVar20 < local_54) <= (uint)((int)piVar15 - (int)local_5c)) {
      return param_2;
    }
    if (uVar19 < uVar14 || uVar19 - uVar14 < (uint)(uVar6 - uVar20 < uVar7)) {
      return param_2;
    }
    iVar2 = *param_2;
    piVar13 = piVar15;
    uVar19 = uVar20;
    while( true ) {
      uVar21 = uVar19 + uVar7;
      piVar8 = (int *)((int)piVar13 + CARRY4(uVar19,uVar7) + uVar14);
      if ((local_5c <= piVar8 && (uint)(uVar21 < local_54) <= (uint)((int)piVar8 - (int)local_5c))
         && (uVar16 = (int)local_5c + (-(uint)(local_54 < uVar19) - (int)piVar13),
            uVar12 = (int)piVar8 + (-(uint)(uVar21 < local_54) - (int)local_5c),
            uVar16 <= uVar12 && (uint)(uVar21 - local_54 < local_54 - uVar19) <= uVar12 - uVar16))
      break;
      pcVar1 = (char *)(param_1 + -1 + iVar2);
      *pcVar1 = *pcVar1 + -1;
      uVar12 = (int)local_58 + (-(uint)(uVar6 < uVar21) - (int)piVar8);
      if ((local_5c <= piVar8 && (uint)(uVar21 < local_54) <= (uint)((int)piVar8 - (int)local_5c))
         || (piVar13 = piVar8, uVar19 = uVar21,
            uVar12 < uVar14 || uVar12 - uVar14 < (uint)(uVar6 - uVar21 < uVar7))) break;
    }
    if (piVar15 <= local_58 && (uint)(uVar6 < uVar20) <= (uint)((int)local_58 - (int)piVar15)) {
      return piVar8;
    }
  } while( true );
}


// ==== FUN_00027200 @ 00027200

void FUN_00027200(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  void *__src;
  uint uVar12;
  void *__dest;
  size_t __n;
  
  puVar1 = (undefined4 *)param_1[1];
  if (puVar1 < (undefined4 *)param_1[2]) {
    uVar2 = param_2[0x10];
    uVar3 = param_2[0x11];
    uVar4 = param_2[0x12];
    puVar1[0xf] = param_2[0xf];
    puVar1[0x10] = uVar2;
    puVar1[0x11] = uVar3;
    puVar1[0x12] = uVar4;
    uVar2 = param_2[0xd];
    uVar3 = param_2[0xe];
    uVar4 = param_2[0xf];
    puVar1[0xc] = param_2[0xc];
    puVar1[0xd] = uVar2;
    puVar1[0xe] = uVar3;
    puVar1[0xf] = uVar4;
    uVar2 = param_2[9];
    uVar3 = param_2[10];
    uVar4 = param_2[0xb];
    puVar1[8] = param_2[8];
    puVar1[9] = uVar2;
    puVar1[10] = uVar3;
    puVar1[0xb] = uVar4;
    uVar2 = *param_2;
    uVar3 = param_2[1];
    uVar4 = param_2[2];
    uVar5 = param_2[3];
    uVar6 = param_2[5];
    uVar7 = param_2[6];
    uVar8 = param_2[7];
    puVar1[4] = param_2[4];
    puVar1[5] = uVar6;
    puVar1[6] = uVar7;
    puVar1[7] = uVar8;
    *puVar1 = uVar2;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    param_1[1] = puVar1 + 0x13;
  }
  else {
    __src = (void *)*param_1;
    __n = (int)puVar1 - (int)__src;
    uVar10 = ((int)__n >> 2) * 0x286bca1b + 1;
    if (0x35e50d7 < uVar10) {
      FUN_0002ba50(param_1);
LAB_00027355:
                    /* WARNING: Subroutine does not return */
      FUN_000231e0("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
    }
    iVar9 = (int)param_1[2] - (int)__src >> 2;
    uVar12 = iVar9 * 0x50d79436;
    if (uVar12 < uVar10) {
      uVar12 = uVar10;
    }
    uVar10 = 0x35e50d7;
    if ((uint)(iVar9 * 0x286bca1b) < 0x1af286b) {
      uVar10 = uVar12;
    }
    if (uVar10 == 0) {
      iVar9 = 0;
    }
    else {
      if (0x35e50d7 < uVar10) goto LAB_00027355;
      iVar9 = FUN_00029f70(uVar10 * 0x4c);
    }
    iVar11 = ((int)__n >> 2) * 4;
    uVar2 = param_2[0x10];
    uVar3 = param_2[0x11];
    uVar4 = param_2[0x12];
    puVar1 = (undefined4 *)(iVar9 + 0x3c + iVar11);
    *puVar1 = param_2[0xf];
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    uVar2 = param_2[0xd];
    uVar3 = param_2[0xe];
    uVar4 = param_2[0xf];
    puVar1 = (undefined4 *)(iVar9 + 0x30 + iVar11);
    *puVar1 = param_2[0xc];
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    uVar2 = param_2[9];
    uVar3 = param_2[10];
    uVar4 = param_2[0xb];
    puVar1 = (undefined4 *)(iVar9 + 0x20 + iVar11);
    *puVar1 = param_2[8];
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    uVar2 = *param_2;
    uVar3 = param_2[1];
    uVar4 = param_2[2];
    uVar5 = param_2[3];
    uVar6 = param_2[5];
    uVar7 = param_2[6];
    uVar8 = param_2[7];
    puVar1 = (undefined4 *)(iVar9 + 0x10 + iVar11);
    *puVar1 = param_2[4];
    puVar1[1] = uVar6;
    puVar1[2] = uVar7;
    puVar1[3] = uVar8;
    puVar1 = (undefined4 *)(iVar9 + iVar11);
    *puVar1 = uVar2;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    __dest = (void *)((iVar9 + iVar11) - __n);
    if (0 < (int)__n) {
      memcpy(__dest,__src,__n);
      __src = (void *)*param_1;
    }
    *param_1 = __dest;
    param_1[1] = iVar9 + iVar11 + 0x4c;
    param_1[2] = uVar10 * 0x4c + iVar9;
    if (__src != (void *)0x0) {
      FUN_0002a000(__src);
    }
  }
  return;
}


// ==== _INIT_0 @ 00027370

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _INIT_0(void)

{
  DAT_00050880 = 1000;
  _DAT_00050884 = 0;
  _DAT_00050888 = 0;
  DAT_0005088c = 0;
  DAT_00050890 = 0;
  DAT_00050894 = 0;
                    /* try { // try from 000273a5 to 000273b0 has its CatchHandler @ 000273f4 */
  DAT_0005088c = FUN_00029f70(76000);
  DAT_00050894 = DAT_0005088c + 76000;
  DAT_00050890 = DAT_0005088c;
  __cxa_atexit(&LAB_00020c00,&DAT_00050880,&PTR_LOOP_0004b1b0);
  return;
}


// ==== FUN_00027420 @ 00027420

void FUN_00027420(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_000274e0(param_1,param_2,param_3,param_4);
  return;
}


// ==== FUN_00027450 @ 00027450

void FUN_00027450(undefined4 param_1)

{
  FUN_00027620(param_1);
  return;
}


// ==== FUN_00027480 @ 00027480

void FUN_00027480(void)

{
  FUN_00027800();
  return;
}


// ==== FUN_000274b0 @ 000274b0

void FUN_000274b0(undefined4 param_1)

{
  FUN_00027e60(param_1);
  return;
}


// ==== FUN_000274e0 @ 000274e0

undefined4 FUN_000274e0(char *param_1,char *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *__ptr;
  char *pcVar2;
  undefined4 uVar3;
  int in_GS_OFFSET;
  uchar *local_28;
  ulong uStack_24;
  ulong uStack_20;
  reg_syntax_t rStack_1c;
  char *local_18;
  
  local_18 = *(char **)(in_GS_OFFSET + 0x14);
  uVar3 = 0x3ea;
  if (((param_1 != (char *)0x0) && (param_2 != (char *)0x0)) && (param_3 != 0)) {
    if (DAT_000508a8 == 0) {
      iVar1 = regcomp((regex_t *)&local_28,param_1,4);
      if (iVar1 == 0) {
        __ptr = malloc(0x24);
        uVar3 = 0x3eb;
        if (__ptr != (undefined4 *)0x0) {
          pcVar2 = strdup(param_2);
          __ptr[4] = pcVar2;
          if (pcVar2 == (char *)0x0) {
            free(__ptr);
          }
          else {
            *__ptr = local_28;
            __ptr[1] = uStack_24;
            __ptr[2] = uStack_20;
            __ptr[3] = rStack_1c;
            __ptr[5] = param_3;
            __ptr[6] = param_4;
            pthread_mutex_lock((pthread_mutex_t *)&DAT_000508ac);
            __ptr[7] = 0;
            __ptr[8] = PTR_DAT_00050844;
            *(undefined4 **)PTR_DAT_00050844 = __ptr;
            PTR_DAT_00050844 = (undefined *)(__ptr + 7);
            pthread_mutex_unlock((pthread_mutex_t *)&DAT_000508ac);
            uVar3 = 0;
          }
        }
      }
    }
    else if (DAT_00050854 < 7) {
      __android_log_print(6,"xhook","do not register hook after refresh(): %s, %s",param_1,param_2);
    }
  }
  if (*(char **)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar3;
}


// ==== FUN_00027620 @ 00027620

undefined4 FUN_00027620(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  pthread_mutex_t *__mutex;
  int in_GS_OFFSET;
  _union_1051 local_28;
  undefined4 local_24;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if (DAT_000508a8 == 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_000508ac);
    if (DAT_000508a8 == 0) {
      DAT_000508a8 = 1;
      if (DAT_00050854 < 5) {
        uVar1 = FUN_00029df0();
        __android_log_print(4,"xhook",&DAT_0001520a,uVar1);
      }
      if (DAT_00050850 != 0) {
        local_24 = 0;
        local_28.sa_handler = (__sighandler_t)&LAB_00027e90;
        iVar2 = sigaction(0xb,(sigaction *)&local_28,(sigaction *)&DAT_000508d4);
        if (iVar2 != 0) goto LAB_000276ef;
      }
      DAT_000508b0 = 1;
    }
LAB_000276ef:
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_000508ac);
  }
  uVar1 = 0x3e9;
  if (DAT_000508b0 != 0) {
    if (param_1 == 0) {
      __mutex = (pthread_mutex_t *)&DAT_000508c0;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_000508c0);
      FUN_00027fe0();
    }
    else {
      if (DAT_000508cc == 0) {
        pthread_mutex_lock((pthread_mutex_t *)&DAT_000508ac);
        if (DAT_000508cc == 0) {
          DAT_000508cc = 1;
          DAT_000508c4 = 1;
          iVar2 = pthread_create(&DAT_000508c8,(pthread_attr_t *)0x0,
                                 (__start_routine *)&LAB_00027ee0,(void *)0x0);
          if (iVar2 == 0) {
            DAT_000508b4 = 1;
          }
          else {
            DAT_000508c4 = 0;
          }
        }
        pthread_mutex_unlock((pthread_mutex_t *)&DAT_000508ac);
      }
      if (DAT_000508b4 == 0) goto LAB_000277df;
      __mutex = (pthread_mutex_t *)&DAT_000508ac;
      pthread_mutex_lock((pthread_mutex_t *)&DAT_000508ac);
      DAT_000508b8 = 1;
      pthread_cond_signal((pthread_cond_t *)&DAT_000508bc);
    }
    pthread_mutex_unlock(__mutex);
    uVar1 = 0;
  }
LAB_000277df:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar1;
}


// ==== FUN_00027800 @ 00027800

void FUN_00027800(void)

{
  regex_t *prVar1;
  regex_t *prVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 *__ptr;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  if (DAT_000508b4 != 0) {
    pthread_mutex_lock((pthread_mutex_t *)&DAT_000508ac);
    DAT_000508c4 = 0;
    pthread_cond_signal((pthread_cond_t *)&DAT_000508bc);
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_000508ac);
    pthread_join(DAT_000508c8,(void **)0x0);
    DAT_000508b4 = 0;
  }
  DAT_000508cc = 0;
  if (DAT_000508b0 != 0) {
    if (DAT_00050850 != 0) {
      sigaction(0xb,(sigaction *)&DAT_000508d4,(sigaction *)0x0);
    }
    DAT_000508b0 = 0;
  }
  DAT_000508a8 = 0;
  pthread_mutex_lock((pthread_mutex_t *)&DAT_000508ac);
  pthread_mutex_lock((pthread_mutex_t *)&DAT_000508c0);
  piVar5 = &DAT_000508d0;
  puVar4 = (undefined4 *)0x0;
  do {
    __ptr = puVar4;
    puVar4 = (undefined4 *)*piVar5;
    piVar5 = puVar4 + 0x1b;
  } while (puVar4 != (undefined4 *)0x0);
  do {
    if (__ptr == (undefined4 *)0x0) {
      prVar2 = DAT_00050840;
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = *(regex_t **)&prVar2->field_0x1c;
        piVar5 = (int *)prVar2[1].buffer;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_00050844 = (undefined *)piVar5;
        }
        else {
          prVar1[1].buffer = (uchar *)piVar5;
          piVar5 = (int *)prVar2[1].buffer;
        }
        *piVar5 = (int)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      prVar2 = DAT_00050848;
      while (prVar2 != (regex_t *)0x0) {
        prVar1 = (regex_t *)prVar2->translate;
        piVar5 = (int *)prVar2->re_nsub;
        if (prVar1 == (regex_t *)0x0) {
          PTR_DAT_0005084c = (undefined *)piVar5;
        }
        else {
          prVar1->re_nsub = (size_t)piVar5;
          piVar5 = (int *)prVar2->re_nsub;
        }
        *piVar5 = (int)prVar1;
        regfree(prVar2);
        free(prVar2->fastmap);
        free(prVar2);
        prVar2 = prVar1;
      }
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_000508c0);
      pthread_mutex_unlock((pthread_mutex_t *)&DAT_000508ac);
      return;
    }
    puVar4 = (undefined4 *)__ptr[0x1c];
    if ((undefined4 *)__ptr[0x1c] == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)__ptr[0x1d];
      puVar7 = (undefined4 *)0x0;
      if (puVar4 != (undefined4 *)0x0) {
        if ((undefined4 *)puVar4[0x1b] == __ptr) {
LAB_00027992:
          puVar7 = puVar4;
        }
        else {
          puVar3 = puVar4;
          puVar6 = __ptr;
          do {
            puVar4 = puVar3;
            if (puVar6 != (undefined4 *)puVar4[0x1c]) goto LAB_00027992;
            puVar3 = (undefined4 *)puVar4[0x1d];
            puVar6 = puVar4;
          } while ((undefined4 *)puVar4[0x1d] != (undefined4 *)0x0);
        }
      }
    }
    else {
      do {
        puVar7 = puVar4;
        puVar4 = (undefined4 *)puVar7[0x1b];
      } while ((undefined4 *)puVar7[0x1b] != (undefined4 *)0x0);
    }
    FUN_00027a40();
    if ((void *)*__ptr != (void *)0x0) {
      free((void *)*__ptr);
    }
    free(__ptr);
    __ptr = puVar7;
  } while( true );
}


// ==== FUN_00027a40 @ 00027a40

void FUN_00027a40(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int in_ECX;
  int iVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  
  iVar5 = *(int *)(in_ECX + 0x6c);
  iVar4 = *(int *)(in_ECX + 0x70);
  if (iVar5 == 0) {
    iVar9 = *(int *)(in_ECX + 0x74);
    iVar8 = *(int *)(in_ECX + 0x78);
    if (iVar4 == 0) {
      iVar4 = 0;
      goto joined_r0x00027b47;
    }
    *(int *)(iVar4 + 0x74) = iVar9;
    if (iVar9 != 0) goto LAB_00027b2f;
LAB_00027b49:
    iVar9 = 0;
    piVar7 = &DAT_000508d0;
  }
  else {
    if (iVar4 != 0) {
      do {
        iVar5 = iVar4;
        iVar4 = *(int *)(iVar5 + 0x6c);
      } while (*(int *)(iVar5 + 0x6c) != 0);
      iVar4 = *(int *)(iVar5 + 0x70);
      iVar9 = *(int *)(iVar5 + 0x74);
      iVar8 = *(int *)(iVar5 + 0x78);
      if (iVar4 != 0) {
        *(int *)(iVar4 + 0x74) = iVar9;
      }
      piVar7 = &DAT_000508d0;
      if (iVar9 != 0) {
        piVar7 = (int *)(iVar9 + 0x70);
        if (*(int *)(iVar9 + 0x6c) == iVar5) {
          piVar7 = (int *)(iVar9 + 0x6c);
        }
      }
      *piVar7 = iVar4;
      if (*(int *)(iVar5 + 0x74) == in_ECX) {
        iVar9 = iVar5;
      }
      uVar1 = *(undefined4 *)(in_ECX + 0x70);
      uVar2 = *(undefined4 *)(in_ECX + 0x74);
      uVar3 = *(undefined4 *)(in_ECX + 0x78);
      *(undefined4 *)(iVar5 + 0x6c) = *(undefined4 *)(in_ECX + 0x6c);
      *(undefined4 *)(iVar5 + 0x70) = uVar1;
      *(undefined4 *)(iVar5 + 0x74) = uVar2;
      *(undefined4 *)(iVar5 + 0x78) = uVar3;
      iVar6 = *(int *)(in_ECX + 0x74);
      piVar7 = &DAT_000508d0;
      if (iVar6 != 0) {
        piVar7 = (int *)(iVar6 + 0x70);
        if (*(int *)(iVar6 + 0x6c) == in_ECX) {
          piVar7 = (int *)(iVar6 + 0x6c);
        }
      }
      *piVar7 = iVar5;
      *(int *)(*(int *)(in_ECX + 0x6c) + 0x74) = iVar5;
      if (*(int *)(in_ECX + 0x70) != 0) {
        *(int *)(*(int *)(in_ECX + 0x70) + 0x74) = iVar5;
      }
      goto LAB_00027b57;
    }
    iVar9 = *(int *)(in_ECX + 0x74);
    iVar8 = *(int *)(in_ECX + 0x78);
    *(int *)(iVar5 + 0x74) = iVar9;
    iVar4 = iVar5;
joined_r0x00027b47:
    if (iVar9 == 0) goto LAB_00027b49;
LAB_00027b2f:
    piVar7 = (int *)(iVar9 + 0x70);
    if (*(int *)(iVar9 + 0x6c) == in_ECX) {
      piVar7 = (int *)(iVar9 + 0x6c);
    }
  }
  *piVar7 = iVar4;
LAB_00027b57:
  if (iVar8 != 0) {
    return;
  }
  iVar5 = DAT_000508d0;
  do {
    if (iVar4 == 0) {
      if (iVar5 == 0) {
        return;
      }
    }
    else if ((*(int *)(iVar4 + 0x78) != 0) || (iVar4 == iVar5)) goto LAB_00027e47;
    iVar8 = *(int *)(iVar9 + 0x6c);
    if (iVar8 == iVar4) {
      iVar4 = *(int *)(iVar9 + 0x70);
      iVar6 = iVar4;
      if (*(int *)(iVar4 + 0x78) == 1) {
        *(undefined4 *)(iVar4 + 0x78) = 0;
        *(undefined4 *)(iVar9 + 0x78) = 1;
        iVar6 = *(int *)(iVar4 + 0x6c);
        *(int *)(iVar9 + 0x70) = iVar6;
        if (iVar6 != 0) {
          *(int *)(iVar6 + 0x74) = iVar9;
        }
        iVar8 = *(int *)(iVar9 + 0x74);
        *(int *)(iVar4 + 0x74) = iVar8;
        if (iVar8 == 0) {
          iVar5 = iVar4;
          DAT_000508d0 = iVar4;
        }
        else {
          iVar8 = *(int *)(iVar9 + 0x74);
          if (iVar9 == *(int *)(iVar8 + 0x6c)) {
            *(int *)(iVar8 + 0x6c) = iVar4;
          }
          else {
            *(int *)(iVar8 + 0x70) = iVar4;
            iVar6 = *(int *)(iVar9 + 0x70);
          }
        }
        *(int *)(iVar4 + 0x6c) = iVar9;
        *(int *)(iVar9 + 0x74) = iVar4;
      }
      iVar4 = *(int *)(iVar6 + 0x6c);
      if ((iVar4 == 0) || (*(int *)(iVar4 + 0x78) == 0)) {
        iVar8 = *(int *)(iVar6 + 0x70);
        if ((iVar8 == 0) || (*(int *)(iVar8 + 0x78) == 0)) goto LAB_00027b70;
LAB_00027cd8:
        *(undefined4 *)(iVar6 + 0x78) = *(undefined4 *)(iVar9 + 0x78);
        *(undefined4 *)(iVar9 + 0x78) = 0;
LAB_00027dfe:
        *(undefined4 *)(iVar8 + 0x78) = 0;
      }
      else {
        iVar8 = *(int *)(iVar6 + 0x70);
        if ((iVar8 != 0) && (*(int *)(iVar8 + 0x78) != 0)) goto LAB_00027cd8;
        *(undefined4 *)(iVar4 + 0x78) = 0;
        *(undefined4 *)(iVar6 + 0x78) = 1;
        iVar8 = *(int *)(iVar4 + 0x70);
        *(int *)(iVar6 + 0x6c) = iVar8;
        if (iVar8 != 0) {
          *(int *)(iVar8 + 0x74) = iVar6;
        }
        iVar8 = *(int *)(iVar6 + 0x74);
        *(int *)(iVar4 + 0x74) = iVar8;
        if (iVar8 == 0) {
          iVar5 = iVar4;
          piVar7 = &DAT_000508d0;
        }
        else {
          iVar8 = *(int *)(iVar6 + 0x74);
          piVar7 = (int *)(iVar8 + 0x70);
          if (iVar6 == *(int *)(iVar8 + 0x6c)) {
            piVar7 = (int *)(iVar8 + 0x6c);
          }
        }
        *piVar7 = iVar4;
        *(int *)(iVar4 + 0x70) = iVar6;
        *(int *)(iVar6 + 0x74) = iVar4;
        iVar6 = *(int *)(iVar9 + 0x70);
        iVar8 = *(int *)(iVar6 + 0x70);
        *(undefined4 *)(iVar6 + 0x78) = *(undefined4 *)(iVar9 + 0x78);
        *(undefined4 *)(iVar9 + 0x78) = 0;
        if (iVar8 != 0) goto LAB_00027dfe;
      }
      iVar4 = *(int *)(iVar6 + 0x6c);
      *(int *)(iVar9 + 0x70) = iVar4;
      if (iVar4 != 0) {
        *(int *)(iVar4 + 0x74) = iVar9;
      }
      iVar4 = *(int *)(iVar9 + 0x74);
      *(int *)(iVar6 + 0x74) = iVar4;
      if (iVar4 == 0) {
        iVar5 = iVar6;
        piVar7 = &DAT_000508d0;
      }
      else {
        iVar4 = *(int *)(iVar9 + 0x74);
        piVar7 = (int *)(iVar4 + 0x70);
        if (iVar9 == *(int *)(iVar4 + 0x6c)) {
          piVar7 = (int *)(iVar4 + 0x6c);
        }
      }
      *piVar7 = iVar6;
      *(int *)(iVar6 + 0x6c) = iVar9;
      goto LAB_00027e3e;
    }
    iVar6 = iVar8;
    if (*(int *)(iVar8 + 0x78) == 1) {
      *(undefined4 *)(iVar8 + 0x78) = 0;
      *(undefined4 *)(iVar9 + 0x78) = 1;
      iVar6 = *(int *)(iVar8 + 0x70);
      *(int *)(iVar9 + 0x6c) = iVar6;
      if (iVar6 != 0) {
        *(int *)(iVar6 + 0x74) = iVar9;
      }
      iVar4 = *(int *)(iVar9 + 0x74);
      *(int *)(iVar8 + 0x74) = iVar4;
      if (iVar4 == 0) {
        iVar5 = iVar8;
        DAT_000508d0 = iVar8;
      }
      else {
        iVar4 = *(int *)(iVar9 + 0x74);
        if (iVar9 == *(int *)(iVar4 + 0x6c)) {
          *(int *)(iVar4 + 0x6c) = iVar8;
          iVar6 = *(int *)(iVar9 + 0x6c);
        }
        else {
          *(int *)(iVar4 + 0x70) = iVar8;
        }
      }
      *(int *)(iVar8 + 0x70) = iVar9;
      *(int *)(iVar9 + 0x74) = iVar8;
    }
    iVar4 = *(int *)(iVar6 + 0x6c);
    if ((iVar4 != 0) && (*(int *)(iVar4 + 0x78) != 0)) goto LAB_00027cb9;
    iVar8 = *(int *)(iVar6 + 0x70);
    if ((iVar8 != 0) && (*(int *)(iVar8 + 0x78) != 0)) break;
LAB_00027b70:
    *(undefined4 *)(iVar6 + 0x78) = 1;
    iVar4 = iVar9;
    iVar9 = *(int *)(iVar9 + 0x74);
  } while( true );
  if ((iVar4 == 0) || (*(int *)(iVar4 + 0x78) == 0)) {
    *(undefined4 *)(iVar8 + 0x78) = 0;
    *(undefined4 *)(iVar6 + 0x78) = 1;
    iVar4 = *(int *)(iVar8 + 0x6c);
    *(int *)(iVar6 + 0x70) = iVar4;
    if (iVar4 != 0) {
      *(int *)(iVar4 + 0x74) = iVar6;
    }
    iVar4 = *(int *)(iVar6 + 0x74);
    *(int *)(iVar8 + 0x74) = iVar4;
    if (iVar4 == 0) {
      iVar5 = iVar8;
      piVar7 = &DAT_000508d0;
    }
    else {
      iVar4 = *(int *)(iVar6 + 0x74);
      piVar7 = (int *)(iVar4 + 0x70);
      if (iVar6 == *(int *)(iVar4 + 0x6c)) {
        piVar7 = (int *)(iVar4 + 0x6c);
      }
    }
    *piVar7 = iVar8;
    *(int *)(iVar8 + 0x6c) = iVar6;
    *(int *)(iVar6 + 0x74) = iVar8;
    iVar6 = *(int *)(iVar9 + 0x6c);
    iVar4 = *(int *)(iVar6 + 0x6c);
    *(undefined4 *)(iVar6 + 0x78) = *(undefined4 *)(iVar9 + 0x78);
    *(undefined4 *)(iVar9 + 0x78) = 0;
    if (iVar4 == 0) goto LAB_00027d98;
  }
  else {
LAB_00027cb9:
    *(undefined4 *)(iVar6 + 0x78) = *(undefined4 *)(iVar9 + 0x78);
    *(undefined4 *)(iVar9 + 0x78) = 0;
  }
  *(undefined4 *)(iVar4 + 0x78) = 0;
LAB_00027d98:
  iVar4 = *(int *)(iVar6 + 0x70);
  *(int *)(iVar9 + 0x6c) = iVar4;
  if (iVar4 != 0) {
    *(int *)(iVar4 + 0x74) = iVar9;
  }
  iVar4 = *(int *)(iVar9 + 0x74);
  *(int *)(iVar6 + 0x74) = iVar4;
  if (iVar4 == 0) {
    iVar5 = iVar6;
    piVar7 = &DAT_000508d0;
  }
  else {
    iVar4 = *(int *)(iVar9 + 0x74);
    piVar7 = (int *)(iVar4 + 0x70);
    if (iVar9 == *(int *)(iVar4 + 0x6c)) {
      piVar7 = (int *)(iVar4 + 0x6c);
    }
  }
  *piVar7 = iVar6;
  *(int *)(iVar6 + 0x70) = iVar9;
LAB_00027e3e:
  *(int *)(iVar9 + 0x74) = iVar6;
  iVar4 = iVar5;
  if (iVar5 != 0) {
LAB_00027e47:
    *(undefined4 *)(iVar4 + 0x78) = 0;
  }
  return;
}


// ==== FUN_00027e60 @ 00027e60

void FUN_00027e60(int param_1)

{
  DAT_00050850 = (uint)(param_1 != 0);
  return;
}


// ==== FUN_00027fe0 @ 00027fe0

void FUN_00027fe0(void)

{
  bool bVar1;
  regex_t *__preg;
  undefined4 *puVar2;
  FILE *__stream;
  char *pcVar3;
  int iVar4;
  size_t sVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 *__ptr;
  undefined4 *puVar8;
  regex_t *__preg_00;
  undefined4 *puVar9;
  int in_GS_OFFSET;
  undefined4 uVar10;
  int local_22c;
  ulong local_228;
  uint local_224;
  char local_21d [3];
  char local_21a;
  char acStack_219 [513];
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    if (6 < DAT_00050854) goto LAB_0002843e;
    pcVar3 = "fopen /proc/self/maps failed";
    uVar10 = 6;
  }
  else {
    pcVar3 = fgets(acStack_219 + 1,0x200,__stream);
    if (pcVar3 != (char *)0x0) {
LAB_000280c6:
      iVar4 = sscanf(acStack_219 + 1,"%x-%*lx %4s %lx %*x:%*x %*d%n",&local_224,local_21d,&local_228
                     ,&local_22c);
      if ((((iVar4 == 3) && (local_21d[0] == 'r')) && (local_21a == 'p')) && (local_228 == 0)) {
        iVar4 = local_22c;
        if ((acStack_219[local_22c + 1] == 0x20 || (int)acStack_219[local_22c + 1] - 9U < 5) &&
           (local_22c < 0x1ff)) {
          do {
            iVar4 = local_22c + 1;
            if (acStack_219[local_22c + 2] != 0x20 && 4 < (int)acStack_219[local_22c + 2] - 9U)
            break;
            bVar1 = local_22c < 0x1fe;
            local_22c = iVar4;
          } while (bVar1);
        }
        local_22c = iVar4;
        if (iVar4 < 0x1ff) {
          pcVar3 = acStack_219 + iVar4 + 1;
          sVar5 = strlen(pcVar3);
          if (((sVar5 != 0) &&
              ((acStack_219[sVar5 + iVar4] != '\n' || (pcVar3[sVar5 - 1] = '\0', sVar5 - 1 != 0))))
             && (__preg = DAT_00050840, *pcVar3 != '[')) {
            for (; __preg != (regex_t *)0x0; __preg = *(regex_t **)&__preg->field_0x1c) {
              iVar4 = regexec(__preg,pcVar3,0,(regmatch_t *)0x0,0);
              if (iVar4 == 0) {
                __preg_00 = DAT_00050848;
                goto LAB_00028223;
              }
            }
          }
        }
      }
      goto LAB_000280a0;
    }
LAB_00028350:
    fclose(__stream);
    piVar7 = (int *)&DAT_000508d0;
    puVar6 = (undefined4 *)0x0;
    do {
      __ptr = puVar6;
      puVar6 = (undefined4 *)*piVar7;
      piVar7 = puVar6 + 0x1b;
    } while (puVar6 != (undefined4 *)0x0);
    while (__ptr != (undefined4 *)0x0) {
      puVar6 = (undefined4 *)__ptr[0x1c];
      if ((undefined4 *)__ptr[0x1c] == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)__ptr[0x1d];
        puVar9 = (undefined4 *)0x0;
        if (puVar6 != (undefined4 *)0x0) {
          if ((undefined4 *)puVar6[0x1b] == __ptr) {
LAB_000283e2:
            puVar9 = puVar6;
          }
          else {
            puVar2 = puVar6;
            puVar8 = __ptr;
            do {
              puVar6 = puVar2;
              if (puVar8 != (undefined4 *)puVar6[0x1c]) goto LAB_000283e2;
              puVar2 = (undefined4 *)puVar6[0x1d];
              puVar8 = puVar6;
            } while ((undefined4 *)puVar6[0x1d] != (undefined4 *)0x0);
          }
        }
      }
      else {
        do {
          puVar9 = puVar6;
          puVar6 = (undefined4 *)puVar9[0x1b];
        } while ((undefined4 *)puVar9[0x1b] != (undefined4 *)0x0);
      }
      FUN_00027a40();
      if ((void *)*__ptr != (void *)0x0) {
        free((void *)*__ptr);
      }
      free(__ptr);
      __ptr = puVar9;
    }
    DAT_000508d0 = (undefined4 *)0x0;
    if (4 < DAT_00050854) goto LAB_0002843e;
    pcVar3 = "map refreshed";
    uVar10 = 4;
  }
  __android_log_print(uVar10,"xhook",pcVar3);
LAB_0002843e:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
LAB_00028223:
  if (__preg_00 == (regex_t *)0x0) goto LAB_00028087;
  iVar4 = regexec(__preg_00,pcVar3,0,(regmatch_t *)0x0,0);
  if ((iVar4 == 0) &&
     ((__preg_00->fastmap == (char *)0x0 ||
      (iVar4 = strcmp(__preg_00->fastmap,__preg->fastmap), iVar4 == 0)))) goto LAB_000280a0;
  __preg_00 = (regex_t *)__preg_00->translate;
  goto LAB_00028223;
LAB_00028087:
  iVar4 = FUN_00028460();
  puVar6 = DAT_000508d0;
  if (iVar4 == 0) {
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)puVar6[0x1b]) {
      while( true ) {
        iVar4 = strcmp(pcVar3,(char *)*puVar6);
        if (iVar4 < 0) break;
        if (iVar4 == 0) {
          FUN_00027a40();
          iVar4 = FUN_00028510();
          if (iVar4 != 0) goto LAB_00028311;
          if (puVar6[1] != local_224) {
            puVar6[1] = local_224;
            FUN_00028750();
          }
          goto LAB_000280a0;
        }
        puVar6 = (undefined4 *)puVar6[0x1c];
        if (puVar6 == (undefined4 *)0x0) goto LAB_000282a9;
      }
    }
LAB_000282a9:
    puVar6 = malloc(0x7c);
    if (puVar6 != (undefined4 *)0x0) {
      pcVar3 = strdup(pcVar3);
      *puVar6 = pcVar3;
      if (pcVar3 != (char *)0x0) {
        puVar6[1] = local_224;
        iVar4 = FUN_00028510();
        if (iVar4 == 0) {
          FUN_00028750();
          goto LAB_000280a0;
        }
LAB_00028311:
        free((void *)*puVar6);
      }
      free(puVar6);
    }
  }
LAB_000280a0:
  pcVar3 = fgets(acStack_219 + 1,0x200,__stream);
  if (pcVar3 == (char *)0x0) goto LAB_00028350;
  goto LAB_000280c6;
}


// ==== FUN_00028460 @ 00028460

undefined4 FUN_00028460(void)

{
  int iVar1;
  undefined4 uVar2;
  
  if (DAT_00050850 == 0) {
    uVar2 = FUN_000288c0();
  }
  else {
    DAT_000508e4 = 1;
    iVar1 = sigsetjmp(&DAT_000508e8,1);
    if (iVar1 == 0) {
      uVar2 = FUN_000288c0();
    }
    else {
      uVar2 = 0x3f1;
      if (DAT_00050854 < 6) {
        __android_log_print(5,"xhook","catch SIGSEGV when check_elfheader: %s");
      }
    }
    DAT_000508e4 = 0;
  }
  return uVar2;
}


// ==== FUN_00028510 @ 00028510

undefined4 * FUN_00028510(void)

{
  char *__s1;
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *in_ECX;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 *in_EDX;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  if ((undefined4 *)*in_ECX == (undefined4 *)0x0) {
    in_EDX[0x1b] = 0;
    in_EDX[0x1c] = 0;
    in_EDX[0x1d] = 0;
    in_EDX[0x1e] = 1;
    *in_ECX = (int)in_EDX;
  }
  else {
    __s1 = (char *)*in_EDX;
    puVar1 = (undefined4 *)*in_ECX;
    do {
      while( true ) {
        puVar8 = puVar1;
        uVar4 = strcmp(__s1,(char *)*puVar8);
        if ((int)uVar4 < 0) break;
        if (uVar4 == 0) {
          return puVar8;
        }
        puVar1 = (undefined4 *)puVar8[0x1c];
        if ((undefined4 *)puVar8[0x1c] == (undefined4 *)0x0) goto LAB_0002857f;
      }
      puVar1 = (undefined4 *)puVar8[0x1b];
    } while ((undefined4 *)puVar8[0x1b] != (undefined4 *)0x0);
LAB_0002857f:
    in_EDX[0x1d] = puVar8;
    in_EDX[0x1c] = 0;
    in_EDX[0x1b] = 0;
    in_EDX[0x1e] = 1;
    puVar8[0x1b - ((int)~uVar4 >> 0x1f)] = in_EDX;
    do {
      if (puVar8[0x1e] != 1) break;
      puVar1 = (undefined4 *)puVar8[0x1d];
      puVar5 = (undefined4 *)puVar1[0x1b];
      if (puVar8 == puVar5) {
        puVar5 = (undefined4 *)puVar1[0x1c];
        if ((puVar5 != (undefined4 *)0x0) && (puVar5[0x1e] == 1)) goto LAB_000285b0;
        puVar5 = (undefined4 *)puVar8[0x1c];
        if (puVar5 == in_EDX) {
          iVar2 = in_EDX[0x1b];
          puVar8[0x1c] = iVar2;
          if (iVar2 == 0) {
            in_EDX[0x1d] = puVar1;
LAB_000286bf:
            iVar2 = puVar8[0x1d];
            piVar6 = (int *)(iVar2 + 0x70);
            if (puVar8 == *(undefined4 **)(iVar2 + 0x6c)) {
              piVar6 = (int *)(iVar2 + 0x6c);
            }
          }
          else {
            *(undefined4 **)(iVar2 + 0x74) = puVar8;
            iVar2 = puVar8[0x1d];
            in_EDX[0x1d] = iVar2;
            if (iVar2 != 0) goto LAB_000286bf;
            piVar6 = in_ECX;
          }
          *piVar6 = (int)in_EDX;
          in_EDX[0x1b] = puVar8;
          puVar8[0x1d] = in_EDX;
          puVar7 = (undefined4 *)puVar1[0x1b];
          puVar5 = (undefined4 *)puVar7[0x1c];
          puVar9 = puVar8;
        }
        else {
          puVar7 = puVar8;
          puVar9 = in_EDX;
          in_EDX = puVar8;
        }
        in_EDX[0x1e] = 0;
        puVar1[0x1e] = 1;
        puVar1[0x1b] = puVar5;
        if (puVar5 != (undefined4 *)0x0) {
          puVar5[0x1d] = puVar1;
        }
        iVar2 = puVar1[0x1d];
        puVar7[0x1d] = iVar2;
        if (iVar2 == 0) {
          piVar6 = in_ECX;
        }
        else {
          iVar2 = puVar1[0x1d];
          piVar6 = (int *)(iVar2 + 0x70);
          if (puVar1 == *(undefined4 **)(iVar2 + 0x6c)) {
            piVar6 = (int *)(iVar2 + 0x6c);
          }
        }
        *piVar6 = (int)puVar7;
        puVar7[0x1c] = puVar1;
        puVar1[0x1d] = puVar7;
        in_EDX = puVar9;
      }
      else if ((puVar5 == (undefined4 *)0x0) || (puVar5[0x1e] != 1)) {
        if ((undefined4 *)puVar8[0x1b] == in_EDX) {
          iVar2 = in_EDX[0x1c];
          puVar8[0x1b] = iVar2;
          if (iVar2 == 0) {
            in_EDX[0x1d] = puVar1;
LAB_0002865a:
            iVar2 = puVar8[0x1d];
            piVar6 = (int *)(iVar2 + 0x70);
            if (puVar8 == *(undefined4 **)(iVar2 + 0x6c)) {
              piVar6 = (int *)(iVar2 + 0x6c);
            }
          }
          else {
            *(undefined4 **)(iVar2 + 0x74) = puVar8;
            iVar2 = puVar8[0x1d];
            in_EDX[0x1d] = iVar2;
            if (iVar2 != 0) goto LAB_0002865a;
            piVar6 = in_ECX;
          }
          *piVar6 = (int)in_EDX;
          in_EDX[0x1c] = puVar8;
          puVar8[0x1d] = in_EDX;
          puVar5 = in_EDX;
        }
        else {
          puVar5 = puVar8;
          puVar8 = in_EDX;
        }
        puVar5[0x1e] = 0;
        puVar1[0x1e] = 1;
        iVar2 = puVar1[0x1c];
        iVar3 = *(int *)(iVar2 + 0x6c);
        puVar1[0x1c] = iVar3;
        if (iVar3 != 0) {
          *(undefined4 **)(iVar3 + 0x74) = puVar1;
        }
        iVar3 = puVar1[0x1d];
        *(int *)(iVar2 + 0x74) = iVar3;
        if (iVar3 == 0) {
          piVar6 = in_ECX;
        }
        else {
          iVar3 = puVar1[0x1d];
          piVar6 = (int *)(iVar3 + 0x70);
          if (puVar1 == *(undefined4 **)(iVar3 + 0x6c)) {
            piVar6 = (int *)(iVar3 + 0x6c);
          }
        }
        *piVar6 = iVar2;
        *(undefined4 **)(iVar2 + 0x6c) = puVar1;
        puVar1[0x1d] = iVar2;
        in_EDX = puVar8;
      }
      else {
LAB_000285b0:
        puVar5[0x1e] = 0;
        puVar8[0x1e] = 0;
        puVar1[0x1e] = 1;
        in_EDX = puVar1;
      }
      puVar8 = (undefined4 *)in_EDX[0x1d];
    } while (puVar8 != (undefined4 *)0x0);
    in_EDX = (undefined4 *)*in_ECX;
  }
  in_EDX[0x1e] = 0;
  return (undefined4 *)0x0;
}


// ==== FUN_00028750 @ 00028750

void FUN_00028750(void)

{
  int iVar1;
  undefined4 *in_ECX;
  
  if (DAT_00050850 == 0) {
    FUN_000287e0();
  }
  else {
    DAT_000508e4 = 1;
    iVar1 = sigsetjmp(&DAT_000508e8,1);
    if (iVar1 == 0) {
      FUN_000287e0();
    }
    else if (DAT_00050854 < 6) {
      __android_log_print(5,"xhook","catch SIGSEGV when init or hook: %s",*in_ECX);
    }
    DAT_000508e4 = 0;
  }
  return;
}


// ==== FUN_000287e0 @ 000287e0

void FUN_000287e0(void)

{
  int iVar1;
  undefined4 *in_ECX;
  regex_t *__preg;
  regex_t *__preg_00;
  
  iVar1 = FUN_00028920(in_ECX + 2,in_ECX[1],*in_ECX);
  if (iVar1 == 0) {
    for (__preg_00 = DAT_00050840; __preg_00 != (regex_t *)0x0;
        __preg_00 = *(regex_t **)&__preg_00->field_0x1c) {
      iVar1 = regexec(__preg_00,(char *)*in_ECX,0,(regmatch_t *)0x0,0);
      if (iVar1 == 0) {
        for (__preg = DAT_00050848; __preg != (regex_t *)0x0; __preg = (regex_t *)__preg->translate)
        {
          iVar1 = regexec(__preg,(char *)*in_ECX,0,(regmatch_t *)0x0,0);
          if (iVar1 == 0) {
            if (__preg->fastmap == (char *)0x0) {
              return;
            }
            iVar1 = strcmp(__preg->fastmap,__preg_00->fastmap);
            if (iVar1 == 0) goto LAB_00028845;
          }
        }
        FUN_00028dd0(in_ECX + 2,__preg_00->fastmap,__preg_00->translate,__preg_00->re_nsub);
      }
LAB_00028845:
    }
  }
  return;
}


// ==== FUN_000288c0 @ 000288c0

undefined4 FUN_000288c0(int *param_1)

{
  undefined4 uVar1;
  
  if ((((*param_1 != 0x464c457f) || ((char)param_1[1] != '\x01')) ||
      (*(char *)((int)param_1 + 5) != '\x01')) ||
     (((*(char *)((int)param_1 + 6) != '\x01' || ((*(ushort *)(param_1 + 4) & 0xfffe) != 2)) ||
      (*(short *)((int)param_1 + 0x12) != 3)))) {
    return 0x3ef;
  }
  uVar1 = 0x3ef;
  if (param_1[5] == 1) {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_00028920 @ 00028920

undefined4 FUN_00028920(int *param_1,int *param_2,int param_3)

{
  ushort uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  undefined *puVar8;
  int iVar9;
  int *piVar10;
  char *pcVar11;
  
  if (param_2 == (int *)0x0) {
    return 0x3ea;
  }
  if (param_3 == 0) {
    return 0x3ea;
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[0x18] = 0;
  *param_1 = param_3;
  param_1[1] = (int)param_2;
  param_1[3] = (int)param_2;
  piVar7 = (int *)(param_2[7] + (int)param_2);
  param_1[4] = (int)piVar7;
  uVar1 = *(ushort *)(param_2 + 0xb);
  if (uVar1 != 0) {
    piVar5 = piVar7;
    do {
      if ((*piVar5 == 1) && (piVar5[1] == 0)) {
        if (param_2 < (int *)piVar5[2]) {
          return 0x3ef;
        }
        iVar9 = (int)param_2 - piVar5[2];
        param_1[2] = iVar9;
        piVar5 = piVar7;
        goto LAB_00028a10;
      }
      piVar5 = piVar5 + 8;
    } while (piVar5 < piVar7 + (uint)uVar1 * 8);
  }
  if (6 < DAT_00050854) {
    return 0x3ef;
  }
  pcVar11 = "Can NOT found the first load segment. %s";
  goto LAB_000289e4;
  while (piVar5 = piVar5 + 8, piVar5 < piVar7 + (uint)uVar1 * 8) {
LAB_00028a10:
    if (*piVar5 == 2) {
      piVar10 = (int *)(piVar5[2] + iVar9);
      param_1[5] = (int)piVar10;
      uVar2 = piVar5[5];
      param_1[6] = uVar2;
      if (uVar2 < 8) goto LAB_00028a55;
      piVar5 = (int *)((uVar2 & 0xfffffff8) + (int)piVar10);
      goto LAB_00028b9f;
    }
  }
  if (6 < DAT_00050854) {
    return 0x3ef;
  }
  pcVar11 = "Can NOT found dynamic segment. %s";
  goto LAB_000289e4;
LAB_00028b9f:
  do {
    iVar3 = *piVar10;
    switch(iVar3) {
    case 0:
      piVar10 = piVar5;
      break;
    case 1:
    case 3:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x10:
    case 0x13:
    case 0x15:
    case 0x16:
      break;
    case 2:
      param_1[10] = piVar10[1];
      break;
    case 4:
      if (param_1[0x18] != 1) {
        piVar6 = (int *)(piVar10[1] + iVar9);
        if (piVar6 < param_2) {
          return 0x3ef;
        }
        iVar3 = *piVar6;
        param_1[0x10] = iVar3;
        param_1[0x12] = piVar6[1];
        param_1[0xf] = (int)(piVar6 + 2);
        param_1[0x11] = (int)(piVar6 + iVar3 + 2);
      }
      break;
    case 5:
      piVar6 = (int *)(piVar10[1] + iVar9);
      param_1[7] = (int)piVar6;
      goto joined_r0x00028be1;
    case 6:
      piVar6 = (int *)(piVar10[1] + iVar9);
      param_1[8] = (int)piVar6;
      goto joined_r0x00028be1;
    case 7:
    case 0x11:
      piVar6 = (int *)(piVar10[1] + iVar9);
      param_1[0xb] = (int)piVar6;
      goto joined_r0x00028be1;
    case 8:
    case 0x12:
      param_1[0xc] = piVar10[1];
      break;
    case 0x14:
      param_1[0x17] = (uint)(piVar10[1] == 7);
      break;
    case 0x17:
      piVar6 = (int *)(piVar10[1] + iVar9);
      param_1[9] = (int)piVar6;
joined_r0x00028be1:
      if (piVar6 < param_2) {
        return 0x3ef;
      }
      break;
    default:
      switch(iVar3) {
      case 0x6000000f:
      case 0x60000011:
        piVar6 = (int *)(piVar10[1] + iVar9);
        param_1[0xd] = (int)piVar6;
        goto joined_r0x00028be1;
      case 0x60000010:
      case 0x60000012:
        param_1[0xe] = piVar10[1];
        break;
      default:
        if (iVar3 == 0x6ffffef5) {
          piVar6 = (int *)(piVar10[1] + iVar9);
          if (piVar6 < param_2) {
            return 0x3ef;
          }
          iVar3 = *piVar6;
          param_1[0x10] = iVar3;
          param_1[0x13] = piVar6[1];
          iVar4 = piVar6[2];
          param_1[0x15] = iVar4;
          param_1[0x16] = piVar6[3];
          param_1[0x14] = (int)(piVar6 + 4);
          param_1[0xf] = (int)(piVar6 + iVar4 + 4);
          param_1[0x11] = (int)(piVar6 + iVar4 + 4 + iVar3);
          param_1[0x18] = 1;
        }
      }
    }
    piVar10 = piVar10 + 2;
  } while (piVar10 < piVar5);
LAB_00028a55:
  pcVar11 = (char *)param_1[0xd];
  if (pcVar11 != (char *)0x0) {
    if (((((uint)param_1[0xe] < 4) || (*pcVar11 != 'A')) || (pcVar11[1] != 'P')) ||
       ((pcVar11[2] != 'S' || (pcVar11[3] != '2')))) {
      if (6 < DAT_00050854) {
        return 0x3ef;
      }
      pcVar11 = "android rel/rela format error\n";
      param_3 = 0x28931;
      goto LAB_000289e4;
    }
    param_1[0xd] = (int)(pcVar11 + 4);
    param_1[0xe] = param_1[0xe] - 4;
  }
  if (iVar9 == 0) {
    if (6 < DAT_00050854) {
      return 0x3ef;
    }
    pcVar11 = "bias_addr == 0\n";
  }
  else if (piVar7 == (int *)0x0) {
    if (6 < DAT_00050854) {
      return 0x3ef;
    }
    pcVar11 = "phdr == NULL\n";
  }
  else if (param_1[7] == 0) {
    if (6 < DAT_00050854) {
      return 0x3ef;
    }
    pcVar11 = "strtab == NULL\n";
  }
  else if (param_1[8] == 0) {
    if (6 < DAT_00050854) {
      return 0x3ef;
    }
    pcVar11 = "symtab == NULL\n";
  }
  else if (param_1[0xf] == 0) {
    if (6 < DAT_00050854) {
      return 0x3ef;
    }
    pcVar11 = "bucket == NULL\n";
  }
  else if (param_1[0x11] == 0) {
    if (6 < DAT_00050854) {
      return 0x3ef;
    }
    pcVar11 = "chain == NULL\n";
  }
  else {
    if ((param_1[0x18] != 1) || (param_1[0x14] != 0)) {
      if (4 < DAT_00050854) {
        return 0;
      }
      puVar8 = &DAT_00014473;
      if (param_1[0x17] == 0) {
        puVar8 = &DAT_000143a8;
      }
      pcVar11 = "GNU_HASH";
      if (param_1[0x18] == 0) {
        pcVar11 = "ELF_HASH";
      }
      __android_log_print(4,"xhook","init OK: %s (%s %s PLT:%u DYN:%u ANDROID:%u)\n",param_3,puVar8,
                          pcVar11,param_1[10],param_1[0xc],param_1[0xe]);
      return 0;
    }
    if (6 < DAT_00050854) {
      return 0x3ef;
    }
    pcVar11 = "bloom == NULL\n";
  }
  __android_log_print(6,"xhook",pcVar11);
  if (6 < DAT_00050854) {
    return 0x3ef;
  }
  pcVar11 = "elf init check failed. %s";
LAB_000289e4:
  __android_log_print(6,"xhook",pcVar11,param_3);
  return 0x3ef;
}


// ==== FUN_00028dd0 @ 00028dd0

int FUN_00028dd0(int *param_1,byte *param_2,int param_3,undefined4 param_4)

{
  byte *pbVar1;
  int iVar2;
  byte *pbVar3;
  int iVar4;
  char *pcVar5;
  byte *pbVar6;
  uint *puVar7;
  byte bVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  int *piVar14;
  uint uVar15;
  int in_GS_OFFSET;
  uint local_98;
  uint local_94;
  uint local_90;
  uint local_88;
  int local_80;
  uint local_78;
  uint local_74;
  uint local_6c;
  int local_64;
  byte *local_60;
  byte *local_5c;
  uint local_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint local_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  int local_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint local_28;
  int local_24;
  int local_20;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if (*param_1 == 0) {
    iVar2 = 0x3f0;
    if (DAT_00050854 < 7) {
      __android_log_print(6,"xhook","not inited\n");
      iVar2 = 0x3f0;
    }
    goto LAB_000297da;
  }
  iVar2 = 0x3ea;
  if ((param_2 == (byte *)0x0) || (param_3 == 0)) goto LAB_000297da;
  if (DAT_00050854 < 5) {
    __android_log_print(4,"xhook","hooking %s in %s\n",param_2,*param_1);
  }
  bVar8 = *param_2;
  if (param_1[0x18] == 0) {
    uVar13 = 0;
    if (bVar8 != 0) {
      uVar13 = 0;
      pbVar3 = param_2;
      do {
        pbVar3 = pbVar3 + 1;
        uVar13 = (uint)bVar8 + uVar13 * 0x10;
        uVar13 = uVar13 >> 0x18 & 0xfffffff0 ^ uVar13 & 0xfffffff;
        bVar8 = *pbVar3;
      } while (bVar8 != 0);
    }
    local_98 = *(uint *)(param_1[0xf] + (uVar13 % (uint)param_1[0x10]) * 4);
    if (local_98 != 0) {
      iVar2 = param_1[7];
      iVar11 = param_1[8];
      do {
        iVar4 = strcmp((char *)param_2,(char *)(*(int *)(iVar11 + local_98 * 0x10) + iVar2));
        if (iVar4 == 0) {
          if (4 < DAT_00050854) goto LAB_00029124;
          pcVar5 = "found %s at symidx: %u (ELF_HASH)\n";
          goto LAB_00029106;
        }
        local_98 = *(uint *)(param_1[0x11] + local_98 * 4);
      } while (local_98 != 0);
    }
  }
  else {
    if (bVar8 == 0) {
      uVar13 = 0x1505;
    }
    else {
      uVar13 = 0x1505;
      pbVar3 = param_2;
      do {
        pbVar3 = pbVar3 + 1;
        uVar13 = uVar13 * 0x21 + (uint)bVar8;
        bVar8 = *pbVar3;
      } while (bVar8 != 0);
    }
    if (((1 << ((byte)(uVar13 >> (*(byte *)(param_1 + 0x16) & 0x1f)) & 0x1f) | 1 << (uVar13 & 0x1f))
        & ~*(uint *)(param_1[0x14] + ((uVar13 >> 5) % (uint)param_1[0x15]) * 4)) == 0) {
      uVar9 = param_1[0x13];
      local_98 = *(uint *)(param_1[0xf] + (uVar13 % (uint)param_1[0x10]) * 4);
      if (uVar9 <= local_98) {
        iVar2 = param_1[0x11];
        iVar11 = local_98 << 4;
        do {
          uVar10 = *(uint *)(iVar2 + uVar9 * -4 + local_98 * 4);
          if (((uVar10 ^ uVar13) < 2) &&
             (iVar4 = strcmp((char *)param_2,(char *)(param_1[7] + *(int *)(param_1[8] + iVar11))),
             iVar4 == 0)) {
            if (4 < DAT_00050854) goto LAB_00029124;
            pcVar5 = "found %s at symidx: %u (GNU_HASH DEF)\n";
            goto LAB_00029106;
          }
          local_98 = local_98 + 1;
          iVar11 = iVar11 + 0x10;
        } while ((uVar10 & 1) == 0);
        goto joined_r0x00029061;
      }
    }
    else {
      uVar9 = param_1[0x13];
joined_r0x00029061:
      if (uVar9 == 0) goto LAB_000297d8;
    }
    iVar2 = param_1[7];
    piVar14 = (int *)param_1[8];
    local_98 = 0;
LAB_000290b0:
    iVar11 = strcmp((char *)(*piVar14 + iVar2),(char *)param_2);
    if (iVar11 != 0) goto code_r0x000290cb;
    if (DAT_00050854 < 5) {
      pcVar5 = "found %s at symidx: %u (GNU_HASH UNDEF)\n";
LAB_00029106:
      __android_log_print(4,"xhook",pcVar5,param_2,local_98);
      uVar13 = param_1[9];
    }
    else {
LAB_00029124:
      uVar13 = param_1[9];
    }
    if (uVar13 != 0) {
      uVar9 = uVar13 + param_1[10];
      iVar11 = param_1[0x17];
      do {
        if (uVar9 <= uVar13) break;
        iVar2 = FUN_00029800(1,param_2,param_3,param_4,local_98,uVar13,&local_64);
        if (iVar2 != 0) goto LAB_000297da;
        uVar13 = uVar13 + (uint)(iVar11 != 0) * 4 + 8;
      } while (local_64 == 0);
    }
    uVar13 = param_1[0xb];
    if (uVar13 != 0) {
      iVar11 = param_1[0xc];
      iVar4 = param_1[0x17];
      uVar9 = uVar13;
      while (uVar9 < uVar13 + iVar11) {
        iVar2 = FUN_00029800(0,param_2,param_3,param_4,local_98,uVar9,0);
        uVar9 = uVar9 + (uint)(iVar4 != 0) * 4 + 8;
        if (iVar2 != 0) goto LAB_000297da;
      }
    }
    pbVar3 = (byte *)param_1[0xd];
    if (pbVar3 == (byte *)0x0) goto LAB_000297d8;
    iVar11 = param_1[0x17];
    local_38 = 0;
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    local_48 = 0;
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_3c = 0;
    local_58 = 0;
    uStack_54 = 0;
    uStack_50 = 0;
    uStack_4c = 0;
    local_24 = 0;
    local_28 = 0;
    pbVar1 = pbVar3 + param_1[0xe];
    if (param_1[0xe] < 1) {
LAB_000292c1:
      local_60 = pbVar3;
    }
    else {
      uVar9 = 0;
      uVar13 = 0;
      while( true ) {
        bVar8 = *pbVar3;
        uVar13 = (bVar8 & 0x7f) << ((byte)uVar9 & 0x1f) | uVar13;
        pbVar3 = pbVar3 + 1;
        uVar9 = uVar9 + 7;
        if ((bVar8 & 0x80) == 0) break;
        if (pbVar1 <= pbVar3) goto LAB_000292c1;
      }
      local_58 = -1 << ((byte)uVar9 & 0x1f);
      if ((bVar8 & 0x40) == 0) {
        local_58 = 0;
      }
      if (0x1f < uVar9) {
        local_58 = 0;
      }
      local_58 = local_58 | uVar13;
      uVar13 = 0;
      uVar9 = 0;
      local_60 = pbVar3;
      do {
        if (pbVar1 <= local_60) goto LAB_000292d5;
        pbVar3 = local_60 + 1;
        bVar8 = *local_60;
        uVar13 = uVar13 | (bVar8 & 0x7f) << ((byte)uVar9 & 0x1f);
        uVar9 = uVar9 + 7;
        local_60 = pbVar3;
      } while ((bVar8 & 0x80) != 0);
      uStack_2c = -1 << ((byte)uVar9 & 0x1f);
      if ((bVar8 & 0x40) == 0) {
        uStack_2c = 0;
      }
      if (0x1f < uVar9) {
        uStack_2c = 0;
      }
      uStack_2c = uStack_2c | uVar13;
    }
LAB_000292d5:
    uVar13 = local_58;
    local_74 = 0;
    local_80 = 0;
    local_6c = 0;
    local_88 = 0;
    uVar9 = 0;
    local_90 = 0;
    local_78 = 0;
    pbVar3 = local_60;
    local_94 = uStack_2c;
    local_5c = pbVar1;
    local_20 = iVar11;
    while (local_78 < uVar13) {
      if (local_90 == uVar9) {
        uVar12 = 0;
        uVar10 = 0;
        do {
          if (pbVar1 <= pbVar3) goto LAB_000297d8;
          local_60 = pbVar3 + 1;
          bVar8 = *pbVar3;
          uVar12 = uVar12 | (bVar8 & 0x7f) << ((byte)uVar10 & 0x1f);
          uVar10 = uVar10 + 7;
          pbVar3 = local_60;
        } while ((bVar8 & 0x80) != 0);
        uVar9 = -1 << ((byte)uVar10 & 0x1f);
        if ((bVar8 & 0x40) == 0) {
          uVar9 = 0;
        }
        if (0x1f < uVar10) {
          uVar9 = 0;
        }
        uVar9 = uVar9 | uVar12;
        uVar12 = 0;
        uVar10 = 0;
        do {
          uStack_54 = uVar9;
          if (pbVar1 <= local_60) goto LAB_000297d8;
          pbVar3 = local_60 + 1;
          bVar8 = *local_60;
          uVar12 = uVar12 | (bVar8 & 0x7f) << ((byte)uVar10 & 0x1f);
          uVar10 = uVar10 + 7;
          local_60 = pbVar3;
        } while ((bVar8 & 0x80) != 0);
        local_88 = -1 << ((byte)uVar10 & 0x1f);
        if ((bVar8 & 0x40) == 0) {
          local_88 = 0;
        }
        if (0x1f < uVar10) {
          local_88 = 0;
        }
        local_88 = local_88 | uVar12;
        uStack_50 = local_88;
        if ((local_88 & 2) != 0) {
          uVar12 = 0;
          uVar10 = 0;
          do {
            if (pbVar1 <= local_60) goto LAB_000290db;
            pbVar3 = local_60 + 1;
            bVar8 = *local_60;
            uVar12 = uVar12 | (bVar8 & 0x7f) << ((byte)uVar10 & 0x1f);
            uVar10 = uVar10 + 7;
            local_60 = pbVar3;
          } while ((bVar8 & 0x80) != 0);
          local_6c = -1 << ((byte)uVar10 & 0x1f);
          if ((bVar8 & 0x40) == 0) {
            local_6c = 0;
          }
          if (0x1f < uVar10) {
            local_6c = 0;
          }
          local_6c = local_6c | uVar12;
          uStack_4c = local_6c;
        }
        if ((local_88 & 1) == 0) {
        }
        else {
          uVar12 = 0;
          uVar10 = 0;
          do {
            if (pbVar1 <= local_60) goto LAB_000290db;
            pbVar3 = local_60 + 1;
            bVar8 = *local_60;
            uVar12 = uVar12 | (bVar8 & 0x7f) << ((byte)uVar10 & 0x1f);
            uVar10 = uVar10 + 7;
            local_60 = pbVar3;
          } while ((bVar8 & 0x80) != 0);
          local_74 = -1 << ((byte)uVar10 & 0x1f);
          if ((bVar8 & 0x40) == 0) {
            local_74 = 0;
          }
          if (0x1f < uVar10) {
            local_74 = 0;
          }
          local_74 = local_74 | uVar12;
          local_28 = local_74;
        }
        if ((~local_88 & 0xc) == 0) {
          if (iVar11 == 0) {
            if (DAT_00050854 < 7) {
              __android_log_print(6,"xhook","unexpected r_addend in android.rel section");
            }
            break;
          }
          uVar10 = 0;
          uVar12 = 0;
          do {
            if (pbVar1 <= local_60) goto LAB_000297d8;
            pbVar3 = local_60 + 1;
            bVar8 = *local_60;
            uVar10 = uVar10 | (bVar8 & 0x7f) << ((byte)uVar12 & 0x1f);
            uVar12 = uVar12 + 7;
            local_60 = pbVar3;
          } while ((bVar8 & 0x80) != 0);
          uVar15 = -1 << ((byte)uVar12 & 0x1f);
          if ((bVar8 & 0x40) == 0) {
            uVar15 = 0;
          }
          if (0x1f < uVar12) {
            uVar15 = 0;
          }
          iVar2 = local_80 + (uVar15 | uVar10);
LAB_00029712:
          local_80 = iVar2;
          local_24 = iVar2;
        }
        else {
          iVar2 = 0;
          if ((local_88 & 8) == 0) goto LAB_00029712;
        }
        uStack_44 = 0;
        local_90 = 1;
        pbVar3 = local_60;
      }
      else {
        local_90 = local_90 + 1;
      }
      if ((local_88 & 2) == 0) {
        uVar12 = 0;
        uVar10 = 0;
        pbVar6 = pbVar3;
        do {
          if (pbVar1 <= pbVar6) goto LAB_000297d8;
          pbVar3 = pbVar6 + 1;
          bVar8 = *pbVar6;
          uVar12 = uVar12 | (bVar8 & 0x7f) << ((byte)uVar10 & 0x1f);
          uVar10 = uVar10 + 7;
          pbVar6 = pbVar3;
          local_60 = pbVar3;
        } while ((bVar8 & 0x80) != 0);
        uVar15 = -1 << ((byte)uVar10 & 0x1f);
        if ((bVar8 & 0x40) == 0) {
          uVar15 = 0;
        }
        if (0x1f < uVar10) {
          uVar15 = 0;
        }
        uVar10 = uVar15 | uVar12;
      }
      else {
        uVar10 = local_6c;
      }
      local_94 = local_94 + uVar10;
      uStack_2c = local_94;
      if ((local_88 & 1) == 0) {
        uVar12 = 0;
        uVar10 = 0;
        pbVar6 = pbVar3;
        do {
          if (pbVar1 <= pbVar6) goto LAB_000297d8;
          pbVar3 = pbVar6 + 1;
          bVar8 = *pbVar6;
          uVar12 = uVar12 | (bVar8 & 0x7f) << ((byte)uVar10 & 0x1f);
          uVar10 = uVar10 + 7;
          pbVar6 = pbVar3;
          local_60 = pbVar3;
        } while ((bVar8 & 0x80) != 0);
        local_74 = -1 << ((byte)uVar10 & 0x1f);
        if ((bVar8 & 0x40) == 0) {
          local_74 = 0;
        }
        if (0x1f < uVar10) {
          local_74 = 0;
        }
        local_74 = local_74 | uVar12;
        local_28 = local_74;
      }
      if (iVar11 == 0) {
        uStack_30 = local_74;
        puVar7 = &uStack_34;
        uStack_34 = local_94;
      }
      else {
        if ((local_88 & 0xc) == 8) {
          uVar10 = 0;
          uVar12 = 0;
          pbVar6 = pbVar3;
          do {
            if (pbVar1 <= pbVar6) goto LAB_000297d8;
            pbVar3 = pbVar6 + 1;
            bVar8 = *pbVar6;
            uVar10 = uVar10 | (bVar8 & 0x7f) << ((byte)uVar12 & 0x1f);
            uVar12 = uVar12 + 7;
            pbVar6 = pbVar3;
            local_60 = pbVar3;
          } while ((bVar8 & 0x80) != 0);
          uVar15 = -1 << ((byte)uVar12 & 0x1f);
          if ((bVar8 & 0x40) == 0) {
            uVar15 = 0;
          }
          if (0x1f < uVar12) {
            uVar15 = 0;
          }
          local_80 = local_80 + (uVar15 | uVar10);
          local_24 = local_80;
        }
        uStack_3c = local_74;
        local_38 = local_80;
        puVar7 = &uStack_40;
        uStack_40 = local_94;
      }
      local_78 = local_78 + 1;
      local_48 = local_78;
      uStack_44 = local_90;
      iVar2 = FUN_00029800(0,param_2,param_3,param_4,local_98,puVar7,0);
      if (iVar2 != 0) goto LAB_000297da;
    }
  }
LAB_000297d8:
  iVar2 = 0;
LAB_000297da:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar2;
code_r0x000290cb:
  local_98 = local_98 + 1;
  piVar14 = piVar14 + 4;
  if (uVar9 == local_98) goto LAB_000290db;
  goto LAB_000290b0;
LAB_000290db:
  iVar2 = 0;
  goto LAB_000297da;
}


// ==== FUN_00029800 @ 00029800

int FUN_00029800(int param_1,undefined4 param_2,int param_3,int *param_4,uint param_5,int *param_6,
                undefined4 *param_7)

{
  uint uVar1;
  int iVar2;
  undefined4 *in_ECX;
  undefined4 in_EDX;
  int *piVar3;
  int iVar4;
  int in_GS_OFFSET;
  int local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if (param_7 != (undefined4 *)0x0) {
    *param_7 = 0;
  }
  uVar1 = param_6[1];
  iVar4 = 0;
  if (((uVar1 >> 8 != param_5) || ((iVar2 = *param_6, param_1 != 0 && ((uVar1 & 0xff) != 7)))) ||
     ((param_1 == 0 && (((char)uVar1 != '\x06' && ((char)uVar1 != '\x01')))))) goto LAB_00029a45;
  if (DAT_00050854 < 5) {
    __android_log_print(4,"xhook","found %s at %s offset: %p\n",param_2,in_EDX,iVar2);
  }
  if (param_7 != (undefined4 *)0x0) {
    *param_7 = 1;
  }
  piVar3 = (int *)(iVar2 + in_ECX[2]);
  iVar4 = 0x3ef;
  if (piVar3 < (int *)in_ECX[1]) goto LAB_00029a45;
  local_1c = 0;
  if (*piVar3 == param_3) {
LAB_00029a43:
    iVar4 = 0;
  }
  else {
    iVar4 = FUN_00029ce0(piVar3,*in_ECX,&local_1c);
    if (iVar4 == 0) {
      if ((local_1c == 3) || (iVar4 = FUN_00029d10(piVar3,3), iVar4 == 0)) {
        iVar4 = *piVar3;
        if (param_4 != (int *)0x0) {
          *param_4 = iVar4;
        }
        *piVar3 = param_3;
        if (((local_1c != 3) && (iVar2 = FUN_00029d10(piVar3,local_1c), iVar2 != 0)) &&
           (DAT_00050854 < 6)) {
          __android_log_print(5,"xhook","restore addr prot failed. ret: %d",iVar2);
        }
        FUN_00029db0(piVar3);
        if (DAT_00050854 < 5) {
          __android_log_print(4,"xhook","XH_HK_OK %p: %p -> %p %s %s\n",piVar3,iVar4,param_3,param_2
                              ,*in_ECX);
        }
        goto LAB_00029a43;
      }
      if (6 < DAT_00050854) goto LAB_00029a45;
      __android_log_print(6,"xhook","set addr prot failed. ret: %d",iVar4);
    }
    else {
      if (6 < DAT_00050854) goto LAB_00029a45;
      __android_log_print(6,"xhook","get addr prot failed. ret: %d",iVar4);
    }
    if (DAT_00050854 < 7) {
      __android_log_print(6,"xhook","replace function failed: %s at %s\n",param_2,in_EDX);
    }
  }
LAB_00029a45:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar4;
}


// ==== FUN_00029a60 @ 00029a60

int FUN_00029a60(uint param_1,int param_2,char *param_3,uint *param_4)

{
  FILE *__stream;
  char *pcVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int in_GS_OFFSET;
  int local_238;
  uint local_228;
  uint local_224;
  char local_21d;
  char local_21c;
  char local_21b;
  char local_21a;
  char local_218 [512];
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  *param_4 = 0;
  __stream = fopen("/proc/self/maps","r");
  if (__stream == (FILE *)0x0) {
    local_238 = 0x3ee;
    if (*(int *)(in_GS_OFFSET + 0x14) != local_18) goto LAB_00029cd8;
  }
  else {
    pcVar1 = fgets(local_218,0x200,__stream);
    if (pcVar1 != (char *)0x0) {
      uVar4 = param_2 + param_1;
      local_238 = 1;
      do {
        if (param_3 == (char *)0x0) {
          while ((iVar2 = sscanf(local_218,"%x-%x %4s ",&local_224,&local_228,&local_21d),
                 iVar2 != 3 || (local_21a != 'p'))) {
            pcVar1 = fgets(local_218,0x200,__stream);
            if (pcVar1 == (char *)0x0) goto LAB_00029c8f;
          }
        }
        else {
          while (((pcVar1 = strstr(local_218,param_3), pcVar1 == (char *)0x0 ||
                  (iVar2 = sscanf(local_218,"%x-%x %4s ",&local_224,&local_228,&local_21d),
                  iVar2 != 3)) || (local_21a != 'p'))) {
            pcVar1 = fgets(local_218,0x200,__stream);
            if (pcVar1 == (char *)0x0) goto LAB_00029c8f;
          }
        }
        if ((local_224 <= param_1) && (param_1 < local_228)) {
          if (local_238 == 0) {
            if (local_21d != 'r') {
              *(byte *)param_4 = (byte)*param_4 & 0xfe;
            }
            if (local_21c != 'w') {
              *(byte *)param_4 = (byte)*param_4 & 0xfd;
            }
            if (local_21b != 'x') {
              uVar3 = *param_4 & 0xfffffffb;
              goto LAB_00029c57;
            }
          }
          else {
            if (local_21d == 'r') {
              *(byte *)param_4 = (byte)*param_4 | 1;
            }
            if (local_21c == 'w') {
              *(byte *)param_4 = (byte)*param_4 | 2;
            }
            if (local_21b == 'x') {
              uVar3 = *param_4 | 4;
LAB_00029c57:
              *param_4 = uVar3;
            }
          }
          local_238 = 0;
          param_1 = local_228;
          if (uVar4 <= local_228) goto LAB_00029c9b;
        }
        pcVar1 = fgets(local_218,0x200,__stream);
      } while (pcVar1 != (char *)0x0);
    }
LAB_00029c8f:
    local_238 = 0x3f1;
LAB_00029c9b:
    fclose(__stream);
    if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
LAB_00029cd8:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  return local_238;
}


// ==== FUN_00029ce0 @ 00029ce0

void FUN_00029ce0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00029a60(param_1,4,param_2,param_3);
  return;
}


// ==== FUN_00029d10 @ 00029d10

int FUN_00029d10(uint param_1,int param_2)

{
  long lVar1;
  long lVar2;
  long lVar3;
  long lVar4;
  int iVar5;
  int *piVar6;
  
  lVar1 = sysconf(0x27);
  lVar2 = sysconf(0x27);
  lVar3 = sysconf(0x27);
  lVar4 = sysconf(0x27);
  iVar5 = mprotect((void *)(-lVar1 & param_1),(lVar3 + (-lVar2 & param_1 + 3)) - (-lVar4 & param_1),
                   param_2);
  if (iVar5 == 0) {
    iVar5 = 0;
  }
  else {
    piVar6 = (int *)__errno();
    iVar5 = 0x3e9;
    if (*piVar6 != 0) {
      iVar5 = *piVar6;
    }
  }
  return iVar5;
}


// ==== FUN_00029db0 @ 00029db0

void FUN_00029db0(void)

{
  sysconf(0x27);
  sysconf(0x27);
  sysconf(0x27);
  return;
}


// ==== FUN_00029df0 @ 00029df0

char * FUN_00029df0(void)

{
  return "libxhook 1.2.0 (x86)";
}


// ==== FUN_00029e10 @ 00029e10

void FUN_00029e10(pthread_cond_t *param_1)

{
                    /* try { // try from 00029e29 to 00029e30 has its CatchHandler @ 00029e37 */
  pthread_cond_signal(param_1);
  return;
}


// ==== FUN_00029e40 @ 00029e40

void FUN_00029e40(pthread_cond_t *param_1)

{
                    /* try { // try from 00029e59 to 00029e60 has its CatchHandler @ 00029e67 */
  pthread_cond_destroy(param_1);
  return;
}


// ==== FUN_00029e70 @ 00029e70

void FUN_00029e70(void)

{
  return;
}


// ==== FUN_00029e80 @ 00029e80

void FUN_00029e80(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = param_1 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 != 0) {
      return;
    }
  }
  (**(code **)(*param_1 + 0x10))(param_1);
  return;
}


// ==== FUN_00029ed0 @ 00029ed0

void FUN_00029ed0(pthread_mutex_t *param_1)

{
  code *pcVar1;
  int iVar2;
  
  iVar2 = pthread_mutex_lock(param_1);
  if (iVar2 == 0) {
    return;
  }
  FUN_0002b8c0(iVar2,"mutex lock failed");
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_00029f10 @ 00029f10

void FUN_00029f10(pthread_mutex_t *param_1)

{
                    /* try { // try from 00029f29 to 00029f30 has its CatchHandler @ 00029f37 */
  pthread_mutex_unlock(param_1);
  return;
}


// ==== FUN_00029f40 @ 00029f40

void FUN_00029f40(pthread_mutex_t *param_1)

{
                    /* try { // try from 00029f59 to 00029f60 has its CatchHandler @ 00029f67 */
  pthread_mutex_destroy(param_1);
  return;
}


// ==== FUN_00029f70 @ 00029f70

void FUN_00029f70(size_t param_1)

{
  void *pvVar1;
  code *pcVar2;
  undefined4 uVar3;
  size_t __size;
  
  __size = 1;
  if (param_1 != 0) {
    __size = param_1;
  }
  while( true ) {
    pvVar1 = malloc(__size);
    if (pvVar1 != (void *)0x0) {
      return;
    }
    pcVar2 = (code *)FUN_0002c330();
    if (pcVar2 == (code *)0x0) break;
    (*pcVar2)();
  }
  uVar3 = FUN_0002bad0(4);
  FUN_00042ad0(uVar3);
  FUN_0002bb70(uVar3,&PTR_PTR_0004c488,FUN_00042a70);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}


// ==== FUN_0002a000 @ 0002a000

void FUN_0002a000(void *param_1)

{
  free(param_1);
  return;
}


// ==== FUN_0002a030 @ 0002a030

void FUN_0002a030(undefined4 *param_1,void *param_2)

{
  int iVar1;
  int *piVar2;
  
  *param_1 = &PTR_LAB_0004c49c;
                    /* try { // try from 0002a059 to 0002a075 has its CatchHandler @ 0002a0ab */
  iVar1 = __strlen_chk(param_2,0xffffffff);
  piVar2 = (int *)FUN_00029f70(iVar1 + 0xd);
  *piVar2 = iVar1;
  piVar2[1] = iVar1;
  piVar2[2] = 0;
  memcpy(piVar2 + 3,param_2,iVar1 + 1);
  param_1[1] = piVar2 + 3;
  return;
}


// ==== FUN_0002a0c0 @ 0002a0c0

void FUN_0002a0c0(undefined4 *param_1,byte *param_2)

{
  int iVar1;
  int *piVar2;
  
  *param_1 = &PTR_FUN_0004c4b0;
  if ((*param_2 & 1) == 0) {
    param_2 = param_2 + 1;
  }
  else {
    param_2 = *(byte **)(param_2 + 8);
  }
                    /* try { // try from 0002a0f6 to 0002a116 has its CatchHandler @ 0002a14d */
  iVar1 = __strlen_chk(param_2,0xffffffff);
  piVar2 = (int *)FUN_00029f70(iVar1 + 0xd);
  *piVar2 = iVar1;
  piVar2[1] = iVar1;
  piVar2[2] = 0;
  memcpy(piVar2 + 3,param_2,iVar1 + 1);
  param_1[1] = piVar2 + 3;
  return;
}


// ==== FUN_0002a170 @ 0002a170

void FUN_0002a170(undefined4 *param_1,void *param_2)

{
  int iVar1;
  int *piVar2;
  
  *param_1 = &PTR_FUN_0004c4b0;
                    /* try { // try from 0002a199 to 0002a1b5 has its CatchHandler @ 0002a1eb */
  iVar1 = __strlen_chk(param_2,0xffffffff);
  piVar2 = (int *)FUN_00029f70(iVar1 + 0xd);
  *piVar2 = iVar1;
  piVar2[1] = iVar1;
  piVar2[2] = 0;
  memcpy(piVar2 + 3,param_2,iVar1 + 1);
  param_1[1] = piVar2 + 3;
  return;
}


// ==== FUN_0002a200 @ 0002a200

void FUN_0002a200(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_000231e0("basic_string");
}


// ==== FUN_0002a230 @ 0002a230

void FUN_0002a230(void)

{
  code *pcVar1;
  
  FUN_0002a260("basic_string");
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_0002a260 @ 0002a260

void FUN_0002a260(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_0002bad0(8);
                    /* try { // try from 0002a289 to 0002a294 has its CatchHandler @ 0002a2b1 */
  FUN_0002aea0(uVar1,param_1);
  uVar2 = FUN_0002bb70(uVar1,&PTR_PTR_0004c4fc,&LAB_00042b50);
                    /* catch() { ... } // from try @ 0002a289 with catch @ 0002a2b1 */
  FUN_0002bb30(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_00043410(uVar2);
}


// ==== FUN_0002a2d0 @ 0002a2d0

void FUN_0002a2d0(uint *param_1,uint param_2,uint param_3,int param_4,size_t param_5,int param_6,
                 size_t param_7,void *param_8)

{
  uint uVar1;
  void *__dest;
  byte *__src;
  size_t __n;
  uint uVar2;
  
  if (-param_2 - 0x12 < param_3) {
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(param_1);
  }
  if ((*param_1 & 1) == 0) {
    __src = (byte *)((int)param_1 + 1);
  }
  else {
    __src = (byte *)param_1[2];
  }
  uVar2 = 0xffffffef;
  if (param_2 < 0x7fffffe7) {
    uVar1 = param_3 + param_2;
    if (param_3 + param_2 < param_2 * 2) {
      uVar1 = param_2 * 2;
    }
    uVar2 = 0xb;
    if (10 < uVar1) {
      uVar2 = uVar1 + 0x10 & 0xfffffff0;
    }
  }
  __dest = (void *)FUN_00029f70(uVar2);
  if (param_5 != 0) {
    memcpy(__dest,__src,param_5);
  }
  if (param_7 != 0) {
    memcpy((void *)(param_5 + (int)__dest),param_8,param_7);
  }
  __n = param_4 - (param_5 + param_6);
  if (__n != 0) {
    memcpy((void *)((int)__dest + param_7 + param_5),__src + param_6 + param_5,__n);
  }
  if (param_2 != 10) {
    FUN_0002a000(__src);
  }
  param_1[2] = (uint)__dest;
  *param_1 = uVar2 | 1;
  uVar2 = param_7 + param_5 + __n;
  param_1[1] = uVar2;
  *(undefined1 *)((int)__dest + uVar2) = 0;
  return;
}


// ==== FUN_0002a410 @ 0002a410

void FUN_0002a410(uint *param_1,byte *param_2)

{
  uint uVar1;
  void *__src;
  char *__dest;
  uint uVar2;
  
  if ((*param_2 & 1) == 0) {
    param_1[2] = *(uint *)(param_2 + 8);
    *(undefined8 *)param_1 = *(undefined8 *)param_2;
  }
  else {
    uVar1 = *(uint *)(param_2 + 4);
    __src = *(void **)(param_2 + 8);
    if (uVar1 < 0xb) {
      *(char *)param_1 = (char)uVar1 * '\x02';
      __dest = (char *)((int)param_1 + 1);
    }
    else {
      if (0xffffffef < uVar1) {
                    /* WARNING: Subroutine does not return */
        FUN_0002a200(param_1);
      }
      uVar2 = uVar1 + 0x10 & 0xfffffff0;
      __dest = (char *)FUN_00029f70(uVar2);
      param_1[2] = (uint)__dest;
      *param_1 = uVar2 | 1;
      param_1[1] = uVar1;
    }
    memcpy(__dest,__src,uVar1 + 1);
  }
  return;
}


// ==== FUN_0002a4b0 @ 0002a4b0

void FUN_0002a4b0(uint *param_1,uint param_2,uint param_3,int param_4,size_t param_5,int param_6,
                 int param_7)

{
  uint uVar1;
  void *__dest;
  byte *__src;
  size_t __n;
  uint uVar2;
  
  if (-param_2 - 0x11 < param_3) {
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(param_1);
  }
  if ((*param_1 & 1) == 0) {
    __src = (byte *)((int)param_1 + 1);
  }
  else {
    __src = (byte *)param_1[2];
  }
  uVar2 = 0xffffffef;
  if (param_2 < 0x7fffffe7) {
    uVar1 = param_3 + param_2;
    if (param_3 + param_2 < param_2 * 2) {
      uVar1 = param_2 * 2;
    }
    uVar2 = 0xb;
    if (10 < uVar1) {
      uVar2 = uVar1 + 0x10 & 0xfffffff0;
    }
  }
  __dest = (void *)FUN_00029f70(uVar2);
  if (param_5 != 0) {
    memcpy(__dest,__src,param_5);
  }
  __n = param_4 - (param_6 + param_5);
  if (__n != 0) {
    memcpy((void *)((int)__dest + param_7 + param_5),__src + param_6 + param_5,__n);
  }
  if (param_2 != 10) {
    FUN_0002a000(__src);
  }
  param_1[2] = (uint)__dest;
  *param_1 = uVar2 | 1;
  return;
}


// ==== FUN_0002a5b0 @ 0002a5b0

uint * FUN_0002a5b0(uint *param_1,uint param_2,byte *param_3,uint param_4)

{
  byte bVar1;
  code *pcVar2;
  uint *puVar3;
  int iVar4;
  byte *__src;
  uint uVar5;
  uint uVar6;
  byte *pbVar7;
  
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar6 = (uint)(bVar1 >> 1);
  }
  else {
    uVar6 = param_1[1];
  }
  if (uVar6 < param_2) {
    FUN_0002a230(param_1);
    pcVar2 = (code *)swi(3);
    puVar3 = (uint *)(*pcVar2)();
    return puVar3;
  }
  iVar4 = 10;
  if ((bVar1 & 1) != 0) {
    iVar4 = (*param_1 & 0xfffffffe) - 1;
  }
  if (iVar4 - uVar6 < param_4) {
    FUN_0002a2d0(param_1,iVar4,(uVar6 + param_4) - iVar4,uVar6,param_2,0,param_4,param_3);
  }
  else if (param_4 != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar7 = (byte *)((int)param_1 + 1);
    }
    else {
      pbVar7 = (byte *)param_1[2];
    }
    if (uVar6 - param_2 != 0) {
      __src = pbVar7 + param_2;
      uVar5 = 0;
      if (param_3 < pbVar7 + uVar6) {
        uVar5 = param_4;
      }
      if (param_3 < __src) {
        uVar5 = 0;
      }
      param_3 = param_3 + uVar5;
      memmove(__src + param_4,__src,uVar6 - param_2);
    }
    memmove(pbVar7 + param_2,param_3,param_4);
    uVar6 = uVar6 + param_4;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar6 * '\x02';
    }
    else {
      param_1[1] = uVar6;
    }
    pbVar7[uVar6] = 0;
  }
  return param_1;
}


// ==== FUN_0002a6e0 @ 0002a6e0

uint * FUN_0002a6e0(uint *param_1,void *param_2,uint param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  byte *pbVar4;
  
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar2 = (uint)(bVar1 >> 1);
    iVar3 = 10;
  }
  else {
    iVar3 = (*param_1 & 0xfffffffe) - 1;
    uVar2 = param_1[1];
  }
  if (iVar3 - uVar2 < param_3) {
    FUN_0002a2d0(param_1,iVar3,(param_3 + uVar2) - iVar3,uVar2,uVar2,0,param_3,param_2);
  }
  else if (param_3 != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar4 = (byte *)((int)param_1 + 1);
    }
    else {
      pbVar4 = (byte *)param_1[2];
    }
    memcpy(pbVar4 + uVar2,param_2,param_3);
    uVar2 = uVar2 + param_3;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar2 * '\x02';
    }
    else {
      param_1[1] = uVar2;
    }
    pbVar4[uVar2] = 0;
  }
  return param_1;
}


// ==== FUN_0002a7b0 @ 0002a7b0

void FUN_0002a7b0(undefined4 param_1,undefined4 param_2,char *param_3)

{
  size_t sVar1;
  
  sVar1 = strlen(param_3);
  FUN_0002a5b0(param_1,param_2,param_3,sVar1);
  return;
}


// ==== FUN_0002a7f0 @ 0002a7f0

void FUN_0002a7f0(uint *param_1,byte param_2)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  
  if (((byte)*param_1 & 1) == 0) {
    bVar1 = (byte)*param_1 >> 1;
    uVar3 = (uint)bVar1;
    uVar4 = 10;
    uVar2 = 10;
    if (bVar1 == 10) {
LAB_0002a836:
      uVar3 = uVar2;
      FUN_0002a4b0(param_1,uVar4,1,uVar4,uVar4,0,0,0x2a801);
      if ((*param_1 & 1) != 0) goto LAB_0002a863;
    }
    *(byte *)param_1 = (char)uVar3 * '\x02' + 2;
    pbVar5 = (byte *)((int)param_1 + 1);
  }
  else {
    uVar3 = param_1[1];
    uVar4 = (*param_1 & 0xfffffffe) - 1;
    uVar2 = uVar3;
    if (uVar3 == uVar4) goto LAB_0002a836;
LAB_0002a863:
    pbVar5 = (byte *)param_1[2];
    param_1[1] = uVar3 + 1;
  }
  pbVar5[uVar3] = param_2;
  pbVar5[uVar3 + 1] = 0;
  return;
}


// ==== FUN_0002a880 @ 0002a880

void FUN_0002a880(uint *param_1,uint param_2,byte param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  uint local_20;
  
  if (param_2 != 0) {
    uVar3 = *param_1;
    if (((byte)*param_1 & 1) == 0) {
      uVar2 = (uint)(byte)((byte)*param_1 >> 1);
      iVar1 = 10;
    }
    else {
      iVar1 = (uVar3 & 0xfffffffe) - 1;
      uVar2 = param_1[1];
    }
    if (iVar1 - uVar2 < param_2) {
      FUN_0002a4b0(param_1,iVar1,(uVar2 + param_2) - iVar1,uVar2,uVar2,0,0,0x2a891);
      uVar3 = (uint)(byte)*param_1;
    }
    local_20 = uVar2 + param_2;
    if ((uVar3 & 1) == 0) {
      pbVar4 = (byte *)((int)param_1 + 1);
    }
    else {
      pbVar4 = (byte *)param_1[2];
    }
    memset(pbVar4 + uVar2,(uint)param_3,param_2);
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)local_20 * '\x02';
    }
    else {
      param_1[1] = local_20;
    }
    pbVar4[local_20] = 0;
  }
  return;
}


// ==== FUN_0002a960 @ 0002a960

uint * FUN_0002a960(uint *param_1,char *param_2)

{
  byte bVar1;
  size_t __n;
  byte *pbVar2;
  int iVar3;
  uint uVar4;
  
  __n = strlen(param_2);
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar4 = (uint)(bVar1 >> 1);
    iVar3 = 10;
  }
  else {
    iVar3 = (*param_1 & 0xfffffffe) - 1;
    uVar4 = param_1[1];
  }
  if (iVar3 - uVar4 < __n) {
    FUN_0002a2d0(param_1,iVar3,(__n + uVar4) - iVar3,uVar4,uVar4,0,__n,param_2);
  }
  else if (__n != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar2 = (byte *)((int)param_1 + 1);
    }
    else {
      pbVar2 = (byte *)param_1[2];
    }
    memcpy(pbVar2 + uVar4,param_2,__n);
    uVar4 = __n + uVar4;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar4 * '\x02';
    }
    else {
      param_1[1] = uVar4;
    }
    pbVar2[uVar4] = 0;
  }
  return param_1;
}


// ==== FUN_0002aa30 @ 0002aa30

void FUN_0002aa30(byte *param_1,uint param_2,char param_3)

{
  byte bVar1;
  uint uVar2;
  
  bVar1 = *param_1;
  if ((bVar1 & 1) == 0) {
    uVar2 = (uint)(bVar1 >> 1);
  }
  else {
    uVar2 = *(uint *)(param_1 + 4);
  }
  if (uVar2 < param_2) {
    FUN_0002a880(param_1,param_2 - uVar2,(int)param_3,0x2aa3d);
  }
  else if ((bVar1 & 1) == 0) {
    param_1[param_2 + 1] = 0;
    *param_1 = (char)param_2 * '\x02';
  }
  else {
    *(undefined1 *)(*(int *)(param_1 + 8) + param_2) = 0;
    *(uint *)(param_1 + 4) = param_2;
  }
  return;
}


// ==== FUN_0002aaa0 @ 0002aaa0

uint * FUN_0002aaa0(uint *param_1,char *param_2,byte *param_3)

{
  byte bVar1;
  size_t __n;
  uint __n_00;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  
  param_1[1] = 0;
  *param_1 = 0;
  param_1[2] = 0;
  __n = strlen(param_2);
  bVar1 = *param_3;
  if ((bVar1 & 1) == 0) {
    __n_00 = (uint)(bVar1 >> 1);
  }
  else {
    __n_00 = *(uint *)(param_3 + 4);
  }
  uVar3 = __n_00 + __n;
  if (0xffffffef < uVar3) {
                    /* try { // try from 0002ac25 to 0002ac34 has its CatchHandler @ 0002ac35 */
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(param_1);
  }
  if (uVar3 < 0xb) {
    *(char *)param_1 = (char)__n * '\x02';
    pbVar4 = (byte *)((int)param_1 + 1);
  }
  else {
    uVar3 = uVar3 + 0x10 & 0xfffffff0;
                    /* try { // try from 0002ab21 to 0002ab30 has its CatchHandler @ 0002ac35 */
    pbVar4 = (byte *)FUN_00029f70(uVar3);
    param_1[2] = (uint)pbVar4;
    *param_1 = uVar3 | 1;
    param_1[1] = __n;
  }
  if (__n != 0) {
    memcpy(pbVar4,param_2,__n);
  }
  pbVar4[__n] = 0;
  if ((bVar1 & 1) == 0) {
    param_3 = param_3 + 1;
  }
  else {
    param_3 = *(byte **)(param_3 + 8);
  }
  bVar1 = (byte)*param_1;
  if ((bVar1 & 1) == 0) {
    uVar3 = (uint)(bVar1 >> 1);
    iVar2 = 10;
  }
  else {
    iVar2 = (*param_1 & 0xfffffffe) - 1;
    uVar3 = param_1[1];
  }
  if (iVar2 - uVar3 < __n_00) {
                    /* try { // try from 0002abaf to 0002abc6 has its CatchHandler @ 0002ac35 */
    FUN_0002a2d0(param_1,iVar2,(uVar3 + __n_00) - iVar2,uVar3,uVar3,0,__n_00,param_3);
  }
  else if (__n_00 != 0) {
    if ((bVar1 & 1) == 0) {
      pbVar4 = (byte *)((int)param_1 + 1);
    }
    else {
      pbVar4 = (byte *)param_1[2];
    }
    memcpy(pbVar4 + uVar3,param_3,__n_00);
    uVar3 = uVar3 + __n_00;
    if ((*param_1 & 1) == 0) {
      *(char *)param_1 = (char)uVar3 * '\x02';
    }
    else {
      param_1[1] = uVar3;
    }
    pbVar4[uVar3] = 0;
  }
  return param_1;
}


// ==== FUN_0002ac70 @ 0002ac70

/* WARNING: Type propagation algorithm not settling */

uint * FUN_0002ac70(uint *param_1,uint param_2)

{
  int *piVar1;
  undefined1 *puVar2;
  uint uVar3;
  uint uVar4;
  char *__dest;
  int in_GS_OFFSET;
  undefined4 local_23;
  int local_18 [2];
  
  local_18[0] = *(int *)(in_GS_OFFSET + 0x14);
  piVar1 = local_18;
  if ((int)param_2 < 0) {
    puVar2 = (undefined1 *)((int)&local_23 + 1);
    local_23._0_1_ = 0x2d;
    param_2 = -param_2;
  }
  else {
    puVar2 = (undefined1 *)&local_23;
  }
  if ((int)piVar1 - (int)puVar2 < 10) {
    uVar3 = 0x1f;
    if ((param_2 | 1) != 0) {
      for (; (param_2 | 1) >> uVar3 == 0; uVar3 = uVar3 - 1) {
      }
    }
    uVar3 = (uVar3 ^ 0xffffffe0) * 0x4d1 + 0x9ef1 >> 0xc;
    if ((int)piVar1 - (int)puVar2 <
        (int)((uVar3 - (param_2 < *(uint *)(&DAT_00015d98 + uVar3 * 4))) + 1)) goto LAB_0002ad03;
  }
  piVar1 = (int *)FUN_0002aee0(param_2,puVar2);
LAB_0002ad03:
  uVar3 = (int)piVar1 - (int)&local_23;
  if (0xffffffef < uVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(param_1);
  }
  if (uVar3 < 0xb) {
    *(char *)param_1 = (char)uVar3 * '\x02';
    __dest = (char *)((int)param_1 + 1);
  }
  else {
    uVar4 = uVar3 + 0x10 & 0xfffffff0;
    __dest = (char *)FUN_00029f70(uVar4);
    param_1[2] = (uint)__dest;
    *param_1 = uVar4 | 1;
    param_1[1] = uVar3;
  }
  if (&local_23 != piVar1) {
    memcpy(__dest,&local_23,uVar3);
    __dest = __dest + uVar3;
  }
  *__dest = '\0';
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18[0]) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_0002adc0 @ 0002adc0

uint * FUN_0002adc0(uint *param_1,undefined4 param_2)

{
  undefined1 *puVar1;
  uint __n;
  char *__dest;
  uint uVar2;
  int in_GS_OFFSET;
  undefined1 local_23 [11];
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  puVar1 = (undefined1 *)FUN_0002aee0(param_2,local_23);
  __n = (int)puVar1 - (int)local_23;
  if (0xffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(param_1);
  }
  if (__n < 0xb) {
    *(char *)param_1 = (char)__n * '\x02';
    __dest = (char *)((int)param_1 + 1);
  }
  else {
    uVar2 = __n + 0x10 & 0xfffffff0;
    __dest = (char *)FUN_00029f70(uVar2);
    param_1[2] = (uint)__dest;
    *param_1 = uVar2 | 1;
    param_1[1] = __n;
  }
  if (local_23 != puVar1) {
    memcpy(__dest,local_23,__n);
    __dest = __dest + __n;
  }
  *__dest = '\0';
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_0002aea0 @ 0002aea0

void FUN_0002aea0(undefined4 *param_1,undefined4 param_2)

{
  FUN_0002a030(param_1,param_2);
  *param_1 = &PTR_LAB_0004c4f0;
  return;
}


// ==== FUN_0002aee0 @ 0002aee0

char * FUN_0002aee0(uint param_1,char *param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 < 100000000) {
    param_2 = (char *)FUN_0002b000(param_2,param_1);
  }
  else {
    uVar2 = param_1 % 100000000;
    if (param_1 < 1000000000) {
      *param_2 = (char)(param_1 / 100000000) + '0';
      iVar1 = 1;
    }
    else {
      *(undefined2 *)param_2 =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (param_1 / 100000000) * 2);
      iVar1 = 2;
    }
    *(undefined2 *)(param_2 + iVar1) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (uVar2 / 1000000) * 2);
    *(undefined2 *)(param_2 + iVar1 + 2) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + (uVar2 / 10000 + (uVar2 / 1000000) * -100 & 0xffff) * 2);
    *(undefined2 *)(param_2 + iVar1 + 4) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + ((uVar2 % 10000) / 100) * 2);
    *(undefined2 *)(param_2 + iVar1 + 6) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + ((uVar2 % 10000) % 100) * 2);
    param_2 = param_2 + iVar1 + 8;
  }
  return param_2;
}


// ==== FUN_0002b000 @ 0002b000

char * FUN_0002b000(char *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  if (param_2 < 10000) {
    if (param_2 < 100) {
      if (param_2 < 10) {
        *param_1 = (char)param_2 + '0';
        param_1 = param_1 + 1;
      }
      else {
        *(undefined2 *)param_1 =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + param_2 * 2);
        param_1 = param_1 + 2;
      }
    }
    else {
      uVar3 = (param_2 & 0xffff) / 100;
      if (param_2 < 1000) {
        *param_1 = (char)uVar3 + '0';
        *(undefined2 *)(param_1 + 1) =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + ((param_2 & 0xffff) % 100) * 2);
        param_1 = param_1 + 3;
      }
      else {
        *(undefined2 *)param_1 =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + uVar3 * 2);
        *(undefined2 *)(param_1 + 2) =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + (param_2 + uVar3 * -100 & 0xffff) * 2);
        param_1 = param_1 + 4;
      }
    }
  }
  else {
    uVar3 = param_2 / 10000;
    if (param_2 < 1000000) {
      if (param_2 < 100000) {
        *param_1 = (char)uVar3 + '0';
        iVar1 = 1;
      }
      else {
        *(undefined2 *)param_1 =
             *(undefined2 *)
              (
              "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
              + uVar3 * 2);
        iVar1 = 2;
      }
    }
    else if (param_2 < 10000000) {
      uVar2 = (uVar3 & 0xffff) / 100;
      *param_1 = (char)uVar2 + '0';
      *(undefined2 *)(param_1 + 1) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (uVar3 + uVar2 * -100 & 0xffff) * 2);
      iVar1 = 3;
    }
    else {
      *(undefined2 *)param_1 =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (param_2 / 1000000) * 2);
      *(undefined2 *)(param_1 + 2) =
           *(undefined2 *)
            (
            "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
            + (uVar3 % 100) * 2);
      iVar1 = 4;
    }
    *(undefined2 *)(param_1 + iVar1) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + ((param_2 % 10000) / 100) * 2);
    *(undefined2 *)(param_1 + iVar1 + 2) =
         *(undefined2 *)
          (
          "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899NSt6__ndk112system_errorE"
          + ((param_2 % 10000) % 100) * 2);
    param_1 = param_1 + iVar1 + 4;
  }
  return param_1;
}


// ==== FUN_0002b290 @ 0002b290

uint * FUN_0002b290(uint *param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  char *pcVar3;
  size_t __n;
  char *__buf;
  uint uVar4;
  int in_GS_OFFSET;
  char local_418 [1024];
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  __buf = local_418;
  puVar2 = (undefined4 *)__errno();
  uVar1 = *puVar2;
  pcVar3 = strerror_r(param_3,__buf,0x400);
  if (pcVar3 != (char *)0x0) {
    if (pcVar3 == (char *)0xffffffff) {
      pcVar3 = (char *)*puVar2;
    }
    if (pcVar3 != (char *)0x16) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    __buf = "";
  }
  if (*__buf == '\0') {
    __buf = local_418;
    FUN_0002b9f0(__buf);
  }
  *puVar2 = uVar1;
  __n = strlen(__buf);
  if (0xffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(param_1);
  }
  if (__n < 0xb) {
    *(char *)param_1 = (char)__n * '\x02';
    pcVar3 = (char *)((int)param_1 + 1);
    if (__n == 0) goto LAB_0002b37e;
  }
  else {
    uVar4 = __n + 0x10 & 0xfffffff0;
    pcVar3 = (char *)FUN_00029f70(uVar4);
    param_1[2] = (uint)pcVar3;
    *param_1 = uVar4 | 1;
    param_1[1] = __n;
  }
  memcpy(pcVar3,__buf,__n);
LAB_0002b37e:
  pcVar3[__n] = '\0';
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}


// ==== FUN_0002b5c0 @ 0002b5c0

void FUN_0002b5c0(undefined8 *param_1,int *param_2,uint *param_3)

{
  int iVar1;
  uint **ppuVar2;
  int in_GS_OFFSET;
  uint *local_44;
  uint *local_40;
  int *local_3c;
  int local_38;
  byte local_2c;
  undefined1 local_2b [3];
  uint local_28;
  uint *local_24;
  undefined4 local_18;
  
  ppuVar2 = &local_40;
  local_44 = (uint *)0x2b5d1;
  local_18 = *(undefined4 *)(in_GS_OFFSET + 0x14);
  iVar1 = *param_2;
  if (iVar1 == 0) goto LAB_0002b673;
  if (((byte)*param_3 & 1) == 0) {
    if ((byte)((byte)*param_3 >> 1) != 0) goto LAB_0002b609;
  }
  else if (param_3[1] != 0) {
LAB_0002b609:
    local_3c = (int *)&DAT_00014988;
    local_40 = param_3;
    local_44 = (uint *)0x2b61b;
    FUN_0002a960();
    iVar1 = *param_2;
  }
  local_3c = (int *)param_2[1];
  local_40 = &local_28;
  local_44 = (uint *)0x2b634;
  local_38 = iVar1;
  (**(code **)(*local_3c + 0x18))();
  if ((local_2c & 1) == 0) {
    local_28 = (uint)(local_2c >> 1);
    local_40 = (uint *)local_2b;
  }
  else {
    local_40 = local_24;
  }
                    /* try { // try from 0002b650 to 0002b65f has its CatchHandler @ 0002b6b4 */
  local_44 = param_3;
  local_3c = (int *)local_28;
  FUN_0002a6e0();
  ppuVar2 = &local_44;
  if ((local_2c & 1) != 0) {
    local_44 = local_24;
    FUN_0002a000();
    ppuVar2 = &local_44;
  }
LAB_0002b673:
  *(uint *)(param_1 + 1) = param_3[2];
  *param_1 = *(undefined8 *)param_3;
  param_3[1] = 0;
  *param_3 = 0;
  param_3[2] = 0;
  if (*(int *)(in_GS_OFFSET + 0x14) != *(int *)((int)ppuVar2 + 0x28)) {
                    /* WARNING: Subroutine does not return */
    *(undefined1 **)((int)ppuVar2 + -4) = &LAB_0002b6b4;
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0002b6e0 @ 0002b6e0

void FUN_0002b6e0(undefined4 *param_1,undefined8 param_2,char *param_3)

{
  size_t __n;
  void *__dest;
  uint uVar1;
  char *__src;
  int in_GS_OFFSET;
  byte local_3c;
  undefined4 local_38;
  size_t local_34;
  void *local_30;
  byte local_2c;
  undefined1 local_28 [4];
  undefined4 local_24;
  int local_1c;
  undefined4 local_18;
  
  __src = param_3;
  local_18 = *(undefined4 *)(in_GS_OFFSET + 0x14);
  __n = strlen(param_3);
  if (0xffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0002a200(&local_38);
  }
  if (__n < 0xb) {
    local_38 = CONCAT31(local_38._1_3_,(char)__n * '\x02');
    __dest = (void *)((int)&local_38 + 1);
    if (__n == 0) goto LAB_0002b76b;
  }
  else {
    uVar1 = __n + 0x10 & 0xfffffff0;
    __dest = (void *)FUN_00029f70(uVar1);
    local_38 = uVar1 | 1;
    __src = param_3;
    local_34 = __n;
    local_30 = __dest;
  }
  memcpy(__dest,__src,__n);
LAB_0002b76b:
  *(undefined1 *)((int)__dest + __n) = 0;
                    /* try { // try from 0002b76f to 0002b78c has its CatchHandler @ 0002b82b */
  FUN_0002b5c0(local_28,&param_2,&local_38);
                    /* try { // try from 0002b790 to 0002b79b has its CatchHandler @ 0002b7fe */
  FUN_0002a0c0(param_1,local_28);
  if ((local_2c & 1) != 0) {
    FUN_0002a000(local_24);
  }
  if ((local_3c & 1) != 0) {
    FUN_0002a000(local_34);
  }
  *param_1 = &PTR_LAB_0004b27c;
  *(undefined8 *)(param_1 + 2) = param_2;
  if (*(int *)(in_GS_OFFSET + 0x14) != local_1c) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0002b8c0 @ 0002b8c0

void FUN_0002b8c0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_0002bad0(0x10);
  if (DAT_00050924 == '\0') goto LAB_0002b938;
  do {
                    /* try { // try from 0002b901 to 0002b91b has its CatchHandler @ 0002b968 */
    FUN_0002b6e0(uVar1,CONCAT44(&DAT_00050920,param_1),param_2);
    FUN_0002bb70(uVar1,&DAT_0004b288,&LAB_0002b850);
LAB_0002b938:
    iVar2 = FUN_0002bf60(&DAT_00050924);
    if (iVar2 != 0) {
      DAT_00050920 = &PTR_LAB_0004b2e0;
      FUN_0002c0c0(&DAT_00050924);
    }
  } while( true );
}


// ==== FUN_0002b9f0 @ 0002b9f0

void FUN_0002b9f0(char *param_1)

{
  int iVar1;
  int in_GS_OFFSET;
  undefined1 uStack00000014;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  vsnprintf(param_1,0x400,"Unknown error %d",&uStack00000014);
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_0002ba50 @ 0002ba50

void FUN_0002ba50(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_000231e0("vector");
}


// ==== FUN_0002ba80 @ 0002ba80

undefined8 FUN_0002ba80(undefined8 *param_1)

{
  return *param_1;
}


// ==== FUN_0002baa0 @ 0002baa0

bool FUN_0002baa0(int param_1)

{
  return *(uint *)(param_1 + 4) >> 8 == 0x434c4e && *(int *)(param_1 + 1) == 0x47432b2b;
}


// ==== FUN_0002bad0 @ 0002bad0

int FUN_0002bad0(int param_1)

{
  void *__s;
  uint __n;
  
  __n = param_1 + 0x5fU & 0xfffffff0;
                    /* try { // try from 0002baf1 to 0002baf8 has its CatchHandler @ 0002bb25 */
  __s = (void *)FUN_00042040(__n);
  if (__s == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_0002c220();
  }
  memset(__s,0,__n);
  return (int)__s + 0x50;
}


// ==== FUN_0002bb30 @ 0002bb30

void FUN_0002bb30(int param_1)

{
                    /* try { // try from 0002bb4c to 0002bb53 has its CatchHandler @ 0002bb5a */
  FUN_000421b0(param_1 + -0x50);
  return;
}


// ==== FUN_0002bb70 @ 0002bb70

void FUN_0002bb70(int param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar2 = FUN_0002bf00();
  iVar4 = param_1 + -0x50;
  uVar3 = FUN_0002c200();
  *(undefined4 *)(param_1 + -0x48) = uVar3;
  uVar3 = FUN_0002c2b0();
  *(undefined4 *)(param_1 + -0x44) = uVar3;
  *(undefined4 *)(param_1 + -0x50) = param_2;
  *(undefined4 *)(param_1 + -0x4c) = param_3;
  FUN_0002bbf0();
  *(undefined4 *)(param_1 + -0x24) = 1;
  *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
  *(undefined1 **)(param_1 + -0x18) = &LAB_0002bc10;
  FUN_000431e0(param_1 + -0x20,iVar2,iVar4);
  FUN_0002bc80();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_0002bbf0 @ 0002bbf0

void FUN_0002bbf0(void)

{
  undefined4 *in_ECX;
  
  in_ECX[1] = 0x434c4e47;
  *in_ECX = 0x432b2b00;
  return;
}


// ==== FUN_0002bc80 @ 0002bc80

void FUN_0002bc80(void)

{
  code *pcVar1;
  int in_ECX;
  
  FUN_0002bcb0(in_ECX + 0x30);
  FUN_0002c2d0(*(undefined4 *)(in_ECX + 0xc));
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_0002bcb0 @ 0002bcb0

uint * FUN_0002bcb0(uint *param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  
  uVar4 = *param_1;
  uVar2 = param_1[1];
                    /* try { // try from 0002bcd0 to 0002bcd4 has its CatchHandler @ 0002bd35 */
  piVar3 = (int *)FUN_0002bf00();
  puVar1 = param_1 + -0xc;
  if (uVar2 >> 8 == 0x434c4e && (uVar4 >> 8 | uVar2 << 0x18) == 0x47432b2b) {
    uVar4 = -param_1[-7];
    if ((int)uVar4 < 0) {
      uVar4 = param_1[-7];
    }
    param_1[-7] = uVar4 + 1;
    if ((uint *)*piVar3 != puVar1) {
      param_1[-8] = (uint)*piVar3;
      *piVar3 = (int)puVar1;
    }
    piVar3[1] = piVar3[1] + -1;
    param_1 = (uint *)param_1[-2];
  }
  else {
    if (*piVar3 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)puVar1;
    param_1 = param_1 + 8;
  }
  return param_1;
}


// ==== FUN_0002bd40 @ 0002bd40

void FUN_0002bd40(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = (int *)FUN_0002bf30();
  iVar2 = *piVar1;
  if (iVar2 == 0) {
    return;
  }
  if (*(uint *)(iVar2 + 0x34) >> 8 == 0x434c4e && *(int *)(iVar2 + 0x31) == 0x47432b2b) {
    iVar3 = *(int *)(iVar2 + 0x14);
    if (-1 < iVar3) {
      *(int *)(iVar2 + 0x14) = iVar3 + -1;
      if (iVar3 + -1 != 0) {
        return;
      }
      *piVar1 = *(int *)(iVar2 + 0x10);
      iVar3 = iVar2;
      if (*(char *)(iVar2 + 0x30) == '\x01') {
        iVar3 = *(int *)(iVar2 + 0x2c) + -0x50;
        FUN_000421b0(iVar2);
      }
      LOCK();
      piVar1 = (int *)(iVar3 + 0x2c);
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (*piVar1 != 0) {
        return;
      }
      if (*(code **)(iVar3 + 4) != (code *)0x0) {
                    /* try { // try from 0002bdb8 to 0002bdbc has its CatchHandler @ 0002bde9 */
        (**(code **)(iVar3 + 4))(iVar3 + 0x50);
      }
                    /* try { // try from 0002bdbd to 0002bdc4 has its CatchHandler @ 0002bdf1 */
      FUN_000421b0(iVar3);
      return;
    }
    *(int *)(iVar2 + 0x14) = iVar3 + 1;
    if (iVar3 + 1 != 0) {
      return;
    }
    iVar2 = *(int *)(iVar2 + 0x10);
  }
  else {
    FUN_00043610(iVar2 + 0x30);
    iVar2 = 0;
  }
  *piVar1 = iVar2;
  return;
}


// ==== FUN_0002be00 @ 0002be00

void FUN_0002be00(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  
  piVar4 = (int *)FUN_0002bf00();
  iVar1 = *piVar4;
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0x34);
    uVar6 = *(uint *)(iVar1 + 0x30) & 0xffffff00;
    if (iVar2 == 0x434c4e47 && uVar6 == 0x432b2b00) {
      *(int *)(iVar1 + 0x14) = -*(int *)(iVar1 + 0x14);
      piVar4[1] = piVar4[1] + 1;
    }
    else {
      *piVar4 = 0;
    }
    FUN_000431e0((uint *)(iVar1 + 0x30));
    uVar3 = *(uint *)(iVar1 + 0x30);
    iVar7 = *(int *)(iVar1 + 0x34);
                    /* try { // try from 0002be72 to 0002be76 has its CatchHandler @ 0002bef5 */
    piVar4 = (int *)FUN_0002bf00();
    if ((uVar3 & 0xffffff00) == 0x432b2b00 && iVar7 == 0x434c4e47) {
      iVar7 = -*(int *)(iVar1 + 0x14);
      if (iVar7 < 0) {
        iVar7 = *(int *)(iVar1 + 0x14);
      }
      *(int *)(iVar1 + 0x14) = iVar7 + 1;
      if (*piVar4 != iVar1) {
        *(int *)(iVar1 + 0x10) = *piVar4;
        *piVar4 = iVar1;
      }
      piVar4[1] = piVar4[1] + -1;
    }
    else {
      if (*piVar4 != 0) goto LAB_0002be23;
      *piVar4 = iVar1;
    }
    if (iVar2 == 0x434c4e47 && uVar6 == 0x432b2b00) {
      uVar5 = FUN_0002c2d0(*(undefined4 *)(iVar1 + 0xc));
                    /* catch() { ... } // from try @ 0002be72 with catch @ 0002bef5 */
                    /* WARNING: Subroutine does not return */
      FUN_00041b70(uVar5);
    }
  }
LAB_0002be23:
                    /* WARNING: Subroutine does not return */
  FUN_0002c220();
}


// ==== FUN_0002bf00 @ 0002bf00

void FUN_0002bf00(void)

{
  FUN_00042e80(&DAT_00050858);
  return;
}


// ==== FUN_0002bf30 @ 0002bf30

void FUN_0002bf30(void)

{
  FUN_00042e80(&DAT_00050858);
  return;
}


// ==== FUN_0002bf60 @ 0002bf60

undefined4 FUN_0002bf60(char *param_1)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  undefined4 uVar4;
  long local_18;
  
  if (*param_1 != '\0') {
    return 0;
  }
  iVar3 = pthread_mutex_lock((pthread_mutex_t *)&DAT_0005092c);
  if (iVar3 == 0) {
    bVar1 = param_1[1];
                    /* try { // try from 0002bfaf to 0002bfba has its CatchHandler @ 0002c070 */
    if (((bVar1 & 2) != 0) &&
       (iVar3 = *(int *)(param_1 + 4), local_18 = syscall(0xe0), iVar3 == local_18))
    goto LAB_0002c062;
    while (bVar2 = param_1[1], (bVar2 & 2) != 0) {
      param_1[1] = bVar2 | 4;
                    /* try { // try from 0002bfdd to 0002bfec has its CatchHandler @ 0002c07a */
      pthread_cond_wait((pthread_cond_t *)&DAT_00050930,(pthread_mutex_t *)&DAT_0005092c);
    }
    uVar4 = 0;
    if (bVar2 != 1) {
      if ((bVar1 & 2) == 0) {
                    /* try { // try from 0002c000 to 0002c00b has its CatchHandler @ 0002c070 */
        local_18 = syscall(0xe0);
      }
      *(long *)(param_1 + 4) = local_18;
      param_1[1] = '\x02';
      uVar4 = 1;
    }
                    /* try { // try from 0002c018 to 0002c023 has its CatchHandler @ 0002c072 */
    iVar3 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_0005092c);
    if (iVar3 == 0) {
      return uVar4;
    }
  }
  else {
    FUN_0002c180("%s failed to acquire mutex","__cxa_guard_acquire");
  }
                    /* try { // try from 0002c04a to 0002c061 has its CatchHandler @ 0002c072 */
  FUN_0002c180("%s failed to release mutex","__cxa_guard_acquire");
LAB_0002c062:
                    /* try { // try from 0002c062 to 0002c06f has its CatchHandler @ 0002c070 */
  uVar4 = FUN_0002c180("__cxa_guard_acquire detected recursive initialization");
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0002bfaf with catch @ 0002c070
                       catch(type#1 @ 00000000) { ... } // from try @ 0002c000 with catch @ 0002c070
                       catch(type#1 @ 00000000) { ... } // from try @ 0002c062 with catch @ 0002c070
                        */
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0002bfdd with catch @ 0002c07a
                        */
                    /* try { // try from 0002c07c to 0002c087 has its CatchHandler @ 0002c0ac */
  iVar3 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_0005092c);
  if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_00043410(uVar4);
  }
                    /* try { // try from 0002c094 to 0002c0ab has its CatchHandler @ 0002c0ac */
  uVar4 = FUN_0002c180("%s failed to release mutex","__cxa_guard_acquire");
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0002c07c with catch @ 0002c0ac
                       catch(type#1 @ 00000000) { ... } // from try @ 0002c094 with catch @ 0002c0ac
                        */
                    /* WARNING: Subroutine does not return */
  FUN_000227c0(uVar4);
}


// ==== FUN_0002c0c0 @ 0002c0c0

void FUN_0002c0c0(undefined1 *param_1)

{
  byte bVar1;
  int iVar2;
  undefined4 uVar3;
  
  *param_1 = 1;
  iVar2 = pthread_mutex_lock((pthread_mutex_t *)&DAT_0005092c);
  if (iVar2 == 0) {
    bVar1 = param_1[1];
    param_1[1] = 1;
                    /* try { // try from 0002c0fb to 0002c102 has its CatchHandler @ 0002c170 */
    iVar2 = pthread_mutex_unlock((pthread_mutex_t *)&DAT_0005092c);
    if (iVar2 == 0) {
      if ((bVar1 & 4) == 0) {
        return;
      }
      iVar2 = pthread_cond_broadcast((pthread_cond_t *)&DAT_00050930);
      if (iVar2 == 0) {
        return;
      }
      goto LAB_0002c158;
    }
  }
  else {
    FUN_0002c180("%s failed to acquire mutex","__cxa_guard_release");
  }
                    /* try { // try from 0002c140 to 0002c157 has its CatchHandler @ 0002c170 */
  FUN_0002c180("%s failed to release mutex","__cxa_guard_release");
LAB_0002c158:
  uVar3 = FUN_0002c180("%s failed to broadcast","__cxa_guard_release");
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0002c0fb with catch @ 0002c170
                       catch(type#1 @ 00000000) { ... } // from try @ 0002c140 with catch @ 0002c170
                        */
                    /* WARNING: Subroutine does not return */
  FUN_000227c0(uVar3);
}


// ==== FUN_0002c180 @ 0002c180

void FUN_0002c180(char *param_1,undefined1 param_2)

{
  code *pcVar1;
  char *local_20;
  undefined1 *local_1c;
  undefined1 *local_18;
  
  local_18 = &param_2;
  vfprintf((FILE *)0x511ac,param_1,&param_2);
  fputc(10,(FILE *)0x511ac);
  local_1c = &param_2;
  vasprintf(&local_20,param_1,&param_2);
  __assert2("/buildbot/src/android/ndk-r25-release/toolchain/llvm-project/libcxx/../../../toolchain/llvm-project/libcxxabi/src/abort_message.cpp"
            ,0x48,"abort_message",local_20);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_0002c200 @ 0002c200

undefined * FUN_0002c200(void)

{
  return PTR_LAB_0005086c;
}


// ==== FUN_0002c220 @ 0002c220

void FUN_0002c220(void)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  int unaff_ESI;
  
                    /* try { // try from 0002c22f to 0002c233 has its CatchHandler @ 0002c270 */
  piVar2 = (int *)FUN_0002bf30();
  if ((piVar2 != (int *)0x0) && (unaff_ESI = *piVar2, unaff_ESI != 0)) goto LAB_0002c24e;
  do {
    FUN_0002c2d0(PTR_LAB_00050868);
LAB_0002c24e:
                    /* try { // try from 0002c251 to 0002c258 has its CatchHandler @ 0002c268 */
    cVar1 = FUN_0002baa0(unaff_ESI + 0x30);
  } while (cVar1 == '\0');
  uVar3 = FUN_0002c2d0(*(undefined4 *)(unaff_ESI + 0xc));
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0002c251 with catch @ 0002c268
                        */
                    /* WARNING: Subroutine does not return */
  FUN_000227c0(uVar3);
}


// ==== FUN_0002c280 @ 0002c280

void FUN_0002c280(code *param_1)

{
  code *pcVar1;
  
  (*param_1)();
  FUN_0002c180("unexpected_handler unexpectedly returned");
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}


// ==== FUN_0002c2b0 @ 0002c2b0

undefined * FUN_0002c2b0(void)

{
  return PTR_LAB_00050868;
}


// ==== FUN_0002c2d0 @ 0002c2d0

void FUN_0002c2d0(code *param_1)

{
  undefined4 uVar1;
  
                    /* try { // try from 0002c2e7 to 0002c2f7 has its CatchHandler @ 0002c2f8 */
  (*param_1)();
  uVar1 = FUN_0002c180("terminate_handler unexpectedly returned");
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0002c2e7 with catch @ 0002c2f8
                        */
  FUN_0002bcb0(uVar1);
                    /* try { // try from 0002c300 to 0002c30d has its CatchHandler @ 0002c30e */
  uVar1 = FUN_0002c180("terminate_handler unexpectedly threw an exception");
                    /* catch(type#1 @ 00000000) { ... } // from try @ 0002c300 with catch @ 0002c30e
                        */
                    /* try { // try from 0002c310 to 0002c314 has its CatchHandler @ 0002c31d */
  FUN_0002bd40();
                    /* WARNING: Subroutine does not return */
  FUN_000227c0(uVar1);
}


// ==== FUN_0002c330 @ 0002c330

undefined4 FUN_0002c330(void)

{
  return DAT_00050934;
}


// ==== FUN_0002c490 @ 0002c490

void * FUN_0002c490(char *param_1,void *param_2,uint *param_3,undefined4 *param_4)

{
  char *pcVar1;
  undefined4 *puVar2;
  size_t sVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  char *pcVar7;
  char *pcVar8;
  uint uVar9;
  int iVar10;
  char *pcVar11;
  void *pvVar12;
  int in_GS_OFFSET;
  char *local_11e0;
  void *local_11d8;
  void *local_11d0;
  uint local_11cc;
  size_t sStack_11c8;
  undefined4 uStack_11c4;
  undefined4 uStack_11c0;
  int local_11bc;
  char *local_11b8;
  char *local_11b4;
  undefined4 *local_11b0;
  undefined4 *local_11ac;
  undefined4 **local_11a8;
  undefined4 local_11a4;
  undefined4 uStack_11a0;
  undefined4 uStack_119c;
  undefined4 uStack_1198;
  undefined4 local_1194;
  undefined4 uStack_1190;
  undefined4 uStack_118c;
  undefined4 uStack_1188;
  undefined4 local_1184;
  undefined4 uStack_1180;
  undefined4 uStack_117c;
  undefined4 uStack_1178;
  undefined4 local_1174;
  undefined4 uStack_1170;
  undefined4 uStack_116c;
  undefined4 uStack_1168;
  undefined4 local_1164;
  undefined4 uStack_1160;
  undefined4 uStack_115c;
  undefined4 uStack_1158;
  undefined4 local_1154;
  undefined4 uStack_1150;
  undefined4 uStack_114c;
  undefined4 uStack_1148;
  undefined4 local_1144;
  undefined4 uStack_1140;
  undefined4 uStack_113c;
  undefined4 uStack_1138;
  undefined4 local_1134;
  undefined4 uStack_1130;
  undefined4 uStack_112c;
  undefined4 uStack_1128;
  undefined4 *local_1124;
  undefined4 *local_1120;
  undefined4 **local_111c;
  undefined4 local_1118;
  undefined4 uStack_1114;
  undefined4 uStack_1110;
  undefined4 uStack_110c;
  undefined4 local_1108;
  undefined4 uStack_1104;
  undefined4 uStack_1100;
  undefined4 uStack_10fc;
  undefined4 local_10f8;
  undefined4 uStack_10f4;
  undefined4 uStack_10f0;
  undefined4 uStack_10ec;
  undefined4 local_10e8;
  undefined4 uStack_10e4;
  undefined4 uStack_10e0;
  undefined4 uStack_10dc;
  undefined4 local_10d8;
  undefined4 uStack_10d4;
  undefined4 uStack_10d0;
  undefined4 uStack_10cc;
  undefined4 local_10c8;
  undefined4 uStack_10c4;
  undefined4 uStack_10c0;
  undefined4 uStack_10bc;
  undefined4 local_10b8;
  undefined4 uStack_10b4;
  undefined4 uStack_10b0;
  undefined4 uStack_10ac;
  undefined4 local_10a8;
  undefined4 uStack_10a4;
  undefined4 uStack_10a0;
  undefined4 uStack_109c;
  undefined4 *local_1098;
  undefined4 *local_1094;
  undefined4 **local_1090;
  undefined4 local_108c;
  undefined4 uStack_1088;
  undefined4 uStack_1084;
  undefined4 uStack_1080;
  undefined4 local_107c;
  undefined4 uStack_1078;
  undefined4 uStack_1074;
  undefined4 uStack_1070;
  undefined4 *local_106c;
  undefined4 *local_1068;
  undefined4 **local_1064;
  undefined4 local_1060;
  undefined4 uStack_105c;
  undefined4 uStack_1058;
  undefined4 uStack_1054;
  undefined4 *local_1050;
  undefined4 *local_104c;
  undefined2 *local_1048;
  undefined4 local_1044;
  undefined4 uStack_1040;
  undefined4 uStack_103c;
  undefined4 uStack_1038;
  undefined2 local_1034 [2];
  undefined4 local_1030;
  undefined4 local_102c;
  undefined4 uStack_1028;
  undefined4 uStack_1024;
  undefined4 uStack_1020;
  undefined4 local_101c;
  undefined4 *local_20;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if ((param_1 == (char *)0x0) || ((param_2 != (void *)0x0 && (param_3 == (uint *)0x0)))) {
    pvVar12 = (void *)0x0;
    if (param_4 != (undefined4 *)0x0) {
      *param_4 = 0xfffffffd;
    }
    goto LAB_0002cad8;
  }
  local_11d8 = param_2;
  sVar3 = strlen(param_1);
  local_11b4 = param_1 + sVar3;
  local_11b8 = param_1;
  local_11b0 = &local_11a4;
  local_11a8 = &local_1124;
  local_11a4 = 0;
  uStack_11a0 = 0;
  uStack_119c = 0;
  uStack_1198 = 0;
  local_1194 = 0;
  uStack_1190 = 0;
  uStack_118c = 0;
  uStack_1188 = 0;
  local_1184 = 0;
  uStack_1180 = 0;
  uStack_117c = 0;
  uStack_1178 = 0;
  local_1174 = 0;
  uStack_1170 = 0;
  uStack_116c = 0;
  uStack_1168 = 0;
  local_1164 = 0;
  uStack_1160 = 0;
  uStack_115c = 0;
  uStack_1158 = 0;
  local_1154 = 0;
  uStack_1150 = 0;
  uStack_114c = 0;
  uStack_1148 = 0;
  local_1144 = 0;
  uStack_1140 = 0;
  uStack_113c = 0;
  uStack_1138 = 0;
  local_1134 = 0;
  uStack_1130 = 0;
  uStack_112c = 0;
  uStack_1128 = 0;
  local_1124 = &local_1118;
  local_111c = &local_1098;
  local_1118 = 0;
  uStack_1114 = 0;
  uStack_1110 = 0;
  uStack_110c = 0;
  local_1108 = 0;
  uStack_1104 = 0;
  uStack_1100 = 0;
  uStack_10fc = 0;
  local_10f8 = 0;
  uStack_10f4 = 0;
  uStack_10f0 = 0;
  uStack_10ec = 0;
  local_10e8 = 0;
  uStack_10e4 = 0;
  uStack_10e0 = 0;
  uStack_10dc = 0;
  local_10d8 = 0;
  uStack_10d4 = 0;
  uStack_10d0 = 0;
  uStack_10cc = 0;
  local_10c8 = 0;
  uStack_10c4 = 0;
  uStack_10c0 = 0;
  uStack_10bc = 0;
  local_10b8 = 0;
  uStack_10b4 = 0;
  uStack_10b0 = 0;
  uStack_10ac = 0;
  local_10a8 = 0;
  uStack_10a4 = 0;
  uStack_10a0 = 0;
  uStack_109c = 0;
  local_1098 = &local_108c;
  local_1090 = &local_106c;
  local_108c = 0;
  uStack_1088 = 0;
  uStack_1084 = 0;
  uStack_1080 = 0;
  local_107c = 0;
  uStack_1078 = 0;
  uStack_1074 = 0;
  uStack_1070 = 0;
  local_106c = &local_1060;
  local_1064 = &local_1050;
  local_1060 = 0;
  uStack_105c = 0;
  uStack_1058 = 0;
  uStack_1054 = 0;
  local_1050 = &local_1044;
  local_1048 = local_1034;
  local_1044 = 0;
  uStack_1040 = 0;
  uStack_103c = 0;
  uStack_1038 = 0;
  local_1034[0] = 1;
  local_1030 = 0xffffffff;
  local_102c = 0;
  uStack_1028 = 0;
  uStack_1024 = 0;
  uStack_1020 = 0;
  local_101c = 0;
  local_11d0 = (void *)0x0;
  local_11cc = 0;
  sStack_11c8 = 0;
  uStack_11c4 = 0xffffffff;
  uStack_11c0 = 0xffffffff;
  local_11ac = local_11b0;
  local_1120 = local_1124;
  local_1094 = local_1098;
  local_1068 = local_106c;
  local_104c = local_1050;
  local_20 = &uStack_1020;
  if ((sVar3 < 2) || (*param_1 != '_')) {
LAB_0002c791:
    piVar4 = (int *)FUN_0002d6e0();
    if (local_11b4 == local_11b8) {
LAB_0002c953:
      if (piVar4 != (int *)0x0) goto LAB_0002c95b;
    }
    uVar6 = 0xfffffffe;
    pvVar12 = (void *)0x0;
  }
  else {
    iVar10 = 2;
    if (param_1[1] != 'Z') {
      if ((sVar3 < 3) || (param_1[1] != '_')) goto LAB_0002c791;
      iVar10 = 3;
      if (param_1[2] == 'Z') goto LAB_0002c6bf;
      if ((sVar3 < 4) ||
         (((param_1[2] != '_' || (iVar10 = 4, param_1[3] != 'Z')) &&
          ((sVar3 < 5 ||
           (((param_1[2] != '_' || (param_1[3] != '_')) || (iVar10 = 5, param_1[4] != 'Z'))))))))
      goto LAB_0002c791;
      local_11b8 = param_1 + iVar10;
      local_11bc = FUN_0002cc90();
      piVar4 = (int *)0x0;
      if (local_11bc != 0) {
        if ((((uint)((int)local_11b4 - (int)local_11b8) < 0xd) || (*local_11b8 != '_')) ||
           ((((local_11b8[1] != 'b' || ((local_11b8[2] != 'l' || (local_11b8[3] != 'o')))) ||
             (local_11b8[4] != 'c')) ||
            (((((local_11b8[5] != 'k' || (local_11b8[6] != '_')) || (local_11b8[7] != 'i')) ||
              ((local_11b8[8] != 'n' || (local_11b8[9] != 'v')))) ||
             ((local_11b8[10] != 'o' || (local_11b8[0xb] != 'k')))))))) {
LAB_0002c951:
          piVar4 = (int *)0x0;
        }
        else {
          piVar4 = (int *)0x0;
          if (local_11b8[0xc] == 'e') {
            pcVar1 = local_11b8 + 0xd;
            if (pcVar1 != local_11b4) {
              pcVar8 = pcVar1;
              if (*pcVar1 == '_') {
                pcVar8 = local_11b8 + 0xe;
              }
              local_11b8 = pcVar8;
              local_11e0 = (char *)0x0;
              pcVar8 = local_11b4;
              pcVar11 = (char *)0x0;
              if (local_11b4 != local_11b8) {
                pcVar7 = local_11b8;
                if ((int)*local_11b8 - 0x3aU < 0xfffffff6) {
                  local_11e0 = (char *)0x0;
                  pcVar8 = local_11b8;
                  pcVar11 = (char *)0x0;
                }
                else {
                  do {
                    pcVar7 = pcVar7 + 1;
                    local_11e0 = local_11b8;
                    if (pcVar7 == local_11b4) {
                      pcVar11 = local_11b4;
                      local_11b8 = pcVar7;
                      goto LAB_0002c93c;
                    }
                  } while (0xfffffff5 < (int)*pcVar7 - 0x3aU);
                  pcVar8 = pcVar7;
                  pcVar11 = pcVar7;
                  local_11b8 = pcVar7;
                }
              }
LAB_0002c93c:
              if ((*pcVar1 == '_') && (local_11e0 == pcVar11)) goto LAB_0002c951;
              pcVar1 = local_11b8;
              if (local_11b4 != pcVar8) {
                piVar4 = (int *)0x0;
                if (*pcVar8 != '.') goto LAB_0002c953;
                local_11b8 = local_11b4;
                pcVar1 = local_11b8;
              }
            }
                    /* try { // try from 0002cb4f to 0002cb66 has its CatchHandler @ 0002cb71 */
            local_11b8 = pcVar1;
            piVar4 = (int *)FUN_0002d630(&local_11bc);
          }
        }
      }
      goto LAB_0002c953;
    }
LAB_0002c6bf:
    local_11b8 = param_1 + iVar10;
                    /* try { // try from 0002c6c5 to 0002c9c8 has its CatchHandler @ 0002cb71 */
    piVar4 = (int *)FUN_0002cc90();
    puVar2 = local_20;
    pcVar8 = local_11b4;
    pcVar1 = local_11b8;
    uVar6 = 0xfffffffe;
    pvVar12 = (void *)0x0;
    if (piVar4 != (int *)0x0) {
      if (local_11b4 != local_11b8) {
        if (*local_11b8 != '.') goto LAB_0002ca27;
        iVar10 = local_20[1];
        if (iVar10 - 0xfd8U < 0xfffff008) {
          puVar5 = malloc(0x1000);
          if (puVar5 == (undefined4 *)0x0) goto LAB_0002cb34;
          *puVar5 = puVar2;
          puVar5[1] = 0;
          iVar10 = 0;
          local_20 = puVar5;
        }
        local_20[1] = iVar10 + 0x20;
        *(undefined4 *)((int)local_20 + iVar10 + 0xc) = 0x1010101;
        *(undefined ***)((int)local_20 + iVar10 + 8) = &PTR_LAB_0004c038;
        *(int **)((int)local_20 + iVar10 + 0x10) = piVar4;
        *(char **)((int)local_20 + iVar10 + 0x14) = pcVar1;
        *(char **)((int)local_20 + iVar10 + 0x18) = pcVar8;
        piVar4 = (int *)((int)local_20 + iVar10 + 8);
        local_11b8 = local_11b4;
      }
LAB_0002c95b:
      if (param_2 == (void *)0x0) {
        local_11d8 = malloc(0x400);
        if (local_11d8 == (void *)0x0) {
          uVar6 = 0xffffffff;
          pvVar12 = (void *)0x0;
          goto LAB_0002ca27;
        }
        sStack_11c8 = 0x400;
      }
      else {
        sStack_11c8 = *param_3;
      }
      local_11cc = 0;
      local_11d0 = local_11d8;
      (**(code **)(*piVar4 + 0x10))(piVar4,&local_11d0);
      if (*(char *)((int)piVar4 + 5) != '\x01') {
        (**(code **)(*piVar4 + 0x14))(piVar4,&local_11d0);
      }
      uVar9 = local_11cc + 1;
      if (sStack_11c8 <= uVar9) {
        sStack_11c8 = sStack_11c8 * 2;
        if (sStack_11c8 < uVar9) {
          sStack_11c8 = uVar9;
        }
        local_11d0 = realloc(local_11d0,sStack_11c8);
        if (local_11d0 == (void *)0x0) {
LAB_0002cb34:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        uVar9 = local_11cc + 1;
      }
      *(undefined1 *)((int)local_11d0 + local_11cc) = 0;
      if (param_3 != (uint *)0x0) {
        *param_3 = uVar9;
      }
      uVar6 = 0;
      pvVar12 = local_11d0;
      local_11cc = uVar9;
    }
  }
LAB_0002ca27:
  if (param_4 != (undefined4 *)0x0) {
    *param_4 = uVar6;
  }
  while (puVar2 = local_20, puVar2 != (undefined4 *)0x0) {
    local_20 = (undefined4 *)*puVar2;
    if (&uStack_1020 != puVar2) {
      free(puVar2);
    }
  }
  uStack_1020 = 0;
  local_101c = 0;
  local_20 = &uStack_1020;
  if (local_1050 != &local_1044) {
    free(local_1050);
  }
  if (local_106c != &local_1060) {
    free(local_106c);
  }
  if (local_1098 != &local_108c) {
    free(local_1098);
  }
  if (local_1124 != &local_1118) {
    free(local_1124);
  }
  if (local_11b0 != &local_11a4) {
    free(local_11b0);
  }
LAB_0002cad8:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return pvVar12;
}


// ==== FUN_0002cb90 @ 0002cb90

void FUN_0002cb90(void)

{
  undefined4 *puVar1;
  undefined4 *__ptr;
  int in_ECX;
  
  puVar1 = *(undefined4 **)(in_ECX + 0x1198);
  while (__ptr = puVar1, __ptr != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*__ptr;
    *(undefined4 **)(in_ECX + 0x1198) = puVar1;
    if ((undefined4 *)(in_ECX + 0x198) != __ptr) {
      free(__ptr);
      puVar1 = *(undefined4 **)(in_ECX + 0x1198);
    }
  }
  *(undefined4 *)(in_ECX + 0x198) = 0;
  *(undefined4 *)(in_ECX + 0x19c) = 0;
  *(undefined4 **)(in_ECX + 0x1198) = (undefined4 *)(in_ECX + 0x198);
  if (*(void **)(in_ECX + 0x168) != (void *)(in_ECX + 0x174)) {
    free(*(void **)(in_ECX + 0x168));
  }
  if (*(void **)(in_ECX + 0x14c) != (void *)(in_ECX + 0x158)) {
    free(*(void **)(in_ECX + 0x14c));
  }
  if (*(void **)(in_ECX + 0x120) != (void *)(in_ECX + 300)) {
    free(*(void **)(in_ECX + 0x120));
  }
  if (*(void **)(in_ECX + 0x94) != (void *)(in_ECX + 0xa0)) {
    free(*(void **)(in_ECX + 0x94));
  }
  if (*(void **)(in_ECX + 8) != (void *)(in_ECX + 0x14)) {
    free(*(void **)(in_ECX + 8));
  }
  return;
}


// ==== FUN_0002cc90 @ 0002cc90

int FUN_0002cc90(void)

{
  int *piVar1;
  byte *pbVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  char *pcVar6;
  byte *pbVar7;
  undefined4 *in_ECX;
  int iVar8;
  char *pcVar9;
  byte bVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  int in_GS_OFFSET;
  bool bVar15;
  int local_38 [4];
  undefined4 local_28;
  uint local_24;
  undefined1 local_20 [4];
  uint local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar6 = (char *)*in_ECX;
  pcVar9 = (char *)in_ECX[1];
  if ((pcVar9 == pcVar6) || ((cVar3 = *pcVar6, cVar3 != 'T' && (cVar3 != 'G')))) {
    local_28 = local_28 & 0xffff0000;
    local_24 = 0;
    local_20[0] = 0;
    local_1c = (int)(in_ECX[0x5b] - in_ECX[0x5a]) >> 2;
    local_38[3] = FUN_0002e860();
    iVar13 = 0;
    if (local_38[3] == 0) goto LAB_0002d0b6;
    iVar13 = in_ECX[0x5a];
    uVar11 = in_ECX[0x5b] - iVar13 >> 2;
    if (local_1c < uVar11) {
      piVar1 = (int *)in_ECX[0x53];
      if ((piVar1 != (int *)in_ECX[0x54]) && (piVar5 = (int *)*piVar1, piVar5 != (int *)0x0)) {
        iVar4 = *(int *)(iVar13 + local_1c * 4);
        uVar14 = *(uint *)(iVar4 + 8);
        iVar8 = *piVar5;
        if (uVar14 < (uint)(piVar5[1] - iVar8 >> 2)) {
          uVar12 = local_1c;
          do {
            uVar12 = uVar12 + 1;
            *(undefined4 *)(iVar4 + 0xc) = *(undefined4 *)(iVar8 + uVar14 * 4);
            if (uVar11 == uVar12) goto LAB_0002cebb;
            piVar5 = (int *)*piVar1;
            if (piVar5 == (int *)0x0) break;
            iVar4 = *(int *)(iVar13 + uVar12 * 4);
            uVar14 = *(uint *)(iVar4 + 8);
            iVar8 = *piVar5;
          } while (uVar14 < (uint)(piVar5[1] - iVar8 >> 2));
          iVar13 = 0;
          if (uVar12 < uVar11) goto LAB_0002d0b6;
          goto LAB_0002ced4;
        }
      }
    }
    else {
LAB_0002cebb:
      in_ECX[0x5b] = iVar13 + local_1c * 4;
LAB_0002ced4:
      pcVar9 = (char *)*in_ECX;
      pcVar6 = (char *)in_ECX[1];
      iVar13 = local_38[3];
      if ((((pcVar6 == pcVar9) || (cVar3 = *pcVar9, cVar3 == '.')) || (cVar3 == 'E')) ||
         (cVar3 == '_')) goto LAB_0002d0b6;
      local_38[2] = 0;
      if ((((((0xc < (uint)((int)pcVar6 - (int)pcVar9)) && (cVar3 == 'U')) &&
            ((pcVar9[1] == 'a' && ((pcVar9[2] == '9' && (pcVar9[3] == 'e')))))) &&
           (pcVar9[4] == 'n')) && (((pcVar9[5] == 'a' && (pcVar9[6] == 'b')) && (pcVar9[7] == 'l')))
          ) && (((pcVar9[8] == 'e' && (pcVar9[9] == '_')) &&
                ((pcVar9[10] == 'i' && ((pcVar9[0xb] == 'f' && (pcVar9[0xc] == 'I')))))))) {
        pcVar9 = pcVar9 + 0xd;
        *in_ECX = pcVar9;
        iVar13 = in_ECX[3];
        iVar4 = in_ECX[2];
        if (pcVar9 == pcVar6) goto LAB_0002cfc0;
        while (*pcVar9 != 'E') {
LAB_0002cfc0:
          do {
            local_38[0] = FUN_0002f430();
            if (local_38[0] == 0) goto LAB_0002d0b4;
            FUN_0002f5d0();
            pcVar9 = (char *)*in_ECX;
          } while (pcVar9 == (char *)in_ECX[1]);
        }
        *in_ECX = pcVar9 + 1;
        iVar13 = (iVar13 - iVar4 >> 2) * 4;
        FUN_00039de0(in_ECX[2] + iVar13,in_ECX[3]);
        in_ECX[3] = iVar13 + in_ECX[2];
        local_38[2] = FUN_0002f680();
      }
      if ((((char)local_28 != '\0') || (local_28._1_1_ == '\0')) ||
         (iVar13 = FUN_0002d6e0(), iVar13 != 0)) {
        pcVar6 = (char *)*in_ECX;
        if ((pcVar6 == (char *)in_ECX[1]) || (*pcVar6 != 'v')) {
          iVar13 = in_ECX[3];
          iVar4 = in_ECX[2];
          do {
            local_38[0] = FUN_0002d6e0();
            if (local_38[0] == 0) goto LAB_0002d0b4;
            FUN_0002f5d0();
          } while ((((char *)in_ECX[1] != (char *)*in_ECX) &&
                   (cVar3 = *(char *)*in_ECX, cVar3 != '.')) && ((cVar3 != '_' && (cVar3 != 'E'))));
          iVar13 = (iVar13 - iVar4 >> 2) * 4;
          FUN_00039de0(in_ECX[2] + iVar13,in_ECX[3]);
          in_ECX[3] = iVar13 + in_ECX[2];
        }
        else {
          *in_ECX = pcVar6 + 1;
          local_38[0] = 0;
          local_38[1] = 0;
        }
        iVar13 = FUN_0002f720(local_38 + 3,local_38,local_38 + 2,&local_24,local_20);
        goto LAB_0002d0b6;
      }
    }
    goto LAB_0002d0b4;
  }
  iVar13 = 0;
  if (pcVar9 == pcVar6) goto LAB_0002d0b6;
  if (cVar3 == 'G') {
    if ((uint)((int)pcVar9 - (int)pcVar6) < 2) goto LAB_0002d0b6;
    if (pcVar6[1] == 'R') {
      *in_ECX = pcVar6 + 2;
      iVar4 = FUN_0002e860();
      if (iVar4 == 0) goto LAB_0002d0b4;
      pbVar7 = (byte *)*in_ECX;
      pbVar2 = (byte *)in_ECX[1];
      if (pbVar2 != pbVar7) {
        bVar10 = *pbVar7;
        bVar15 = true;
        iVar13 = 0;
        if (('/' < (char)bVar10) && ((bVar10 < 0x3a || ((byte)(bVar10 + 0xbf) < 0x1a)))) {
          pbVar7 = pbVar7 + 1;
          do {
            if ((0x39 < bVar10) && (0x19 < (byte)(bVar10 + 0xbf))) break;
            *in_ECX = pbVar7;
            if (pbVar7 == pbVar2) goto LAB_0002d0b6;
            bVar10 = *pbVar7;
            pbVar7 = pbVar7 + 1;
          } while ('/' < (char)bVar10);
          pbVar7 = pbVar7 + -1;
          bVar15 = false;
        }
        if ((pbVar7 == pbVar2) || (bVar10 != 0x5f)) {
          if (!bVar15) goto LAB_0002d0b6;
        }
        else {
          *in_ECX = pbVar7 + 1;
        }
      }
      piVar1 = (int *)in_ECX[0x466];
      iVar13 = piVar1[1];
      piVar5 = piVar1;
      if (iVar13 - 0xfd8U < 0xfffff008) {
        piVar5 = malloc(0x1000);
        if (piVar5 == (int *)0x0) {
LAB_0002d58f:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar5 = (int)piVar1;
        piVar5[1] = 0;
        in_ECX[0x466] = piVar5;
        iVar13 = 0;
      }
      piVar5[1] = iVar13 + 0x20;
      *(undefined4 *)((int)piVar5 + iVar13 + 0xc) = 0x1010114;
      *(undefined ***)((int)piVar5 + iVar13 + 8) = &PTR_LAB_0004b310;
      *(char **)((int)piVar5 + iVar13 + 0x10) = "reference temporary for ";
      *(char **)((int)piVar5 + iVar13 + 0x14) = "";
    }
    else {
      if (pcVar6[1] != 'V') goto LAB_0002d0b6;
      *in_ECX = pcVar6 + 2;
      iVar4 = FUN_0002e860();
      iVar13 = 0;
      if (iVar4 == 0) goto LAB_0002d0b6;
      piVar1 = (int *)in_ECX[0x466];
      iVar13 = piVar1[1];
      piVar5 = piVar1;
      if (iVar13 - 0xfd8U < 0xfffff008) {
        piVar5 = malloc(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0002d58f;
        *piVar5 = (int)piVar1;
        piVar5[1] = 0;
        in_ECX[0x466] = piVar5;
        iVar13 = 0;
      }
      piVar5[1] = iVar13 + 0x20;
      *(undefined4 *)((int)piVar5 + iVar13 + 0xc) = 0x1010114;
      *(undefined ***)((int)piVar5 + iVar13 + 8) = &PTR_LAB_0004b310;
      *(char **)((int)piVar5 + iVar13 + 0x10) = "guard variable for ";
      *(char **)((int)piVar5 + iVar13 + 0x14) = "";
    }
    *(int *)((int)piVar5 + iVar13 + 0x18) = iVar4;
    iVar13 = (int)piVar5 + iVar13 + 8;
    goto LAB_0002d0b6;
  }
  if (cVar3 != 'T') goto LAB_0002d0b6;
  if ((uint)((int)pcVar9 - (int)pcVar6) < 2) {
switchD_0002cd15_caseD_44:
    pcVar6 = pcVar6 + 1;
    *in_ECX = pcVar6;
    if (pcVar9 == pcVar6) {
      bVar15 = false;
    }
    else {
      bVar15 = *pcVar6 == 'v';
    }
    cVar3 = FUN_0002fa90();
    iVar13 = 0;
    if (cVar3 != '\0') goto LAB_0002d0b6;
    local_28 = FUN_0002cc90();
    if (local_28 != 0) {
      if (bVar15) {
        iVar13 = FUN_0002fde0();
      }
      else {
        iVar13 = FUN_0002fe80();
      }
      goto LAB_0002d0b6;
    }
    goto LAB_0002d0b4;
  }
  switch(pcVar6[1]) {
  case 'C':
    *in_ECX = pcVar6 + 2;
    local_38[0] = FUN_0002d6e0();
    iVar13 = 0;
    if (local_38[0] == 0) goto LAB_0002d0b6;
    FUN_0002d5a0(1);
    if (((local_28 != local_24) && (pcVar6 = (char *)*in_ECX, pcVar6 != (char *)in_ECX[1])) &&
       (*pcVar6 == '_')) {
      *in_ECX = pcVar6 + 1;
      local_28 = FUN_0002d6e0();
      if (local_28 != 0) {
        iVar13 = FUN_0002fca0(local_38);
        goto LAB_0002d0b6;
      }
    }
    break;
  default:
    goto switchD_0002cd15_caseD_44;
  case 'H':
    *in_ECX = pcVar6 + 2;
    local_28 = FUN_0002e860();
    iVar13 = 0;
    if (local_28 != 0) {
      iVar13 = FUN_0002fd40();
    }
    goto LAB_0002d0b6;
  case 'I':
    *in_ECX = pcVar6 + 2;
    local_28 = FUN_0002d6e0();
    if (local_28 != 0) {
      iVar13 = FUN_0002f950();
      goto LAB_0002d0b6;
    }
    break;
  case 'S':
    *in_ECX = pcVar6 + 2;
    local_28 = FUN_0002d6e0();
    if (local_28 != 0) {
      iVar13 = FUN_0002f9f0();
      goto LAB_0002d0b6;
    }
    break;
  case 'T':
    *in_ECX = pcVar6 + 2;
    local_28 = FUN_0002d6e0();
    if (local_28 != 0) {
      iVar13 = FUN_0002f8b0();
      goto LAB_0002d0b6;
    }
    break;
  case 'V':
    *in_ECX = pcVar6 + 2;
    local_28 = FUN_0002d6e0();
    if (local_28 != 0) {
      iVar13 = FUN_0002f810();
      goto LAB_0002d0b6;
    }
    break;
  case 'W':
    *in_ECX = pcVar6 + 2;
    local_28 = FUN_0002e860();
    iVar13 = 0;
    if (local_28 != 0) {
      iVar13 = FUN_0002d630(&local_28);
    }
    goto LAB_0002d0b6;
  case 'c':
    *in_ECX = pcVar6 + 2;
    cVar3 = FUN_0002fa90();
    if (cVar3 == '\0') {
      cVar3 = FUN_0002fa90();
      iVar13 = 0;
      if (cVar3 != '\0') goto LAB_0002d0b6;
      local_28 = FUN_0002cc90();
      if (local_28 != 0) {
        iVar13 = FUN_0002fc00();
        goto LAB_0002d0b6;
      }
    }
  }
LAB_0002d0b4:
  iVar13 = 0;
LAB_0002d0b6:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar13;
}


// ==== FUN_0002d5a0 @ 0002d5a0

void FUN_0002d5a0(char param_1)

{
  char *pcVar1;
  char *pcVar2;
  undefined4 *in_ECX;
  int *in_EDX;
  char *pcVar3;
  char *pcVar4;
  char *local_18;
  
  pcVar1 = (char *)*in_EDX;
  pcVar2 = (char *)in_EDX[1];
  pcVar4 = pcVar1;
  if (((param_1 != '\0') && (pcVar1 != pcVar2)) && (*pcVar1 == 'n')) {
    pcVar4 = pcVar1 + 1;
    *in_EDX = (int)pcVar4;
  }
  local_18 = (char *)0x0;
  if (pcVar2 == pcVar4) {
    pcVar3 = (char *)0x0;
  }
  else {
    pcVar3 = (char *)0x0;
    if (0xfffffff5 < (int)*pcVar4 - 0x3aU) {
      do {
        pcVar4 = pcVar4 + 1;
        *in_EDX = (int)pcVar4;
        local_18 = pcVar1;
        if (pcVar4 == pcVar2) {
          pcVar3 = pcVar2;
          goto LAB_0002d611;
        }
      } while (0xfffffff5 < (int)*pcVar4 - 0x3aU);
      pcVar3 = pcVar4;
    }
  }
LAB_0002d611:
  *in_ECX = local_18;
  in_ECX[1] = pcVar3;
  return;
}


// ==== FUN_0002d630 @ 0002d630

int FUN_0002d630(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  size_t sVar4;
  int in_ECX;
  char *in_EDX;
  int iVar5;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar3 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar5 = 0;
  }
  piVar3[1] = iVar5 + 0x20;
  sVar4 = strlen(in_EDX);
  uVar2 = *param_1;
  *(undefined4 *)((int)piVar3 + iVar5 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar5 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar5 + 0x10) = in_EDX;
  *(char **)((int)piVar3 + iVar5 + 0x14) = in_EDX + sVar4;
  *(undefined4 *)((int)piVar3 + iVar5 + 0x18) = uVar2;
  return (int)piVar3 + iVar5 + 8;
}


// ==== FUN_0002d6e0 @ 0002d6e0

char * FUN_0002d6e0(void)

{
  char cVar1;
  char *pcVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  char *pcVar6;
  char *pcVar7;
  byte bVar8;
  int *in_ECX;
  int iVar9;
  uint uVar10;
  char *pcVar11;
  int in_GS_OFFSET;
  char **ppcVar12;
  char *local_2c;
  char *local_28;
  char *local_24;
  char *local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar7 = (char *)*in_ECX;
  pcVar2 = (char *)in_ECX[1];
  uVar4 = (int)pcVar2 - (int)pcVar7;
  if (pcVar2 == pcVar7) goto switchD_0002d739_caseD_42;
  cVar1 = *pcVar7;
  switch(cVar1) {
  case 'A':
    local_2c = (char *)0x0;
    if (pcVar7 == pcVar2) {
LAB_0002e563:
      local_2c = (char *)0x0;
    }
    else {
      if (cVar1 != 'A') goto LAB_0002e11a;
      pcVar6 = pcVar7 + 1;
      *in_ECX = (int)pcVar6;
      local_1c = (char *)0x0;
      if (pcVar2 == pcVar6) {
LAB_0002e56c:
        pcVar7 = (char *)FUN_00031980();
        local_2c = (char *)0x0;
        if (((pcVar7 == (char *)0x0) || (pcVar2 = (char *)*in_ECX, pcVar2 == (char *)in_ECX[1])) ||
           (*pcVar2 != '_')) goto LAB_0002e11a;
        *in_ECX = (int)(pcVar2 + 1);
        local_1c = pcVar7;
      }
      else if ((int)*pcVar6 - 0x3aU < 0xfffffff6) {
        if (*pcVar6 != '_') goto LAB_0002e56c;
        *in_ECX = (int)(pcVar7 + 2);
      }
      else {
        pcVar7 = pcVar7 + 2;
        do {
          pcVar11 = pcVar7;
          *in_ECX = (int)pcVar11;
          local_24 = pcVar2;
          if (pcVar11 == pcVar2) goto LAB_0002e66f;
          pcVar7 = pcVar11 + 1;
        } while (0xfffffff5 < (int)*pcVar11 - 0x3aU);
        local_24 = pcVar11;
LAB_0002e66f:
        local_28 = pcVar6;
        local_1c = (char *)FUN_0003fed0();
        pcVar7 = (char *)*in_ECX;
        local_2c = (char *)0x0;
        if ((pcVar7 == (char *)in_ECX[1]) || (*pcVar7 != '_')) goto LAB_0002e11a;
        *in_ECX = (int)(pcVar7 + 1);
      }
      local_28 = (char *)FUN_0002d6e0();
      if (local_28 == (char *)0x0) {
LAB_0002e6cb:
        local_2c = (char *)0x0;
      }
      else {
        local_2c = (char *)FUN_000402e0(&local_1c);
      }
    }
    goto LAB_0002e11a;
  default:
    goto switchD_0002d739_caseD_42;
  case 'C':
    *in_ECX = (int)(pcVar7 + 1);
    local_28 = (char *)FUN_0002d6e0();
    if (local_28 == (char *)0x0) goto LAB_0002e633;
    local_2c = (char *)FUN_0003f340();
    goto LAB_0002e126;
  case 'D':
    local_2c = (char *)0x0;
    if (uVar4 < 2) break;
    switch(pcVar7[1]) {
    case 'O':
    case 'o':
    case 'w':
    case 'x':
      local_2c = (char *)FUN_0003e420();
      goto LAB_0002e11a;
    default:
      goto switchD_0002df83_caseD_50;
    case 'T':
    case 't':
      local_2c = (char *)FUN_00030ec0();
      goto LAB_0002e11a;
    case 'a':
      *in_ECX = (int)(pcVar7 + 2);
      pcVar7 = (char *)FUN_00031650();
      break;
    case 'c':
      *in_ECX = (int)(pcVar7 + 2);
      goto LAB_0002e82f;
    case 'd':
      *in_ECX = (int)(pcVar7 + 2);
      goto LAB_0002e7fb;
    case 'e':
      *in_ECX = (int)(pcVar7 + 2);
      pcVar7 = (char *)FUN_0003b2c0();
      break;
    case 'f':
      *in_ECX = (int)(pcVar7 + 2);
      goto LAB_0002e7fb;
    case 'h':
      *in_ECX = (int)(pcVar7 + 2);
LAB_0002e7fb:
      pcVar7 = (char *)FUN_0003b370();
      break;
    case 'i':
      *in_ECX = (int)(pcVar7 + 2);
      pcVar7 = (char *)FUN_0003ed10();
      break;
    case 'n':
      *in_ECX = (int)(pcVar7 + 2);
LAB_0002e82f:
      pcVar7 = (char *)FUN_0003b6a0();
      break;
    case 'p':
      *in_ECX = (int)(pcVar7 + 2);
      local_28 = (char *)FUN_0002d6e0();
      if (local_28 == (char *)0x0) goto switchD_0002df83_caseD_50;
      local_2c = (char *)FUN_000359d0();
      goto LAB_0002e126;
    case 's':
      *in_ECX = (int)(pcVar7 + 2);
      pcVar7 = (char *)FUN_0003ed10();
      break;
    case 'u':
      *in_ECX = (int)(pcVar7 + 2);
      pcVar7 = (char *)FUN_000361f0();
      break;
    case 'v':
      local_2c = (char *)FUN_0003edc0();
      goto LAB_0002e11a;
    }
    if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
    return pcVar7;
  case 'F':
switchD_0002d739_caseD_46:
    local_2c = (char *)FUN_0003e420();
    goto LAB_0002e11a;
  case 'G':
    *in_ECX = (int)(pcVar7 + 1);
    local_28 = (char *)FUN_0002d6e0();
    if (local_28 != (char *)0x0) {
      local_2c = (char *)FUN_0003f3e0();
      goto LAB_0002e126;
    }
    goto LAB_0002e633;
  case 'K':
  case 'V':
  case 'r':
    uVar10 = (uint)(cVar1 == 'r');
    if (uVar10 < uVar4) {
      if (pcVar7[uVar10] == 'V') {
        uVar10 = (cVar1 == 'r') + 1;
      }
    }
    if (uVar10 < uVar4) {
      uVar10 = uVar10 + (pcVar7[uVar10] == 'K');
    }
    if (uVar10 < uVar4) {
      if (pcVar7[uVar10] == 'F') goto switchD_0002d739_caseD_46;
      if ((pcVar7[uVar10] == 'D') && (uVar10 + 1 < uVar4)) {
        bVar8 = pcVar7[uVar10 + 1] + 0x91;
        if (((bVar8 < 10) && ((0x301U >> (bVar8 & 0x1f) & 1) != 0)) || (pcVar7[uVar10 + 1] == 'O'))
        goto switchD_0002d739_caseD_46;
      }
    }
  case 'U':
    local_2c = (char *)FUN_0003e8a0();
LAB_0002e11a:
    if (local_2c != (char *)0x0) {
LAB_0002e126:
      FUN_0002f5d0();
      break;
    }
    goto LAB_0002e633;
  case 'M':
    local_2c = (char *)0x0;
    if (pcVar7 == pcVar2) goto LAB_0002e563;
    if (cVar1 == 'M') {
      *in_ECX = (int)(pcVar7 + 1);
      local_28 = (char *)FUN_0002d6e0();
      if ((local_28 == (char *)0x0) || (local_1c = (char *)FUN_0002d6e0(), local_1c == (char *)0x0))
      goto LAB_0002e6cb;
      local_2c = (char *)FUN_00040540(&local_1c);
    }
    goto LAB_0002e11a;
  case 'O':
    *in_ECX = (int)(pcVar7 + 1);
    local_28 = (char *)FUN_0002d6e0();
    if (local_28 != (char *)0x0) {
      local_1c = (char *)0x1;
LAB_0002e395:
      local_2c = (char *)FUN_0003f290(&local_1c);
      goto LAB_0002e126;
    }
    goto LAB_0002e633;
  case 'P':
    *in_ECX = (int)(pcVar7 + 1);
    local_28 = (char *)FUN_0002d6e0();
    if (local_28 != (char *)0x0) {
      local_2c = (char *)FUN_0003f1f0();
      goto LAB_0002e126;
    }
    goto LAB_0002e633;
  case 'R':
    *in_ECX = (int)(pcVar7 + 1);
    local_28 = (char *)FUN_0002d6e0();
    if (local_28 != (char *)0x0) {
      local_1c = (char *)0x0;
      goto LAB_0002e395;
    }
    goto LAB_0002e633;
  case 'S':
    if (((1 < uVar4) && (pcVar7[1] != '\0')) && (pcVar7[1] != 't')) {
      local_28 = (char *)FUN_000301b0();
      local_2c = local_28;
      if ((((local_28 == (char *)0x0) || ((char)in_ECX[0x61] == '\0')) ||
          ((char *)in_ECX[1] == (char *)*in_ECX)) || (*(char *)*in_ECX != 'I')) break;
      local_2c = (char *)0x0;
      local_1c = (char *)FUN_00030570();
      if (local_1c == (char *)0x0) break;
      ppcVar12 = &local_1c;
LAB_0002e5f1:
      local_2c = (char *)FUN_00030a60(ppcVar12);
      goto LAB_0002e126;
    }
    goto switchD_0002d739_caseD_42;
  case 'T':
    if (((1 < uVar4) && ((byte)(pcVar7[1] + 0x9bU) < 0x11)) &&
       ((0x14001U >> ((byte)(pcVar7[1] + 0x9bU) & 0x1f) & 1) != 0)) goto switchD_0002d739_caseD_42;
    local_2c = (char *)FUN_00030b00();
    if (local_2c != (char *)0x0) {
      if ((((char)in_ECX[0x61] != '\0') && ((char *)in_ECX[1] != (char *)*in_ECX)) &&
         (*(char *)*in_ECX == 'I')) {
        local_28 = (char *)FUN_00030570();
        local_2c = (char *)0x0;
        if (local_28 == (char *)0x0) break;
        ppcVar12 = &local_28;
        goto LAB_0002e5f1;
      }
      goto LAB_0002e126;
    }
    goto LAB_0002e633;
  case 'a':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) {
LAB_0002e84a:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "signed char";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'b':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(undefined **)((int)piVar5 + iVar9 + 0x10) = &DAT_000149aa;
    *(undefined **)((int)piVar5 + iVar9 + 0x14) = &DAT_000149ae;
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'c':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(undefined **)((int)piVar5 + iVar9 + 0x10) = &DAT_00014611;
    *(undefined **)((int)piVar5 + iVar9 + 0x14) = &DAT_00014615;
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'd':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "double";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'e':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "long double";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'f':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "float";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'g':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "__float128";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'h':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "unsigned char";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'i':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(undefined **)((int)piVar5 + iVar9 + 0x10) = &DAT_000140e8;
    *(undefined **)((int)piVar5 + iVar9 + 0x14) = &DAT_000140eb;
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'j':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "unsigned int";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'l':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(undefined **)((int)piVar5 + iVar9 + 0x10) = &DAT_00013b70;
    *(undefined **)((int)piVar5 + iVar9 + 0x14) = &DAT_00013b74;
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'm':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "unsigned long";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'n':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "__int128";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'o':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "unsigned __int128";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 's':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "short";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 't':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "unsigned short";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'u':
    pcVar6 = pcVar7 + 1;
    *in_ECX = (int)pcVar6;
    if ((pcVar2 != pcVar6) && (0xf5 < (byte)(*pcVar6 - 0x3aU))) {
      uVar4 = 0;
      pcVar7 = pcVar7 + 2;
      do {
        pcVar11 = pcVar7;
        *in_ECX = (int)pcVar11;
        uVar4 = ((int)pcVar11[-1] + uVar4 * 10) - 0x30;
        if (pcVar11 == pcVar2) {
          pcVar6 = pcVar2;
          pcVar11 = pcVar2;
          goto LAB_0002e601;
        }
        pcVar6 = pcVar6 + 1;
        pcVar7 = pcVar11 + 1;
      } while ((byte)(*pcVar11 - 0x30U) < 10);
LAB_0002e601:
      if (uVar4 <= (uint)((int)pcVar2 - (int)pcVar6)) {
        local_24 = pcVar11 + uVar4;
        *in_ECX = (int)local_24;
        local_28 = pcVar6;
        if (uVar4 != 0) {
          local_2c = (char *)FUN_0003a740();
          goto LAB_0002e126;
        }
      }
    }
LAB_0002e633:
    local_2c = (char *)0x0;
    break;
  case 'v':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(undefined **)((int)piVar5 + iVar9 + 0x10) = &DAT_00014ffb;
    *(undefined **)((int)piVar5 + iVar9 + 0x14) = &DAT_00014fff;
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'w':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(undefined **)((int)piVar5 + iVar9 + 0x10) = &DAT_00013c4e;
    *(undefined **)((int)piVar5 + iVar9 + 0x14) = &DAT_00013c55;
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'x':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "long long";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'y':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(char **)((int)piVar5 + iVar9 + 0x10) = "unsigned long long";
    *(char **)((int)piVar5 + iVar9 + 0x14) = "";
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
    break;
  case 'z':
    *in_ECX = (int)(pcVar7 + 1);
    piVar3 = (int *)in_ECX[0x466];
    iVar9 = piVar3[1];
    piVar5 = piVar3;
    if (iVar9 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_0002e84a;
      *piVar5 = (int)piVar3;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar9 = 0;
    }
    piVar5[1] = iVar9 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar9 + 0xc) = 0x1010107;
    *(undefined ***)((int)piVar5 + iVar9 + 8) = &PTR_LAB_0004b388;
    *(undefined **)((int)piVar5 + iVar9 + 0x10) = &DAT_00014af1;
    *(undefined **)((int)piVar5 + iVar9 + 0x14) = &DAT_00014af4;
    local_2c = (char *)((int)piVar5 + iVar9 + 8);
  }
switchD_0002df83_caseD_50:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return local_2c;
switchD_0002d739_caseD_42:
  local_2c = (char *)FUN_0003f0c0();
  goto LAB_0002e11a;
}


// ==== FUN_0002e860 @ 0002e860

int FUN_0002e860(void)

{
  char cVar1;
  byte bVar2;
  char *pcVar3;
  byte *pbVar4;
  int iVar5;
  undefined1 uVar6;
  byte bVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  int *in_ECX;
  int iVar11;
  int iVar12;
  undefined1 *in_EDX;
  char *pcVar13;
  char *pcVar14;
  uint uVar15;
  byte *pbVar16;
  byte *pbVar17;
  int in_GS_OFFSET;
  int local_28 [3];
  int local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar13 = (char *)*in_ECX;
  pcVar3 = (char *)in_ECX[1];
  if ((pcVar13 != pcVar3) && (*pcVar13 == 'L')) {
    pcVar13 = pcVar13 + 1;
    *in_ECX = (int)pcVar13;
  }
  if (pcVar3 == pcVar13) {
LAB_0002e926:
    local_28[0] = FUN_000311e0();
    if (local_28[0] != 0) {
LAB_0002e941:
      iVar11 = local_28[0];
      if (((char *)in_ECX[1] == (char *)*in_ECX) || (*(char *)*in_ECX != 'I')) goto LAB_0002f407;
      FUN_0002f5d0();
      iVar8 = FUN_00030570();
      if (iVar8 != 0) {
        if (in_EDX != (undefined1 *)0x0) {
          in_EDX[1] = 1;
        }
        piVar10 = (int *)in_ECX[0x466];
        iVar12 = piVar10[1];
        if (iVar12 - 0xfe8U < 0xfffff008) {
          piVar9 = malloc(0x1000);
          if (piVar9 == (int *)0x0) goto LAB_0002f41d;
          *piVar9 = (int)piVar10;
          piVar9[1] = 0;
          in_ECX[0x466] = (int)piVar9;
          iVar12 = 0;
          piVar10 = piVar9;
        }
        piVar10[1] = iVar12 + 0x10;
        *(undefined4 *)((int)piVar10 + iVar12 + 0xc) = 0x1010125;
        *(undefined ***)((int)piVar10 + iVar12 + 8) = &PTR_LAB_0004bf20;
        *(int *)((int)piVar10 + iVar12 + 0x10) = iVar11;
        *(int *)((int)piVar10 + iVar12 + 0x14) = iVar8;
        iVar11 = (int)piVar10 + iVar12 + 8;
        goto LAB_0002f407;
      }
    }
  }
  else {
    cVar1 = *pcVar13;
    if (cVar1 == 'Z') {
      if (pcVar13 == pcVar3) {
LAB_0002f37c:
        iVar11 = 0;
        goto LAB_0002f407;
      }
      *in_ECX = (int)(pcVar13 + 1);
      local_1c = FUN_0002cc90();
      iVar11 = 0;
      if (local_1c == 0) goto LAB_0002f407;
      pcVar13 = (char *)*in_ECX;
      if (pcVar13 == (char *)in_ECX[1]) goto LAB_0002f401;
      if (*pcVar13 != 'E') goto LAB_0002f37c;
      pcVar3 = pcVar13 + 1;
      *in_ECX = (int)pcVar3;
      if (pcVar3 == (char *)in_ECX[1]) {
LAB_0002f383:
        local_28[0] = FUN_0002e860();
        if (local_28[0] == 0) goto LAB_0002f401;
        iVar11 = FUN_0003d330();
        *in_ECX = iVar11;
      }
      else {
        if (*pcVar3 != 'd') {
          if (*pcVar3 == 's') {
            *in_ECX = (int)(pcVar13 + 2);
            iVar11 = FUN_0003d330();
            *in_ECX = iVar11;
            local_28[0] = FUN_0003b6a0();
            iVar11 = FUN_0003d3c0(local_28);
LAB_0002f375:
            goto LAB_0002f407;
          }
          goto LAB_0002f383;
        }
        *in_ECX = (int)(pcVar13 + 2);
        FUN_0002d5a0(1);
        pcVar13 = (char *)*in_ECX;
        if (pcVar13 == (char *)in_ECX[1]) goto LAB_0002f401;
        iVar11 = 0;
        if (*pcVar13 != '_') goto LAB_0002f407;
        *in_ECX = (int)(pcVar13 + 1);
        local_28[0] = FUN_0002e860();
        if (local_28[0] == 0) goto LAB_0002f401;
      }
      iVar11 = FUN_0003d3c0(local_28);
      goto LAB_0002f407;
    }
    if (cVar1 == 'S') {
      if (((uint)((int)pcVar3 - (int)pcVar13) < 2) || (pcVar13[1] != 't')) {
        local_28[0] = FUN_000301b0();
        iVar11 = 0;
        if ((local_28[0] == 0) ||
           (((char *)in_ECX[1] == (char *)*in_ECX || (*(char *)*in_ECX != 'I')))) goto LAB_0002f407;
        local_1c = FUN_00030570();
        if (local_1c != 0) {
          if (in_EDX != (undefined1 *)0x0) {
            in_EDX[1] = 1;
          }
          iVar11 = FUN_00030a60(&local_1c);
          goto LAB_0002f407;
        }
      }
      else {
        if (((uint)((int)pcVar3 - (int)pcVar13) < 3) || (iVar11 = 3, pcVar13[2] != 'L')) {
          iVar11 = 2;
        }
        *in_ECX = (int)(pcVar13 + iVar11);
        iVar11 = FUN_000311e0();
        if (iVar11 != 0) {
          piVar10 = (int *)in_ECX[0x466];
          iVar8 = piVar10[1];
          piVar9 = piVar10;
          if (iVar8 - 0xfe8U < 0xfffff008) {
            piVar9 = malloc(0x1000);
            if (piVar9 == (int *)0x0) goto LAB_0002f41d;
            *piVar9 = (int)piVar10;
            piVar9[1] = 0;
            in_ECX[0x466] = (int)piVar9;
            iVar8 = 0;
          }
          piVar9[1] = iVar8 + 0x10;
          *(undefined4 *)((int)piVar9 + iVar8 + 0xc) = 0x1010127;
          *(undefined ***)((int)piVar9 + iVar8 + 8) = &PTR_LAB_0004bf58;
          *(int *)((int)piVar9 + iVar8 + 0x10) = iVar11;
          local_28[0] = (int)piVar9 + iVar8 + 8;
          goto LAB_0002e941;
        }
      }
      goto LAB_0002f401;
    }
    if (cVar1 != 'N') goto LAB_0002e926;
    if (pcVar13 == pcVar3) goto LAB_0002f37c;
    pcVar14 = pcVar13 + 1;
    *in_ECX = (int)pcVar14;
    uVar15 = 0;
    if (pcVar14 == pcVar3) {
LAB_0002ebb4:
      pcVar14 = pcVar3;
    }
    else {
      if (*pcVar14 == 'r') {
        pcVar14 = pcVar13 + 2;
        *in_ECX = (int)pcVar14;
        uVar15 = 4;
      }
      if (pcVar14 == pcVar3) goto LAB_0002ebb4;
      if (*pcVar14 == 'V') {
        pcVar14 = pcVar14 + 1;
        *in_ECX = (int)pcVar14;
        uVar15 = uVar15 | 2;
      }
      if (pcVar14 == pcVar3) goto LAB_0002ebb4;
      if (*pcVar14 == 'K') {
        *in_ECX = (int)(pcVar14 + 1);
        uVar15 = uVar15 | 1;
        pcVar14 = pcVar14 + 1;
      }
    }
    if (in_EDX != (undefined1 *)0x0) {
      *(uint *)(in_EDX + 4) = uVar15;
    }
    if (pcVar14 == pcVar3) {
LAB_0002ebdc:
      if (in_EDX != (undefined1 *)0x0) {
        uVar6 = 0;
        goto LAB_0002ec24;
      }
    }
    else {
      if (*pcVar14 == 'R') {
        *in_ECX = (int)(pcVar14 + 1);
        uVar6 = 1;
      }
      else {
        if (*pcVar14 != 'O') goto LAB_0002ebdc;
        *in_ECX = (int)(pcVar14 + 1);
        uVar6 = 2;
      }
      pcVar14 = pcVar14 + 1;
      if (in_EDX != (undefined1 *)0x0) {
LAB_0002ec24:
        in_EDX[8] = uVar6;
      }
    }
    local_28[0] = 0;
    if (((1 < (uint)((int)pcVar3 - (int)pcVar14)) && (*pcVar14 == 'S')) && (pcVar14[1] == 't')) {
      *in_ECX = (int)(pcVar14 + 2);
      piVar10 = (int *)in_ECX[0x466];
      iVar11 = piVar10[1];
      piVar9 = piVar10;
      if (iVar11 - 0xfe8U < 0xfffff008) {
        piVar9 = malloc(0x1000);
        if (piVar9 == (int *)0x0) {
LAB_0002f41d:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar9 = (int)piVar10;
        piVar9[1] = 0;
        in_ECX[0x466] = (int)piVar9;
        iVar11 = 0;
      }
      piVar9[1] = iVar11 + 0x10;
      local_28[0] = (int)piVar9 + iVar11 + 8;
      *(undefined4 *)((int)piVar9 + iVar11 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar9 + iVar11 + 8) = &PTR_LAB_0004b388;
      *(undefined **)((int)piVar9 + iVar11 + 0x10) = &DAT_00013f91;
      *(undefined **)((int)piVar9 + iVar11 + 0x14) = &DAT_00013f94;
    }
    do {
      while( true ) {
        pbVar16 = (byte *)*in_ECX;
        pbVar4 = (byte *)in_ECX[1];
        if (pbVar16 == pbVar4) break;
        if (*pbVar16 != 0x4c) {
          if (*pbVar16 != 0x45) break;
          *in_ECX = (int)(pbVar16 + 1);
          if (local_28[0] == 0) goto LAB_0002f37c;
          iVar11 = 0;
          if (in_ECX[0x25] == in_ECX[0x26]) goto LAB_0002f407;
          in_ECX[0x26] = in_ECX[0x26] + -4;
          iVar11 = local_28[0];
          goto LAB_0002f375;
        }
        pbVar16 = pbVar16 + 1;
        *in_ECX = (int)pbVar16;
        if (pbVar16 != pbVar4) goto LAB_0002ed4d;
LAB_0002ed52:
        uVar15 = (int)pbVar4 - (int)pbVar16;
        if (pbVar4 == pbVar16) goto switchD_0002ed75_caseD_45;
        switch(*pbVar16) {
        case 0x44:
          if (1 < uVar15) {
            bVar7 = pbVar16[1];
            if (bVar7 == 0x43) goto switchD_0002ed75_caseD_45;
            if ((bVar7 == 0x74) || (bVar7 == 0x54)) {
              iVar11 = FUN_00030ec0();
              goto joined_r0x0002efd9;
            }
          }
        case 0x43:
          iVar11 = 0;
          if (local_28[0] == 0) goto LAB_0002f407;
          if ((*(char *)(local_28[0] + 4) == ')') &&
             (iVar11 = *(int *)(local_28[0] + 8), iVar11 - 2U < 4)) {
            piVar10 = (int *)in_ECX[0x466];
            iVar8 = piVar10[1];
            if (iVar8 - 0xfe8U < 0xfffff008) {
              piVar9 = malloc(0x1000);
              if (piVar9 == (int *)0x0) goto LAB_0002f41d;
              *piVar9 = (int)piVar10;
              piVar9[1] = 0;
              in_ECX[0x466] = (int)piVar9;
              iVar8 = 0;
              piVar10 = piVar9;
            }
            piVar10[1] = iVar8 + 0x10;
            *(undefined4 *)((int)piVar10 + iVar8 + 0xc) = 0x1010128;
            *(undefined ***)((int)piVar10 + iVar8 + 8) = &PTR_LAB_0004bd60;
            *(int *)((int)piVar10 + iVar8 + 0x10) = iVar11;
            local_28[0] = (int)piVar10 + iVar8 + 8;
          }
          iVar8 = local_28[0];
          iVar11 = 0;
          if (pbVar16 == pbVar4) {
            bVar7 = *pbVar4;
LAB_0002f1c9:
            if ((bVar7 != 0x44) || (uVar15 == 1)) goto LAB_0002f407;
            bVar7 = pbVar16[1];
            if ((5 < (byte)(bVar7 - 0x30)) || ((byte)(bVar7 - 0x30) == 3)) goto LAB_0002f407;
            *in_ECX = (int)(pbVar16 + 2);
            if (in_EDX != (undefined1 *)0x0) {
              *in_EDX = 1;
            }
            piVar10 = (int *)in_ECX[0x466];
            iVar11 = piVar10[1];
            piVar9 = piVar10;
            if (iVar11 - 0xfd8U < 0xfffff008) {
              piVar9 = malloc(0x1000);
              if (piVar9 == (int *)0x0) goto LAB_0002f41d;
              *piVar9 = (int)piVar10;
              piVar9[1] = 0;
              in_ECX[0x466] = (int)piVar9;
              iVar11 = 0;
            }
            iVar12 = iVar11 + 0x20;
            piVar9[1] = iVar12;
            uVar6 = 1;
          }
          else {
            bVar7 = *pbVar16;
            if (bVar7 != 0x43) goto LAB_0002f1c9;
            pbVar17 = pbVar16 + 1;
            *in_ECX = (int)pbVar17;
            if (pbVar17 == pbVar4) goto LAB_0002f407;
            bVar2 = *pbVar17;
            if (bVar2 == 0x49) {
              pbVar17 = pbVar16 + 2;
              *in_ECX = (int)pbVar17;
            }
            if (pbVar4 == pbVar17) goto LAB_0002f407;
            bVar7 = *pbVar17;
            if (4 < (byte)(bVar7 - 0x31)) goto LAB_0002f37c;
            *in_ECX = (int)(pbVar17 + 1);
            if (in_EDX != (undefined1 *)0x0) {
              *in_EDX = 1;
            }
            if ((bVar2 == 0x49) && (iVar11 = FUN_0002e860(), iVar11 == 0)) goto LAB_0002f37c;
            piVar10 = (int *)in_ECX[0x466];
            iVar11 = piVar10[1];
            piVar9 = piVar10;
            if (iVar11 - 0xfd8U < 0xfffff008) {
              piVar9 = malloc(0x1000);
              if (piVar9 == (int *)0x0) goto LAB_0002f41d;
              *piVar9 = (int)piVar10;
              piVar9[1] = 0;
              in_ECX[0x466] = (int)piVar9;
              iVar11 = 0;
            }
            iVar12 = iVar11 + 0x20;
            piVar9[1] = iVar12;
            uVar6 = 0;
          }
          iVar5 = local_28[0];
          *(undefined4 *)((int)piVar9 + iVar11 + 0xc) = 0x101012a;
          *(undefined ***)((int)piVar9 + iVar11 + 8) = &PTR_LAB_0004bd98;
          *(int *)((int)piVar9 + iVar11 + 0x10) = iVar8;
          *(undefined1 *)((int)piVar9 + iVar11 + 0x14) = uVar6;
          *(uint *)((int)piVar9 + iVar11 + 0x18) = bVar7 - 0x30;
          if (local_28[0] != 0) {
            piVar10 = piVar9;
            if (iVar12 - 0xfe8U < 0xfffff008) {
              piVar10 = malloc(0x1000);
              if (piVar10 == (int *)0x0) goto LAB_0002f41d;
              *piVar10 = (int)piVar9;
              piVar10[1] = 0;
              in_ECX[0x466] = (int)piVar10;
              iVar12 = 0;
            }
            piVar10[1] = iVar12 + 0x10;
            *(undefined4 *)((int)piVar10 + iVar12 + 0xc) = 0x1010117;
            *(undefined ***)((int)piVar10 + iVar12 + 8) = &PTR_LAB_0004b3c0;
            *(int *)((int)piVar10 + iVar12 + 0x10) = iVar5;
            *(int *)((int)piVar10 + iVar12 + 0x14) = (int)piVar9 + iVar11 + 8;
          }
          if (in_EDX != (undefined1 *)0x0) {
            in_EDX[1] = 0;
          }
          local_28[0] = FUN_00030fe0();
          iVar11 = 0;
          if (local_28[0] == 0) goto LAB_0002f407;
LAB_0002f32a:
          FUN_0002f5d0();
          break;
        default:
          goto switchD_0002ed75_caseD_45;
        case 0x49:
          iVar12 = FUN_00030570();
          iVar8 = local_28[0];
          iVar11 = 0;
          if ((iVar12 == 0) || (local_28[0] == 0)) goto LAB_0002f407;
          piVar10 = (int *)in_ECX[0x466];
          iVar11 = piVar10[1];
          piVar9 = piVar10;
          if (iVar11 - 0xfe8U < 0xfffff008) {
            piVar9 = malloc(0x1000);
            if (piVar9 == (int *)0x0) goto LAB_0002f41d;
            *piVar9 = (int)piVar10;
            piVar9[1] = 0;
            in_ECX[0x466] = (int)piVar9;
            iVar11 = 0;
          }
          piVar9[1] = iVar11 + 0x10;
          *(undefined4 *)((int)piVar9 + iVar11 + 0xc) = 0x1010125;
          *(undefined ***)((int)piVar9 + iVar11 + 8) = &PTR_LAB_0004bf20;
          *(int *)((int)piVar9 + iVar11 + 0x10) = iVar8;
          *(int *)((int)piVar9 + iVar11 + 0x14) = iVar12;
          local_28[0] = (int)piVar9 + iVar11 + 8;
          if (in_EDX != (undefined1 *)0x0) {
            in_EDX[1] = 1;
          }
          goto LAB_0002f32a;
        case 0x53:
          if ((uVar15 < 2) || (pbVar16[1] != 0x74)) {
            iVar8 = FUN_000301b0();
            iVar11 = local_28[0];
            local_1c = iVar8;
            if (iVar8 == 0) goto LAB_0002f401;
            if (local_28[0] == 0) {
              local_28[0] = iVar8;
            }
            else {
              piVar10 = (int *)in_ECX[0x466];
              iVar12 = piVar10[1];
              piVar9 = piVar10;
              if (iVar12 - 0xfe8U < 0xfffff008) {
                piVar9 = malloc(0x1000);
                if (piVar9 == (int *)0x0) goto LAB_0002f41d;
                *piVar9 = (int)piVar10;
                piVar9[1] = 0;
                in_ECX[0x466] = (int)piVar9;
                iVar12 = 0;
              }
              piVar9[1] = iVar12 + 0x10;
              *(undefined4 *)((int)piVar9 + iVar12 + 0xc) = 0x1010117;
              *(undefined ***)((int)piVar9 + iVar12 + 8) = &PTR_LAB_0004b3c0;
              *(int *)((int)piVar9 + iVar12 + 0x10) = iVar11;
              *(int *)((int)piVar9 + iVar12 + 0x14) = iVar8;
              local_28[0] = (int)piVar9 + iVar12 + 8;
            }
            if (in_EDX != (undefined1 *)0x0) {
              in_EDX[1] = 0;
            }
            if (local_28[0] != iVar8) {
              FUN_0002f5d0();
            }
          }
          else {
switchD_0002ed75_caseD_45:
            iVar11 = FUN_000311e0();
            if (iVar11 == 0) goto LAB_0002f401;
LAB_0002ef17:
            iVar8 = local_28[0];
            if (local_28[0] == 0) {
              local_28[0] = iVar11;
            }
            else {
              piVar10 = (int *)in_ECX[0x466];
              iVar12 = piVar10[1];
              piVar9 = piVar10;
              if (iVar12 - 0xfe8U < 0xfffff008) {
                piVar9 = malloc(0x1000);
                if (piVar9 == (int *)0x0) goto LAB_0002f41d;
                *piVar9 = (int)piVar10;
                piVar9[1] = 0;
                in_ECX[0x466] = (int)piVar9;
                iVar12 = 0;
              }
              piVar9[1] = iVar12 + 0x10;
              *(undefined4 *)((int)piVar9 + iVar12 + 0xc) = 0x1010117;
              *(undefined ***)((int)piVar9 + iVar12 + 8) = &PTR_LAB_0004b3c0;
              *(int *)((int)piVar9 + iVar12 + 0x10) = iVar8;
              *(int *)((int)piVar9 + iVar12 + 0x14) = iVar11;
              local_28[0] = (int)piVar9 + iVar12 + 8;
            }
            if (in_EDX != (undefined1 *)0x0) {
              in_EDX[1] = 0;
            }
            FUN_0002f5d0();
          }
          break;
        case 0x54:
          iVar11 = FUN_00030b00();
joined_r0x0002efd9:
          if (iVar11 != 0) goto LAB_0002ef17;
          goto LAB_0002f401;
        }
      }
      if (pbVar16 == pbVar4) goto LAB_0002ed52;
LAB_0002ed4d:
      if (*pbVar16 != 0x4d) goto LAB_0002ed52;
      *in_ECX = (int)(pbVar16 + 1);
    } while (local_28[0] != 0);
  }
LAB_0002f401:
  iVar11 = 0;
LAB_0002f407:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar11;
}


// ==== FUN_0002f430 @ 0002f430

int FUN_0002f430(void)

{
  int iVar1;
  char cVar2;
  char *pcVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  char *pcVar7;
  int *piVar8;
  undefined4 *in_ECX;
  int in_GS_OFFSET;
  int local_20;
  undefined4 local_1c;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar7 = (char *)*in_ECX;
  pcVar3 = (char *)in_ECX[1];
  if (pcVar3 == pcVar7) {
LAB_0002f47f:
    iVar6 = FUN_0002d6e0();
  }
  else {
    cVar2 = *pcVar7;
    if (cVar2 == 'J') {
      pcVar7 = pcVar7 + 1;
      *in_ECX = pcVar7;
      iVar6 = in_ECX[3];
      iVar5 = in_ECX[2];
      if (pcVar7 == pcVar3) goto LAB_0002f4f5;
      while (*pcVar7 != 'E') {
LAB_0002f4f5:
        do {
          local_20 = FUN_0002f430();
          if (local_20 == 0) {
            iVar6 = 0;
            goto LAB_0002f486;
          }
          FUN_0002f5d0();
          pcVar7 = (char *)*in_ECX;
        } while (pcVar7 == (char *)in_ECX[1]);
      }
      *in_ECX = pcVar7 + 1;
      iVar6 = (iVar6 - iVar5 >> 2) * 4;
      FUN_00039de0(in_ECX[2] + iVar6,in_ECX[3]);
      in_ECX[3] = iVar6 + in_ECX[2];
      piVar4 = (int *)in_ECX[0x466];
      iVar6 = piVar4[1];
      piVar8 = piVar4;
      if (iVar6 - 0xfe8U < 0xfffff008) {
        piVar8 = malloc(0x1000);
        if (piVar8 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar8 = (int)piVar4;
        piVar8[1] = 0;
        in_ECX[0x466] = piVar8;
        iVar6 = 0;
      }
      piVar8[1] = iVar6 + 0x10;
      *(undefined4 *)((int)piVar8 + iVar6 + 0xc) = 0x1010121;
      *(undefined ***)((int)piVar8 + iVar6 + 8) = &PTR_LAB_0004bf90;
      *(undefined4 *)((int)piVar8 + iVar6 + 0x14) = local_1c;
      *(int *)((int)piVar8 + iVar6 + 0x10) = local_20;
      iVar6 = (int)piVar8 + iVar6 + 8;
      goto LAB_0002f486;
    }
    if (cVar2 == 'L') {
      if (((uint)((int)pcVar3 - (int)pcVar7) < 2) || (pcVar7[1] != 'Z')) {
        iVar6 = FUN_00032f90();
        goto LAB_0002f486;
      }
      *in_ECX = pcVar7 + 2;
      iVar5 = FUN_0002cc90();
    }
    else {
      if (cVar2 != 'X') goto LAB_0002f47f;
      *in_ECX = pcVar7 + 1;
      iVar5 = FUN_00031980();
    }
    iVar6 = 0;
    if (((iVar5 != 0) && (pcVar3 = (char *)*in_ECX, pcVar3 != (char *)in_ECX[1])) &&
       (*pcVar3 == 'E')) {
      *in_ECX = pcVar3 + 1;
      iVar6 = iVar5;
    }
  }
LAB_0002f486:
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar6;
}


// ==== FUN_0002f5d0 @ 0002f5d0

void FUN_0002f5d0(void)

{
  undefined4 *__src;
  undefined4 uVar1;
  void *__dest;
  undefined4 *in_ECX;
  undefined4 *in_EDX;
  size_t __n;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)in_ECX[1];
  if (puVar2 == (undefined4 *)in_ECX[2]) {
    __src = (undefined4 *)*in_ECX;
    __n = (int)puVar2 - (int)__src;
    if (__src == in_ECX + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_0002f679;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *in_ECX = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *in_ECX = __dest;
      if (__dest == (void *)0x0) {
LAB_0002f679:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
    }
    puVar2 = (undefined4 *)((int)__dest + ((int)__n >> 2) * 4);
    in_ECX[1] = puVar2;
    in_ECX[2] = (void *)((int)__dest + ((int)__n >> 1) * 4);
  }
  uVar1 = *in_EDX;
  in_ECX[1] = puVar2 + 1;
  *puVar2 = uVar1;
  return;
}


// ==== FUN_0002f680 @ 0002f680

int FUN_0002f680(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = in_EDX[1];
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010109;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004bfc8;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_0002f720 @ 0002f720

int FUN_0002f720(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
                undefined1 *param_5)

{
  undefined1 uVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int *piVar9;
  int in_ECX;
  int iVar10;
  undefined4 *in_EDX;
  
  piVar2 = *(int **)(in_ECX + 0x1198);
  iVar10 = piVar2[1];
  piVar9 = piVar2;
  if (iVar10 - 0xfc8U < 0xfffff008) {
    piVar9 = malloc(0x1000);
    if (piVar9 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar9 = (int)piVar2;
    piVar9[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar9;
    iVar10 = 0;
  }
  piVar9[1] = iVar10 + 0x30;
  uVar3 = *in_EDX;
  uVar1 = *param_5;
  uVar4 = *param_1;
  uVar5 = *param_2;
  uVar6 = param_2[1];
  uVar7 = *param_3;
  uVar8 = *param_4;
  *(undefined4 *)((int)piVar9 + iVar10 + 0xc) = 0x10012;
  *(undefined ***)((int)piVar9 + iVar10 + 8) = &PTR_LAB_0004c000;
  *(undefined4 *)((int)piVar9 + iVar10 + 0x10) = uVar3;
  *(undefined4 *)((int)piVar9 + iVar10 + 0x14) = uVar4;
  *(undefined4 *)((int)piVar9 + iVar10 + 0x18) = uVar5;
  *(undefined4 *)((int)piVar9 + iVar10 + 0x1c) = uVar6;
  *(undefined4 *)((int)piVar9 + iVar10 + 0x20) = uVar7;
  *(undefined4 *)((int)piVar9 + iVar10 + 0x24) = uVar8;
  *(undefined1 *)((int)piVar9 + iVar10 + 0x28) = uVar1;
  return (int)piVar9 + iVar10 + 8;
}


// ==== FUN_0002f810 @ 0002f810

int FUN_0002f810(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "vtable for ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0002f8b0 @ 0002f8b0

int FUN_0002f8b0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "VTT for ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0002f950 @ 0002f950

int FUN_0002f950(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "typeinfo for ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0002f9f0 @ 0002f9f0

int FUN_0002f9f0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "typeinfo name for ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0002fa90 @ 0002fa90

undefined4 FUN_0002fa90(void)

{
  char *pcVar1;
  char *pcVar2;
  int *in_ECX;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  pcVar4 = (char *)*in_ECX;
  pcVar2 = (char *)in_ECX[1];
  if (pcVar4 == pcVar2) {
    return 1;
  }
  if (*pcVar4 == 'h') {
    pcVar1 = pcVar4 + 1;
    *in_ECX = (int)pcVar1;
    if (pcVar1 != pcVar2) {
      pcVar3 = pcVar1;
      if (*pcVar1 == 'n') {
        pcVar3 = pcVar4 + 2;
        *in_ECX = (int)pcVar3;
      }
      if ((pcVar2 != pcVar3) && (0xfffffff5 < (int)*pcVar3 - 0x3aU)) {
        do {
          pcVar3 = pcVar3 + 1;
          *in_ECX = (int)pcVar3;
          if (pcVar3 == pcVar2) {
            pcVar4 = pcVar2;
            goto LAB_0002fb6d;
          }
        } while (0xfffffff5 < (int)*pcVar3 - 0x3aU);
        pcVar4 = pcVar3;
LAB_0002fb6d:
        if (pcVar1 != pcVar4) goto joined_r0x0002fbf1;
      }
    }
  }
  else {
    if (*pcVar4 != 'v') {
      return 1;
    }
    pcVar1 = pcVar4 + 1;
    *in_ECX = (int)pcVar1;
    if (pcVar1 == pcVar2) {
      return 1;
    }
    pcVar3 = pcVar1;
    if (*pcVar1 == 'n') {
      pcVar3 = pcVar4 + 2;
      *in_ECX = (int)pcVar3;
    }
    if (pcVar2 == pcVar3) {
      return 1;
    }
    if (0xfffffff5 < (int)*pcVar3 - 0x3aU) {
      do {
        pcVar4 = pcVar3;
        pcVar3 = pcVar4 + 1;
        *in_ECX = (int)pcVar3;
        if (pcVar3 == pcVar2) {
          pcVar5 = pcVar2;
          goto LAB_0002fb8a;
        }
      } while (0xfffffff5 < (int)*pcVar3 - 0x3aU);
      pcVar5 = pcVar3;
LAB_0002fb8a:
      if (pcVar1 == pcVar5) {
        return 1;
      }
      if (pcVar3 == pcVar2) {
        return 1;
      }
      if (*pcVar3 != '_') {
        return 1;
      }
      pcVar1 = pcVar4 + 2;
      *in_ECX = (int)pcVar1;
      if (pcVar1 == pcVar2) {
        return 1;
      }
      pcVar3 = pcVar1;
      if (*pcVar1 == 'n') {
        pcVar3 = pcVar4 + 3;
        *in_ECX = (int)pcVar3;
      }
      if ((pcVar2 != pcVar3) && (0xfffffff5 < (int)*pcVar3 - 0x3aU)) {
        do {
          pcVar3 = pcVar3 + 1;
          *in_ECX = (int)pcVar3;
          if (pcVar3 == pcVar2) {
            pcVar4 = pcVar2;
            goto LAB_0002fbe9;
          }
        } while (0xfffffff5 < (int)*pcVar3 - 0x3aU);
        pcVar4 = pcVar3;
LAB_0002fbe9:
        if (pcVar1 == pcVar4) {
          return 1;
        }
joined_r0x0002fbf1:
        if (pcVar3 == pcVar2) {
          return 1;
        }
        if (*pcVar3 == '_') {
          *in_ECX = (int)(pcVar3 + 1);
          return 0;
        }
        return 1;
      }
    }
  }
  return 1;
}


// ==== FUN_0002fc00 @ 0002fc00

int FUN_0002fc00(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "covariant return thunk to ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0002fca0 @ 0002fca0

int FUN_0002fca0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010115;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b350;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_0002fd40 @ 0002fd40

int FUN_0002fd40(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "thread-local initialization routine for ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0002fde0 @ 0002fde0

int FUN_0002fde0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "virtual thunk to ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0002fe80 @ 0002fe80

int FUN_0002fe80(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010114;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b310;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "non-virtual thunk to ";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00030010 @ 00030010

void FUN_00030010(void)

{
  return;
}


// ==== FUN_000301b0 @ 000301b0

int FUN_000301b0(void)

{
  byte *pbVar1;
  int iVar2;
  byte *pbVar3;
  byte bVar4;
  int iVar5;
  int *piVar6;
  int *in_ECX;
  int iVar7;
  byte *pbVar8;
  undefined4 uVar9;
  int *piVar10;
  int in_GS_OFFSET;
  
  iVar2 = *(int *)(in_GS_OFFSET + 0x14);
  pbVar8 = (byte *)*in_ECX;
  pbVar3 = (byte *)in_ECX[1];
  iVar5 = 0;
  if ((pbVar8 == pbVar3) || (*pbVar8 != 0x53)) goto switchD_00030261_caseD_63;
  pbVar1 = pbVar8 + 1;
  *in_ECX = (int)pbVar1;
  if (pbVar3 == pbVar1) goto switchD_00030261_caseD_63;
  if ((int)(char)*pbVar1 - 0x7bU < 0xffffffe6) {
    iVar5 = 0;
    if (*pbVar1 == 0x5f) {
      *in_ECX = (int)(pbVar8 + 2);
      if ((int *)in_ECX[0x25] != (int *)in_ECX[0x26]) {
        iVar5 = *(int *)in_ECX[0x25];
      }
    }
    else {
      bVar4 = *pbVar1;
      if (('/' < (char)bVar4) && ((bVar4 < 0x3a || ((byte)(bVar4 + 0xbf) < 0x1a)))) {
        pbVar8 = pbVar8 + 2;
        iVar7 = 0;
        do {
          iVar5 = -0x30;
          if ((0x39 < bVar4) && (iVar5 = -0x37, 0x19 < (byte)(bVar4 + 0xbf))) break;
          *in_ECX = (int)pbVar8;
          if (pbVar8 == pbVar3) {
            iVar5 = 0;
            goto switchD_00030261_caseD_63;
          }
          iVar7 = (uint)bVar4 + iVar7 * 0x24 + iVar5;
          bVar4 = *pbVar8;
          pbVar8 = pbVar8 + 1;
        } while ('/' < (char)bVar4);
        iVar5 = 0;
        if ((pbVar8 + -1 != pbVar3) && (pbVar8[-1] == 0x5f)) {
          *in_ECX = (int)pbVar8;
          iVar5 = 0;
          if (iVar7 + 1U < (uint)(in_ECX[0x26] - in_ECX[0x25] >> 2)) {
            iVar5 = *(int *)(in_ECX[0x25] + 4 + iVar7 * 4);
          }
        }
      }
    }
    goto switchD_00030261_caseD_63;
  }
  iVar5 = 0;
  switch((int)(char)*pbVar1) {
  case 0x61:
    *in_ECX = (int)(pbVar8 + 2);
    piVar10 = (int *)in_ECX[0x466];
    iVar5 = piVar10[1];
    uVar9 = 0;
    if (iVar5 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) {
LAB_00030555:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      uVar9 = 0;
LAB_000304d6:
      *piVar6 = (int)piVar10;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar5 = 0;
      piVar10 = piVar6;
    }
    break;
  case 0x62:
    *in_ECX = (int)(pbVar8 + 2);
    piVar10 = (int *)in_ECX[0x466];
    iVar5 = piVar10[1];
    uVar9 = 1;
    if (iVar5 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00030555;
      uVar9 = 1;
      goto LAB_000304d6;
    }
    break;
  case 99:
  case 0x65:
  case 0x66:
  case 0x67:
  case 0x68:
  case 0x6a:
  case 0x6b:
  case 0x6c:
  case 0x6d:
  case 0x6e:
  case 0x70:
  case 0x71:
  case 0x72:
    goto switchD_00030261_caseD_63;
  case 100:
    *in_ECX = (int)(pbVar8 + 2);
    piVar10 = (int *)in_ECX[0x466];
    iVar5 = piVar10[1];
    uVar9 = 5;
    if (iVar5 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00030555;
      uVar9 = 5;
      goto LAB_000304d6;
    }
    break;
  case 0x69:
    *in_ECX = (int)(pbVar8 + 2);
    piVar10 = (int *)in_ECX[0x466];
    iVar5 = piVar10[1];
    uVar9 = 3;
    if (iVar5 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00030555;
      uVar9 = 3;
      goto LAB_000304d6;
    }
    break;
  case 0x6f:
    *in_ECX = (int)(pbVar8 + 2);
    piVar10 = (int *)in_ECX[0x466];
    iVar5 = piVar10[1];
    uVar9 = 4;
    if (iVar5 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00030555;
      uVar9 = 4;
      goto LAB_000304d6;
    }
    break;
  case 0x73:
    *in_ECX = (int)(pbVar8 + 2);
    piVar10 = (int *)in_ECX[0x466];
    iVar5 = piVar10[1];
    uVar9 = 2;
    if (iVar5 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00030555;
      uVar9 = 2;
      goto LAB_000304d6;
    }
    break;
  default:
    iVar5 = 0;
    goto switchD_00030261_caseD_63;
  }
  piVar10[1] = iVar5 + 0x10;
  *(undefined4 *)((int)piVar10 + iVar5 + 0xc) = 0x1010129;
  *(undefined ***)((int)piVar10 + iVar5 + 8) = &PTR_LAB_0004be78;
  *(undefined4 *)((int)piVar10 + iVar5 + 0x10) = uVar9;
  iVar5 = (int)piVar10 + iVar5 + 8;
  iVar7 = FUN_00030fe0();
  if (iVar7 != iVar5) {
    FUN_0002f5d0();
    iVar5 = iVar7;
  }
switchD_00030261_caseD_63:
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar2) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar5;
}


// ==== FUN_00030570 @ 00030570

int FUN_00030570(void)

{
  undefined4 *puVar1;
  char *pcVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  int iVar10;
  undefined4 *in_ECX;
  undefined4 *__src;
  int iVar11;
  char in_DL;
  int iVar12;
  int in_GS_OFFSET;
  undefined4 *local_38;
  undefined4 *local_34;
  undefined1 *local_30;
  undefined4 local_2c [4];
  undefined1 local_1c [4];
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar2 = (char *)*in_ECX;
  if ((pcVar2 != (char *)in_ECX[1]) && (*pcVar2 == 'I')) {
    *in_ECX = pcVar2 + 1;
    if (in_DL != '\0') {
      in_ECX[0x54] = in_ECX[0x53];
      local_38 = in_ECX + 0x48;
      FUN_000315a0();
      in_ECX[0x49] = in_ECX[0x48];
    }
    iVar10 = in_ECX[3];
    iVar3 = in_ECX[2];
    puVar1 = in_ECX + 0x56;
LAB_00030628:
    do {
      pcVar2 = (char *)*in_ECX;
      if ((pcVar2 != (char *)in_ECX[1]) && (*pcVar2 == 'E')) {
        *in_ECX = pcVar2 + 1;
        iVar10 = (iVar10 - iVar3 >> 2) * 4;
        FUN_00039de0(in_ECX[2] + iVar10,in_ECX[3]);
        in_ECX[3] = iVar10 + in_ECX[2];
        piVar5 = (int *)in_ECX[0x466];
        iVar10 = piVar5[1];
        piVar9 = piVar5;
        if (iVar10 - 0xfe8U < 0xfffff008) {
          piVar9 = malloc(0x1000);
          if (piVar9 == (int *)0x0) {
LAB_00030a30:
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar9 = (int)piVar5;
          piVar9[1] = 0;
          in_ECX[0x466] = piVar9;
          iVar10 = 0;
        }
        piVar9[1] = iVar10 + 0x10;
        *(undefined4 *)((int)piVar9 + iVar10 + 0xc) = 0x1010123;
        *(undefined ***)((int)piVar9 + iVar10 + 8) = &PTR_LAB_0004bee8;
        *(undefined4 **)((int)piVar9 + iVar10 + 0x14) = local_34;
        *(undefined4 **)((int)piVar9 + iVar10 + 0x10) = local_38;
        iVar10 = (int)piVar9 + iVar10 + 8;
        goto LAB_0003097f;
      }
      if (in_DL == '\0') {
        local_38 = (undefined4 *)FUN_0002f430();
        if (local_38 == (undefined4 *)0x0) break;
        FUN_0002f5d0();
        goto LAB_00030628;
      }
      local_38 = local_2c;
      local_30 = local_1c;
      local_2c[0] = 0;
      local_2c[1] = 0;
      local_2c[2] = 0;
      local_2c[3] = 0;
      puVar7 = (undefined4 *)in_ECX[0x53];
      if (puVar7 == puVar1) {
        if (in_ECX[0x54] - (int)puVar1 == 0) {
          iVar6 = 0;
          puVar7 = puVar1;
        }
        else {
          __memmove_chk(local_2c,puVar1,in_ECX[0x54] - (int)puVar1,0x10);
          iVar6 = in_ECX[0x54] - (int)in_ECX[0x53] >> 2;
          puVar7 = (undefined4 *)in_ECX[0x53];
        }
        local_34 = local_2c + iVar6;
        in_ECX[0x54] = puVar7;
      }
      else {
        local_34 = (undefined4 *)in_ECX[0x54];
        local_30 = (undefined1 *)in_ECX[0x55];
        in_ECX[0x53] = puVar1;
        in_ECX[0x54] = puVar1;
        in_ECX[0x55] = in_ECX + 0x5a;
        local_38 = puVar7;
      }
                    /* try { // try from 00030717 to 0003071d has its CatchHandler @ 00030a3a */
      iVar6 = FUN_0002f430();
      puVar7 = (undefined4 *)in_ECX[0x53];
      if (local_38 == local_2c) {
        if (puVar7 == puVar1) {
          __src = local_2c;
        }
        else {
          free(puVar7);
          in_ECX[0x53] = puVar1;
          in_ECX[0x54] = puVar1;
          in_ECX[0x55] = in_ECX + 0x5a;
          puVar7 = puVar1;
          __src = local_38;
        }
        if ((int)local_34 - (int)__src == 0) {
          iVar8 = 0;
          puVar7 = puVar1;
        }
        else {
          memmove(puVar7,__src,(int)local_34 - (int)__src);
          iVar8 = (int)local_34 - (int)local_38 >> 2;
          __src = local_38;
          puVar7 = (undefined4 *)in_ECX[0x53];
        }
        in_ECX[0x54] = puVar7 + iVar8;
        local_34 = __src;
      }
      else {
        in_ECX[0x53] = local_38;
        if (puVar7 == puVar1) {
          in_ECX[0x54] = local_34;
          in_ECX[0x55] = local_30;
          local_34 = local_2c;
          local_38 = local_2c;
        }
        else {
          in_ECX[0x54] = local_34;
          in_ECX[0x55] = local_30;
          local_34 = puVar7;
          local_38 = puVar7;
        }
      }
      puVar7 = local_34;
      if (iVar6 != 0) {
        FUN_0002f5d0();
        if (*(char *)(iVar6 + 4) == '!') {
          iVar8 = *(int *)(iVar6 + 8);
          iVar4 = *(int *)(iVar6 + 0xc);
          piVar5 = (int *)in_ECX[0x466];
          iVar11 = piVar5[1];
          piVar9 = piVar5;
          if (iVar11 - 0xfe8U < 0xfffff008) {
            piVar9 = malloc(0x1000);
            if (piVar9 == (int *)0x0) goto LAB_00030a30;
            *piVar9 = (int)piVar5;
            piVar9[1] = 0;
            in_ECX[0x466] = piVar9;
            iVar11 = 0;
          }
          piVar9[1] = iVar11 + 0x10;
          *(undefined4 *)((int)piVar9 + iVar11 + 0xc) = 0x2020220;
          *(undefined ***)((int)piVar9 + iVar11 + 8) = &PTR_LAB_0004beb0;
          *(int *)((int)piVar9 + iVar11 + 0x14) = iVar4;
          *(int *)((int)piVar9 + iVar11 + 0x10) = iVar8;
          if (iVar4 != 0) {
            iVar12 = 0;
            do {
              if (*(char *)(*(int *)(iVar8 + iVar12) + 6) != '\x01') goto LAB_000308e4;
              iVar12 = iVar12 + 4;
            } while (iVar4 * 4 != iVar12);
          }
          *(undefined1 *)((int)piVar9 + iVar11 + 0xe) = 1;
LAB_000308e4:
          if (iVar4 != 0) {
            iVar12 = 0;
            do {
              if (*(char *)(*(int *)(iVar8 + iVar12) + 7) != '\x01') goto LAB_00030914;
              iVar12 = iVar12 + 4;
            } while (iVar4 * 4 != iVar12);
          }
          *(undefined1 *)((int)piVar9 + iVar11 + 0xf) = 1;
LAB_00030914:
          if (iVar4 != 0) {
            iVar12 = 0;
            do {
              if (*(char *)(*(int *)(iVar8 + iVar12) + 5) != '\x01') goto LAB_0003094e;
              iVar12 = iVar12 + 4;
            } while (iVar4 << 2 != iVar12);
          }
          *(undefined1 *)((int)piVar9 + iVar11 + 0xd) = 1;
        }
LAB_0003094e:
        FUN_00037f60();
        puVar7 = local_38;
      }
      if (puVar7 != local_2c) {
        free(puVar7);
      }
    } while (iVar6 != 0);
  }
  iVar10 = 0;
LAB_0003097f:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar10;
}


// ==== FUN_00030a60 @ 00030a60

int FUN_00030a60(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010125;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004bf20;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00030b00 @ 00030b00

int FUN_00030b00(void)

{
  char *pcVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  int *__src;
  int iVar5;
  int *piVar6;
  char *pcVar7;
  void *__dest;
  int *in_ECX;
  uint uVar8;
  uint uVar9;
  int iVar10;
  size_t __n;
  int *piVar11;
  uint uVar12;
  int in_GS_OFFSET;
  
  iVar2 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar3 = (char *)*in_ECX;
  pcVar4 = (char *)in_ECX[1];
  iVar5 = 0;
  if ((pcVar3 != pcVar4) && (*pcVar3 == 'T')) {
    pcVar7 = pcVar3 + 1;
    *in_ECX = (int)pcVar7;
    if (pcVar7 == pcVar4) goto LAB_00030e95;
    uVar8 = 0;
    if (*pcVar7 == 'L') {
      pcVar7 = pcVar3 + 2;
      *in_ECX = (int)pcVar7;
      if ((pcVar4 == pcVar7) || ((byte)(*pcVar7 - 0x3aU) < 0xf6)) {
        iVar5 = 0;
        goto LAB_00030e95;
      }
      iVar5 = 0;
      pcVar3 = pcVar3 + 4;
      do {
        pcVar7 = pcVar3;
        pcVar1 = pcVar7 + -1;
        *in_ECX = (int)pcVar1;
        iVar10 = (int)pcVar7[-2] + iVar5 * 10;
        iVar5 = iVar10 + -0x30;
        if (pcVar1 == pcVar4) break;
        pcVar3 = pcVar7 + 1;
      } while ((byte)(pcVar7[-1] - 0x30U) < 10);
      iVar5 = 0;
      if ((pcVar1 == pcVar4) || (pcVar7[-1] != '_')) goto LAB_00030e95;
      uVar8 = iVar10 - 0x2f;
      *in_ECX = (int)pcVar7;
    }
    iVar5 = 0;
    if (pcVar7 == pcVar4) goto LAB_00030e95;
    uVar9 = 0;
    if (*pcVar7 != '_') {
      iVar5 = 0;
      if ((byte)(*pcVar7 - 0x3aU) < 0xf6) goto LAB_00030e95;
      iVar5 = 0;
      pcVar3 = pcVar7;
      do {
        pcVar7 = pcVar3 + 1;
        *in_ECX = (int)pcVar7;
        iVar10 = (int)*pcVar3 + iVar5 * 10;
        iVar5 = iVar10 + -0x30;
        if (pcVar7 == pcVar4) break;
        pcVar3 = pcVar7;
      } while ((byte)(*pcVar7 - 0x30U) < 10);
      iVar5 = 0;
      if ((pcVar7 == pcVar4) || (*pcVar7 != '_')) goto LAB_00030e95;
      uVar9 = iVar10 - 0x2f;
    }
    *in_ECX = (int)(pcVar7 + 1);
    if ((*(char *)((int)in_ECX + 0x185) == '\0') || (uVar8 != 0)) {
      uVar12 = in_ECX[0x54] - in_ECX[0x53] >> 2;
      if ((uVar8 < uVar12) &&
         ((piVar11 = *(int **)(in_ECX[0x53] + uVar8 * 4), piVar11 != (int *)0x0 &&
          (uVar9 < (uint)(piVar11[1] - *piVar11 >> 2))))) {
        iVar5 = *(int *)(*piVar11 + uVar9 * 4);
      }
      else {
        iVar5 = 0;
        if ((in_ECX[0x62] == uVar8) && (uVar8 <= uVar12)) {
          if (uVar8 == uVar12) {
            FUN_000315a0();
          }
          piVar11 = (int *)in_ECX[0x466];
          iVar10 = piVar11[1];
          piVar6 = piVar11;
          if (iVar10 - 0xfe8U < 0xfffff008) {
            piVar6 = malloc(0x1000);
            if (piVar6 == (int *)0x0) goto LAB_00030eae;
            *piVar6 = (int)piVar11;
            piVar6[1] = 0;
            in_ECX[0x466] = (int)piVar6;
            iVar10 = 0;
          }
          piVar6[1] = iVar10 + 0x10;
          iVar5 = (int)piVar6 + iVar10 + 8;
          *(undefined4 *)((int)piVar6 + iVar10 + 0xc) = 0x1010107;
          *(undefined ***)((int)piVar6 + iVar10 + 8) = &PTR_LAB_0004b388;
          *(undefined **)((int)piVar6 + iVar10 + 0x10) = &DAT_00013ffe;
          *(undefined **)((int)piVar6 + iVar10 + 0x14) = &DAT_00014002;
        }
      }
      goto LAB_00030e95;
    }
    piVar11 = (int *)in_ECX[0x466];
    iVar5 = piVar11[1];
    if (iVar5 - 0xfd8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00030eae;
      *piVar6 = (int)piVar11;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar5 = 0;
      piVar11 = piVar6;
    }
    piVar11[1] = iVar5 + 0x20;
    *(undefined4 *)((int)piVar11 + iVar5 + 0xc) = 0x2020224;
    *(undefined ***)((int)piVar11 + iVar5 + 8) = &PTR_LAB_0004b3f8;
    *(uint *)((int)piVar11 + iVar5 + 0x10) = uVar9;
    *(undefined4 *)((int)piVar11 + iVar5 + 0x14) = 0;
    *(undefined1 *)((int)piVar11 + iVar5 + 0x18) = 0;
    piVar6 = (int *)in_ECX[0x5b];
    if (piVar6 == (int *)in_ECX[0x5c]) {
      __src = (int *)in_ECX[0x5a];
      __n = (int)piVar6 - (int)__src;
      if (__src == in_ECX + 0x5d) {
        __dest = malloc(__n * 2);
        if (__dest == (void *)0x0) goto LAB_00030eae;
        if (__n != 0) {
          memmove(__dest,__src,__n);
        }
        in_ECX[0x5a] = (int)__dest;
      }
      else {
        __dest = realloc(__src,__n * 2);
        in_ECX[0x5a] = (int)__dest;
        if (__dest == (void *)0x0) {
LAB_00030eae:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
      }
      piVar6 = (int *)((int)__dest + ((int)__n >> 2) * 4);
      in_ECX[0x5c] = (int)((int)__dest + ((int)__n >> 1) * 4);
    }
    iVar5 = (int)piVar11 + iVar5 + 8;
    in_ECX[0x5b] = (int)(piVar6 + 1);
    *piVar6 = iVar5;
  }
LAB_00030e95:
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar2) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar5;
}


// ==== FUN_00030ec0 @ 00030ec0

int FUN_00030ec0(void)

{
  byte *pbVar1;
  byte *pbVar2;
  char *pcVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *in_ECX;
  int iVar7;
  
  pbVar2 = (byte *)*in_ECX;
  iVar7 = 0;
  if ((pbVar2 != (byte *)in_ECX[1]) && (*pbVar2 == 0x44)) {
    pbVar1 = pbVar2 + 1;
    *in_ECX = (int)pbVar1;
    if ((pbVar1 != (byte *)in_ECX[1]) && ((*pbVar1 | 0x20) == 0x74)) {
      *in_ECX = (int)(pbVar2 + 2);
      iVar5 = FUN_00031980();
      if (((iVar5 != 0) && (pcVar3 = (char *)*in_ECX, pcVar3 != (char *)in_ECX[1])) &&
         (*pcVar3 == 'E')) {
        *in_ECX = (int)(pcVar3 + 1);
        piVar4 = (int *)in_ECX[0x466];
        iVar7 = piVar4[1];
        piVar6 = piVar4;
        if (iVar7 - 0xfd8U < 0xfffff008) {
          piVar6 = malloc(0x1000);
          if (piVar6 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar6 = (int)piVar4;
          piVar6[1] = 0;
          in_ECX[0x466] = (int)piVar6;
          iVar7 = 0;
        }
        piVar6[1] = iVar7 + 0x20;
        *(undefined4 *)((int)piVar6 + iVar7 + 0xc) = 0x1010134;
        *(undefined ***)((int)piVar6 + iVar7 + 8) = &PTR_LAB_0004bc10;
        *(char **)((int)piVar6 + iVar7 + 0x10) = "decltype(";
        *(char **)((int)piVar6 + iVar7 + 0x14) = "";
        *(int *)((int)piVar6 + iVar7 + 0x18) = iVar5;
        *(undefined **)((int)piVar6 + iVar7 + 0x1c) = &DAT_000150c3;
        *(undefined **)((int)piVar6 + iVar7 + 0x20) = &DAT_000150c4;
        iVar7 = (int)piVar6 + iVar7 + 8;
      }
    }
  }
  return iVar7;
}


// ==== FUN_00030fe0 @ 00030fe0

int FUN_00030fe0(void)

{
  int iVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  char *pcVar4;
  uint uVar5;
  char *pcVar6;
  int *piVar7;
  int *in_ECX;
  int iVar8;
  int in_EDX;
  int iVar9;
  int *piVar10;
  char *pcVar11;
  uint local_30;
  int local_2c;
  
  pcVar4 = (char *)*in_ECX;
  pcVar11 = (char *)in_ECX[1];
  if (pcVar4 == pcVar11) {
LAB_000311b5:
    local_2c = in_EDX;
  }
  else {
    do {
      if (*pcVar4 != 'B') goto LAB_000311b5;
      pcVar6 = pcVar4 + 1;
      *in_ECX = (int)pcVar6;
      if (pcVar11 == pcVar6) {
        return 0;
      }
      if ((byte)(*pcVar6 - 0x3aU) < 0xf6) {
        return 0;
      }
      local_30 = 0;
      pcVar6 = pcVar4 + 2;
      iVar1 = 0x2e - (int)pcVar4;
      uVar5 = local_30;
      do {
        local_30 = uVar5;
        iVar9 = iVar1;
        pcVar4 = pcVar6;
        *in_ECX = (int)pcVar4;
        uVar5 = ((int)pcVar4[-1] + local_30 * 10) - 0x30;
        if (pcVar4 == pcVar11) {
          pcVar6 = pcVar11;
          goto LAB_00031126;
        }
        pcVar6 = pcVar4 + 1;
        iVar1 = iVar9 + -1;
      } while ((byte)(*pcVar4 - 0x30U) < 10);
      pcVar6 = pcVar4;
LAB_00031126:
      if ((uint)((int)pcVar11 - (int)pcVar6) < uVar5) {
        return 0;
      }
      iVar1 = (int)pcVar4[-1] + local_30 * 10;
      *in_ECX = (int)(pcVar4 + iVar1 + -0x30);
      if (uVar5 == 0) {
        return 0;
      }
      piVar10 = (int *)in_ECX[0x466];
      iVar8 = piVar10[1];
      if (iVar8 - 0xfd8U < 0xfffff008) {
        piVar7 = malloc(0x1000);
        if (piVar7 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar7 = (int)piVar10;
        piVar7[1] = 0;
        in_ECX[0x466] = (int)piVar7;
        iVar8 = 0;
        piVar10 = piVar7;
      }
      piVar10[1] = iVar8 + 0x20;
      uVar2 = *(undefined1 *)(in_EDX + 7);
      uVar3 = *(undefined2 *)(in_EDX + 5);
      *(undefined1 *)((int)piVar10 + iVar8 + 0xc) = 8;
      *(undefined2 *)((int)piVar10 + iVar8 + 0xd) = uVar3;
      *(undefined1 *)((int)piVar10 + iVar8 + 0xf) = uVar2;
      *(undefined ***)((int)piVar10 + iVar8 + 8) = &PTR_LAB_0004bdd0;
      *(int *)((int)piVar10 + iVar8 + 0x10) = in_EDX;
      *(char **)((int)piVar10 + iVar8 + 0x14) = pcVar6;
      in_EDX = (int)piVar10 + iVar8 + 8;
      *(int *)((int)piVar10 + iVar8 + 0x18) = iVar1 - iVar9;
      pcVar4 = (char *)*in_ECX;
      pcVar11 = (char *)in_ECX[1];
    } while (pcVar4 != pcVar11);
    local_2c = in_EDX;
  }
  return local_2c;
}


// ==== FUN_000311e0 @ 000311e0

undefined4 FUN_000311e0(void)

{
  int iVar1;
  char *pcVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *in_ECX;
  int in_GS_OFFSET;
  int local_20;
  undefined4 local_1c;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar2 = (char *)*in_ECX;
  if ((char *)in_ECX[1] == pcVar2) {
LAB_00031241:
    if ((((uint)((int)in_ECX[1] - (int)pcVar2) < 2) || (*pcVar2 != 'D')) || (pcVar2[1] != 'C')) {
      iVar5 = FUN_0003a900();
joined_r0x00031364:
      if (iVar5 != 0) goto LAB_00031366;
    }
    else {
      *in_ECX = pcVar2 + 2;
      iVar5 = in_ECX[3];
      iVar3 = in_ECX[2];
      local_20 = FUN_0003a4f0();
      if (local_20 != 0) {
        do {
          FUN_0002f5d0();
          pcVar2 = (char *)*in_ECX;
          if ((pcVar2 != (char *)in_ECX[1]) && (*pcVar2 == 'E')) {
            *in_ECX = pcVar2 + 1;
            iVar5 = (iVar5 - iVar3 >> 2) * 4;
            FUN_00039de0(in_ECX[2] + iVar5,in_ECX[3]);
            in_ECX[3] = iVar5 + in_ECX[2];
            piVar4 = (int *)in_ECX[0x466];
            iVar5 = piVar4[1];
            piVar6 = piVar4;
            if (iVar5 - 0xfe8U < 0xfffff008) {
              piVar6 = malloc(0x1000);
              if (piVar6 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
                FUN_0002c220();
              }
              *piVar6 = (int)piVar4;
              piVar6[1] = 0;
              in_ECX[0x466] = piVar6;
              iVar5 = 0;
            }
            piVar6[1] = iVar5 + 0x10;
            *(undefined4 *)((int)piVar6 + iVar5 + 0xc) = 0x101012e;
            *(undefined ***)((int)piVar6 + iVar5 + 8) = &PTR_LAB_0004be08;
            *(undefined4 *)((int)piVar6 + iVar5 + 0x14) = local_1c;
            *(int *)((int)piVar6 + iVar5 + 0x10) = local_20;
            goto LAB_00031366;
          }
          local_20 = FUN_0003a4f0();
        } while (local_20 != 0);
      }
    }
LAB_0003137e:
    if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
LAB_00031399:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
    uVar7 = 0;
  }
  else {
    if (*pcVar2 == 'U') {
      iVar5 = FUN_000362a0();
      goto joined_r0x00031364;
    }
    if (8 < (byte)(*pcVar2 - 0x31U)) goto LAB_00031241;
    iVar5 = FUN_0003a4f0();
    if (iVar5 == 0) goto LAB_0003137e;
LAB_00031366:
    uVar7 = FUN_00030fe0();
    if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) goto LAB_00031399;
  }
  return uVar7;
}


// ==== FUN_000315a0 @ 000315a0

void FUN_000315a0(void)

{
  undefined4 *__src;
  undefined4 uVar1;
  void *__dest;
  undefined4 *in_ECX;
  undefined4 *in_EDX;
  size_t __n;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)in_ECX[1];
  if (puVar2 == (undefined4 *)in_ECX[2]) {
    __src = (undefined4 *)*in_ECX;
    __n = (int)puVar2 - (int)__src;
    if (__src == in_ECX + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_00031649;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *in_ECX = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *in_ECX = __dest;
      if (__dest == (void *)0x0) {
LAB_00031649:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
    }
    puVar2 = (undefined4 *)((int)__dest + ((int)__n >> 2) * 4);
    in_ECX[1] = puVar2;
    in_ECX[2] = (void *)((int)__dest + ((int)__n >> 1) * 4);
  }
  uVar1 = *in_EDX;
  in_ECX[1] = puVar2 + 1;
  *puVar2 = uVar1;
  return;
}


// ==== FUN_00031650 @ 00031650

int FUN_00031650(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_00031980 @ 00031980

undefined4 FUN_00031980(void)

{
  char *pcVar1;
  char *pcVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined *puVar6;
  int *in_ECX;
  uint uVar7;
  char *pcVar8;
  int iVar9;
  int in_GS_OFFSET;
  undefined8 uVar10;
  undefined8 in_stack_fffffe70;
  undefined4 local_17c;
  int local_14c;
  undefined *local_148;
  undefined *puStack_144;
  undefined *local_140;
  undefined *puStack_13c;
  undefined *local_138;
  undefined *puStack_134;
  undefined *local_130;
  undefined *puStack_12c;
  undefined *local_128;
  undefined *puStack_124;
  undefined *local_120;
  undefined *puStack_11c;
  undefined *local_118;
  undefined *puStack_114;
  undefined *local_110;
  undefined *puStack_10c;
  undefined *local_108;
  undefined *puStack_104;
  undefined *local_100;
  undefined *puStack_fc;
  undefined *local_f8;
  undefined *puStack_f4;
  undefined *local_f0;
  undefined *puStack_ec;
  undefined *local_e8;
  undefined *puStack_e4;
  undefined *local_e0;
  undefined *puStack_dc;
  undefined *local_d8;
  undefined *puStack_d4;
  undefined *local_d0;
  undefined *puStack_cc;
  undefined *local_c8;
  undefined *puStack_c4;
  undefined *local_c0;
  undefined *puStack_bc;
  undefined *local_b8;
  undefined *puStack_b4;
  undefined *local_b0;
  undefined *puStack_ac;
  undefined1 *local_a8;
  undefined1 *puStack_a4;
  undefined *local_a0;
  undefined *puStack_9c;
  undefined *local_98;
  undefined *puStack_94;
  undefined *local_90;
  undefined *puStack_8c;
  undefined *local_88;
  undefined *puStack_84;
  undefined *local_80;
  undefined *puStack_7c;
  undefined *local_78;
  undefined *puStack_74;
  undefined *local_70;
  undefined *puStack_6c;
  undefined *local_68;
  undefined *puStack_64;
  undefined *local_60;
  undefined *puStack_5c;
  int local_58 [3];
  uint local_4c;
  undefined *local_48;
  undefined *puStack_44;
  undefined *local_40;
  undefined *puStack_3c;
  undefined *local_38;
  undefined *puStack_34;
  undefined *local_30;
  undefined *puStack_2c;
  undefined *local_28;
  undefined *puStack_24;
  undefined1 local_19;
  int local_18;
  
  uVar5 = (undefined4)((ulonglong)in_stack_fffffe70 >> 0x20);
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar8 = (char *)*in_ECX;
  pcVar2 = (char *)in_ECX[1];
  uVar7 = (int)pcVar2 - (int)pcVar8;
  local_17c = 0;
  if (uVar7 < 2) goto switchD_00031ab5_caseD_66;
  cVar4 = *pcVar8;
  if ((cVar4 == 'g') && (pcVar8[1] == 's')) {
    pcVar8 = pcVar8 + 2;
    *in_ECX = (int)pcVar8;
    uVar7 = (int)pcVar2 - (int)pcVar8;
    local_19 = 1;
    if (uVar7 < 2) goto switchD_00031ab5_caseD_66;
    cVar4 = *pcVar8;
  }
  else {
    local_19 = 0;
  }
  switch(cVar4) {
  case '1':
  case '2':
  case '3':
  case '4':
  case '5':
  case '6':
  case '7':
  case '8':
  case '9':
switchD_00031a30_caseD_31:
    uVar5 = FUN_00034840();
    goto LAB_00032d53;
  default:
    if (((10 < uVar7) && (cVar4 == 'u')) && ((pcVar8[1] == '8' && (pcVar8[2] == '_')))) {
      if ((((((pcVar8[3] == '_') && (pcVar8[4] == 'u')) && (pcVar8[5] == 'u')) &&
           ((pcVar8[6] == 'i' && (pcVar8[7] == 'd')))) && (pcVar8[8] == 'o')) &&
         ((pcVar8[9] == 'f' && (pcVar8[10] == 't')))) {
        *in_ECX = (int)(pcVar8 + 0xb);
        local_58[0] = FUN_0002d6e0();
      }
      else {
        if ((((pcVar8[3] != '_') || (pcVar8[4] != 'u')) || (pcVar8[5] != 'u')) ||
           (((pcVar8[6] != 'i' || (pcVar8[7] != 'd')) ||
            ((pcVar8[8] != 'o' || ((pcVar8[9] != 'f' || (pcVar8[10] != 'z')))))))) break;
        *in_ECX = (int)(pcVar8 + 0xb);
        local_58[0] = FUN_00031980();
      }
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_17c = FUN_00035f00();
    }
    break;
  case 'L':
    uVar5 = FUN_00032f90();
    goto LAB_00032d53;
  case 'T':
    uVar5 = FUN_00030b00();
    goto LAB_00032d53;
  case 'a':
    switch(pcVar8[1]) {
    case 'N':
      *in_ECX = (int)(pcVar8 + 2);
      local_40 = &DAT_000143ac;
      puStack_3c = &DAT_000143ae;
      uVar10 = 0x143ae000143ac;
      break;
    default:
      goto switchD_00031ab5_caseD_66;
    case 'S':
      *in_ECX = (int)(pcVar8 + 2);
      local_48 = &DAT_000148b3;
      puStack_44 = &DAT_000148b4;
      uVar10 = 0x148b4000148b3;
      break;
    case 'a':
      *in_ECX = (int)(pcVar8 + 2);
      local_28 = &DAT_00014ebb;
      puStack_24 = &DAT_00014ebd;
      uVar10 = 0x14ebd00014ebb;
      break;
    case 'd':
      *in_ECX = (int)(pcVar8 + 2);
      local_30 = &DAT_00014f65;
      puStack_2c = &DAT_00014f66;
      uVar10 = 0x14f6600014f65;
      goto LAB_00032cb1;
    case 'n':
      *in_ECX = (int)(pcVar8 + 2);
      local_38 = &DAT_00014f65;
      puStack_34 = &DAT_00014f66;
      uVar10 = 0x14f6600014f65;
      break;
    case 't':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_0002d6e0();
      goto LAB_00032940;
    case 'z':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
LAB_00032940:
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_17c = FUN_00032ec0(local_58);
      goto switchD_00031ab5_caseD_66;
    }
    goto LAB_00032d49;
  case 'c':
    switch(pcVar8[1]) {
    case 'c':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_0002d6e0();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if (local_4c == 0) goto LAB_00032d12;
      local_17c = FUN_00034300(&local_4c);
      break;
    case 'l':
      *in_ECX = (int)(pcVar8 + 2);
      local_4c = FUN_00031980();
      if (local_4c != 0) {
        iVar9 = in_ECX[3];
        iVar3 = in_ECX[2];
        while( true ) {
          pcVar2 = (char *)*in_ECX;
          if ((pcVar2 != (char *)in_ECX[1]) && (*pcVar2 == 'E')) {
            *in_ECX = (int)(pcVar2 + 1);
            iVar9 = (iVar9 - iVar3 >> 2) * 4;
            FUN_00039de0(in_ECX[2] + iVar9,in_ECX[3]);
            in_ECX[3] = iVar9 + in_ECX[2];
            local_17c = FUN_000343b0(local_58);
            goto switchD_00031ab5_caseD_66;
          }
          local_58[0] = FUN_00031980();
          if (local_58[0] == 0) break;
          FUN_0002f5d0();
        }
      }
      goto LAB_00032ea9;
    case 'm':
      *in_ECX = (int)(pcVar8 + 2);
      local_60 = &DAT_0001428a;
      puStack_5c = &DAT_0001428b;
      uVar10 = 0x1428b0001428a;
      goto LAB_00032d49;
    case 'o':
      *in_ECX = (int)(pcVar8 + 2);
      local_68 = &DAT_00014f67;
      puStack_64 = &DAT_00014f68;
      uVar10 = 0x14f6800014f67;
      goto LAB_00032cb1;
    case 'v':
      uVar5 = FUN_00034450();
      goto LAB_00032d53;
    }
    break;
  case 'd':
    switch(pcVar8[1]) {
    case 'V':
      *in_ECX = (int)(pcVar8 + 2);
      local_80 = &DAT_00013f95;
      puStack_7c = &DAT_00013f97;
      uVar10 = 0x13f9700013f95;
      goto LAB_00032d49;
    case 'a':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = CONCAT31(local_4c._1_3_,1);
LAB_00032ba3:
      local_17c = FUN_000346f0(&local_19,&local_4c);
      break;
    case 'c':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_0002d6e0();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if (local_4c == 0) {
LAB_00032d12:
        local_17c = 0;
      }
      else {
        local_17c = FUN_00034790(&local_4c);
      }
      break;
    case 'e':
      *in_ECX = (int)(pcVar8 + 2);
      local_70 = &DAT_000141c0;
      puStack_6c = &DAT_000141c1;
      uVar10 = 0x141c1000141c0;
      goto LAB_00032cb1;
    case 'l':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] != 0) {
        local_4c = local_4c & 0xffffff00;
        goto LAB_00032ba3;
      }
      goto LAB_00032ea9;
    case 'n':
      goto switchD_00031a30_caseD_31;
    case 's':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if (local_4c == 0) goto LAB_00032d12;
      puVar6 = &DAT_00014730;
LAB_00032c15:
      local_17c = FUN_00034e00(puVar6);
      break;
    case 't':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if (local_4c == 0) goto LAB_00032d12;
      local_17c = FUN_00034ec0(&local_4c);
      break;
    case 'v':
      *in_ECX = (int)(pcVar8 + 2);
      local_78 = &DAT_00013c46;
      puStack_74 = &DAT_00013c47;
      uVar10 = 0x13c4700013c46;
      goto LAB_00032d49;
    }
    break;
  case 'e':
    cVar4 = pcVar8[1];
    if (cVar4 == 'O') {
      *in_ECX = (int)(pcVar8 + 2);
      local_90 = &DAT_000146d1;
      puStack_8c = &DAT_000146d3;
      uVar10 = 0x146d3000146d1;
    }
    else if (cVar4 == 'q') {
      *in_ECX = (int)(pcVar8 + 2);
      local_98 = &DAT_000146d4;
      puStack_94 = &DAT_000146d6;
      uVar10 = 0x146d6000146d4;
    }
    else {
      if (cVar4 != 'o') break;
      *in_ECX = (int)(pcVar8 + 2);
      local_88 = &DAT_0001498b;
      puStack_84 = &DAT_0001498c;
      uVar10 = 0x1498c0001498b;
    }
    goto LAB_00032d49;
  case 'f':
    if ((pcVar8[1] == 'p') ||
       (((pcVar8[1] == 'L' && (2 < uVar7)) && (0xfffffff5 < (int)pcVar8[2] - 0x3aU)))) {
      uVar5 = FUN_000339d0();
    }
    else {
      uVar5 = FUN_00033c80();
    }
    goto LAB_00032d53;
  case 'g':
    if (pcVar8[1] == 't') {
      *in_ECX = (int)(pcVar8 + 2);
      local_a8 = &DAT_000146d7;
      puStack_a4 = &DAT_000146d8;
      uVar10 = 0x146d8000146d7;
    }
    else {
      if (pcVar8[1] != 'e') break;
      *in_ECX = (int)(pcVar8 + 2);
      local_a0 = &DAT_00013b4c;
      puStack_9c = &DAT_00013b4e;
      uVar10 = 0x13b4e00013b4c;
    }
    goto LAB_00032d49;
  case 'i':
    if (pcVar8[1] == 'l') {
      pcVar8 = pcVar8 + 2;
      *in_ECX = (int)pcVar8;
      iVar9 = in_ECX[3];
      iVar3 = in_ECX[2];
      if (pcVar8 == pcVar2) goto LAB_0003207b;
      while (*pcVar8 != 'E') {
LAB_0003207b:
        do {
          local_58[0] = FUN_00035010();
          if (local_58[0] == 0) goto switchD_00031ab5_caseD_66;
          FUN_0002f5d0();
          pcVar8 = (char *)*in_ECX;
        } while (pcVar8 == (char *)in_ECX[1]);
      }
      *in_ECX = (int)(pcVar8 + 1);
      iVar9 = (iVar9 - iVar3 >> 2) * 4;
      FUN_00039de0(in_ECX[2] + iVar9,in_ECX[3]);
      in_ECX[3] = iVar9 + in_ECX[2];
      local_17c = FUN_00035270(local_58);
    }
    else if (pcVar8[1] == 'x') {
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if (local_4c == 0) goto LAB_00032d12;
      local_17c = FUN_00034f70(&local_4c);
    }
    break;
  case 'l':
    switch(pcVar8[1]) {
    case 'S':
      *in_ECX = (int)(pcVar8 + 2);
      local_c0 = &DAT_00014a20;
      puStack_bc = &DAT_00014a23;
      uVar10 = 0x14a2300014a20;
      break;
    default:
      goto switchD_00031ab5_caseD_66;
    case 'e':
      *in_ECX = (int)(pcVar8 + 2);
      local_b0 = &DAT_00014d63;
      puStack_ac = &DAT_00014d65;
      uVar10 = 0x14d6500014d63;
      break;
    case 's':
      *in_ECX = (int)(pcVar8 + 2);
      local_b8 = &DAT_00014bde;
      puStack_b4 = &DAT_00014be0;
      uVar10 = 0x14be000014bde;
      break;
    case 't':
      *in_ECX = (int)(pcVar8 + 2);
      local_c8 = &DAT_00013af8;
      puStack_c4 = &DAT_00013af9;
      uVar10 = 0x13af900013af8;
    }
    goto LAB_00032d49;
  case 'm':
    switch(pcVar8[1]) {
    case 'I':
      *in_ECX = (int)(pcVar8 + 2);
      local_d8 = &DAT_00013f98;
      puStack_d4 = &DAT_00013f9a;
      uVar10 = 0x13f9a00013f98;
      break;
    default:
      goto switchD_00031ab5_caseD_66;
    case 'L':
      *in_ECX = (int)(pcVar8 + 2);
      local_e8 = &DAT_0001428c;
      puStack_e4 = &DAT_0001428e;
      uVar10 = 0x1428e0001428c;
      break;
    case 'i':
      *in_ECX = (int)(pcVar8 + 2);
      local_d0 = &DAT_00014003;
      puStack_cc = &DAT_00014004;
      uVar10 = 0x1400400014003;
      break;
    case 'l':
      *in_ECX = (int)(pcVar8 + 2);
      local_e0 = &DAT_000141c0;
      puStack_dc = &DAT_000141c1;
      uVar10 = 0x141c1000141c0;
      break;
    case 'm':
      pcVar1 = pcVar8 + 2;
      *in_ECX = (int)pcVar1;
      if ((pcVar1 != pcVar2) && (*pcVar1 == '_')) {
        *in_ECX = (int)(pcVar8 + 3);
        local_f0 = &DAT_000150c5;
        puStack_ec = &DAT_000150c7;
        uVar10 = 0x150c7000150c5;
LAB_00032766:
        uVar5 = FUN_00034250(uVar10);
        goto LAB_00032d53;
      }
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      puVar6 = &DAT_000150c5;
LAB_00032d8f:
      local_17c = FUN_00035310(puVar6);
      goto switchD_00031ab5_caseD_66;
    }
    goto LAB_00032d49;
  case 'n':
    switch(pcVar8[1]) {
    case 'a':
    case 'w':
      uVar5 = FUN_000353d0();
      goto LAB_00032d53;
    case 'e':
      *in_ECX = (int)(pcVar8 + 2);
      local_f8 = &DAT_00014cb5;
      puStack_f4 = &DAT_00014cb7;
      uVar10 = 0x14cb700014cb5;
      goto LAB_00032d49;
    case 'g':
      *in_ECX = (int)(pcVar8 + 2);
      local_100 = &DAT_00014003;
      puStack_fc = &DAT_00014004;
      uVar10 = 0x1400400014003;
      goto LAB_00032cb1;
    case 't':
      *in_ECX = (int)(pcVar8 + 2);
      local_108 = &DAT_00014604;
      puStack_104 = &DAT_00014605;
      uVar10 = 0x1460500014604;
LAB_00032cb1:
      uVar5 = FUN_00034250(uVar10);
      goto LAB_00032d53;
    case 'x':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_17c = FUN_00035710();
    }
    break;
  case 'o':
    switch(pcVar8[1]) {
    case 'R':
      *in_ECX = (int)(pcVar8 + 2);
      local_120 = &DAT_0001498d;
      puStack_11c = &DAT_0001498f;
      uVar10 = 0x1498f0001498d;
      break;
    default:
      goto switchD_00031ab5_caseD_66;
    case 'n':
      goto switchD_00031a30_caseD_31;
    case 'o':
      *in_ECX = (int)(pcVar8 + 2);
      local_110 = &DAT_000148b5;
      puStack_10c = &DAT_000148b7;
      uVar10 = 0x148b7000148b5;
      break;
    case 'r':
      *in_ECX = (int)(pcVar8 + 2);
      local_118 = &DAT_00014ebe;
      puStack_114 = &DAT_00014ebf;
      uVar10 = 0x14ebf00014ebe;
    }
    goto LAB_00032d49;
  case 'p':
    switch(pcVar8[1]) {
    case 'L':
      *in_ECX = (int)(pcVar8 + 2);
      local_138 = &DAT_0001476f;
      puStack_134 = &DAT_00014771;
      uVar10 = 0x147710001476f;
      break;
    default:
      goto switchD_00031ab5_caseD_66;
    case 'l':
      *in_ECX = (int)(pcVar8 + 2);
      local_130 = &DAT_00014990;
      puStack_12c = &DAT_00014991;
      uVar10 = 0x1499100014990;
      break;
    case 'm':
      *in_ECX = (int)(pcVar8 + 2);
      local_128 = &DAT_000143af;
      puStack_124 = &DAT_000143b2;
      uVar10 = 0x143b2000143af;
      break;
    case 'p':
      pcVar1 = pcVar8 + 2;
      *in_ECX = (int)pcVar1;
      if ((pcVar1 != pcVar2) && (*pcVar1 == '_')) {
        *in_ECX = (int)(pcVar8 + 3);
        local_140 = &DAT_00013afa;
        puStack_13c = &DAT_00013afc;
        uVar10 = 0x13afc00013afa;
        goto LAB_00032766;
      }
      local_58[0] = FUN_00031980();
      if (local_58[0] != 0) {
        puVar6 = &DAT_00013afa;
        goto LAB_00032d8f;
      }
      goto LAB_00032ea9;
    case 's':
      *in_ECX = (int)(pcVar8 + 2);
      local_148 = &DAT_00014990;
      puStack_144 = &DAT_00014991;
      uVar10 = 0x1499100014990;
      goto LAB_00032cb1;
    case 't':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] != 0) {
        local_4c = FUN_00031980();
        if (local_4c != 0) {
          puVar6 = &DAT_00014aee;
          goto LAB_00032c15;
        }
        goto LAB_00032d12;
      }
LAB_00032ea9:
      local_17c = 0;
      goto switchD_00031ab5_caseD_66;
    }
    goto LAB_00032d49;
  case 'q':
    if (pcVar8[1] == 'u') {
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if ((local_4c == 0) || (local_14c = FUN_00031980(), local_14c == 0)) goto LAB_00032d12;
      local_17c = FUN_000357d0(&local_4c,&local_14c);
    }
    break;
  case 'r':
    switch(pcVar8[1]) {
    case 'M':
      *in_ECX = (int)(pcVar8 + 2);
      uVar10 = 0x14d6800014d66;
      break;
    default:
      goto switchD_00031ab5_caseD_66;
    case 'S':
      *in_ECX = (int)(pcVar8 + 2);
      uVar10 = 0x1477500014772;
      break;
    case 'c':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_0002d6e0();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if (local_4c == 0) goto LAB_00032d12;
      local_17c = FUN_00035870(&local_4c);
      goto switchD_00031ab5_caseD_66;
    case 'm':
      *in_ECX = (int)(pcVar8 + 2);
      uVar10 = 0x1534700015346;
      break;
    case 's':
      *in_ECX = (int)(pcVar8 + 2);
      uVar10 = 0x13d5d00013d5b;
    }
LAB_00032d49:
    uVar5 = FUN_00034180(uVar10);
LAB_00032d53:
    if (*(int *)(in_GS_OFFSET + 0x14) == local_18) {
      return uVar5;
    }
    goto LAB_00032eba;
  case 's':
    switch(pcVar8[1]) {
    case 'P':
      pcVar8 = pcVar8 + 2;
      *in_ECX = (int)pcVar8;
      iVar9 = in_ECX[3];
      iVar3 = in_ECX[2];
      if (pcVar8 == pcVar2) goto LAB_00031e92;
      while (*pcVar8 != 'E') {
LAB_00031e92:
        do {
          local_58[0] = FUN_0002f430();
          if (local_58[0] == 0) goto switchD_00031ab5_caseD_66;
          FUN_0002f5d0();
          pcVar8 = (char *)*in_ECX;
        } while (pcVar8 == (char *)in_ECX[1]);
      }
      *in_ECX = (int)(pcVar8 + 1);
      iVar9 = (iVar9 - iVar3 >> 2) * 4;
      FUN_00039de0(in_ECX[2] + iVar9,in_ECX[3]);
      in_ECX[3] = iVar9 + in_ECX[2];
      local_58[0] = FUN_00035c80();
LAB_00032e92:
      local_17c = FUN_00035bc0();
      break;
    case 'Z':
      pcVar8 = pcVar8 + 2;
      *in_ECX = (int)pcVar8;
      if (pcVar2 != pcVar8) {
        if (*pcVar8 == 'f') {
          local_58[0] = FUN_000339d0();
          if (local_58[0] == 0) goto LAB_00032ea9;
          goto LAB_00032e92;
        }
        if (*pcVar8 == 'T') {
          local_58[0] = FUN_00030b00();
          if (local_58[0] == 0) goto LAB_00032ea9;
          local_17c = FUN_00035b30();
        }
      }
      break;
    case 'c':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_0002d6e0();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_4c = FUN_00031980();
      if (local_4c == 0) goto LAB_00032d12;
      local_17c = FUN_00035920(&local_4c);
      break;
    case 'p':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_17c = FUN_000359d0();
      break;
    case 'r':
      goto switchD_00031a30_caseD_31;
    case 't':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_0002d6e0();
      goto LAB_00032a71;
    case 'z':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
LAB_00032a71:
      if (local_58[0] == 0) goto LAB_00032ea9;
      uVar10 = CONCAT44(uVar5,local_58);
LAB_00032a90:
      local_17c = FUN_00035a60(uVar10);
    }
    break;
  case 't':
    switch(pcVar8[1]) {
    case 'e':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      goto LAB_00032263;
    case 'i':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_0002d6e0();
LAB_00032263:
      if (local_58[0] == 0) goto LAB_00032ea9;
      uVar10 = CONCAT44(uVar5,local_58);
      goto LAB_00032a90;
    case 'l':
      *in_ECX = (int)(pcVar8 + 2);
      local_4c = FUN_0002d6e0();
      if (local_4c != 0) {
        iVar9 = in_ECX[3];
        iVar3 = in_ECX[2];
        while( true ) {
          pcVar2 = (char *)*in_ECX;
          if ((pcVar2 != (char *)in_ECX[1]) && (*pcVar2 == 'E')) {
            *in_ECX = (int)(pcVar2 + 1);
            iVar9 = (iVar9 - iVar3 >> 2) * 4;
            FUN_00039de0(in_ECX[2] + iVar9,in_ECX[3]);
            in_ECX[3] = iVar9 + in_ECX[2];
            local_17c = FUN_00035d20(local_58);
            goto switchD_00031ab5_caseD_66;
          }
          local_58[0] = FUN_00035010();
          if (local_58[0] == 0) break;
          FUN_0002f5d0();
        }
      }
      goto LAB_00032ea9;
    case 'r':
      *in_ECX = (int)(pcVar8 + 2);
      uVar5 = FUN_00035dc0();
      goto LAB_00032d53;
    case 'w':
      *in_ECX = (int)(pcVar8 + 2);
      local_58[0] = FUN_00031980();
      if (local_58[0] == 0) goto LAB_00032ea9;
      local_17c = FUN_00035e70();
    }
  }
switchD_00031ab5_caseD_66:
  if (*(int *)(in_GS_OFFSET + 0x14) == local_18) {
    return local_17c;
  }
LAB_00032eba:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00032ec0 @ 00032ec0

int FUN_00032ec0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  size_t sVar4;
  int in_ECX;
  char *in_EDX;
  int iVar5;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar3 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar5 = 0;
  }
  piVar3[1] = iVar5 + 0x20;
  sVar4 = strlen(in_EDX);
  uVar2 = *param_1;
  *(undefined4 *)((int)piVar3 + iVar5 + 0xc) = 0x1010134;
  *(undefined ***)((int)piVar3 + iVar5 + 8) = &PTR_LAB_0004bc10;
  *(char **)((int)piVar3 + iVar5 + 0x10) = in_EDX;
  *(char **)((int)piVar3 + iVar5 + 0x14) = in_EDX + sVar4;
  *(undefined4 *)((int)piVar3 + iVar5 + 0x18) = uVar2;
  *(undefined **)((int)piVar3 + iVar5 + 0x1c) = &DAT_000150c3;
  *(undefined **)((int)piVar3 + iVar5 + 0x20) = &DAT_000150c4;
  return (int)piVar3 + iVar5 + 8;
}


// ==== FUN_00032f90 @ 00032f90

int FUN_00032f90(void)

{
  char *pcVar1;
  char *pcVar2;
  char cVar3;
  char *pcVar4;
  char *pcVar5;
  int *piVar6;
  undefined **ppuVar7;
  int *in_ECX;
  uint uVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  int in_GS_OFFSET;
  undefined8 uVar12;
  int local_a8;
  char *local_a0;
  char *local_98;
  char *local_94;
  int local_8c;
  char *local_88;
  char *pcStack_84;
  char *local_80;
  char *pcStack_7c;
  undefined *local_78;
  undefined *puStack_74;
  undefined *local_70;
  undefined *puStack_6c;
  undefined *local_68;
  undefined *puStack_64;
  undefined *local_60;
  undefined *puStack_5c;
  undefined *local_58;
  undefined *puStack_54;
  undefined1 *local_50;
  undefined1 *puStack_4c;
  char *local_48;
  char *pcStack_44;
  char *local_40;
  char *pcStack_3c;
  char *local_38;
  char *pcStack_34;
  char *local_30;
  char *pcStack_2c;
  undefined *local_28;
  undefined *puStack_24;
  undefined *local_20;
  undefined *puStack_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar4 = (char *)*in_ECX;
  pcVar5 = (char *)in_ECX[1];
  if (pcVar4 == pcVar5) {
LAB_000330e2:
    local_a8 = 0;
    goto switchD_00033007_caseD_54;
  }
  local_a8 = 0;
  if (*pcVar4 != 'L') goto switchD_00033007_caseD_54;
  pcVar1 = pcVar4 + 1;
  *in_ECX = (int)pcVar1;
  uVar8 = (int)pcVar5 - (int)pcVar1;
  if (pcVar5 == pcVar1) {
switchD_00033007_caseD_42:
    local_8c = FUN_0002d6e0();
    if (local_8c == 0) goto LAB_000330e2;
    pcVar4 = (char *)*in_ECX;
    local_a8 = 0;
    if ((char *)in_ECX[1] == pcVar4) goto switchD_00033007_caseD_54;
    if ((int)*pcVar4 - 0x3aU < 0xfffffff6) goto switchD_00033007_caseD_54;
    local_a8 = 0;
    iVar10 = 0;
    do {
      iVar9 = iVar10;
      pcVar5 = pcVar4 + iVar9 + 1;
      *in_ECX = (int)pcVar5;
      if (pcVar5 == (char *)in_ECX[1]) goto switchD_00033007_caseD_54;
      iVar10 = iVar9 + 1;
    } while (0xfffffff5 < (int)*pcVar5 - 0x3aU);
    local_94 = pcVar4 + iVar10;
    local_98 = pcVar4;
    if ((iVar10 == 0) || (*pcVar5 != 'E')) goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + iVar9 + 2);
    iVar10 = FUN_00036930(&local_98);
    goto LAB_000330dc;
  }
  cVar3 = *pcVar1;
  switch(cVar3) {
  case 'A':
    local_98 = (char *)FUN_0002d6e0();
    local_a8 = 0;
    if (((local_98 != (char *)0x0) && (pcVar4 = (char *)*in_ECX, pcVar4 != (char *)in_ECX[1])) &&
       (*pcVar4 == 'E')) {
      *in_ECX = (int)(pcVar4 + 1);
      local_a8 = FUN_00036160();
    }
    goto switchD_00033007_caseD_54;
  default:
    goto switchD_00033007_caseD_42;
  case 'D':
    if ((((uVar8 < 3) || (cVar3 != 'D')) || (pcVar4[2] != 'n')) || (pcVar4[3] != 'E'))
    goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + 4);
    iVar10 = FUN_000361f0();
    goto LAB_000338dc;
  case 'T':
    goto switchD_00033007_caseD_54;
  case 'U':
    if ((uVar8 < 2) || (pcVar4[2] != 'l')) goto switchD_00033007_caseD_54;
    local_a8 = 0;
    local_98 = (char *)FUN_000362a0();
    if ((local_98 == (char *)0x0) ||
       ((pcVar4 = (char *)*in_ECX, pcVar4 == (char *)in_ECX[1] || (*pcVar4 != 'E'))))
    goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + 1);
    iVar10 = FUN_000368a0();
    goto LAB_000330dc;
  case '_':
    if (((uVar8 < 2) || (cVar3 != '_')) || (pcVar4[2] != 'Z')) goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + 3);
    iVar10 = FUN_0002cc90();
    if (((iVar10 == 0) || (pcVar4 = (char *)*in_ECX, pcVar4 == (char *)in_ECX[1])) ||
       (*pcVar4 != 'E')) goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + 1);
    goto LAB_000330dc;
  case 'a':
    *in_ECX = (int)(pcVar4 + 2);
    local_30 = "signed char";
    pcStack_2c = "";
    uVar12 = 0x141cd000141c2;
    break;
  case 'b':
    if ((uVar8 < 3) || (cVar3 != 'b')) goto switchD_00033007_caseD_54;
    if (pcVar4[2] == '1') {
      if (pcVar4[3] != 'E') goto switchD_00033007_caseD_54;
      *in_ECX = (int)(pcVar4 + 4);
      local_98 = (char *)0x1;
    }
    else {
      if ((pcVar4[2] != '0') || (pcVar4[3] != 'E')) goto switchD_00033007_caseD_54;
      *in_ECX = (int)(pcVar4 + 4);
      local_98 = (char *)0x0;
    }
    iVar10 = FUN_000360d0();
    goto LAB_000330dc;
  case 'c':
    *in_ECX = (int)(pcVar4 + 2);
    local_28 = &DAT_00014611;
    puStack_24 = &DAT_00014615;
    uVar12 = 0x1461500014611;
    break;
  case 'd':
    *in_ECX = (int)(pcVar4 + 2);
    if (((((((uint)((int)pcVar5 - (int)(pcVar4 + 2)) < 0x11) ||
           (((int)pcVar4[2] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[2] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
          ((((int)pcVar4[3] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[3] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
           (((((int)pcVar4[4] - 0x3aU < 0xfffffff6 &&
              (((int)pcVar4[4] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
             (((int)pcVar4[5] - 0x3aU < 0xfffffff6 &&
              (((int)pcVar4[5] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
            (((int)pcVar4[6] - 0x3aU < 0xfffffff6 &&
             (((int)pcVar4[6] & 0xffffffdfU) - 0x47 < 0xfffffffa)))))))) ||
         (((int)pcVar4[7] - 0x3aU < 0xfffffff6 &&
          (((int)pcVar4[7] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
        ((((((int)pcVar4[8] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[8] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
           (((int)pcVar4[9] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[9] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
          ((((int)pcVar4[10] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[10] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
           (((int)pcVar4[0xb] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[0xb] & 0xffffffdfU) - 0x47 < 0xfffffffa)))))) ||
         (((((int)pcVar4[0xc] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[0xc] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
           (((int)pcVar4[0xd] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[0xd] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
          (((int)pcVar4[0xe] - 0x3aU < 0xfffffff6 &&
           (((int)pcVar4[0xe] & 0xffffffdfU) - 0x47 < 0xfffffffa)))))))) ||
       ((((int)pcVar4[0xf] - 0x3aU < 0xfffffff6 &&
         (((int)pcVar4[0xf] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
        ((((int)pcVar4[0x10] - 0x3aU < 0xfffffff6 &&
          (((int)pcVar4[0x10] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
         (((int)pcVar4[0x11] - 0x3aU < 0xfffffff6 &&
          (((int)pcVar4[0x11] & 0xffffffdfU) - 0x47 < 0xfffffffa))))))))
    goto switchD_00033007_caseD_54;
    local_a0 = pcVar4 + 0x12;
    *in_ECX = (int)local_a0;
    if ((local_a0 == pcVar5) || (*local_a0 != 'E')) goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + 0x13);
    piVar11 = (int *)in_ECX[0x466];
    iVar10 = piVar11[1];
    piVar6 = piVar11;
    if (iVar10 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) {
LAB_000339bf:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      *piVar6 = (int)piVar11;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar10 = 0;
    }
    piVar6[1] = iVar10 + 0x10;
    *(undefined4 *)((int)piVar6 + iVar10 + 0xc) = 0x1010147;
    ppuVar7 = &PTR_LAB_0004b4d8;
    goto LAB_000332fe;
  case 'e':
    pcVar1 = pcVar4 + 2;
    *in_ECX = (int)pcVar1;
    if ((uint)((int)pcVar5 - (int)pcVar1) < 0x15) goto switchD_00033007_caseD_54;
    pcVar2 = pcVar4 + 0x16;
    iVar10 = 3;
    do {
      if ((((int)pcVar4[iVar10 + -1] - 0x3aU < 0xfffffff6) &&
          (((int)pcVar4[iVar10 + -1] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
         (((int)pcVar4[iVar10] - 0x3aU < 0xfffffff6 &&
          (((int)pcVar4[iVar10] & 0xffffffdfU) - 0x47 < 0xfffffffa))))
      goto switchD_00033007_caseD_54;
      iVar10 = iVar10 + 2;
    } while (iVar10 != 0x17);
    *in_ECX = (int)pcVar2;
    if ((pcVar2 == pcVar5) || (*pcVar2 != 'E')) goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + 0x17);
    piVar11 = (int *)in_ECX[0x466];
    iVar10 = piVar11[1];
    if (iVar10 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_000339bf;
      *piVar6 = (int)piVar11;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar10 = 0;
      piVar11 = piVar6;
    }
    piVar11[1] = iVar10 + 0x10;
    *(undefined4 *)((int)piVar11 + iVar10 + 0xc) = 0x1010148;
    *(undefined ***)((int)piVar11 + iVar10 + 8) = &PTR_LAB_0004b510;
    *(char **)((int)piVar11 + iVar10 + 0x10) = pcVar1;
    *(char **)((int)piVar11 + iVar10 + 0x14) = pcVar2;
    iVar10 = (int)piVar11 + iVar10 + 8;
    goto LAB_000330dc;
  case 'f':
    *in_ECX = (int)(pcVar4 + 2);
    if ((((((uint)((int)pcVar5 - (int)(pcVar4 + 2)) < 9) ||
          (((int)pcVar4[2] - 0x3aU < 0xfffffff6 &&
           (((int)pcVar4[2] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
         (((int)pcVar4[3] - 0x3aU < 0xfffffff6 &&
          (((int)pcVar4[3] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
        ((((((int)pcVar4[4] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[4] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
           (((int)pcVar4[5] - 0x3aU < 0xfffffff6 &&
            (((int)pcVar4[5] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
          (((int)pcVar4[6] - 0x3aU < 0xfffffff6 &&
           (((int)pcVar4[6] & 0xffffffdfU) - 0x47 < 0xfffffffa)))) ||
         (((int)pcVar4[7] - 0x3aU < 0xfffffff6 &&
          (((int)pcVar4[7] & 0xffffffdfU) - 0x47 < 0xfffffffa)))))) ||
       ((((int)pcVar4[8] - 0x3aU < 0xfffffff6 &&
         (((int)pcVar4[8] & 0xffffffdfU) - 0x47 < 0xfffffffa)) ||
        (((int)pcVar4[9] - 0x3aU < 0xfffffff6 &&
         (((int)pcVar4[9] & 0xffffffdfU) - 0x47 < 0xfffffffa)))))) goto switchD_00033007_caseD_54;
    local_a0 = pcVar4 + 10;
    *in_ECX = (int)local_a0;
    if ((local_a0 == pcVar5) || (*local_a0 != 'E')) goto switchD_00033007_caseD_54;
    *in_ECX = (int)(pcVar4 + 0xb);
    piVar11 = (int *)in_ECX[0x466];
    iVar10 = piVar11[1];
    piVar6 = piVar11;
    if (iVar10 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_000339bf;
      *piVar6 = (int)piVar11;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar10 = 0;
    }
    piVar6[1] = iVar10 + 0x10;
    *(undefined4 *)((int)piVar6 + iVar10 + 0xc) = 0x1010146;
    ppuVar7 = &PTR_LAB_0004b4a0;
LAB_000332fe:
    *(undefined ***)((int)piVar6 + iVar10 + 8) = ppuVar7;
    *(char **)((int)piVar6 + iVar10 + 0x10) = pcVar4 + 2;
    *(char **)((int)piVar6 + iVar10 + 0x14) = local_a0;
    iVar10 = (int)piVar6 + iVar10 + 8;
LAB_000330dc:
    local_a8 = iVar10;
switchD_00033007_caseD_54:
    if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
    return local_a8;
  case 'h':
    *in_ECX = (int)(pcVar4 + 2);
    local_38 = "unsigned char";
    pcStack_34 = "";
    uVar12 = 0x13eee00013ee1;
    break;
  case 'i':
    *in_ECX = (int)(pcVar4 + 2);
    local_50 = &DAT_00014ffa;
    puStack_4c = &DAT_00014ffa;
    uVar12 = 0x14ffa00014ffa;
    break;
  case 'j':
    *in_ECX = (int)(pcVar4 + 2);
    local_58 = &DAT_00014616;
    puStack_54 = &DAT_00014617;
    uVar12 = 0x1461700014616;
    break;
  case 'l':
    *in_ECX = (int)(pcVar4 + 2);
    local_60 = &DAT_00014f7a;
    puStack_5c = &DAT_00014f7b;
    uVar12 = 0x14f7b00014f7a;
    break;
  case 'm':
    *in_ECX = (int)(pcVar4 + 2);
    local_68 = &DAT_00014776;
    puStack_64 = &DAT_00014778;
    uVar12 = 0x1477800014776;
    break;
  case 'n':
    *in_ECX = (int)(pcVar4 + 2);
    local_80 = "__int128";
    pcStack_7c = "";
    uVar12 = 0x148c0000148b8;
    break;
  case 'o':
    *in_ECX = (int)(pcVar4 + 2);
    local_88 = "unsigned __int128";
    pcStack_84 = "";
    uVar12 = 0x13d6f00013d5e;
    break;
  case 's':
    *in_ECX = (int)(pcVar4 + 2);
    local_40 = "short";
    pcStack_3c = "";
    uVar12 = 0x146de000146d9;
    break;
  case 't':
    *in_ECX = (int)(pcVar4 + 2);
    local_48 = "unsigned short";
    pcStack_44 = "";
    uVar12 = 0x1401300014005;
    break;
  case 'w':
    *in_ECX = (int)(pcVar4 + 2);
    local_20 = &DAT_00013c4e;
    puStack_1c = &DAT_00013c55;
    uVar12 = 0x13c5500013c4e;
    break;
  case 'x':
    *in_ECX = (int)(pcVar4 + 2);
    local_70 = &DAT_000152a9;
    puStack_6c = &DAT_000152ab;
    uVar12 = 0x152ab000152a9;
    break;
  case 'y':
    *in_ECX = (int)(pcVar4 + 2);
    local_78 = &DAT_00014df7;
    puStack_74 = &DAT_00014dfa;
    uVar12 = 0x14dfa00014df7;
  }
  iVar10 = FUN_00035f90(uVar12);
LAB_000338dc:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar10;
}


// ==== FUN_000339d0 @ 000339d0

int FUN_000339d0(void)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  int *piVar4;
  int *in_ECX;
  int iVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  int *local_20;
  char *local_18;
  
  pcVar7 = (char *)*in_ECX;
  pcVar3 = (char *)in_ECX[1];
  if (((uint)((int)pcVar3 - (int)pcVar7) < 2) || (*pcVar7 != 'f')) {
    return 0;
  }
  pcVar8 = pcVar3;
  if (pcVar7[1] == 'p') {
    local_18 = pcVar7 + 2;
    *in_ECX = (int)local_18;
    if (local_18 == pcVar3) {
      return 0;
    }
    if (*local_18 == 'r') {
      local_18 = pcVar7 + 3;
      *in_ECX = (int)local_18;
    }
    if (local_18 == pcVar3) {
      return 0;
    }
    if (*local_18 == 'V') {
      local_18 = local_18 + 1;
      *in_ECX = (int)local_18;
    }
    if (local_18 == pcVar3) {
      return 0;
    }
    if (*local_18 == 'K') {
      local_18 = local_18 + 1;
      *in_ECX = (int)local_18;
    }
    if (pcVar3 == local_18) {
      return 0;
    }
    pcVar7 = local_18;
    if ((int)*local_18 - 0x3aU < 0xfffffff6) {
      local_18 = (char *)0x0;
      pcVar8 = (char *)0x0;
    }
    else {
      do {
        pcVar7 = pcVar7 + 1;
        *in_ECX = (int)pcVar7;
        if (pcVar7 == pcVar3) goto LAB_00033b76;
      } while (0xfffffff5 < (int)*pcVar7 - 0x3aU);
      pcVar8 = pcVar7;
    }
LAB_00033b76:
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 != '_') {
      return 0;
    }
    *in_ECX = (int)(pcVar7 + 1);
    piVar4 = (int *)in_ECX[0x466];
    iVar5 = piVar4[1];
    if (0xfffff007 < iVar5 - 0xfe8U) goto LAB_00033bdb;
    local_20 = piVar4;
  }
  else {
    if (*pcVar7 != 'f') {
      return 0;
    }
    if (pcVar7[1] != 'L') {
      return 0;
    }
    pcVar1 = pcVar7 + 2;
    *in_ECX = (int)pcVar1;
    if (pcVar3 == pcVar1) {
      return 0;
    }
    if ((int)*pcVar1 - 0x3aU < 0xfffffff6) {
      return 0;
    }
    pcVar7 = pcVar7 + 5;
    do {
      pcVar6 = pcVar7;
      pcVar2 = pcVar6 + -2;
      *in_ECX = (int)pcVar2;
      if (pcVar2 == pcVar3) {
        pcVar7 = pcVar3;
        goto LAB_00033aec;
      }
      pcVar7 = pcVar6 + 1;
    } while (0xfffffff5 < (int)pcVar6[-2] - 0x3aU);
    pcVar7 = pcVar6 + -2;
LAB_00033aec:
    if (pcVar1 == pcVar7) {
      return 0;
    }
    if (pcVar2 == pcVar3) {
      return 0;
    }
    if (pcVar6[-2] != 'p') {
      return 0;
    }
    local_18 = pcVar6 + -1;
    *in_ECX = (int)local_18;
    if (local_18 == pcVar3) {
      return 0;
    }
    if (*local_18 == 'r') {
      *in_ECX = (int)pcVar6;
      local_18 = pcVar6;
    }
    if (local_18 == pcVar3) {
      return 0;
    }
    if (*local_18 == 'V') {
      local_18 = local_18 + 1;
      *in_ECX = (int)local_18;
    }
    if (local_18 == pcVar3) {
      return 0;
    }
    if (*local_18 == 'K') {
      local_18 = local_18 + 1;
      *in_ECX = (int)local_18;
    }
    if (pcVar3 == local_18) {
      return 0;
    }
    pcVar7 = local_18;
    if ((int)*local_18 - 0x3aU < 0xfffffff6) {
      local_18 = (char *)0x0;
      pcVar8 = (char *)0x0;
    }
    else {
      do {
        pcVar7 = pcVar7 + 1;
        *in_ECX = (int)pcVar7;
        if (pcVar7 == pcVar3) goto LAB_00033c36;
      } while (0xfffffff5 < (int)*pcVar7 - 0x3aU);
      pcVar8 = pcVar7;
    }
LAB_00033c36:
    if (pcVar7 == pcVar3) {
      return 0;
    }
    if (*pcVar7 != '_') {
      return 0;
    }
    *in_ECX = (int)(pcVar7 + 1);
    piVar4 = (int *)in_ECX[0x466];
    iVar5 = piVar4[1];
    local_20 = piVar4;
    if (0xfffff007 < iVar5 - 0xfe8U) goto LAB_00033bdb;
  }
  piVar4 = malloc(0x1000);
  if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_0002c220();
  }
  *piVar4 = (int)local_20;
  piVar4[1] = 0;
  in_ECX[0x466] = (int)piVar4;
  iVar5 = 0;
LAB_00033bdb:
  piVar4[1] = iVar5 + 0x10;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x101013b;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b778;
  *(char **)((int)piVar4 + iVar5 + 0x10) = local_18;
  *(char **)((int)piVar4 + iVar5 + 0x14) = pcVar8;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00033c80 @ 00033c80

int FUN_00033c80(void)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *in_ECX;
  char cVar7;
  char cVar9;
  uint uVar8;
  int iVar10;
  undefined *local_28;
  undefined *local_24;
  int local_20;
  char local_1c;
  
  pcVar2 = (char *)*in_ECX;
  pcVar3 = (char *)in_ECX[1];
  iVar10 = 0;
  if (pcVar2 == pcVar3) {
    return 0;
  }
  if (*pcVar2 != 'f') {
    return 0;
  }
  pcVar1 = pcVar2 + 1;
  *in_ECX = (int)pcVar1;
  if (pcVar3 == pcVar1) {
    return 0;
  }
  uVar8 = CONCAT11(*pcVar1,*pcVar1) & 0xffffffdf;
  cVar7 = (char)uVar8;
  cVar9 = (char)(uVar8 >> 8);
  if (cVar7 == 'L') {
    local_1c = '\x01';
  }
  else {
    if (cVar7 != 'R') {
      return 0;
    }
    local_1c = '\0';
  }
  pcVar1 = pcVar2 + 2;
  *in_ECX = (int)pcVar1;
  if ((uint)((int)pcVar3 - (int)pcVar1) < 2) {
    return 0;
  }
  switch(*pcVar1) {
  case 'a':
    local_28 = &DAT_00014ebd;
    local_24 = &DAT_00014ebb;
    switch(pcVar2[3]) {
    case 'N':
      local_28 = &DAT_000143ae;
      local_24 = &DAT_000143ac;
      break;
    default:
      goto switchD_00033d16_caseD_62;
    case 'S':
      local_28 = &DAT_000148b4;
      local_24 = &DAT_000148b3;
      break;
    case 'a':
      break;
    case 'n':
      local_28 = &DAT_00014f66;
      local_24 = &DAT_00014f65;
    }
    break;
  default:
    goto switchD_00033d16_caseD_62;
  case 'c':
    if (pcVar2[3] != 'm') {
      return 0;
    }
    local_28 = &DAT_0001428b;
    local_24 = &DAT_0001428a;
    break;
  case 'd':
    cVar7 = pcVar2[3];
    if (cVar7 == 'V') {
      local_28 = &DAT_00013f97;
      local_24 = &DAT_00013f95;
    }
    else if (cVar7 == 's') {
      local_28 = &DAT_00014732;
      local_24 = &DAT_00014730;
    }
    else {
      if (cVar7 != 'v') {
        return 0;
      }
      local_28 = &DAT_00013c47;
      local_24 = &DAT_00013c46;
    }
    break;
  case 'e':
    cVar7 = pcVar2[3];
    if (cVar7 == 'O') {
      local_28 = &DAT_000146d3;
      local_24 = &DAT_000146d1;
    }
    else if (cVar7 == 'o') {
      local_28 = &DAT_0001498c;
      local_24 = &DAT_0001498b;
    }
    else {
      if (cVar7 != 'q') {
        return 0;
      }
      local_28 = &DAT_000146d6;
      local_24 = &DAT_000146d4;
    }
    break;
  case 'g':
    if (pcVar2[3] == 'e') {
      local_28 = &DAT_00013b4e;
      local_24 = &DAT_00013b4c;
    }
    else {
      if (pcVar2[3] != 't') {
        return 0;
      }
      local_28 = &DAT_000146d8;
      local_24 = &DAT_000146d7;
    }
    break;
  case 'l':
    local_28 = &DAT_00014d65;
    local_24 = &DAT_00014d63;
    switch(pcVar2[3]) {
    case 'S':
      local_28 = &DAT_00014a23;
      local_24 = &DAT_00014a20;
      break;
    default:
      goto switchD_00033d16_caseD_62;
    case 'e':
      break;
    case 's':
      local_28 = &DAT_00014be0;
      local_24 = &DAT_00014bde;
      break;
    case 't':
      local_28 = &DAT_00013af9;
      local_24 = &DAT_00013af8;
    }
    break;
  case 'm':
    local_28 = &DAT_00014004;
    local_24 = &DAT_00014003;
    switch(pcVar2[3]) {
    case 'I':
      local_28 = &DAT_00013f9a;
      local_24 = &DAT_00013f98;
      break;
    default:
      goto switchD_00033d16_caseD_62;
    case 'L':
      local_28 = &DAT_0001428e;
      local_24 = &DAT_0001428c;
      break;
    case 'i':
      break;
    case 'l':
      local_28 = &DAT_000141c1;
      local_24 = &DAT_000141c0;
    }
    break;
  case 'n':
    if (pcVar2[3] != 'e') {
      return 0;
    }
    local_28 = &DAT_00014cb7;
    local_24 = &DAT_00014cb5;
    break;
  case 'o':
    cVar7 = pcVar2[3];
    if (cVar7 == 'R') {
      local_28 = &DAT_0001498f;
      local_24 = &DAT_0001498d;
    }
    else if (cVar7 == 'o') {
      local_28 = &DAT_000148b7;
      local_24 = &DAT_000148b5;
    }
    else {
      if (cVar7 != 'r') {
        return 0;
      }
      local_28 = &DAT_00014ebf;
      local_24 = &DAT_00014ebe;
    }
    break;
  case 'p':
    if (pcVar2[3] == 'L') {
      local_28 = &DAT_00014771;
      local_24 = &DAT_0001476f;
    }
    else {
      if (pcVar2[3] != 'l') {
        return 0;
      }
      local_28 = &DAT_00014991;
      local_24 = &DAT_00014990;
    }
    break;
  case 'r':
    local_28 = &DAT_00015347;
    local_24 = &DAT_00015346;
    switch(pcVar2[3]) {
    case 'M':
      local_28 = &DAT_00014d68;
      local_24 = &DAT_00014d66;
      break;
    default:
      goto switchD_00033d16_caseD_62;
    case 'S':
      local_28 = &DAT_00014775;
      local_24 = &DAT_00014772;
      break;
    case 'm':
      break;
    case 's':
      local_28 = &DAT_00013d5d;
      local_24 = &DAT_00013d5b;
    }
  }
  *in_ECX = (int)(pcVar2 + 4);
  local_20 = FUN_00031980();
  if (local_20 != 0) {
    if ((cVar9 == 'R') || (cVar9 == 'L')) {
      iVar10 = FUN_00031980();
      if (iVar10 == 0) {
        return 0;
      }
      iVar5 = iVar10;
      if (local_1c != '\0') {
        iVar5 = local_20;
        local_20 = iVar10;
      }
    }
    else {
      iVar5 = 0;
    }
    piVar4 = (int *)in_ECX[0x466];
    iVar10 = piVar4[1];
    piVar6 = piVar4;
    if (iVar10 - 0xfd8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      *piVar6 = (int)piVar4;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar10 = 0;
    }
    piVar6[1] = iVar10 + 0x20;
    *(undefined4 *)((int)piVar6 + iVar10 + 0xc) = 0x101013e;
    *(undefined ***)((int)piVar6 + iVar10 + 8) = &PTR_LAB_0004b7b0;
    *(int *)((int)piVar6 + iVar10 + 0x10) = local_20;
    *(int *)((int)piVar6 + iVar10 + 0x14) = iVar5;
    *(undefined **)((int)piVar6 + iVar10 + 0x18) = local_24;
    *(undefined **)((int)piVar6 + iVar10 + 0x1c) = local_28;
    *(char *)((int)piVar6 + iVar10 + 0x20) = local_1c;
    iVar10 = (int)piVar6 + iVar10 + 8;
  }
switchD_00033d16_caseD_62:
  return iVar10;
}


// ==== FUN_00034180 @ 00034180

int FUN_00034180(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  
  iVar2 = FUN_00031980();
  iVar5 = 0;
  if (iVar2 != 0) {
    iVar3 = FUN_00031980();
    if (iVar3 != 0) {
      piVar1 = *(int **)(in_ECX + 0x1198);
      iVar5 = piVar1[1];
      piVar4 = piVar1;
      if (iVar5 - 0xfd8U < 0xfffff008) {
        piVar4 = malloc(0x1000);
        if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar4 = (int)piVar1;
        piVar4[1] = 0;
        *(int **)(in_ECX + 0x1198) = piVar4;
        iVar5 = 0;
      }
      piVar4[1] = iVar5 + 0x20;
      *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x101012f;
      *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b820;
      *(int *)((int)piVar4 + iVar5 + 0x10) = iVar2;
      *(undefined4 *)((int)piVar4 + iVar5 + 0x18) = param_2;
      *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = param_1;
      *(int *)((int)piVar4 + iVar5 + 0x1c) = iVar3;
      iVar5 = (int)piVar4 + iVar5 + 8;
    }
  }
  return iVar5;
}


// ==== FUN_00034250 @ 00034250

int FUN_00034250(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  
  iVar2 = FUN_00031980();
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    piVar1 = *(int **)(in_ECX + 0x1198);
    iVar4 = piVar1[1];
    piVar3 = piVar1;
    if (iVar4 - 0xfd8U < 0xfffff008) {
      piVar3 = malloc(0x1000);
      if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      *piVar3 = (int)piVar1;
      piVar3[1] = 0;
      *(int **)(in_ECX + 0x1198) = piVar3;
      iVar4 = 0;
    }
    piVar3[1] = iVar4 + 0x20;
    *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x101013a;
    *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b858;
    *(undefined4 *)((int)piVar3 + iVar4 + 0x14) = param_2;
    *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = param_1;
    *(int *)((int)piVar3 + iVar4 + 0x18) = iVar2;
    iVar2 = (int)piVar3 + iVar4 + 8;
  }
  return iVar2;
}


// ==== FUN_00034300 @ 00034300

int FUN_00034300(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010135;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b890;
  *(char **)((int)piVar4 + iVar5 + 0x10) = "const_cast";
  *(char **)((int)piVar4 + iVar5 + 0x14) = "";
  *(undefined4 *)((int)piVar4 + iVar5 + 0x18) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x1c) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_000343b0 @ 000343b0

int FUN_000343b0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int in_ECX;
  int iVar6;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar1[1];
  piVar5 = piVar1;
  if (iVar6 - 0xfd8U < 0xfffff008) {
    piVar5 = malloc(0x1000);
    if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar5 = (int)piVar1;
    piVar5[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar5;
    iVar6 = 0;
  }
  piVar5[1] = iVar6 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  uVar4 = param_1[1];
  *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010137;
  *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_LAB_0004b8c8;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x18) = uVar4;
  return (int)piVar5 + iVar6 + 8;
}


// ==== FUN_00034450 @ 00034450

int FUN_00034450(void)

{
  int iVar1;
  undefined1 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  char *pcVar6;
  int *piVar7;
  int *piVar8;
  undefined4 *in_ECX;
  int iVar9;
  int iVar10;
  int in_GS_OFFSET;
  int local_20;
  undefined4 local_1c;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar6 = (char *)*in_ECX;
  iVar10 = 0;
  if (((1 < (uint)(in_ECX[1] - (int)pcVar6)) && (*pcVar6 == 'c')) && (pcVar6[1] == 'v')) {
    *in_ECX = pcVar6 + 2;
    uVar2 = *(undefined1 *)(in_ECX + 0x61);
    *(undefined1 *)(in_ECX + 0x61) = 0;
                    /* try { // try from 000344af to 000344b5 has its CatchHandler @ 000346d8 */
    iVar5 = FUN_0002d6e0();
    *(undefined1 *)(in_ECX + 0x61) = uVar2;
    if (iVar5 != 0) {
      pcVar6 = (char *)*in_ECX;
      if ((pcVar6 == (char *)in_ECX[1]) || (*pcVar6 != '_')) {
        iVar10 = FUN_00031980();
        if (iVar10 == 0) {
          iVar10 = 0;
          goto LAB_000346b8;
        }
        piVar4 = (int *)in_ECX[0x466];
        iVar9 = piVar4[1];
        piVar7 = piVar4;
        if (iVar9 - 0xfe8U < 0xfffff008) {
          piVar7 = malloc(0x1000);
          if (piVar7 == (int *)0x0) goto LAB_000346ce;
          *piVar7 = (int)piVar4;
          piVar7[1] = 0;
          in_ECX[0x466] = piVar7;
          iVar9 = 0;
        }
        piVar7[1] = iVar9 + 0x10;
        *(int *)((int)piVar7 + iVar9 + 8) = iVar10;
        piVar4 = (int *)in_ECX[0x466];
        iVar10 = piVar4[1];
        piVar8 = piVar4;
        if (iVar10 - 0xfd8U < 0xfffff008) {
          piVar8 = malloc(0x1000);
          if (piVar8 == (int *)0x0) goto LAB_000346ce;
          *piVar8 = (int)piVar4;
          piVar8[1] = 0;
          in_ECX[0x466] = piVar8;
          iVar10 = 0;
        }
        piVar8[1] = iVar10 + 0x20;
        *(undefined4 *)((int)piVar8 + iVar10 + 0xc) = 0x101013c;
        *(undefined ***)((int)piVar8 + iVar10 + 8) = &PTR_LAB_0004b900;
        *(int *)((int)piVar8 + iVar10 + 0x10) = iVar5;
        *(int *)((int)piVar8 + iVar10 + 0x14) = (int)piVar7 + iVar9 + 8;
        *(undefined4 *)((int)piVar8 + iVar10 + 0x18) = 1;
      }
      else {
        pcVar6 = pcVar6 + 1;
        *in_ECX = pcVar6;
        iVar9 = in_ECX[3];
        iVar3 = in_ECX[2];
        if (pcVar6 == (char *)in_ECX[1]) goto LAB_00034509;
        while (*pcVar6 != 'E') {
LAB_00034509:
          do {
            local_20 = FUN_00031980();
            if (local_20 == 0) goto LAB_000346b8;
            FUN_0002f5d0();
            pcVar6 = (char *)*in_ECX;
          } while (pcVar6 == (char *)in_ECX[1]);
        }
        *in_ECX = pcVar6 + 1;
        iVar10 = (iVar9 - iVar3 >> 2) * 4;
        FUN_00039de0(in_ECX[2] + iVar10,in_ECX[3]);
        in_ECX[3] = iVar10 + in_ECX[2];
        piVar4 = (int *)in_ECX[0x466];
        iVar10 = piVar4[1];
        piVar8 = piVar4;
        if (iVar10 - 0xfd8U < 0xfffff008) {
          piVar8 = malloc(0x1000);
          if (piVar8 == (int *)0x0) {
LAB_000346ce:
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar8 = (int)piVar4;
          piVar8[1] = 0;
          in_ECX[0x466] = piVar8;
          iVar10 = 0;
        }
        piVar8[1] = iVar10 + 0x20;
        *(undefined4 *)((int)piVar8 + iVar10 + 0xc) = 0x101013c;
        *(undefined ***)((int)piVar8 + iVar10 + 8) = &PTR_LAB_0004b900;
        *(int *)((int)piVar8 + iVar10 + 0x10) = iVar5;
        *(undefined4 *)((int)piVar8 + iVar10 + 0x18) = local_1c;
        *(int *)((int)piVar8 + iVar10 + 0x14) = local_20;
      }
      iVar10 = (int)piVar8 + iVar10 + 8;
    }
  }
LAB_000346b8:
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar10;
}


// ==== FUN_000346f0 @ 000346f0

int FUN_000346f0(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  undefined1 uVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  int in_ECX;
  int iVar6;
  undefined4 *in_EDX;
  
  piVar3 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar3[1];
  piVar5 = piVar3;
  if (iVar6 - 0xfe8U < 0xfffff008) {
    piVar5 = malloc(0x1000);
    if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar5 = (int)piVar3;
    piVar5[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar5;
    iVar6 = 0;
  }
  piVar5[1] = iVar6 + 0x10;
  uVar1 = *param_1;
  uVar2 = *param_2;
  uVar4 = *in_EDX;
  *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010139;
  *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_LAB_0004b938;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x10) = uVar4;
  *(undefined1 *)((int)piVar5 + iVar6 + 0x14) = uVar1;
  *(undefined1 *)((int)piVar5 + iVar6 + 0x15) = uVar2;
  return (int)piVar5 + iVar6 + 8;
}


// ==== FUN_00034790 @ 00034790

int FUN_00034790(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010135;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b890;
  *(char **)((int)piVar4 + iVar5 + 0x10) = "dynamic_cast";
  *(char **)((int)piVar4 + iVar5 + 0x14) = "";
  *(undefined4 *)((int)piVar4 + iVar5 + 0x18) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x1c) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00034840 @ 00034840

int FUN_00034840(void)

{
  int *piVar1;
  bool bVar2;
  char *pcVar3;
  char *pcVar4;
  int iVar5;
  int *piVar6;
  undefined4 *in_ECX;
  int iVar7;
  char cVar8;
  char *pcVar9;
  int in_GS_OFFSET;
  bool bVar10;
  int local_20;
  char *local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar4 = (char *)*in_ECX;
  pcVar9 = (char *)in_ECX[1];
  if ((uint)((int)pcVar9 - (int)pcVar4) < 3) {
    if ((int)pcVar9 - (int)pcVar4 != 2) {
LAB_00034a22:
      iVar5 = FUN_0003a300();
      if (*(int *)(in_GS_OFFSET + 0x14) == local_18) {
        return iVar5;
      }
      goto LAB_00034df6;
    }
    cVar8 = *pcVar4;
LAB_0003496c:
    bVar10 = cVar8 == 'g';
    if (bVar10) {
      if (pcVar4[1] != 's') goto LAB_00034a22;
      pcVar4 = pcVar4 + 2;
      *in_ECX = pcVar4;
      bVar2 = true;
      if (1 < (uint)((int)pcVar9 - (int)pcVar4)) {
        cVar8 = *pcVar4;
        goto LAB_00034998;
      }
    }
    else {
LAB_00034998:
      bVar2 = bVar10;
      if (cVar8 == 's') {
LAB_000349a5:
        cVar8 = pcVar4[1];
        goto joined_r0x00034ae6;
      }
    }
LAB_00034af2:
    iVar7 = FUN_0003a300();
    if ((bVar2) && (iVar7 != 0)) {
      piVar1 = (int *)in_ECX[0x466];
      iVar5 = piVar1[1];
      piVar6 = piVar1;
      if (iVar5 - 0xfe8U < 0xfffff008) {
        piVar6 = malloc(0x1000);
        if (piVar6 == (int *)0x0) {
LAB_00034df1:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar6 = (int)piVar1;
        piVar6[1] = 0;
        in_ECX[0x466] = piVar6;
        iVar5 = 0;
      }
      piVar6[1] = iVar5 + 0x10;
      *(undefined4 *)((int)piVar6 + iVar5 + 0xc) = 0x1010126;
      *(undefined ***)((int)piVar6 + iVar5 + 8) = &PTR_LAB_0004ba50;
      *(int *)((int)piVar6 + iVar5 + 0x10) = iVar7;
      iVar7 = (int)piVar6 + iVar5 + 8;
    }
  }
  else {
    cVar8 = *pcVar4;
    if (cVar8 != 's') goto LAB_0003496c;
    if (pcVar4[1] == 'r') {
      bVar2 = false;
      if (pcVar4[2] != 'N') goto LAB_000349a5;
      *in_ECX = pcVar4 + 3;
      pcVar4 = (char *)FUN_0003a180();
      if (pcVar4 == (char *)0x0) goto LAB_00034d4e;
      pcVar3 = pcVar4;
      if (((char *)in_ECX[1] != (char *)*in_ECX) && (*(char *)*in_ECX == 'I')) {
        iVar5 = FUN_00030570();
        iVar7 = 0;
        if (iVar5 == 0) goto LAB_00034d50;
        piVar1 = (int *)in_ECX[0x466];
        iVar7 = piVar1[1];
        piVar6 = piVar1;
        if (iVar7 - 0xfe8U < 0xfffff008) {
          piVar6 = malloc(0x1000);
          if (piVar6 == (int *)0x0) goto LAB_00034df1;
          *piVar6 = (int)piVar1;
          piVar6[1] = 0;
          in_ECX[0x466] = piVar6;
          iVar7 = 0;
        }
        piVar6[1] = iVar7 + 0x10;
        *(undefined4 *)((int)piVar6 + iVar7 + 0xc) = 0x1010125;
        *(undefined ***)((int)piVar6 + iVar7 + 8) = &PTR_LAB_0004bf20;
        *(char **)((int)piVar6 + iVar7 + 0x10) = pcVar4;
        *(int *)((int)piVar6 + iVar7 + 0x14) = iVar5;
        pcVar3 = (char *)((int)piVar6 + iVar7 + 8);
        pcVar9 = pcVar4;
      }
      while( true ) {
        pcVar4 = (char *)*in_ECX;
        if ((pcVar4 != (char *)in_ECX[1]) && (*pcVar4 == 'E')) {
          *in_ECX = pcVar4 + 1;
          local_1c = pcVar9;
          iVar5 = FUN_0003a300();
          iVar7 = 0;
          if (iVar5 == 0) goto LAB_00034d50;
          piVar1 = (int *)in_ECX[0x466];
          iVar7 = piVar1[1];
          piVar6 = piVar1;
          if (iVar7 - 0xfe8U < 0xfffff008) {
            piVar6 = malloc(0x1000);
            if (piVar6 == (int *)0x0) goto LAB_00034df1;
            *piVar6 = (int)piVar1;
            piVar6[1] = 0;
            in_ECX[0x466] = piVar6;
            iVar7 = 0;
          }
          piVar6[1] = iVar7 + 0x10;
          *(undefined4 *)((int)piVar6 + iVar7 + 0xc) = 0x1010116;
          *(undefined ***)((int)piVar6 + iVar7 + 8) = &PTR_LAB_0004b970;
          *(char **)((int)piVar6 + iVar7 + 0x10) = pcVar3;
          *(int *)((int)piVar6 + iVar7 + 0x14) = iVar5;
          iVar7 = (int)piVar6 + iVar7 + 8;
          goto LAB_00034d50;
        }
        iVar5 = FUN_0003a230();
        if (iVar5 == 0) break;
        piVar1 = (int *)in_ECX[0x466];
        iVar7 = piVar1[1];
        piVar6 = piVar1;
        if (iVar7 - 0xfe8U < 0xfffff008) {
          piVar6 = malloc(0x1000);
          if (piVar6 == (int *)0x0) goto LAB_00034df1;
          *piVar6 = (int)piVar1;
          piVar6[1] = 0;
          in_ECX[0x466] = piVar6;
          iVar7 = 0;
        }
        piVar6[1] = iVar7 + 0x10;
        *(undefined4 *)((int)piVar6 + iVar7 + 0xc) = 0x1010116;
        *(undefined ***)((int)piVar6 + iVar7 + 8) = &PTR_LAB_0004b970;
        *(char **)((int)piVar6 + iVar7 + 0x10) = pcVar3;
        *(int *)((int)piVar6 + iVar7 + 0x14) = iVar5;
        pcVar3 = (char *)((int)piVar6 + iVar7 + 8);
        pcVar9 = pcVar3;
      }
      local_1c = pcVar9;
    }
    else {
      bVar2 = false;
      cVar8 = pcVar4[1];
joined_r0x00034ae6:
      if (cVar8 != 'r') goto LAB_00034af2;
      pcVar4 = pcVar4 + 2;
      *in_ECX = pcVar4;
      if ((pcVar9 == pcVar4) || ((int)*pcVar4 - 0x3aU < 0xfffffff6)) {
        local_1c = (char *)FUN_0003a180();
        if (local_1c != (char *)0x0) {
          if (((char *)in_ECX[1] != (char *)*in_ECX) && (*(char *)*in_ECX == 'I')) {
            local_20 = FUN_00030570();
            if (local_20 == 0) goto LAB_00034d4e;
            local_1c = (char *)FUN_00030a60(&local_20);
          }
LAB_00034ccd:
          pcVar4 = local_1c;
          iVar5 = FUN_0003a300();
          if (iVar5 != 0) {
            piVar1 = (int *)in_ECX[0x466];
            iVar7 = piVar1[1];
            piVar6 = piVar1;
            if (iVar7 - 0xfe8U < 0xfffff008) {
              piVar6 = malloc(0x1000);
              if (piVar6 == (int *)0x0) goto LAB_00034df1;
              *piVar6 = (int)piVar1;
              piVar6[1] = 0;
              in_ECX[0x466] = piVar6;
              iVar7 = 0;
            }
            piVar6[1] = iVar7 + 0x10;
            *(undefined4 *)((int)piVar6 + iVar7 + 0xc) = 0x1010116;
            *(undefined ***)((int)piVar6 + iVar7 + 8) = &PTR_LAB_0004b970;
            *(char **)((int)piVar6 + iVar7 + 0x10) = pcVar4;
            *(int *)((int)piVar6 + iVar7 + 0x14) = iVar5;
            iVar7 = (int)piVar6 + iVar7 + 8;
            goto LAB_00034d50;
          }
        }
      }
      else {
        pcVar4 = (char *)FUN_0003a230();
        if (pcVar4 != (char *)0x0) {
          pcVar9 = (char *)0x0;
          do {
            if (pcVar9 == (char *)0x0) {
              if (bVar2) {
                piVar1 = (int *)in_ECX[0x466];
                iVar5 = piVar1[1];
                piVar6 = piVar1;
                if (iVar5 - 0xfe8U < 0xfffff008) {
                  piVar6 = malloc(0x1000);
                  if (piVar6 == (int *)0x0) goto LAB_00034df1;
                  *piVar6 = (int)piVar1;
                  piVar6[1] = 0;
                  in_ECX[0x466] = piVar6;
                  iVar5 = 0;
                }
                piVar6[1] = iVar5 + 0x10;
                *(undefined4 *)((int)piVar6 + iVar5 + 0xc) = 0x1010126;
                *(undefined ***)((int)piVar6 + iVar5 + 8) = &PTR_LAB_0004ba50;
                *(char **)((int)piVar6 + iVar5 + 0x10) = pcVar4;
                local_1c = (char *)((int)piVar6 + iVar5 + 8);
              }
              else {
                local_1c = pcVar4;
              }
            }
            else {
              piVar1 = (int *)in_ECX[0x466];
              iVar5 = piVar1[1];
              piVar6 = piVar1;
              if (iVar5 - 0xfe8U < 0xfffff008) {
                piVar6 = malloc(0x1000);
                if (piVar6 == (int *)0x0) goto LAB_00034df1;
                *piVar6 = (int)piVar1;
                piVar6[1] = 0;
                in_ECX[0x466] = piVar6;
                iVar5 = 0;
              }
              piVar6[1] = iVar5 + 0x10;
              *(undefined4 *)((int)piVar6 + iVar5 + 0xc) = 0x1010116;
              *(undefined ***)((int)piVar6 + iVar5 + 8) = &PTR_LAB_0004b970;
              *(char **)((int)piVar6 + iVar5 + 0x10) = pcVar9;
              *(char **)((int)piVar6 + iVar5 + 0x14) = pcVar4;
              local_1c = (char *)((int)piVar6 + iVar5 + 8);
            }
            pcVar9 = local_1c;
            pcVar4 = (char *)*in_ECX;
            if ((pcVar4 != (char *)in_ECX[1]) && (*pcVar4 == 'E')) {
              *in_ECX = pcVar4 + 1;
              goto LAB_00034ccd;
            }
            pcVar4 = (char *)FUN_0003a230();
          } while (pcVar4 != (char *)0x0);
        }
      }
    }
LAB_00034d4e:
    iVar7 = 0;
  }
LAB_00034d50:
  if (*(int *)(in_GS_OFFSET + 0x14) == local_18) {
    return iVar7;
  }
LAB_00034df6:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_00034e00 @ 00034e00

int FUN_00034e00(char *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  size_t sVar5;
  int in_ECX;
  undefined4 *in_EDX;
  int iVar6;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar1[1];
  piVar4 = piVar1;
  if (iVar6 - 0xfd8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar6 = 0;
  }
  piVar4[1] = iVar6 + 0x20;
  uVar2 = *in_EDX;
  sVar5 = strlen(param_1);
  uVar3 = *param_2;
  *(undefined4 *)((int)piVar4 + iVar6 + 0xc) = 0x1010133;
  *(undefined ***)((int)piVar4 + iVar6 + 8) = &PTR_LAB_0004ba88;
  *(undefined4 *)((int)piVar4 + iVar6 + 0x10) = uVar2;
  *(char **)((int)piVar4 + iVar6 + 0x14) = param_1;
  *(char **)((int)piVar4 + iVar6 + 0x18) = param_1 + sVar5;
  *(undefined4 *)((int)piVar4 + iVar6 + 0x1c) = uVar3;
  return (int)piVar4 + iVar6 + 8;
}


// ==== FUN_00034ec0 @ 00034ec0

int FUN_00034ec0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010133;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004ba88;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  *(undefined **)((int)piVar4 + iVar5 + 0x14) = &DAT_00013c07;
  *(undefined **)((int)piVar4 + iVar5 + 0x18) = &DAT_00013c08;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x1c) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00034f70 @ 00034f70

int FUN_00034f70(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010130;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004bac0;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00035010 @ 00035010

int FUN_00035010(void)

{
  char cVar1;
  char *pcVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 *in_ECX;
  int iVar8;
  
  pcVar2 = (char *)*in_ECX;
  if ((((char *)in_ECX[1] == pcVar2) || (*pcVar2 != 'd')) || ((int)in_ECX[1] - (int)pcVar2 == 1)) {
LAB_00035104:
    iVar8 = FUN_00031980();
  }
  else {
    cVar1 = pcVar2[1];
    if (cVar1 == 'X') {
      *in_ECX = pcVar2 + 2;
      iVar4 = FUN_00031980();
      iVar8 = 0;
      if (((iVar4 == 0) || (iVar5 = FUN_00031980(), iVar5 == 0)) ||
         (iVar7 = FUN_00035010(), iVar7 == 0)) goto LAB_0003525a;
      piVar3 = (int *)in_ECX[0x466];
      iVar8 = piVar3[1];
      piVar6 = piVar3;
      if (iVar8 - 0xfd8U < 0xfffff008) {
        piVar6 = malloc(0x1000);
        if (piVar6 == (int *)0x0) {
LAB_00035262:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar6 = (int)piVar3;
        piVar6[1] = 0;
        in_ECX[0x466] = piVar6;
        iVar8 = 0;
      }
      piVar6[1] = iVar8 + 0x20;
      *(undefined4 *)((int)piVar6 + iVar8 + 0xc) = 0x101014a;
      *(undefined ***)((int)piVar6 + iVar8 + 8) = &PTR_LAB_0004bb30;
      *(int *)((int)piVar6 + iVar8 + 0x10) = iVar4;
      *(int *)((int)piVar6 + iVar8 + 0x14) = iVar5;
      *(int *)((int)piVar6 + iVar8 + 0x18) = iVar7;
    }
    else if (cVar1 == 'x') {
      *in_ECX = pcVar2 + 2;
      iVar4 = FUN_00031980();
      iVar8 = 0;
      if ((iVar4 == 0) || (iVar5 = FUN_00035010(), iVar5 == 0)) goto LAB_0003525a;
      piVar3 = (int *)in_ECX[0x466];
      iVar8 = piVar3[1];
      piVar6 = piVar3;
      if (iVar8 - 0xfd8U < 0xfffff008) {
        piVar6 = malloc(0x1000);
        if (piVar6 == (int *)0x0) goto LAB_00035262;
        *piVar6 = (int)piVar3;
        piVar6[1] = 0;
        in_ECX[0x466] = piVar6;
        iVar8 = 0;
      }
      piVar6[1] = iVar8 + 0x20;
      *(undefined4 *)((int)piVar6 + iVar8 + 0xc) = 0x1010149;
      *(undefined ***)((int)piVar6 + iVar8 + 8) = &PTR_LAB_0004baf8;
      *(int *)((int)piVar6 + iVar8 + 0x10) = iVar4;
      *(int *)((int)piVar6 + iVar8 + 0x14) = iVar5;
      *(undefined1 *)((int)piVar6 + iVar8 + 0x18) = 1;
    }
    else {
      if (cVar1 != 'i') goto LAB_00035104;
      *in_ECX = pcVar2 + 2;
      iVar4 = FUN_0003a4f0();
      iVar8 = 0;
      if ((iVar4 == 0) || (iVar5 = FUN_00035010(), iVar5 == 0)) goto LAB_0003525a;
      piVar3 = (int *)in_ECX[0x466];
      iVar8 = piVar3[1];
      piVar6 = piVar3;
      if (iVar8 - 0xfd8U < 0xfffff008) {
        piVar6 = malloc(0x1000);
        if (piVar6 == (int *)0x0) goto LAB_00035262;
        *piVar6 = (int)piVar3;
        piVar6[1] = 0;
        in_ECX[0x466] = piVar6;
        iVar8 = 0;
      }
      piVar6[1] = iVar8 + 0x20;
      *(undefined4 *)((int)piVar6 + iVar8 + 0xc) = 0x1010149;
      *(undefined ***)((int)piVar6 + iVar8 + 8) = &PTR_LAB_0004baf8;
      *(int *)((int)piVar6 + iVar8 + 0x10) = iVar4;
      *(int *)((int)piVar6 + iVar8 + 0x14) = iVar5;
      *(undefined1 *)((int)piVar6 + iVar8 + 0x18) = 0;
    }
    iVar8 = (int)piVar6 + iVar8 + 8;
  }
LAB_0003525a:
  return iVar8;
}


// ==== FUN_00035270 @ 00035270

int FUN_00035270(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x20;
  uVar2 = *param_1;
  uVar3 = param_1[1];
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x101013d;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004bb68;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = 0;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x18) = uVar3;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar2;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00035310 @ 00035310

int FUN_00035310(char *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  size_t sVar4;
  int in_ECX;
  undefined4 *in_EDX;
  int iVar5;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar3 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar5 = 0;
  }
  piVar3[1] = iVar5 + 0x20;
  uVar2 = *in_EDX;
  sVar4 = strlen(param_1);
  *(undefined4 *)((int)piVar3 + iVar5 + 0xc) = 0x1010131;
  *(undefined ***)((int)piVar3 + iVar5 + 8) = &PTR_LAB_0004bba0;
  *(undefined4 *)((int)piVar3 + iVar5 + 0x10) = uVar2;
  *(char **)((int)piVar3 + iVar5 + 0x14) = param_1;
  *(char **)((int)piVar3 + iVar5 + 0x18) = param_1 + sVar4;
  return (int)piVar3 + iVar5 + 8;
}


// ==== FUN_000353d0 @ 000353d0

int FUN_000353d0(void)

{
  int iVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  undefined4 *in_ECX;
  char cVar9;
  char *pcVar10;
  int in_GS_OFFSET;
  undefined1 local_2c;
  int local_28;
  undefined4 local_24;
  int local_20;
  undefined4 local_1c;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar10 = (char *)*in_ECX;
  pcVar3 = (char *)in_ECX[1];
  iVar5 = 0;
  if ((uint)((int)pcVar3 - (int)pcVar10) < 2) goto LAB_00035568;
  cVar9 = *pcVar10;
  if (cVar9 == 'g') {
    if (pcVar10[1] == 's') {
      pcVar10 = pcVar10 + 2;
      *in_ECX = pcVar10;
      if (1 < (uint)((int)pcVar3 - (int)pcVar10)) {
        cVar9 = *pcVar10;
        local_2c = 1;
        goto LAB_00035441;
      }
    }
  }
  else {
    local_2c = 0;
LAB_00035441:
    cVar2 = pcVar10[1];
    if ((cVar9 == 'n') && ((cVar2 == 'w' || (cVar2 == 'a')))) {
      pcVar10 = pcVar10 + 2;
      *in_ECX = pcVar10;
      iVar5 = in_ECX[3];
      iVar6 = in_ECX[2];
      if (pcVar10 == pcVar3) goto LAB_00035495;
      while (*pcVar10 != '_') {
LAB_00035495:
        do {
          local_20 = FUN_00031980();
          if (local_20 == 0) goto LAB_00035566;
          FUN_0002f5d0();
          pcVar10 = (char *)*in_ECX;
        } while (pcVar10 == (char *)in_ECX[1]);
      }
      *in_ECX = pcVar10 + 1;
      iVar5 = (iVar5 - iVar6 >> 2) * 4;
      FUN_00039de0(in_ECX[2] + iVar5,in_ECX[3]);
      in_ECX[3] = iVar5 + in_ECX[2];
      iVar6 = FUN_0002d6e0();
      iVar5 = 0;
      if (iVar6 != 0) {
        pcVar10 = (char *)*in_ECX;
        pcVar3 = (char *)in_ECX[1];
        if ((((uint)((int)pcVar3 - (int)pcVar10) < 2) || (*pcVar10 != 'p')) || (pcVar10[1] != 'i'))
        {
          if ((pcVar10 == pcVar3) || (*pcVar10 != 'E')) goto LAB_00035568;
          *in_ECX = pcVar10 + 1;
          piVar8 = (int *)in_ECX[0x466];
          iVar5 = piVar8[1];
          if (iVar5 - 0xfd8U < 0xfffff008) {
            piVar7 = malloc(0x1000);
            if (piVar7 == (int *)0x0) goto LAB_000356f3;
            *piVar7 = (int)piVar8;
            piVar7[1] = 0;
            in_ECX[0x466] = piVar7;
            iVar5 = 0;
            piVar8 = piVar7;
          }
          piVar8[1] = iVar5 + 0x20;
          *(undefined4 *)((int)piVar8 + iVar5 + 0xc) = 0x1010138;
          *(undefined ***)((int)piVar8 + iVar5 + 8) = &PTR_LAB_0004bbd8;
          *(undefined4 *)((int)piVar8 + iVar5 + 0x14) = local_1c;
          *(int *)((int)piVar8 + iVar5 + 0x10) = local_20;
          *(int *)((int)piVar8 + iVar5 + 0x18) = iVar6;
          *(undefined4 *)((int)piVar8 + iVar5 + 0x1c) = 0;
          *(undefined4 *)((int)piVar8 + iVar5 + 0x20) = 0;
        }
        else {
          pcVar10 = pcVar10 + 2;
          *in_ECX = pcVar10;
          iVar5 = in_ECX[3];
          iVar4 = in_ECX[2];
          if (pcVar10 == pcVar3) goto LAB_0003553f;
          while (*pcVar10 != 'E') {
LAB_0003553f:
            do {
              local_28 = FUN_00031980();
              if (local_28 == 0) goto LAB_00035566;
              FUN_0002f5d0();
              pcVar10 = (char *)*in_ECX;
            } while (pcVar10 == (char *)in_ECX[1]);
          }
          *in_ECX = pcVar10 + 1;
          iVar5 = (iVar5 - iVar4 >> 2) * 4;
          FUN_00039de0(in_ECX[2] + iVar5,in_ECX[3]);
          in_ECX[3] = iVar5 + in_ECX[2];
          piVar7 = (int *)in_ECX[0x466];
          iVar5 = piVar7[1];
          piVar8 = piVar7;
          if (iVar5 - 0xfd8U < 0xfffff008) {
            piVar8 = malloc(0x1000);
            if (piVar8 == (int *)0x0) {
LAB_000356f3:
                    /* WARNING: Subroutine does not return */
              FUN_0002c220();
            }
            *piVar8 = (int)piVar7;
            piVar8[1] = 0;
            in_ECX[0x466] = piVar8;
            iVar5 = 0;
          }
          piVar8[1] = iVar5 + 0x20;
          *(undefined4 *)((int)piVar8 + iVar5 + 0xc) = 0x1010138;
          *(undefined ***)((int)piVar8 + iVar5 + 8) = &PTR_LAB_0004bbd8;
          *(int *)((int)piVar8 + iVar5 + 0x10) = local_20;
          *(undefined4 *)((int)piVar8 + iVar5 + 0x14) = local_1c;
          *(int *)((int)piVar8 + iVar5 + 0x18) = iVar6;
          *(int *)((int)piVar8 + iVar5 + 0x1c) = local_28;
          *(undefined4 *)((int)piVar8 + iVar5 + 0x20) = local_24;
        }
        *(undefined1 *)((int)piVar8 + iVar5 + 0x24) = local_2c;
        *(bool *)((int)piVar8 + iVar5 + 0x25) = cVar2 == 'a';
        iVar5 = (int)piVar8 + iVar5 + 8;
      }
      goto LAB_00035568;
    }
  }
LAB_00035566:
  iVar5 = 0;
LAB_00035568:
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar5;
}


// ==== FUN_00035710 @ 00035710

int FUN_00035710(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010134;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004bc10;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "noexcept (";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  *(undefined **)((int)piVar3 + iVar4 + 0x1c) = &DAT_000150c3;
  *(undefined **)((int)piVar3 + iVar4 + 0x20) = &DAT_000150c4;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_000357d0 @ 000357d0

int FUN_000357d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int in_ECX;
  int iVar6;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar1[1];
  piVar5 = piVar1;
  if (iVar6 - 0xfd8U < 0xfffff008) {
    piVar5 = malloc(0x1000);
    if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar5 = (int)piVar1;
    piVar5[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar5;
    iVar6 = 0;
  }
  piVar5[1] = iVar6 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  uVar4 = *param_2;
  *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010132;
  *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_LAB_0004bc48;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x18) = uVar4;
  return (int)piVar5 + iVar6 + 8;
}


// ==== FUN_00035870 @ 00035870

int FUN_00035870(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010135;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b890;
  *(char **)((int)piVar4 + iVar5 + 0x10) = "reinterpret_cast";
  *(char **)((int)piVar4 + iVar5 + 0x14) = "";
  *(undefined4 *)((int)piVar4 + iVar5 + 0x18) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x1c) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00035920 @ 00035920

int FUN_00035920(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010135;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b890;
  *(char **)((int)piVar4 + iVar5 + 0x10) = "static_cast";
  *(char **)((int)piVar4 + iVar5 + 0x14) = "";
  *(undefined4 *)((int)piVar4 + iVar5 + 0x18) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x1c) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_000359d0 @ 000359d0

int FUN_000359d0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010122;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b7e8;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00035a60 @ 00035a60

int FUN_00035a60(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  size_t sVar4;
  int in_ECX;
  char *in_EDX;
  int iVar5;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar3 = piVar1;
  if (iVar5 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar5 = 0;
  }
  piVar3[1] = iVar5 + 0x20;
  sVar4 = strlen(in_EDX);
  uVar2 = *param_1;
  *(undefined4 *)((int)piVar3 + iVar5 + 0xc) = 0x1010134;
  *(undefined ***)((int)piVar3 + iVar5 + 8) = &PTR_LAB_0004bc10;
  *(char **)((int)piVar3 + iVar5 + 0x10) = in_EDX;
  *(char **)((int)piVar3 + iVar5 + 0x14) = in_EDX + sVar4;
  *(undefined4 *)((int)piVar3 + iVar5 + 0x18) = uVar2;
  *(undefined **)((int)piVar3 + iVar5 + 0x1c) = &DAT_000150c3;
  *(undefined **)((int)piVar3 + iVar5 + 0x20) = &DAT_000150c4;
  return (int)piVar3 + iVar5 + 8;
}


// ==== FUN_00035b30 @ 00035b30

int FUN_00035b30(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010136;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004bc80;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00035bc0 @ 00035bc0

int FUN_00035bc0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010134;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004bc10;
  *(char **)((int)piVar3 + iVar4 + 0x10) = "sizeof... (";
  *(char **)((int)piVar3 + iVar4 + 0x14) = "";
  *(undefined4 *)((int)piVar3 + iVar4 + 0x18) = uVar2;
  *(undefined **)((int)piVar3 + iVar4 + 0x1c) = &DAT_000150c3;
  *(undefined **)((int)piVar3 + iVar4 + 0x20) = &DAT_000150c4;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00035c80 @ 00035c80

int FUN_00035c80(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = in_EDX[1];
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010100;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004bcb8;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00035d20 @ 00035d20

int FUN_00035d20(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int in_ECX;
  int iVar6;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar1[1];
  piVar5 = piVar1;
  if (iVar6 - 0xfd8U < 0xfffff008) {
    piVar5 = malloc(0x1000);
    if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar5 = (int)piVar1;
    piVar5[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar5;
    iVar6 = 0;
  }
  piVar5[1] = iVar6 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  uVar4 = param_1[1];
  *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x101013d;
  *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_LAB_0004bb68;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x18) = uVar4;
  return (int)piVar5 + iVar6 + 8;
}


// ==== FUN_00035dc0 @ 00035dc0

int FUN_00035dc0(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_00035e70 @ 00035e70

int FUN_00035e70(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x101013f;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004bcf0;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00035f00 @ 00035f00

int FUN_00035f00(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010140;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004bd28;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00035f90 @ 00035f90

int FUN_00035f90(undefined4 param_1,undefined4 param_2)

{
  char *pcVar1;
  char *pcVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *in_ECX;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  
  pcVar1 = (char *)*in_ECX;
  pcVar2 = (char *)in_ECX[1];
  pcVar6 = pcVar1;
  if ((pcVar1 != pcVar2) && (*pcVar1 == 'n')) {
    pcVar6 = pcVar1 + 1;
    *in_ECX = (int)pcVar6;
  }
  iVar4 = 0;
  if ((pcVar2 != pcVar6) && (0xfffffff5 < (int)*pcVar6 - 0x3aU)) {
    do {
      pcVar7 = pcVar6;
      pcVar6 = pcVar7 + 1;
      *in_ECX = (int)pcVar6;
      if (pcVar6 == pcVar2) {
        pcVar8 = pcVar2;
        if (pcVar1 == pcVar2) {
          return 0;
        }
        goto LAB_00036024;
      }
    } while (0xfffffff5 < (int)*pcVar6 - 0x3aU);
    pcVar8 = pcVar6;
    if (pcVar1 != pcVar6) {
LAB_00036024:
      if ((pcVar6 != pcVar2) && (*pcVar6 == 'E')) {
        *in_ECX = (int)(pcVar7 + 2);
        piVar3 = (int *)in_ECX[0x466];
        iVar4 = piVar3[1];
        piVar5 = piVar3;
        if (iVar4 - 0xfd8U < 0xfffff008) {
          piVar5 = malloc(0x1000);
          if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar5 = (int)piVar3;
          piVar5[1] = 0;
          in_ECX[0x466] = (int)piVar5;
          iVar4 = 0;
        }
        piVar5[1] = iVar4 + 0x20;
        *(undefined4 *)((int)piVar5 + iVar4 + 0xc) = 0x1010145;
        *(undefined ***)((int)piVar5 + iVar4 + 8) = &PTR_LAB_0004b430;
        *(undefined4 *)((int)piVar5 + iVar4 + 0x14) = param_2;
        *(undefined4 *)((int)piVar5 + iVar4 + 0x10) = param_1;
        *(char **)((int)piVar5 + iVar4 + 0x18) = pcVar1;
        *(char **)((int)piVar5 + iVar4 + 0x1c) = pcVar8;
        iVar4 = (int)piVar5 + iVar4 + 8;
      }
    }
  }
  return iVar4;
}


// ==== FUN_000360d0 @ 000360d0

int FUN_000360d0(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  int *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  iVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010141;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b468;
  *(bool *)((int)piVar3 + iVar4 + 0x10) = iVar2 != 0;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00036160 @ 00036160

int FUN_00036160(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010142;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b548;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_000361f0 @ 000361f0

int FUN_000361f0(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_000362a0 @ 000362a0

int FUN_000362a0(void)

{
  int *piVar1;
  int iVar2;
  size_t __n;
  undefined *puVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  char *pcVar7;
  char cVar8;
  int *in_ECX;
  int iVar9;
  char *pcVar10;
  int in_EDX;
  int iVar11;
  int iVar12;
  uint uVar13;
  char *pcVar14;
  int iVar15;
  char *pcVar16;
  int in_GS_OFFSET;
  char *local_78;
  int local_60;
  undefined4 local_5c;
  undefined4 **local_58;
  int local_54;
  undefined4 *local_48;
  undefined4 *local_44;
  undefined1 *local_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined1 local_1c [4];
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if (in_EDX != 0) {
    in_ECX[0x54] = in_ECX[0x53];
  }
  pcVar14 = (char *)*in_ECX;
  pcVar7 = (char *)in_ECX[1];
  iVar11 = 0;
  if (((uint)((int)pcVar7 - (int)pcVar14) < 2) || (*pcVar14 != 'U')) goto LAB_00036829;
  cVar8 = pcVar14[1];
  if (cVar8 == 'b') {
    pcVar16 = pcVar14 + 2;
    *in_ECX = (int)pcVar16;
    if (pcVar7 != pcVar16) {
      iVar11 = 0;
      if (0xfffffff5 < (int)*pcVar16 - 0x3aU) {
        pcVar14 = pcVar14 + 3;
        do {
          pcVar16 = pcVar14;
          *in_ECX = (int)pcVar16;
          if (pcVar16 == pcVar7) goto LAB_00036829;
          pcVar14 = pcVar16 + 1;
        } while (0xfffffff5 < (int)*pcVar16 - 0x3aU);
      }
      if ((pcVar16 != pcVar7) && (*pcVar16 == '_')) {
        *in_ECX = (int)(pcVar16 + 1);
        piVar1 = (int *)in_ECX[0x466];
        iVar9 = piVar1[1];
        piVar6 = piVar1;
        if (iVar9 - 0xfe8U < 0xfffff008) {
          piVar6 = malloc(0x1000);
          if (piVar6 == (int *)0x0) goto LAB_0003683f;
          *piVar6 = (int)piVar1;
          piVar6[1] = 0;
          in_ECX[0x466] = (int)piVar6;
          iVar9 = 0;
        }
        piVar6[1] = iVar9 + 0x10;
        iVar11 = (int)piVar6 + iVar9 + 8;
        *(undefined4 *)((int)piVar6 + iVar9 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar6 + iVar9 + 8) = &PTR_LAB_0004b388;
        *(char **)((int)piVar6 + iVar9 + 0x10) = "\'block-literal\'";
        *(char **)((int)piVar6 + iVar9 + 0x14) = "";
      }
    }
    goto LAB_00036829;
  }
  if (cVar8 != 'l') {
    if (cVar8 == 't') {
      pcVar16 = pcVar14 + 2;
      *in_ECX = (int)pcVar16;
      if (pcVar7 != pcVar16) {
        if ((int)*pcVar16 - 0x3aU < 0xfffffff6) {
          local_78 = (char *)0x0;
          pcVar10 = pcVar16;
          pcVar14 = (char *)0x0;
        }
        else {
          pcVar14 = pcVar14 + 3;
          do {
            pcVar10 = pcVar14;
            *in_ECX = (int)pcVar10;
            if (pcVar10 == pcVar7) {
              pcVar10 = pcVar7;
              goto LAB_00036699;
            }
            pcVar14 = pcVar10 + 1;
          } while (0xfffffff5 < (int)*pcVar10 - 0x3aU);
LAB_00036699:
          pcVar14 = pcVar10;
          local_78 = pcVar16;
        }
        iVar11 = 0;
        if ((pcVar10 != pcVar7) && (*pcVar10 == '_')) {
          *in_ECX = (int)(pcVar10 + 1);
          piVar1 = (int *)in_ECX[0x466];
          iVar11 = piVar1[1];
          piVar6 = piVar1;
          if (iVar11 - 0xfe8U < 0xfffff008) {
            piVar6 = malloc(0x1000);
            if (piVar6 == (int *)0x0) goto LAB_0003683f;
            *piVar6 = (int)piVar1;
            piVar6[1] = 0;
            in_ECX[0x466] = (int)piVar6;
            iVar11 = 0;
          }
          piVar6[1] = iVar11 + 0x10;
          *(undefined4 *)((int)piVar6 + iVar11 + 0xc) = 0x101012c;
          *(undefined ***)((int)piVar6 + iVar11 + 8) = &PTR_LAB_0004b580;
          *(char **)((int)piVar6 + iVar11 + 0x10) = local_78;
          *(char **)((int)piVar6 + iVar11 + 0x14) = pcVar14;
          iVar11 = (int)piVar6 + iVar11 + 8;
        }
      }
    }
    goto LAB_00036829;
  }
  *in_ECX = (int)(pcVar14 + 2);
  iVar9 = in_ECX[0x62];
  iVar2 = in_ECX[0x54] - in_ECX[0x53] >> 2;
  in_ECX[0x62] = iVar2;
  local_48 = &local_3c;
  local_40 = local_1c;
  local_58 = &local_48;
  local_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  local_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  local_44 = local_48;
  FUN_000315a0();
  iVar11 = in_ECX[3];
  iVar15 = in_ECX[2];
  pcVar14 = (char *)*in_ECX;
  iVar4 = iVar11;
  iVar12 = iVar15;
  if ((char *)in_ECX[1] != pcVar14) {
    while (*pcVar14 == 'T') {
                    /* try { // try from 000363d5 to 000363e4 has its CatchHandler @ 0003684d */
      __n = __strlen_chk(&DAT_00014be1,5);
      if ((uint)(in_ECX[1] - *in_ECX) < 2) {
        cVar8 = '\0';
      }
      else {
        cVar8 = *(char *)(*in_ECX + 1);
      }
      if (((__n == 0) || (puVar3 = memchr(&DAT_00014be1,(int)cVar8,__n), puVar3 == (undefined *)0x0)
          ) || (puVar3 == &DAT_00014be0)) break;
                    /* try { // try from 0003641b to 00036421 has its CatchHandler @ 0003684b */
      local_58 = (undefined4 **)FUN_000377c0();
      if (local_58 == (undefined4 **)0x0) goto LAB_000365b7;
      FUN_0002f5d0();
      pcVar14 = (char *)*in_ECX;
      if ((char *)in_ECX[1] == pcVar14) break;
    }
    iVar12 = in_ECX[2];
    iVar4 = in_ECX[3];
  }
  iVar11 = iVar11 - iVar15 >> 2;
  iVar15 = iVar11 * 4;
  FUN_00039de0(iVar12 + iVar11 * 4,iVar4);
  in_ECX[3] = in_ECX[2] + iVar15;
  if (local_54 == 0) {
    in_ECX[0x54] = in_ECX[0x54] + -4;
  }
                    /* try { // try from 00036485 to 0003649a has its CatchHandler @ 00036849 */
  pcVar14 = "vE";
  uVar5 = __strlen_chk(&DAT_00014992,3);
  iVar11 = *in_ECX;
  if ((uint)(in_ECX[1] - iVar11) < uVar5) {
LAB_000364b0:
    do {
                    /* try { // try from 000364b0 to 000364ba has its CatchHandler @ 0003684f */
      local_60 = FUN_0002d6e0();
      if (local_60 == 0) goto LAB_000365b7;
      FUN_0002f5d0();
      pcVar14 = (char *)*in_ECX;
    } while ((pcVar14 == (char *)in_ECX[1]) || (*pcVar14 != 'E'));
    pcVar14 = pcVar14 + 1;
  }
  else {
    if (uVar5 != 0) {
      uVar13 = 0;
      do {
        if (*pcVar14 != *(char *)(iVar11 + uVar13)) goto LAB_000364b0;
        pcVar14 = pcVar14 + 1;
        uVar13 = uVar13 + 1;
      } while (uVar5 != uVar13);
    }
    pcVar14 = (char *)(iVar11 + uVar5);
  }
  *in_ECX = (int)pcVar14;
  FUN_00039de0(in_ECX[2] + iVar15,in_ECX[3]);
  in_ECX[3] = iVar15 + in_ECX[2];
  local_78 = (char *)*in_ECX;
  pcVar14 = (char *)in_ECX[1];
  pcVar7 = local_78;
  if (pcVar14 == local_78) {
    local_78 = (char *)0x0;
    pcVar16 = (char *)0x0;
  }
  else {
    pcVar16 = local_78;
    if ((int)*local_78 - 0x3aU < 0xfffffff6) {
      local_78 = (char *)0x0;
      pcVar16 = (char *)0x0;
    }
    else {
      do {
        pcVar16 = pcVar16 + 1;
        *in_ECX = (int)pcVar16;
        if (pcVar16 == pcVar14) {
          pcVar16 = pcVar14;
          goto LAB_0003672a;
        }
      } while (0xfffffff5 < (int)*pcVar16 - 0x3aU);
LAB_0003672a:
      pcVar7 = pcVar16;
    }
  }
  iVar11 = 0;
  if ((pcVar7 != pcVar14) && (*pcVar7 == '_')) {
    *in_ECX = (int)(pcVar7 + 1);
    piVar1 = (int *)in_ECX[0x466];
    iVar11 = piVar1[1];
    piVar6 = piVar1;
    if (iVar11 - 0xfd8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) {
LAB_0003683f:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      *piVar6 = (int)piVar1;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar11 = 0;
    }
    piVar6[1] = iVar11 + 0x20;
    *(undefined4 *)((int)piVar6 + iVar11 + 0xc) = 0x101012d;
    *(undefined ***)((int)piVar6 + iVar11 + 8) = &PTR_LAB_0004b6d0;
    *(undefined4 ***)((int)piVar6 + iVar11 + 0x10) = local_58;
    *(int *)((int)piVar6 + iVar11 + 0x14) = local_54;
    *(int *)((int)piVar6 + iVar11 + 0x18) = local_60;
    *(undefined4 *)((int)piVar6 + iVar11 + 0x1c) = local_5c;
    *(char **)((int)piVar6 + iVar11 + 0x20) = local_78;
    *(char **)((int)piVar6 + iVar11 + 0x24) = pcVar16;
    iVar11 = (int)piVar6 + iVar11 + 8;
  }
LAB_000367f0:
  in_ECX[0x54] = iVar2 * 4 + in_ECX[0x53];
  if (local_48 != &local_3c) {
    free(local_48);
  }
  in_ECX[0x62] = iVar9;
LAB_00036829:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar11;
LAB_000365b7:
  iVar11 = 0;
  goto LAB_000367f0;
}


// ==== FUN_000368a0 @ 000368a0

int FUN_000368a0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010143;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b708;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00036930 @ 00036930

int FUN_00036930(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int in_ECX;
  int iVar6;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar1[1];
  piVar5 = piVar1;
  if (iVar6 - 0xfd8U < 0xfffff008) {
    piVar5 = malloc(0x1000);
    if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar5 = (int)piVar1;
    piVar5[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar5;
    iVar6 = 0;
  }
  piVar5[1] = iVar6 + 0x20;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  uVar4 = param_1[1];
  *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010144;
  *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_LAB_0004b740;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x18) = uVar4;
  return (int)piVar5 + iVar6 + 8;
}


// ==== FUN_00036fd0 @ 00036fd0

void FUN_00036fd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined1 param_5)

{
  int iVar1;
  int in_GS_OFFSET;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  __vsnprintf_chk(param_1,param_3,0,param_2,param_4,&param_5);
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_000377c0 @ 000377c0

int FUN_000377c0(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *in_ECX;
  int iVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  int iVar11;
  char *pcVar12;
  int in_GS_OFFSET;
  char *local_6c;
  undefined4 **local_58;
  undefined4 local_54;
  undefined4 *local_48;
  undefined4 *local_44;
  undefined1 *local_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined1 local_1c [4];
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar12 = (char *)*in_ECX;
  iVar11 = 0;
  if (((uint)(in_ECX[1] - (int)pcVar12) < 2) || (*pcVar12 != 'T')) goto switchD_0003781a_caseD_6f;
  switch(pcVar12[1]) {
  case 'n':
    *in_ECX = (int)(pcVar12 + 2);
    iVar8 = in_ECX[100];
    in_ECX[100] = iVar8 + 1;
    piVar10 = (int *)in_ECX[0x466];
    iVar7 = piVar10[1];
    if (iVar7 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_00037d2f;
      *piVar5 = (int)piVar10;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar7 = 0;
      piVar10 = piVar5;
    }
    piVar10[1] = iVar7 + 0x10;
    *(undefined4 *)((int)piVar10 + iVar7 + 0xc) = 0x101011b;
    *(undefined ***)((int)piVar10 + iVar7 + 8) = &PTR_LAB_0004b5b8;
    *(undefined4 *)((int)piVar10 + iVar7 + 0x10) = 1;
    *(int *)((int)piVar10 + iVar7 + 0x14) = iVar8;
    FUN_00037f60();
    iVar8 = FUN_0002d6e0();
    if (iVar8 == 0) goto switchD_0003781a_caseD_6f;
    piVar5 = (int *)in_ECX[0x466];
    iVar11 = piVar5[1];
    piVar6 = piVar5;
    if (iVar11 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) {
LAB_00037d2f:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      *piVar6 = (int)piVar5;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar11 = 0;
    }
    piVar6[1] = iVar11 + 0x10;
    *(undefined4 *)((int)piVar6 + iVar11 + 0xc) = 0x101001d;
    *(undefined ***)((int)piVar6 + iVar11 + 8) = &PTR_LAB_0004b628;
    *(int *)((int)piVar6 + iVar11 + 0x10) = (int)piVar10 + iVar7 + 8;
    *(int *)((int)piVar6 + iVar11 + 0x14) = iVar8;
    break;
  default:
    goto switchD_0003781a_caseD_6f;
  case 'p':
    *in_ECX = (int)(pcVar12 + 2);
    iVar8 = FUN_000377c0();
    if (iVar8 == 0) goto switchD_0003781a_caseD_6f;
    piVar10 = (int *)in_ECX[0x466];
    iVar11 = piVar10[1];
    piVar6 = piVar10;
    if (iVar11 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00037d2f;
      *piVar6 = (int)piVar10;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar11 = 0;
    }
    piVar6[1] = iVar11 + 0x10;
    *(undefined4 *)((int)piVar6 + iVar11 + 0xc) = 0x101001f;
    *(undefined ***)((int)piVar6 + iVar11 + 8) = &PTR_LAB_0004b698;
    *(int *)((int)piVar6 + iVar11 + 0x10) = iVar8;
    break;
  case 't':
    *in_ECX = (int)(pcVar12 + 2);
    iVar11 = in_ECX[0x65];
    in_ECX[0x65] = iVar11 + 1;
    piVar10 = (int *)in_ECX[0x466];
    iVar8 = piVar10[1];
    piVar5 = piVar10;
    if (iVar8 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_00037d2f;
      *piVar5 = (int)piVar10;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar8 = 0;
    }
    piVar5[1] = iVar8 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar8 + 0xc) = 0x101011b;
    *(undefined ***)((int)piVar5 + iVar8 + 8) = &PTR_LAB_0004b5b8;
    *(undefined4 *)((int)piVar5 + iVar8 + 0x10) = 2;
    *(int *)((int)piVar5 + iVar8 + 0x14) = iVar11;
    FUN_00037f60();
    iVar11 = in_ECX[3];
    iVar7 = in_ECX[2];
    iVar1 = in_ECX[0x54];
    iVar2 = in_ECX[0x53];
    local_48 = &local_3c;
    local_40 = local_1c;
    local_58 = &local_48;
    local_3c = 0;
    uStack_38 = 0;
    uStack_34 = 0;
    uStack_30 = 0;
    local_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_20 = 0;
    local_44 = local_48;
    FUN_000315a0();
    local_6c = "E";
    do {
                    /* try { // try from 00037990 to 000379a3 has its CatchHandler @ 00037d3b */
      uVar4 = __strlen_chk(&DAT_000150c8,2);
      iVar3 = *in_ECX;
      if (uVar4 <= (uint)(in_ECX[1] - iVar3)) {
        if (uVar4 == 0) {
LAB_00037a02:
          *in_ECX = iVar3 + uVar4;
          iVar11 = (iVar11 - iVar7 >> 2) * 4;
          FUN_00039de0(in_ECX[2] + iVar11,in_ECX[3]);
          in_ECX[3] = iVar11 + in_ECX[2];
          piVar10 = (int *)in_ECX[0x466];
          iVar11 = piVar10[1];
          piVar6 = piVar10;
          if (iVar11 - 0xfd8U < 0xfffff008) {
            piVar6 = malloc(0x1000);
            if (piVar6 == (int *)0x0) goto LAB_00037d2f;
            *piVar6 = (int)piVar10;
            piVar6[1] = 0;
            in_ECX[0x466] = (int)piVar6;
            iVar11 = 0;
          }
          piVar6[1] = iVar11 + 0x20;
          *(undefined4 *)((int)piVar6 + iVar11 + 0xc) = 0x101001e;
          *(undefined ***)((int)piVar6 + iVar11 + 8) = &PTR_LAB_0004b660;
          *(int *)((int)piVar6 + iVar11 + 0x10) = (int)piVar5 + iVar8 + 8;
          *(undefined4 *)((int)piVar6 + iVar11 + 0x18) = local_54;
          *(undefined4 ***)((int)piVar6 + iVar11 + 0x14) = local_58;
          iVar11 = (int)piVar6 + iVar11 + 8;
          goto LAB_00037aa5;
        }
        uVar9 = 0;
        pcVar12 = local_6c;
        while (*pcVar12 == *(char *)(iVar3 + uVar9)) {
          pcVar12 = pcVar12 + 1;
          uVar9 = uVar9 + 1;
          if (uVar4 == uVar9) goto LAB_00037a02;
        }
      }
                    /* try { // try from 000379b1 to 000379bb has its CatchHandler @ 00037d39 */
      local_58 = (undefined4 **)FUN_000377c0();
      if (local_58 == (undefined4 **)0x0) goto LAB_00037d28;
      FUN_0002f5d0();
    } while( true );
  case 'y':
    *in_ECX = (int)(pcVar12 + 2);
    iVar11 = in_ECX[99];
    in_ECX[99] = iVar11 + 1;
    piVar10 = (int *)in_ECX[0x466];
    iVar8 = piVar10[1];
    piVar5 = piVar10;
    if (iVar8 - 0xfe8U < 0xfffff008) {
      piVar5 = malloc(0x1000);
      if (piVar5 == (int *)0x0) goto LAB_00037d2f;
      *piVar5 = (int)piVar10;
      piVar5[1] = 0;
      in_ECX[0x466] = (int)piVar5;
      iVar8 = 0;
    }
    piVar5[1] = iVar8 + 0x10;
    *(undefined4 *)((int)piVar5 + iVar8 + 0xc) = 0x101011b;
    *(undefined ***)((int)piVar5 + iVar8 + 8) = &PTR_LAB_0004b5b8;
    *(undefined4 *)((int)piVar5 + iVar8 + 0x10) = 0;
    *(int *)((int)piVar5 + iVar8 + 0x14) = iVar11;
    FUN_00037f60();
    piVar10 = (int *)in_ECX[0x466];
    iVar11 = piVar10[1];
    piVar6 = piVar10;
    if (iVar11 - 0xfe8U < 0xfffff008) {
      piVar6 = malloc(0x1000);
      if (piVar6 == (int *)0x0) goto LAB_00037d2f;
      *piVar6 = (int)piVar10;
      piVar6[1] = 0;
      in_ECX[0x466] = (int)piVar6;
      iVar11 = 0;
    }
    piVar6[1] = iVar11 + 0x10;
    *(undefined4 *)((int)piVar6 + iVar11 + 0xc) = 0x101001c;
    *(undefined ***)((int)piVar6 + iVar11 + 8) = &PTR_LAB_0004b5f0;
    *(int *)((int)piVar6 + iVar11 + 0x10) = (int)piVar5 + iVar8 + 8;
  }
  iVar11 = (int)piVar6 + iVar11 + 8;
  goto switchD_0003781a_caseD_6f;
LAB_00037d28:
  iVar11 = 0;
LAB_00037aa5:
  in_ECX[0x54] = (iVar1 - iVar2 >> 2) * 4 + in_ECX[0x53];
  if (local_48 != &local_3c) {
    free(local_48);
  }
switchD_0003781a_caseD_6f:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar11;
}


// ==== FUN_00037d70 @ 00037d70

int FUN_00037d70(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_00037f60 @ 00037f60

void FUN_00037f60(void)

{
  undefined4 *__src;
  undefined4 uVar1;
  void *__dest;
  undefined4 *in_ECX;
  undefined4 *in_EDX;
  size_t __n;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)in_ECX[1];
  if (puVar2 == (undefined4 *)in_ECX[2]) {
    __src = (undefined4 *)*in_ECX;
    __n = (int)puVar2 - (int)__src;
    if (__src == in_ECX + 3) {
      __dest = malloc(__n * 2);
      if (__dest == (void *)0x0) goto LAB_00038009;
      if (__n != 0) {
        memmove(__dest,__src,__n);
      }
      *in_ECX = __dest;
    }
    else {
      __dest = realloc(__src,__n * 2);
      *in_ECX = __dest;
      if (__dest == (void *)0x0) {
LAB_00038009:
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
    }
    puVar2 = (undefined4 *)((int)__dest + ((int)__n >> 2) * 4);
    in_ECX[1] = puVar2;
    in_ECX[2] = (void *)((int)__dest + ((int)__n >> 1) * 4);
  }
  uVar1 = *in_EDX;
  in_ECX[1] = puVar2 + 1;
  *puVar2 = uVar1;
  return;
}


// ==== FUN_00038610 @ 00038610

void FUN_00038610(void)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  uint __size;
  void *pvVar4;
  int iVar5;
  bool bVar6;
  int *in_ECX;
  undefined4 *in_EDX;
  int iVar7;
  
  if (in_ECX[1] != 0) {
    iVar3 = in_EDX[1];
    iVar7 = 0;
    bVar6 = true;
    do {
      iVar5 = iVar3;
      if (!bVar6) {
        uVar1 = iVar3 + 2;
        if (uVar1 < (uint)in_EDX[2]) {
          pvVar4 = (void *)*in_EDX;
        }
        else {
          __size = in_EDX[2] * 2;
          if (__size < uVar1) {
            __size = uVar1;
          }
          in_EDX[2] = __size;
          pvVar4 = realloc((void *)*in_EDX,__size);
          *in_EDX = pvVar4;
          if (pvVar4 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          iVar5 = in_EDX[1];
        }
        *(undefined2 *)((int)pvVar4 + iVar5) = 0x202c;
        iVar5 = in_EDX[1] + 2;
        in_EDX[1] = iVar5;
      }
      piVar2 = *(int **)(*in_ECX + iVar7 * 4);
      (**(code **)(*piVar2 + 0x10))(piVar2,in_EDX);
      if (*(char *)((int)piVar2 + 5) != '\x01') {
        (**(code **)(*piVar2 + 0x14))(piVar2,in_EDX);
      }
      if (iVar5 == in_EDX[1]) {
        in_EDX[1] = iVar3;
      }
      else {
        bVar6 = false;
        iVar3 = in_EDX[1];
      }
      iVar7 = iVar7 + 1;
    } while (iVar7 != in_ECX[1]);
  }
  return;
}


// ==== FUN_00038970 @ 00038970

void FUN_00038970(void)

{
  uint uVar1;
  uint uVar2;
  void *pvVar3;
  int in_ECX;
  undefined4 *in_EDX;
  int iVar4;
  
  iVar4 = in_EDX[1];
  if (*(int *)(in_ECX + 0xc) != 0) {
    uVar1 = iVar4 + 1;
    if (uVar1 < (uint)in_EDX[2]) {
      pvVar3 = (void *)*in_EDX;
    }
    else {
      uVar2 = in_EDX[2] * 2;
      if (uVar2 < uVar1) {
        uVar2 = uVar1;
      }
      in_EDX[2] = uVar2;
      pvVar3 = realloc((void *)*in_EDX,uVar2);
      *in_EDX = pvVar3;
      if (pvVar3 == (void *)0x0) goto LAB_00038aa6;
      iVar4 = in_EDX[1];
    }
    *(undefined1 *)((int)pvVar3 + iVar4) = 0x3c;
    in_EDX[1] = in_EDX[1] + 1;
    FUN_00038610();
    iVar4 = in_EDX[1];
    uVar1 = iVar4 + 1;
    if (uVar1 < (uint)in_EDX[2]) {
      pvVar3 = (void *)*in_EDX;
    }
    else {
      uVar2 = in_EDX[2] * 2;
      if (uVar2 < uVar1) {
        uVar2 = uVar1;
      }
      in_EDX[2] = uVar2;
      pvVar3 = realloc((void *)*in_EDX,uVar2);
      *in_EDX = pvVar3;
      if (pvVar3 == (void *)0x0) goto LAB_00038aa6;
      iVar4 = in_EDX[1];
    }
    *(undefined1 *)((int)pvVar3 + iVar4) = 0x3e;
    iVar4 = in_EDX[1] + 1;
    in_EDX[1] = iVar4;
  }
  uVar1 = iVar4 + 1;
  if (uVar1 < (uint)in_EDX[2]) {
    pvVar3 = (void *)*in_EDX;
  }
  else {
    uVar2 = in_EDX[2] * 2;
    if (uVar2 < uVar1) {
      uVar2 = uVar1;
    }
    in_EDX[2] = uVar2;
    pvVar3 = realloc((void *)*in_EDX,uVar2);
    *in_EDX = pvVar3;
    if (pvVar3 == (void *)0x0) goto LAB_00038aa6;
    iVar4 = in_EDX[1];
  }
  *(undefined1 *)((int)pvVar3 + iVar4) = 0x28;
  in_EDX[1] = in_EDX[1] + 1;
  FUN_00038610();
  iVar4 = in_EDX[1];
  uVar1 = iVar4 + 1;
  if (uVar1 < (uint)in_EDX[2]) {
    pvVar3 = (void *)*in_EDX;
  }
  else {
    uVar2 = in_EDX[2] * 2;
    if (uVar2 < uVar1) {
      uVar2 = uVar1;
    }
    in_EDX[2] = uVar2;
    pvVar3 = realloc((void *)*in_EDX,uVar2);
    *in_EDX = pvVar3;
    if (pvVar3 == (void *)0x0) {
LAB_00038aa6:
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    iVar4 = in_EDX[1];
  }
  *(undefined1 *)((int)pvVar3 + iVar4) = 0x29;
  in_EDX[1] = in_EDX[1] + 1;
  return;
}


// ==== FUN_00039360 @ 00039360

void FUN_00039360(void)

{
  undefined4 *puVar1;
  uint uVar2;
  void *pvVar3;
  int *in_ECX;
  uint uVar4;
  int iVar5;
  int iVar6;
  int in_GS_OFFSET;
  undefined **local_28;
  undefined4 local_24;
  undefined4 local_20;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  puVar1 = (undefined4 *)*in_ECX;
  iVar6 = in_ECX[1];
  iVar5 = puVar1[1];
  uVar4 = iVar5 + 1;
  if (uVar4 < (uint)puVar1[2]) {
    pvVar3 = (void *)*puVar1;
  }
  else {
    uVar2 = puVar1[2] * 2;
    if (uVar2 < uVar4) {
      uVar2 = uVar4;
    }
    puVar1[2] = uVar2;
    pvVar3 = realloc((void *)*puVar1,uVar2);
    *puVar1 = pvVar3;
    if (pvVar3 == (void *)0x0) goto LAB_0003944e;
    iVar5 = puVar1[1];
    uVar4 = iVar5 + 1;
  }
  puVar1[1] = uVar4;
  *(undefined1 *)((int)pvVar3 + iVar5) = 0x28;
  local_20 = *(undefined4 *)(iVar6 + 8);
  local_24 = 0x1010122;
  local_28 = &PTR_LAB_0004b7e8;
  FUN_00039460(&local_28,*in_ECX);
  puVar1 = (undefined4 *)*in_ECX;
  iVar6 = puVar1[1];
  uVar4 = iVar6 + 1;
  if (uVar4 < (uint)puVar1[2]) {
    pvVar3 = (void *)*puVar1;
  }
  else {
    uVar2 = puVar1[2] * 2;
    if (uVar2 < uVar4) {
      uVar2 = uVar4;
    }
    puVar1[2] = uVar2;
    pvVar3 = realloc((void *)*puVar1,uVar2);
    *puVar1 = pvVar3;
    if (pvVar3 == (void *)0x0) {
LAB_0003944e:
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    iVar6 = puVar1[1];
    uVar4 = iVar6 + 1;
  }
  puVar1[1] = uVar4;
  *(undefined1 *)((int)pvVar3 + iVar6) = 0x29;
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}


// ==== FUN_00039460 @ 00039460

void FUN_00039460(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  size_t sVar6;
  uint __size;
  void *pvVar7;
  int iVar8;
  uint uVar9;
  
  iVar8 = param_2[1];
  uVar2 = param_2[3];
  param_2[3] = 0xffffffff;
  uVar3 = param_2[4];
  param_2[4] = 0xffffffff;
  piVar4 = *(int **)(param_1 + 8);
                    /* try { // try from 000394a5 to 000394c5 has its CatchHandler @ 00039656 */
  (**(code **)(*piVar4 + 0x10))(piVar4,param_2);
  if (*(char *)((int)piVar4 + 5) != '\x01') {
    (**(code **)(*piVar4 + 0x14))(piVar4,param_2);
  }
  uVar5 = param_2[4];
  if (uVar5 == 0xffffffff) {
                    /* try { // try from 000395bc to 000395cf has its CatchHandler @ 00039656 */
    sVar6 = __strlen_chk(&DAT_00014af1,4);
    if (sVar6 == 0) goto LAB_00039633;
    iVar8 = param_2[1];
    uVar5 = iVar8 + sVar6;
    if (uVar5 < (uint)param_2[2]) {
      pvVar7 = (void *)*param_2;
    }
    else {
      uVar9 = param_2[2] * 2;
      if (uVar9 < uVar5) {
        uVar9 = uVar5;
      }
      param_2[2] = uVar9;
      pvVar7 = realloc((void *)*param_2,uVar9);
      *param_2 = pvVar7;
      if (pvVar7 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      iVar8 = param_2[1];
    }
    memcpy((void *)(iVar8 + (int)pvVar7),&DAT_00014af1,sVar6);
    iVar8 = sVar6 + param_2[1];
  }
  else if (uVar5 != 0) {
    if (1 < uVar5) {
      uVar9 = 1;
      do {
                    /* try { // try from 0003950d to 0003951d has its CatchHandler @ 00039658 */
        sVar6 = __strlen_chk(&DAT_00014f1f,3);
        if (sVar6 != 0) {
          iVar8 = param_2[1];
          uVar1 = iVar8 + sVar6;
          if (uVar1 < (uint)param_2[2]) {
            pvVar7 = (void *)*param_2;
          }
          else {
            __size = param_2[2] * 2;
            if (__size < uVar1) {
              __size = uVar1;
            }
            param_2[2] = __size;
            pvVar7 = realloc((void *)*param_2,__size);
            *param_2 = pvVar7;
            if (pvVar7 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
              FUN_0002c220();
            }
            iVar8 = param_2[1];
          }
          memcpy((void *)(iVar8 + (int)pvVar7),&DAT_00014f1f,sVar6);
          param_2[1] = param_2[1] + sVar6;
        }
        param_2[3] = uVar9;
        piVar4 = *(int **)(param_1 + 8);
                    /* try { // try from 00039592 to 000395b6 has its CatchHandler @ 00039658 */
        (**(code **)(*piVar4 + 0x10))(piVar4,param_2);
        if (*(char *)((int)piVar4 + 5) != '\x01') {
          (**(code **)(*piVar4 + 0x14))(piVar4,param_2);
        }
        uVar9 = uVar9 + 1;
      } while (uVar5 != uVar9);
    }
    goto LAB_00039633;
  }
  param_2[1] = iVar8;
LAB_00039633:
  param_2[4] = uVar3;
  param_2[3] = uVar2;
  return;
}


// ==== FUN_00039de0 @ 00039de0

void FUN_00039de0(void *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *in_ECX;
  int iVar4;
  int in_EDX;
  size_t __n;
  uint uVar5;
  
  __n = param_2 - (int)param_1;
  uVar5 = __n + 0xf & 0xfffffff0;
  piVar3 = *(int **)(in_EDX + 0x1198);
  iVar4 = piVar3[1];
  if (0xff7 < iVar4 + uVar5) {
    if (0xff8 < uVar5) {
      puVar1 = malloc(uVar5 | 8);
      if (puVar1 == (undefined4 *)0x0) goto LAB_00039ed4;
      *puVar1 = *piVar3;
      puVar1[1] = 0;
      *piVar3 = (int)puVar1;
      puVar1 = puVar1 + 2;
      goto joined_r0x00039eaa;
    }
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
LAB_00039ed4:
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar3;
    piVar2[1] = 0;
    *(int **)(in_EDX + 0x1198) = piVar2;
    iVar4 = 0;
    piVar3 = piVar2;
  }
  piVar3[1] = uVar5 + iVar4;
  puVar1 = (undefined4 *)((int)piVar3 + iVar4 + 8);
joined_r0x00039eaa:
  if (__n != 0) {
    memmove(puVar1,param_1,__n);
  }
  *in_ECX = puVar1;
  in_ECX[1] = (int)__n >> 2;
  return;
}


// ==== FUN_0003a180 @ 0003a180

int FUN_0003a180(void)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 *in_ECX;
  int in_GS_OFFSET;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  if ((char *)in_ECX[1] == (char *)*in_ECX) {
LAB_0003a1d2:
    iVar3 = FUN_000301b0();
    if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) goto LAB_0003a21d;
  }
  else {
    cVar2 = *(char *)*in_ECX;
    if (cVar2 == 'D') {
      iVar3 = FUN_00030ec0();
    }
    else {
      if (cVar2 != 'T') goto LAB_0003a1d2;
      iVar3 = FUN_00030b00();
    }
    if (iVar3 != 0) {
      FUN_0002f5d0();
    }
    if (*(int *)(in_GS_OFFSET + 0x14) != iVar1) {
LAB_0003a21d:
                    /* WARNING: Subroutine does not return */
      __stack_chk_fail();
    }
  }
  return iVar3;
}


// ==== FUN_0003a230 @ 0003a230

int FUN_0003a230(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *in_ECX;
  int iVar5;
  
  iVar2 = FUN_0003a4f0();
  if (iVar2 == 0) {
    iVar5 = 0;
  }
  else {
    iVar5 = iVar2;
    if (((char *)in_ECX[1] != (char *)*in_ECX) && (*(char *)*in_ECX == 'I')) {
      iVar5 = 0;
      iVar3 = FUN_00030570();
      if (iVar3 != 0) {
        piVar1 = (int *)in_ECX[0x466];
        iVar5 = piVar1[1];
        piVar4 = piVar1;
        if (iVar5 - 0xfe8U < 0xfffff008) {
          piVar4 = malloc(0x1000);
          if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar4 = (int)piVar1;
          piVar4[1] = 0;
          in_ECX[0x466] = piVar4;
          iVar5 = 0;
        }
        piVar4[1] = iVar5 + 0x10;
        *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010125;
        *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004bf20;
        *(int *)((int)piVar4 + iVar5 + 0x10) = iVar2;
        *(int *)((int)piVar4 + iVar5 + 0x14) = iVar3;
        iVar5 = (int)piVar4 + iVar5 + 8;
      }
    }
  }
  return iVar5;
}


// ==== FUN_0003a300 @ 0003a300

int FUN_0003a300(void)

{
  char *pcVar1;
  char *pcVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 *in_ECX;
  int iVar6;
  int *piVar7;
  
  pcVar2 = (char *)*in_ECX;
  pcVar1 = (char *)in_ECX[1];
  if ((pcVar1 != pcVar2) && (0xfffffff5 < (int)*pcVar2 - 0x3aU)) {
    iVar3 = FUN_0003a230();
    return iVar3;
  }
  if (1 < (uint)((int)pcVar1 - (int)pcVar2)) {
    if (*pcVar2 == 'o') {
      if (pcVar2[1] == 'n') {
        *in_ECX = pcVar2 + 2;
      }
    }
    else if ((*pcVar2 == 'd') && (pcVar2[1] == 'n')) {
      pcVar2 = pcVar2 + 2;
      *in_ECX = pcVar2;
      if ((pcVar1 == pcVar2) || ((int)*pcVar2 - 0x3aU < 0xfffffff6)) {
        iVar3 = FUN_0003a180();
      }
      else {
        iVar3 = FUN_0003a230();
      }
      if (iVar3 == 0) {
        return 0;
      }
      piVar7 = (int *)in_ECX[0x466];
      iVar6 = piVar7[1];
      if (0xfffff007 < iVar6 - 0xfe8U) {
LAB_0003a4b9:
        piVar7[1] = iVar6 + 0x10;
        *(undefined4 *)((int)piVar7 + iVar6 + 0xc) = 0x101012b;
        *(undefined ***)((int)piVar7 + iVar6 + 8) = &PTR_LAB_0004b9a8;
        *(int *)((int)piVar7 + iVar6 + 0x10) = iVar3;
        return (int)piVar7 + iVar6 + 8;
      }
      piVar4 = malloc(0x1000);
      if (piVar4 != (int *)0x0) {
        *piVar4 = (int)piVar7;
        piVar4[1] = 0;
        in_ECX[0x466] = piVar4;
        iVar6 = 0;
        piVar7 = piVar4;
        goto LAB_0003a4b9;
      }
      goto LAB_0003a4dd;
    }
  }
  iVar6 = FUN_0003a900();
  iVar3 = 0;
  if (iVar6 != 0) {
    if (((char *)in_ECX[1] == (char *)*in_ECX) || (*(char *)*in_ECX != 'I')) {
      iVar3 = iVar6;
    }
    else {
      iVar5 = FUN_00030570();
      iVar3 = 0;
      if (iVar5 != 0) {
        piVar7 = (int *)in_ECX[0x466];
        iVar3 = piVar7[1];
        piVar4 = piVar7;
        if (iVar3 - 0xfe8U < 0xfffff008) {
          piVar4 = malloc(0x1000);
          if (piVar4 == (int *)0x0) {
LAB_0003a4dd:
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar4 = (int)piVar7;
          piVar4[1] = 0;
          in_ECX[0x466] = piVar4;
          iVar3 = 0;
        }
        piVar4[1] = iVar3 + 0x10;
        *(undefined4 *)((int)piVar4 + iVar3 + 0xc) = 0x1010125;
        *(undefined ***)((int)piVar4 + iVar3 + 8) = &PTR_LAB_0004bf20;
        *(int *)((int)piVar4 + iVar3 + 0x10) = iVar6;
        *(int *)((int)piVar4 + iVar3 + 0x14) = iVar5;
        iVar3 = (int)piVar4 + iVar3 + 8;
      }
    }
  }
  return iVar3;
}


// ==== FUN_0003a4f0 @ 0003a4f0

int FUN_0003a4f0(void)

{
  int iVar1;
  char *pcVar2;
  uint uVar3;
  int *piVar4;
  undefined4 *in_ECX;
  uint uVar5;
  char *pcVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  char *local_20;
  
  pcVar2 = (char *)*in_ECX;
  iVar7 = (int)in_ECX[1] - (int)pcVar2;
  if (iVar7 == 0) {
    return 0;
  }
  if ((byte)(*pcVar2 - 0x3aU) < 0xf6) {
    return 0;
  }
  uVar3 = 0;
  uVar9 = 0;
  do {
    uVar8 = uVar9;
    uVar5 = uVar3;
    local_20 = pcVar2 + uVar5 + 1;
    *in_ECX = local_20;
    iVar1 = (int)pcVar2[uVar5] + uVar8 * 10;
    uVar9 = iVar1 - 0x30;
    if (local_20 == (char *)in_ECX[1]) break;
    uVar3 = uVar5 + 1;
  } while ((byte)(*local_20 - 0x30U) < 10);
  if (~uVar5 + iVar7 <= iVar1 - 0x31U) {
    return 0;
  }
  pcVar6 = pcVar2 + uVar5 + (int)pcVar2[uVar5] + uVar8 * 10 + -0x2f;
  *in_ECX = pcVar6;
  if ((((((uVar9 < 10) || (pcVar2[uVar5 + 1] != '_')) || (pcVar2[uVar5 + 2] != 'G')) ||
       ((pcVar2[uVar5 + 3] != 'L' || (pcVar2[uVar5 + 4] != 'O')))) ||
      ((pcVar2[uVar5 + 5] != 'B' || ((pcVar2[uVar5 + 6] != 'A' || (pcVar2[uVar5 + 7] != 'L')))))) ||
     ((pcVar2[uVar5 + 8] != '_' || ((pcVar2[uVar5 + 9] != '_' || (pcVar2[uVar5 + 10] != 'N')))))) {
    piVar10 = (int *)in_ECX[0x466];
    iVar7 = piVar10[1];
    if (0xfffff007 < iVar7 - 0xfe8U) goto LAB_0003a6e4;
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) goto LAB_0003a730;
  }
  else {
    piVar10 = (int *)in_ECX[0x466];
    iVar7 = piVar10[1];
    if (0xfffff007 < iVar7 - 0xfe8U) {
      pcVar6 = "";
      local_20 = "(anonymous namespace)";
      goto LAB_0003a6e4;
    }
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
LAB_0003a730:
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    pcVar6 = "";
    local_20 = "(anonymous namespace)";
  }
  *piVar4 = (int)piVar10;
  piVar4[1] = 0;
  in_ECX[0x466] = piVar4;
  iVar7 = 0;
  piVar10 = piVar4;
LAB_0003a6e4:
  piVar10[1] = iVar7 + 0x10;
  *(undefined4 *)((int)piVar10 + iVar7 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar10 + iVar7 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar10 + iVar7 + 0x10) = local_20;
  *(char **)((int)piVar10 + iVar7 + 0x14) = pcVar6;
  return (int)piVar10 + iVar7 + 8;
}


// ==== FUN_0003a740 @ 0003a740

int FUN_0003a740(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = in_EDX[1];
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b388;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_0003a900 @ 0003a900

int FUN_0003a900(void)

{
  int iVar1;
  char cVar2;
  undefined1 uVar3;
  undefined1 *puVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  undefined4 *in_ECX;
  uint uVar8;
  int iVar9;
  undefined1 *in_EDX;
  int in_GS_OFFSET;
  int local_2c;
  
  iVar1 = *(int *)(in_GS_OFFSET + 0x14);
  puVar4 = (undefined1 *)*in_ECX;
  local_2c = 0;
  uVar8 = (int)in_ECX[1] - (int)puVar4;
  if ((undefined1 *)in_ECX[1] == puVar4) goto switchD_0003a953_caseD_62;
  switch(*puVar4) {
  case 0x61:
    if (uVar8 < 2) break;
    switch(puVar4[1]) {
    case 0x4e:
      *in_ECX = puVar4 + 2;
      break;
    default:
      goto switchD_0003a953_caseD_62;
    case 0x53:
      *in_ECX = puVar4 + 2;
      goto LAB_0003b144;
    case 0x61:
      *in_ECX = puVar4 + 2;
      break;
    case 100:
    case 0x6e:
      *in_ECX = puVar4 + 2;
      piVar5 = (int *)in_ECX[0x466];
      iVar6 = piVar5[1];
      piVar7 = piVar5;
      if (iVar6 - 0xfe8U < 0xfffff008) {
        piVar7 = malloc(0x1000);
        if (piVar7 == (int *)0x0) goto LAB_0003b1ee;
        *piVar7 = (int)piVar5;
        piVar7[1] = 0;
        in_ECX[0x466] = piVar7;
        iVar6 = 0;
      }
      piVar7[1] = iVar6 + 0x10;
      local_2c = (int)piVar7 + iVar6 + 8;
      *(undefined4 *)((int)piVar7 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar7 + iVar6 + 8) = &PTR_LAB_0004b388;
      *(char **)((int)piVar7 + iVar6 + 0x10) = "operator&";
      *(char **)((int)piVar7 + iVar6 + 0x14) = "";
      goto switchD_0003a953_caseD_62;
    }
LAB_0003b19a:
    iVar6 = FUN_0003b2c0();
LAB_0003b1a1:
    if (*(int *)(in_GS_OFFSET + 0x14) == iVar1) {
      return iVar6;
    }
    goto LAB_0003b1f3;
  case 99:
    if (uVar8 < 2) break;
    switch(puVar4[1]) {
    case 0x6c:
      *in_ECX = puVar4 + 2;
      goto LAB_0003b19a;
    case 0x6d:
      *in_ECX = puVar4 + 2;
      goto LAB_0003b144;
    case 0x6f:
      *in_ECX = puVar4 + 2;
LAB_0003b144:
      iVar6 = FUN_0003b370();
      goto LAB_0003b1a1;
    case 0x76:
      *in_ECX = puVar4 + 2;
      uVar3 = *(undefined1 *)(in_ECX + 0x61);
      cVar2 = *(char *)((int)in_ECX + 0x185);
      *(undefined1 *)(in_ECX + 0x61) = 0;
      *(bool *)((int)in_ECX + 0x185) = in_EDX != (undefined1 *)0x0 || cVar2 != '\0';
                    /* try { // try from 0003b01d to 0003b023 has its CatchHandler @ 0003b1f8 */
      iVar6 = FUN_0002d6e0();
      if (iVar6 == 0) {
        local_2c = 0;
      }
      else {
        if (in_EDX != (undefined1 *)0x0) {
          *in_EDX = 1;
        }
        local_2c = FUN_0003b420();
      }
      *(char *)((int)in_ECX + 0x185) = cVar2;
      *(undefined1 *)(in_ECX + 0x61) = uVar3;
    }
    break;
  case 100:
    if (uVar8 < 2) break;
    switch(puVar4[1]) {
    case 0x56:
      *in_ECX = puVar4 + 2;
      goto LAB_0003b19a;
    default:
      goto switchD_0003a953_caseD_62;
    case 0x61:
      *in_ECX = puVar4 + 2;
      iVar6 = FUN_0003b4b0();
      break;
    case 0x65:
switchD_0003ada0_caseD_6c:
      *in_ECX = puVar4 + 2;
      goto LAB_0003b144;
    case 0x6c:
      *in_ECX = puVar4 + 2;
      iVar6 = FUN_00037d70();
      break;
    case 0x76:
      *in_ECX = puVar4 + 2;
      goto LAB_0003b144;
    }
    goto LAB_0003b1a1;
  case 0x65:
    if (1 < uVar8) {
      cVar2 = puVar4[1];
      if (cVar2 == 'O') {
        *in_ECX = puVar4 + 2;
      }
      else {
        if (cVar2 != 'q') {
          if (cVar2 == 'o') {
            *in_ECX = puVar4 + 2;
            goto LAB_0003b144;
          }
          break;
        }
        *in_ECX = puVar4 + 2;
      }
      goto LAB_0003b19a;
    }
    break;
  case 0x67:
    if (1 < uVar8) {
      if (puVar4[1] == 't') {
        *in_ECX = puVar4 + 2;
        piVar5 = (int *)in_ECX[0x466];
        iVar6 = piVar5[1];
        piVar7 = piVar5;
        if (iVar6 - 0xfe8U < 0xfffff008) {
          piVar7 = malloc(0x1000);
          if (piVar7 == (int *)0x0) {
LAB_0003b1ee:
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar7 = (int)piVar5;
          piVar7[1] = 0;
          in_ECX[0x466] = piVar7;
          iVar6 = 0;
        }
        piVar7[1] = iVar6 + 0x10;
        local_2c = (int)piVar7 + iVar6 + 8;
        *(undefined4 *)((int)piVar7 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar7 + iVar6 + 8) = &PTR_LAB_0004b388;
        *(char **)((int)piVar7 + iVar6 + 0x10) = "operator>";
        *(char **)((int)piVar7 + iVar6 + 0x14) = "";
      }
      else if (puVar4[1] == 'e') {
        *in_ECX = puVar4 + 2;
        piVar5 = (int *)in_ECX[0x466];
        iVar6 = piVar5[1];
        piVar7 = piVar5;
        if (iVar6 - 0xfe8U < 0xfffff008) {
          piVar7 = malloc(0x1000);
          if (piVar7 == (int *)0x0) goto LAB_0003b1ee;
          *piVar7 = (int)piVar5;
          piVar7[1] = 0;
          in_ECX[0x466] = piVar7;
          iVar6 = 0;
        }
        piVar7[1] = iVar6 + 0x10;
        local_2c = (int)piVar7 + iVar6 + 8;
        *(undefined4 *)((int)piVar7 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar7 + iVar6 + 8) = &PTR_LAB_0004b388;
        *(char **)((int)piVar7 + iVar6 + 0x10) = "operator>=";
        *(char **)((int)piVar7 + iVar6 + 0x14) = "";
      }
    }
    break;
  case 0x69:
    if ((1 < uVar8) && (puVar4[1] == 'x')) {
      *in_ECX = puVar4 + 2;
      piVar5 = (int *)in_ECX[0x466];
      iVar6 = piVar5[1];
      piVar7 = piVar5;
      if (iVar6 - 0xfe8U < 0xfffff008) {
        piVar7 = malloc(0x1000);
        if (piVar7 == (int *)0x0) goto LAB_0003b1ee;
        *piVar7 = (int)piVar5;
        piVar7[1] = 0;
        in_ECX[0x466] = piVar7;
        iVar6 = 0;
      }
      piVar7[1] = iVar6 + 0x10;
      local_2c = (int)piVar7 + iVar6 + 8;
      *(undefined4 *)((int)piVar7 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar7 + iVar6 + 8) = &PTR_LAB_0004b388;
      *(char **)((int)piVar7 + iVar6 + 0x10) = "operator[]";
      *(char **)((int)piVar7 + iVar6 + 0x14) = "";
    }
    break;
  case 0x6c:
    if (uVar8 < 2) break;
    switch(puVar4[1]) {
    case 0x53:
      *in_ECX = puVar4 + 2;
LAB_0003b179:
      iVar6 = FUN_0003b5f0();
      goto LAB_0003b1a1;
    default:
      goto switchD_0003a953_caseD_62;
    case 0x65:
      *in_ECX = puVar4 + 2;
      break;
    case 0x69:
      *in_ECX = puVar4 + 2;
      iVar6 = FUN_0003a4f0();
      if (iVar6 == 0) {
        local_2c = 0;
      }
      else {
        local_2c = FUN_0003b560();
      }
      goto switchD_0003a953_caseD_62;
    case 0x73:
      *in_ECX = puVar4 + 2;
      break;
    case 0x74:
      *in_ECX = puVar4 + 2;
      goto LAB_0003b144;
    }
    goto LAB_0003b19a;
  case 0x6d:
    if (1 < uVar8) {
      switch(puVar4[1]) {
      case 0x49:
        *in_ECX = puVar4 + 2;
        break;
      default:
        goto switchD_0003a953_caseD_62;
      case 0x4c:
        *in_ECX = puVar4 + 2;
        break;
      case 0x69:
switchD_0003aea5_caseD_67:
        *in_ECX = puVar4 + 2;
        goto LAB_0003b144;
      case 0x6c:
        goto switchD_0003ada0_caseD_6c;
      case 0x6d:
        *in_ECX = puVar4 + 2;
      }
      goto LAB_0003b19a;
    }
    break;
  case 0x6e:
    if (1 < uVar8) {
      switch(puVar4[1]) {
      case 0x61:
        *in_ECX = puVar4 + 2;
        iVar6 = FUN_0003b6a0();
        break;
      default:
        goto switchD_0003a953_caseD_62;
      case 0x65:
        *in_ECX = puVar4 + 2;
        goto LAB_0003b19a;
      case 0x67:
        goto switchD_0003aea5_caseD_67;
      case 0x74:
        *in_ECX = puVar4 + 2;
        goto LAB_0003b144;
      case 0x77:
        *in_ECX = puVar4 + 2;
        iVar6 = FUN_0003b750();
      }
      goto LAB_0003b1a1;
    }
    break;
  case 0x6f:
    if (1 < uVar8) {
      cVar2 = puVar4[1];
      if (cVar2 == 'R') {
        *in_ECX = puVar4 + 2;
      }
      else {
        if (cVar2 == 'r') {
          *in_ECX = puVar4 + 2;
          goto LAB_0003b144;
        }
        if (cVar2 != 'o') break;
        *in_ECX = puVar4 + 2;
      }
      goto LAB_0003b19a;
    }
    break;
  case 0x70:
    if (1 < uVar8) {
      switch(puVar4[1]) {
      case 0x4c:
        *in_ECX = puVar4 + 2;
        break;
      default:
        goto switchD_0003a953_caseD_62;
      case 0x6c:
      case 0x73:
        *in_ECX = puVar4 + 2;
        goto LAB_0003b144;
      case 0x6d:
        *in_ECX = puVar4 + 2;
        goto LAB_0003b179;
      case 0x70:
        *in_ECX = puVar4 + 2;
        break;
      case 0x74:
        *in_ECX = puVar4 + 2;
      }
      goto LAB_0003b19a;
    }
    break;
  case 0x71:
    if ((1 < uVar8) && (puVar4[1] == 'u')) {
      *in_ECX = puVar4 + 2;
      piVar5 = (int *)in_ECX[0x466];
      iVar6 = piVar5[1];
      piVar7 = piVar5;
      if (iVar6 - 0xfe8U < 0xfffff008) {
        piVar7 = malloc(0x1000);
        if (piVar7 == (int *)0x0) goto LAB_0003b1ee;
        *piVar7 = (int)piVar5;
        piVar7[1] = 0;
        in_ECX[0x466] = piVar7;
        iVar6 = 0;
      }
      piVar7[1] = iVar6 + 0x10;
      local_2c = (int)piVar7 + iVar6 + 8;
      *(undefined4 *)((int)piVar7 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar7 + iVar6 + 8) = &PTR_LAB_0004b388;
      *(char **)((int)piVar7 + iVar6 + 0x10) = "operator?";
      *(char **)((int)piVar7 + iVar6 + 0x14) = "";
    }
    break;
  case 0x72:
    if (1 < uVar8) {
      switch(puVar4[1]) {
      case 0x4d:
        *in_ECX = puVar4 + 2;
        break;
      default:
        goto switchD_0003a953_caseD_62;
      case 0x53:
        *in_ECX = puVar4 + 2;
        goto LAB_0003b179;
      case 0x6d:
        *in_ECX = puVar4 + 2;
        goto LAB_0003b144;
      case 0x73:
        *in_ECX = puVar4 + 2;
      }
      goto LAB_0003b19a;
    }
    break;
  case 0x73:
    if ((1 < uVar8) && (puVar4[1] == 's')) {
      *in_ECX = puVar4 + 2;
      piVar5 = (int *)in_ECX[0x466];
      iVar6 = piVar5[1];
      piVar7 = piVar5;
      if (iVar6 - 0xfe8U < 0xfffff008) {
        piVar7 = malloc(0x1000);
        if (piVar7 == (int *)0x0) goto LAB_0003b1ee;
        *piVar7 = (int)piVar5;
        piVar7[1] = 0;
        in_ECX[0x466] = piVar7;
        iVar6 = 0;
      }
      piVar7[1] = iVar6 + 0x10;
      local_2c = (int)piVar7 + iVar6 + 8;
      *(undefined4 *)((int)piVar7 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar7 + iVar6 + 8) = &PTR_LAB_0004b388;
      *(char **)((int)piVar7 + iVar6 + 0x10) = "operator<=>";
      *(char **)((int)piVar7 + iVar6 + 0x14) = "";
    }
    break;
  case 0x76:
    if ((1 < uVar8) && (0xfffffff5 < (int)(char)puVar4[1] - 0x3aU)) {
      *in_ECX = puVar4 + 2;
      iVar6 = FUN_0003a4f0();
      if (iVar6 != 0) {
        piVar5 = (int *)in_ECX[0x466];
        iVar9 = piVar5[1];
        piVar7 = piVar5;
        if (iVar9 - 0xfe8U < 0xfffff008) {
          piVar7 = malloc(0x1000);
          if (piVar7 == (int *)0x0) goto LAB_0003b1ee;
          *piVar7 = (int)piVar5;
          piVar7[1] = 0;
          in_ECX[0x466] = piVar7;
          iVar9 = 0;
        }
        piVar7[1] = iVar9 + 0x10;
        *(undefined4 *)((int)piVar7 + iVar9 + 0xc) = 0x1010104;
        *(undefined ***)((int)piVar7 + iVar9 + 8) = &PTR_LAB_0004b9e0;
        *(int *)((int)piVar7 + iVar9 + 0x10) = iVar6;
        local_2c = (int)piVar7 + iVar9 + 8;
      }
    }
  }
switchD_0003a953_caseD_62:
  if (*(int *)(in_GS_OFFSET + 0x14) == iVar1) {
    return local_2c;
  }
LAB_0003b1f3:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== FUN_0003b2c0 @ 0003b2c0

int FUN_0003b2c0(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_0003b370 @ 0003b370

int FUN_0003b370(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_0003b420 @ 0003b420

int FUN_0003b420(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010104;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004b9e0;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0003b4b0 @ 0003b4b0

int FUN_0003b4b0(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_0003b560 @ 0003b560

int FUN_0003b560(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010113;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004ba18;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0003b5f0 @ 0003b5f0

int FUN_0003b5f0(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_0003b6a0 @ 0003b6a0

int FUN_0003b6a0(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_0003b750 @ 0003b750

int FUN_0003b750(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_0003d330 @ 0003d330

void FUN_0003d330(void)

{
  char cVar1;
  char *in_ECX;
  int iVar2;
  char *pcVar3;
  char *in_EDX;
  
  if (in_ECX != in_EDX) {
    iVar2 = (int)*in_ECX;
    if (iVar2 == 0x5f) {
      if (((in_ECX + 1 != in_EDX) && (cVar1 = in_ECX[1], (int)cVar1 - 0x3aU < 0xfffffff6)) &&
         (cVar1 == '_')) {
        pcVar3 = in_ECX + 2;
        do {
          if (pcVar3 == in_EDX) {
            return;
          }
          cVar1 = *pcVar3;
          pcVar3 = pcVar3 + 1;
        } while (0xfffffff5 < (int)cVar1 - 0x3aU);
      }
    }
    else {
      while ((0xfffffff5 < iVar2 - 0x3aU && (in_ECX = in_ECX + 1, in_ECX != in_EDX))) {
        iVar2 = (int)*in_ECX;
      }
    }
  }
  return;
}


// ==== FUN_0003d3c0 @ 0003d3c0

int FUN_0003d3c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010118;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004be40;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_0003e2c0 @ 0003e2c0

void FUN_0003e2c0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  int *piVar2;
  void *pvVar3;
  uint uVar4;
  void *pvVar5;
  int iVar6;
  size_t __n;
  
  piVar2 = *(int **)(param_1 + 8);
  (**(code **)(*piVar2 + 0x10))(piVar2,param_2);
  if (*(char *)((int)piVar2 + 5) != '\x01') {
    (**(code **)(*piVar2 + 0x14))(piVar2,param_2);
  }
  iVar6 = param_2[1];
  uVar1 = iVar6 + 2;
  if (uVar1 < (uint)param_2[2]) {
    pvVar5 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] * 2;
    if (uVar4 < uVar1) {
      uVar4 = uVar1;
    }
    param_2[2] = uVar4;
    pvVar5 = realloc((void *)*param_2,uVar4);
    *param_2 = pvVar5;
    if (pvVar5 == (void *)0x0) goto LAB_0003e3e1;
    iVar6 = param_2[1];
  }
  *(undefined2 *)((int)pvVar5 + iVar6) = 0x2820;
  iVar6 = param_2[1] + 2;
  param_2[1] = iVar6;
  pvVar5 = *(void **)(param_1 + 0xc);
  __n = *(int *)(param_1 + 0x10) - (int)pvVar5;
  if (__n != 0) {
    uVar1 = iVar6 + __n;
    if (uVar1 < (uint)param_2[2]) {
      pvVar3 = (void *)*param_2;
    }
    else {
      uVar4 = param_2[2] * 2;
      if (uVar4 < uVar1) {
        uVar4 = uVar1;
      }
      param_2[2] = uVar4;
      pvVar3 = realloc((void *)*param_2,uVar4);
      *param_2 = pvVar3;
      if (pvVar3 == (void *)0x0) goto LAB_0003e3e1;
      iVar6 = param_2[1];
    }
    memmove((void *)(iVar6 + (int)pvVar3),pvVar5,__n);
    iVar6 = __n + param_2[1];
    param_2[1] = iVar6;
  }
  uVar1 = iVar6 + 1;
  if (uVar1 < (uint)param_2[2]) {
    pvVar5 = (void *)*param_2;
  }
  else {
    uVar4 = param_2[2] * 2;
    if (uVar4 < uVar1) {
      uVar4 = uVar1;
    }
    param_2[2] = uVar4;
    pvVar5 = realloc((void *)*param_2,uVar4);
    *param_2 = pvVar5;
    if (pvVar5 == (void *)0x0) {
LAB_0003e3e1:
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    iVar6 = param_2[1];
  }
  *(undefined1 *)((int)pvVar5 + iVar6) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}


// ==== FUN_0003e420 @ 0003e420

int FUN_0003e420(void)

{
  char *pcVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  char *pcVar6;
  int *piVar7;
  int iVar8;
  int *in_ECX;
  int iVar9;
  int iVar10;
  uint uVar11;
  char *pcVar12;
  int in_GS_OFFSET;
  int local_34;
  undefined1 local_30;
  int local_20;
  undefined4 local_1c;
  
  iVar2 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar6 = (char *)*in_ECX;
  pcVar12 = (char *)in_ECX[1];
  uVar11 = 0;
  if ((pcVar6 != pcVar12) && (*pcVar6 == 'r')) {
    pcVar6 = pcVar6 + 1;
    *in_ECX = (int)pcVar6;
    uVar11 = 4;
  }
  if (pcVar6 == pcVar12) {
LAB_0003e482:
    pcVar6 = pcVar12;
  }
  else {
    if (*pcVar6 == 'V') {
      pcVar6 = pcVar6 + 1;
      *in_ECX = (int)pcVar6;
      uVar11 = uVar11 | 2;
    }
    if (pcVar6 == pcVar12) goto LAB_0003e482;
    if (*pcVar6 == 'K') {
      *in_ECX = (int)(pcVar6 + 1);
      uVar11 = uVar11 | 1;
      pcVar6 = pcVar6 + 1;
    }
  }
  local_34 = 0;
  if ((1 < (uint)((int)pcVar12 - (int)pcVar6)) && (*pcVar6 == 'D')) {
    cVar3 = pcVar6[1];
    if (cVar3 == 'O') {
      *in_ECX = (int)(pcVar6 + 2);
      iVar9 = FUN_00031980();
      iVar8 = 0;
      if (((iVar9 == 0) || (pcVar12 = (char *)*in_ECX, pcVar12 == (char *)in_ECX[1])) ||
         (*pcVar12 != 'E')) goto LAB_0003e873;
      *in_ECX = (int)(pcVar12 + 1);
      piVar4 = (int *)in_ECX[0x466];
      local_34 = piVar4[1];
      piVar7 = piVar4;
      if (local_34 - 0xfe8U < 0xfffff008) {
        piVar7 = malloc(0x1000);
        if (piVar7 == (int *)0x0) goto LAB_0003e888;
        *piVar7 = (int)piVar4;
        piVar7[1] = 0;
        in_ECX[0x466] = (int)piVar7;
        local_34 = 0;
      }
      piVar7[1] = local_34 + 0x10;
      *(undefined4 *)((int)piVar7 + local_34 + 0xc) = 0x1010110;
      *(undefined ***)((int)piVar7 + local_34 + 8) = &PTR_LAB_0004c070;
      *(int *)((int)piVar7 + local_34 + 0x10) = iVar9;
      local_34 = (int)piVar7 + local_34;
    }
    else {
      if (cVar3 != 'w') {
        if (cVar3 == 'o') {
          *in_ECX = (int)(pcVar6 + 2);
          piVar4 = (int *)in_ECX[0x466];
          iVar9 = piVar4[1];
          piVar7 = piVar4;
          if (iVar9 - 0xfe8U < 0xfffff008) {
            piVar7 = malloc(0x1000);
            if (piVar7 == (int *)0x0) goto LAB_0003e888;
            *piVar7 = (int)piVar4;
            piVar7[1] = 0;
            in_ECX[0x466] = (int)piVar7;
            iVar9 = 0;
          }
          piVar7[1] = iVar9 + 0x10;
          local_34 = (int)piVar7 + iVar9 + 8;
          *(undefined4 *)((int)piVar7 + iVar9 + 0xc) = 0x1010107;
          *(undefined ***)((int)piVar7 + iVar9 + 8) = &PTR_LAB_0004b388;
          *(char **)((int)piVar7 + iVar9 + 0x10) = "noexcept";
          *(char **)((int)piVar7 + iVar9 + 0x14) = "";
        }
        goto LAB_0003e6d1;
      }
      pcVar6 = pcVar6 + 2;
      *in_ECX = (int)pcVar6;
      iVar9 = in_ECX[3];
      iVar8 = in_ECX[2];
      if (pcVar6 == pcVar12) goto LAB_0003e605;
      while (*pcVar6 != 'E') {
LAB_0003e605:
        do {
          local_20 = FUN_0002d6e0();
          if (local_20 == 0) goto LAB_0003e79c;
          FUN_0002f5d0();
          pcVar6 = (char *)*in_ECX;
        } while (pcVar6 == (char *)in_ECX[1]);
      }
      *in_ECX = (int)(pcVar6 + 1);
      iVar9 = (iVar9 - iVar8 >> 2) * 4;
      FUN_00039de0(in_ECX[2] + iVar9,in_ECX[3]);
      in_ECX[3] = iVar9 + in_ECX[2];
      piVar4 = (int *)in_ECX[0x466];
      local_34 = piVar4[1];
      piVar7 = piVar4;
      if (local_34 - 0xfe8U < 0xfffff008) {
        piVar7 = malloc(0x1000);
        if (piVar7 == (int *)0x0) {
LAB_0003e888:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar7 = (int)piVar4;
        piVar7[1] = 0;
        in_ECX[0x466] = (int)piVar7;
        local_34 = 0;
      }
      piVar7[1] = local_34 + 0x10;
      *(undefined4 *)((int)piVar7 + local_34 + 0xc) = 0x1010111;
      *(undefined ***)((int)piVar7 + local_34 + 8) = &PTR_LAB_0004c0a8;
      *(undefined4 *)((int)piVar7 + local_34 + 0x14) = local_1c;
      *(int *)((int)piVar7 + local_34 + 0x10) = local_20;
      local_34 = (int)piVar7 + local_34;
    }
    local_34 = local_34 + 8;
  }
LAB_0003e6d1:
  pcVar12 = (char *)*in_ECX;
  pcVar6 = (char *)in_ECX[1];
  if (((1 < (uint)((int)pcVar6 - (int)pcVar12)) && (*pcVar12 == 'D')) && (pcVar12[1] == 'x')) {
    pcVar12 = pcVar12 + 2;
    *in_ECX = (int)pcVar12;
  }
  iVar8 = 0;
  if ((pcVar12 != pcVar6) && (*pcVar12 == 'F')) {
    pcVar1 = pcVar12 + 1;
    *in_ECX = (int)pcVar1;
    if ((pcVar1 != pcVar6) && (*pcVar1 == 'Y')) {
      *in_ECX = (int)(pcVar12 + 2);
    }
    iVar9 = FUN_0002d6e0();
    if (iVar9 != 0) {
      iVar8 = in_ECX[3];
      iVar5 = in_ECX[2];
      do {
        while( true ) {
          pcVar12 = (char *)*in_ECX;
          if (pcVar12 == (char *)in_ECX[1]) break;
          if (*pcVar12 != 'v') {
            if (*pcVar12 != 'E') break;
            iVar10 = 1;
            local_30 = 0;
LAB_0003e7c1:
            *in_ECX = (int)(pcVar12 + iVar10);
            iVar8 = (iVar8 - iVar5 >> 2) * 4;
            FUN_00039de0(in_ECX[2] + iVar8,in_ECX[3]);
            in_ECX[3] = iVar8 + in_ECX[2];
            piVar4 = (int *)in_ECX[0x466];
            iVar8 = piVar4[1];
            piVar7 = piVar4;
            if (iVar8 - 0xfd8U < 0xfffff008) {
              piVar7 = malloc(0x1000);
              if (piVar7 == (int *)0x0) goto LAB_0003e888;
              *piVar7 = (int)piVar4;
              piVar7[1] = 0;
              in_ECX[0x466] = (int)piVar7;
              iVar8 = 0;
            }
            piVar7[1] = iVar8 + 0x20;
            *(undefined4 *)((int)piVar7 + iVar8 + 0xc) = 0x1000f;
            *(undefined ***)((int)piVar7 + iVar8 + 8) = &PTR_LAB_0004c0e0;
            *(int *)((int)piVar7 + iVar8 + 0x10) = iVar9;
            *(undefined4 *)((int)piVar7 + iVar8 + 0x18) = local_1c;
            *(int *)((int)piVar7 + iVar8 + 0x14) = local_20;
            *(uint *)((int)piVar7 + iVar8 + 0x1c) = uVar11;
            *(undefined1 *)((int)piVar7 + iVar8 + 0x20) = local_30;
            *(int *)((int)piVar7 + iVar8 + 0x24) = local_34;
            iVar8 = (int)piVar7 + iVar8 + 8;
            goto LAB_0003e873;
          }
          *in_ECX = (int)(pcVar12 + 1);
        }
        if (1 < (uint)(in_ECX[1] - (int)pcVar12)) {
          if (*pcVar12 == 'O') {
            if (pcVar12[1] == 'E') {
              local_30 = 2;
              goto LAB_0003e7b8;
            }
          }
          else if ((*pcVar12 == 'R') && (pcVar12[1] == 'E')) {
            local_30 = 1;
LAB_0003e7b8:
            iVar10 = 2;
            goto LAB_0003e7c1;
          }
        }
        local_20 = FUN_0002d6e0();
        if (local_20 == 0) break;
        FUN_0002f5d0();
      } while( true );
    }
LAB_0003e79c:
    iVar8 = 0;
  }
LAB_0003e873:
  if (*(int *)(in_GS_OFFSET + 0x14) != iVar2) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar8;
}


// ==== FUN_0003e8a0 @ 0003e8a0

int FUN_0003e8a0(void)

{
  undefined1 uVar1;
  char cVar2;
  char cVar3;
  undefined2 uVar4;
  char *pcVar5;
  int *piVar6;
  int iVar7;
  char *pcVar8;
  int iVar9;
  int *piVar10;
  int *in_ECX;
  uint uVar11;
  int iVar12;
  char *pcVar13;
  char *pcVar14;
  char *pcVar15;
  uint uVar16;
  char *pcVar17;
  int iVar18;
  char *local_24;
  
  pcVar17 = (char *)*in_ECX;
  pcVar5 = (char *)in_ECX[1];
  uVar11 = 0;
  if (pcVar17 != pcVar5) {
    if (*pcVar17 == 'r') {
      pcVar17 = pcVar17 + 1;
      *in_ECX = (int)pcVar17;
      uVar11 = 4;
    }
    else if (*pcVar17 == 'U') {
      pcVar13 = pcVar17 + 1;
      *in_ECX = (int)pcVar13;
      if (pcVar5 == pcVar13) {
        return 0;
      }
      if ((byte)(*pcVar13 - 0x3aU) < 0xf6) {
        return 0;
      }
      iVar9 = 0;
      uVar11 = 0;
      do {
        uVar16 = uVar11;
        iVar12 = iVar9;
        pcVar13 = pcVar17 + iVar12 + 2;
        *in_ECX = (int)pcVar13;
        iVar7 = (int)pcVar17[iVar12 + 1];
        uVar11 = (iVar7 + uVar16 * 10) - 0x30;
        if (pcVar13 == pcVar5) {
          pcVar13 = pcVar5;
          goto LAB_0003ea3c;
        }
        iVar9 = iVar12 + 1;
      } while ((byte)(*pcVar13 - 0x30U) < 10);
      pcVar13 = pcVar17 + iVar12 + 2;
LAB_0003ea3c:
      if ((uint)((int)pcVar5 - (int)pcVar13) < uVar11) {
        return 0;
      }
      pcVar8 = pcVar17 + iVar12 + iVar7 + uVar16 * 10 + -0x2e;
      *in_ECX = (int)pcVar8;
      if (uVar11 == 0) {
        return 0;
      }
      if ((((((uVar11 < 9) || (*pcVar13 != 'o')) || (pcVar13[1] != 'b')) ||
           ((pcVar13[2] != 'j' || (pcVar13[3] != 'c')))) ||
          ((pcVar13[4] != 'p' || ((pcVar13[5] != 'r' || (pcVar13[6] != 'o')))))) ||
         ((pcVar13[7] != 't' || (pcVar13[8] != 'o')))) {
        iVar9 = FUN_0003e8a0();
        if (iVar9 == 0) {
          return 0;
        }
        piVar6 = (int *)in_ECX[0x466];
        iVar7 = piVar6[1];
        piVar10 = piVar6;
        if (iVar7 - 0xfd8U < 0xfffff008) {
          piVar10 = malloc(0x1000);
          if (piVar10 == (int *)0x0) {
LAB_0003ecfa:
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar10 = (int)piVar6;
          piVar10[1] = 0;
          in_ECX[0x466] = (int)piVar10;
          iVar7 = 0;
        }
        piVar10[1] = iVar7 + 0x20;
        *(undefined4 *)((int)piVar10 + iVar7 + 0xc) = 0x1010102;
        *(undefined ***)((int)piVar10 + iVar7 + 8) = &PTR_LAB_0004c150;
        *(int *)((int)piVar10 + iVar7 + 0x10) = iVar9;
        *(char **)((int)piVar10 + iVar7 + 0x14) = pcVar13;
LAB_0003ebf9:
        *(char **)((int)piVar10 + iVar7 + 0x18) = pcVar8;
        return (int)piVar10 + iVar7 + 8;
      }
      local_24 = pcVar13 + 9;
      *in_ECX = (int)local_24;
      in_ECX[1] = (int)pcVar8;
      if ((pcVar8 != local_24) && (0xf5 < (byte)(*local_24 - 0x3aU))) {
        pcVar14 = pcVar13 + 10;
        pcVar15 = (char *)0x0;
        iVar9 = 0x26 - (int)pcVar13;
        do {
          iVar18 = iVar9;
          pcVar13 = pcVar15;
          *in_ECX = (int)pcVar14;
          cVar2 = pcVar14[-1];
          pcVar15 = (char *)((int)cVar2 + (int)pcVar13 * 10 + -0x30);
          if (pcVar8 == pcVar14) {
            local_24 = pcVar8;
            break;
          }
          cVar3 = *pcVar14;
          local_24 = local_24 + 1;
          pcVar14 = pcVar14 + 1;
          iVar9 = iVar18 + -1;
        } while ((byte)(cVar3 - 0x30U) < 10);
        if (pcVar15 <= pcVar17 + iVar12 + (uVar16 * 10 - (int)local_24) + iVar7 + -0x2e) {
          in_ECX[1] = (int)pcVar5;
          *in_ECX = (int)pcVar8;
          if (pcVar15 == (char *)0x0) {
            return 0;
          }
          iVar9 = FUN_0003e8a0();
          if (iVar9 == 0) {
            return 0;
          }
          piVar6 = (int *)in_ECX[0x466];
          iVar7 = piVar6[1];
          piVar10 = piVar6;
          if (iVar7 - 0xfd8U < 0xfffff008) {
            piVar10 = malloc(0x1000);
            if (piVar10 == (int *)0x0) goto LAB_0003ecfa;
            *piVar10 = (int)piVar6;
            piVar10[1] = 0;
            in_ECX[0x466] = (int)piVar10;
            iVar7 = 0;
          }
          pcVar8 = (char *)(((int)cVar2 + (int)pcVar13 * 10) - iVar18);
          piVar10[1] = iVar7 + 0x20;
          *(undefined4 *)((int)piVar10 + iVar7 + 0xc) = 0x101010a;
          *(undefined ***)((int)piVar10 + iVar7 + 8) = &PTR_LAB_0004c118;
          *(int *)((int)piVar10 + iVar7 + 0x10) = iVar9;
          *(char **)((int)piVar10 + iVar7 + 0x14) = local_24;
          goto LAB_0003ebf9;
        }
      }
      in_ECX[1] = (int)pcVar5;
      *in_ECX = (int)pcVar8;
      return 0;
    }
  }
  if (pcVar17 != pcVar5) {
    if (*pcVar17 == 'V') {
      pcVar17 = pcVar17 + 1;
      *in_ECX = (int)pcVar17;
      uVar11 = uVar11 | 2;
    }
    if ((pcVar17 != pcVar5) && (*pcVar17 == 'K')) {
      *in_ECX = (int)(pcVar17 + 1);
      uVar11 = uVar11 | 1;
    }
  }
  iVar9 = FUN_0002d6e0();
  if (iVar9 == 0) {
    return 0;
  }
  if (uVar11 == 0) {
    return iVar9;
  }
  piVar6 = (int *)in_ECX[0x466];
  iVar7 = piVar6[1];
  piVar10 = piVar6;
  if (iVar7 - 0xfe8U < 0xfffff008) {
    piVar10 = malloc(0x1000);
    if (piVar10 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar10 = (int)piVar6;
    piVar10[1] = 0;
    in_ECX[0x466] = (int)piVar10;
    iVar7 = 0;
  }
  piVar10[1] = iVar7 + 0x10;
  uVar1 = *(undefined1 *)(iVar9 + 7);
  uVar4 = *(undefined2 *)(iVar9 + 5);
  *(undefined1 *)((int)piVar10 + iVar7 + 0xc) = 3;
  *(undefined2 *)((int)piVar10 + iVar7 + 0xd) = uVar4;
  *(undefined1 *)((int)piVar10 + iVar7 + 0xf) = uVar1;
  *(undefined ***)((int)piVar10 + iVar7 + 8) = &PTR_LAB_0004c188;
  *(uint *)((int)piVar10 + iVar7 + 0x10) = uVar11;
  *(int *)((int)piVar10 + iVar7 + 0x14) = iVar9;
  return (int)piVar10 + iVar7 + 8;
}


// ==== FUN_0003ed10 @ 0003ed10

int FUN_0003ed10(void)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int in_ECX;
  char *in_EDX;
  int iVar4;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar2 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar2 = malloc(0x1000);
    if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar2 = (int)piVar1;
    piVar2[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar2;
    iVar4 = 0;
  }
  piVar2[1] = iVar4 + 0x10;
  sVar3 = strlen(in_EDX);
  *(undefined4 *)((int)piVar2 + iVar4 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar2 + iVar4 + 8) = &PTR_LAB_0004b388;
  *(char **)((int)piVar2 + iVar4 + 0x10) = in_EDX;
  *(char **)((int)piVar2 + iVar4 + 0x14) = in_EDX + sVar3;
  return (int)piVar2 + iVar4 + 8;
}


// ==== FUN_0003edc0 @ 0003edc0

int FUN_0003edc0(void)

{
  byte *pbVar1;
  char *pcVar2;
  byte bVar3;
  char *pcVar4;
  byte *pbVar5;
  byte *pbVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  int iVar10;
  int *in_ECX;
  int iVar11;
  byte *pbVar12;
  int in_GS_OFFSET;
  int *local_2c;
  int local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  pcVar4 = (char *)*in_ECX;
  pbVar12 = (byte *)in_ECX[1];
  iVar11 = 0;
  if ((((uint)((int)pbVar12 - (int)pcVar4) < 2) || (*pcVar4 != 'D')) || (pcVar4[1] != 'v'))
  goto LAB_0003f091;
  pbVar1 = (byte *)(pcVar4 + 2);
  *in_ECX = (int)pbVar1;
  if ((pbVar12 == pbVar1) || (bVar3 = *pbVar1, (char)bVar3 < '1')) {
LAB_0003ef36:
    iVar8 = FUN_00031980();
    if (iVar8 != 0) {
      pcVar4 = (char *)*in_ECX;
      iVar11 = 0;
      if ((pcVar4 == (char *)in_ECX[1]) || (*pcVar4 != '_')) goto LAB_0003f091;
      *in_ECX = (int)(pcVar4 + 1);
      iVar10 = FUN_0002d6e0();
      iVar11 = 0;
      if (iVar10 == 0) goto LAB_0003f091;
      piVar7 = (int *)in_ECX[0x466];
      iVar11 = piVar7[1];
      piVar9 = piVar7;
      if (iVar11 - 0xfe8U < 0xfffff008) {
        piVar9 = malloc(0x1000);
        if (piVar9 == (int *)0x0) {
LAB_0003f0a7:
                    /* WARNING: Subroutine does not return */
          FUN_0002c220();
        }
        *piVar9 = (int)piVar7;
        piVar9[1] = 0;
        in_ECX[0x466] = (int)piVar9;
        iVar11 = 0;
      }
      piVar9[1] = iVar11 + 0x10;
      *(undefined4 *)((int)piVar9 + iVar11 + 0xc) = 0x1010119;
      *(undefined ***)((int)piVar9 + iVar11 + 8) = &PTR_LAB_0004c1f8;
      *(int *)((int)piVar9 + iVar11 + 0x10) = iVar10;
      *(int *)((int)piVar9 + iVar11 + 0x14) = iVar8;
LAB_0003efe3:
      iVar11 = (int)piVar9 + iVar11 + 8;
      goto LAB_0003f091;
    }
  }
  else {
    if (0x39 < bVar3) {
      if (bVar3 != 0x5f) goto LAB_0003ef36;
      *in_ECX = (int)(pcVar4 + 3);
      iVar8 = FUN_0002d6e0();
      iVar11 = 0;
      if (iVar8 == 0) goto LAB_0003f091;
      piVar7 = (int *)in_ECX[0x466];
      iVar11 = piVar7[1];
      piVar9 = piVar7;
      if (iVar11 - 0xfe8U < 0xfffff008) {
        piVar9 = malloc(0x1000);
        if (piVar9 == (int *)0x0) goto LAB_0003f0a7;
        *piVar9 = (int)piVar7;
        piVar9[1] = 0;
        in_ECX[0x466] = (int)piVar9;
        iVar11 = 0;
      }
      piVar9[1] = iVar11 + 0x10;
      *(undefined4 *)((int)piVar9 + iVar11 + 0xc) = 0x1010119;
      *(undefined ***)((int)piVar9 + iVar11 + 8) = &PTR_LAB_0004c1f8;
      *(int *)((int)piVar9 + iVar11 + 0x10) = iVar8;
      *(undefined4 *)((int)piVar9 + iVar11 + 0x14) = 0;
      goto LAB_0003efe3;
    }
    pbVar5 = (byte *)(pcVar4 + 3);
    do {
      pbVar6 = pbVar5;
      *in_ECX = (int)pbVar6;
      if (pbVar6 == pbVar12) goto LAB_0003ee59;
      pbVar5 = pbVar6 + 1;
    } while (0xfffffff5 < (int)(char)*pbVar6 - 0x3aU);
    pbVar12 = pbVar6;
LAB_0003ee59:
    local_2c = (int *)in_ECX[0x466];
    iVar11 = local_2c[1];
    if (iVar11 - 0xfe8U < 0xfffff008) {
      piVar7 = malloc(0x1000);
      if (piVar7 == (int *)0x0) goto LAB_0003f0a7;
      *piVar7 = (int)local_2c;
      piVar7[1] = 0;
      in_ECX[0x466] = (int)piVar7;
      iVar11 = 0;
      local_2c = piVar7;
    }
    local_2c[1] = iVar11 + 0x10;
    *(undefined4 *)((int)local_2c + iVar11 + 0xc) = 0x1010107;
    *(undefined ***)((int)local_2c + iVar11 + 8) = &PTR_LAB_0004b388;
    *(byte **)((int)local_2c + iVar11 + 0x10) = pbVar1;
    *(byte **)((int)local_2c + iVar11 + 0x14) = pbVar12;
    local_1c = (int)local_2c + iVar11 + 8;
    pcVar4 = (char *)*in_ECX;
    iVar11 = 0;
    if ((pcVar4 == (char *)in_ECX[1]) || (*pcVar4 != '_')) goto LAB_0003f091;
    pcVar2 = pcVar4 + 1;
    *in_ECX = (int)pcVar2;
    if ((pcVar2 != (char *)in_ECX[1]) && (*pcVar2 == 'p')) {
      *in_ECX = (int)(pcVar4 + 2);
      iVar11 = FUN_0003ff70();
      goto LAB_0003f091;
    }
    iVar11 = FUN_0002d6e0();
    if (iVar11 != 0) {
      iVar11 = FUN_00040000(&local_1c);
      goto LAB_0003f091;
    }
  }
  iVar11 = 0;
LAB_0003f091:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar11;
}


// ==== FUN_0003f0c0 @ 0003f0c0

int FUN_0003f0c0(void)

{
  char cVar1;
  char *pcVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined4 *in_ECX;
  char *pcVar6;
  int iVar7;
  char *local_20;
  
  pcVar2 = (char *)*in_ECX;
  if (((uint)(in_ECX[1] - (int)pcVar2) < 2) || (*pcVar2 != 'T')) {
LAB_0003f10f:
    iVar7 = FUN_0002e860();
  }
  else {
    cVar1 = pcVar2[1];
    if (cVar1 == 'e') {
      local_20 = "";
      pcVar6 = "enum";
    }
    else if (cVar1 == 's') {
      local_20 = "";
      pcVar6 = "struct";
    }
    else {
      if (cVar1 != 'u') goto LAB_0003f10f;
      local_20 = "";
      pcVar6 = "union";
    }
    *in_ECX = pcVar2 + 2;
    iVar4 = FUN_0002e860();
    iVar7 = 0;
    if (iVar4 != 0) {
      if (pcVar6 == local_20) {
        iVar7 = iVar4;
      }
      else {
        piVar3 = (int *)in_ECX[0x466];
        iVar7 = piVar3[1];
        piVar5 = piVar3;
        if (iVar7 - 0xfd8U < 0xfffff008) {
          piVar5 = malloc(0x1000);
          if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_0002c220();
          }
          *piVar5 = (int)piVar3;
          piVar5[1] = 0;
          in_ECX[0x466] = piVar5;
          iVar7 = 0;
        }
        piVar5[1] = iVar7 + 0x20;
        *(undefined4 *)((int)piVar5 + iVar7 + 0xc) = 0x1010106;
        *(undefined ***)((int)piVar5 + iVar7 + 8) = &PTR_LAB_0004c2a0;
        *(char **)((int)piVar5 + iVar7 + 0x10) = pcVar6;
        *(char **)((int)piVar5 + iVar7 + 0x14) = local_20;
        *(int *)((int)piVar5 + iVar7 + 0x18) = iVar4;
        iVar7 = (int)piVar5 + iVar7 + 8;
      }
    }
  }
  return iVar7;
}


// ==== FUN_0003f1f0 @ 0003f1f0

int FUN_0003f1f0(void)

{
  undefined1 uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  int *in_EDX;
  
  piVar2 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar2[1];
  piVar4 = piVar2;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar2;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  iVar3 = *in_EDX;
  uVar1 = *(undefined1 *)(iVar3 + 5);
  *(undefined1 *)((int)piVar4 + iVar5 + 0xc) = 0xb;
  *(undefined1 *)((int)piVar4 + iVar5 + 0xd) = uVar1;
  *(undefined2 *)((int)piVar4 + iVar5 + 0xe) = 0x101;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004c2d8;
  *(int *)((int)piVar4 + iVar5 + 0x10) = iVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_0003f290 @ 0003f290

int FUN_0003f290(undefined4 *param_1)

{
  undefined1 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int in_ECX;
  int iVar6;
  int *in_EDX;
  
  piVar2 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar2[1];
  piVar5 = piVar2;
  if (iVar6 - 0xfd8U < 0xfffff008) {
    piVar5 = malloc(0x1000);
    if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar5 = (int)piVar2;
    piVar5[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar5;
    iVar6 = 0;
  }
  piVar5[1] = iVar6 + 0x20;
  iVar3 = *in_EDX;
  uVar4 = *param_1;
  uVar1 = *(undefined1 *)(iVar3 + 5);
  *(undefined1 *)((int)piVar5 + iVar6 + 0xc) = 0xc;
  *(undefined1 *)((int)piVar5 + iVar6 + 0xd) = uVar1;
  *(undefined2 *)((int)piVar5 + iVar6 + 0xe) = 0x101;
  *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_LAB_0004c310;
  *(int *)((int)piVar5 + iVar6 + 0x10) = iVar3;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x14) = uVar4;
  *(undefined1 *)((int)piVar5 + iVar6 + 0x18) = 0;
  return (int)piVar5 + iVar6 + 8;
}


// ==== FUN_0003f340 @ 0003f340

int FUN_0003f340(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010105;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004c348;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  *(char **)((int)piVar3 + iVar4 + 0x14) = " complex";
  *(char **)((int)piVar3 + iVar4 + 0x18) = "";
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0003f3e0 @ 0003f3e0

int FUN_0003f3e0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfd8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x20;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x1010105;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004c348;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  *(char **)((int)piVar3 + iVar4 + 0x14) = " imaginary";
  *(char **)((int)piVar3 + iVar4 + 0x18) = "";
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_0003fed0 @ 0003fed0

int FUN_0003fed0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = in_EDX[1];
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010107;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004b388;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_0003ff70 @ 0003ff70

int FUN_0003ff70(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int in_ECX;
  int iVar4;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar4 = piVar1[1];
  piVar3 = piVar1;
  if (iVar4 - 0xfe8U < 0xfffff008) {
    piVar3 = malloc(0x1000);
    if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar3 = (int)piVar1;
    piVar3[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar3;
    iVar4 = 0;
  }
  piVar3[1] = iVar4 + 0x10;
  uVar2 = *in_EDX;
  *(undefined4 *)((int)piVar3 + iVar4 + 0xc) = 0x101011a;
  *(undefined ***)((int)piVar3 + iVar4 + 8) = &PTR_LAB_0004c1c0;
  *(undefined4 *)((int)piVar3 + iVar4 + 0x10) = uVar2;
  return (int)piVar3 + iVar4 + 8;
}


// ==== FUN_00040000 @ 00040000

int FUN_00040000(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x1010119;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004c1f8;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_000402e0 @ 000402e0

int FUN_000402e0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  undefined4 *in_EDX;
  
  piVar1 = *(int **)(in_ECX + 0x1198);
  iVar5 = piVar1[1];
  piVar4 = piVar1;
  if (iVar5 - 0xfe8U < 0xfffff008) {
    piVar4 = malloc(0x1000);
    if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar4 = (int)piVar1;
    piVar4[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar4;
    iVar5 = 0;
  }
  piVar4[1] = iVar5 + 0x10;
  uVar2 = *in_EDX;
  uVar3 = *param_1;
  *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x100000e;
  *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_LAB_0004c230;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x10) = uVar2;
  *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = uVar3;
  return (int)piVar4 + iVar5 + 8;
}


// ==== FUN_00040540 @ 00040540

int FUN_00040540(int *param_1)

{
  undefined1 uVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int in_ECX;
  int iVar6;
  undefined4 *in_EDX;
  
  piVar2 = *(int **)(in_ECX + 0x1198);
  iVar6 = piVar2[1];
  piVar5 = piVar2;
  if (iVar6 - 0xfe8U < 0xfffff008) {
    piVar5 = malloc(0x1000);
    if (piVar5 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0002c220();
    }
    *piVar5 = (int)piVar2;
    piVar5[1] = 0;
    *(int **)(in_ECX + 0x1198) = piVar5;
    iVar6 = 0;
  }
  piVar5[1] = iVar6 + 0x10;
  uVar3 = *in_EDX;
  iVar4 = *param_1;
  uVar1 = *(undefined1 *)(iVar4 + 5);
  *(undefined1 *)((int)piVar5 + iVar6 + 0xc) = 0xd;
  *(undefined1 *)((int)piVar5 + iVar6 + 0xd) = uVar1;
  *(undefined2 *)((int)piVar5 + iVar6 + 0xe) = 0x101;
  *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_LAB_0004c268;
  *(undefined4 *)((int)piVar5 + iVar6 + 0x10) = uVar3;
  *(int *)((int)piVar5 + iVar6 + 0x14) = iVar4;
  return (int)piVar5 + iVar6 + 8;
}


// ==== FUN_000414d0 @ 000414d0

void FUN_000414d0(char param_1,int param_2,undefined4 param_3)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  byte bVar11;
  byte bVar12;
  uint *in_ECX;
  uint uVar13;
  uint in_EDX;
  byte *pbVar14;
  byte *pbVar15;
  byte *pbVar16;
  int in_GS_OFFSET;
  longlong lVar17;
  byte *local_54;
  byte *local_3c;
  byte *local_24;
  byte *local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  *in_ECX = 0;
  in_ECX[1] = 0;
  in_ECX[2] = 0;
  in_ECX[3] = 0;
  in_ECX[5] = 0;
  in_ECX[4] = 0;
  in_ECX[6] = 3;
  if ((in_EDX & 1) == 0) {
    if ((in_EDX & 2) == 0) goto LAB_000419d3;
    if ((~in_EDX & 0xc) == 0) {
      in_ECX[6] = 2;
      goto LAB_000419d3;
    }
  }
  else if ((in_EDX & 0xe) != 0) goto LAB_000419d3;
  uVar3 = FUN_00043590(param_3);
  if (uVar3 != 0) {
    in_ECX[3] = uVar3;
    iVar4 = FUN_00043670(param_3);
    uVar5 = FUN_000435d0(param_3);
    uVar6 = FUN_00041de0();
    if (uVar6 == 0) {
      uVar6 = uVar5;
    }
    uVar13 = (uint)*(byte *)(uVar3 + 1);
    pbVar14 = (byte *)(uVar3 + 2);
    bVar12 = 0;
    if (uVar13 == 0xff) {
      local_3c = (byte *)0x0;
    }
    else {
      bVar11 = 0;
      uVar3 = 0;
      do {
        bVar1 = *pbVar14;
        uVar3 = uVar3 | (bVar1 & 0x7f) << (bVar11 & 0x1f);
        pbVar14 = pbVar14 + 1;
        bVar11 = bVar11 + 7;
      } while ((bVar1 & 0x80) != 0);
      local_3c = pbVar14 + uVar3;
    }
    uVar3 = iVar4 + ~uVar5;
    pbVar14 = pbVar14 + 1;
    uVar5 = 0;
    do {
      bVar11 = *pbVar14;
      uVar5 = uVar5 | (bVar11 & 0x7f) << (bVar12 & 0x1f);
      pbVar14 = pbVar14 + 1;
      bVar12 = bVar12 + 7;
    } while ((bVar11 & 0x80) != 0);
    local_24 = pbVar14;
    do {
      if (pbVar14 + uVar5 <= local_24) break;
      uVar7 = FUN_00041de0();
      iVar4 = FUN_00041de0();
      iVar8 = FUN_00041de0();
      bVar12 = 0;
      uVar9 = 0;
      do {
        bVar11 = *local_24;
        uVar9 = uVar9 | (bVar11 & 0x7f) << (bVar12 & 0x1f);
        local_24 = local_24 + 1;
        bVar12 = bVar12 + 7;
      } while ((bVar11 & 0x80) != 0);
      if ((uVar7 <= uVar3) && (uVar3 < iVar4 + uVar7)) {
        if (iVar8 == 0) goto LAB_0004198a;
        uVar6 = iVar8 + uVar6;
        if (uVar9 != 0) {
          bVar12 = (byte)(uVar13 & 0xf);
          pbVar14 = pbVar14 + uVar5 + uVar9 + -1;
          local_54 = (byte *)(param_2 + 0x20);
          goto LAB_00041730;
        }
        if ((in_EDX & 6) != 2) goto LAB_000419c8;
        in_ECX[1] = 0;
        *in_ECX = 0;
        in_ECX[4] = uVar6;
        in_ECX[6] = 6;
        goto LAB_000419d3;
      }
    } while (uVar7 <= uVar3);
LAB_00041afa:
    FUN_0002bcb0(param_2);
    if (param_1 != '\0') {
      FUN_0002c2d0(*(undefined4 *)(param_2 + -0x24));
    }
                    /* WARNING: Subroutine does not return */
    FUN_0002c220();
  }
LAB_000419c8:
  in_ECX[6] = 8;
LAB_000419d3:
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
LAB_00041730:
  uVar5 = 0;
  uVar3 = 0;
  pbVar16 = pbVar14;
  do {
    bVar11 = *pbVar16;
    uVar3 = uVar3 | (bVar11 & 0x7f) << ((byte)uVar5 & 0x1f);
    pbVar16 = pbVar16 + 1;
    uVar5 = uVar5 + 7;
  } while ((bVar11 & 0x80) != 0);
  uVar7 = -1 << ((byte)uVar5 & 0x1f);
  if (0x1f < uVar5) {
    uVar7 = 0;
  }
  if ((bVar11 & 0x40) == 0) {
    uVar7 = 0;
  }
  uVar7 = uVar7 | uVar3;
  uVar3 = (int)uVar7 >> 0x1f;
  if ((int)uVar7 < 1) {
    if ((int)uVar7 < 0) {
      if (param_1 == '\0') {
        if ((in_EDX & 5) != 0) goto LAB_000419eb;
        if ((in_EDX & 8) == 0) goto LAB_00041b4f;
      }
      else {
        lVar17 = FUN_0002ba80(param_2);
        pbVar15 = local_54;
        if (lVar17 == 0x434c4e47432b2b01) {
          pbVar15 = *(byte **)(param_2 + -4);
        }
        if ((pbVar15 == (byte *)0x0) || (*(int *)(param_2 + -0x30) == 0)) goto LAB_00041b3f;
        cVar2 = FUN_00041f00(local_3c,uVar13,*(int *)(param_2 + -0x30),pbVar15,param_2);
        if (cVar2 != '\0') {
          if ((in_EDX & 1) == 0) goto LAB_00041914;
          *in_ECX = uVar7;
          in_ECX[1] = uVar3;
          in_ECX[2] = (uint)pbVar14;
          in_ECX[4] = uVar6;
          in_ECX[5] = (uint)pbVar15;
          in_ECX[6] = 6;
          goto LAB_000419d3;
        }
      }
    }
    else if ((in_EDX & 6) == 2) {
      in_ECX[1] = 0;
      *in_ECX = 0;
      in_ECX[2] = (uint)pbVar14;
      in_ECX[4] = uVar6;
      lVar17 = FUN_0002ba80(param_2);
      if (lVar17 == 0x434c4e47432b2b01) {
        local_54 = *(byte **)(param_2 + -4);
      }
      in_ECX[5] = (uint)local_54;
      in_ECX[6] = 6;
      goto LAB_000419d3;
    }
  }
  else {
    if (((local_3c == (byte *)0x0) || (0xc < bVar12)) || ((0x1c1dU >> bVar12 & 1) == 0))
    goto LAB_00041afa;
    local_1c = local_3c + *(int *)(&DAT_00018014 + (uVar13 & 0xf) * 4) * uVar7;
    piVar10 = (int *)FUN_00041de0();
    if (piVar10 == (int *)0x0) {
      if ((in_EDX & 5) != 0) {
LAB_000419eb:
        *in_ECX = uVar7;
        in_ECX[1] = uVar3;
        in_ECX[2] = (uint)pbVar14;
        in_ECX[4] = uVar6;
        lVar17 = FUN_0002ba80(param_2);
        if (lVar17 == 0x434c4e47432b2b01) {
          local_54 = *(byte **)(param_2 + -4);
        }
        in_ECX[5] = (uint)local_54;
        in_ECX[6] = 6;
        goto LAB_000419d3;
      }
      if ((in_EDX & 8) == 0) goto LAB_00041afa;
    }
    else if (param_1 != '\0') {
      lVar17 = FUN_0002ba80(param_2);
      local_1c = local_54;
      if (lVar17 == 0x434c4e47432b2b01) {
        local_1c = *(byte **)(param_2 + -4);
      }
      if ((local_1c == (byte *)0x0) || (*(int *)(param_2 + -0x30) == 0)) {
LAB_00041b3f:
        FUN_0002bcb0(param_2);
        FUN_0002c2d0(*(undefined4 *)(param_2 + -0x24));
LAB_00041b4f:
        FUN_0002bcb0(param_2);
                    /* WARNING: Subroutine does not return */
        FUN_0002c220();
      }
      cVar2 = (**(code **)(*piVar10 + 0x10))(piVar10,*(int *)(param_2 + -0x30),&local_1c);
      if (cVar2 != '\0') {
        if ((in_EDX & 1) != 0) {
          *in_ECX = uVar7;
          in_ECX[1] = uVar3;
          in_ECX[2] = (uint)pbVar14;
          in_ECX[4] = uVar6;
          in_ECX[5] = (uint)local_1c;
          in_ECX[6] = 6;
          goto LAB_000419d3;
        }
LAB_00041914:
        if ((in_EDX & 8) == 0) goto LAB_00041b3f;
      }
    }
  }
  uVar5 = 0;
  uVar3 = 0;
  pbVar14 = pbVar16;
  do {
    bVar11 = *pbVar14;
    uVar3 = uVar3 | (bVar11 & 0x7f) << ((byte)uVar5 & 0x1f);
    pbVar14 = pbVar14 + 1;
    uVar5 = uVar5 + 7;
  } while ((bVar11 & 0x80) != 0);
  uVar7 = -1 << ((byte)uVar5 & 0x1f);
  if (0x1f < uVar5) {
    uVar7 = 0;
  }
  if ((bVar11 & 0x40) == 0) {
    uVar7 = 0;
  }
  if ((uVar7 | uVar3) == 0) goto LAB_0004198a;
  pbVar14 = pbVar16 + (uVar7 | uVar3);
  goto LAB_00041730;
LAB_0004198a:
  in_ECX[6] = 8;
  goto LAB_000419d3;
}


// ==== FUN_00041b70 @ 00041b70

void FUN_00041b70(undefined **param_1)

{
  byte bVar1;
  undefined **ppuVar2;
  char cVar3;
  char cVar4;
  undefined *puVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 *puVar8;
  byte bVar9;
  undefined **ppuVar10;
  undefined *unaff_EDI;
  byte *pbVar11;
  longlong lVar12;
  undefined **local_38;
  undefined *local_34;
  undefined **local_30 [2];
  undefined **local_28;
  int local_24;
  undefined *local_20;
  char *local_1c;
  int *local_18;
  
  if (param_1 == (undefined **)0x0) {
    FUN_0002bcb0(0);
                    /* WARNING: Subroutine does not return */
    FUN_0002c220();
  }
  FUN_0002bcb0(param_1);
  cVar3 = FUN_0002baa0(param_1);
  if (cVar3 == '\0') {
    local_34 = (undefined *)FUN_0002c2b0();
    local_38 = (undefined **)0x0;
    puVar5 = (undefined *)FUN_0002c200();
  }
  else {
    local_38 = param_1 + -0xc;
    puVar5 = param_1[-10];
    local_34 = param_1[-9];
    local_20 = param_1[-6];
    local_24 = (int)local_20 >> 0x1f;
    unaff_EDI = param_1[-4];
  }
                    /* try { // try from 00041bf2 to 00041bf9 has its CatchHandler @ 00041bfa */
  uVar6 = FUN_0002c280(puVar5);
                    /* catch(type#1 @ 00000000) { ... } // from try @ 00041bf2 with catch @ 00041bfa
                        */
  FUN_0002bcb0(uVar6);
  ppuVar10 = param_1;
  if (cVar3 == '\0') {
LAB_00041d45:
    FUN_0002bd40();
LAB_00041d4a:
    FUN_0002c2d0(local_34);
  }
  else {
    local_1c = unaff_EDI + 1;
                    /* try { // try from 00041c17 to 00041c1f has its CatchHandler @ 00041dc1 */
    FUN_00041de0();
    cVar3 = *local_1c;
    if (cVar3 == -1) goto LAB_00041d4a;
    pbVar11 = (byte *)(local_1c + 1);
    bVar9 = 0;
    ppuVar10 = (undefined **)0x0;
    do {
      bVar1 = *pbVar11;
      ppuVar10 = (undefined **)((uint)ppuVar10 | (bVar1 & 0x7f) << (bVar9 & 0x1f));
      pbVar11 = pbVar11 + 1;
      bVar9 = bVar9 + 7;
    } while ((bVar1 & 0x80) != 0);
                    /* try { // try from 00041c56 to 00041c5a has its CatchHandler @ 00041dbf */
    piVar7 = (int *)FUN_0002bf30();
    ppuVar2 = (undefined **)*piVar7;
    if (ppuVar2 == (undefined **)0x0) goto LAB_00041d4a;
    local_28 = ppuVar2 + 0xc;
    local_18 = piVar7;
                    /* try { // try from 00041c70 to 00041c7b has its CatchHandler @ 00041dbd */
    cVar4 = FUN_0002baa0(local_28);
    pbVar11 = pbVar11 + (int)ppuVar10;
    if ((cVar4 != '\0') && (ppuVar2 != local_38)) {
      puVar5 = *ppuVar2;
                    /* try { // try from 00041c91 to 00041ce5 has its CatchHandler @ 00041dbb */
      lVar12 = FUN_0002ba80(local_28);
      if (lVar12 == 0x434c4e47432b2b01) {
        ppuVar10 = (undefined **)ppuVar2[0xb];
      }
      else {
        ppuVar10 = ppuVar2 + 0x14;
      }
      cVar4 = FUN_00041f00(pbVar11,cVar3,puVar5,ppuVar10,param_1);
      if (cVar4 == '\0') {
        ppuVar2[5] = (undefined *)-(int)ppuVar2[5];
        local_18[1] = local_18[1] + 1;
                    /* try { // try from 00041d90 to 00041daa has its CatchHandler @ 00041dbb */
        FUN_0002bd40();
        FUN_0002bd40();
        FUN_0002bcb0(local_28);
        uVar6 = FUN_0002be00();
        goto LAB_00041dab;
      }
    }
    local_38 = &PTR_FUN_0004c470;
                    /* try { // try from 00041d06 to 00041d34 has its CatchHandler @ 00041dab */
    ppuVar10 = &PTR_PTR_0004c47c;
    local_30[0] = local_38;
    cVar3 = FUN_00041f00(pbVar11,cVar3,&PTR_PTR_0004c47c,local_30,param_1);
    if (cVar3 != '\0') {
      FUN_00042a70(local_30);
      goto LAB_00041d45;
    }
  }
                    /* try { // try from 00041d56 to 00041d5a has its CatchHandler @ 00041dab */
  FUN_0002bd40();
  puVar8 = (undefined4 *)FUN_0002bad0(4);
  *puVar8 = local_38;
                    /* try { // try from 00041d6d to 00041d82 has its CatchHandler @ 00041dab */
  uVar6 = FUN_0002bb70(puVar8,ppuVar10,FUN_00042a70);
LAB_00041dab:
                    /* catch(type#1 @ 00000000) { ... } // from try @ 00041d06 with catch @ 00041dab
                       catch(type#1 @ 00000000) { ... } // from try @ 00041d56 with catch @ 00041dab
                       catch(type#1 @ 00000000) { ... } // from try @ 00041d6d with catch @ 00041dab
                        */
  FUN_00042a70(local_30);
                    /* try { // try from 00041dc3 to 00041dc7 has its CatchHandler @ 00041dd0 */
  FUN_0002bd40();
                    /* WARNING: Subroutine does not return */
  FUN_00043410(uVar6);
}


// ==== FUN_00041de0 @ 00041de0

/* WARNING: Type propagation algorithm not settling */

byte * FUN_00041de0(void)

{
  ushort *puVar1;
  ushort uVar2;
  uint uVar3;
  byte *pbVar4;
  byte bVar5;
  undefined4 *in_ECX;
  uint uVar6;
  uint in_EDX;
  uint uVar7;
  ushort *puVar8;
  
  if ((char)in_EDX == -1) {
    return (byte *)0x0;
  }
  if (0xc < (in_EDX & 0xf)) {
switchD_00041e21_caseD_5:
                    /* WARNING: Subroutine does not return */
    abort();
  }
  puVar1 = (ushort *)*in_ECX;
  puVar8 = puVar1;
  switch(in_EDX & 0xf) {
  case 0:
  case 3:
  case 0xb:
    pbVar4 = *(byte **)puVar1;
    puVar8 = puVar1 + 2;
    break;
  case 1:
    bVar5 = 0;
    pbVar4 = (byte *)0x0;
    do {
      uVar2 = *puVar8;
      pbVar4 = (byte *)((uint)pbVar4 | ((byte)uVar2 & 0x7f) << (bVar5 & 0x1f));
      puVar8 = (ushort *)((int)puVar8 + 1);
      bVar5 = bVar5 + 7;
    } while (((byte)uVar2 & 0x80) != 0);
    break;
  case 2:
    pbVar4 = (byte *)(uint)*puVar1;
    goto LAB_00041ea6;
  case 4:
  case 0xc:
    pbVar4 = *(byte **)puVar1;
    puVar8 = puVar1 + 4;
    break;
  default:
    goto switchD_00041e21_caseD_5;
  case 9:
    uVar6 = 0;
    uVar7 = 0;
    do {
      bVar5 = (byte)*puVar8;
      uVar7 = uVar7 | (bVar5 & 0x7f) << ((byte)uVar6 & 0x1f);
      puVar8 = (ushort *)((int)puVar8 + 1);
      uVar6 = uVar6 + 7;
    } while ((bVar5 & 0x80) != 0);
    uVar3 = -1 << ((byte)uVar6 & 0x1f);
    if (0x1f < uVar6) {
      uVar3 = 0;
    }
    if ((bVar5 & 0x40) == 0) {
      uVar3 = 0;
    }
    pbVar4 = (byte *)(uVar3 | uVar7);
    break;
  case 10:
    pbVar4 = (byte *)(int)(short)*puVar1;
LAB_00041ea6:
    puVar8 = puVar1 + 1;
  }
  uVar6 = in_EDX >> 4 & 7;
  if (uVar6 == 0) {
joined_r0x00041ed4:
    if (pbVar4 != (byte *)0x0) {
      if ((in_EDX & 0x80) != 0) {
        pbVar4 = *(byte **)pbVar4;
      }
      goto LAB_00041edd;
    }
  }
  else {
    if (uVar6 != 1) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    if (pbVar4 != (byte *)0x0) {
      pbVar4 = pbVar4 + (int)puVar1;
      goto joined_r0x00041ed4;
    }
  }
  pbVar4 = (byte *)0x0;
LAB_00041edd:
  *in_ECX = puVar8;
  return pbVar4;
}


// ==== FUN_00041f00 @ 00041f00

bool FUN_00041f00(int param_1,byte param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  byte bVar1;
  char cVar2;
  int *piVar3;
  byte bVar4;
  uint in_ECX;
  uint uVar5;
  byte *pbVar6;
  uint uVar7;
  int in_GS_OFFSET;
  undefined4 local_20;
  int local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if (param_1 == 0) {
LAB_00042014:
    FUN_0002bcb0(param_5);
                    /* WARNING: Subroutine does not return */
    FUN_0002c220();
  }
  param_2 = param_2 & 0xf;
  pbVar6 = (byte *)(~in_ECX + param_1);
  bVar4 = 0;
  uVar5 = 0;
  do {
    do {
      bVar1 = *pbVar6;
      pbVar6 = pbVar6 + 1;
      uVar7 = uVar5 | (bVar1 & 0x7f) << (bVar4 & 0x1f);
      bVar4 = bVar4 + 7;
      uVar5 = uVar7;
    } while ((bVar1 & 0x80) != 0);
    if (uVar7 == 0) break;
    if ((0xc < param_2) || ((0x1c1dU >> param_2 & 1) == 0)) {
      FUN_0002bcb0(param_5);
      FUN_0002c2d0(*(undefined4 *)(param_5 + -0x24));
      goto LAB_00042014;
    }
    local_1c = *(int *)(&DAT_00018014 + (uint)param_2 * 4) * uVar7 + param_1;
    piVar3 = (int *)FUN_00041de0();
    local_20 = param_4;
    cVar2 = (**(code **)(*piVar3 + 0x10))(piVar3,param_3,&local_20);
    bVar4 = 0;
    uVar5 = 0;
  } while (cVar2 == '\0');
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar7 == 0;
}


// ==== FUN_00042040 @ 00042040

void * FUN_00042040(size_t param_1)

{
  int iVar1;
  size_t __size;
  int in_GS_OFFSET;
  void *local_18;
  int local_14;
  
  local_14 = *(int *)(in_GS_OFFSET + 0x14);
  __size = 1;
  if (param_1 != 0) {
    __size = param_1;
  }
  iVar1 = posix_memalign(&local_18,0x10,__size);
  if (iVar1 != 0) {
    local_18 = (void *)FUN_000420b0();
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return local_18;
}


// ==== FUN_000420b0 @ 000420b0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ushort * FUN_000420b0(void)

{
  ushort *puVar1;
  ushort uVar2;
  uint uVar3;
  int in_ECX;
  ushort *puVar4;
  ushort *puVar5;
  uint uVar6;
  
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00050938);
  if (DAT_0005093c == (ushort *)0x0) {
    DAT_0005093c = &DAT_00050940;
    _DAT_00050940 = 0x800080;
  }
  if (DAT_0005093c != &DAT_00050b40) {
    uVar6 = (in_ECX + 3U >> 2) + 1;
    puVar1 = DAT_0005093c;
    puVar4 = (ushort *)0x0;
    do {
      puVar5 = puVar1;
      uVar2 = puVar5[1];
      if (uVar6 < uVar2) {
        uVar2 = uVar2 - (ushort)uVar6;
        puVar5[1] = uVar2;
        uVar3 = (uint)uVar2;
        puVar5[uVar3 * 2] = 0;
        puVar5[uVar3 * 2 + 1] = (ushort)uVar6;
        puVar5 = puVar5 + uVar3 * 2 + 2;
        goto LAB_00042191;
      }
      if (uVar6 == uVar2) {
        if (puVar4 == (ushort *)0x0) {
          DAT_0005093c = &DAT_00050940 + (uint)*puVar5 * 2;
        }
        else {
          *puVar4 = *puVar5;
        }
        *puVar5 = 0;
        puVar5 = puVar5 + 2;
        goto LAB_00042191;
      }
      puVar1 = &DAT_00050940 + (uint)*puVar5 * 2;
      puVar4 = puVar5;
    } while (*puVar5 != 0x80);
  }
  puVar5 = (ushort *)0x0;
LAB_00042191:
                    /* try { // try from 00042191 to 00042198 has its CatchHandler @ 000421a3 */
  pthread_mutex_unlock((pthread_mutex_t *)&DAT_00050938);
  return puVar5;
}


// ==== FUN_000421b0 @ 000421b0

void FUN_000421b0(undefined2 *param_1)

{
  if ((param_1 < &DAT_00050940) || ((undefined2 *)0x50b3f < param_1)) {
    free(param_1);
  }
  else {
    FUN_00042200();
  }
  return;
}


// ==== FUN_00042200 @ 00042200

void FUN_00042200(void)

{
  ushort *puVar1;
  ushort uVar2;
  ushort *puVar3;
  int in_ECX;
  ushort *puVar4;
  ushort *puVar5;
  
  puVar1 = (ushort *)(in_ECX + -4);
  pthread_mutex_lock((pthread_mutex_t *)&DAT_00050938);
  if ((DAT_0005093c != (ushort *)0x0) && (DAT_0005093c != &DAT_00050b40)) {
    puVar3 = DAT_0005093c;
    puVar5 = (ushort *)0x0;
    do {
      puVar4 = puVar3;
      uVar2 = puVar4[1];
      if (puVar4 + (uint)uVar2 * 2 == puVar1) {
        puVar4[1] = *(short *)(in_ECX + -2) + uVar2;
        goto LAB_000422f3;
      }
      if (puVar1 + (uint)*(ushort *)(in_ECX + -2) * 2 == puVar4) {
        *(ushort *)(in_ECX + -2) = *(ushort *)(in_ECX + -2) + uVar2;
        if (puVar5 == (ushort *)0x0) {
          DAT_0005093c = puVar1;
          *puVar1 = *puVar4;
        }
        else {
          *puVar5 = (ushort)(in_ECX - 0x50944U >> 2);
        }
        goto LAB_000422f3;
      }
      puVar3 = &DAT_00050940 + (uint)*puVar4 * 2;
      puVar5 = puVar4;
    } while (*puVar4 != 0x80);
  }
  *puVar1 = (ushort)((uint)(DAT_0005093c + -0x284a0) >> 2);
  DAT_0005093c = puVar1;
LAB_000422f3:
                    /* try { // try from 000422f7 to 000422fe has its CatchHandler @ 00042307 */
  pthread_mutex_unlock((pthread_mutex_t *)&DAT_00050938);
  return;
}


// ==== FUN_000423e0 @ 000423e0

bool FUN_000423e0(int param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  int in_GS_OFFSET;
  bool bVar2;
  int *local_50;
  undefined4 local_4c;
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 local_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 local_1c;
  int local_18;
  
  local_18 = *(int *)(in_GS_OFFSET + 0x14);
  if (*(int *)(param_1 + 4) == *(int *)(param_2 + 4)) {
    bVar2 = true;
  }
  else {
    piVar1 = (int *)FUN_00042590(param_2,&PTR_PTR_0004c3d8,&PTR_PTR_0004c3e4,0);
    if (piVar1 == (int *)0x0) {
      bVar2 = false;
    }
    else {
      local_4c = 0;
      uStack_40 = 0;
      local_2c = 0;
      uStack_28 = 0;
      uStack_24 = 0;
      local_3c = 0;
      iStack_38 = 0;
      uStack_34 = 0;
      uStack_30 = 0;
      local_1c = 0;
      iStack_48 = param_1;
      uStack_44 = 0xffffffff;
      uStack_20 = 1;
      local_50 = piVar1;
      (**(code **)(*piVar1 + 0x1c))(piVar1,&local_50,*param_3,1);
      bVar2 = iStack_38 == 1;
      if (bVar2) {
        *param_3 = uStack_40;
      }
    }
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_18) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return bVar2;
}


// ==== FUN_00042590 @ 00042590

int FUN_00042590(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int in_GS_OFFSET;
  int local_50;
  int *local_4c;
  undefined4 local_48;
  undefined4 local_44;
  int local_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int local_30;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined3 uStack_1c;
  int local_14;
  
  local_14 = *(int *)(in_GS_OFFSET + 0x14);
  iVar3 = *(int *)(*param_1 + -8) + (int)param_1;
  piVar1 = *(int **)(*param_1 + -4);
  local_50 = param_3;
  local_4c = param_1;
  local_48 = param_2;
  local_44 = param_4;
  local_40 = 0;
  iStack_3c = 0;
  iStack_38 = 0;
  iStack_34 = 0;
  local_30 = 0;
  iStack_2c = 0;
  iStack_28 = 0;
  uStack_1c = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  if (piVar1[1] == *(int *)(param_3 + 4)) {
    uStack_20 = 1;
    (**(code **)(*piVar1 + 0x14))(piVar1,&local_50,iVar3,iVar3,1,0);
    iVar2 = 0;
    if (iStack_38 == 1) {
      iVar2 = iVar3;
    }
  }
  else {
    (**(code **)(*piVar1 + 0x18))(piVar1,&local_50,iVar3,1,0);
    iVar2 = 0;
    if (iStack_2c == 1) {
      if ((iStack_38 == 1) || (((iStack_28 == 0 && (iStack_34 == 1)) && (local_30 == 1)))) {
        iVar2 = local_40;
      }
    }
    else if ((iStack_2c == 0) && (iVar2 = 0, local_30 == 1 && (iStack_34 == 1 && iStack_28 == 1))) {
      iVar2 = iStack_3c;
    }
  }
  if (*(int *)(in_GS_OFFSET + 0x14) != local_14) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar2;
}


// ==== FUN_00042a70 @ 00042a70

void FUN_00042a70(void)

{
  return;
}


// ==== FUN_00042ad0 @ 00042ad0

void FUN_00042ad0(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_0004c454;
  return;
}


// ==== FUN_00042c20 @ 00042c20

void FUN_00042c20(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  *param_1 = &PTR_FUN_0004c4b0;
  iVar3 = param_1[1];
  LOCK();
  piVar1 = (int *)(iVar3 + -4);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 + -1 < 0) {
    FUN_0002a000(iVar3 + -0xc);
  }
  FUN_00042a70(param_1);
  return;
}


// ==== FUN_00042ce0 @ 00042ce0

undefined4 FUN_00042ce0(int param_1)

{
  return *(undefined4 *)(param_1 + 4);
}


// ==== FUN_00042cf0 @ 00042cf0

void FUN_00042cf0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  *param_1 = &PTR_LAB_0004c49c;
  iVar3 = param_1[1];
  LOCK();
  piVar1 = (int *)(iVar3 + -4);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 + -1 < 0) {
    FUN_0002a000(iVar3 + -0xc);
  }
  FUN_00042a70(param_1);
  FUN_0002a000(param_1);
  return;
}


// ==== FUN_00042db0 @ 00042db0

void FUN_00042db0(void)

{
  return;
}


// ==== FUN_00042dc0 @ 00042dc0

undefined * FUN_00042dc0(void)

{
  pthread_once((pthread_once_t *)&DAT_00050b40,(__init_routine *)&LAB_00042e00);
  return &DAT_00050b50;
}


// ==== FUN_00042e80 @ 00042e80

void * FUN_00042e80(size_t *param_1)

{
  size_t sVar1;
  undefined4 *__ptr;
  void *pvVar2;
  size_t sVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *__s;
  
  sVar3 = param_1[2];
  if (sVar3 == 0) {
    pthread_once((pthread_once_t *)&DAT_00050b94,(__init_routine *)&LAB_00043090);
    pthread_mutex_lock((pthread_mutex_t *)&DAT_00050b98);
    sVar3 = param_1[2];
    if (sVar3 == 0) {
      sVar3 = DAT_00050b90 + 1;
      DAT_00050b90 = sVar3;
      param_1[2] = sVar3;
    }
    pthread_mutex_unlock((pthread_mutex_t *)&DAT_00050b98);
  }
  __ptr = pthread_getspecific(DAT_00050b8c);
  if (__ptr == (undefined4 *)0x0) {
    uVar6 = sVar3 + 0x11 & 0xfffffff0;
    sVar1 = uVar6 * 4;
    __ptr = malloc(sVar1);
    if (__ptr == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    iVar5 = uVar6 - 2;
    memset(__ptr + 2,0,sVar1 - 8);
    *__ptr = 1;
  }
  else {
    uVar6 = __ptr[1];
    if (sVar3 <= uVar6) goto LAB_00042faf;
    uVar4 = sVar3 + 0x11 & 0xfffffff0;
    __ptr = realloc(__ptr,uVar4 * 4);
    if (__ptr == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    iVar5 = uVar4 - 2;
    memset(__ptr + uVar6 + 2,0,(iVar5 - uVar6) * 4);
  }
  __ptr[1] = iVar5;
  pthread_setspecific(DAT_00050b8c,__ptr);
LAB_00042faf:
  __s = (void *)__ptr[sVar3 + 1];
  if (__s == (void *)0x0) {
    uVar6 = 4;
    if (4 < param_1[1]) {
      uVar6 = param_1[1];
    }
    if ((uVar6 & uVar6 - 1) != 0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    sVar1 = *param_1;
    pvVar2 = malloc(sVar1 + uVar6 + 3);
    if (pvVar2 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      abort();
    }
    __s = (void *)(-uVar6 & uVar6 + 3 + (int)pvVar2);
    *(void **)((int)__s + -4) = pvVar2;
    if ((void *)param_1[3] == (void *)0x0) {
      memset(__s,0,sVar1);
    }
    else {
      memcpy(__s,(void *)param_1[3],sVar1);
    }
    __ptr[sVar3 + 1] = __s;
  }
  return __s;
}


// ==== FUN_00043050 @ 00043050

void FUN_00043050(void)

{
  if (DAT_00050b88 == '\x01') {
    pthread_key_delete(DAT_00050b8c);
    DAT_00050b88 = '\0';
  }
  return;
}


// ==== FUN_00043140 @ 00043140

ulonglong FUN_00043140(uint param_1,uint param_2,uint param_3,uint param_4)

{
  int iVar1;
  byte bVar2;
  uint uVar3;
  
  iVar1 = 0x1f;
  if (param_4 != 0) {
    for (; param_4 >> iVar1 == 0; iVar1 = iVar1 + -1) {
    }
  }
  if (param_4 != 0) {
    bVar2 = (byte)iVar1;
    uVar3 = param_4 << (~bVar2 & 0x1f) | (param_3 >> (bVar2 & 0x1f)) >> 1;
    if (param_2 < uVar3) {
      uVar3 = ((uint)(CONCAT44(param_2,param_1) / (ulonglong)uVar3) >> 1) >> (bVar2 & 0x1f);
      return (ulonglong)
             (uVar3 - ((param_2 - (int)((ulonglong)uVar3 * (ulonglong)param_3 >> 0x20)) -
                       (uint)(param_1 < (uint)((ulonglong)uVar3 * (ulonglong)param_3)) <
                      param_4 * uVar3));
    }
    uVar3 = ((uint)(CONCAT44(param_2 - uVar3,param_1) / (ulonglong)uVar3) >> 1 | 0x80000000) >>
            (bVar2 & 0x1f);
    return (ulonglong)
           (uVar3 - ((param_2 - (int)((ulonglong)uVar3 * (ulonglong)param_3 >> 0x20)) -
                     (uint)(param_1 < (uint)((ulonglong)uVar3 * (ulonglong)param_3)) <
                    param_4 * uVar3));
  }
  return CONCAT44(param_2 / param_3,
                  (int)(((ulonglong)param_2 % (ulonglong)param_3 << 0x20 | (ulonglong)param_1) /
                       (ulonglong)param_3));
}


// ==== FUN_000431e0 @ 000431e0

undefined4 FUN_000431e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_f8;
  undefined1 local_f4 [12];
  code *local_e8;
  undefined1 local_cc [64];
  undefined1 local_8c [124];
  
  FUN_00046c64(local_cc);
  param_1[3] = 0;
  param_1[4] = 0;
  FUN_000436d0(local_8c,local_cc);
  iVar1 = FUN_00043840(local_8c);
  while( true ) {
    if (iVar1 == 0) {
      return 5;
    }
    if (iVar1 < 0) {
      return 3;
    }
    iVar1 = FUN_00043870(local_8c,local_f4);
    if (iVar1 != 0) {
      return 3;
    }
    if ((local_e8 != (code *)0x0) &&
       (iVar1 = (*local_e8)(1,1,*param_1,param_1[1],param_1,local_8c), iVar1 != 8)) break;
    iVar1 = FUN_00043840(local_8c);
  }
  if (iVar1 == 6) {
    FUN_00043740(local_8c,0xfffffffe,&local_f8);
    param_1[4] = local_f8;
    uVar2 = FUN_000432f0(param_1);
    return uVar2;
  }
  return 3;
}


// ==== FUN_000432f0 @ 000432f0

undefined4 FUN_000432f0(undefined4 *param_1)

{
  int iVar1;
  int local_40;
  code *local_30;
  
  FUN_000436d0();
  iVar1 = FUN_00043840();
  do {
    if (iVar1 == 0) {
      return 5;
    }
    if (iVar1 < 0) {
      return 2;
    }
    FUN_00043740();
    iVar1 = FUN_00043870();
    if (iVar1 != 0) {
      return 2;
    }
    if (local_30 != (code *)0x0) {
      iVar1 = (*local_30)(1,(local_40 == param_1[4]) * '\x04' + '\x02',*param_1,param_1[1],param_1);
      if (iVar1 != 8) {
        if (iVar1 == 7) {
          FUN_000438b0();
          return 2;
        }
        return 2;
      }
      if (local_40 == param_1[4]) {
        fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","unwind_phase2",
                "during phase1 personality function said it would stop here, but now in phase2 it did not stop here"
               );
        fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
        abort();
      }
    }
    iVar1 = FUN_00043840();
  } while( true );
}


// ==== FUN_00043410 @ 00043410

void FUN_00043410(int param_1)

{
  undefined1 local_c4 [188];
  
  FUN_00046c64(local_c4);
  if (*(int *)(param_1 + 0xc) == 0) {
    FUN_000432f0(param_1);
  }
  else {
    FUN_000434b0(param_1,*(int *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  }
  fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","_Unwind_Resume","_Unwind_Resume() can\'t return");
  fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_000434b0 @ 000434b0

void FUN_000434b0(undefined4 *param_1,code *param_2)

{
  int iVar1;
  code *local_30;
  
  FUN_000436d0();
  iVar1 = FUN_00043840();
  while( true ) {
    if (iVar1 < 1) {
      (*param_2)(1,0x1a,*param_1,param_1[1],param_1);
      return;
    }
    iVar1 = FUN_00043870();
    if (iVar1 != 0) break;
    iVar1 = (*param_2)(1,10,*param_1,param_1[1],param_1);
    if (iVar1 != 0) {
      return;
    }
    if ((local_30 != (code *)0x0) &&
       (iVar1 = (*local_30)(1,10,*param_1,param_1[1],param_1), iVar1 != 8)) {
      if (iVar1 != 7) {
        return;
      }
      FUN_000438b0();
    }
    iVar1 = FUN_00043840();
  }
  return;
}


// ==== FUN_00043590 @ 00043590

undefined4 FUN_00043590(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 local_2c [8];
  undefined4 local_24;
  
  iVar1 = FUN_00043870(param_1,local_2c);
  uVar2 = 0;
  if (iVar1 == 0) {
    uVar2 = local_24;
  }
  return uVar2;
}


// ==== FUN_000435d0 @ 000435d0

undefined4 FUN_000435d0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_2c [10];
  
  iVar1 = FUN_00043870(param_1,local_2c);
  uVar2 = 0;
  if (iVar1 == 0) {
    uVar2 = local_2c[0];
  }
  return uVar2;
}


// ==== FUN_00043610 @ 00043610

void FUN_00043610(int param_1)

{
  if (*(code **)(param_1 + 8) == (code *)0x0) {
    return;
  }
  (**(code **)(param_1 + 8))(1,param_1);
  return;
}


// ==== FUN_00043640 @ 00043640

void FUN_00043640(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_000437a0(param_1,param_2,param_3,0x43649);
  return;
}


// ==== FUN_00043670 @ 00043670

undefined4 FUN_00043670(undefined4 param_1)

{
  undefined4 local_8;
  
  FUN_00043740(param_1,0xffffffff,&local_8,0x43679);
  return local_8;
}


// ==== FUN_000436a0 @ 000436a0

void FUN_000436a0(undefined4 param_1,undefined4 param_2)

{
  FUN_000437a0(param_1,0xffffffff,param_2,0x436a9);
  return;
}


// ==== FUN_000436d0 @ 000436d0

undefined4 FUN_000436d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  *param_1 = &PTR_LAB_0004c524;
  param_1[1] = &DAT_00050b9c;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  uVar4 = param_2[4];
  uVar5 = param_2[5];
  uVar6 = param_2[6];
  uVar7 = param_2[7];
  param_1[2] = *param_2;
  param_1[3] = uVar1;
  param_1[4] = uVar2;
  param_1[5] = uVar3;
  param_1[6] = uVar4;
  param_1[7] = uVar5;
  param_1[8] = uVar6;
  param_1[9] = uVar7;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  param_1[10] = param_2[8];
  param_1[0xb] = uVar1;
  param_1[0xc] = uVar2;
  param_1[0xd] = uVar3;
  uVar1 = param_2[0xd];
  uVar2 = param_2[0xe];
  uVar3 = param_2[0xf];
  param_1[0xe] = param_2[0xc];
  param_1[0xf] = uVar1;
  param_1[0x10] = uVar2;
  param_1[0x11] = uVar3;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  *(undefined4 *)((int)param_1 + 0x62) = 0;
  *(undefined4 *)((int)param_1 + 0x66) = 0;
  *(undefined4 *)((int)param_1 + 0x6a) = 0;
  *(undefined4 *)((int)param_1 + 0x6e) = 0;
  FUN_00044070(param_1,0);
  return 0;
}


// ==== FUN_00043740 @ 00043740

undefined4 FUN_00043740(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  
  cVar1 = (**(code **)(*param_1 + 8))(param_1,param_2);
  uVar2 = 0xffffe672;
  if (cVar1 != '\0') {
    uVar2 = (**(code **)(*param_1 + 0xc))(param_1,param_2);
    *param_3 = uVar2;
    uVar2 = 0;
  }
  return uVar2;
}


// ==== FUN_000437a0 @ 000437a0

undefined4 FUN_000437a0(int *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined1 local_3c [16];
  int local_2c;
  
  uVar4 = 0x437ac;
  cVar1 = (**(code **)(*param_1 + 8))(param_1,param_2);
  uVar3 = 0xffffe672;
  if (cVar1 != '\0') {
    (**(code **)(*param_1 + 0x10))(param_1,param_2,param_3,uVar4);
    uVar3 = 0;
    if (param_2 == -1) {
      (**(code **)(*param_1 + 0x24))(param_1,local_3c);
      (**(code **)(*param_1 + 0x34))(param_1,0);
      if (local_2c != 0) {
        iVar2 = (**(code **)(*param_1 + 0xc))(param_1,0xfffffffe);
        (**(code **)(*param_1 + 0x10))(param_1,0xfffffffe,iVar2 + local_2c);
      }
    }
  }
  return uVar3;
}


// ==== FUN_00043840 @ 00043840

void FUN_00043840(int *param_1)

{
  (**(code **)(*param_1 + 0x20))(param_1);
  return;
}


// ==== FUN_00043870 @ 00043870

undefined4 FUN_00043870(int *param_1,int param_2)

{
  undefined4 uVar1;
  
  (**(code **)(*param_1 + 0x24))(param_1,param_2);
  uVar1 = 0xffffe66b;
  if (*(int *)(param_2 + 4) != 0) {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_000438b0 @ 000438b0

undefined4 FUN_000438b0(int *param_1)

{
  (**(code **)(*param_1 + 0x28))(param_1);
  return 0xffffe674;
}


// ==== FUN_000438e0 @ 000438e0

char * FUN_000438e0(undefined4 param_1,int *param_2,undefined4 *param_3,int *param_4,char param_5)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  char *pcVar4;
  int iVar5;
  int *piVar6;
  int *local_1c;
  int local_18;
  int *local_14;
  
  iVar5 = *param_2;
  if (iVar5 == -1) {
    iVar5 = param_2[1];
    piVar6 = param_2 + 3;
  }
  else {
    piVar6 = param_2 + 1;
  }
  if (iVar5 == 0) {
    pcVar4 = "FDE has zero length";
  }
  else if (*piVar6 == 0) {
    pcVar4 = "FDE is really a CIE";
  }
  else {
    iVar1 = (int)piVar6 - *piVar6;
    if (param_5 == '\0') {
      pcVar4 = (char *)FUN_00043a70(param_1,iVar1,param_4);
      if (pcVar4 != (char *)0x0) {
        return pcVar4;
      }
    }
    else if (*param_4 != iVar1) {
      return "CIE start does not match";
    }
    iVar5 = iVar5 + (int)piVar6;
    local_1c = piVar6 + 1;
    local_18 = FUN_00045520(param_1,&local_1c,iVar5,(char)param_4[3],0);
    iVar1 = FUN_00045520(param_1,&local_1c,iVar5,*(byte *)(param_4 + 3) & 0xf,0);
    param_3[5] = 0;
    piVar6 = local_1c;
    if (*(char *)((int)param_4 + 0x1d) != '\0') {
      iVar2 = FUN_00045800(&local_1c,iVar5);
      piVar6 = (int *)(iVar2 + (int)local_1c);
      if (*(byte *)((int)param_4 + 0xd) != 0xff) {
        local_14 = local_1c;
        iVar2 = FUN_00045520(param_1,&local_1c,iVar5,*(byte *)((int)param_4 + 0xd) & 0xf,0);
        if (iVar2 != 0) {
          local_1c = local_14;
          uVar3 = FUN_00045520(param_1,&local_1c,iVar5,*(undefined1 *)((int)param_4 + 0xd),0);
          param_3[5] = uVar3;
        }
      }
    }
    *param_3 = param_2;
    param_3[1] = iVar5 - (int)param_2;
    param_3[2] = piVar6;
    param_3[3] = local_18;
    param_3[4] = iVar1 + local_18;
    pcVar4 = (char *)0x0;
  }
  return pcVar4;
}


// ==== FUN_00043a70 @ 00043a70

char * FUN_00043a70(undefined4 param_1,int *param_2,int *param_3)

{
  int *piVar1;
  undefined *puVar2;
  int iVar3;
  undefined **ppuVar4;
  int iVar5;
  uint uVar6;
  byte bVar7;
  byte bVar8;
  uint uVar9;
  byte *pbVar10;
  byte *local_30;
  byte *local_2c;
  byte local_25;
  undefined **local_24;
  byte *local_20;
  uint local_1c;
  int local_18;
  byte *local_14;
  
  *(undefined2 *)(param_3 + 3) = 0xff00;
  *(undefined4 *)((int)param_3 + 0xe) = 0;
  *(undefined4 *)((int)param_3 + 0x12) = 0;
  *(undefined4 *)((int)param_3 + 0x16) = 0;
  *(undefined4 *)((int)param_3 + 0x1a) = 0;
  *param_3 = (int)param_2;
  iVar5 = *param_2;
  piVar1 = param_2 + 1;
  if (iVar5 == -1) {
    iVar5 = param_2[1];
    piVar1 = param_2 + 3;
    iVar3 = iVar5 + 0xc;
  }
  else {
    iVar3 = iVar5 + 4;
  }
  local_2c = (byte *)((int)param_2 + iVar3);
  if (iVar5 != 0) {
    if (*piVar1 != 0) {
      return "CIE ID is not zero";
    }
    local_25 = *(byte *)(piVar1 + 1);
    if ((local_25 & 0xfd) != 1) {
      return "CIE version is not 1 or 3";
    }
    local_20 = (byte *)((int)piVar1 + 5);
    local_30 = local_20;
    do {
      bVar8 = *local_30;
      local_30 = local_30 + 1;
    } while (bVar8 != 0);
    local_24 = &__DT_PLTGOT;
    iVar5 = FUN_00045800(&local_30,local_2c);
    ppuVar4 = local_24;
    param_3[5] = iVar5;
    uVar9 = 0xfffffff9;
    local_18 = 0;
    local_1c = 0;
    local_14 = local_30;
    pbVar10 = local_30;
    do {
      if (pbVar10 == local_2c) {
        puVar2 = local_24[-8];
        fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)local_24 + -0x37fab),local_24 + -0xe244,
                (int)local_24 + -0x3858a);
        fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
        abort();
      }
      uVar9 = uVar9 + 7;
      bVar8 = *pbVar10;
      pbVar10 = pbVar10 + 1;
      uVar6 = (bVar8 & 0x7f) << ((byte)uVar9 & 0x1f);
      if ((uVar9 & 0x20) != 0) {
        uVar6 = 0;
      }
      local_1c = local_1c | uVar6;
      local_18 = local_18 + -1;
    } while ((bVar8 & 0x80) != 0);
    bVar7 = (byte)uVar9 + 7;
    uVar6 = -1 << (bVar7 & 0x1f);
    if ((bVar7 & 0x20) != 0) {
      uVar6 = 0;
    }
    if ((bVar8 >> 6 & uVar9 < 0x39) == 0) {
      uVar6 = 0;
    }
    local_30 = local_30 + -local_18;
    param_3[6] = local_1c | uVar6;
    if (local_25 == 1) {
      local_30 = local_30 + 1;
      bVar8 = *pbVar10;
    }
    else {
      bVar8 = FUN_00045800(&local_30,local_2c);
    }
    pbVar10 = local_20;
    *(byte *)((int)param_3 + 0x1e) = bVar8;
    if (*local_20 == 0x7a) {
      FUN_00045800(&local_30,local_2c);
LAB_00043c3c:
      bVar8 = *pbVar10 + 0xb4;
      if (bVar8 < 0x2f) {
        switch(ppuVar4[bVar8 - 0xd16e] + (int)ppuVar4) {
        case (undefined *)0x43c35:
          *(undefined1 *)(param_3 + 7) = 1;
        default:
          goto switchD_00043c56_caseD_43c39;
        case (undefined *)0x43c58:
          *(byte *)((int)param_3 + 0xd) = *local_30;
          break;
        case (undefined *)0x43c64:
          bVar8 = *local_30;
          *(byte *)((int)param_3 + 0xe) = bVar8;
          local_30 = local_30 + 1;
          *(char *)((int)param_3 + 0xf) = (char)local_30 - (char)param_2;
          iVar5 = FUN_00045520(param_1,&local_30,local_2c,bVar8,0);
          param_3[4] = iVar5;
          pbVar10 = pbVar10 + 1;
          goto LAB_00043c3c;
        case (undefined *)0x43c9d:
          *(byte *)(param_3 + 3) = *local_30;
          break;
        case (undefined *)0x43cb3:
          goto switchD_00043c56_caseD_43cb3;
        }
        local_30 = local_30 + 1;
        pbVar10 = pbVar10 + 1;
        goto LAB_00043c3c;
      }
      if (*pbVar10 != 0) goto switchD_00043c56_caseD_43c39;
    }
    param_3[1] = (int)local_2c - *param_3;
    param_3[2] = (int)local_30;
  }
  return (char *)0x0;
switchD_00043c56_caseD_43cb3:
  *(undefined1 *)((int)param_3 + 0x1d) = 1;
  pbVar10 = pbVar10 + 1;
  goto LAB_00043c3c;
switchD_00043c56_caseD_43c39:
  pbVar10 = pbVar10 + 1;
  goto LAB_00043c3c;
}


// ==== FUN_00044070 @ 00044070

void FUN_00044070(int *param_1,byte param_2)

{
  char cVar1;
  int iVar2;
  undefined *puVar3;
  uint uVar4;
  int local_114;
  int local_110;
  int local_108;
  int local_104;
  int local_100;
  int local_fc;
  undefined1 *puStack_f8;
  uint uStack_f4;
  undefined4 uStack_f0;
  int local_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 local_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 local_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 local_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 local_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 local_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 local_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 local_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 local_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined1 local_4c [16];
  int local_3c;
  undefined1 local_2c [8];
  int local_24;
  
  iVar2 = (**(code **)(*param_1 + 0xc))(param_1,0xffffffff);
  if (iVar2 != 0) {
    uVar4 = iVar2 - (uint)param_2;
    local_fc = param_1[1];
    puStack_f8 = local_2c;
    uStack_f4 = uVar4;
    iVar2 = dl_iterate_phdr(&LAB_00046650,&local_fc);
    if (((iVar2 != 0) && (local_24 != 0)) &&
       (cVar1 = FUN_000462c0(param_1,uVar4,local_2c,0), cVar1 != '\0')) {
      return;
    }
    pthread_rwlock_rdlock((pthread_rwlock_t *)&DAT_00050ba0);
    for (puVar3 = PTR_DAT_00050874; puVar3 < PTR_DAT_00050878; puVar3 = puVar3 + 0x10) {
      if ((*(uint *)(puVar3 + 4) <= uVar4) && (uVar4 < *(uint *)(puVar3 + 8))) {
        iVar2 = *(int *)(puVar3 + 0xc);
        pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00050ba0);
        if (iVar2 != 0) {
          iVar2 = FUN_000438e0(param_1[1],iVar2,&local_114,local_4c,0);
          if (iVar2 == 0) {
            local_6c = 0;
            uStack_68 = 0;
            uStack_64 = 0;
            uStack_60 = 0;
            local_7c = 0;
            uStack_78 = 0;
            uStack_74 = 0;
            uStack_70 = 0;
            local_8c = 0;
            uStack_88 = 0;
            uStack_84 = 0;
            uStack_80 = 0;
            local_9c = 0;
            uStack_98 = 0;
            uStack_94 = 0;
            uStack_90 = 0;
            local_ac = 0;
            uStack_a8 = 0;
            uStack_a4 = 0;
            uStack_a0 = 0;
            local_bc = 0;
            uStack_b8 = 0;
            uStack_b4 = 0;
            uStack_b0 = 0;
            local_cc = 0;
            uStack_c8 = 0;
            uStack_c4 = 0;
            uStack_c0 = 0;
            local_dc = 0;
            uStack_d8 = 0;
            uStack_d4 = 0;
            uStack_d0 = 0;
            local_ec = 0;
            uStack_e8 = 0;
            uStack_e4 = 0;
            uStack_e0 = 0;
            local_fc = 0;
            puStack_f8 = (undefined1 *)0x0;
            uStack_f4 = 0;
            uStack_f0 = 0;
            local_5c = 0;
            cVar1 = FUN_000446a0(param_1[1],&local_114,local_4c,uVar4,0,&local_fc);
            if (cVar1 != '\0') {
              param_1[0x12] = local_108;
              param_1[0x13] = local_104;
              param_1[0x14] = local_100;
              param_1[0x15] = local_3c;
              param_1[0x16] = local_ec;
              param_1[0x17] = 0;
              param_1[0x18] = 0x4000000;
              param_1[0x1a] = local_114;
              param_1[0x19] = local_110;
              param_1[0x1b] = 0;
              return;
            }
          }
        }
        goto LAB_00044240;
      }
    }
    pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00050ba0);
  }
LAB_00044240:
  *(undefined1 *)(param_1 + 0x1c) = 1;
  return;
}


// ==== FUN_00044290 @ 00044290

undefined4
FUN_00044290(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined1 *param_5)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  int local_164;
  int local_160;
  int local_15c;
  int local_158;
  int local_154;
  int local_150;
  int local_14c;
  int local_148;
  int *local_144;
  int *local_140;
  int *local_13c;
  int *local_138;
  int *local_134;
  int *local_130;
  int *local_12c;
  int *local_128;
  int local_124;
  int local_120;
  int local_11c;
  int iStack_118;
  int iStack_114;
  int iStack_110;
  int local_10c;
  undefined4 local_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 local_ec;
  int aiStack_e8 [39];
  undefined1 local_4c [28];
  undefined1 local_30;
  byte local_2e;
  undefined1 local_2c [28];
  
  iVar2 = FUN_000438e0(param_1,param_3,local_2c,local_4c,0);
  if (iVar2 != 0) {
    return 0xffffe66e;
  }
  aiStack_e8[0x1f] = 0;
  aiStack_e8[0x20] = 0;
  aiStack_e8[0x21] = 0;
  aiStack_e8[0x22] = 0;
  aiStack_e8[0x1b] = 0;
  aiStack_e8[0x1c] = 0;
  aiStack_e8[0x1d] = 0;
  aiStack_e8[0x1e] = 0;
  aiStack_e8[0x17] = 0;
  aiStack_e8[0x18] = 0;
  aiStack_e8[0x19] = 0;
  aiStack_e8[0x1a] = 0;
  aiStack_e8[0x13] = 0;
  aiStack_e8[0x14] = 0;
  aiStack_e8[0x15] = 0;
  aiStack_e8[0x16] = 0;
  aiStack_e8[0xf] = 0;
  aiStack_e8[0x10] = 0;
  aiStack_e8[0x11] = 0;
  aiStack_e8[0x12] = 0;
  aiStack_e8[0xb] = 0;
  aiStack_e8[0xc] = 0;
  aiStack_e8[0xd] = 0;
  aiStack_e8[0xe] = 0;
  aiStack_e8[7] = 0;
  aiStack_e8[8] = 0;
  aiStack_e8[9] = 0;
  aiStack_e8[10] = 0;
  aiStack_e8[3] = 0;
  aiStack_e8[4] = 0;
  aiStack_e8[5] = 0;
  aiStack_e8[6] = 0;
  local_ec = 0;
  aiStack_e8[0] = 0;
  aiStack_e8[1] = 0;
  aiStack_e8[2] = 0;
  local_fc = 0;
  iStack_f8 = 0;
  uStack_f4 = 0;
  uStack_f0 = 0;
  aiStack_e8[0x23] = 0;
  cVar1 = FUN_000446a0(param_1,local_2c,local_4c,param_2,0,&local_fc);
  if (cVar1 == '\0') {
    return 0xffffe66e;
  }
  switch(local_fc) {
  case 0:
    iVar2 = FUN_000459e0(uStack_f4,param_1,param_4,0);
    goto LAB_000443d0;
  case 1:
    piVar6 = param_4 + 2;
    break;
  case 2:
    piVar6 = param_4 + 3;
    break;
  case 3:
    piVar6 = param_4 + 1;
    break;
  case 5:
    piVar6 = param_4 + 6;
    break;
  case 6:
    piVar6 = param_4 + 5;
    break;
  case 7:
    piVar6 = param_4 + 4;
    break;
  case 0xfffffffe:
  case 4:
    piVar6 = param_4 + 7;
    break;
  case 0xffffffff:
    piVar6 = param_4 + 10;
    break;
  default:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getRegister","unsupported x86 register");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  iVar2 = iStack_f8 + *piVar6;
LAB_000443d0:
  local_148 = *param_4;
  local_12c = param_4 + 1;
  local_14c = param_4[1];
  local_130 = param_4 + 2;
  local_150 = param_4[2];
  local_134 = param_4 + 3;
  local_154 = param_4[3];
  local_158 = param_4[4];
  local_15c = param_4[5];
  local_160 = param_4[6];
  local_120 = param_4[8];
  local_124 = param_4[9];
  local_10c = param_4[0xf];
  local_138 = param_4 + 4;
  local_11c = param_4[0xb];
  iStack_118 = param_4[0xc];
  iStack_114 = param_4[0xd];
  iStack_110 = param_4[0xe];
  local_13c = param_4 + 5;
  local_140 = param_4 + 6;
  local_144 = param_4 + 7;
  local_128 = param_4 + 0xb;
  piVar6 = aiStack_e8;
  uVar7 = 0;
  iVar8 = 0;
  local_164 = iVar2;
  do {
    uVar3 = (uint)local_2e;
    if (*piVar6 == 0) {
      if (uVar7 == uVar3) {
        piVar5 = param_4;
        switch(uVar3) {
        case 0:
          break;
        case 1:
          piVar5 = local_130;
          break;
        case 2:
          piVar5 = local_134;
          break;
        case 3:
          piVar5 = local_12c;
          break;
        case 4:
          piVar5 = local_144;
          break;
        case 5:
          piVar5 = local_140;
          break;
        case 6:
          piVar5 = local_13c;
          break;
        case 7:
          piVar5 = local_138;
          break;
        default:
          fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getRegister","unsupported x86 register");
          fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
          abort();
        }
        iVar8 = *piVar5;
      }
    }
    else if (uVar7 == uVar3) {
      iVar8 = FUN_000453f0(param_1,param_4,iVar2,piVar6);
    }
    else {
      if (7 < uVar7) {
        return 0xffffe672;
      }
      iVar4 = FUN_000453f0(param_1,param_4,iVar2,piVar6);
      if (7 < uVar7) {
        fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","setRegister","unsupported x86 register");
        fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
        abort();
      }
      piVar5 = &local_148;
      switch(uVar7) {
      case 1:
        piVar5 = &local_150;
        break;
      case 2:
        piVar5 = &local_154;
        break;
      case 3:
        piVar5 = &local_14c;
        break;
      case 4:
        piVar5 = &local_164;
        break;
      case 5:
        piVar5 = &local_160;
        break;
      case 6:
        piVar5 = &local_15c;
        break;
      case 7:
        piVar5 = &local_158;
      }
      *piVar5 = iVar4;
    }
    uVar7 = uVar7 + 1;
    piVar6 = piVar6 + 4;
    if (uVar7 == 9) {
      *param_5 = local_30;
      *param_4 = local_148;
      param_4[1] = local_14c;
      param_4[2] = local_150;
      param_4[3] = local_154;
      param_4[4] = local_158;
      param_4[5] = local_15c;
      param_4[6] = local_160;
      param_4[7] = local_164;
      param_4[9] = local_124;
      param_4[8] = local_120;
      param_4[10] = iVar8;
      local_128[4] = local_10c;
      *local_128 = local_11c;
      local_128[1] = iStack_118;
      local_128[2] = iStack_114;
      local_128[3] = iStack_110;
      return 1;
    }
  } while( true );
}


// ==== FUN_000446a0 @ 000446a0

undefined4
FUN_000446a0(undefined4 param_1,int *param_2,int *param_3,int param_4,undefined4 param_5,int param_6
            )

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  byte bVar5;
  undefined4 uVar6;
  char *__format;
  uint uVar7;
  int iVar8;
  undefined **ppuVar9;
  longlong lVar10;
  undefined4 auStack_f0 [37];
  uint local_5c;
  int local_58;
  undefined4 local_54;
  int local_50;
  int local_4c;
  int local_48;
  uint local_44;
  uint *local_40;
  undefined4 local_38;
  uint local_2c;
  uint local_20;
  undefined **local_1c;
  byte *local_18;
  byte *local_14;
  
  ppuVar9 = &__DT_PLTGOT;
  local_5c = param_3[2];
  local_58 = param_3[1] + *param_3;
  local_54 = 0xffffffff;
  local_50 = param_2[2];
  local_4c = param_2[1] + *param_2;
  local_48 = param_4 - param_2[3];
  local_40 = &local_5c;
  local_38 = 0;
  local_1c = &__DT_PLTGOT;
  do {
    local_14 = (byte *)*local_40;
    local_18 = (byte *)local_40[1];
    if ((local_14 < (byte *)local_40[1]) && (local_44 = local_40[2], local_40[2] != 0)) {
      local_2c = 0;
      do {
        bVar5 = *local_14;
        uVar7 = (uint)bVar5;
        local_14 = local_14 + 1;
        if (uVar7 < 0x30) {
                    /* WARNING: Could not recover jumptable at 0x0004475b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          uVar6 = (*(code *)(ppuVar9[uVar7 - 0xd111] + (int)ppuVar9))();
          return uVar6;
        }
        uVar7 = uVar7 & 0x3f;
        bVar5 = bVar5 & 0xc0;
        if (bVar5 == 0x40) {
          local_2c = local_2c + uVar7 * param_3[5];
        }
        else if (bVar5 == 0xc0) {
          if (8 < (byte)uVar7) {
            __format = (char *)((int)ppuVar9 + -0x37f46);
            goto LAB_000452e7;
          }
          if (*(char *)(param_6 + 0x18 + uVar7 * 0x10) != '\0') {
            uVar6 = auStack_f0[uVar7 * 4 + 1];
            uVar3 = auStack_f0[uVar7 * 4 + 2];
            uVar4 = auStack_f0[uVar7 * 4 + 3];
            puVar1 = (undefined4 *)(param_6 + 0x14 + uVar7 * 0x10);
            *puVar1 = auStack_f0[uVar7 * 4];
            puVar1[1] = uVar6;
            puVar1[2] = uVar3;
            puVar1[3] = uVar4;
          }
        }
        else {
          if (bVar5 != 0x80) {
            return 0;
          }
          if (8 < (byte)uVar7) {
            __format = (char *)((int)ppuVar9 + -0x3737e);
LAB_000452e7:
            fprintf((FILE *)(ppuVar9[-8] + 0xa8),__format,uVar7,0);
            return 0;
          }
          local_20 = uVar7;
          lVar10 = FUN_00045800(&local_14,local_18);
          uVar7 = local_20;
          iVar2 = param_3[6];
          iVar8 = local_20 * 0x10;
          if (*(char *)(param_6 + 0x18 + iVar8) == '\0') {
            puVar1 = (undefined4 *)(param_6 + 0x14 + iVar8);
            uVar6 = puVar1[1];
            uVar3 = puVar1[2];
            uVar4 = puVar1[3];
            auStack_f0[local_20 * 4] = *puVar1;
            auStack_f0[uVar7 * 4 + 1] = uVar6;
            auStack_f0[uVar7 * 4 + 2] = uVar3;
            auStack_f0[uVar7 * 4 + 3] = uVar4;
            *(undefined1 *)(iVar8 + param_6 + 0x18) = 1;
          }
          *(undefined4 *)(param_6 + 0x14 + iVar8) = 2;
          *(int *)(param_6 + 0x20 + iVar8) = (int)((ulonglong)(lVar10 * iVar2) >> 0x20);
          *(int *)(param_6 + 0x1c + iVar8) = (int)(lVar10 * iVar2);
          ppuVar9 = local_1c;
        }
      } while ((local_14 < local_18) && (local_2c < local_44));
    }
    local_40 = local_40 + 3;
    if (local_40 == &local_44) {
      return CONCAT31((int3)((uint)local_40 >> 8),1);
    }
  } while( true );
}


// ==== FUN_000453f0 @ 000453f0

undefined4 FUN_000453f0(undefined4 param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = 0;
  switch(*param_4) {
  case 1:
    break;
  case 2:
    uVar1 = *(undefined4 *)(param_4[2] + param_3);
    break;
  default:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getSavedRegister",
            "unsupported restore location for register");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  case 4:
    switch(param_4[2]) {
    case 1:
      uVar1 = param_2[2];
      break;
    case 2:
      uVar1 = param_2[3];
      break;
    case 3:
      uVar1 = param_2[1];
      break;
    case 5:
      uVar1 = param_2[6];
      break;
    case 6:
      uVar1 = param_2[5];
      break;
    case 7:
      uVar1 = param_2[4];
      break;
    case 0xfffffffe:
    case 4:
      param_2 = param_2 + 7;
    case 0:
      uVar1 = *param_2;
      break;
    case 0xffffffff:
      uVar1 = param_2[10];
      break;
    default:
      fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getRegister","unsupported x86 register");
      fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    break;
  case 5:
    puVar2 = (undefined4 *)FUN_000459e0(param_4[2],param_1,param_2,param_3);
    uVar1 = *puVar2;
    break;
  case 6:
    uVar1 = FUN_000459e0(param_4[2],param_1,param_2,param_3);
    return uVar1;
  }
  return uVar1;
}


// ==== FUN_00045520 @ 00045520

/* WARNING: Type propagation algorithm not settling */

byte * FUN_00045520(undefined4 param_1,int *param_2,ushort *param_3,byte param_4,int param_5)

{
  byte bVar1;
  ushort *puVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  ushort *puVar6;
  byte *pbVar7;
  ushort *puVar8;
  uint local_20;
  
  if (0xc < (param_4 & 0xf)) {
switchD_00045555_caseD_5:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getEncodedP","unknown pointer encoding");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  }
  puVar2 = (ushort *)*param_2;
  switch(param_4 & 0xf) {
  case 0:
  case 3:
  case 0xb:
    pbVar7 = *(byte **)puVar2;
    puVar6 = puVar2 + 2;
    break;
  case 1:
    pbVar7 = (byte *)FUN_00045800(param_2,param_3);
    goto LAB_00045637;
  case 2:
    pbVar7 = (byte *)(uint)*puVar2;
    goto LAB_00045632;
  case 4:
  case 0xc:
    pbVar7 = *(byte **)puVar2;
    puVar6 = puVar2 + 4;
    break;
  default:
    goto switchD_00045555_caseD_5;
  case 9:
    uVar4 = 0xfffffff9;
    local_20 = 0;
    puVar6 = puVar2;
    puVar8 = puVar2;
    do {
      if (puVar6 == param_3) {
        fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getSLEB128","truncated sleb128 expression");
        fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
        abort();
      }
      uVar4 = uVar4 + 7;
      bVar1 = (byte)*puVar6;
      puVar6 = (ushort *)((int)puVar6 + 1);
      uVar5 = (bVar1 & 0x7f) << ((byte)uVar4 & 0x1f);
      if ((uVar4 & 0x20) != 0) {
        uVar5 = 0;
      }
      local_20 = local_20 | uVar5;
      puVar8 = (ushort *)((int)puVar8 + 1);
    } while ((bVar1 & 0x80) != 0);
    bVar3 = (byte)uVar4 + 7;
    *param_2 = (int)puVar8;
    uVar5 = -1 << (bVar3 & 0x1f);
    if ((bVar3 & 0x20) != 0) {
      uVar5 = 0;
    }
    if ((bVar1 >> 6 & uVar4 < 0x39) == 0) {
      uVar5 = 0;
    }
    pbVar7 = (byte *)(local_20 | uVar5);
    goto LAB_00045637;
  case 10:
    pbVar7 = (byte *)(int)(short)*puVar2;
LAB_00045632:
    puVar6 = puVar2 + 1;
  }
  *param_2 = (int)puVar6;
LAB_00045637:
  switch(param_4 >> 4 & 7) {
  case 0:
    goto switchD_0004564d_caseD_0;
  case 1:
    pbVar7 = pbVar7 + (int)puVar2;
switchD_0004564d_caseD_0:
    if ((param_4 & 0x80) != 0) {
LAB_00045656:
      pbVar7 = *(byte **)pbVar7;
    }
    return pbVar7;
  case 2:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_textrel pointer encoding not supported");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  case 3:
    if (param_5 == 0) {
      fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getEncodedP",
              "DW_EH_PE_datarel is invalid with a datarelBase of 0");
      fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
      abort();
    }
    pbVar7 = pbVar7 + param_5;
    if ((param_4 & 0x80) == 0) {
      return pbVar7;
    }
    goto LAB_00045656;
  case 4:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_funcrel pointer encoding not supported");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  case 5:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getEncodedP",
            "DW_EH_PE_aligned pointer encoding not supported");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  default:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getEncodedP","unknown pointer encoding");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  }
}


// ==== FUN_00045800 @ 00045800

undefined8 FUN_00045800(int *param_1,byte *param_2)

{
  byte *pbVar1;
  uint uVar2;
  ushort uVar3;
  byte bVar4;
  uint uVar5;
  byte *pbVar6;
  
  pbVar1 = (byte *)*param_1;
  if (pbVar1 != param_2) {
    bVar4 = *pbVar1;
    uVar5 = 0;
    pbVar6 = pbVar1 + 1;
    if (-1 < (char)bVar4) {
      uVar2 = bVar4 & 0x7f;
LAB_0004595e:
      *param_1 = (int)pbVar6;
      return CONCAT44(uVar5,uVar2);
    }
    if (pbVar6 != param_2) {
      uVar2 = (uint)(pbVar1[1] & 0x7f) << 7 | bVar4 & 0x7f;
      pbVar6 = pbVar1 + 2;
      if (-1 < (char)pbVar1[1]) goto LAB_0004595e;
      if (pbVar6 != param_2) {
        uVar3 = CONCAT11(pbVar1[2],pbVar1[2]) & 0x7fff;
        uVar2 = uVar2 | (uint)(uVar3 >> 8) << 0xe;
        pbVar6 = pbVar1 + 3;
        if (-1 < (char)uVar3) goto LAB_0004595e;
        if (pbVar6 != param_2) {
          uVar3 = CONCAT11(pbVar1[3],pbVar1[3]) & 0x7fff;
          uVar2 = uVar2 | (uint)(uVar3 >> 8) << 0x15;
          pbVar6 = pbVar1 + 4;
          if (-1 < (char)uVar3) goto LAB_0004595e;
          if (pbVar6 != param_2) {
            bVar4 = pbVar1[4] & 0x7f;
            uVar5 = (uint)(bVar4 >> 4);
            uVar2 = uVar2 | (uint)bVar4 << 0x1c;
            pbVar6 = pbVar1 + 5;
            if (-1 < (char)pbVar1[4]) goto LAB_0004595e;
            if (pbVar6 != param_2) {
              uVar3 = CONCAT11(pbVar1[5],pbVar1[5]) & 0x7fff;
              uVar5 = uVar5 + (uint)(uVar3 >> 8) * 8;
              pbVar6 = pbVar1 + 6;
              if (-1 < (char)uVar3) goto LAB_0004595e;
              if (pbVar6 != param_2) {
                uVar3 = CONCAT11(pbVar1[6],pbVar1[6]) & 0x7fff;
                uVar5 = uVar5 | (uint)(uVar3 >> 8) << 10;
                pbVar6 = pbVar1 + 7;
                if (-1 < (char)uVar3) goto LAB_0004595e;
                if (pbVar6 != param_2) {
                  uVar3 = CONCAT11(pbVar1[7],pbVar1[7]) & 0x7fff;
                  uVar5 = uVar5 | (uint)(uVar3 >> 8) << 0x11;
                  pbVar6 = pbVar1 + 8;
                  if (-1 < (char)uVar3) goto LAB_0004595e;
                  if (pbVar6 != param_2) {
                    uVar3 = CONCAT11(pbVar1[8],pbVar1[8]) & 0x7fff;
                    uVar5 = uVar5 | (uint)(uVar3 >> 8) << 0x18;
                    pbVar6 = pbVar1 + 9;
                    if (-1 < (char)uVar3) goto LAB_0004595e;
                    if (pbVar6 != param_2) {
                      bVar4 = *pbVar6;
                      if ((bVar4 & 0x7e) == 0) {
                        pbVar6 = pbVar1 + 10;
                        if (-1 < (char)bVar4) {
                          uVar5 = uVar5 | (uint)bVar4 << 0x1f;
                          goto LAB_0004595e;
                        }
                        if (pbVar6 == param_2) goto LAB_0004596c;
                      }
                      fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getULEB128",
                              "malformed uleb128 expression");
                      fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
                      abort();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
LAB_0004596c:
  fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getULEB128","truncated uleb128 expression");
  fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== FUN_000459e0 @ 000459e0

uint FUN_000459e0(byte *param_1,undefined4 param_2,uint *param_3,uint param_4)

{
  byte bVar1;
  undefined *puVar2;
  int iVar3;
  byte *pbVar4;
  uint *puVar5;
  uint *puVar6;
  byte bVar7;
  byte bVar8;
  uint uVar9;
  undefined **ppuVar10;
  uint uVar11;
  byte *pbVar12;
  uint uVar13;
  uint *puVar14;
  byte *local_1dc;
  undefined **local_1d8;
  byte *local_1d4;
  byte *local_1d0;
  uint *local_1cc;
  byte *local_1c8;
  uint *local_1c4;
  uint *local_1c0;
  uint *local_1bc;
  uint *local_1b8;
  uint *local_1b4;
  uint *local_1b0;
  uint *local_1ac;
  uint *local_1a8;
  uint local_1a4;
  uint local_19c [99];
  
  ppuVar10 = &__DT_PLTGOT;
  local_1dc = param_1;
  iVar3 = FUN_00045800(&local_1dc,param_1 + 0x14);
  local_1d4 = local_1dc + iVar3;
  local_19c[0] = param_4;
  if (local_1dc < local_1d4) {
    local_1ac = param_3 + 4;
    local_1b0 = param_3 + 5;
    local_1cc = param_3 + 7;
    local_1b4 = param_3 + 6;
    local_1b8 = param_3 + 1;
    local_1bc = param_3 + 3;
    local_1c0 = param_3 + 2;
    local_1a8 = param_3 + 10;
    local_1d8 = &__DT_PLTGOT;
    puVar14 = local_19c;
    do {
      pbVar12 = local_1dc + 1;
      bVar1 = *local_1dc;
      puVar5 = puVar14;
      switch(ppuVar10[(byte)(bVar1 + 0x80) - 0xd0be] + (int)ppuVar10) {
      case (undefined *)0x45a79:
        uVar9 = *(uint *)(local_1dc + 1);
        local_1dc = local_1dc + 5;
        goto LAB_00045a90;
      case (undefined *)0x45ac8:
        local_1a4 = (uint)bVar1;
        uVar13 = 0;
        uVar9 = 0xfffffff9;
        pbVar4 = pbVar12;
        local_1c8 = pbVar12;
        do {
          if (pbVar4 == local_1d4) {
            puVar2 = local_1d8[-8];
            local_1dc = pbVar12;
            local_1c4 = puVar14;
            fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)local_1d8 + -0x37fab),local_1d8 + -0xe244,
                    (int)local_1d8 + -0x3858a);
            fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
            abort();
          }
          uVar9 = uVar9 + 7;
          bVar8 = *pbVar4;
          local_1d0 = (byte *)(uint)bVar8;
          pbVar4 = pbVar4 + 1;
          uVar11 = ((uint)local_1d0 & 0x7f) << ((byte)uVar9 & 0x1f);
          if ((uVar9 & 0x20) != 0) {
            uVar11 = 0;
          }
          uVar13 = uVar13 | uVar11;
          local_1dc = local_1c8 + 1;
          local_1c8 = local_1dc;
        } while ((bVar8 & 0x80) != 0);
        bVar7 = (byte)uVar9 + 7;
        uVar11 = -1 << (bVar7 & 0x1f);
        if ((bVar7 & 0x20) != 0) {
          uVar11 = 0;
        }
        if ((bVar8 >> 6 & uVar9 < 0x39) == 0) {
          uVar11 = 0;
        }
        if (9 < (byte)(bVar1 + 0x92)) {
          puVar2 = local_1d8[-8];
          local_1c4 = puVar14;
          fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)local_1d8 + -0x37fab),
                  (int)local_1d8 + -0x3741f,(int)local_1d8 + -0x37577);
          fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
          abort();
        }
        uVar13 = uVar13 | uVar11;
        puVar5 = local_1a8;
        local_1c4 = puVar14;
        switch(local_1d8[(byte)(bVar1 + 0x92) - 0xcfac] + (int)local_1d8) {
        default:
switchD_00045b75_caseD_45b77:
          puVar5 = local_1cc;
          break;
        case (undefined *)0x45e0f:
switchD_00045b75_caseD_45e0f:
          puVar5 = param_3;
          break;
        case (undefined *)0x45e18:
switchD_00045b75_caseD_45e18:
          puVar5 = local_1c0;
          break;
        case (undefined *)0x45e1e:
switchD_00045b75_caseD_45e1e:
          puVar5 = local_1bc;
          break;
        case (undefined *)0x45e24:
switchD_00045b75_caseD_45e24:
          puVar5 = local_1b8;
          break;
        case (undefined *)0x45e2a:
switchD_00045b75_caseD_45e2a:
          puVar5 = local_1b4;
          break;
        case (undefined *)0x45e30:
switchD_00045b75_caseD_45e30:
          puVar5 = local_1b0;
          break;
        case (undefined *)0x45e36:
switchD_00045b75_caseD_45e36:
          puVar5 = local_1ac;
          break;
        case (undefined *)0x45e40:
          break;
        }
switchD_00045b75_caseD_45e40:
        local_1c4[1] = uVar13 + *puVar5;
        ppuVar10 = local_1d8;
        puVar14 = local_1c4;
        goto LAB_00045a93;
      case (undefined *)0x45b80:
        puVar14[1] = bVar1 - 0x30;
        local_1dc = pbVar12;
        goto LAB_00045a93;
      case (undefined *)0x45b90:
        if (7 < (byte)(bVar1 + 0xb0)) {
          puVar2 = ppuVar10[-8];
          local_1dc = pbVar12;
          fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)ppuVar10 + -0x37fab),
                  (int)ppuVar10 + -0x3741f,(int)ppuVar10 + -0x37577);
          fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
          abort();
        }
        puVar5 = param_3;
        local_1dc = pbVar12;
        switch(ppuVar10[(byte)(bVar1 + 0xb0) - 0xcf98] + (int)ppuVar10) {
        case (undefined *)0x45bb1:
          goto switchD_00045baf_caseD_45bb1;
        case (undefined *)0x45bb5:
          goto switchD_00045baf_caseD_45bb5;
        case (undefined *)0x45d0a:
          goto switchD_00045baf_caseD_45d0a;
        case (undefined *)0x45d15:
          goto switchD_00045baf_caseD_45d15;
        case (undefined *)0x45d20:
          goto switchD_00045baf_caseD_45d20;
        case (undefined *)0x45d2b:
          goto switchD_00045baf_caseD_45d2b;
        case (undefined *)0x45d36:
          goto switchD_00045baf_caseD_45d36;
        }
switchD_00045baf_caseD_45cff:
        uVar9 = *local_1cc;
LAB_00045a90:
        puVar14[1] = uVar9;
LAB_00045a93:
        puVar5 = puVar14 + 1;
        break;
      case (undefined *)0x45bbc:
        uVar9 = *(uint *)(local_1dc + 1);
        local_1dc = local_1dc + 9;
        goto LAB_00045a90;
      case (undefined *)0x45bc7:
        puVar5 = puVar14 + -1;
        if (*puVar14 == 0) {
          local_1dc = local_1dc + 3;
        }
        else {
          local_1dc = local_1dc + 3 + *(short *)(local_1dc + 1);
        }
        break;
      case (undefined *)0x45be9:
        uVar9 = (uint)(*puVar14 <= puVar14[-1]);
        goto LAB_0004600d;
      case (undefined *)0x45bf8:
        uVar9 = (uint)*(short *)(local_1dc + 1);
        local_1dc = local_1dc + 3;
        goto LAB_00045a90;
      case (undefined *)0x45c04:
        local_1d0 = (byte *)0x0;
        uVar9 = 0xfffffff9;
        pbVar4 = pbVar12;
        local_1c8 = pbVar12;
        do {
          if (pbVar4 == local_1d4) {
            puVar2 = local_1d8[-8];
            local_1dc = pbVar12;
            local_1c4 = puVar14;
            fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)local_1d8 + -0x37fab),local_1d8 + -0xe244,
                    (int)local_1d8 + -0x3858a);
            fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
            abort();
          }
          uVar9 = uVar9 + 7;
          bVar1 = *pbVar4;
          pbVar4 = pbVar4 + 1;
          uVar13 = (bVar1 & 0x7f) << ((byte)uVar9 & 0x1f);
          if ((uVar9 & 0x20) != 0) {
            uVar13 = 0;
          }
          local_1d0 = (byte *)((uint)local_1d0 | uVar13);
          local_1c8 = local_1c8 + 1;
        } while ((bVar1 & 0x80) != 0);
        bVar8 = (byte)uVar9 + 7;
        uVar13 = -1 << (bVar8 & 0x1f);
        if ((bVar8 & 0x20) != 0) {
          uVar13 = 0;
        }
        if ((bVar1 >> 6 & uVar9 < 0x39) == 0) {
          uVar13 = 0;
        }
        puVar14[1] = (uint)local_1d0 | uVar13;
        ppuVar10 = local_1d8;
        puVar5 = puVar14 + 1;
        local_1dc = local_1c8;
        local_1c4 = puVar14;
        break;
      case (undefined *)0x45ca2:
        uVar9 = *puVar14;
        local_1dc = pbVar12;
        goto LAB_00045a90;
      case (undefined *)0x45ca9:
        uVar9 = (int)puVar14[-1] / (int)*puVar14;
        goto LAB_00045fa2;
      case (undefined *)0x45cb4:
        puVar14[-1] = puVar14[-1] << ((byte)*puVar14 & 0x1f);
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45cc1:
        uVar9 = (uint)(puVar14[-1] != *puVar14);
LAB_0004600d:
        puVar14[-1] = uVar9;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45cd0:
        local_1dc = pbVar12;
        iVar3 = FUN_00045800(&local_1dc,local_1d4);
        if (9 < iVar3 + 2U) {
          puVar2 = ppuVar10[-8];
          fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)ppuVar10 + -0x37fab),
                  (int)ppuVar10 + -0x3741f,(int)ppuVar10 + -0x37577);
          fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
          abort();
        }
        puVar5 = local_1a8;
        switch(ppuVar10[iVar3 + -0xcfa0] + (int)ppuVar10) {
        case (undefined *)0x45bb1:
switchD_00045baf_caseD_45bb1:
          puVar5 = local_1c0;
        case (undefined *)0x45bb5:
switchD_00045baf_caseD_45bb5:
          uVar9 = *puVar5;
          break;
        default:
          goto switchD_00045baf_caseD_45cff;
        case (undefined *)0x45d0a:
switchD_00045baf_caseD_45d0a:
          uVar9 = *local_1bc;
          break;
        case (undefined *)0x45d15:
switchD_00045baf_caseD_45d15:
          uVar9 = *local_1b8;
          break;
        case (undefined *)0x45d20:
switchD_00045baf_caseD_45d20:
          uVar9 = *local_1b4;
          break;
        case (undefined *)0x45d2b:
switchD_00045baf_caseD_45d2b:
          uVar9 = *local_1b0;
          break;
        case (undefined *)0x45d36:
switchD_00045baf_caseD_45d36:
          uVar9 = *local_1ac;
          break;
        case (undefined *)0x46029:
          uVar9 = *param_3;
        }
        goto LAB_00045a90;
      case (undefined *)0x45d41:
        local_1dc = pbVar12;
        local_1c4 = puVar14;
        local_1a4 = FUN_00045800(&local_1dc,local_1d4);
        uVar13 = 0;
        uVar9 = 0xfffffff9;
        pbVar12 = local_1dc;
        pbVar4 = local_1dc;
        do {
          local_1d0 = pbVar12;
          if (pbVar4 == local_1d4) {
            puVar2 = local_1d8[-8];
            fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)local_1d8 + -0x37fab),local_1d8 + -0xe244,
                    (int)local_1d8 + -0x3858a);
            fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
            abort();
          }
          uVar9 = uVar9 + 7;
          bVar1 = *pbVar4;
          local_1c8 = (byte *)(uint)bVar1;
          pbVar4 = pbVar4 + 1;
          uVar11 = ((uint)local_1c8 & 0x7f) << ((byte)uVar9 & 0x1f);
          if ((uVar9 & 0x20) != 0) {
            uVar11 = 0;
          }
          uVar13 = uVar13 | uVar11;
          pbVar12 = local_1d0 + 1;
        } while ((bVar1 & 0x80) != 0);
        uVar11 = (uint)local_1d0 >> 8;
        local_1d0 = (byte *)CONCAT31((int3)uVar11,uVar9 < 0x39);
        bVar8 = (byte)uVar9 + 7;
        uVar11 = -1 << (bVar8 & 0x1f);
        if ((bVar8 & 0x20) != 0) {
          uVar11 = 0;
        }
        if ((uVar9 < 0x39 & bVar1 >> 6) == 0) {
          uVar11 = 0;
        }
        local_1dc = pbVar12;
        if (9 < local_1a4 + 2) {
          puVar2 = local_1d8[-8];
          fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)local_1d8 + -0x37fab),
                  (int)local_1d8 + -0x3741f,(int)local_1d8 + -0x37577);
          fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
          abort();
        }
        uVar13 = uVar13 | uVar11;
        puVar5 = local_1a8;
        switch(local_1d8[local_1a4 - 0xcfb4] + (int)local_1d8) {
        default:
          goto switchD_00045b75_caseD_45b77;
        case (undefined *)0x45e0f:
          goto switchD_00045b75_caseD_45e0f;
        case (undefined *)0x45e18:
          goto switchD_00045b75_caseD_45e18;
        case (undefined *)0x45e1e:
          goto switchD_00045b75_caseD_45e1e;
        case (undefined *)0x45e24:
          goto switchD_00045b75_caseD_45e24;
        case (undefined *)0x45e2a:
          goto switchD_00045b75_caseD_45e2a;
        case (undefined *)0x45e30:
          goto switchD_00045b75_caseD_45e30;
        case (undefined *)0x45e36:
          goto switchD_00045b75_caseD_45e36;
        case (undefined *)0x45e40:
          goto switchD_00045b75_caseD_45e40;
        }
      case (undefined *)0x45e4a:
        puVar6 = (uint *)*puVar14;
        pbVar12 = local_1dc + 2;
        pbVar4 = local_1dc + 1;
        local_1dc = pbVar12;
        if (7 < (byte)(*pbVar4 - 1)) {
switchD_00045e6d_caseD_4620e:
          puVar2 = ppuVar10[-8];
          fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)ppuVar10 + -0x37fab),
                  (int)ppuVar10 + -0x37d22,(int)ppuVar10 + -0x37efb);
          fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
          abort();
        }
        switch(ppuVar10[(byte)(*pbVar4 - 1) - 0xcfbe] + (int)ppuVar10) {
        case (undefined *)0x45e6f:
          *puVar14 = (uint)(byte)*puVar6;
          break;
        case (undefined *)0x45e7b:
          goto switchD_00045e6d_caseD_45e7b;
        case (undefined *)0x4601f:
          *puVar14 = (uint)(ushort)*puVar6;
          break;
        default:
          goto switchD_00045e6d_caseD_4620e;
        }
        break;
      case (undefined *)0x45e79:
        puVar6 = (uint *)*puVar14;
        local_1dc = pbVar12;
switchD_00045e6d_caseD_45e7b:
        *puVar14 = *puVar6;
        break;
      case (undefined *)0x45e84:
        uVar9 = (uint)local_1dc[1];
        goto LAB_00045e8e;
      case (undefined *)0x45e8a:
        uVar9 = (uint)(char)local_1dc[1];
LAB_00045e8e:
        local_1dc = local_1dc + 2;
        goto LAB_00045a90;
      case (undefined *)0x45e96:
        uVar9 = (uint)*(ushort *)(local_1dc + 1);
        local_1dc = local_1dc + 3;
        goto LAB_00045a90;
      case (undefined *)0x45ea2:
        local_1dc = pbVar12;
        uVar9 = FUN_00045800(&local_1dc,local_1d4);
        goto LAB_00045a90;
      case (undefined *)0x45ebb:
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45ec3:
        uVar9 = puVar14[-1];
        local_1dc = pbVar12;
        goto LAB_00045a90;
      case (undefined *)0x45ecb:
        uVar9 = puVar14[-(uint)local_1dc[1]];
        local_1dc = local_1dc + 2;
        goto LAB_00045a90;
      case (undefined *)0x45ee2:
        uVar9 = *puVar14;
        *puVar14 = puVar14[-1];
        puVar14[-1] = uVar9;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45ef1:
        uVar9 = *puVar14;
        *puVar14 = puVar14[-1];
        puVar14[-1] = puVar14[-2];
        puVar14[-2] = uVar9;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45f06:
        local_1dc = pbVar12;
        if ((int)*puVar14 < 0) {
          *puVar14 = -*puVar14;
        }
        break;
      case (undefined *)0x45f19:
        puVar14[-1] = puVar14[-1] & *puVar14;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45f26:
        puVar14[-1] = puVar14[-1] - *puVar14;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45f33:
        puVar14[-1] = (int)puVar14[-1] % (int)*puVar14;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45f44:
        *puVar14 = -*puVar14;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45f4b:
        puVar14[-1] = puVar14[-1] ^ *puVar14;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45f58:
        uVar9 = (uint)(*puVar14 < puVar14[-1]);
        goto LAB_0004600d;
      case (undefined *)0x45f67:
        uVar9 = (uint)(puVar14[-1] <= *puVar14);
        goto LAB_0004600d;
      case (undefined *)0x45f76:
        uVar9 = (uint)(puVar14[-1] < *puVar14);
        goto LAB_0004600d;
      case (undefined *)0x45f85:
        local_1dc = local_1dc + *(short *)(local_1dc + 1) + 3;
        break;
      case (undefined *)0x45f96:
        uVar9 = *(uint *)*puVar14;
        goto LAB_00045fa2;
      case (undefined *)0x45f9c:
        uVar9 = puVar14[-1] * *puVar14;
LAB_00045fa2:
        puVar14[-1] = uVar9;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45fad:
        *puVar14 = ~*puVar14;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45fb4:
        puVar14[-1] = puVar14[-1] | *puVar14;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45fc1:
        puVar14[-1] = puVar14[-1] + *puVar14;
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45fce:
        local_1dc = pbVar12;
        iVar3 = FUN_00045800(&local_1dc,local_1d4);
        *puVar14 = *puVar14 + iVar3;
        break;
      case (undefined *)0x45fe9:
        puVar14[-1] = puVar14[-1] >> ((byte)*puVar14 & 0x1f);
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x45ff6:
        puVar14[-1] = (int)puVar14[-1] >> ((byte)*puVar14 & 0x1f);
        puVar5 = puVar14 + -1;
        local_1dc = pbVar12;
        break;
      case (undefined *)0x46003:
        uVar9 = (uint)(puVar14[-1] == *puVar14);
        goto LAB_0004600d;
      case (undefined *)0x46169:
        puVar2 = ppuVar10[-8];
        local_1dc = pbVar12;
        fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)ppuVar10 + -0x37fab),(int)ppuVar10 + -0x37d22,
                (int)ppuVar10 + -0x37af7);
        fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
        abort();
      case (undefined *)0x461a0:
        puVar2 = ppuVar10[-8];
        local_1dc = pbVar12;
        fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)ppuVar10 + -0x37fab),(int)ppuVar10 + -0x37d22,
                ppuVar10 + -0xdccd);
        fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
        abort();
      default:
        puVar2 = ppuVar10[-8];
        local_1dc = pbVar12;
        fprintf((FILE *)(puVar2 + 0xa8),(char *)((int)ppuVar10 + -0x37fab),(int)ppuVar10 + -0x37d22,
                (int)ppuVar10 + -0x3786e);
        fflush((FILE *)(puVar2 + 0xa8));
                    /* WARNING: Subroutine does not return */
        abort();
      }
      puVar14 = puVar5;
    } while (local_1dc < local_1d4);
    param_4 = *puVar5;
  }
  return param_4;
}


// ==== FUN_000462c0 @ 000462c0

undefined4 FUN_000462c0(int param_1,uint param_2,int *param_3,int param_4)

{
  int iVar1;
  undefined *__src;
  char cVar2;
  int *piVar3;
  undefined *__dest;
  size_t __n;
  byte local_10c;
  int local_f4;
  undefined4 local_f0;
  int local_e8;
  int local_e4;
  undefined4 local_e0;
  undefined1 local_dc [16];
  undefined4 local_cc;
  undefined4 local_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 local_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 local_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 local_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 local_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 local_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 local_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 local_1c;
  
  if ((param_4 != 0) &&
     (cVar2 = FUN_000467f0(*(undefined4 *)(param_1 + 4),param_2,param_3[2],param_3[3],
                           param_4 + param_3[2],&local_f4,local_dc), cVar2 != '\0')) {
    local_10c = 0;
    goto LAB_0004647d;
  }
  if ((param_3[4] != 0) &&
     (cVar2 = FUN_000469d0(*(undefined4 *)(param_1 + 4),param_2,param_3[4],param_3[5],&local_f4,
                           local_dc), cVar2 != '\0')) {
    local_10c = 0;
    goto LAB_0004647d;
  }
  iVar1 = *param_3;
  pthread_rwlock_rdlock((pthread_rwlock_t *)&DAT_00050ba0);
  if (PTR_DAT_00050874 < PTR_DAT_00050878) {
    piVar3 = (int *)PTR_DAT_00050874;
    if (iVar1 == -1) {
      do {
        if (((uint)piVar3[1] <= param_2) && (param_2 < (uint)piVar3[2])) goto LAB_000463e1;
        piVar3 = piVar3 + 4;
      } while (piVar3 < PTR_DAT_00050878);
    }
    else {
      do {
        if (((*piVar3 == iVar1) && ((uint)piVar3[1] <= param_2)) && (param_2 < (uint)piVar3[2]))
        goto LAB_000463e1;
        piVar3 = piVar3 + 4;
      } while (piVar3 < PTR_DAT_00050878);
    }
  }
  pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00050ba0);
LAB_00046439:
  local_10c = 0;
LAB_0004644d:
  cVar2 = FUN_000467f0(*(undefined4 *)(param_1 + 4),param_2,param_3[2],param_3[3],0,&local_f4,
                       local_dc);
  if (cVar2 == '\0') {
    return 0;
  }
LAB_0004647d:
  iVar1 = *param_3;
  local_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  local_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  local_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  local_5c = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  uStack_50 = 0;
  local_6c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  local_7c = 0;
  uStack_78 = 0;
  uStack_74 = 0;
  uStack_70 = 0;
  local_8c = 0;
  uStack_88 = 0;
  uStack_84 = 0;
  uStack_80 = 0;
  local_9c = 0;
  uStack_98 = 0;
  uStack_94 = 0;
  uStack_90 = 0;
  local_ac = 0;
  uStack_a8 = 0;
  uStack_a4 = 0;
  uStack_a0 = 0;
  local_bc = 0;
  uStack_b8 = 0;
  uStack_b4 = 0;
  uStack_b0 = 0;
  local_1c = 0;
  cVar2 = FUN_000446a0(*(undefined4 *)(param_1 + 4),&local_f4,local_dc,param_2,0,&local_bc);
  if (cVar2 == '\0') {
    return 0;
  }
  *(int *)(param_1 + 0x48) = local_e8;
  *(int *)(param_1 + 0x4c) = local_e4;
  *(undefined4 *)(param_1 + 0x50) = local_e0;
  *(undefined4 *)(param_1 + 0x54) = local_cc;
  *(undefined4 *)(param_1 + 0x58) = local_ac;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0x4000000;
  *(int *)(param_1 + 0x68) = local_f4;
  *(undefined4 *)(param_1 + 100) = local_f0;
  *(int *)(param_1 + 0x6c) = iVar1;
  if ((param_4 != 0 | local_10c) == 1) {
    return 1;
  }
  if (param_3[4] != 0) {
    return 1;
  }
  iVar1 = *param_3;
  pthread_rwlock_wrlock((pthread_rwlock_t *)&DAT_00050ba0);
  __src = PTR_DAT_00050874;
  if (DAT_0005087c <= PTR_DAT_00050878) {
    __n = (int)DAT_0005087c - (int)PTR_DAT_00050874;
    __dest = malloc(__n * 4);
    memcpy(__dest,__src,__n);
    if ((undefined4 *)__src != &DAT_00050bc8) {
      free(__src);
    }
    PTR_DAT_00050878 = __dest + ((int)__n >> 4) * 0x10;
    DAT_0005087c = __dest + ((int)__n >> 2) * 0x10;
    PTR_DAT_00050874 = __dest;
  }
  *(int *)PTR_DAT_00050878 = iVar1;
  *(int *)((int)PTR_DAT_00050878 + 4) = local_e8;
  *(int *)((int)PTR_DAT_00050878 + 8) = local_e4;
  *(int *)((int)PTR_DAT_00050878 + 0xc) = local_f4;
  PTR_DAT_00050878 = (undefined *)((int)PTR_DAT_00050878 + 0x10);
  pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00050ba0);
  return 1;
LAB_000463e1:
  iVar1 = piVar3[3];
  pthread_rwlock_unlock((pthread_rwlock_t *)&DAT_00050ba0);
  if (iVar1 == 0) goto LAB_00046439;
  local_10c = FUN_000467f0(*(undefined4 *)(param_1 + 4),param_2,param_3[2],param_3[3],iVar1,
                           &local_f4,local_dc);
  if (local_10c == 1) goto LAB_0004647d;
  goto LAB_0004644d;
}


// ==== FUN_000467f0 @ 000467f0

undefined4
FUN_000467f0(undefined4 param_1,uint param_2,int *param_3,int param_4,int *param_5,
            undefined4 *param_6,int param_7)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  undefined4 uVar5;
  int *local_20;
  uint local_1c;
  int *local_18;
  int *local_14;
  
  uVar5 = 0x467fc;
  if (param_5 == (int *)0x0) {
    param_5 = param_3;
  }
  local_18 = (int *)((int)param_3 + param_4);
  if (param_4 == -1) {
    local_18 = (int *)0xffffffff;
  }
  if (param_5 < local_18) {
    do {
      iVar2 = *param_5;
      local_20 = param_5 + 1;
      if (iVar2 == -1) {
        iVar2 = param_5[1];
        local_20 = param_5 + 3;
      }
      if (iVar2 == 0) {
        return 0;
      }
      piVar4 = (int *)(iVar2 + (int)local_20);
      if ((((*local_20 != 0) && (piVar1 = (int *)((int)local_20 - *local_20), param_3 <= piVar1)) &&
          (piVar1 < local_18)) && (iVar2 = FUN_00043a70(param_1,piVar1,param_7,uVar5), iVar2 == 0))
      {
        local_20 = local_20 + 1;
        local_1c = FUN_00045520(param_1,&local_20,piVar4,*(undefined1 *)(param_7 + 0xc),0);
        iVar2 = FUN_00045520(param_1,&local_20,piVar4,*(byte *)(param_7 + 0xc) & 0xf,0);
        if ((local_1c < param_2) && (uVar3 = iVar2 + local_1c, param_2 <= uVar3)) {
          param_6[5] = 0;
          local_18 = (int *)uVar3;
          if (*(char *)(param_7 + 0x1d) == '\0') {
            local_14 = local_20;
          }
          else {
            iVar2 = FUN_00045800(&local_20,piVar4);
            piVar1 = local_20;
            local_14 = (int *)(iVar2 + (int)local_20);
            if (*(byte *)(param_7 + 0xd) == 0xff) {
            }
            else {
              iVar2 = FUN_00045520(param_1,&local_20,piVar4,*(byte *)(param_7 + 0xd) & 0xf,0);
              if (iVar2 != 0) {
                local_20 = piVar1;
                uVar5 = FUN_00045520(param_1,&local_20,piVar4,*(undefined1 *)(param_7 + 0xd),0);
                param_6[5] = uVar5;
              }
            }
          }
          *param_6 = param_5;
          param_6[1] = (int)piVar4 - (int)param_5;
          param_6[2] = local_14;
          param_6[3] = local_1c;
          param_6[4] = local_18;
          return 1;
        }
      }
      param_5 = piVar4;
    } while (piVar4 < local_18);
  }
  return 0;
}


// ==== FUN_000469d0 @ 000469d0

undefined4
FUN_000469d0(undefined4 param_1,uint param_2,char *param_3,int param_4,int param_5,
            undefined4 param_6)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  char *local_30;
  uint local_2c;
  uint local_28;
  int local_24;
  char *local_20;
  uint local_1c;
  char *local_18;
  char *local_14;
  
  if (*param_3 == '\x01') {
    pcVar7 = param_3 + param_4;
    local_28 = CONCAT31(local_28._1_3_,param_3[2]);
    local_14 = param_3 + 4;
    local_2c = CONCAT31(local_2c._1_3_,param_3[3]);
    FUN_00045520(param_1,&local_14,pcVar7,param_3[1],param_3);
    if ((char)local_28 != -1) {
      uVar2 = FUN_00045520(param_1,&local_14,pcVar7,local_28 & 0xff,param_3);
      if (uVar2 == 0) {
        return 0;
      }
      local_20 = local_14;
      local_1c = local_2c & 0xff;
      local_18 = pcVar7;
      local_24 = FUN_00046b80(local_1c);
      uVar6 = 0;
      do {
        if (uVar2 < 2) {
          pcVar7 = local_20 + uVar6 * local_24;
          break;
        }
        uVar8 = uVar2 >> 1;
        local_2c = uVar8 + uVar6;
        pcVar7 = local_20 + local_2c * local_24;
        local_30 = pcVar7;
        local_28 = uVar6;
        uVar3 = FUN_00045520(param_1,&local_30,local_18,local_1c,param_3);
        if (uVar3 < param_2) {
          uVar8 = uVar2 - uVar8;
          uVar6 = local_2c;
        }
        else {
          uVar6 = local_28;
        }
        uVar2 = uVar8;
      } while (uVar3 != param_2);
      pcVar1 = local_18;
      uVar2 = local_1c;
      local_30 = pcVar7;
      FUN_00045520(param_1,&local_30,local_18,local_1c,param_3);
      uVar4 = FUN_00045520(param_1,&local_30,pcVar1,uVar2,param_3);
      iVar5 = FUN_000438e0(param_1,uVar4,param_5,param_6,0);
      if (((iVar5 == 0) && (*(uint *)(param_5 + 0xc) <= param_2)) &&
         (param_2 < *(uint *)(param_5 + 0x10))) {
        return 1;
      }
    }
  }
  else {
    fwrite("libunwind: Unsupported .eh_frame_hdr version\n",0x2d,1,(FILE *)0x511ac);
  }
  return 0;
}


// ==== FUN_00046b80 @ 00046b80

undefined4 FUN_00046b80(byte param_1)

{
  undefined4 uVar1;
  
  uVar1 = 4;
  switch(param_1 & 0xf) {
  case 1:
  case 9:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getTableEntrySize",
            "Can\'t binary search on variable length encoded data.");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  case 2:
  case 10:
    goto switchD_00046bad_caseD_2;
  case 3:
  case 0xb:
    uVar1 = 8;
switchD_00046bad_caseD_2:
    return uVar1;
  case 4:
  case 0xc:
    return 0x10;
  default:
    fprintf((FILE *)0x511ac,"libunwind: %s - %s\n","getTableEntrySize",
            "Unknown DWARF encoding for search table.");
    fflush((FILE *)0x511ac);
                    /* WARNING: Subroutine does not return */
    abort();
  }
}


// ==== FUN_00046c34 @ 00046c34

void FUN_00046c34(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = param_1[7];
  puVar2 = (undefined4 *)(iVar1 + -8);
  param_1[7] = puVar2;
  *puVar2 = *param_1;
  *(undefined4 *)(iVar1 + -4) = param_1[10];
                    /* WARNING: Could not recover jumptable at 0x00046c62. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1[7] + 4))();
  return;
}


// ==== FUN_00046c64 @ 00046c64

undefined4 FUN_00046c64(undefined4 *param_1)

{
  undefined4 in_EAX;
  undefined4 in_ECX;
  undefined4 in_EDX;
  undefined4 unaff_EBX;
  undefined4 unaff_EBP;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  undefined4 unaff_retaddr;
  
  param_1[1] = unaff_EBX;
  param_1[2] = in_ECX;
  param_1[3] = in_EDX;
  param_1[4] = unaff_EDI;
  param_1[5] = unaff_ESI;
  param_1[6] = unaff_EBP;
  param_1[7] = &param_1;
  param_1[10] = unaff_retaddr;
  *param_1 = in_EAX;
  return 0;
}


// ==== FUN_00046ca0 @ 00046ca0

void FUN_00046ca0(void)

{
  (*(code *)(undefined *)0x0)();
  return;
}


// ==== __cxa_finalize @ 00046cb0

void __cxa_finalize(void)

{
  __cxa_finalize();
  return;
}


// ==== __cxa_atexit @ 00046cc0

void __cxa_atexit(void)

{
  __cxa_atexit();
  return;
}


// ==== __stack_chk_fail @ 00046cd0

void __stack_chk_fail(void)

{
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== strlen @ 00046ce0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
  size_t sVar1;
  
  sVar1 = strlen(__s);
  return sVar1;
}


// ==== memcpy @ 00046cf0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memcpy(__dest,__src,__n);
  return pvVar1;
}


// ==== memset @ 00046d00

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memset(__s,__c,__n);
  return pvVar1;
}


// ==== AMotionEvent_getAction @ 00046d10

void AMotionEvent_getAction(void)

{
  AMotionEvent_getAction();
  return;
}


// ==== AInputEvent_getDeviceId @ 00046d20

void AInputEvent_getDeviceId(void)

{
  AInputEvent_getDeviceId();
  return;
}


// ==== AInputEvent_getSource @ 00046d30

void AInputEvent_getSource(void)

{
  AInputEvent_getSource();
  return;
}


// ==== gettimeofday @ 00046d40

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
  int iVar1;
  
  iVar1 = gettimeofday(__tv,__tz);
  return iVar1;
}


// ==== AMotionEvent_getX @ 00046d50

void AMotionEvent_getX(void)

{
  AMotionEvent_getX();
  return;
}


// ==== AMotionEvent_getY @ 00046d60

void AMotionEvent_getY(void)

{
  AMotionEvent_getY();
  return;
}


// ==== AMotionEvent_getToolType @ 00046d70

void AMotionEvent_getToolType(void)

{
  AMotionEvent_getToolType();
  return;
}


// ==== AMotionEvent_getPointerId @ 00046d80

void AMotionEvent_getPointerId(void)

{
  AMotionEvent_getPointerId();
  return;
}


// ==== AMotionEvent_getPressure @ 00046d90

void AMotionEvent_getPressure(void)

{
  AMotionEvent_getPressure();
  return;
}


// ==== AMotionEvent_getSize @ 00046da0

void AMotionEvent_getSize(void)

{
  AMotionEvent_getSize();
  return;
}


// ==== AMotionEvent_getFlags @ 00046db0

void AMotionEvent_getFlags(void)

{
  AMotionEvent_getFlags();
  return;
}


// ==== AMotionEvent_getPointerCount @ 00046dc0

void AMotionEvent_getPointerCount(void)

{
  AMotionEvent_getPointerCount();
  return;
}


// ==== AMotionEvent_getXPrecision @ 00046dd0

void AMotionEvent_getXPrecision(void)

{
  AMotionEvent_getXPrecision();
  return;
}


// ==== AMotionEvent_getYPrecision @ 00046de0

void AMotionEvent_getYPrecision(void)

{
  AMotionEvent_getYPrecision();
  return;
}


// ==== AMotionEvent_getDownTime @ 00046df0

void AMotionEvent_getDownTime(void)

{
  AMotionEvent_getDownTime();
  return;
}


// ==== AMotionEvent_getEventTime @ 00046e00

void AMotionEvent_getEventTime(void)

{
  AMotionEvent_getEventTime();
  return;
}


// ==== memcmp @ 00046e10

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = memcmp(__s1,__s2,__n);
  return iVar1;
}


// ==== __vsnprintf_chk @ 00046e20

void __vsnprintf_chk(void)

{
  __vsnprintf_chk();
  return;
}


// ==== memmove @ 00046e30

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memmove(__dest,__src,__n);
  return pvVar1;
}


// ==== __android_log_print @ 00046e40

void __android_log_print(void)

{
  __android_log_print();
  return;
}


// ==== regcomp @ 00046e50

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
  int iVar1;
  
  iVar1 = regcomp(__preg,__pattern,__cflags);
  return iVar1;
}


// ==== malloc @ 00046e60

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = malloc(__size);
  return pvVar1;
}


// ==== strdup @ 00046e70

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
  char *pcVar1;
  
  pcVar1 = strdup(__s);
  return pcVar1;
}


// ==== pthread_mutex_lock @ 00046e80

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_lock(__mutex);
  return iVar1;
}


// ==== pthread_mutex_unlock @ 00046e90

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_unlock(__mutex);
  return iVar1;
}


// ==== free @ 00046ea0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}


// ==== sigaction @ 00046eb0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
  int iVar1;
  
  iVar1 = sigaction(__sig,__act,__oact);
  return iVar1;
}


// ==== pthread_create @ 00046ec0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
  int iVar1;
  
  iVar1 = pthread_create(__newthread,__attr,__start_routine,__arg);
  return iVar1;
}


// ==== pthread_cond_signal @ 00046ed0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_signal(__cond);
  return iVar1;
}


// ==== pthread_join @ 00046ee0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
  int iVar1;
  
  iVar1 = pthread_join(__th,__thread_return);
  return iVar1;
}


// ==== regfree @ 00046ef0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
  regfree(__preg);
  return;
}


// ==== siglongjmp @ 00046f00

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Subroutine does not return */
  siglongjmp(__env,__val);
}


// ==== pthread_self @ 00046f10

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
  pthread_t pVar1;
  
  pVar1 = pthread_self();
  return pVar1;
}


// ==== pthread_setname_np @ 00046f20

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
  int iVar1;
  
  iVar1 = pthread_setname_np(__target_thread,__name);
  return iVar1;
}


// ==== pthread_cond_wait @ 00046f30

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_cond_wait(__cond,__mutex);
  return iVar1;
}


// ==== fopen @ 00046f40

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
  FILE *pFVar1;
  
  pFVar1 = fopen(__filename,__modes);
  return pFVar1;
}


// ==== fgets @ 00046f50

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
  char *pcVar1;
  
  pcVar1 = fgets(__s,__n,__stream);
  return pcVar1;
}


// ==== sscanf @ 00046f60

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
  int iVar1;
  
  iVar1 = sscanf(__s,__format);
  return iVar1;
}


// ==== regexec @ 00046f70

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
  int iVar1;
  
  iVar1 = regexec(__preg,__string,__nmatch,__pmatch,__eflags);
  return iVar1;
}


// ==== strcmp @ 00046f80

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = strcmp(__s1,__s2);
  return iVar1;
}


// ==== fclose @ 00046f90

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fclose(__stream);
  return iVar1;
}


// ==== sigsetjmp @ 00046fa0

void sigsetjmp(void)

{
  sigsetjmp();
  return;
}


// ==== sysconf @ 00046fb0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long sysconf(int __name)

{
  long lVar1;
  
  lVar1 = sysconf(__name);
  return lVar1;
}


// ==== strstr @ 00046fc0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
  char *pcVar1;
  
  pcVar1 = strstr(__haystack,__needle);
  return pcVar1;
}


// ==== mprotect @ 00046fd0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
  int iVar1;
  
  iVar1 = mprotect(__addr,__len,__prot);
  return iVar1;
}


// ==== __errno @ 00046fe0

void __errno(void)

{
  __errno();
  return;
}


// ==== pthread_cond_broadcast @ 00046ff0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_broadcast(__cond);
  return iVar1;
}


// ==== pthread_getspecific @ 00047000

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
  void *pvVar1;
  
  pvVar1 = pthread_getspecific(__key);
  return pvVar1;
}


// ==== pthread_setspecific @ 00047010

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
  int iVar1;
  
  iVar1 = pthread_setspecific(__key,__pointer);
  return iVar1;
}


// ==== pthread_cond_destroy @ 00047020

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_destroy(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = pthread_cond_destroy(__cond);
  return iVar1;
}


// ==== pthread_mutex_destroy @ 00047030

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = pthread_mutex_destroy(__mutex);
  return iVar1;
}


// ==== posix_memalign @ 00047040

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
  int iVar1;
  
  iVar1 = posix_memalign(__memptr,__alignment,__size);
  return iVar1;
}


// ==== __strlen_chk @ 00047050

void __strlen_chk(void)

{
  __strlen_chk();
  return;
}


// ==== memchr @ 00047060

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memchr(__s,__c,__n);
  return pvVar1;
}


// ==== strerror_r @ 00047070

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
  char *pcVar1;
  
  pcVar1 = strerror_r(__errnum,__buf,__buflen);
  return pcVar1;
}


// ==== abort @ 00047080

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Subroutine does not return */
  abort();
}


// ==== vsnprintf @ 00047090

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vsnprintf(__s,__maxlen,__format,__arg);
  return iVar1;
}


// ==== pthread_key_create @ 000470a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
  int iVar1;
  
  iVar1 = pthread_key_create(__key,__destr_function);
  return iVar1;
}


// ==== syscall @ 000470b0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
  long lVar1;
  
  lVar1 = syscall(__sysno);
  return lVar1;
}


// ==== vfprintf @ 000470c0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vfprintf(__s,__format,__arg);
  return iVar1;
}


// ==== fputc @ 000470d0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
  int iVar1;
  
  iVar1 = fputc(__c,__stream);
  return iVar1;
}


// ==== vasprintf @ 000470e0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = vasprintf(__ptr,__f,__arg);
  return iVar1;
}


// ==== __assert2 @ 000470f0

void __assert2(void)

{
  __assert2();
  return;
}


// ==== realloc @ 00047100

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
  void *pvVar1;
  
  pvVar1 = realloc(__ptr,__size);
  return pvVar1;
}


// ==== __memmove_chk @ 00047110

void __memmove_chk(void)

{
  __memmove_chk();
  return;
}


// ==== pthread_once @ 00047120

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
  int iVar1;
  
  iVar1 = pthread_once(__once_control,__init_routine);
  return iVar1;
}


// ==== pthread_key_delete @ 00047130

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
  int iVar1;
  
  iVar1 = pthread_key_delete(__key);
  return iVar1;
}


// ==== fprintf @ 00047140

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
  int iVar1;
  
  iVar1 = fprintf(__stream,__format);
  return iVar1;
}


// ==== fflush @ 00047150

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fflush(__stream);
  return iVar1;
}


// ==== pthread_rwlock_wrlock @ 00047160

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_wrlock(__rwlock);
  return iVar1;
}


// ==== pthread_rwlock_unlock @ 00047170

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_unlock(__rwlock);
  return iVar1;
}


// ==== dl_iterate_phdr @ 00047180

void dl_iterate_phdr(void)

{
  dl_iterate_phdr();
  return;
}


// ==== pthread_rwlock_rdlock @ 00047190

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = pthread_rwlock_rdlock(__rwlock);
  return iVar1;
}


// ==== fwrite @ 000471a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
  size_t sVar1;
  
  sVar1 = fwrite(__ptr,__size,__n,__s);
  return sVar1;
}


// ==== __cxa_finalize @ 00051000

/* WARNING: Control flow encountered bad instruction data */

void __cxa_finalize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __cxa_atexit @ 00051004

/* WARNING: Control flow encountered bad instruction data */

void __cxa_atexit(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __stack_chk_fail @ 00051008

/* WARNING: Control flow encountered bad instruction data */

void __stack_chk_fail(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strlen @ 0005100c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcpy @ 00051010

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memset @ 00051014

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getAction @ 00051018

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getAction(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getDeviceId @ 0005101c

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getDeviceId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AInputEvent_getSource @ 00051020

/* WARNING: Control flow encountered bad instruction data */

void AInputEvent_getSource(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== gettimeofday @ 00051024

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int gettimeofday(timeval *__tv,__timezone_ptr_t __tz)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getX @ 00051028

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getX(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getY @ 0005102c

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getY(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getToolType @ 00051030

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getToolType(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerId @ 00051034

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerId(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPressure @ 00051038

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPressure(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getSize @ 0005103c

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getSize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getFlags @ 00051040

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getFlags(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getPointerCount @ 00051044

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getPointerCount(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getXPrecision @ 00051048

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getXPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getYPrecision @ 0005104c

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getYPrecision(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getDownTime @ 00051050

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getDownTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== AMotionEvent_getEventTime @ 00051054

/* WARNING: Control flow encountered bad instruction data */

void AMotionEvent_getEventTime(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memcmp @ 00051058

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __vsnprintf_chk @ 0005105c

/* WARNING: Control flow encountered bad instruction data */

void __vsnprintf_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memmove @ 00051060

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __android_log_print @ 00051064

/* WARNING: Control flow encountered bad instruction data */

void __android_log_print(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regcomp @ 00051068

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regcomp(regex_t *__preg,char *__pattern,int __cflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== malloc @ 0005106c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strdup @ 00051070

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strdup(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_lock @ 00051074

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_unlock @ 00051078

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== free @ 0005107c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigaction @ 00051080

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_create @ 00051084

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_signal @ 00051088

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_signal(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_join @ 0005108c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regfree @ 00051090

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void regfree(regex_t *__preg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== siglongjmp @ 00051094

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void siglongjmp(__jmp_buf_tag *__env,int __val)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_self @ 00051098

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setname_np @ 0005109c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_wait @ 000510a0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fopen @ 000510a4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fgets @ 000510a8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sscanf @ 000510ac

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== regexec @ 000510b0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int regexec(regex_t *__preg,char *__string,size_t __nmatch,regmatch_t *__pmatch,int __eflags)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strcmp @ 000510b4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fclose @ 000510b8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sigsetjmp @ 000510bc

/* WARNING: Control flow encountered bad instruction data */

void sigsetjmp(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== sysconf @ 000510c0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long sysconf(int __name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strstr @ 000510c4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== mprotect @ 000510c8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __errno @ 000510cc

/* WARNING: Control flow encountered bad instruction data */

void __errno(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_broadcast @ 000510d0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_getspecific @ 000510d4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_setspecific @ 000510d8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_cond_destroy @ 000510dc

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_destroy(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_mutex_destroy @ 000510e0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== posix_memalign @ 000510e4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __strlen_chk @ 000510e8

/* WARNING: Control flow encountered bad instruction data */

void __strlen_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== memchr @ 000510ec

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== strerror_r @ 000510f0

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== abort @ 000510f4

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vsnprintf @ 000510f8

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_create @ 000510fc

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== syscall @ 00051100

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vfprintf @ 00051108

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fputc @ 0005110c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== vasprintf @ 00051110

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __assert2 @ 00051114

/* WARNING: Control flow encountered bad instruction data */

void __assert2(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== realloc @ 00051118

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== __memmove_chk @ 0005111c

/* WARNING: Control flow encountered bad instruction data */

void __memmove_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_once @ 00051120

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_key_delete @ 00051124

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fprintf @ 00051128

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fflush @ 0005112c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_wrlock @ 00051130

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_unlock @ 00051134

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== dl_iterate_phdr @ 00051138

/* WARNING: Control flow encountered bad instruction data */

void dl_iterate_phdr(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== pthread_rwlock_rdlock @ 0005113c

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


// ==== fwrite @ 00051140

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}


