package io.reactivex.exceptions;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes11.dex */
public final class ProtocolViolationException extends IllegalStateException {
    private static final long serialVersionUID = 1644750035281290266L;

    public ProtocolViolationException(String str) {
        super(str);
    }
}
