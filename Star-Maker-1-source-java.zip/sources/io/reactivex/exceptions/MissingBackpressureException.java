package io.reactivex.exceptions;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes11.dex */
public final class MissingBackpressureException extends RuntimeException {
    private static final long serialVersionUID = 8517344746016032542L;
}
