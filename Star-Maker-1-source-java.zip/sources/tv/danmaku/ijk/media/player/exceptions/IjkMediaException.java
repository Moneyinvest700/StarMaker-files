package tv.danmaku.ijk.media.player.exceptions;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes11.dex */
public class IjkMediaException extends Exception {
    private static final long serialVersionUID = 7234796519009099506L;
}
