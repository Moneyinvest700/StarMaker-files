package tv.danmaku.ijk.media.player.pragma;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes3.dex */
public class Pragma {
    public static final boolean ENABLE_VERBOSE = true;
}
