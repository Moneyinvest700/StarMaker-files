package tv.danmaku.ijk.media.player;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes3.dex */
public class MediaInfo {
    public String mAudioDecoder;
    public String mAudioDecoderImpl;
    public String mMediaPlayerName;
    public IjkMediaMeta mMeta;
    public String mVideoDecoder;
    public String mVideoDecoderImpl;
}
