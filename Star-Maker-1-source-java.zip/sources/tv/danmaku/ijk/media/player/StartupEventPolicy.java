package tv.danmaku.ijk.media.player;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes3.dex */
final class StartupEventPolicy {
    static final int MIN_ASYNC_MESSAGE_SDK_INT = 22;
    private boolean mMediaCodecEnabled;
    private boolean mStartupActive;

    private static boolean isAsynchronousStartupEvent(int i) {
        return i == 5 || i == 10001;
    }

    private static boolean isTerminalEvent(int i, int i2) {
        if (i == 2 || i == 100) {
            return true;
        }
        return i == 200 && i2 == 3;
    }

    public static boolean shouldNotifyVideoSarChanged(int i, int i2, boolean z) {
        if (z) {
            return i > 0 && i2 > 0;
        }
        return true;
    }

    public synchronized void begin(int i) {
        this.mStartupActive = this.mMediaCodecEnabled && i >= 22;
    }

    public synchronized void end() {
        this.mStartupActive = false;
    }

    public synchronized void onPlayerOption(int i, String str, long j) {
        if (i == 4) {
            if ("mediacodec".equals(str)) {
                boolean z = j != 0;
                this.mMediaCodecEnabled = z;
                if (!z) {
                    this.mStartupActive = false;
                }
            }
        }
    }

    public synchronized boolean shouldPostAsynchronously(int i, int i2) {
        if (!this.mStartupActive) {
            return false;
        }
        if (isTerminalEvent(i, i2)) {
            this.mStartupActive = false;
            return false;
        }
        return isAsynchronousStartupEvent(i);
    }
}
