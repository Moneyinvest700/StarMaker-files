package javax.annotation;

import com.facebook.ads.redexgen.core.EnumC2195qy;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Nonnull(when = EnumC2195qy.A05)
@Documented
@Retention(RetentionPolicy.RUNTIME)
/* loaded from: assets/audience_network/classes2.dex */
public @interface Nullable {
}
