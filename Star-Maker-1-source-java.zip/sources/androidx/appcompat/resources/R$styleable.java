package androidx.appcompat.resources;

/* loaded from: classes4.dex */
public final class R$styleable {
}
