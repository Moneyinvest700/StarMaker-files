package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;
import defpackage.ap0;
import defpackage.cq0;
import defpackage.d4v;
import defpackage.t8v;
import defpackage.y15;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes.dex */
public class AppCompatImageView extends ImageView {
    private final ap0 mBackgroundTintHelper;
    private boolean mHasLevel;
    private final cq0 mImageHelper;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        t8v.a(context);
        this.mHasLevel = false;
        d4v.a(getContext(), this);
        ap0 ap0Var = new ap0(this);
        this.mBackgroundTintHelper = ap0Var;
        ap0Var.d(attributeSet, i);
        cq0 cq0Var = new cq0(this);
        this.mImageHelper = cq0Var;
        cq0Var.b(attributeSet, i);
    }

    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        ap0 ap0Var = this.mBackgroundTintHelper;
        if (ap0Var != null) {
            ap0Var.a();
        }
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var != null) {
            cq0Var.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        ap0 ap0Var = this.mBackgroundTintHelper;
        if (ap0Var != null) {
            return ap0Var.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        ap0 ap0Var = this.mBackgroundTintHelper;
        if (ap0Var != null) {
            return ap0Var.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        y15 y15Var;
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var == null || (y15Var = cq0Var.b) == null) {
            return null;
        }
        return (ColorStateList) y15Var.d;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        y15 y15Var;
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var == null || (y15Var = cq0Var.b) == null) {
            return null;
        }
        return (PorterDuff.Mode) y15Var.e;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return !(this.mImageHelper.f10048a.getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        ap0 ap0Var = this.mBackgroundTintHelper;
        if (ap0Var != null) {
            ap0Var.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        ap0 ap0Var = this.mBackgroundTintHelper;
        if (ap0Var != null) {
            ap0Var.f(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var != null) {
            cq0Var.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var != null && drawable != null && !this.mHasLevel) {
            cq0Var.c = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        cq0 cq0Var2 = this.mImageHelper;
        if (cq0Var2 != null) {
            cq0Var2.a();
            if (this.mHasLevel) {
                return;
            }
            cq0 cq0Var3 = this.mImageHelper;
            ImageView imageView = cq0Var3.f10048a;
            if (imageView.getDrawable() != null) {
                imageView.getDrawable().setLevel(cq0Var3.c);
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i) {
        super.setImageLevel(i);
        this.mHasLevel = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var != null) {
            cq0Var.c(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var != null) {
            cq0Var.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        ap0 ap0Var = this.mBackgroundTintHelper;
        if (ap0Var != null) {
            ap0Var.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        ap0 ap0Var = this.mBackgroundTintHelper;
        if (ap0Var != null) {
            ap0Var.i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var != null) {
            y15 y15Var = cq0Var.b;
            if (y15Var == null) {
                y15Var = new y15();
                cq0Var.b = y15Var;
            }
            y15Var.d = colorStateList;
            y15Var.c = true;
            cq0Var.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        cq0 cq0Var = this.mImageHelper;
        if (cq0Var != null) {
            y15 y15Var = cq0Var.b;
            if (y15Var == null) {
                y15Var = new y15();
                cq0Var.b = y15Var;
            }
            y15Var.e = mode;
            y15Var.b = true;
            cq0Var.a();
        }
    }

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AppCompatImageView(Context context) {
        this(context, null);
    }
}
