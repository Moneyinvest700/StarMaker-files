package androidx.media3.exoplayer.image;

import androidx.media3.decoder.DecoderException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ImageDecoderException extends DecoderException {
}
