package androidx.media3.exoplayer.source.ads;

import java.io.IOException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class AdsMediaSource$AdLoadException extends IOException {
    public final int type;
}
