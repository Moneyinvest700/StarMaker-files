package androidx.media3.exoplayer.drm;

import android.net.Uri;
import defpackage.bt5;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes5.dex */
public final class MediaDrmCallbackException extends IOException {
    public final long bytesLoaded;
    public final bt5 dataSpec;
    public final Map<String, List<String>> responseHeaders;
    public final Uri uriAfterRedirects;
}
