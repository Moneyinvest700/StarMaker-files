package androidx.media3.datasource;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class HttpEngineDataSource$OpenException extends HttpDataSource$HttpDataSourceException {
    public final int httpEngineConnectionStatus;
}
