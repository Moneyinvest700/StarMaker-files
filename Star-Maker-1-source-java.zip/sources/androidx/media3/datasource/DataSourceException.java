package androidx.media3.datasource;

import java.io.IOException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class DataSourceException extends IOException {
    public final int reason;

    public DataSourceException(int i) {
        this.reason = i;
    }

    public DataSourceException(Exception exc, int i) {
        super(exc);
        this.reason = i;
    }

    public DataSourceException(String str, Exception exc, int i) {
        super(str, exc);
        this.reason = i;
    }
}
