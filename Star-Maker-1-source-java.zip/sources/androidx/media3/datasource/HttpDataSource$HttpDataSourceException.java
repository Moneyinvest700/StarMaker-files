package androidx.media3.datasource;

import com.facebook.ads.AdError;
import defpackage.bt5;
import defpackage.c12;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class HttpDataSource$HttpDataSourceException extends DataSourceException {
    public final bt5 dataSpec;
    public final int type;

    /* JADX WARN: Illegal instructions before constructor call */
    public HttpDataSource$HttpDataSourceException(IOException iOException, bt5 bt5Var, int i, int i2) {
        if (i == 2000 && i2 == 1) {
            i = 2001;
        }
        super(iOException, i);
        this.dataSpec = bt5Var;
        this.type = i2;
    }

    public static HttpDataSource$HttpDataSourceException a(IOException iOException, bt5 bt5Var, int i) {
        String message = iOException.getMessage();
        int i2 = iOException instanceof SocketTimeoutException ? 2002 : iOException instanceof InterruptedIOException ? 1004 : (message == null || !c12.l0(message).matches("cleartext.*not permitted.*")) ? 2001 : 2007;
        return i2 == 2007 ? new HttpDataSource$CleartextNotPermittedException("Cleartext HTTP traffic not permitted. See https://developer.android.com/guide/topics/media/issues/cleartext-not-permitted", iOException, bt5Var, 2007) : new HttpDataSource$HttpDataSourceException(iOException, bt5Var, i2, i);
    }

    public HttpDataSource$HttpDataSourceException(bt5 bt5Var) {
        super(AdError.REMOTE_ADS_SERVICE_ERROR);
        this.dataSpec = bt5Var;
        this.type = 1;
    }

    public HttpDataSource$HttpDataSourceException(String str, IOException iOException, bt5 bt5Var, int i) {
        super(str, iOException, i == 2000 ? 2001 : i);
        this.dataSpec = bt5Var;
        this.type = 1;
    }
}
