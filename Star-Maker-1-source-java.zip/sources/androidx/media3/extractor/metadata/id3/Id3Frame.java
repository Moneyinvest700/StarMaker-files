package androidx.media3.extractor.metadata.id3;

import androidx.media3.common.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class Id3Frame implements Metadata.Entry {
    public final String b;

    public Id3Frame(String str) {
        this.b = str;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        return this.b;
    }
}
