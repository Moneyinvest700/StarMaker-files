package androidx.media3.extractor.metadata.mp4;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.media3.common.Metadata;
import defpackage.uh2;
import defpackage.vpw;
import defpackage.wqx;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class SlowMotionData implements Metadata.Entry {
    public static final Parcelable.Creator<SlowMotionData> CREATOR = new a();
    public final ArrayList b;

    /* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
    public static final class Segment implements Parcelable {
        public static final Parcelable.Creator<Segment> CREATOR = new b();
        public final long b;
        public final long c;
        public final int d;

        public Segment(long j, long j2, int i) {
            uh2.i(j < j2);
            this.b = j;
            this.c = j2;
            this.d = i;
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj != null && Segment.class == obj.getClass()) {
                Segment segment = (Segment) obj;
                if (this.b == segment.b && this.c == segment.c && this.d == segment.d) {
                    return true;
                }
            }
            return false;
        }

        public final int hashCode() {
            return Arrays.hashCode(new Object[]{Long.valueOf(this.b), Long.valueOf(this.c), Integer.valueOf(this.d)});
        }

        public final String toString() {
            int i = vpw.f16901a;
            Locale locale = Locale.US;
            StringBuilder sbU = wqx.u(this.b, "Segment: startTimeMs=", ", endTimeMs=");
            sbU.append(this.c);
            sbU.append(", speedDivisor=");
            sbU.append(this.d);
            return sbU.toString();
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeLong(this.b);
            parcel.writeLong(this.c);
            parcel.writeInt(this.d);
        }
    }

    public SlowMotionData(ArrayList arrayList) {
        this.b = arrayList;
        boolean z = false;
        if (!arrayList.isEmpty()) {
            long j = ((Segment) arrayList.get(0)).c;
            int i = 1;
            while (true) {
                if (i >= arrayList.size()) {
                    break;
                }
                if (((Segment) arrayList.get(i)).b < j) {
                    z = true;
                    break;
                } else {
                    j = ((Segment) arrayList.get(i)).c;
                    i++;
                }
            }
        }
        uh2.i(!z);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || SlowMotionData.class != obj.getClass()) {
            return false;
        }
        return this.b.equals(((SlowMotionData) obj).b);
    }

    public final int hashCode() {
        return this.b.hashCode();
    }

    public final String toString() {
        return "SlowMotion: segments=" + this.b;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeList(this.b);
    }
}
