package androidx.media3.common;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class VideoFrameProcessingException extends Exception {
    public static final /* synthetic */ int b = 0;
    public final long presentationTimeUs;

    public VideoFrameProcessingException(Exception exc) {
        super(exc);
        this.presentationTimeUs = -9223372036854775807L;
    }
}
