package androidx.media3.common.audio;

import defpackage.e41;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class AudioProcessor$UnhandledAudioFormatException extends Exception {
    public final e41 inputAudioFormat;

    public AudioProcessor$UnhandledAudioFormatException(e41 e41Var) {
        super("Unhandled input format: " + e41Var);
        this.inputAudioFormat = e41Var;
    }
}
