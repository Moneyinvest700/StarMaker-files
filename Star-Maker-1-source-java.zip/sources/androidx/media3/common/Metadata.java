package androidx.media3.common;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.jox;
import defpackage.udj;
import defpackage.vpw;
import java.util.Arrays;
import java.util.List;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class Metadata implements Parcelable {
    public static final Parcelable.Creator<Metadata> CREATOR = new udj(10);
    public final Entry[] b;
    public final long c;

    public Metadata(Parcel parcel) {
        this.b = new Entry[parcel.readInt()];
        int i = 0;
        while (true) {
            Entry[] entryArr = this.b;
            if (i >= entryArr.length) {
                this.c = parcel.readLong();
                return;
            } else {
                entryArr[i] = (Entry) parcel.readParcelable(Entry.class.getClassLoader());
                i++;
            }
        }
    }

    public final Metadata a(Entry... entryArr) {
        if (entryArr.length == 0) {
            return this;
        }
        int i = vpw.f16901a;
        Entry[] entryArr2 = this.b;
        Object[] objArrCopyOf = Arrays.copyOf(entryArr2, entryArr2.length + entryArr.length);
        System.arraycopy(entryArr, 0, objArrCopyOf, entryArr2.length, entryArr.length);
        return new Metadata(this.c, (Entry[]) objArrCopyOf);
    }

    public final Metadata b(Metadata metadata) {
        return metadata == null ? this : a(metadata.b);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && Metadata.class == obj.getClass()) {
            Metadata metadata = (Metadata) obj;
            if (Arrays.equals(this.b, metadata.b) && this.c == metadata.c) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return jox.q(this.c) + (Arrays.hashCode(this.b) * 31);
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder("entries=");
        sb.append(Arrays.toString(this.b));
        long j = this.c;
        if (j == -9223372036854775807L) {
            str = "";
        } else {
            str = ", presentationTimeUs=" + j;
        }
        sb.append(str);
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        Entry[] entryArr = this.b;
        parcel.writeInt(entryArr.length);
        for (Entry entry : entryArr) {
            parcel.writeParcelable(entry, 0);
        }
        parcel.writeLong(this.c);
    }

    /* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
    public interface Entry extends Parcelable {
        default byte[] l() {
            return null;
        }

        default b m() {
            return null;
        }

        default void Y(c cVar) {
        }
    }

    public Metadata(long j, Entry... entryArr) {
        this.c = j;
        this.b = entryArr;
    }

    public Metadata(List list) {
        this((Entry[]) list.toArray(new Entry[0]));
    }

    public Metadata(Entry... entryArr) {
        this(-9223372036854775807L, entryArr);
    }
}
