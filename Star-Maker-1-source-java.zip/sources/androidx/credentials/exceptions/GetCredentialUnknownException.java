package androidx.credentials.exceptions;

import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Landroidx/credentials/exceptions/GetCredentialUnknownException;", "Landroidx/credentials/exceptions/GetCredentialException;", "credentials"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class GetCredentialUnknownException extends GetCredentialException {
    public GetCredentialUnknownException(CharSequence charSequence) {
        super(charSequence, com.google.android.gms.identitycredentials.GetCredentialException.ERROR_TYPE_UNKNOWN);
    }
}
