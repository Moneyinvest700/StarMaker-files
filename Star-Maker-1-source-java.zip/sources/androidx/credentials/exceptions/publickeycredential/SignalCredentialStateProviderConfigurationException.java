package androidx.credentials.exceptions.publickeycredential;

import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Landroidx/credentials/exceptions/publickeycredential/SignalCredentialStateProviderConfigurationException;", "Landroidx/credentials/exceptions/publickeycredential/SignalCredentialStateException;", "credentials"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class SignalCredentialStateProviderConfigurationException extends SignalCredentialStateException {
    public SignalCredentialStateProviderConfigurationException() {
        super("this device requires a Google Play Services update for the given feature to be supported", "androidx.credentials.SignalCredentialStateException.TYPE_PROVIDER_CONFIGURATION");
    }
}
