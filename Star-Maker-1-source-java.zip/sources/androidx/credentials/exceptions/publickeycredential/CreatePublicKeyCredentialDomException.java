package androidx.credentials.exceptions.publickeycredential;

import defpackage.a68;
import kotlin.Metadata;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001:\u0001\u0007R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0005\u0010\u0006¨\u0006\b"}, d2 = {"Landroidx/credentials/exceptions/publickeycredential/CreatePublicKeyCredentialDomException;", "Landroidx/credentials/exceptions/publickeycredential/CreatePublicKeyCredentialException;", "La68;", "domError", "La68;", "getDomError", "()La68;", "b6e", "credentials"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class CreatePublicKeyCredentialDomException extends CreatePublicKeyCredentialException {
    public static final /* synthetic */ int c = 0;
    private final a68 domError;

    public CreatePublicKeyCredentialDomException(a68 a68Var, String str) {
        super(str, "androidx.credentials.TYPE_CREATE_PUBLIC_KEY_CREDENTIAL_DOM_EXCEPTION/".concat(a68Var.f846a));
        this.domError = a68Var;
    }
}
