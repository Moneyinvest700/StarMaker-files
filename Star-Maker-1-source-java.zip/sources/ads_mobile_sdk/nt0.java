package ads_mobile_sdk;

import defpackage.pcy;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class nt0 extends PhantomReference {

    /* renamed from: a, reason: collision with root package name */
    public final pcy f2660a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public nt0(pcy pcyVar, Object obj, ReferenceQueue referenceQueue) {
        super(obj, referenceQueue);
        pcyVar.getClass();
        obj.getClass();
        referenceQueue.getClass();
        this.f2660a = pcyVar;
    }
}
