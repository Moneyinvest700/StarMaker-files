package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum mz {
    /* JADX INFO: Fake field, exist only in values array */
    UNKNOWN(-1),
    STRING(0),
    NUMBER(1),
    BOOLEAN(2);


    /* renamed from: a, reason: collision with root package name */
    public final int f2559a;

    mz(int i) {
        this.f2559a = i;
    }
}
