package ads_mobile_sdk;

import java.util.concurrent.ExecutorService;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class vl0 {

    /* renamed from: a, reason: collision with root package name */
    public final ExecutorService f3621a;

    public vl0(ExecutorService executorService) {
        this.f3621a = executorService;
    }
}
