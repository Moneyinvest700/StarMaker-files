package ads_mobile_sdk;

import defpackage.b1y;
import defpackage.gux;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class aq1 implements b1y {

    /* renamed from: a, reason: collision with root package name */
    public final b1y f1034a;
    public final b1y b;
    public final Function1 c;

    public aq1(b1y b1yVar, b1y b1yVar2, Function1 function1) {
        b1yVar.getClass();
        b1yVar2.getClass();
        function1.getClass();
        this.f1034a = b1yVar;
        this.b = b1yVar2;
        this.c = function1;
    }

    @Override // defpackage.b1y
    public final gux a(String str) {
        str.getClass();
        gux guxVarA = this.b.a(str);
        if (guxVarA != null) {
            return new zp1(guxVarA, this);
        }
        if (this.f1034a.a(str) != null) {
            return this.f1034a.a(str);
        }
        return null;
    }
}
