package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum x50 implements x0z {
    SAFE_OR_OTHER(0),
    MALWARE(1),
    PHISHING(2),
    UNWANTED(3),
    BILLING(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f3828a;

    x50(int i) {
        this.f3828a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3828a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + x50.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3828a + " name=" + name() + '>';
    }
}
