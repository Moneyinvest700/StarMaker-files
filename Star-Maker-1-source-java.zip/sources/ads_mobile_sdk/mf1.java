package ads_mobile_sdk;

import defpackage.awy;
import defpackage.ihy;
import defpackage.jxy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class mf1 implements ihy {

    /* renamed from: a, reason: collision with root package name */
    public final awy f2493a;

    public mf1(jxy jxyVar) {
        jxyVar.getClass();
        this.f2493a = jxyVar;
    }
}
