package ads_mobile_sdk;

import android.os.Handler;
import android.os.Looper;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ht1 {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ ht1 f1907a = new ht1();
    public static final Handler b = new Handler(Looper.getMainLooper());
}
