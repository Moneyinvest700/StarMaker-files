package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class uo3 {

    /* renamed from: a, reason: collision with root package name */
    public final long f3514a;
    public final long b;
    public final long c;

    public uo3(long j, long j2, long j3) {
        this.f3514a = j;
        this.c = j2;
        this.b = j3;
    }
}
