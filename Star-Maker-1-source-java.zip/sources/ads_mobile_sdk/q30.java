package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum q30 implements x0z {
    UNKNOWN(0),
    UNAVAILABLE(1),
    NOT_MANAGED(2),
    ENTERPRISE_MANAGED(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f2937a;

    q30(int i) {
        this.f2937a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2937a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + q30.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2937a + " name=" + name() + '>';
    }
}
