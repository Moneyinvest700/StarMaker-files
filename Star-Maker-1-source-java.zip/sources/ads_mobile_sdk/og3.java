package ads_mobile_sdk;

import android.graphics.drawable.Drawable;
import android.net.Uri;
import com.google.android.gms.ads.formats.NativeAd;
import defpackage.mqy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class og3 implements mqy {

    /* renamed from: a, reason: collision with root package name */
    public final Drawable f2744a;
    public final Uri b;
    public final double c;
    public final int d;
    public final int e;

    public og3(NativeAd.Image image) {
        this.f2744a = image.getDrawable();
        this.b = image.getUri();
        this.c = image.getScale();
        this.d = image.getWidth();
        this.e = image.getHeight();
    }

    @Override // defpackage.mqy
    public final double a() {
        return this.c;
    }

    @Override // defpackage.mqy
    public final int b() {
        return this.d;
    }

    @Override // defpackage.mqy
    public final int c() {
        return this.e;
    }

    @Override // defpackage.mqy
    public final Uri d() {
        return this.b;
    }

    @Override // defpackage.mqy
    public final Drawable e() {
        return this.f2744a;
    }
}
