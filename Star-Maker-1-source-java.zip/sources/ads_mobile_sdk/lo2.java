package ads_mobile_sdk;

import android.os.Bundle;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class lo2 {

    /* renamed from: a, reason: collision with root package name */
    public final Bundle f2398a;

    public lo2(Bundle bundle) {
        this.f2398a = bundle;
    }
}
