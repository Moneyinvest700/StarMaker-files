package ads_mobile_sdk;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;
import com.google.android.libraries.ads.mobile.sdk.R;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class v83 extends TextView {
    public static final /* synthetic */ int b = 0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v83(Context context) throws Resources.NotFoundException {
        CharSequence string;
        super(context);
        context.getClass();
        try {
            string = context.getResources().getString(R.string.test_ad);
        } catch (Resources.NotFoundException unused) {
            string = "Test Ad";
        }
        setText(string);
        setTextSize(15.0f);
        setTextColor(-1);
        setPadding(5, 0, 5, 0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setColor(-12303292);
        gradientDrawable.setCornerRadius(8.0f);
        setBackground(gradientDrawable);
    }
}
