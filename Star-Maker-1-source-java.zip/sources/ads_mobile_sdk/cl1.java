package ads_mobile_sdk;

import android.location.Location;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import java.util.Date;
import java.util.Set;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class cl1 implements MediationAdRequest {

    /* renamed from: a, reason: collision with root package name */
    public final Set f1264a;
    public final boolean b;
    public final int c;
    public final int d;
    public final String e;
    public final Location f;

    public cl1(Set set, boolean z, int i, int i2, String str, Location location) {
        this.f1264a = set;
        this.b = z;
        this.c = i;
        this.d = i2;
        this.e = str;
        this.f = location;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final Date getBirthday() {
        return null;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final int getGender() {
        return 0;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final Set getKeywords() {
        return this.f1264a;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final Location getLocation() {
        return this.f;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final String getMaxAdContentRating() {
        return this.e;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final boolean isDesignedForFamilies() {
        return false;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final boolean isTesting() {
        return this.b;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final int taggedForChildDirectedTreatment() {
        return this.c;
    }

    @Override // com.google.android.gms.ads.mediation.MediationAdRequest
    public final int taggedForUnderAgeTreatment() {
        return this.d;
    }

    public /* synthetic */ cl1(Set set, boolean z, int i, int i2, String str) {
        this(set, z, i, i2, str, null);
    }
}
