package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class r30 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final r30 f3057a = new r30();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? i != 5 ? null : s30.TAILORED_WARNING_SUSPICIOUS : s30.TAILORED_WARNING_SUSPICIOUS_BASE : s30.TAILORED_WARNING_CT_ACCOUNT_INFO : s30.TAILORED_WARNING_CT : s30.TAILORED_WARNING_CT_BASE : s30.UNSPECIFIED) != null;
    }
}
