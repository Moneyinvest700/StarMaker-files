package ads_mobile_sdk;

import defpackage.i3h;
import java.util.Map;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class te0 extends i3h implements Function1 {

    /* renamed from: a, reason: collision with root package name */
    public static final te0 f3357a = new te0();

    public te0() {
        super(1);
    }

    public static String a(Map.Entry entry) {
        entry.getClass();
        return entry.getKey() + " = " + entry.getValue();
    }

    @Override // kotlin.jvm.functions.Function1
    public final /* bridge */ /* synthetic */ Object invoke(Object obj) {
        return a((Map.Entry) obj);
    }
}
