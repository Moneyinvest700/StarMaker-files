package ads_mobile_sdk;

import defpackage.wqx;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class mm0 {

    /* renamed from: a, reason: collision with root package name */
    public final String f2515a;
    public final String b;
    public final String c;

    public mm0(String str, String str2, String str3) {
        str3.getClass();
        this.f2515a = str;
        this.b = str2;
        this.c = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof mm0)) {
            return false;
        }
        mm0 mm0Var = (mm0) obj;
        return Intrinsics.e(this.f2515a, mm0Var.f2515a) && Intrinsics.e(this.b, mm0Var.b) && Intrinsics.e(this.c, mm0Var.c);
    }

    public final int hashCode() {
        String str = this.f2515a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.b;
        return this.c.hashCode() + ((iHashCode + (str2 != null ? str2.hashCode() : 0)) * 31);
    }

    public final String toString() {
        String str = this.f2515a;
        String str2 = this.b;
        return wqx.p(wqx.w("FirebaseAnalyticsIds(firebaseAppId=", str, ", firebaseAppInstanceId=", str2, ", firebaseAdEventId="), this.c, ")");
    }
}
