package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum kc implements x0z {
    FALLBACK_NONE(0),
    FALLBACK_TIMEOUT(1);


    /* renamed from: a, reason: collision with root package name */
    public final int f2232a;

    kc(int i) {
        this.f2232a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2232a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + kc.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2232a + " name=" + name() + '>';
    }
}
