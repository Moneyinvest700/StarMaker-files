package ads_mobile_sdk;

import defpackage.cby;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class lu0 {

    /* renamed from: a, reason: collision with root package name */
    public final cby f2413a;

    public lu0(cby cbyVar) {
        this.f2413a = cbyVar;
    }
}
