package ads_mobile_sdk;

import android.graphics.Rect;
import defpackage.r04;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class kj3 {

    /* renamed from: a, reason: collision with root package name */
    public final mj3 f2259a;
    public final boolean b;
    public final int c;
    public final Rect d;
    public final boolean e;
    public final Rect f;
    public final Rect g;
    public final boolean h;
    public final Rect i;
    public final boolean j;
    public final Rect k;

    public kj3(mj3 mj3Var, boolean z, int i, Rect rect, boolean z2, Rect rect2, Rect rect3, boolean z3, Rect rect4, boolean z4, Rect rect5) {
        mj3Var.getClass();
        rect.getClass();
        rect2.getClass();
        rect3.getClass();
        rect4.getClass();
        rect5.getClass();
        this.f2259a = mj3Var;
        this.b = z;
        this.c = i;
        this.d = rect;
        this.e = z2;
        this.f = rect2;
        this.g = rect3;
        this.h = z3;
        this.i = rect4;
        this.j = z4;
        this.k = rect5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof kj3)) {
            return false;
        }
        kj3 kj3Var = (kj3) obj;
        return this.f2259a == kj3Var.f2259a && this.b == kj3Var.b && this.c == kj3Var.c && Intrinsics.e(this.d, kj3Var.d) && this.e == kj3Var.e && Intrinsics.e(this.f, kj3Var.f) && Intrinsics.e(this.g, kj3Var.g) && this.h == kj3Var.h && Intrinsics.e(this.i, kj3Var.i) && this.j == kj3Var.j && Intrinsics.e(this.k, kj3Var.k);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final int hashCode() {
        int iHashCode = this.f2259a.hashCode() * 31;
        boolean z = this.b;
        int i = z;
        if (z != 0) {
            i = 1;
        }
        int iHashCode2 = (this.d.hashCode() + r04.a(this.c, (iHashCode + i) * 31)) * 31;
        boolean z2 = this.e;
        int i2 = z2;
        if (z2 != 0) {
            i2 = 1;
        }
        int iHashCode3 = (this.g.hashCode() + ((this.f.hashCode() + ((iHashCode2 + i2) * 31)) * 31)) * 31;
        boolean z3 = this.h;
        int i3 = z3;
        if (z3 != 0) {
            i3 = 1;
        }
        int iHashCode4 = (this.i.hashCode() + ((iHashCode3 + i3) * 31)) * 31;
        boolean z4 = this.j;
        return this.k.hashCode() + ((iHashCode4 + (z4 ? 1 : z4 ? 1 : 0)) * 31);
    }

    public final String toString() {
        return "ViewabilityEvent(viewabilityUpdateEvent=" + this.f2259a + ", isVisible=" + this.b + ", windowVisibility=" + this.c + ", adPosition=" + this.d + ", isAttachedToWindow=" + this.e + ", screenPosition=" + this.f + ", globalVisibleBox=" + this.g + ", globalVisibleBoxVisible=" + this.h + ", localVisibleBox=" + this.i + ", localVisibleBoxVisible=" + this.j + ", hitRect=" + this.k + ")";
    }
}
