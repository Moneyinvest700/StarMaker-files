package ads_mobile_sdk;

import defpackage.jxy;
import defpackage.kyx;
import defpackage.vay;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class qf1 implements vay {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f2979a;

    public qf1(jxy jxyVar) {
        this.f2979a = jxyVar;
    }

    @Override // defpackage.awy
    public final Object get() {
        kyx kyxVar = (kyx) this.f2979a.get();
        kyxVar.getClass();
        return kyxVar;
    }
}
