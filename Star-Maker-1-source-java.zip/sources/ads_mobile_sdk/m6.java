package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum m6 {
    b("html"),
    /* JADX INFO: Fake field, exist only in values array */
    EF1("native"),
    c("javascript");


    /* renamed from: a, reason: collision with root package name */
    public final String f2458a;

    m6(String str) {
        this.f2458a = str;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return this.f2458a;
    }
}
