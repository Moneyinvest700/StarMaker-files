package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class p30 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final p30 f2821a = new p30();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? null : q30.ENTERPRISE_MANAGED : q30.NOT_MANAGED : q30.UNAVAILABLE : q30.UNKNOWN) != null;
    }
}
