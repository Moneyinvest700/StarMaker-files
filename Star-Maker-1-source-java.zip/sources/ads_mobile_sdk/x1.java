package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum x1 {
    /* JADX INFO: Fake field, exist only in values array */
    EF7("landscape"),
    /* JADX INFO: Fake field, exist only in values array */
    EF17("portrait"),
    /* JADX INFO: Fake field, exist only in values array */
    EF27("unknown");

    x1(String str) {
    }
}
