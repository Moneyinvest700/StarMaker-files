package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum u30 implements x0z {
    UNKNOWN_USER_POPULATION(0),
    SAFE_BROWSING(1),
    EXTENDED_REPORTING(2),
    ENHANCED_PROTECTION(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f3434a;

    u30(int i) {
        this.f3434a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3434a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + u30.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3434a + " name=" + name() + '>';
    }
}
