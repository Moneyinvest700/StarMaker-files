package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum w63 implements x0z {
    STATUS_UNKNOWN(0),
    STATUS_SUCCESS(1),
    STATUS_FAIL(2);


    /* renamed from: a, reason: collision with root package name */
    public final int f3695a;

    w63(int i) {
        this.f3695a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3695a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + w63.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3695a + " name=" + name() + '>';
    }
}
