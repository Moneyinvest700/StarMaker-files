package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum s50 implements x0z {
    SAFE_BROWSING_URL_API_TYPE_UNSPECIFIED(0),
    PVER3_NATIVE(1),
    PVER4_NATIVE(2),
    ANDROID_SAFETYNET(3),
    FLYWHEEL(4),
    REAL_TIME(5),
    PVER5_NATIVE_REAL_TIME(6),
    ANDROID_SAFEBROWSING_REAL_TIME(7),
    ANDROID_SAFEBROWSING(8),
    CLIENT_SIDE_DETECTION(9),
    GLIC(10);


    /* renamed from: a, reason: collision with root package name */
    public final int f3193a;

    s50(int i) {
        this.f3193a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3193a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + s50.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3193a + " name=" + name() + '>';
    }
}
