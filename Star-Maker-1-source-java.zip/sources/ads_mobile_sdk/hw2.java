package ads_mobile_sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class hw2 extends BroadcastReceiver {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ iw2 f1919a = iw2.d;

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
            iw2 iw2Var = this.f1919a;
            iw2Var.a(true, iw2Var.c);
            this.f1919a.b = true;
        } else if (intent.getAction().equals("android.intent.action.SCREEN_ON")) {
            iw2 iw2Var2 = this.f1919a;
            iw2Var2.a(false, iw2Var2.c);
            this.f1919a.b = false;
        }
    }
}
