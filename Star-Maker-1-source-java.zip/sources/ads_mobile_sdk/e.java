package ads_mobile_sdk;

import defpackage.vay;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class e implements vay {

    /* renamed from: a, reason: collision with root package name */
    public final Map f1428a;

    public e(LinkedHashMap linkedHashMap) {
        this.f1428a = Collections.unmodifiableMap(linkedHashMap);
    }
}
