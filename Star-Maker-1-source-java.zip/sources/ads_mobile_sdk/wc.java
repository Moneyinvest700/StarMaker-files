package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum wc implements x0z {
    NETWORK_INTERFACE_UNSPECIFIED(0),
    NETWORK_INTERFACE_NOT_SET(1),
    NETWORK_INTERFACE_ERROR(2),
    NETWORK_INTERFACE_WIFI(3),
    NETWORK_INTERFACE_CELLULAR(4),
    NETWORK_INTERFACE_ETHERNET(5),
    NETWORK_INTERFACE_LOOPBACK(6),
    NETWORK_INTERFACE_OTHER(7),
    NETWORK_INTERFACE_NO_CONNECTION(8);


    /* renamed from: a, reason: collision with root package name */
    public final int f3719a;

    wc(int i) {
        this.f3719a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3719a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + wc.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3719a + " name=" + name() + '>';
    }
}
