package ads_mobile_sdk;

import defpackage.qc5;
import java.util.Map;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class mk0 {

    /* renamed from: a, reason: collision with root package name */
    public final qc5 f2509a;
    public final Map b;

    public mk0(qc5 qc5Var, Map map) {
        qc5Var.getClass();
        map.getClass();
        this.f2509a = qc5Var;
        this.b = map;
    }
}
