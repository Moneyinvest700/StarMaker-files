package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum cx0 {
    UNKNOWN(0),
    PLAYING(1),
    PAUSED(2),
    ENDED(3),
    /* JADX INFO: Fake field, exist only in values array */
    READY(5);


    /* renamed from: a, reason: collision with root package name */
    public final int f1300a;

    cx0(int i) {
        this.f1300a = i;
    }
}
