package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum ct1 {
    SCROLL_VIEW_TYPE_NONE(0),
    SCROLL_VIEW_TYPE_SCROLL_VIEW(1),
    SCROLL_VIEW_TYPE_ABS_LIST_VIEW(2),
    SCROLL_VIEW_TYPE_HORIZONTAL_SCROLL_VIEW(3),
    SCROLL_VIEW_TYPE_SCROLLING_VIEW(4),
    SCROLL_VIEW_TYPE_BY_KEYWORD(5);


    /* renamed from: a, reason: collision with root package name */
    public final int f1290a;

    ct1(int i) {
        this.f1290a = i;
    }
}
