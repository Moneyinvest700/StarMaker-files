package ads_mobile_sdk;

import com.google.common.util.concurrent.ListenableFuture;
import java.io.File;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class y63 {

    /* renamed from: a, reason: collision with root package name */
    public final File f3964a;

    public y63(File file) {
        this.f3964a = file;
    }

    public abstract ListenableFuture a();

    public abstract ListenableFuture a(Object obj);
}
