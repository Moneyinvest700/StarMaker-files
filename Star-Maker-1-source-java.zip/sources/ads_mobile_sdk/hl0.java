package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum hl0 {
    b("Internal error."),
    c("No fill."),
    d("Operation timed out."),
    e("The system WebView required for this operation was terminated.");


    /* renamed from: a, reason: collision with root package name */
    public final String f1882a;

    hl0(String str) {
        this.f1882a = str;
    }

    public final String a() {
        return this.f1882a;
    }
}
