package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class zv2 implements Comparable {

    /* renamed from: a, reason: collision with root package name */
    public final Runnable f4189a;
    public final long b;

    public zv2(Runnable runnable, long j) {
        this.f4189a = runnable;
        this.b = j;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return Long.compare(this.b, ((zv2) obj).b);
    }
}
