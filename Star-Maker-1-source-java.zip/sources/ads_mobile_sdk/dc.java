package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class dc implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final dc f1354a = new dc();

    @Override // defpackage.crx
    public final boolean a(int i) {
        ec ecVar;
        switch (i) {
            case 0:
                ecVar = ec.DEBUGGER_STATE_UNSPECIFIED;
                break;
            case 1:
                ecVar = ec.DEBUGGER_STATE_NOT_INSTALLED;
                break;
            case 2:
                ecVar = ec.DEBUGGER_STATE_INSTALLED;
                break;
            case 3:
                ecVar = ec.DEBUGGER_STATE_ACTIVE;
                break;
            case 4:
                ecVar = ec.DEBUGGER_STATE_ENVVAR;
                break;
            case 5:
                ecVar = ec.DEBUGGER_STATE_MACHPORT;
                break;
            case 6:
                ecVar = ec.DEBUGGER_STATE_ENVVAR_MACHPORT;
                break;
            default:
                ecVar = null;
                break;
        }
        return ecVar != null;
    }
}
