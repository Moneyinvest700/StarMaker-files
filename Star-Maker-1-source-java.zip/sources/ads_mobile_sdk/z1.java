package ads_mobile_sdk;

import defpackage.dmj;
import defpackage.vzy;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum z1 {
    FORMAT_DEFAULT(0),
    ON_AD_OPENED(1),
    ON_AD_SHOW(2),
    THIRD_PARTY_SDK_CALLBACK(3);

    public static final vzy b = new vzy();
    public static final LinkedHashMap c;

    /* renamed from: a, reason: collision with root package name */
    public final int f4077a;

    static {
        z1[] z1VarArrValues = values();
        int iB = dmj.b(z1VarArrValues.length);
        LinkedHashMap linkedHashMap = new LinkedHashMap(iB < 16 ? 16 : iB);
        for (z1 z1Var : z1VarArrValues) {
            linkedHashMap.put(Integer.valueOf(z1Var.f4077a), z1Var);
        }
        c = linkedHashMap;
    }

    z1(int i) {
        this.f4077a = i;
    }
}
