package ads_mobile_sdk;

import android.content.Context;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ox0 {
    public static ox0 b;

    /* renamed from: a, reason: collision with root package name */
    public final px0 f2799a;

    public ox0(Context context) {
        this.f2799a = px0.a(context);
    }

    public final void a(boolean z) {
        synchronized (ox0.class) {
            try {
                this.f2799a.a(Boolean.valueOf(z), "paidv2_publisher_option");
                if (!z) {
                    this.f2799a.a("paidv2_creation_time");
                    this.f2799a.a("paidv2_id");
                    this.f2799a.a("vendor_scoped_gpid_v2_id");
                    this.f2799a.a("vendor_scoped_gpid_v2_creation_time");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean b() {
        boolean z;
        synchronized (ox0.class) {
            z = this.f2799a.b.getBoolean("paidv2_user_option", true);
        }
        return z;
    }

    public final boolean a() {
        boolean z;
        synchronized (ox0.class) {
            z = this.f2799a.b.getBoolean("paidv2_publisher_option", true);
        }
        return z;
    }

    public static final ox0 a(Context context) {
        ox0 ox0Var;
        synchronized (ox0.class) {
            try {
                ox0Var = b;
                if (ox0Var == null) {
                    ox0Var = new ox0(context);
                    b = ox0Var;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return ox0Var;
    }
}
