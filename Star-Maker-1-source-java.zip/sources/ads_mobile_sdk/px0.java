package ads_mobile_sdk;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import defpackage.fiy;
import defpackage.v7y;
import java.io.IOException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class px0 {
    public static px0 c;

    /* renamed from: a, reason: collision with root package name */
    public final String f2917a;
    public final SharedPreferences b;

    public px0(Context context) {
        this.f2917a = context.getPackageName();
        this.b = context.getSharedPreferences("paid_storage_sp", 0);
    }

    public final void a(Object obj, String str) throws IOException {
        boolean zCommit;
        if (obj instanceof String) {
            zCommit = this.b.edit().putString(str, (String) obj).commit();
        } else if (obj instanceof Long) {
            zCommit = this.b.edit().putLong(str, ((Long) obj).longValue()).commit();
        } else if (obj instanceof Boolean) {
            zCommit = this.b.edit().putBoolean(str, ((Boolean) obj).booleanValue()).commit();
        } else {
            if (!(obj instanceof Integer)) {
                Log.e("GpidLifecycleSPHandler", "Unexpected object class " + obj.getClass() + " for app " + this.f2917a);
                fiy.i(v7y.p("Failed to store ", str, " for app "), this.f2917a);
            }
            zCommit = this.b.edit().putInt(str, ((Integer) obj).intValue()).commit();
        }
        if (zCommit) {
            return;
        }
        fiy.i(v7y.p("Failed to store ", str, " for app "), this.f2917a);
    }

    public final void a(String str) throws IOException {
        if (this.b.edit().remove(str).commit()) {
            return;
        }
        fiy.i(v7y.p("Failed to remove ", str, " for app "), this.f2917a);
    }

    public static px0 a(Context context) {
        px0 px0Var = c;
        if (px0Var != null) {
            return px0Var;
        }
        px0 px0Var2 = new px0(context);
        c = px0Var2;
        return px0Var2;
    }
}
