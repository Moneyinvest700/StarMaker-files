package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class au0 extends RuntimeException {

    /* renamed from: a, reason: collision with root package name */
    public final pt0 f1049a;

    public au0(pt0 pt0Var) {
        pt0Var.getClass();
        this.f1049a = pt0Var;
    }
}
