package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class zh0 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final zh0 f4143a = new zh0();

    @Override // defpackage.crx
    public final boolean a(int i) {
        ai0 ai0Var;
        switch (i) {
            case 0:
                ai0Var = ai0.DEVICE_TYPE_UNKNOWN;
                break;
            case 1:
                ai0Var = ai0.DEVICE_TYPE_PHONE;
                break;
            case 2:
                ai0Var = ai0.DEVICE_TYPE_TABLET;
                break;
            case 3:
                ai0Var = ai0.DEVICE_TYPE_WATCH;
                break;
            case 4:
                ai0Var = ai0.DEVICE_TYPE_AUTO;
                break;
            case 5:
                ai0Var = ai0.DEVICE_TYPE_TV;
                break;
            case 6:
                ai0Var = ai0.DEVICE_TYPE_PC;
                break;
            default:
                ai0Var = null;
                break;
        }
        return ai0Var != null;
    }
}
