package ads_mobile_sdk;

import defpackage.any;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class s71 {

    /* renamed from: a, reason: collision with root package name */
    public final any f3202a;

    public s71(any anyVar) {
        anyVar.getClass();
        this.f3202a = anyVar;
    }
}
