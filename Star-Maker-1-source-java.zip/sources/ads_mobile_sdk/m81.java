package ads_mobile_sdk;

import defpackage.jcy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class m81 {

    /* renamed from: a, reason: collision with root package name */
    public final jcy f2467a;

    public m81(jcy jcyVar) {
        this.f2467a = jcyVar;
    }
}
