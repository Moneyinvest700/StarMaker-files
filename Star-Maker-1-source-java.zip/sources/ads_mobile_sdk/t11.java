package ads_mobile_sdk;

import com.ushowmedia.starmaker.profile.ProfileActivity;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum t11 {
    b("definedByJavaScript"),
    c("unspecified"),
    /* JADX INFO: Fake field, exist only in values array */
    EF2("loaded"),
    d("beginToRender"),
    e("onePixel"),
    /* JADX INFO: Fake field, exist only in values array */
    EF65("viewable"),
    /* JADX INFO: Fake field, exist only in values array */
    EF75("audible"),
    /* JADX INFO: Fake field, exist only in values array */
    EF85(ProfileActivity.SOURCE_OTHER);


    /* renamed from: a, reason: collision with root package name */
    public final String f3307a;

    t11(String str) {
        this.f3307a = str;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return this.f3307a;
    }
}
