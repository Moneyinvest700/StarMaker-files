package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum bt1 {
    /* JADX INFO: Fake field, exist only in values array */
    UNKNOWN,
    /* JADX INFO: Fake field, exist only in values array */
    SMALL,
    /* JADX INFO: Fake field, exist only in values array */
    MEDIUM
}
