package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum f00 {
    b("definedByJavaScript"),
    c("htmlDisplay"),
    d("nativeDisplay"),
    e("video"),
    /* JADX INFO: Fake field, exist only in values array */
    EF55("audio");


    /* renamed from: a, reason: collision with root package name */
    public final String f1546a;

    f00(String str) {
        this.f1546a = str;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return this.f1546a;
    }
}
