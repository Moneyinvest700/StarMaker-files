package ads_mobile_sdk;

import defpackage.lxy;
import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class dt0 extends CancellationException implements lxy {

    /* renamed from: a, reason: collision with root package name */
    public final CancellationException f1409a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public dt0(CancellationException cancellationException) {
        super(cancellationException.getMessage());
        cancellationException.getClass();
        this.f1409a = cancellationException;
    }

    @Override // defpackage.lxy
    public final Throwable a() {
        return this.f1409a;
    }
}
