package ads_mobile_sdk;

import defpackage.i3h;
import java.util.Arrays;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class y92 extends i3h implements Function1 {

    /* renamed from: a, reason: collision with root package name */
    public static final y92 f3973a = new y92();

    public y92() {
        super(1);
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        return String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(((Number) obj).byteValue())}, 1));
    }
}
