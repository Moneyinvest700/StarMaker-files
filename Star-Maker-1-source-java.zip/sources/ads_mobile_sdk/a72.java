package ads_mobile_sdk;

import android.content.Context;
import defpackage.wqx;
import java.io.IOException;
import java.util.UUID;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class a72 {

    /* renamed from: a, reason: collision with root package name */
    public final String f966a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;
    public final px0 f;
    public final ox0 g;

    static {
        new UUID(0L, 0L).toString();
    }

    public a72(Context context, String str, String str2, String str3) {
        this.f = px0.a(context);
        this.g = ox0.a(context);
        this.f966a = str;
        this.b = str.concat("_3p");
        this.c = str2;
        this.d = str2.concat("_3p");
        this.e = str3;
    }

    public final mx0 a(long j) throws IOException {
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (jCurrentTimeMillis < 0) {
            defpackage.h1.l(wqx.p(new StringBuilder(), this.e, ": Invalid negative current timestamp. Updating PAID failed"));
            return null;
        }
        px0 px0Var = this.f;
        long j2 = px0Var.b.getLong(this.c, -1L);
        if (j2 != -1) {
            if (jCurrentTimeMillis < j2) {
                this.f.a(Long.valueOf(jCurrentTimeMillis), this.c);
            } else if (jCurrentTimeMillis >= j2 + j) {
                return a(UUID.randomUUID().toString(), false);
            }
        }
        px0 px0Var2 = this.f;
        String string = px0Var2.b.getString(this.f966a, null);
        if (string == null) {
            return a(UUID.randomUUID().toString(), false);
        }
        px0 px0Var3 = this.f;
        return new mx0(px0Var3.b.getLong(this.c, -1L), string);
    }

    public final mx0 a(String str, boolean z) throws IOException {
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (jCurrentTimeMillis >= 0) {
            this.f.a(Long.valueOf(jCurrentTimeMillis), z ? this.d : this.c);
            this.f.a(str, z ? this.b : this.f966a);
            return new mx0(jCurrentTimeMillis, str);
        }
        defpackage.h1.l(wqx.p(new StringBuilder(), this.e, ": Invalid negative current timestamp. Updating PAID failed"));
        return null;
    }
}
