package ads_mobile_sdk;

import defpackage.l3t;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class cl0 {

    /* renamed from: a, reason: collision with root package name */
    public static volatile cl0 f1263a;
    public static volatile cl0 b;
    public static final cl0 c = new cl0();

    public static cl0 a() {
        cl0 cl0VarA;
        if (je.b) {
            return c;
        }
        cl0 cl0Var = f1263a;
        if (cl0Var != null) {
            return cl0Var;
        }
        synchronized (cl0.class) {
            try {
                cl0VarA = f1263a;
                if (cl0VarA == null) {
                    cl0VarA = bl0.a("getEmptyRegistry");
                    if (cl0VarA == null) {
                        cl0VarA = c;
                    }
                    f1263a = cl0VarA;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return cl0VarA;
    }

    public static cl0 b() {
        cl0 cl0VarA;
        cl0 cl0Var = b;
        if (cl0Var != null) {
            return cl0Var;
        }
        synchronized (cl0.class) {
            try {
                cl0 cl0Var2 = b;
                if (cl0Var2 != null) {
                    return cl0Var2;
                }
                if (je.b) {
                    cl0VarA = l3t.e();
                } else {
                    cl0VarA = bl0.a("loadGeneratedRegistry");
                    if (cl0VarA == null && (cl0VarA = l3t.e()) == null && (cl0VarA = bl0.a("getEmptyRegistry")) == null) {
                        cl0VarA = c;
                    }
                }
                b = cl0VarA;
                return cl0VarA;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
