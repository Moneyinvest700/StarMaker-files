package ads_mobile_sdk;

import defpackage.muy;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ql0 implements muy {

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f3002a;

    public ql0(byte[] bArr) {
        this.f3002a = bArr;
    }

    @Override // defpackage.muy
    public final Object a(FileInputStream fileInputStream) {
        try {
            return defpackage.jj2.b(fileInputStream);
        } catch (IOException e) {
            throw new rl0("Cannot read bytes.", e);
        }
    }

    @Override // defpackage.muy
    public final Object a() {
        return this.f3002a;
    }

    @Override // defpackage.muy
    public final void a(Object obj, FileOutputStream fileOutputStream) throws IOException {
        fileOutputStream.write((byte[]) obj);
    }
}
