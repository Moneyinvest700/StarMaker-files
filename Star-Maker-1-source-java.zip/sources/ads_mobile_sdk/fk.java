package ads_mobile_sdk;

import android.content.Context;
import defpackage.qc5;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class fk {

    /* renamed from: a, reason: collision with root package name */
    public final Context f1619a;
    public final qc5 b;

    public fk(Context context, qc5 qc5Var) {
        context.getClass();
        qc5Var.getClass();
        this.f1619a = context;
        this.b = qc5Var;
    }
}
