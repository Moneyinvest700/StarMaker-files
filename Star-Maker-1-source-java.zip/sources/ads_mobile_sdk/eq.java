package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class eq {

    /* renamed from: a, reason: collision with root package name */
    public static final fq f1519a = fq.PRODUCTION;
    public static final int b = 5;

    public static fq a() {
        return f1519a;
    }
}
