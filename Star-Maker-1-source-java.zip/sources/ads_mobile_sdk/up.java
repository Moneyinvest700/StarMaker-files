package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum up implements x0z {
    UNKNOWN(0),
    COLLECTED_BIDDING_SIGNAL(1);


    /* renamed from: a, reason: collision with root package name */
    public final int f3515a;

    up(int i) {
        this.f3515a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3515a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + up.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3515a + " name=" + name() + '>';
    }
}
