package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class dr {

    /* renamed from: a, reason: collision with root package name */
    public final long f1402a;
    public final boolean b;
    public final long c;
    public final boolean d;
    public final boolean e;
    public final boolean f;

    public dr(long j, boolean z, long j2, boolean z2, boolean z3, boolean z4) {
        this.f1402a = j;
        this.b = z;
        this.c = j2;
        this.d = z2;
        this.e = z3;
        this.f = z4;
    }
}
