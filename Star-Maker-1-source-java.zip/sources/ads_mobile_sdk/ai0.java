package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum ai0 implements x0z {
    DEVICE_TYPE_UNKNOWN(0),
    DEVICE_TYPE_PHONE(1),
    DEVICE_TYPE_TABLET(2),
    DEVICE_TYPE_WATCH(3),
    DEVICE_TYPE_AUTO(4),
    DEVICE_TYPE_TV(5),
    DEVICE_TYPE_PC(6);


    /* renamed from: a, reason: collision with root package name */
    public final int f1007a;

    ai0(int i2) {
        this.f1007a = i2;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1007a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + ai0.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1007a + " name=" + name() + '>';
    }
}
