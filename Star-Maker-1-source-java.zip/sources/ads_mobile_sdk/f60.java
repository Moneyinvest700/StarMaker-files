package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum f60 implements x0z {
    UNKNOWN(0),
    PHISHING_INTERSTITIAL(1),
    CLIENT_SIDE_PHISHING_INTERSTITIAL(2),
    MALWARE_INTERSTITIAL(3),
    UWS_INTERSTITIAL(4),
    BILLING_INTERSTITIAL(5),
    BINARY_MALWARE_DOWNLOAD_WARNING(6);


    /* renamed from: a, reason: collision with root package name */
    public final int f1570a;

    f60(int i2) {
        this.f1570a = i2;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1570a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + f60.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1570a + " name=" + name() + '>';
    }
}
