package ads_mobile_sdk;

import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class e03 extends CancellationException {

    /* renamed from: a, reason: collision with root package name */
    public final String f1433a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e03(String str) {
        super(str);
        str.getClass();
        this.f1433a = str;
    }

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.f1433a;
    }
}
