package ads_mobile_sdk;

import defpackage.amf;
import java.util.Iterator;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class xg3 implements Iterator, amf {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Iterator f3874a;

    public xg3(Iterator it) {
        it.getClass();
        this.f3874a = it;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f3874a.hasNext();
    }

    @Override // java.util.Iterator
    public final Object next() {
        return this.f3874a.next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
