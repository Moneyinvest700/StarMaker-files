package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum ic implements x0z {
    DEVICE_IDENTIFIER_NO_ID(0),
    DEVICE_IDENTIFIER_APP_SPECIFIC_ID(1),
    DEVICE_IDENTIFIER_GLOBAL_ID(2),
    DEVICE_IDENTIFIER_ADVERTISER_ID(3),
    DEVICE_IDENTIFIER_ADVERTISER_ID_UNHASHED(4),
    DEVICE_IDENTIFIER_ANDROID_AD_ID(5),
    DEVICE_IDENTIFIER_GFIBER_ADVERTISING_ID(6),
    DEVICE_IDENTIFIER_PER_APP_ID(7),
    DEVICE_IDENTIFIER_PER_APP_ID_V2(8),
    DEVICE_IDENTIFIER_CONNECTED_TV_IFA(9);


    /* renamed from: a, reason: collision with root package name */
    public final int f1972a;

    ic(int i) {
        this.f1972a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1972a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + ic.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1972a + " name=" + name() + '>';
    }
}
