package ads_mobile_sdk;

import defpackage.amf;
import java.util.Iterator;
import java.util.Map;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class zg3 implements Iterator, amf {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Iterator f4141a;
    public final /* synthetic */ Iterator b;

    public zg3(Iterator it) {
        this.b = it;
        this.f4141a = it;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f4141a.hasNext();
    }

    @Override // java.util.Iterator
    public final Object next() {
        return new bh3((Map.Entry) this.b.next());
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
