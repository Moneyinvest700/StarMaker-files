package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class n60 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final n60 f2585a = new n60();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? i != 5 ? null : o60.NOTIFICATION_INITIATED : o60.COPY_PASTE_USER_INITIATED : o60.RENDERER_INITIATED_WITH_USER_GESTURE : o60.RENDERER_INITIATED_WITHOUT_USER_GESTURE : o60.BROWSER_INITIATED : o60.UNDEFINED) != null;
    }
}
