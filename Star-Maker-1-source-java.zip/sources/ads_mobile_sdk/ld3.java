package ads_mobile_sdk;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ld3 {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ ld3[] f2366a = {new ld3()};

    /* JADX INFO: Fake field, exist only in values array */
    ld3 EF2;

    public static ld3[] values() {
        return (ld3[]) f2366a.clone();
    }
}
