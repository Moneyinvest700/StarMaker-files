package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class w50 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final w50 f3688a = new w50();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? null : x50.BILLING : x50.UNWANTED : x50.PHISHING : x50.MALWARE : x50.SAFE_OR_OTHER) != null;
    }
}
