package ads_mobile_sdk;

import com.netease.htprotect.O000000o.O00000o.O000000o.O0000Oo;
import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum xc implements x0z {
    /* JADX INFO: Fake field, exist only in values array */
    PSN_INVALID_ERROR_CODE(1),
    /* JADX INFO: Fake field, exist only in values array */
    ERROR_UNKNOWN(3),
    /* JADX INFO: Fake field, exist only in values array */
    ERROR_NO_SIGNALS(5),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_BLANK_VALUE(7),
    /* JADX INFO: Fake field, exist only in values array */
    ERROR_MEMORY(9),
    /* JADX INFO: Fake field, exist only in values array */
    ERROR_SERVICE(11),
    /* JADX INFO: Fake field, exist only in values array */
    ERROR_SERVICE(13),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_WEB64_FAIL(15),
    /* JADX INFO: Fake field, exist only in values array */
    ERROR_COLLECTION_TIMEOUT(17),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_MD5_CHECK_FAIL(19),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_WEB64_FAIL(2),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_DECRYPT_SIZE_FAIL(4),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_MD5_CHECK_FAIL(8),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_MD5_SIZE_FAIL(16),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_BLANK_VALUE(32),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_INVALID_ERROR_CODE(64),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_BLANK_VALUE(128),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_INVALID_ERROR_CODE(256),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_BLANK_VALUE(512),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_INVALID_ERROR_CODE(1024),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_BLANK_VALUE(2048),
    PSN_ENCODE_SIZE_FAIL(4096),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_BLANK_VALUE(8192),
    PSN_INITIALIZATION_FAIL(16384),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_GASS_CLIENT_FAIL(32768),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_SIGNALS_TIMEOUT(65536),
    /* JADX INFO: Fake field, exist only in values array */
    PSN_TINK_FAIL(O0000Oo.O000000o.O0000OoO);


    /* renamed from: a, reason: collision with root package name */
    public final int f3853a;

    xc(int i) {
        this.f3853a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3853a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + xc.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3853a + " name=" + name() + '>';
    }
}
