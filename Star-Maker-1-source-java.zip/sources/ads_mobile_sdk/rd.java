package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class rd implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final rd f3094a = new rd();

    @Override // defpackage.crx
    public final boolean a(int i) {
        sd sdVar;
        switch (i) {
            case 0:
                sdVar = sd.UNKNOWN_ENCRYPTION_METHOD;
                break;
            case 1:
                sdVar = sd.BITSLICER;
                break;
            case 2:
                sdVar = sd.TINK_HYBRID;
                break;
            case 3:
                sdVar = sd.UNENCRYPTED;
                break;
            case 4:
                sdVar = sd.DG;
                break;
            case 5:
                sdVar = sd.DG_XTEA;
                break;
            case 6:
                sdVar = sd.ADSHIELD_3;
                break;
            default:
                sdVar = null;
                break;
        }
        return sdVar != null;
    }
}
