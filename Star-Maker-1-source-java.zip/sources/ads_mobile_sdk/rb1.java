package ads_mobile_sdk;

import defpackage.lpy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class rb1 implements lpy {

    /* renamed from: a, reason: collision with root package name */
    public final sb1 f3087a;

    public rb1(sb1 sb1Var) {
        this.f3087a = sb1Var;
    }
}
