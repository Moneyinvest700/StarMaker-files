package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum yd implements x0z {
    UNKNOWN_PROTO(0),
    AFMA_SIGNALS(1),
    UNITY_SIGNALS(2),
    PARTNER_SIGNALS(3),
    FALLBACK_SIGNALS(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f3987a;

    yd(int i) {
        this.f3987a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3987a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + yd.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3987a + " name=" + name() + '>';
    }
}
