package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum ak implements x0z {
    UNSUPPORTED(0),
    ARM7(2),
    X86(4),
    ARM64(5),
    X86_64(6),
    RISCV64(7),
    UNKNOWN(999);


    /* renamed from: a, reason: collision with root package name */
    public final int f1012a;

    ak(int i2) {
        this.f1012a = i2;
    }

    public static ak a(int i2) {
        if (i2 == 0) {
            return UNSUPPORTED;
        }
        if (i2 == 2) {
            return ARM7;
        }
        if (i2 == 999) {
            return UNKNOWN;
        }
        if (i2 == 4) {
            return X86;
        }
        if (i2 == 5) {
            return ARM64;
        }
        if (i2 == 6) {
            return X86_64;
        }
        if (i2 != 7) {
            return null;
        }
        return RISCV64;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1012a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + ak.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1012a + " name=" + name() + '>';
    }
}
