package ads_mobile_sdk;

import android.view.MotionEvent;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class an1 {

    /* renamed from: a, reason: collision with root package name */
    public final float f1024a;
    public final float b;

    public an1(MotionEvent motionEvent) {
        this.f1024a = motionEvent.getX();
        this.b = motionEvent.getY();
    }
}
