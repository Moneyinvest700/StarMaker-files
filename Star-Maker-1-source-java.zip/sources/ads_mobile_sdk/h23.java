package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class h23 {

    /* renamed from: a, reason: collision with root package name */
    public final String f1815a;
    public final String b;
    public final Class[] c;

    public h23(String str, String str2, Class... clsArr) {
        this.f1815a = str;
        this.b = str2;
        this.c = clsArr;
    }
}
