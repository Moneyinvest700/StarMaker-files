package ads_mobile_sdk;

import defpackage.jxy;
import defpackage.vay;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class rz implements vay {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f3168a;

    public rz(jxy jxyVar) {
        this.f3168a = jxyVar;
    }

    @Override // defpackage.awy
    public final Object get() {
        String str = (String) this.f3168a.get();
        str.getClass();
        return "afma-sdk-a-v".concat(str);
    }
}
