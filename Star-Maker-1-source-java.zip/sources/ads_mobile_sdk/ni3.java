package ads_mobile_sdk;

import defpackage.aky;
import defpackage.ixx;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ni3 extends aky {

    /* renamed from: a, reason: collision with root package name */
    public static final Method f2630a = a();

    @Override // defpackage.nhy
    public final int a(String str) {
        try {
            return ((Integer) f2630a.invoke(str, StandardCharsets.UTF_8)).intValue();
        } catch (ReflectiveOperationException e) {
            ixx.r(e);
            return 0;
        }
    }

    public static Method a() {
        try {
            return String.class.getMethod("encodedLength", Charset.class);
        } catch (ReflectiveOperationException unused) {
            return null;
        }
    }
}
