package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class xd implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final xd f3857a = new xd();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? null : yd.FALLBACK_SIGNALS : yd.PARTNER_SIGNALS : yd.UNITY_SIGNALS : yd.AFMA_SIGNALS : yd.UNKNOWN_PROTO) != null;
    }
}
