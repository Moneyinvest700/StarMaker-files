package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class f40 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final f40 f1563a = new f40();

    @Override // defpackage.crx
    public final boolean a(int i) {
        g40 g40Var;
        switch (i) {
            case 0:
                g40Var = g40.ACTION_UNSPECIFIED;
                break;
            case 1:
                g40Var = g40.PROCEED;
                break;
            case 2:
                g40Var = g40.DISCARD;
                break;
            case 3:
                g40Var = g40.KEEP;
                break;
            case 4:
                g40Var = g40.CLOSE;
                break;
            case 5:
                g40Var = g40.CANCEL;
                break;
            case 6:
                g40Var = g40.DISMISS;
                break;
            case 7:
                g40Var = g40.BACK;
                break;
            case 8:
                g40Var = g40.OPEN_SUBPAGE;
                break;
            case 9:
                g40Var = g40.PROCEED_DEEP_SCAN;
                break;
            case 10:
                g40Var = g40.OPEN_LEARN_MORE_LINK;
                break;
            default:
                g40Var = null;
                break;
        }
        return g40Var != null;
    }
}
