package ads_mobile_sdk;

import android.content.Context;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ah2 {

    /* renamed from: a, reason: collision with root package name */
    public final Context f1005a;

    public ah2(Context context) {
        context.getClass();
        this.f1005a = context;
    }
}
