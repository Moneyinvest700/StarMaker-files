package ads_mobile_sdk;

import defpackage.jxy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ij2 {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f2000a;
    public final jxy b;
    public final jxy c;
    public final jxy d;
    public final jxy e;
    public final jxy f;
    public final jxy g;
    public final jxy h;
    public final jxy i;

    public ij2(mg0 mg0Var, jxy jxyVar, jxy jxyVar2, jxy jxyVar3, mg0 mg0Var2, jxy jxyVar4, jxy jxyVar5, jxy jxyVar6, jxy jxyVar7) {
        this.f2000a = mg0Var;
        this.b = jxyVar;
        this.c = jxyVar2;
        this.d = jxyVar3;
        this.e = mg0Var2;
        this.f = jxyVar4;
        this.g = jxyVar5;
        this.h = jxyVar6;
        this.i = jxyVar7;
    }
}
