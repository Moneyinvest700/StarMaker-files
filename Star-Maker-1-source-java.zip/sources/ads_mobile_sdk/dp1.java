package ads_mobile_sdk;

import android.net.Uri;
import defpackage.i3h;
import kotlin.jvm.functions.Function0;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class dp1 extends i3h implements Function0 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f1399a;
    public final /* synthetic */ Uri b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public dp1(String str, Uri uri) {
        super(0);
        this.f1399a = str;
        this.b = uri;
    }

    @Override // kotlin.jvm.functions.Function0
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final String invoke() {
        return "Saved " + this.f1399a + " to " + this.b;
    }
}
