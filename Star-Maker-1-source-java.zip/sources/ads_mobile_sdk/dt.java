package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum dt implements x0z {
    BLOB_TYPE_UNKNOWN(0),
    BLOB_TYPE_DEFAULT(1),
    BLOB_TYPE_JAR(2),
    BLOB_TYPE_WEB_SUGGEST(3),
    BLOB_TYPE_BRAIN_SUGGEST(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f1408a;

    dt(int i) {
        this.f1408a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1408a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + dt.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1408a + " name=" + name() + '>';
    }
}
