package ads_mobile_sdk;

import defpackage.h2y;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class e02 {

    /* renamed from: a, reason: collision with root package name */
    public static h2y f1432a;

    public static h2y a() {
        return f1432a;
    }
}
