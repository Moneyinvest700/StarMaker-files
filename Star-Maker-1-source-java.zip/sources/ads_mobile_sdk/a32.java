package ads_mobile_sdk;

import android.app.UiModeManager;
import android.content.Context;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class a32 {

    /* renamed from: a, reason: collision with root package name */
    public static UiModeManager f950a;

    public static int a() {
        UiModeManager uiModeManager = f950a;
        if (uiModeManager == null) {
            return 3;
        }
        int currentModeType = uiModeManager.getCurrentModeType();
        if (currentModeType != 1) {
            return currentModeType != 4 ? 3 : 1;
        }
        return 2;
    }

    public static void a(Context context) {
        f950a = (UiModeManager) context.getSystemService("uimode");
    }
}
