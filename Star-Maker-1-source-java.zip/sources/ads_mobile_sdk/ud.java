package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum ud implements x0z {
    ENUM_FALSE(0),
    ENUM_TRUE(1),
    ENUM_FAILURE(2),
    ENUM_UNKNOWN(1000);


    /* renamed from: a, reason: collision with root package name */
    public final int f3475a;

    ud(int i) {
        this.f3475a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3475a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + ud.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3475a + " name=" + name() + '>';
    }
}
