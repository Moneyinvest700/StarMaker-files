package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class l50 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final l50 f2335a = new l50();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? null : m50.AD_RESOURCE_AUTO_CLICK_DESTINATION : m50.AD_RESOURCE_POST_CLICK : m50.AD_RESOURCE_CREATIVE : m50.AD_RESOURCE_UNKNOWN) != null;
    }
}
