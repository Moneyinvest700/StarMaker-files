package ads_mobile_sdk;

import android.view.View;
import defpackage.g0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class vq0 {

    /* renamed from: a, reason: collision with root package name */
    public final g0z f3639a;
    public final String b;
    public final wq0 c;
    public final String d;

    public vq0(View view, wq0 wq0Var, String str) {
        this.f3639a = new g0z(view);
        this.b = view.getClass().getCanonicalName();
        this.c = wq0Var;
        this.d = str;
    }
}
