package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class t30 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final t30 f3314a = new t30();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? null : u30.ENHANCED_PROTECTION : u30.EXTENDED_REPORTING : u30.SAFE_BROWSING : u30.UNKNOWN_USER_POPULATION) != null;
    }
}
