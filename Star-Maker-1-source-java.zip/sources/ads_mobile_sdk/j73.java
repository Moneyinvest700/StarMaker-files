package ads_mobile_sdk;

import defpackage.jxy;
import defpackage.vay;
import java.io.File;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class j73 implements vay {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f2090a;

    public j73(jxy jxyVar) {
        this.f2090a = jxyVar;
    }

    @Override // defpackage.awy
    public final Object get() {
        return new File(new File((File) this.f2090a.get(), "ocs"), "pcbc");
    }
}
