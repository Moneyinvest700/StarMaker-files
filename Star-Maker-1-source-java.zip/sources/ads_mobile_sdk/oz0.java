package ads_mobile_sdk;

import defpackage.l0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class oz0 implements l0z {

    /* renamed from: a, reason: collision with root package name */
    public final int f2805a;
    public final byte[] b;

    public oz0(int i, byte[] bArr) {
        this.f2805a = i;
        this.b = bArr;
    }
}
