package ads_mobile_sdk;

import defpackage.awy;
import defpackage.jxy;
import defpackage.spy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class rl implements spy {

    /* renamed from: a, reason: collision with root package name */
    public final awy f3124a;

    public rl(jxy jxyVar) {
        jxyVar.getClass();
        this.f3124a = jxyVar;
    }
}
