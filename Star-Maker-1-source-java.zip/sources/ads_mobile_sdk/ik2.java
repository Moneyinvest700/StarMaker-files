package ads_mobile_sdk;

import defpackage.ycy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ik2 implements ycy {

    /* renamed from: a, reason: collision with root package name */
    public final Object f2003a;

    public ik2(Object obj) {
        obj.getClass();
        this.f2003a = obj;
    }

    public final Object a() {
        return this.f2003a;
    }
}
