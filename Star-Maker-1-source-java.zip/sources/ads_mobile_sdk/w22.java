package ads_mobile_sdk;

import defpackage.zty;
import java.util.ArrayDeque;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class w22 implements zty {
    public final ArrayDeque b = new ArrayDeque();
    public v22 c = null;

    /* renamed from: a, reason: collision with root package name */
    public final ThreadPoolExecutor f3676a = new ThreadPoolExecutor(1, 1, 1, TimeUnit.SECONDS, new LinkedBlockingQueue());

    public final void a() {
        v22 v22Var = (v22) this.b.poll();
        this.c = v22Var;
        if (v22Var != null) {
            v22Var.a(this.f3676a);
        }
    }

    public final void a(v22 v22Var) {
        v22Var.f3556a = this;
        this.b.add(v22Var);
        if (this.c == null) {
            a();
        }
    }
}
