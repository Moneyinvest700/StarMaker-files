package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum bt implements x0z {
    BLOB_STATE_AVAILABLE(1),
    BLOB_STATE_INACTIVE(2),
    BLOB_STATE_ACTIVE(3),
    BLOB_STATE_FAILED(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f1165a;

    bt(int i) {
        this.f1165a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1165a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + bt.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1165a + " name=" + name() + '>';
    }
}
