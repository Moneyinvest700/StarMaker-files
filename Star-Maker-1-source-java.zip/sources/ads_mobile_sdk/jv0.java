package ads_mobile_sdk;

import defpackage.wqx;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class jv0 {

    /* renamed from: a, reason: collision with root package name */
    public final String f2171a;
    public final String b;

    public jv0(String str, String str2) {
        this.f2171a = str;
        this.b = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof jv0)) {
            return false;
        }
        jv0 jv0Var = (jv0) obj;
        return Intrinsics.e(this.f2171a, jv0Var.f2171a) && Intrinsics.e(this.b, jv0Var.b);
    }

    public final int hashCode() {
        String str = this.f2171a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.b;
        return iHashCode + (str2 != null ? str2.hashCode() : 0);
    }

    public final String toString() {
        return wqx.n("SystemDefaultLocale(language=", this.f2171a, ", country=", this.b, ")");
    }
}
