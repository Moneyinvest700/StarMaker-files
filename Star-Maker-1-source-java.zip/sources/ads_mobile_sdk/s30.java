package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum s30 implements x0z {
    UNSPECIFIED(0),
    TAILORED_WARNING_CT_BASE(1),
    TAILORED_WARNING_CT(2),
    TAILORED_WARNING_CT_ACCOUNT_INFO(3),
    TAILORED_WARNING_SUSPICIOUS_BASE(4),
    TAILORED_WARNING_SUSPICIOUS(5);


    /* renamed from: a, reason: collision with root package name */
    public final int f3184a;

    s30(int i) {
        this.f3184a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3184a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + s30.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3184a + " name=" + name() + '>';
    }
}
