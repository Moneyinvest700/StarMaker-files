package ads_mobile_sdk;

import defpackage.wsy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum tg2 {
    UNKNOWN,
    FIFO,
    ECPM;


    /* renamed from: a, reason: collision with root package name */
    public static final wsy f3368a = new wsy();
}
