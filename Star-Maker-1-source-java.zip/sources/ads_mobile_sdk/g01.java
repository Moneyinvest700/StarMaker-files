package ads_mobile_sdk;

import defpackage.o46;
import java.io.Closeable;
import java.util.Map;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class g01 implements Closeable {

    /* renamed from: a, reason: collision with root package name */
    public final int f1677a;
    public final String b;
    public final Map c;
    public final ir2 d;
    public final o46 e;
    public final String f;

    public g01(int i, String str, Map map, ir2 ir2Var, o46 o46Var, String str2) {
        this.f1677a = i;
        this.b = str;
        this.c = map;
        this.d = ir2Var;
        this.e = o46Var;
        this.f = str2;
    }

    public final ir2 a() {
        return this.d;
    }

    public final int b() {
        return this.f1677a;
    }

    public final String c() {
        return this.b;
    }

    public final String d() {
        return this.f;
    }

    public final boolean e() {
        int i = this.f1677a;
        return 200 <= i && i < 300;
    }

    public /* synthetic */ g01(int i, String str, Map map, ir2 ir2Var, o46 o46Var, String str2, int i2) {
        this(i, str, map, ir2Var, o46Var, str2);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
    }
}
