package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum sm3 {
    DEFAULT,
    FIXED_RECTANGLE,
    FLUID_RECTANGLE,
    FULLSCREEN,
    VIDEO_RECT
}
