package ads_mobile_sdk;

import defpackage.awy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class c41 {

    /* renamed from: a, reason: collision with root package name */
    public final awy f1199a;
    public final boolean b;

    public c41(awy awyVar, boolean z) {
        awyVar.getClass();
        this.f1199a = awyVar;
        this.b = z;
    }

    public /* synthetic */ c41(awy awyVar) {
        this(awyVar, false);
    }
}
