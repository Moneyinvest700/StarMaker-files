package ads_mobile_sdk;

import android.os.Build;
import defpackage.dse;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class zp0 {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ zp0 f4171a;
    public static final dse b;

    static {
        Double dValueOf = Double.valueOf(0.5d);
        f4171a = new zp0();
        dse dseVar = new dse();
        int i = Build.VERSION.SDK_INT;
        if (i >= 30) {
            dseVar.u("4", 1);
            dseVar.u("5", 1);
            dseVar.u("6", dValueOf);
            dseVar.u("9", dValueOf);
            dseVar.u("0", 0);
            dseVar.u("2", 0);
            dseVar.u("3", 0);
            dseVar.u("7", 0);
            dseVar.u("12", -1);
            dseVar.u("1", -1);
            if (i >= 33) {
                dseVar.u("14", -1);
            }
            dseVar.u("13", -1);
            if (i >= 35) {
                dseVar.u("15", -1);
                dseVar.u("16", -1);
            }
            dseVar.u("8", -1);
            dseVar.u("10", -1);
            dseVar.u("11", -1);
        }
        b = dseVar;
    }
}
