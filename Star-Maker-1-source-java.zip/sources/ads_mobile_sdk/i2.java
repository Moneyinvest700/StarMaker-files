package ads_mobile_sdk;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class i2 {

    /* renamed from: a, reason: collision with root package name */
    public static final i2 f1940a;
    public static final /* synthetic */ i2[] b;

    static {
        i2 i2Var = new i2();
        f1940a = i2Var;
        b = new i2[]{i2Var};
    }

    public static i2[] values() {
        return (i2[]) b.clone();
    }

    public final int a() {
        return 7;
    }
}
