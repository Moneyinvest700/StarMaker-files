package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class r50 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final r50 f3064a = new r50();

    @Override // defpackage.crx
    public final boolean a(int i) {
        s50 s50Var;
        switch (i) {
            case 0:
                s50Var = s50.SAFE_BROWSING_URL_API_TYPE_UNSPECIFIED;
                break;
            case 1:
                s50Var = s50.PVER3_NATIVE;
                break;
            case 2:
                s50Var = s50.PVER4_NATIVE;
                break;
            case 3:
                s50Var = s50.ANDROID_SAFETYNET;
                break;
            case 4:
                s50Var = s50.FLYWHEEL;
                break;
            case 5:
                s50Var = s50.REAL_TIME;
                break;
            case 6:
                s50Var = s50.PVER5_NATIVE_REAL_TIME;
                break;
            case 7:
                s50Var = s50.ANDROID_SAFEBROWSING_REAL_TIME;
                break;
            case 8:
                s50Var = s50.ANDROID_SAFEBROWSING;
                break;
            case 9:
                s50Var = s50.CLIENT_SIDE_DETECTION;
                break;
            case 10:
                s50Var = s50.GLIC;
                break;
            default:
                s50Var = null;
                break;
        }
        return s50Var != null;
    }
}
