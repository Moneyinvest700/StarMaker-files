package ads_mobile_sdk;

import android.view.MotionEvent;
import java.util.ArrayDeque;
import java.util.HashMap;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class bn1 {
    public MotionEvent b;

    /* renamed from: a, reason: collision with root package name */
    public final ArrayDeque f1150a = new ArrayDeque();
    public zm1 c = new zm1();

    public final synchronized void a(MotionEvent motionEvent) {
        try {
            if (motionEvent.getAction() == 1) {
                this.b = MotionEvent.obtain(motionEvent);
            }
            zm1 zm1Var = this.c;
            zm1Var.getClass();
            int action = motionEvent.getAction();
            if (action == 0) {
                zm1Var.f4164a++;
                zm1Var.g = 0.0d;
                zm1Var.e = motionEvent.getRawX();
                zm1Var.f = motionEvent.getRawY();
                zm1Var.h = motionEvent.getX();
                zm1Var.i = motionEvent.getY();
                zm1Var.j = motionEvent.getRawX();
                zm1Var.k = motionEvent.getRawY();
            } else if (action == 1) {
                zm1Var.c++;
                zm1Var.g = Math.hypot(motionEvent.getRawX() - zm1Var.e, motionEvent.getRawY() - zm1Var.f) + zm1Var.g;
                zm1Var.e = motionEvent.getRawX();
                zm1Var.f = motionEvent.getRawY();
            } else if (action == 2) {
                zm1Var.b += motionEvent.getHistorySize() + 1;
                zm1Var.g = Math.hypot(motionEvent.getRawX() - zm1Var.e, motionEvent.getRawY() - zm1Var.f) + zm1Var.g;
                zm1Var.e = motionEvent.getRawX();
                zm1Var.f = motionEvent.getRawY();
            } else if (action == 3) {
                zm1Var.d++;
            }
            if (this.f1150a.size() >= 6) {
                this.f1150a.remove();
            }
            this.f1150a.add(new an1(motionEvent));
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized void a(HashMap map) {
        try {
            MotionEvent motionEvent = this.b;
            if (motionEvent != null) {
                map.put(com.secmtp.sdk.core.mw.nv.mm, motionEvent);
                this.b = null;
            }
            map.put("oe", this.c);
            ArrayDeque arrayDeque = this.f1150a;
            map.put("ro", arrayDeque.toArray(new an1[arrayDeque.size()]));
            this.c = new zm1();
            this.f1150a.clear();
            MotionEvent motionEvent2 = this.b;
            if (motionEvent2 != null) {
                motionEvent2.recycle();
                this.b = null;
            }
        } catch (Throwable th) {
            throw th;
        }
    }
}
