package ads_mobile_sdk;

import defpackage.pzy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum z02 {
    UNDEFINED,
    CLICK,
    NOTIFICATION_CLICK;


    /* renamed from: a, reason: collision with root package name */
    public static final pzy f4075a = new pzy();
}
