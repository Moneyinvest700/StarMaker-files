package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class m30 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final m30 f2449a = new m30();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? null : n30.CLIENT_GENERATION : n30.SOURCE_UNSPECIFIED) != null;
    }
}
