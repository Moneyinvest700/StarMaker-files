package ads_mobile_sdk;

import defpackage.dmj;
import defpackage.owy;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum w1 {
    FORMAT_DEFAULT(0),
    ONE_PIXEL(1),
    /* JADX INFO: Fake field, exist only in values array */
    AD_LOAD(2),
    /* JADX INFO: Fake field, exist only in values array */
    NO_IMPRESSION(3),
    THIRD_PARTY_SDK_CALLBACK(4);

    public static final owy b = new owy();
    public static final LinkedHashMap c;

    /* renamed from: a, reason: collision with root package name */
    public final int f3668a;

    static {
        w1[] w1VarArrValues = values();
        int iB = dmj.b(w1VarArrValues.length);
        LinkedHashMap linkedHashMap = new LinkedHashMap(iB < 16 ? 16 : iB);
        for (w1 w1Var : w1VarArrValues) {
            linkedHashMap.put(Integer.valueOf(w1Var.f3668a), w1Var);
        }
        c = linkedHashMap;
    }

    w1(int i) {
        this.f3668a = i;
    }
}
