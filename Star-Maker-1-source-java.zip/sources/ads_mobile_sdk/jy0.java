package ads_mobile_sdk;

import com.google.android.libraries.ads.mobile.sdk.common.AdRequest;
import com.google.android.libraries.ads.mobile.sdk.common.RequestConfiguration;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class jy0 {

    /* renamed from: a, reason: collision with root package name */
    public final AdRequest f2179a;
    public final RequestConfiguration b;

    public jy0(AdRequest adRequest, RequestConfiguration requestConfiguration) {
        adRequest.getClass();
        this.f2179a = adRequest;
        this.b = requestConfiguration;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof jy0)) {
            return false;
        }
        jy0 jy0Var = (jy0) obj;
        return Intrinsics.e(this.f2179a, jy0Var.f2179a) && Intrinsics.e(this.b, jy0Var.b);
    }

    public final int hashCode() {
        int iHashCode = this.f2179a.hashCode() * 31;
        RequestConfiguration requestConfiguration = this.b;
        return iHashCode + (requestConfiguration == null ? 0 : requestConfiguration.hashCode());
    }

    public final String toString() {
        return "H5LoadParams(adRequest=" + this.f2179a + ", requestConfiguration=" + this.b + ")";
    }

    public /* synthetic */ jy0(AdRequest adRequest) {
        this(adRequest, null);
    }
}
