package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class e60 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final e60 f1449a = new e60();

    @Override // defpackage.crx
    public final boolean a(int i) {
        f60 f60Var;
        switch (i) {
            case 0:
                f60Var = f60.UNKNOWN;
                break;
            case 1:
                f60Var = f60.PHISHING_INTERSTITIAL;
                break;
            case 2:
                f60Var = f60.CLIENT_SIDE_PHISHING_INTERSTITIAL;
                break;
            case 3:
                f60Var = f60.MALWARE_INTERSTITIAL;
                break;
            case 4:
                f60Var = f60.UWS_INTERSTITIAL;
                break;
            case 5:
                f60Var = f60.BILLING_INTERSTITIAL;
                break;
            case 6:
                f60Var = f60.BINARY_MALWARE_DOWNLOAD_WARNING;
                break;
            default:
                f60Var = null;
                break;
        }
        return f60Var != null;
    }
}
