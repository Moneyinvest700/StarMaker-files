package ads_mobile_sdk;

import defpackage.jxy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class sb1 {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f3218a;
    public final jxy b;
    public final jxy c;

    public sb1(jxy jxyVar, jxy jxyVar2, jxy jxyVar3) {
        this.f3218a = jxyVar;
        this.b = jxyVar2;
        this.c = jxyVar3;
    }
}
