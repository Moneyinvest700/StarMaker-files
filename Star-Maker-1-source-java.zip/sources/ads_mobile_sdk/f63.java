package ads_mobile_sdk;

import android.content.Context;
import android.view.View;
import defpackage.zyy;
import java.util.ArrayList;
import java.util.HashMap;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class f63 implements zyy {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f1572a = new ArrayList();

    @Override // defpackage.zyy
    public final synchronized void a(HashMap map, Context context, View view) {
        map.put("vst", new ArrayList(this.f1572a));
        this.f1572a.clear();
    }

    @Override // defpackage.zyy
    public final void a(HashMap map) {
    }

    @Override // defpackage.zyy
    public final void b(HashMap map) {
    }
}
