package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum h50 implements x0z {
    TYPE_UNKNOWN(0),
    TYPE_CREATIVE(1);


    /* renamed from: a, reason: collision with root package name */
    public final int f1824a;

    h50(int i) {
        this.f1824a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1824a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + h50.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1824a + " name=" + name() + '>';
    }
}
