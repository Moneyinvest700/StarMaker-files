package ads_mobile_sdk;

import java.io.IOException;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class dg1 extends IOException {

    /* renamed from: a, reason: collision with root package name */
    public boolean f1369a;

    public dg1(IOException iOException) {
        super(iOException.getMessage(), iOException);
    }

    public static dg1 a() {
        return new dg1("Protocol message had invalid UTF-8.");
    }

    public static dg1 b() {
        return new dg1("CodedInputStream encountered an embedded string or message which claimed to have negative size.");
    }

    public static dg1 c() {
        return new dg1("Failed to parse the message.");
    }

    public static dg1 d() {
        return new dg1("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length.");
    }

    public dg1(cg1 cg1Var) {
        super("Unable to parse map entry.", cg1Var);
    }

    public dg1(String str) {
        super(str);
    }
}
