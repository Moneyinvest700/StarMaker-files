package ads_mobile_sdk;

import com.ushowmedia.starmaker.online.smgateway.bean.multichat.SeatItem;
import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum gc2 implements x0z {
    USER_POPULATION_UNSPECIFIED(0),
    CARTER_SB_CHROME_INTERSTITIAL(1),
    GMAIL_PHISHY_JOURNEY(2),
    DOWNLOAD_RELATED_POPULATION_MIN(1000),
    RISKY_DOWNLOADER(1001),
    INFREQUENT_DOWNLOADER(1002),
    REGULAR_DOWNLOADER(1003),
    BOTLIKE_DOWNLOADER(1004),
    DOCUMENT_DOWNLOADER(1005),
    HIGHLY_TECHNICAL_DOWNLOADER(1006),
    LOW_DOWNLOAD_WARNING_CLICK_THROUGH_RATE(SeatItem.SEAT_MULTI_SEAT_ROOM_SEAT_ID_NUM_7),
    HIGH_DOWNLOAD_WARNING_CLICK_THROUGH_RATE(SeatItem.SEAT_MULTI_SEAT_ROOM_SEAT_ID_NUM_8),
    SPAM_PING_SENDER(SeatItem.SEAT_MULTI_SEAT_ROOM_SEAT_ID_NUM_9),
    RFA_TRUSTED(1010),
    DOWNLOAD_RELATED_POPULATION_MAX(1999);


    /* renamed from: a, reason: collision with root package name */
    public final int f1719a;

    gc2(int i) {
        this.f1719a = i;
    }

    public static gc2 a(int i) {
        if (i == 0) {
            return USER_POPULATION_UNSPECIFIED;
        }
        if (i == 1) {
            return CARTER_SB_CHROME_INTERSTITIAL;
        }
        if (i == 2) {
            return GMAIL_PHISHY_JOURNEY;
        }
        if (i == 1999) {
            return DOWNLOAD_RELATED_POPULATION_MAX;
        }
        switch (i) {
            case 1000:
                return DOWNLOAD_RELATED_POPULATION_MIN;
            case 1001:
                return RISKY_DOWNLOADER;
            case 1002:
                return INFREQUENT_DOWNLOADER;
            case 1003:
                return REGULAR_DOWNLOADER;
            case 1004:
                return BOTLIKE_DOWNLOADER;
            case 1005:
                return DOCUMENT_DOWNLOADER;
            case 1006:
                return HIGHLY_TECHNICAL_DOWNLOADER;
            case SeatItem.SEAT_MULTI_SEAT_ROOM_SEAT_ID_NUM_7 /* 1007 */:
                return LOW_DOWNLOAD_WARNING_CLICK_THROUGH_RATE;
            case SeatItem.SEAT_MULTI_SEAT_ROOM_SEAT_ID_NUM_8 /* 1008 */:
                return HIGH_DOWNLOAD_WARNING_CLICK_THROUGH_RATE;
            case SeatItem.SEAT_MULTI_SEAT_ROOM_SEAT_ID_NUM_9 /* 1009 */:
                return SPAM_PING_SENDER;
            case 1010:
                return RFA_TRUSTED;
            default:
                return null;
        }
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1719a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + gc2.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1719a + " name=" + name() + '>';
    }
}
