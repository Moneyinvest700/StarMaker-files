package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class hc implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final hc f1846a = new hc();

    @Override // defpackage.crx
    public final boolean a(int i) {
        ic icVar;
        switch (i) {
            case 0:
                icVar = ic.DEVICE_IDENTIFIER_NO_ID;
                break;
            case 1:
                icVar = ic.DEVICE_IDENTIFIER_APP_SPECIFIC_ID;
                break;
            case 2:
                icVar = ic.DEVICE_IDENTIFIER_GLOBAL_ID;
                break;
            case 3:
                icVar = ic.DEVICE_IDENTIFIER_ADVERTISER_ID;
                break;
            case 4:
                icVar = ic.DEVICE_IDENTIFIER_ADVERTISER_ID_UNHASHED;
                break;
            case 5:
                icVar = ic.DEVICE_IDENTIFIER_ANDROID_AD_ID;
                break;
            case 6:
                icVar = ic.DEVICE_IDENTIFIER_GFIBER_ADVERTISING_ID;
                break;
            case 7:
                icVar = ic.DEVICE_IDENTIFIER_PER_APP_ID;
                break;
            case 8:
                icVar = ic.DEVICE_IDENTIFIER_PER_APP_ID_V2;
                break;
            case 9:
                icVar = ic.DEVICE_IDENTIFIER_CONNECTED_TV_IFA;
                break;
            default:
                icVar = null;
                break;
        }
        return icVar != null;
    }
}
