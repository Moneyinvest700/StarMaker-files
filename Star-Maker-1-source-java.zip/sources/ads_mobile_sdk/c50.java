package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class c50 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final c50 f1203a = new c50();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? null : d50.PHISHY_PASTE_EVENT : d50.PHISHY_KEY_EVENT : d50.PHISHY_CLICK_EVENT : d50.UNSPECIFIED) != null;
    }
}
