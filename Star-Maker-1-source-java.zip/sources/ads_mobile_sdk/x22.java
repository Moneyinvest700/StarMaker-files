package ads_mobile_sdk;

import android.webkit.WebView;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class x22 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ WebView f3815a;
    public final /* synthetic */ String b;
    public final /* synthetic */ y22 c;

    public x22(y22 y22Var, WebView webView, String str) {
        this.c = y22Var;
        this.f3815a = webView;
        this.b = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        y22 y22Var = this.c;
        WebView webView = this.f3815a;
        String str = this.b;
        y22Var.getClass();
        y22.a(webView, str);
    }
}
