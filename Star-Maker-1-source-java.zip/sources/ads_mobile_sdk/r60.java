package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class r60 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final r60 f3069a = new r60();

    @Override // defpackage.crx
    public final boolean a(int i) {
        s60 s60Var;
        switch (i) {
            case 1:
                s60Var = s60.EVENT_URL;
                break;
            case 2:
                s60Var = s60.LANDING_PAGE;
                break;
            case 3:
                s60Var = s60.LANDING_REFERRER;
                break;
            case 4:
                s60Var = s60.CLIENT_REDIRECT;
                break;
            case 5:
                s60Var = s60.SERVER_REDIRECT;
                break;
            case 6:
                s60Var = s60.RECENT_NAVIGATION;
                break;
            case 7:
                s60Var = s60.REFERRER;
                break;
            default:
                s60Var = null;
                break;
        }
        return s60Var != null;
    }
}
