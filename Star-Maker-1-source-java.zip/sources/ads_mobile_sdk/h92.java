package ads_mobile_sdk;

import com.google.android.libraries.ads.mobile.sdk.common.BaseRequest;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class h92 {

    /* renamed from: a, reason: collision with root package name */
    public final int f1838a;
    public final BaseRequest b;
    public long c;
    public int d;

    public h92(int i, BaseRequest baseRequest, long j) {
        baseRequest.getClass();
        this.f1838a = i;
        this.b = baseRequest;
        this.c = j;
    }

    public final BaseRequest a() {
        return this.b;
    }

    public final int b() {
        return this.d;
    }

    public final int c() {
        return this.f1838a;
    }
}
