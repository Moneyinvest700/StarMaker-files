package ads_mobile_sdk;

import defpackage.yly;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class yu0 {

    /* renamed from: a, reason: collision with root package name */
    public final yly f4052a;

    public yu0(yly ylyVar) {
        this.f4052a = ylyVar;
    }
}
