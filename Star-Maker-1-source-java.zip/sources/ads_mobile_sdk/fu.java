package ads_mobile_sdk;

import android.os.SystemClock;
import defpackage.hvx;
import defpackage.jxy;
import defpackage.vay;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class fu implements vay {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f1655a;

    public fu(jxy jxyVar) {
        this.f1655a = jxyVar;
    }

    @Override // defpackage.awy
    public final Object get() {
        hvx hvxVar = (hvx) this.f1655a.get();
        hvxVar.getClass();
        hvxVar.getClass();
        return Long.valueOf(SystemClock.elapsedRealtime());
    }
}
