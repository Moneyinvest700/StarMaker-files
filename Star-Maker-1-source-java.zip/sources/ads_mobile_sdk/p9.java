package ads_mobile_sdk;

import java.util.ArrayList;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class p9 {

    /* renamed from: a, reason: collision with root package name */
    public final vq0 f2842a;
    public final ArrayList b = new ArrayList();

    public p9(vq0 vq0Var, String str) {
        this.f2842a = vq0Var;
        a(str);
    }

    public final void a(String str) {
        this.b.add(str);
    }
}
