package ads_mobile_sdk;

import defpackage.hxy;
import defpackage.jxy;
import defpackage.vay;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class fh implements vay {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f1611a;

    public fh(jxy jxyVar) {
        this.f1611a = jxyVar;
    }

    @Override // defpackage.awy
    public final Object get() {
        hxy hxyVar = (hxy) this.f1611a.get();
        hxyVar.getClass();
        return hxyVar;
    }
}
