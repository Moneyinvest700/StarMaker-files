package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum w62 {
    b("native"),
    c("javascript"),
    d("none");


    /* renamed from: a, reason: collision with root package name */
    public final String f3694a;

    w62(String str) {
        this.f3694a = str;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return this.f3694a;
    }
}
