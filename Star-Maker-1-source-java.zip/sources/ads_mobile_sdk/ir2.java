package ads_mobile_sdk;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.nio.charset.Charset;
import kotlin.text.Charsets;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ir2 implements Closeable {

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f2032a;

    public ir2(byte[] bArr) {
        bArr.getClass();
        this.f2032a = bArr;
    }

    public static String a(ir2 ir2Var) {
        Charset charset = Charsets.UTF_8;
        ir2Var.getClass();
        charset.getClass();
        return new String(ir2Var.f2032a, charset);
    }

    public final ByteArrayInputStream a() {
        return new ByteArrayInputStream(this.f2032a);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
    }
}
