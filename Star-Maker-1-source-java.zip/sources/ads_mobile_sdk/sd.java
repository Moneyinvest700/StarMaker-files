package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum sd implements x0z {
    UNKNOWN_ENCRYPTION_METHOD(0),
    BITSLICER(1),
    TINK_HYBRID(2),
    UNENCRYPTED(3),
    DG(4),
    DG_XTEA(5),
    ADSHIELD_3(6);


    /* renamed from: a, reason: collision with root package name */
    public final int f3225a;

    sd(int i2) {
        this.f3225a = i2;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3225a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + sd.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3225a + " name=" + name() + '>';
    }
}
