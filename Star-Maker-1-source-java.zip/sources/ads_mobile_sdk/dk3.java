package ads_mobile_sdk;

import androidx.webkit.StartUpLocation;
import androidx.webkit.WebViewStartUpResult;
import defpackage.jvx;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class dk3 implements jvx {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ WebViewStartUpResult f1385a;

    public dk3(WebViewStartUpResult webViewStartUpResult) {
        this.f1385a = webViewStartUpResult;
    }

    @Override // defpackage.jvx
    public final List a() {
        try {
            List<StartUpLocation> nonUiThreadBlockingStartUpLocations = this.f1385a.getNonUiThreadBlockingStartUpLocations();
            if (nonUiThreadBlockingStartUpLocations != null) {
                ArrayList arrayList = new ArrayList();
                Iterator<T> it = nonUiThreadBlockingStartUpLocations.iterator();
                while (it.hasNext()) {
                    String stackInformation = ((StartUpLocation) it.next()).getStackInformation();
                    if (stackInformation == null) {
                        stackInformation = null;
                    }
                    if (stackInformation != null) {
                        arrayList.add(stackInformation);
                    }
                }
                return arrayList;
            }
        } catch (Throwable unused) {
        }
        return null;
    }

    @Override // defpackage.jvx
    public final List b() {
        try {
            List<StartUpLocation> uiThreadBlockingStartUpLocations = this.f1385a.getUiThreadBlockingStartUpLocations();
            if (uiThreadBlockingStartUpLocations != null) {
                ArrayList arrayList = new ArrayList();
                Iterator<T> it = uiThreadBlockingStartUpLocations.iterator();
                while (it.hasNext()) {
                    String stackInformation = ((StartUpLocation) it.next()).getStackInformation();
                    if (stackInformation == null) {
                        stackInformation = null;
                    }
                    if (stackInformation != null) {
                        arrayList.add(stackInformation);
                    }
                }
                return arrayList;
            }
        } catch (Throwable unused) {
        }
        return null;
    }

    @Override // defpackage.jvx
    public final Long getMaxTimePerTaskInUiThreadMillis() {
        try {
            return this.f1385a.getMaxTimePerTaskInUiThreadMillis();
        } catch (Throwable unused) {
            return null;
        }
    }

    @Override // defpackage.jvx
    public final Long getTotalTimeInUiThreadMillis() {
        try {
            return this.f1385a.getTotalTimeInUiThreadMillis();
        } catch (Throwable unused) {
            return null;
        }
    }
}
