package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class j50 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final j50 f2082a = new j50();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return k50.a(i) != null;
    }
}
