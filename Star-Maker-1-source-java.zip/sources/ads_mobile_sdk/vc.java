package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class vc implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final vc f3588a = new vc();

    @Override // defpackage.crx
    public final boolean a(int i) {
        wc wcVar;
        switch (i) {
            case 0:
                wcVar = wc.NETWORK_INTERFACE_UNSPECIFIED;
                break;
            case 1:
                wcVar = wc.NETWORK_INTERFACE_NOT_SET;
                break;
            case 2:
                wcVar = wc.NETWORK_INTERFACE_ERROR;
                break;
            case 3:
                wcVar = wc.NETWORK_INTERFACE_WIFI;
                break;
            case 4:
                wcVar = wc.NETWORK_INTERFACE_CELLULAR;
                break;
            case 5:
                wcVar = wc.NETWORK_INTERFACE_ETHERNET;
                break;
            case 6:
                wcVar = wc.NETWORK_INTERFACE_LOOPBACK;
                break;
            case 7:
                wcVar = wc.NETWORK_INTERFACE_OTHER;
                break;
            case 8:
                wcVar = wc.NETWORK_INTERFACE_NO_CONNECTION;
                break;
            default:
                wcVar = null;
                break;
        }
        return wcVar != null;
    }
}
