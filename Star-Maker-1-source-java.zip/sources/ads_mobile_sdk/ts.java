package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum ts implements x0z {
    NONE(0),
    GZIP(1),
    BROTLI(2),
    UNKNOWN(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f3401a;

    ts(int i) {
        this.f3401a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3401a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + ts.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3401a + " name=" + name() + '>';
    }
}
