package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum x7 implements x0z {
    ADSHIELD_VERSION_UNSPECIFIED(0),
    ADSHIELD_VERSION_1(1),
    ADSHIELD_VERSION_2(2),
    ADSHIELD_VERSION_3(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f3836a;

    x7(int i) {
        this.f3836a = i;
    }

    public static x7 a(int i) {
        if (i == 0) {
            return ADSHIELD_VERSION_UNSPECIFIED;
        }
        if (i == 1) {
            return ADSHIELD_VERSION_1;
        }
        if (i == 2) {
            return ADSHIELD_VERSION_2;
        }
        if (i != 3) {
            return null;
        }
        return ADSHIELD_VERSION_3;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3836a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + x7.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3836a + " name=" + name() + '>';
    }
}
