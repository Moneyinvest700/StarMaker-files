package ads_mobile_sdk;

import defpackage.h2z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class pt0 implements h2z {
    public final fb1 b;

    public pt0(fb1 fb1Var) {
        this.b = fb1Var;
    }

    public fb1 a() {
        return this.b;
    }

    public Throwable b() {
        return null;
    }

    public /* synthetic */ pt0(fb1 fb1Var, int i) {
        this(fb1Var);
    }
}
