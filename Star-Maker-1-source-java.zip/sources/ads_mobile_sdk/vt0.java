package ads_mobile_sdk;

import defpackage.h2z;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class vt0 implements h2z {
    public final Object b;

    public vt0(Object obj) {
        this.b = obj;
    }

    public final Object a() {
        return this.b;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof vt0) && Intrinsics.e(this.b, ((vt0) obj).b);
    }

    public final int hashCode() {
        Object obj = this.b;
        if (obj == null) {
            return 0;
        }
        return obj.hashCode();
    }

    public final String toString() {
        return "Success(result=" + this.b + ")";
    }
}
