package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum m50 implements x0z {
    AD_RESOURCE_UNKNOWN(0),
    AD_RESOURCE_CREATIVE(1),
    AD_RESOURCE_POST_CLICK(2),
    AD_RESOURCE_AUTO_CLICK_DESTINATION(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f2456a;

    m50(int i) {
        this.f2456a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2456a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + m50.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2456a + " name=" + name() + '>';
    }
}
