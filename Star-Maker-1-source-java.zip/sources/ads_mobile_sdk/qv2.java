package ads_mobile_sdk;

import com.google.android.gms.tasks.TaskCompletionSource;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class qv2 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final TaskCompletionSource f3035a;

    public qv2() {
        this.f3035a = null;
    }

    public abstract void a();

    @Override // java.lang.Runnable
    public final void run() {
        try {
            a();
        } catch (Exception e) {
            TaskCompletionSource taskCompletionSource = this.f3035a;
            if (taskCompletionSource != null) {
                taskCompletionSource.trySetException(e);
            }
        }
    }

    public qv2(TaskCompletionSource taskCompletionSource) {
        this.f3035a = taskCompletionSource;
    }
}
