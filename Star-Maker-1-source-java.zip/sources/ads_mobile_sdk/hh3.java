package ads_mobile_sdk;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class hh3 {

    /* renamed from: a, reason: collision with root package name */
    public final Unsafe f1870a;

    public hh3(Unsafe unsafe) {
        this.f1870a = unsafe;
    }

    public abstract void a(Object obj, long j, double d);

    public abstract void a(Object obj, long j, float f);

    public abstract void a(Object obj, long j, boolean z);

    public boolean a() {
        Unsafe unsafe = this.f1870a;
        if (unsafe == null) {
            return false;
        }
        try {
            Class<?> cls = unsafe.getClass();
            cls.getMethod("objectFieldOffset", Field.class);
            cls.getMethod("arrayBaseOffset", Class.class);
            cls.getMethod("arrayIndexScale", Class.class);
            Class cls2 = Long.TYPE;
            cls.getMethod("getInt", Object.class, cls2);
            cls.getMethod("putInt", Object.class, cls2, Integer.TYPE);
            cls.getMethod("getLong", Object.class, cls2);
            cls.getMethod("putLong", Object.class, cls2, cls2);
            cls.getMethod("getObject", Object.class, cls2);
            cls.getMethod("putObject", Object.class, cls2, Object.class);
            return true;
        } catch (Throwable th) {
            ih3.a(th);
            return false;
        }
    }

    public abstract boolean a(Object obj, long j);

    public abstract double b(Object obj, long j);

    /* JADX WARN: Removed duplicated region for block: B:13:0x0037 A[PHI: r4
      0x0037: PHI (r4v11 java.lang.reflect.Field) = (r4v8 java.lang.reflect.Field), (r4v14 java.lang.reflect.Field) binds: [B:22:0x0049, B:12:0x0035] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:16:0x003b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean b() {
        /*
            r4 = this;
            java.lang.Class r0 = java.lang.Long.TYPE
            sun.misc.Unsafe r4 = r4.f1870a
            r1 = 0
            if (r4 != 0) goto L8
            return r1
        L8:
            java.lang.Class r4 = r4.getClass()     // Catch: java.lang.Throwable -> L39
            java.lang.String r2 = "objectFieldOffset"
            java.lang.Class<java.lang.reflect.Field> r3 = java.lang.reflect.Field.class
            java.lang.Class[] r3 = new java.lang.Class[]{r3}     // Catch: java.lang.Throwable -> L39
            r4.getMethod(r2, r3)     // Catch: java.lang.Throwable -> L39
            java.lang.String r2 = "getLong"
            java.lang.Class<java.lang.Object> r3 = java.lang.Object.class
            java.lang.Class[] r3 = new java.lang.Class[]{r3, r0}     // Catch: java.lang.Throwable -> L39
            r4.getMethod(r2, r3)     // Catch: java.lang.Throwable -> L39
            sun.misc.Unsafe r4 = ads_mobile_sdk.ih3.f1995a     // Catch: java.lang.Throwable -> L39
            boolean r4 = ads_mobile_sdk.je.b()     // Catch: java.lang.Throwable -> L39
            java.lang.Class<java.nio.Buffer> r2 = java.nio.Buffer.class
            r3 = 0
            if (r4 == 0) goto L3b
            java.lang.String r4 = "effectiveDirectAddress"
            java.lang.reflect.Field r4 = r2.getDeclaredField(r4)     // Catch: java.lang.Throwable -> L34
            goto L35
        L34:
            r4 = r3
        L35:
            if (r4 == 0) goto L3b
        L37:
            r3 = r4
            goto L4c
        L39:
            r4 = move-exception
            goto L51
        L3b:
            java.lang.String r4 = "address"
            java.lang.reflect.Field r4 = r2.getDeclaredField(r4)     // Catch: java.lang.Throwable -> L42
            goto L43
        L42:
            r4 = r3
        L43:
            if (r4 == 0) goto L4c
            java.lang.Class r2 = r4.getType()     // Catch: java.lang.Throwable -> L39
            if (r2 != r0) goto L4c
            goto L37
        L4c:
            if (r3 != 0) goto L4f
            return r1
        L4f:
            r4 = 1
            return r4
        L51:
            ads_mobile_sdk.ih3.a(r4)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: ads_mobile_sdk.hh3.b():boolean");
    }

    public abstract float c(Object obj, long j);

    public final int d(Object obj, long j) {
        return this.f1870a.getInt(obj, j);
    }

    public final long e(Object obj, long j) {
        return this.f1870a.getLong(obj, j);
    }

    public final Object f(Object obj, long j) {
        return this.f1870a.getObject(obj, j);
    }

    public final int b(Class cls) {
        return this.f1870a.arrayIndexScale(cls);
    }

    public final int a(Class cls) {
        return this.f1870a.arrayBaseOffset(cls);
    }

    public final long a(Field field) {
        return this.f1870a.objectFieldOffset(field);
    }

    public final void a(int i, long j, Object obj) {
        this.f1870a.putInt(obj, j, i);
    }

    public final void a(Object obj, long j, long j2) {
        this.f1870a.putLong(obj, j, j2);
    }

    public final void a(long j, Object obj, Object obj2) {
        this.f1870a.putObject(obj, j, obj2);
    }
}
