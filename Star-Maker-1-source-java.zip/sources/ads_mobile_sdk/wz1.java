package ads_mobile_sdk;

import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class wz1 {

    /* renamed from: a, reason: collision with root package name */
    public final xz1 f3801a;

    public wz1(xz1 xz1Var) {
        xz1Var.getClass();
        this.f3801a = xz1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof wz1) && Intrinsics.e(this.f3801a, ((wz1) obj).f3801a);
    }

    public final int hashCode() {
        return this.f3801a.hashCode();
    }

    public final String toString() {
        return "NetworkPingConfig(networkPingStrategy=" + this.f3801a + ")";
    }
}
