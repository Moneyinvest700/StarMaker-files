package ads_mobile_sdk;

import defpackage.i3h;
import kotlin.jvm.functions.Function0;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ub3 extends i3h implements Function0 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Integer f3470a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ub3(Integer num) {
        super(0);
        this.f3470a = num;
    }

    @Override // kotlin.jvm.functions.Function0
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final String invoke() {
        return "Creating Thread with priority offset " + this.f3470a;
    }
}
