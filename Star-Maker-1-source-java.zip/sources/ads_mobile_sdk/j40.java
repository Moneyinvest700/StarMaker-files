package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum j40 implements x0z {
    SURFACE_UNSPECIFIED(0),
    BUBBLE_MAINPAGE(1),
    BUBBLE_SUBPAGE(2),
    DOWNLOADS_PAGE(3),
    DOWNLOAD_PROMPT(4),
    DOWNLOAD_NOTIFICATION(5);


    /* renamed from: a, reason: collision with root package name */
    public final int f2077a;

    j40(int i) {
        this.f2077a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2077a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + j40.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2077a + " name=" + name() + '>';
    }
}
