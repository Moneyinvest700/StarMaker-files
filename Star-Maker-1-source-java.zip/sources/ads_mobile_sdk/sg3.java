package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class sg3 extends RuntimeException {
    public sg3() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
