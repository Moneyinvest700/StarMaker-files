package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class bl0 {

    /* renamed from: a, reason: collision with root package name */
    public static final Class f1140a;

    static {
        Class<?> cls;
        try {
            cls = Class.forName("com.google.protobuf.ExtensionRegistry");
        } catch (ClassNotFoundException unused) {
            cls = null;
        }
        f1140a = cls;
    }

    public static final cl0 a(String str) {
        Class cls = f1140a;
        if (cls == null) {
            return null;
        }
        try {
            return (cl0) cls.getDeclaredMethod(str, null).invoke(null, null);
        } catch (Exception unused) {
            return null;
        }
    }
}
