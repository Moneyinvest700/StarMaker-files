package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class qj1 {

    /* renamed from: a, reason: collision with root package name */
    public final int f2996a;
    public final long b;
    public final Throwable c;
    public final String d;
    public final long e;

    public qj1(int i, long j, Throwable th, String str, long j2) {
        this.f2996a = i;
        this.b = j;
        this.c = th;
        this.d = str;
        this.e = j2;
    }
}
