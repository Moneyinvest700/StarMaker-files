package ads_mobile_sdk;

import defpackage.i3h;
import java.util.Map;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class z92 extends i3h implements Function1 {

    /* renamed from: a, reason: collision with root package name */
    public static final z92 f4111a = new z92();

    public z92() {
        super(1);
    }

    public static String a(Map.Entry entry) {
        return entry.getKey() + ":" + entry.getValue();
    }

    @Override // kotlin.jvm.functions.Function1
    public final /* bridge */ /* synthetic */ Object invoke(Object obj) {
        return a((Map.Entry) obj);
    }
}
