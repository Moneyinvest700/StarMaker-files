package ads_mobile_sdk;

import android.os.Process;
import android.text.TextUtils;
import android.util.Log;
import defpackage.v7y;
import defpackage.wqx;
import java.util.IllegalFormatException;
import java.util.Locale;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes5.dex */
public final class oj1 {

    /* renamed from: a, reason: collision with root package name */
    public final String f2753a;

    public oj1(String str) {
        this.f2753a = wqx.k("UID: [" + Process.myUid() + "]  PID: [" + Process.myPid() + "] ", str);
    }

    public static String a(String str, String str2, Object... objArr) {
        if (objArr.length > 0) {
            try {
                str2 = String.format(Locale.US, str2, objArr);
            } catch (IllegalFormatException e) {
                Log.e("PlayCore", "Unable to format " + str2, e);
                str2 = str2 + " [" + TextUtils.join(", ", objArr) + "]";
            }
        }
        return v7y.g(str, " : ", str2);
    }

    public final void b(String str, Object... objArr) {
        if (Log.isLoggable("PlayCore", 5)) {
            a(this.f2753a, str, objArr);
        }
    }

    public final void a(String str, Object... objArr) {
        if (Log.isLoggable("PlayCore", 4)) {
            a(this.f2753a, str, objArr);
        }
    }
}
