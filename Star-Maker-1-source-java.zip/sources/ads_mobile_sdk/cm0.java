package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum cm0 {
    b("_ac"),
    c("_ai"),
    d("_ar");


    /* renamed from: a, reason: collision with root package name */
    public final String f1267a;

    cm0(String str) {
        this.f1267a = str;
    }

    public final String a() {
        return this.f1267a;
    }
}
