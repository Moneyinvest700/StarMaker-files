package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class lc implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final lc f2360a = new lc();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? null : mc.FUNCTION_CLASS_REPLACEMETHOD : mc.FUNCTION_CLASS_ADDMETHOD : mc.FUNCTION_METHOD_SETIMPLEMENTATIONS : mc.FUNCTION_METHOD_EXCHANGEIMPLEMENTATIONS : mc.FUNCTION_UNSPECIFIED) != null;
    }
}
