package ads_mobile_sdk;

import com.google.android.libraries.ads.mobile.sdk.rewarded.RewardItem;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class zr2 implements RewardItem {

    /* renamed from: a, reason: collision with root package name */
    public final int f4181a;
    public final String b;

    public zr2(String str, int i) {
        this.f4181a = i;
        this.b = str;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.rewarded.RewardItem
    public final int getAmount() {
        return this.f4181a;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.rewarded.RewardItem
    public final String getType() {
        return this.b;
    }
}
