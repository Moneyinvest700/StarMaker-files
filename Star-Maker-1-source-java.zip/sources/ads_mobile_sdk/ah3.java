package ads_mobile_sdk;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ah3 extends wg3 implements Set {
    public final Set b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ah3(Set set) {
        super(set);
        set.getClass();
        this.b = set;
    }

    @Override // ads_mobile_sdk.wg3, java.util.Collection, java.util.Set
    public final boolean contains(Object obj) {
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        return this.f3739a.contains((Map.Entry) obj);
    }

    @Override // ads_mobile_sdk.wg3, java.util.Collection, java.lang.Iterable, java.util.Set
    public final Iterator iterator() {
        return new zg3(this.b.iterator());
    }
}
