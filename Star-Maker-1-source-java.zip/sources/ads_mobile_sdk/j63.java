package ads_mobile_sdk;

import defpackage.fvy;
import org.json.JSONObject;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class j63 implements fvy {

    /* renamed from: a, reason: collision with root package name */
    public JSONObject f2087a;
    public final w22 b;

    public j63(w22 w22Var) {
        this.b = w22Var;
    }
}
