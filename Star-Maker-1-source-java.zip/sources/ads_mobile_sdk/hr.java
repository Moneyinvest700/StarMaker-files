package ads_mobile_sdk;

import android.content.Intent;
import android.net.Uri;
import defpackage.i3h;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class hr extends i3h implements Function1 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Intent f1900a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public hr(Intent intent) {
        super(1);
        this.f1900a = intent;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String str = (String) obj;
        str.getClass();
        return this.f1900a.setData(Uri.parse(str));
    }
}
