package ads_mobile_sdk;

import defpackage.d0z;
import java.nio.ByteBuffer;
import java.security.MessageDigest;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes11.dex */
public final class xf implements d0z {

    /* renamed from: a, reason: collision with root package name */
    public final ByteBuffer f3865a;

    public xf(ByteBuffer byteBuffer) {
        this.f3865a = byteBuffer.slice();
    }

    @Override // defpackage.d0z
    public final void a(MessageDigest[] messageDigestArr, long j, int i) {
        ByteBuffer byteBufferSlice;
        synchronized (this.f3865a) {
            int i2 = (int) j;
            this.f3865a.position(i2);
            this.f3865a.limit(i2 + i);
            byteBufferSlice = this.f3865a.slice();
        }
        for (MessageDigest messageDigest : messageDigestArr) {
            byteBufferSlice.position(0);
            messageDigest.update(byteBufferSlice);
        }
    }

    @Override // defpackage.d0z
    public final long size() {
        return this.f3865a.capacity();
    }
}
