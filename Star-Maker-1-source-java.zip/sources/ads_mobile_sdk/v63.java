package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum v63 implements x0z {
    STATUS_UNKNOWN(0),
    STATUS_UPDATE_PROGRAM_BYTECODE(1),
    STATUS_UPDATE_VM_AND_PROGRAM_BYTECODE(2),
    STATUS_NO_UPDATE(3),
    STATUS_FAILURE_ARCHITECTURE_NOT_SUPPORTED(4),
    STATUS_FAILURE_INVALID_RESPONSE_DECODE_FAILURE(5),
    STATUS_FAILURE_INVALID_RESPONSE_HTTP_ERROR(6),
    STATUS_FAILURE_INVALID_RESPONSE_EMPTY_BYTECODE(7),
    STATUS_FAILURE_INVALID_RESPONSE_PROTO_ERROR(8),
    STATUS_FAILURE_INVALID_RESPONSE_PROTO_ERROR_NPE(9),
    STATUS_FAILURE_INVALID_RESPONSE_PROGRAM_VALIDATION_FAILED(10),
    STATUS_FAILURE_INVALID_RESPONSE_SIGNATURE_VALIDATION_FAILED(11),
    STATUS_FAILURE_INVALID_RESPONSE_HTTP_RUNTIME_EXCEPTION(12);


    /* renamed from: a, reason: collision with root package name */
    public final int f3571a;

    v63(int i) {
        this.f3571a = i;
    }

    public static v63 a(int i) {
        switch (i) {
            case 0:
                return STATUS_UNKNOWN;
            case 1:
                return STATUS_UPDATE_PROGRAM_BYTECODE;
            case 2:
                return STATUS_UPDATE_VM_AND_PROGRAM_BYTECODE;
            case 3:
                return STATUS_NO_UPDATE;
            case 4:
                return STATUS_FAILURE_ARCHITECTURE_NOT_SUPPORTED;
            case 5:
                return STATUS_FAILURE_INVALID_RESPONSE_DECODE_FAILURE;
            case 6:
                return STATUS_FAILURE_INVALID_RESPONSE_HTTP_ERROR;
            case 7:
                return STATUS_FAILURE_INVALID_RESPONSE_EMPTY_BYTECODE;
            case 8:
                return STATUS_FAILURE_INVALID_RESPONSE_PROTO_ERROR;
            case 9:
                return STATUS_FAILURE_INVALID_RESPONSE_PROTO_ERROR_NPE;
            case 10:
                return STATUS_FAILURE_INVALID_RESPONSE_PROGRAM_VALIDATION_FAILED;
            case 11:
                return STATUS_FAILURE_INVALID_RESPONSE_SIGNATURE_VALIDATION_FAILED;
            case 12:
                return STATUS_FAILURE_INVALID_RESPONSE_HTTP_RUNTIME_EXCEPTION;
            default:
                return null;
        }
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3571a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + v63.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3571a + " name=" + name() + '>';
    }
}
