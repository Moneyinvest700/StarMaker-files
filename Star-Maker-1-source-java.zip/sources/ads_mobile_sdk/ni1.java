package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ni1 {

    /* renamed from: a, reason: collision with root package name */
    public Object f2629a;

    public final Object a(String str) {
        Object obj;
        str.getClass();
        synchronized (this) {
            obj = this.f2629a;
            if (obj == null) {
                throw new IllegalStateException(str.toString());
            }
        }
        return obj;
    }

    public final boolean b() {
        return this.f2629a != null;
    }

    public final Object a() {
        return a("The backing field has not yet been initialized.");
    }

    public final void a(Object obj) {
        obj.getClass();
        synchronized (this) {
            this.f2629a = obj;
        }
    }
}
