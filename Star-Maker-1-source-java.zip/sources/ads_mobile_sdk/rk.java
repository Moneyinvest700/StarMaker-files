package ads_mobile_sdk;

import defpackage.ppy;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public class rk implements ppy {

    /* renamed from: a, reason: collision with root package name */
    public final AtomicBoolean f3121a = new AtomicBoolean(true);
}
