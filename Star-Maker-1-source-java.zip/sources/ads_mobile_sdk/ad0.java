package ads_mobile_sdk;

import defpackage.jxy;
import java.util.Optional;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ad0 implements jxy {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f988a;

    public ad0(jxy jxyVar) {
        jxyVar.getClass();
        this.f988a = jxyVar;
    }

    @Override // defpackage.awy
    public final Object get() {
        return Optional.of(this.f988a.get());
    }
}
