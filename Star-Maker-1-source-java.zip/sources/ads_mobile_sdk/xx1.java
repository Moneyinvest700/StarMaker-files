package ads_mobile_sdk;

import java.lang.ref.WeakReference;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class xx1 {

    /* renamed from: a, reason: collision with root package name */
    public WeakReference f3931a = new WeakReference(null);
    public WeakReference b = new WeakReference(null);
    public WeakReference c = new WeakReference(null);
    public WeakReference d = new WeakReference(null);

    public final void a(WeakReference weakReference) {
        weakReference.getClass();
        this.f3931a = weakReference;
    }

    public final void b(WeakReference weakReference) {
        weakReference.getClass();
        this.d = weakReference;
    }
}
