package ads_mobile_sdk;

import defpackage.d0z;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes11.dex */
public final class zf implements d0z {

    /* renamed from: a, reason: collision with root package name */
    public final FileChannel f4133a;
    public final long b;
    public final long c;

    public zf(FileChannel fileChannel, long j, long j2) {
        this.f4133a = fileChannel;
        this.b = j;
        this.c = j2;
    }

    @Override // defpackage.d0z
    public final void a(MessageDigest[] messageDigestArr, long j, int i) throws IOException {
        MappedByteBuffer map = this.f4133a.map(FileChannel.MapMode.READ_ONLY, this.b + j, i);
        map.load();
        for (MessageDigest messageDigest : messageDigestArr) {
            map.position(0);
            messageDigest.update(map);
        }
    }

    @Override // defpackage.d0z
    public final long size() {
        return this.c;
    }
}
