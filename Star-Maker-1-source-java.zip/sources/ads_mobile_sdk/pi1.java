package ads_mobile_sdk;

import android.os.SystemClock;
import defpackage.hvx;
import defpackage.jsx;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.concurrent.Executor;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class pi1 implements jsx {

    /* renamed from: a, reason: collision with root package name */
    public final Executor f2875a;
    public final hvx b;
    public final PriorityQueue c = new PriorityQueue();

    public pi1(Executor executor, hvx hvxVar) {
        this.f2875a = executor;
        this.b = hvxVar;
    }

    @Override // defpackage.jsx
    public final void a() {
        synchronized (this.c) {
            try {
                if (this.c.isEmpty()) {
                    return;
                }
                PriorityQueue priorityQueue = new PriorityQueue();
                this.b.getClass();
                long jElapsedRealtime = SystemClock.elapsedRealtime();
                zv2 zv2Var = (zv2) this.c.peek();
                while (zv2Var != null && zv2Var.b <= jElapsedRealtime) {
                    priorityQueue.add(zv2Var);
                    zv2Var = (zv2) this.c.peek();
                }
                Iterator it = priorityQueue.iterator();
                while (it.hasNext()) {
                    try {
                        this.f2875a.execute(((zv2) it.next()).f4189a);
                    } catch (RuntimeException unused) {
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.jsx
    public final void a(Runnable runnable, long j) {
        if (j <= 0) {
            this.f2875a.execute(runnable);
            return;
        }
        this.b.getClass();
        zv2 zv2Var = new zv2(runnable, SystemClock.elapsedRealtime() + j);
        synchronized (this.c) {
            this.c.add(zv2Var);
        }
    }
}
