package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum st implements x0z {
    DOWNLOADABLE(0),
    DOWNLOADED(1);


    /* renamed from: a, reason: collision with root package name */
    public final int f3279a;

    st(int i) {
        this.f3279a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3279a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + st.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3279a + " name=" + name() + '>';
    }
}
