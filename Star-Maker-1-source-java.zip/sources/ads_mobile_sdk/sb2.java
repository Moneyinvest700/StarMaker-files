package ads_mobile_sdk;

import com.google.android.libraries.ads.mobile.sdk.common.BaseRequest;
import java.util.concurrent.atomic.AtomicLong;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class sb2 {

    /* renamed from: a, reason: collision with root package name */
    public final AtomicLong f3219a;

    public sb2(BaseRequest baseRequest) {
        baseRequest.getClass();
        this.f3219a = new AtomicLong(baseRequest.getPlacementId());
    }

    public final AtomicLong a() {
        return this.f3219a;
    }
}
