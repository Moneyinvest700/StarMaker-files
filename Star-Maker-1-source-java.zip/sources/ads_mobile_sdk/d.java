package ads_mobile_sdk;

import defpackage.jxy;
import defpackage.kpw;
import defpackage.v3l;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class d {

    /* renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f1309a;

    public d(int i) {
        this.f1309a = v3l.b(i);
    }

    public final void a(String str, jxy jxyVar) {
        LinkedHashMap linkedHashMap = this.f1309a;
        if (jxyVar != null) {
            linkedHashMap.put(str, jxyVar);
        } else {
            kpw.l("provider");
        }
    }
}
