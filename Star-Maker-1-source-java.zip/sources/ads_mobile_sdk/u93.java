package ads_mobile_sdk;

import com.google.android.libraries.ads.mobile.sdk.rewarded.RewardItem;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class u93 implements RewardItem {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ com.google.android.gms.ads.rewarded.RewardItem f3460a;

    public u93(com.google.android.gms.ads.rewarded.RewardItem rewardItem) {
        this.f3460a = rewardItem;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.rewarded.RewardItem
    public final int getAmount() {
        return this.f3460a.getAmount();
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.rewarded.RewardItem
    public final String getType() {
        return this.f3460a.getType();
    }
}
