package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum d50 implements x0z {
    UNSPECIFIED(0),
    PHISHY_CLICK_EVENT(1),
    PHISHY_KEY_EVENT(2),
    PHISHY_PASTE_EVENT(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f1330a;

    d50(int i) {
        this.f1330a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1330a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + d50.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1330a + " name=" + name() + '>';
    }
}
