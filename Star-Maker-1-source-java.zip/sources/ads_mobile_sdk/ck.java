package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ck {

    /* renamed from: a, reason: collision with root package name */
    public int f1257a;
    public long b;
    public Object c;
    public int d;

    public ck(cl0 cl0Var) {
        cl0Var.getClass();
    }
}
