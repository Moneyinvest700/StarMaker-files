package ads_mobile_sdk;

import defpackage.qa5;
import java.util.Iterator;
import kotlin.coroutines.Continuation;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class uh1 extends qa5 {

    /* renamed from: a, reason: collision with root package name */
    public Object f3492a;
    public Iterator b;
    public /* synthetic */ Object c;
    public final /* synthetic */ vh1 d;
    public int e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public uh1(vh1 vh1Var, Continuation continuation) {
        super(continuation);
        this.d = vh1Var;
    }

    @Override // defpackage.pk1
    public final Object invokeSuspend(Object obj) {
        this.c = obj;
        this.e |= Integer.MIN_VALUE;
        return this.d.a(null, this);
    }
}
