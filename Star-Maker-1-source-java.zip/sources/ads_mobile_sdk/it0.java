package ads_mobile_sdk;

import defpackage.lxy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class it0 extends Exception implements lxy {

    /* renamed from: a, reason: collision with root package name */
    public final Throwable f2037a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public it0(Throwable th) {
        super(th);
        th.getClass();
        this.f2037a = th;
    }

    @Override // defpackage.lxy
    public final Throwable a() {
        return this.f2037a;
    }
}
