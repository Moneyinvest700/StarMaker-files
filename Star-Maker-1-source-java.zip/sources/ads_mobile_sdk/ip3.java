package ads_mobile_sdk;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final /* synthetic */ class ip3 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ OutputStream f2025a;
    public final /* synthetic */ int b;

    public /* synthetic */ ip3(ByteArrayOutputStream byteArrayOutputStream, int i) {
        this.b = i;
        this.f2025a = byteArrayOutputStream;
    }
}
