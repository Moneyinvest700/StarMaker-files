package ads_mobile_sdk;

import defpackage.r04;
import defpackage.wqx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class xz1 {

    /* renamed from: a, reason: collision with root package name */
    public final int f3936a;
    public final int b;
    public final boolean c;
    public final double d;

    public xz1(int i, int i2, boolean z, double d) {
        this.f3936a = i;
        this.b = i2;
        this.c = z;
        this.d = d;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof xz1)) {
            return false;
        }
        xz1 xz1Var = (xz1) obj;
        return this.f3936a == xz1Var.f3936a && this.b == xz1Var.b && this.c == xz1Var.c && Double.compare(this.d, xz1Var.d) == 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final int hashCode() {
        int iA = r04.a(this.b, Integer.hashCode(this.f3936a) * 31);
        boolean z = this.c;
        int i = z;
        if (z != 0) {
            i = 1;
        }
        return Double.hashCode(this.d) + ((iA + i) * 31);
    }

    public final String toString() {
        int i = this.f3936a;
        int i2 = this.b;
        boolean z = this.c;
        double d = this.d;
        StringBuilder sbR = wqx.r(i, i2, "NetworkPingStrategy(maxAttempts=", ", initialBackoffMs=", ", bufferAfterMaxAttempts=");
        sbR.append(z);
        sbR.append(", backoffMultiplier=");
        sbR.append(d);
        sbR.append(")");
        return sbR.toString();
    }
}
