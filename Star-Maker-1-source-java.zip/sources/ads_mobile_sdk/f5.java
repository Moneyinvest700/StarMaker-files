package ads_mobile_sdk;

import defpackage.b1y;
import defpackage.gux;
import java.util.Map;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class f5 implements b1y {

    /* renamed from: a, reason: collision with root package name */
    public final Map f1567a;

    public f5(Map map) {
        map.getClass();
        this.f1567a = map;
    }

    @Override // defpackage.b1y
    public final gux a(String str) {
        str.getClass();
        return (gux) this.f1567a.get(str);
    }
}
