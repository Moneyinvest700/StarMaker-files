package ads_mobile_sdk;

import defpackage.amf;
import java.util.ListIterator;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes7.dex */
public final class yg3 implements ListIterator, amf {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ ListIterator f4004a;

    public yg3(ListIterator listIterator) {
        listIterator.getClass();
        this.f4004a = listIterator;
    }

    @Override // java.util.ListIterator
    public final void add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final boolean hasNext() {
        return this.f4004a.hasNext();
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        return this.f4004a.hasPrevious();
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final Object next() {
        return this.f4004a.next();
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        return this.f4004a.nextIndex();
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        return this.f4004a.previous();
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        return this.f4004a.previousIndex();
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.ListIterator
    public final void set(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
