package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class w30 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final w30 f3679a = new w30();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return x30.a(i) != null;
    }
}
