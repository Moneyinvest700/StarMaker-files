package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class wb3 {

    /* renamed from: a, reason: collision with root package name */
    public final String f3718a;
    public final long b;

    public wb3(long j, String str) {
        str.getClass();
        this.f3718a = str;
        this.b = j;
    }

    public final long a() {
        return this.b;
    }
}
