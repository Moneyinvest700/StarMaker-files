package ads_mobile_sdk;

import defpackage.any;
import defpackage.ixx;
import defpackage.jxy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class vi0 implements jxy, any {
    public static final Object c = new Object();
    public static final /* synthetic */ boolean d = true;

    /* renamed from: a, reason: collision with root package name */
    public volatile jxy f3610a;
    public volatile Object b = c;

    public vi0(jxy jxyVar) {
        if (d || jxyVar != null) {
            this.f3610a = jxyVar;
        } else {
            ixx.z();
            throw null;
        }
    }

    public static any a(jxy jxyVar) {
        if (jxyVar instanceof any) {
            return (any) jxyVar;
        }
        jxyVar.getClass();
        return new vi0(jxyVar);
    }

    @Override // defpackage.awy
    public final Object get() {
        Object obj;
        Object obj2 = this.b;
        Object obj3 = c;
        if (obj2 != obj3) {
            return obj2;
        }
        synchronized (this) {
            try {
                obj = this.b;
                if (obj == obj3) {
                    obj = this.f3610a.get();
                    Object obj4 = this.b;
                    if (obj4 != obj3 && obj4 != obj) {
                        throw new IllegalStateException("Scoped provider was invoked recursively returning different results: " + obj4 + " & " + obj + ". This is likely due to a circular dependency.");
                    }
                    this.b = obj;
                    this.f3610a = null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return obj;
    }
}
