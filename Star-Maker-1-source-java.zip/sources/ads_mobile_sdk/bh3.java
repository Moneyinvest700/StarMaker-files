package ads_mobile_sdk;

import defpackage.amf;
import java.util.Map;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class bh3 implements Map.Entry, amf {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Map.Entry f1128a;

    public bh3(Map.Entry entry) {
        entry.getClass();
        this.f1128a = entry;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f1128a.getKey();
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f1128a.getValue();
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
