package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class mx0 {

    /* renamed from: a, reason: collision with root package name */
    public final String f2552a;
    public final long b;

    public mx0() {
        this.f2552a = null;
        this.b = -1L;
    }

    public mx0(long j, String str) {
        this.f2552a = str;
        this.b = j;
    }
}
