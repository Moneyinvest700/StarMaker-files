package ads_mobile_sdk;

import java.util.Set;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class k63 {

    /* renamed from: a, reason: collision with root package name */
    public final Set f2212a;
    public final f63 b;

    public k63(f63 f63Var, Set set) {
        this.f2212a = set;
        this.b = f63Var;
    }
}
