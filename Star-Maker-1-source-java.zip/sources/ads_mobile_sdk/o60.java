package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum o60 implements x0z {
    UNDEFINED(0),
    BROWSER_INITIATED(1),
    RENDERER_INITIATED_WITHOUT_USER_GESTURE(2),
    RENDERER_INITIATED_WITH_USER_GESTURE(3),
    COPY_PASTE_USER_INITIATED(4),
    NOTIFICATION_INITIATED(5);


    /* renamed from: a, reason: collision with root package name */
    public final int f2703a;

    o60(int i) {
        this.f2703a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2703a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + o60.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2703a + " name=" + name() + '>';
    }
}
