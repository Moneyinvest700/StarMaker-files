package ads_mobile_sdk;

import defpackage.wqx;
import java.io.IOException;
import java.util.Locale;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class vu extends IOException {
    /* JADX WARN: Illegal instructions before constructor call */
    public vu(long j, long j2, int i, IndexOutOfBoundsException indexOutOfBoundsException) {
        Locale locale = Locale.US;
        StringBuilder sbU = wqx.u(j, "Pos: ", ", limit: ");
        sbU.append(j2);
        sbU.append(", len: ");
        sbU.append(i);
        super("CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(sbU.toString()), indexOutOfBoundsException);
    }

    public vu(IndexOutOfBoundsException indexOutOfBoundsException) {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.", indexOutOfBoundsException);
    }
}
