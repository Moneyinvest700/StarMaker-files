package ads_mobile_sdk;

import android.content.Intent;
import defpackage.i3h;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ir extends i3h implements Function1 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Intent f2029a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ir(Intent intent) {
        super(1);
        this.f2029a = intent;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String str = (String) obj;
        str.getClass();
        return this.f2029a.setAction(str);
    }
}
