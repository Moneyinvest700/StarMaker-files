package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class qj3 extends Exception {

    /* renamed from: a, reason: collision with root package name */
    public final int f2998a;

    public qj3(int i, Exception exc) {
        super(exc);
        this.f2998a = i;
    }

    public qj3(String str, int i) {
        super(str);
        this.f2998a = i;
    }
}
