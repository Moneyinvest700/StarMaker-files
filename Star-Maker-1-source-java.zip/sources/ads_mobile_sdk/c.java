package ads_mobile_sdk;

import kotlin.KotlinVersion;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f1183a = new byte[256];

    public c(byte[] bArr) {
        for (int i = 0; i < 256; i++) {
            this.f1183a[i] = (byte) i;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < 256; i3++) {
            byte[] bArr2 = this.f1183a;
            byte b = bArr2[i3];
            i2 = (i2 + b + bArr[i3 % bArr.length]) & KotlinVersion.MAX_COMPONENT_VALUE;
            bArr2[i3] = bArr2[i2];
            bArr2[i2] = b;
        }
    }
}
