package ads_mobile_sdk;

import defpackage.gly;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum o8 {
    UNKNOWN,
    /* JADX INFO: Fake field, exist only in values array */
    BANNER,
    /* JADX INFO: Fake field, exist only in values array */
    INTERSTITIAL,
    NATIVE,
    /* JADX INFO: Fake field, exist only in values array */
    REWARDED,
    APP_OPEN,
    /* JADX INFO: Fake field, exist only in values array */
    REWARDED_INTERSTITIAL,
    /* JADX INFO: Fake field, exist only in values array */
    SWIPEABLE_INTERSTITIAL;


    /* renamed from: a, reason: collision with root package name */
    public static final gly f2710a = new gly();
}
