package ads_mobile_sdk;

import defpackage.wqx;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class yc1 {

    /* renamed from: a, reason: collision with root package name */
    public final String f3984a;
    public final String b;

    public yc1(String str, String str2) {
        str.getClass();
        str2.getClass();
        this.f3984a = str;
        this.b = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof yc1)) {
            return false;
        }
        yc1 yc1Var = (yc1) obj;
        return Intrinsics.e(this.f3984a, yc1Var.f3984a) && Intrinsics.e(this.b, yc1Var.b);
    }

    public final int hashCode() {
        return this.b.hashCode() + (this.f3984a.hashCode() * 31);
    }

    public final String toString() {
        return wqx.n("InternalMuteThisAdReason(description=", this.f3984a, ", muteUrl=", this.b, ")");
    }
}
