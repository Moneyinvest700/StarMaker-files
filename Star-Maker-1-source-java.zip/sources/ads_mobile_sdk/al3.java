package ads_mobile_sdk;

import android.view.InputEvent;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class al3 {

    /* renamed from: a, reason: collision with root package name */
    public volatile InputEvent f1018a;
}
