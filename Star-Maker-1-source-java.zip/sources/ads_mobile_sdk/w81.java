package ads_mobile_sdk;

import defpackage.any;
import defpackage.kpw;
import defpackage.vay;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class w81 implements vay, any {
    public static final w81 b = new w81(null);

    /* renamed from: a, reason: collision with root package name */
    public final Object f3702a;

    public w81(Object obj) {
        this.f3702a = obj;
    }

    public static w81 a(Object obj) {
        if (obj != null) {
            return new w81(obj);
        }
        kpw.l("instance cannot be null");
        return null;
    }

    @Override // defpackage.awy
    public final Object get() {
        return this.f3702a;
    }
}
