package ads_mobile_sdk;

import defpackage.any;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class qi {

    /* renamed from: a, reason: collision with root package name */
    public final any f2990a;

    public qi(any anyVar) {
        anyVar.getClass();
        this.f2990a = anyVar;
    }
}
