package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum s60 implements x0z {
    EVENT_URL(1),
    LANDING_PAGE(2),
    LANDING_REFERRER(3),
    CLIENT_REDIRECT(4),
    SERVER_REDIRECT(5),
    RECENT_NAVIGATION(6),
    REFERRER(7);


    /* renamed from: a, reason: collision with root package name */
    public final int f3197a;

    s60(int i2) {
        this.f3197a = i2;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f3197a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + s60.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f3197a + " name=" + name() + '>';
    }
}
