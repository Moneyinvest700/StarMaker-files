package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class i40 implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final i40 f1949a = new i40();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? i != 5 ? null : j40.DOWNLOAD_NOTIFICATION : j40.DOWNLOAD_PROMPT : j40.DOWNLOADS_PAGE : j40.BUBBLE_SUBPAGE : j40.BUBBLE_MAINPAGE : j40.SURFACE_UNSPECIFIED) != null;
    }
}
