package ads_mobile_sdk;

import defpackage.i3h;
import kotlin.jvm.functions.Function0;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class o20 extends i3h implements Function0 {

    /* renamed from: a, reason: collision with root package name */
    public static final o20 f2688a = new o20();

    public o20() {
        super(0);
    }

    @Override // kotlin.jvm.functions.Function0
    public final /* bridge */ /* synthetic */ Object invoke() {
        return "Native Cronet engine initialization skipped as requested. Falling back to Java provider.";
    }
}
