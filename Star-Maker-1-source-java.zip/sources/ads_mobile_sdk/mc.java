package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum mc implements x0z {
    FUNCTION_UNSPECIFIED(0),
    FUNCTION_METHOD_EXCHANGEIMPLEMENTATIONS(1),
    FUNCTION_METHOD_SETIMPLEMENTATIONS(2),
    FUNCTION_CLASS_ADDMETHOD(3),
    FUNCTION_CLASS_REPLACEMETHOD(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f2482a;

    mc(int i) {
        this.f2482a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2482a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + mc.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2482a + " name=" + name() + '>';
    }
}
