package ads_mobile_sdk;

import defpackage.hvx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class d00 {

    /* renamed from: a, reason: collision with root package name */
    public long f1311a;

    public d00(hvx hvxVar) {
        hvxVar.getClass();
        this.f1311a = -1L;
    }
}
