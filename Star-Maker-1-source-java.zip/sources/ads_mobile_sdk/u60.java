package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class u60 {

    /* renamed from: a, reason: collision with root package name */
    public final String f3446a;
    public final wb3 b;
    public final long c;

    public u60(String str, wb3 wb3Var, long j) {
        str.getClass();
        wb3Var.getClass();
        this.f3446a = str;
        this.b = wb3Var;
        this.c = j;
    }

    public final long a() {
        return this.c;
    }
}
