package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum n30 implements x0z {
    SOURCE_UNSPECIFIED(0),
    CLIENT_GENERATION(1);


    /* renamed from: a, reason: collision with root package name */
    public final int f2575a;

    n30(int i) {
        this.f2575a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2575a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + n30.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2575a + " name=" + name() + '>';
    }
}
