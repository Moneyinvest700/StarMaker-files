package ads_mobile_sdk;

import android.app.KeyguardManager;
import android.content.Context;
import android.webkit.WebView;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Iterator;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class iw2 {
    public static final iw2 d = new iw2();

    /* renamed from: a, reason: collision with root package name */
    public WeakReference f2047a;
    public boolean b = false;
    public boolean c = false;

    /* JADX WARN: Multi-variable type inference failed */
    public final void a(boolean z, boolean z2) {
        if ((z2 || z) == (this.c || this.b)) {
            return;
        }
        Iterator it = Collections.unmodifiableCollection(o6.c.f2702a).iterator();
        while (it.hasNext()) {
            p6 p6Var = ((n6) it.next()).d;
            boolean z3 = z2 || z;
            if (p6Var.b.get() != 0) {
                y22.f3949a.a((WebView) p6Var.b.get(), "setDeviceLockState", z3 ? "locked" : "unlocked");
            }
        }
    }

    public final void a() {
        KeyguardManager keyguardManager;
        Context context = (Context) this.f2047a.get();
        if (context == null || (keyguardManager = (KeyguardManager) context.getSystemService("keyguard")) == null) {
            return;
        }
        boolean zIsDeviceLocked = keyguardManager.isDeviceLocked();
        a(this.b, zIsDeviceLocked);
        this.c = zIsDeviceLocked;
    }
}
