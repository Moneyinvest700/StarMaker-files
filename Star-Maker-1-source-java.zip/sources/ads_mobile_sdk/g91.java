package ads_mobile_sdk;

import defpackage.kpw;
import java.nio.ByteBuffer;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public abstract class g91 {

    /* renamed from: a, reason: collision with root package name */
    public static final byte[] f1706a;

    static {
        byte[] bArr = new byte[0];
        f1706a = bArr;
        ByteBuffer.wrap(bArr);
    }

    public static Object a(Object obj, String str) {
        if (obj != null) {
            return obj;
        }
        kpw.l(str);
        return null;
    }

    public static void a(Object obj) {
        obj.getClass();
    }
}
