package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum jc3 {
    UNKNOWN_ERROR(0),
    /* JADX INFO: Fake field, exist only in values array */
    SUCCESSFUL(1),
    UNAUTHORIZED(2),
    INCOMPATIBLE_BUILD(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f2108a;

    jc3(int i) {
        this.f2108a = i;
    }
}
