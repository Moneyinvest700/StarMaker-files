package ads_mobile_sdk;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum s {
    NONE(-2),
    STOPPED(-1),
    PAUSED(0),
    CREATED(1),
    INITIAL(2),
    STARTED(3),
    RESUMED(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f3172a;

    s(int i2) {
        this.f3172a = i2;
    }
}
