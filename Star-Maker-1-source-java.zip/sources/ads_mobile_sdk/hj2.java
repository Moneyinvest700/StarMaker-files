package ads_mobile_sdk;

import defpackage.n5y;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class hj2 implements n5y {

    /* renamed from: a, reason: collision with root package name */
    public final ij2 f1875a;

    public hj2(ij2 ij2Var) {
        this.f1875a = ij2Var;
    }
}
