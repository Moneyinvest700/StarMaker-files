package ads_mobile_sdk;

import com.google.android.libraries.ads.mobile.sdk.common.VideoController;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class cb3 implements VideoController {

    /* renamed from: a, reason: collision with root package name */
    public VideoController.VideoLifecycleCallbacks f1231a;

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final VideoController.VideoLifecycleCallbacks getVideoLifecycleCallbacks() {
        VideoController.VideoLifecycleCallbacks videoLifecycleCallbacks;
        synchronized (this) {
            videoLifecycleCallbacks = this.f1231a;
        }
        return videoLifecycleCallbacks;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final boolean isCustomControlsEnabled() {
        return false;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final boolean isMuted() {
        return false;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final void setVideoLifecycleCallbacks(VideoController.VideoLifecycleCallbacks videoLifecycleCallbacks) {
        synchronized (this) {
            this.f1231a = videoLifecycleCallbacks;
        }
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final void pause() {
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final void play() {
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final void stop() {
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.common.VideoController
    public final void mute(boolean z) {
    }
}
