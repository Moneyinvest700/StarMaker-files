package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum ec implements x0z {
    DEBUGGER_STATE_UNSPECIFIED(0),
    DEBUGGER_STATE_NOT_INSTALLED(1),
    DEBUGGER_STATE_INSTALLED(2),
    DEBUGGER_STATE_ACTIVE(3),
    DEBUGGER_STATE_ENVVAR(4),
    DEBUGGER_STATE_MACHPORT(5),
    DEBUGGER_STATE_ENVVAR_MACHPORT(6);


    /* renamed from: a, reason: collision with root package name */
    public final int f1471a;

    ec(int i2) {
        this.f1471a = i2;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1471a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + ec.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1471a + " name=" + name() + '>';
    }
}
