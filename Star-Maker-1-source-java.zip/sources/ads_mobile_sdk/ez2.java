package ads_mobile_sdk;

import defpackage.qxy;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ez2 {

    /* renamed from: a, reason: collision with root package name */
    public final qxy f1545a;

    public ez2(qxy qxyVar) {
        this.f1545a = qxyVar;
    }
}
