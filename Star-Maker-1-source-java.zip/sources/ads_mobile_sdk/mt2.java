package ads_mobile_sdk;

import defpackage.eny;
import defpackage.jxy;
import defpackage.vay;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class mt2 implements vay {

    /* renamed from: a, reason: collision with root package name */
    public final jxy f2541a;

    public mt2(jxy jxyVar) {
        this.f2541a = jxyVar;
    }

    @Override // defpackage.awy
    public final Object get() {
        eny enyVar = (eny) this.f2541a.get();
        enyVar.getClass();
        return enyVar;
    }
}
