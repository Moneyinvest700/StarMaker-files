package ads_mobile_sdk;

import com.google.android.libraries.ads.mobile.sdk.initialization.AdapterStatus;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class qa implements AdapterStatus {

    /* renamed from: a, reason: collision with root package name */
    public final AdapterStatus.InitializationState f2959a;
    public final String b;
    public final int c;
    public final /* synthetic */ AdapterStatus.InitializationState d;
    public final /* synthetic */ String e;
    public final /* synthetic */ int f;

    public qa(AdapterStatus.InitializationState initializationState, String str, int i) {
        this.d = initializationState;
        this.e = str;
        this.f = i;
        this.f2959a = initializationState;
        this.b = str;
        this.c = i;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.initialization.AdapterStatus
    public final String getDescription() {
        return this.b;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.initialization.AdapterStatus
    public final AdapterStatus.InitializationState getInitializationState() {
        return this.f2959a;
    }

    @Override // com.google.android.libraries.ads.mobile.sdk.initialization.AdapterStatus
    public final int getLatency() {
        return this.c;
    }

    public final String toString() {
        return "Adapter in state " + this.d + " completed in " + this.f + " with description: " + this.e;
    }
}
