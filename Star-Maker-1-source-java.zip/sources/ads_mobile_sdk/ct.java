package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class ct implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final ct f1288a = new ct();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? null : dt.BLOB_TYPE_BRAIN_SUGGEST : dt.BLOB_TYPE_WEB_SUGGEST : dt.BLOB_TYPE_JAR : dt.BLOB_TYPE_DEFAULT : dt.BLOB_TYPE_UNKNOWN) != null;
    }
}
