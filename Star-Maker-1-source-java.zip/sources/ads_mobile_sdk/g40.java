package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum g40 implements x0z {
    ACTION_UNSPECIFIED(0),
    PROCEED(1),
    DISCARD(2),
    KEEP(3),
    CLOSE(4),
    CANCEL(5),
    DISMISS(6),
    BACK(7),
    OPEN_SUBPAGE(8),
    PROCEED_DEEP_SCAN(9),
    OPEN_LEARN_MORE_LINK(10);


    /* renamed from: a, reason: collision with root package name */
    public final int f1691a;

    g40(int i) {
        this.f1691a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f1691a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + g40.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f1691a + " name=" + name() + '>';
    }
}
