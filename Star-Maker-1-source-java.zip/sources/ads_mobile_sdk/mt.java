package ads_mobile_sdk;

import defpackage.x0z;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public enum mt implements x0z {
    BLOB_INCREMENT_NOOP(0),
    BLOB_INCREMENT_BSDIFF(1),
    BLOB_INCREMENT_FILEBYFILE(2);


    /* renamed from: a, reason: collision with root package name */
    public final int f2538a;

    mt(int i) {
        this.f2538a = i;
    }

    @Override // defpackage.x0z
    public final int getNumber() {
        return this.f2538a;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + mt.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.f2538a + " name=" + name() + '>';
    }
}
