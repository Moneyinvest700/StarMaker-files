package ads_mobile_sdk;

import defpackage.crx;

/* compiled from: r8-map-id-45013ab888a439ed2937876cab8d1c62206c8fdca8c993c112c909913faad726 */
/* loaded from: classes4.dex */
public final class at implements crx {

    /* renamed from: a, reason: collision with root package name */
    public static final at f1044a = new at();

    @Override // defpackage.crx
    public final boolean a(int i) {
        return (i != 1 ? i != 2 ? i != 3 ? i != 4 ? null : bt.BLOB_STATE_FAILED : bt.BLOB_STATE_ACTIVE : bt.BLOB_STATE_INACTIVE : bt.BLOB_STATE_AVAILABLE) != null;
    }
}
